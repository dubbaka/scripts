Rem ..............................................................
Rem Name: rbs.sql
Rem Purpose: list of rollback information
Rem
Rem ..............................................................
set pagesize 9999
select b.usn,a.segment_name,a.initial_extent,a.next_extent,a.max_extents,
b.shrinks,b.extents,b.wraps,b.optsize,b.aveshrink,b.aveactive
from dba_rollback_segs a,v$rollstat b
where b.usn=a.segment_id
/
