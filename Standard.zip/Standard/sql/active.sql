Rem ..............................................................
Rem Name: active.sql
Rem Purpose: List of session information for all active sessions
Rem
Rem ..............................................................
set pagesize 9999
column logon_time format a20
column machine format a15
select substr(to_char(spid),1,6) "pid",substr(to_char(sid),1,5) "sid",
substr(to_char(s.serial#),1,6)"ser",substr(s.username,1,13) "DB user",
substr(s.osuser,1,10) "O/S username",
s.status,sql_address,
substr(s.program,1,20) "program",
machine,p.pid "P-pid",s.process "client pid",
to_char(logon_time,'DD-MON-YYYY HH24:MI:SS') logon_time
from v$process p, v$session s
where p.addr=s.paddr
and status='ACTIVE'
and background is null
/

