Rem ..............................................................
Rem Name: redo.sql
Rem Purpose:  getting the user information for redo 
Rem		which size > 100000
Rem ..............................................................
column sid format 9999
column osuser format a10
column username format a15
column program format a30
select s.sid,s.serial#,s.username,s.program, value RedoSize
from v$session s, v$sesstat a, v$statname b
where a.statistic#=b.statistic#
and value > 100000
and name like '%redo size%'
and s.sid=a.sid
order by value
/

