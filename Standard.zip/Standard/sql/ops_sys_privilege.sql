
--  To make ops$oracle, SOX compliant
--
--  These are the approved list of sys privileges
--  granted to ops$oracle to replace dba privs
--
--  List as of 6/15/2006

--  Revoke DBA

revoke dba from ops$oracle;

--  Add grants 

grant connect to ops$oracle with admin option;
grant resource to ops$oracle with admin option;

grant create tablespace to ops$oracle;
grant drop tablespace to ops$oracle;
grant alter tablespace to ops$oracle;

grant alter system to ops$oracle;
grant alter database to ops$oracle;

grant create user to ops$oracle;
grant alter user to ops$oracle;
grant drop user to ops$oracle;

grant select any table to ops$oracle;

grant create any index to ops$oracle;
grant alter any index to ops$oracle;

grant grant any privilege to ops$oracle;
grant exp_full_database to ops$oracle;
grant analyze any to ops$oracle;

grant cisco_std_user to ops$oracle with admin option;
grant cisco_std_admin to ops$oracle with admin option;

-- In case of 8i
grant Select_catalog_role to ops$oracle;

-- In case of 9i
grant Select any dictionary to ops$oracle;

-- added on 7/11/2006

grant CISCO_PERF_ADMIN to ops$oracle with admin option;

grant drop any index to ops$oracle;

grant global query rewrite to ops$oracle;
grant query rewrite to ops$oracle;

grant lock any table to ops$oracle;

grant AQ_ADMINISTRATOR_ROLE to ops$oracle;
GRANT EXECUTE ON DBMS_AQADM TO ops$oracle;   
GRANT EXECUTE ON DBMS_AQ TO ops$oracle;

-- added on 7/12

grant create profile to ops$oracle; 
grant alter profile to ops$oracle; 

grant ALTER ROLLBACK SEGMENT to ops$oracle;	
grant select on sys.link$ to ops$oracle;


