-- This script creates a profile that will be used to assign
-- to all database accounts whose username matches with that of
-- cec id.
-- Password expiry is set to 180 days with 10 days grace period
-- for the user to change the password every 180 days.

create profile cec_profile
limit
PASSWORD_LIFE_TIME 170
PASSWORD_GRACE_TIME 10
PASSWORD_REUSE_TIME UNLIMITED
PASSWORD_REUSE_MAX 1
FAILED_LOGIN_ATTEMPTS UNLIMITED
PASSWORD_LOCK_TIME 1/1440
/
