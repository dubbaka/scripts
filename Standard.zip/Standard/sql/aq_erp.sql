set doc off
prompt *******************************************************************
prompt Workflow Advanced Queue SQL Queries to help troubleshoot the Queues
prompt *******************************************************************
Prompt Basic Queue Information 
select q.OWNER OWNER, q.NAME QUEUE_NAME, o.STATUS QUEUE_STATUS, q.ENQUEUE_ENABLED ENQUEUE, q.DEQUEUE_ENABLED DEQUEUE, to_char(q.MAX_RETRIES) RETRIES, q.RETENTION, to_char(q.RETRY_DELAY) RETRY_DELAY
from   ALL_QUEUES q, DBA_OBJECTS o
where (q.NAME = o.OBJECT_NAME and o.object_type = 'QUEUE') and (q.NAME LIKE 'WF%' OR q.NAME LIKE 'ECX%')
order by q.NAME;
/* Example
OWNER	QUEUE_NAME	QUEUE_STATUS	ENQUEUE	DEQUEUE	RETRIES	RETENTION  RETRY_DELAY
------- ------------------- --------- --------- ------- ------- ---------  -----------
APPS	ECX_INBOUND	        VALID	  YES  	  YES  	5	0	   0
APPS	ECX_IN_OAG_Q	        VALID	  YES  	  YES  	5	0	   0
APPS	ECX_OUTBOUND	        VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_CONTROL	        VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_DEFERRED	        VALID	  YES  	  YES  	5	86400	   3600
APPLSYS	WF_DEFERRED_QUEUE_M	VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_ERROR	        VALID	  YES  	  YES  	5	0	   3600
APPLSYS	WF_IN	                VALID	  YES  	  YES  	5	604800	   0
APPLSYS	WF_INBOUND_QUEUE	VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_JAVA_DEFERRED	VALID	  YES  	  YES  	5	86400	   3600
APPLSYS	WF_JAVA_ERROR	        VALID	  YES  	  YES  	5	0	   3600
APPLSYS	WF_JMS_IN	        VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_JMS_JMS_OUT	        VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_JMS_OUT	        VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_NOTIFICATION_IN	VALID	  YES  	  YES  	5	86400	   3600
APPLSYS	WF_NOTIFICATION_OUT	VALID	  YES  	  YES  	5	86400	   3600
APPLSYS	WF_OUT	                VALID	  YES  	  YES  	5	604800	   0
APPLSYS	WF_OUTBOUND_QUEUE	VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_REPLAY_IN	        VALID	  YES  	  YES  	5	604800	   0
APPLSYS	WF_REPLAY_OUT	        VALID	  YES  	  YES  	5	604800	   0
APPLSYS	WF_SMTP_O_1_QUEUE	VALID	  YES  	  YES  	0	0	   0
APPLSYS	WF_WS_JMS_IN	        VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_WS_JMS_OUT	        VALID	  YES  	  YES  	5	0	   0
APPLSYS	WF_WS_SAMPLE	        VALID	  YES  	  YES  	5	0	   0
*/
Prompt Queue Rules Information 
select rule_condition, rule_name from dba_rules 
where rule_name like 'WF%'
/*
RULE_CONDITION	        RULE_NAME
---------------------   ----------------------
1=1	                WF_WS_SAMPLE$21
CORRID like 'APPS%'	WF_DEFERRED_QUEUE_M$1
1=1	                WF_WS_JMS_OUT$21
1=1	                WF_JAVA_ERROR$21
1=1	                WF_DEFERRED$21
1=1	                WF_JMS_OUT$21
1=1	                WF_REPLAY_OUT$3
1=2	                WF_ERROR$21
1=2	                WF_OUT$4
1=1	                WF_JMS_IN$21
1=1	                WF_NOTIFICATION_OUT$21
1=2	                WF_IN$5
1=1	                WF_JAVA_DEFERRED$21
1=1	                WF_NOTIFICATION_IN$21
1=1	                WF_WS_JMS_IN$1
1=1	                WF_JMS_JMS_OUT$1
1=1	                WF_REPLAY_IN$3
*/

prompt **************************************************************
prompt *******         WF_DEFERRED QUEUE TROUBLESHOOTING      *******
prompt ******* The next statements will show how many events  ******* 
prompt ******* of each type are in the WF_DEFERRED queue:     *******
prompt **************************************************************
/*
 Name                            Null?    Type
 ------------------------------- -------- ----
 PRIORITY                                 NUMBER
 SEND_DATE                                DATE
 RECEIVE_DATE                             DATE
 CORRELATION_ID                           VARCHAR2(240)
 PARAMETER_LIST                           WF_PARAMETER_LIST_T
 EVENT_NAME                               VARCHAR2(240)
 EVENT_KEY                                VARCHAR2(240)
 EVENT_DATA                               CLOB
 FROM_AGENT                               WF_AGENT_T
 TO_AGENT                                 WF_AGENT_T
 ERROR_SUBSCRIPTION                       RAW(16)
 ERROR_MESSAGE                            VARCHAR2(4000)
 ERROR_STACK                              VARCHAR2(4000)
*/
--column EVENT_NAME format a40;
select w.user_data.event_name EVENT_NAME,
       count(*) COUNT
from WF_DEFERRED w
group by w.user_data.event_name

select wfd.user_data.EVENT_NAME EVENT_NAME,
decode(wfd.state,
       0, '0 = Ready',
       1, '1 = Delayed',
       2, '2 = Retained',
       3, '3 = Exception',
to_char(substr(wfd.state,1,12))) State,
count(*) COUNT
from applsys.wf_deferred wfd
group by wfd.user_data.EVENT_NAME, wfd.state
order by 3 desc, 1 asc

prompt View the Events that have been processed in the Queue Specified 
select wfd.user_data.EVENT_NAME EVENT_NAME,
decode(wfd.state,
       0, '0 = Ready',
       1, '1 = Delayed',
       2, '2 = Retained',
       3, '3 = Exception',
to_char(substr(wfd.state,1,12))) State,
count(*) COUNT
from applsys.wf_deferred wfd
group by wfd.user_data.EVENT_NAME, wfd.state
order by 3 desc, 1 asc
*/
EVENT_NAME	                        STATE	     COUNT
--------------------------------------- ------------ -----
oracle.apps.wf.notification.denormalize	2 = Retained	1
oracle.apps.wf.notification.send	2 = Retained	1

--OR--
*/
prompt WF_DEFERRED 
prompt View the Events that have been processed in the Queue Specified 
select corr_id, msg_state , count(*) from applsys.aq$wf_deferred where 
corr_id like 'APPS:oracle.apps.wf%' group by corr_id, 
msg_state;
/*
CORR_ID	                                     MSG_STATE	COUNT
-------------------------------------------- ---------- ------
APPS:oracle.apps.wf.notification.send	     PROCESSED	1
APPS:oracle.apps.wf.notification.denormalize PROCESSED	1
*/
prompt Check messages sent in the last day
select status, mail_status, count(*) 
from wf_notifications 
--where begin_date > sysdate-1 
group by status, mail_status

prompt Monitor the Queue: Run the following statement in SQL*Plus to monitor messages on the queue.
prompt The topmost line will be the first to be dequeued off the Deferred queue.
select corrid, user_data user_data
from wf_deferred_table_m
where state = 0
order by priority, enq_time;

prompt Monitor the Queue by Item Type ie APPS<itemtype>
select corrid, user_data user_data
from wf_deferred_table_m
where state = 0
and corrid = 'APPSOEOH'
order by priority, enq_time;


prompt *************************************************************
prompt *******         WF_CONTROL QUEUE TROUBLESHOOTING      *******
prompt ** 11.5.9 issue with Cache Invalidation & turning it off.  **
prompt ** Review Note 295016.1 - Workflow WF_CONTROL queue getting** 
prompt ** 'library cache lock' causes Applications to hang        **
prompt *************************************************************

prompt To find the columns in USER_DATA of data type WF_EVENT_T do this :
prompt SQL> desc wf_event_t  (Run via SQLPLUS, does not run on TOAD)
prompt  Name                            Null?    Type
prompt  ------------------------------- -------- ----
prompt  PRIORITY                                 NUMBER
prompt  SEND_DATE                                DATE
prompt  RECEIVE_DATE                             DATE
prompt  CORRELATION_ID                           VARCHAR2(240)
prompt  PARAMETER_LIST                           WF_PARAMETER_LIST_T
prompt  EVENT_NAME                               VARCHAR2(240)
prompt  EVENT_KEY                                VARCHAR2(240)
prompt  EVENT_DATA                               CLOB
prompt  FROM_AGENT                               WF_AGENT_T
prompt  TO_AGENT                                 WF_AGENT_T
prompt  ERROR_SUBSCRIPTION                       RAW(16)
prompt  ERROR_MESSAGE                            VARCHAR2(4000)
prompt  ERROR_STACK                              VARCHAR2(4000)
prompt ************************************************************
prompt Check the status of Events in the Control Queue 
select substr(wfc.user_data.GET_STRING_PROPERTY('BES_EVENT_NAME'),1,50) EVENT_NAME,
decode(wfc.state,
       0, '0 = Ready',
       1, '1 = Delayed',
       2, '2 = Retained',
       3, '3 = Exception',
to_char(substr(wfc.state,1,12))) State,
count(*) COUNT
from applsys.wf_control wfc
group by wfc.user_data.GET_STRING_PROPERTY('BES_EVENT_NAME'), wfc.state
/*
EVENT_NAME	                                STATE	    COUNT
----------------------------------------------  --------- -------
oracle.apps.fnd.cp.gsc.SvcComponent.start	0 = Ready	8
oracle.apps.fnd.cp.gsc.SvcComponent.refresh	0 = Ready	1
*/

prompt Check for Subscribers on the WF_CONTROL Queue 
select queue_name,
decode(subscriber_type,
           NULL, 'Subscriber Table exists',
              0, '0 = Ready',
              1, '1 = Current Subscriber',
              2, '2 = Ex-Subscriber',
              4, '4 = Address',
              8, '8 = Proxy',
              1224, '1224 = Proxy in 9.2+ (like 8)',
              65, '65 = Current Subscriber in 9.2+ (like 1)',  
              2, '2 = Ex-Subscriber',
              to_char(subscriber_type)) Subscriber_Type,
count(*)
from applsys.aq$_wf_control_s 
group by queue_name, subscriber_type;
/*
QUEUE_NAME	SUBSCRIBER_TYPE	                            COUNT
--------------  ----------------------------------------  -------
0	        Subscriber Table exists	                        1
WF_CONTROL	2 = Ex-Subscriber	                       12
WF_CONTROL	4 = Address	                                1
WF_CONTROL	65 = Current Subscriber in 9.2+ (like 1)	9
*/

prompt Check the WF_CONTROL History tables for high volume
Select i.name, count(*) from APPLSYS.AQ$_WF_CONTROL_I i group by i.name;

Select t.ACTION, count(*) from APPLSYS.AQ$_WF_CONTROL_T t group by t.action;

Select h.NAME, count(*) from APPLSYS.AQ$_WF_CONTROL_H h group by h.name;


prompt *************************************************************
prompt ****    Checking the Workflow Background Engine Queue    ****
prompt ****         NOT the WF_DEFERRED Events Queue            ****
prompt *************************************************************

prompt BACKGROUND PROCESSES QUEUE (Not Events Deferred Queue) 
prompt To find the columns in USER_DATA of data type WF_PAYLOAD_T do this :
prompt SQL> desc system.wf_payload_t
prompt  Name                            Null?    Type
prompt  ------------------------------- -------- ----
prompt  ITEMTYPE                                 VARCHAR2(8)
prompt  ITEMKEY                                  VARCHAR2(240)
prompt  ACTID                                    NUMBER
prompt  FUNCTION_NAME                            VARCHAR2(200)
prompt  PARAM_LIST                               VARCHAR2(4000)
prompt  RESULT                                   VARCHAR2(30)
prompt **************************************************************  
prompt Summary of what is happening in the WF_DEFERRED_TABLE_M for Background Processes 
select corrid,
decode(state, 0, '0 = Ready',
		      1, '1 = Delayed',
		      2, '2 = Retained',
		      3, '3 = Exception',
to_char(state))  State,
count(*) COUNT
from wf_deferred_table_m
group by corrid, state;
/*
CORRID	        STATE	      COUNT
------------  -------------  ------
APPSOEOH	0 = Ready	215
APPSOEOH	1 = Delayed	8
APPSCNCOMPPR	1 = Delayed	1
APPSPACRMUPD	0 = Ready	5
APPSSERVEREQ	0 = Ready	1
*/

prompt Show what is exactly on the Background Process Deferred Queue ready for processing
select w.user_data.itemtype "Item Type", w.user_data.itemkey "Item Key",
decode(w.state, 0, '0 = Ready',
		      1, '1 = Delayed',
		      2, '2 = Retained',
		      3, '3 = Exception',
to_char(w.state))  State,
w.priority, w.ENQ_TIME, w.DEQ_TIME, w.msgid
from wf_deferred_table_m w
where w.user_data.itemtype = 'OEOH';
/*
Item 	Item 
Type    Key    	STATE	    PRIORITY	ENQ_TIME	      DEQ_TIME	                          MSGID
----    -----  ------------ ---------  ---------------------- -------- ---------------------------------
OEOH	93155	0 = Ready	1	12/4/2003 5:35:16 AM		CDA5FA92A17F918EE030928D011519DD
OEOH	93157	0 = Ready	1	12/4/2003 5:35:25 AM		CDA5FA92A184918EE030928D011519DD
OEOH	93162	0 = Ready	1	12/4/2003 5:35:30 AM		CDA5FA92A188918EE030928D011519DD
OEOH	93139	0 = Ready	1	12/4/2003 5:34:55 AM		CDA5FA92A172918EE030928D011519DD
OEOH	93147	0 = Ready	1	12/4/2003 5:35:05 AM		CDA5FA92A179918EE030928D011519DD
OEOH	93165	0 = Ready	1	12/4/2003 5:35:36 AM		CDA5FA92A18A918EE030928D011519DD
OEOH	93168	0 = Ready	1	12/4/2003 5:35:44 AM		CDA5FA92A18F918EE030928D011519DD
OEOH	93173	0 = Ready	1	12/4/2003 5:35:51 AM		CDA5FA92A194918EE030928D011519DD
OEOH	45188	1 = Delayed	1	4/21/2005 10:16:54 AM		F542F95925BDC087E030018A5B302C12
OEOH	45354	1 = Delayed	1	4/21/2005 10:16:55 AM		F542F95925BEC087E030018A5B302C12
OEOH	45355	1 = Delayed	1	4/21/2005 10:16:55 AM		F542F95925BFC087E030018A5B302C12
OEOH	45190	1 = Delayed	1	4/21/2005 10:16:55 AM		F542F95925C0C087E030018A5B302C12
OEOH	45185	1 = Delayed	1	4/21/2005 10:16:55 AM		F542F95925C1C087E030018A5B302C12
OEOH	45352	1 = Delayed	1	4/21/2005 10:16:55 AM		F542F95925C2C087E030018A5B302C12
OEOH	45187	1 = Delayed	1	4/21/2005 10:16:55 AM		F542F95925C3C087E030018A5B302C12
OEOH	45189	1 = Delayed	1	4/21/2005 10:16:55 AM		F542F95925C4C087E030018A5B302C12
*/
