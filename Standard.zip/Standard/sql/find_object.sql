Rem ..............................................................
Rem Name: find_object.sql
Rem Purpose: find object information
Rem
Rem ..............................................................
set pagesize 9999
column owner format a15
column segment_name format a40
column segment_type format a15
select owner,segment_name,segment_type,tablespace_name
from dba_extents
where file_id=&file
and &block between block_id and block_id + blocks -1
/

