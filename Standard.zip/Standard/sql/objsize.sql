Rem ..............................................................
Rem Name: objsize.sql
Rem Purpose:  to find the size of object
Rem
Rem ..............................................................
column owner format a10
column segment_name format a30
column segment_type format a10
column tablespace_name format a20
select owner,segment_name,segment_type type,
bytes,extents,tablespace_name
from dba_segments
where segment_name=upper('&segname')
/
