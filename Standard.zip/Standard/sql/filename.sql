Rem ..............................................................
Rem Name: filename.sql
Rem Purpose: list of database filename per tablespacename 
Rem
Rem ..............................................................
set pagesize 9999
column tablespace_name format a20
column file_name format a40
select tablespace_name,file_name,bytes
from dba_data_files
where tablespace_name=upper('&tablespacename')
/
