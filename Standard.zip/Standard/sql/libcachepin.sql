Rem ..............................................................
Rem Name: libcachepin.sql
Rem Purpose:  to find the session for library cache pin
Rem
Rem ..............................................................
set pagesize 9999
connect / as sysdba
  select sid Holder,
  KGLPNMOD Held, 
  KGLPNREQ Req
  from x$kglpn , v$session
  where KGLPNHDL in (select p1raw from v$session_wait
  where wait_time=0 and event like 'library cache pin%')
  and KGLPNMOD <> 0
  and v$session.saddr=x$kglpn.kglpnuse 
/

