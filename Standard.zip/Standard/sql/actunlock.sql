Rem ..............................................................
Rem Name: actunlock.sql
Rem Purpose: account unlock
Rem
Rem ..............................................................
set pagesize 9999
undefine actname
define userlock=&&actname
alter user &userlock account unlock;
select * from dba_users
where username=upper('&userlock');
