set ver off lines 150 pages 60 pause on pause more...

col sid format 999
col username format a10
col osuser format a10
col program format a25
col process format 9999999
col spid format a5
col pid format 999
col serial# format 99999 head SER
col program format a15 trunc
REM col module format a25 trunc
col module format a35 trunc
col logon_time format a11

select v.sid, v.username,  v.osuser, v.process
, p.pid, p.spid, /* p.username, */ v.status,
v.serial# /* , p.program */
, lockwait, v.terminal, to_char(logon_time, 'DD/MM HH24:MI') logon_time, v.program, module 
-- , object
from v$session v, v$process p
--, v$access a
where v.paddr = p.addr (+)
-- and lockwait is not null
-- and a.sid = v.sid
and v.serial# > 1
and p.background is null
and p.username is not null
-- and a.object = 'COM_TRANS_SCD_DETAIL_REF_H'
order by 1
/

col sql_text format a150
col disk_reads format 999999999 head "DISK|READS"
col buffer_gets format 999999999 head "BUFFER|GETS"
col memory format 999999999

select b.sql_text, first_load_time, executions, rows_processed, sorts, disk_reads, buffer_gets, runtime_mem + persistent_mem  + sharable_mem memory
from v$open_cursor a, v$sqlarea b
where a.address = b.address
and a.hash_value = b.hash_value
and sid = &sid
order by disk_reads desc
-- order by b.address, piece
/
