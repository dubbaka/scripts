grant CREATE TABLE to gesadm;
grant CREATE VIEW to gesadm;
grant CREATE SESSION to gesadm;
grant CREATE SYNONYM to gesadm;
grant CREATE INDEX to gesadm;
grant CREATE PROCEDURE to gesadm;
grant SELECT ANY TABLE to gesadm;
grant SELECT_CATALOG_ROLE to gesadm;
grant CREATE TRIGGER to gesadm;
grant CREATE ANY TRIGGER to gesadm;
grant CREATE DATABASE LINK to gesadm;

