Rem ..............................................................
Rem Name: sessmem.sql
Rem Purpose: List of session information for memory
Rem
Rem ..............................................................
col sid for 999999
col schemaname for a15
col osuser for a8
col machine for a12
col buffer_gets format 9999999
col memory format 99999999
select /*+ RULE */
a.sid, status,schemaname, osuser, machine,sum(disk_reads) disk_reads, 
sum(buffer_gets) buffer_gets,
sum(runtime_mem + persistent_mem  + sharable_mem) memory
from v$open_cursor a, v$sqlarea b, v$session c
where a.address = b.address
and a.hash_value = b.hash_value
and a.sid = c.sid
group by a.sid,status,schemaname, osuser, machine
order by memory desc
/

