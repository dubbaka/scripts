rem .................................................
rem     Generica Create Standard User Script
rem .................................................
undefine useradmin
undefine userreg
undefine tbdata
undefine tbindex
undefine adminpwd
undefine userpwd
define adminuser=&&useradmin
define reguser=&&userreg
define data=&&tbdata
define index=&&tbindex
create user &adminuser identified by &adminpwd password expire
default tablespace &data
temporary tablespace temp
quota unlimited on &data
quota unlimited on &index
quota unlimited on temp
/
create user &reguser identified by &userpwd password expire
default tablespace &data
temporary tablespace temp
quota unlimited on &data
quota unlimited on &index
quota unlimited on temp
/
grant cisco_std_admin to &adminuser
/
grant cisco_std_user to &reguser
/

