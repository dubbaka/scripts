Rem ..............................................................
Rem Name: genoskill.sql
Rem Purpose: generate list of OS (PID) to be killed
Rem          based on username or machine
Rem ..............................................................
set pagesize 9999
spool /tmp/kill.sql
select '!kill -15 '||spid
from v$process p, v$session s
where p.addr=s.paddr
and background is null
and (s.username like upper('&username')
or s.machine like ('&machine')
)
/
spool off
prompt ******** File generated at /tmp/kill.sql *************

