Rem ..............................................................
Rem Name: invalid.sql
Rem Purpose: to list of invalid objects
Rem
Rem ..............................................................
column owner format a10
column object_name format a30
column object_type format a15
select owner,object_name,object_type,last_ddl_time,status
from dba_objects
where status ='INVALID'
order by owner,object_name
/

