Rem ..............................................................
Rem Name: analyze_index.sql
Rem Purpose: analyze index
Rem
Rem ..............................................................
undefine ownername
undefine indexname
define ownername=&&ownername
define indexname=&&indexname
exec dbms_stats.gather_index_stats (ownname=>'&ownername', indname=>'&indexname',estimate_percent=>90);

