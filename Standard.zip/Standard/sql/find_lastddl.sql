Rem ..............................................................
Rem Name: lastddl.sql
Rem Purpose: to find the latest DDL objects
Rem
Rem ..............................................................
column owner format a10
column object_name format a30
column object_type format a15
select owner,object_name,object_type,last_ddl_time,status
from dba_objects
where owner not in ('SYS','SYSTEM')
and last_ddl_time > (sysdate-&numofdays)
/
