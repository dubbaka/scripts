Rem ..............................................................
Rem Name: count.sql
Rem Purpose: count the session based on hosts
Rem
Rem ..............................................................
set pagesize 9999
column machine format a45
select machine,count(*)
from v$session
group by machine
/
