Rem ..............................................................
Rem Name: tempuse.sql
Rem Purpose: get session information for temporary tablespace
Rem
Rem ..............................................................
column username format a15
column tablespace format a20
select /*+ RULE */ v.username,v.sid,v.serial#,tablespace,blocks
from v$session v,v$sort_usage s
where v.saddr=s.session_addr
/

