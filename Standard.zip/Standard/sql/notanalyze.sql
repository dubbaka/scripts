Rem ..............................................................
Rem Name: notanalyze.sql
Rem Purpose: list of objects which have not been analyzed
Rem
Rem ..............................................................
set pagesize 9999
column owner format a12
column table_name format a25
select owner,table_name,num_rows,sample_size,last_analyzed
from dba_tables
where owner not in ('SYS','SYSTEM')
and (last_analyzed < sysdate - nvl('&numofdays',0)
or last_analyzed is null)
/
select owner,index_name,num_rows,sample_size,last_analyzed
from dba_indexes
where owner not in ('SYS','SYSTEM')
and (last_analyzed < sysdate - nvl('&numofdays',0)
or last_analyzed is null)
/

