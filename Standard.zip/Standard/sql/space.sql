Rem ..............................................................
Rem Name: space.sql
Rem Purpose: list of tablespaces with total ,free mbytes,
Rem          pct free, big chunk, used pieces
Rem
Rem ..............................................................
set pagesize 9999
column tablespace_name format a15
column pieces format 999999
select files.tablespace_name, round(files.mbytes) "TOTAL(M)",
nvl(round(free.mbytes), 0) "FREE(M)",
nvl(round((free.mbytes/files.mbytes) * 100), 0) PCT_FREE,
nvl(chunk, 0) chunk, round(files.mbytes) - nvl(round(free.mbytes), 0) used, 
pieces
from    (select tablespace_name, sum(bytes)/1024/1024 mbytes
        from dba_data_files
        group by tablespace_name) files,
        (select tablespace_name, sum(bytes)/1024/1024 mbytes,
        round(max(bytes)/1024/1024) chunk,
        max(bytes) bytes, count(*) pieces
        from dba_free_space
        group by tablespace_name) free
where free.tablespace_name (+) = files.tablespace_name
order by 1
/

