Rem ..............................................................
Rem Name: genkill.sql
Rem Purpose: generate list of alert system sql to be killed
Rem          based on username or machine
Rem ..............................................................
set pagesize 9999
spool /tmp/kill.sql
select 'alter system kill session '''||sid||','||s.serial#||''';'
from v$process p, v$session s
where p.addr=s.paddr
and background is null
and (s.username like upper('&username')
or s.machine like ('&machine')
)
/
prompt ******** File generated at /tmp/kill.sql *************

