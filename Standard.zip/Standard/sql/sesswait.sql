Rem ..............................................................
Rem Name: sesswait.sql
Rem Purpose: List of session information on wait event
Rem
Rem ..............................................................
set pagesize 9999
col sid           format 999 
col "SPID"        format 99999
col "PID"         format 9999
col machine       format a10
col "Logged On"   format a11
col event         format a30
col state         format a17
col "Block"       format 999 
col username      format a15
col "Ser#"        format 99999 
col osuser        format a8
col OBJName	  format a30
select /*+ RULE */ w.holding_session "Block", 
                s.sid, 
                s.serial# "Ser#",
                p.pid "PID",
        p.spid "SPID",
        sw.p2,
        s.username,
        osuser,
        machine,
        to_char(logon_time,'mm/dd hh24:mi') "Logged On",
        event,
	t.name OBJName,
        seconds_in_wait "Secs Waited",   
        state
   from v$session s ,
        v$process p,
                v$session_wait sw,
                sys.dba_waiters w,
		sys.obj$ t
  where p.addr(+)= s.paddr
        and s.type   = 'USER' 
        and s.sid    = sw.sid
        and s.sid    = w.waiting_session (+)
        and seconds_in_wait > 1
        and event   not like  'SQL*Net message%'
        and event   not like  'rdbms ipc%' 
	and sw.p1 = t.obj#
/


