Rem ..............................................................
Rem Name: archrate.sql
Rem Purpose: List of number of archive logs per hour
Rem
Rem ..............................................................
set pagesize 9999
select to_char(first_time, 'DD-MON-YYYY HH24')TimeFrame, 
count(*) "NumofArchiveLogs"
from v$log_history
group by to_char(first_time, 'DD-MON-YYYY HH24')
/


