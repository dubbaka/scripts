Rem ..............................................................
Rem Name: rbsuser.sql
Rem Purpose:  get active sid in rollback
Rem
Rem ..............................................................
set pagesize 9999
column sid format 99999
column "Rollback" format a10
column username format a12
column program format a30
column ublk format 99999
column urec format 99999
select /*+ RULE */ s.sid,s.username,r.name "Rollback",s.program,
t.used_ublk ublk, t.used_urec urec
from v$session s, v$transaction t, v$rollname r
where s.taddr=t.addr
and t.xidusn=r.usn
/

