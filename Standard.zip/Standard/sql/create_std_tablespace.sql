rem ........................................................
rem	Create new tablespace with standard script
rem ........................................................
undefine tbspace
undefine filename
undefine tbsize
define space=&&tbspace
define namefile=&&filename
define sizetb=&&tbsize
create tablespace &space
datafile '&namefile' size &sizetb
        extent management local autoallocate
/


