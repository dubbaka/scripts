Rem ..............................................................
Rem Name: analyze_table.sql
Rem Purpose: analyze table
Rem
Rem ..............................................................
undefine ownername
undefine tablename
define ownername=&&ownername
define tablename=&&tablename
exec dbms_stats.gather_table_stats (ownname=>'&ownername', tabname=>'&tablename',block_sample=>true,estimate_percent=>90,degree=>4,cascade=>true,granularity=>'ALL');

