--Script to Change passwords by changing user profiles and reverting back
--Created By Sunil J.S
--Created On 06/20/2009
-- Fixed the issue to take care spl char in password - Rama, 06/21/2009

CREATE OR REPLACE PROCEDURE change_user_profile (
   p_username   IN   VARCHAR2,
   p_password   IN   VARCHAR2
)
IS
   v_profile   VARCHAR2 (1000);
   v_limit     VARCHAR2 (1000);
   v_debug     VARCHAR2(100);
BEGIN
   v_debug := 'Procedure started selecting profile';

   SELECT PROFILE
     INTO v_profile
     FROM dba_users
    WHERE username = p_username;

   v_debug := 'Selecting v_limit';

   SELECT LIMIT
     INTO v_limit
     FROM dba_profiles
    WHERE resource_name = 'PASSWORD_VERIFY_FUNCTION' AND PROFILE = v_profile;

   v_debug := 'Altering profile setting password_verify_function to null';
   v_debug := 'alter profile '
                     || v_profile
                     || ' limit password_verify_function null';

   EXECUTE IMMEDIATE    'alter profile '
                     || v_profile
                     || ' limit password_verify_function null';

   v_debug := 'Altering user changing system password';

   EXECUTE IMMEDIATE 'alter user '||p_username||' identified by "' || p_password ||'"';

   v_debug := 'Altering profile back to original value';

   EXECUTE IMMEDIATE    'alter profile '
                     || v_profile
                     || ' limit password_verify_function '
                     || v_limit;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.put_line (v_debug || '=>' || SQLERRM);
END;
/
SHOW ERRORS;


