drop user eman_apmon cascade; 
drop profile eman_db_monitor;

create user eman_apmon identified by c1sc0 temporary tablespace temp;
grant create session to eman_apmon;

CREATE PROFILE eman_db_monitor
    LIMIT  SESSIONS_PER_USER          3
           CPU_PER_SESSION            unlimited
           CPU_PER_CALL               unlimited
           CONNECT_TIME               1
           IDLE_TIME                  1
           LOGICAL_READS_PER_SESSION  unlimited
           LOGICAL_READS_PER_CALL     unlimited;
 
alter profile EMAN_DB_MONITOR limit PASSWORD_REUSE_TIME unlimited;
alter profile EMAN_DB_MONITOR limit PASSWORD_LOCK_TIME unlimited;
alter profile EMAN_DB_MONITOR limit PASSWORD_GRACE_TIME unlimited;
alter profile EMAN_DB_MONITOR limit PASSWORD_LIFE_TIME unlimited;

alter user eman_apmon profile eman_db_monitor;

