Rem ..............................................................
Rem Name: genkillidle.sql
Rem Purpose: generate the idle processes
Rem
Rem ..............................................................
set pagesize 999
spool /tmp/kill.sql
select '!kill -15 '||spid from v$process p
where background is null
and not exists
(select 'x' from v$session s
where s.paddr=p.addr)
/
spool off
prompt ******** File generated at /tmp/kill.sql *************
