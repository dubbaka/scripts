Rem ..............................................................
Rem Name: analyze_schema.sql
Rem Purpose: analyze schema
Rem
Rem ..............................................................
set time on
set timing on
undefine ownername
define ownername=&&ownername
exec dbms_stats.gather_schema_stats (ownname=>'&ownername', estimate_percent=>90,degree=>4,cascade=>true,granularity=>'ALL',block_sample=>true);

