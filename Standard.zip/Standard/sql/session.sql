Rem ..............................................................
Rem Name: session.sql
Rem Purpose: 
Rem 1) List of session information based on sid or shawow process id
Rem 2) Get the SQLTEXT per sid
Rem
Rem ..............................................................
set pagesize 9999
column logon_time format a20
column machine format a15
select substr(to_char(spid),1,6) "pid",substr(to_char(sid),1,5) "sid",
substr(to_char(s.serial#),1,6)"ser",substr(s.username,1,13) "DB user",
substr(s.osuser,1,10) "O/S username",
s.status,sql_address,process,
substr(s.program,1,20) "program",
machine,p.pid "P-pid",to_char(logon_time,'DD-MON-YYYY HH24:MI') logon_time
from v$process p, v$session s
where p.addr=s.paddr
and (sid=to_number(nvl('&sid','0'))
or spid=nvl('&pid','0')
)
/
col sql_text format a80
col disk_reads format 999999999 head "DISK|READS"
col buffer_gets format 999999999 head "BUFFER|GETS"
col memory format 999999999
select disk_reads, buffer_gets, 
runtime_mem + persistent_mem  + sharable_mem memory, b.sql_text
from v$open_cursor a, v$sqlarea b
where a.address = b.address
and a.hash_value = b.hash_value
and sid = &sid
order by disk_reads desc
/
