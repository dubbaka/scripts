Rem ..............................................................
Rem Name: actlock.sql
Rem Purpose: account lock
Rem
Rem ..............................................................
set pagesize 9999
undefine actname
define userlock=&&actname
alter user &userlock account lock;
select * from dba_users
where username=upper('&userlock');
