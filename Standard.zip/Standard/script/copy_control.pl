#!/oracle/product/perl

#InstallPath:/usr/tools/oracle
#ServerType:client,media

# Development log

# -> Feature Set
# - brought under RCS control
# - Added InstallPath and ServerType tags
# - Added -v (version) switch and version tracking
# -> Bug fix

# $Log: copy_control.pl,v $
# Revision 1.2  2006/03/14 15:05:57  oracle
# Updated perl path to standard
#
# Revision 1.1  2006/03/14 15:03:35  oracle
# Initial revision
#
# Revision 1.1  2002/08/06 12:38:48  fbicknel
# -> Feature Set
# - brought under RCS control
# - Added InstallPath and ServerType tags
# - Added -v (version) switch and version tracking
# - to use Standard Package

require "ctime.pl";
use Getopt::Std;
use Time::Local;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


my $version_tag = ""; # This will be added at the end of the version (use for development work)
my $version = do { my @r = (q$Revision: 1.2 $ =~ /\d+/g); sprintf "%d".".%d" x $#r."%s", @r, $version_tag };

getopts('b:f:h:s:m:p:t:v');

die "$version\n" if $opt_v;
print "This is version $version\n";


    chomp($hostname = `/bin/uname -n`);
    if (-f "/usr/xpg4/bin/id" )
    {
        chomp($id=`/usr/xpg4/bin/id -un`);
    }
    elsif (-f "/usr/bin/id" )
    {
        chomp($id=`/usr/bin/id -un`);
    }
    else
    {
        `epage dba-duty "copy_control.pl on $hostname: id not found."`;
        exit(1);
    }

    print "ID is $id\n";

    $sid = $opt_s if defined($opt_s) || &usage("-s SID is missing");
    $backup_type = $opt_t if defined($opt_t) || &usage("-t backup_type is missing");
    $backup_host = $opt_b if defined($opt_b) || &usage("-b backup_host is missing");

    $mailto = $opt_m;
    $pageto = $opt_p;

    chomp($host = `/bin/uname -n`);
    &get_pageexe();
    $oracle_sid = $sid;
    $status = 0;

    if ($id eq "root")
    {
        print "Creating directory on the backup server\n";
        $cmd = "/usr/local/bin/ssh $backup_host mkdir /usr/tools/oracle/$oracle_sid";
        print "$cmd\n";
        $string = `$cmd`;
        print "$string\n";
        $cmd = "/usr/local/bin/ssh $backup_host chown oracle:dba /usr/tools/oracle/$oracle_sid";
        print "$cmd\n";
        $string = `$cmd`;
        print "$string\n";
        if ($backup_type eq "ONLINE")
        {
            &copy_cntrl_file();
        }
        elsif ($backup_type eq "OFFLINE")
        {
            $rc=system("su oracle -c \"/usr/tools/oracle/copy_control.pl -s $oracle_sid -t $backup_type -b $backup_host\"");
            if ($rc ne "0")
            {  
        	$rc >>=8 ;
        	print "Returning exit code [$rc] $!\n";
        	exit($rc);
            } 
            print "Copying control file names to $backup_host\n";
            $cmd = "/usr/local/bin/scp /tmp/cntrl_files_$oracle_sid.ora $backup_host:/usr/tools/oracle/$oracle_sid/cntrl_files_$oracle_sid.ora";
            print "$cmd\n";
            $string = `$cmd`;
            print "$string\n";
            $cmd = "/usr/local/bin/ssh $backup_host chown oracle:dba /usr/tools/oracle/$oracle_sid/cntrl_files_$oracle_sid.ora";
            print "$cmd\n";
            $string = `$cmd`;
            print "$string\n";
        }
        else
        {
            die "$backup_type - Invalid Backup type";
        }
    }
    elsif ($id eq "oracle")
    {
        &get_cntrl_file_names();
    }
    else 
    {
        die "copy_control.pl on $hostname: Invalid id $id. Aborting!!!";
    }
    exit(0);


sub copy_cntrl_file
{

    print "Copying backup controlfile to $backup_host.\n";
    $cmd = "/usr/local/bin/scp /oracle/admin/$oracle_sid/bdump/control_backup.ctl $backup_host:/usr/tools/oracle/$oracle_sid/";
    print "$cmd\n";
    $string = `$cmd`;
    print "$string\n";
    $cmd = "/usr/local/bin/ssh $backup_host chown oracle:dba /usr/tools/oracle/$oracle_sid/control_backup.ctl";
    print "$cmd\n";
    $string = `$cmd`;
    print "$string\n";
}

sub get_cntrl_file_names
{
    &ora_home($oracle_sid);
    $dbh = DBI->connect("", "internal", " ", "dbi:Oracle:") ||
        die("Cannot login to $oracle_sid. $DBI::errstr");
    $stmt = "select name from v\$controlfile";
    $sth = $dbh->prepare($stmt) ||
        die("Error while preparing $stmt. $DBI::errstr");
    $rc = $sth->execute() || 
        die("Error while executing $stmt");

    $aref = $sth->fetchall_arrayref;
    $sth->finish();
    open(CNTRL_FILES, "> /tmp/cntrl_files_$oracle_sid.ora") ||
        die("Cannot open /tmp/cntrl_files_$oracle_sid.ora for writing. $!");
       
    foreach(@$aref)
    {
        ($cntrl_file, @dummy) = (@$_);
        print CNTRL_FILES "$cntrl_file\n";
    }
    close(CNTRL_FILES);
    $dbh->disconnect;
    return(0);
}

sub get_pageexe
{
    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");
    $pageexe = "/usr/tools/oracle/itopage.pl" if (-f "/usr/tools/oracle/itopage.pl");

    if (!defined($pageexe))
    {
        print("check_extents.pl on $host: epage/pageme executable not found. Aborting...");
        die ;
    }
}

sub usage
{
    print "$_[0]";
    print "Usage:\ncopy_control.pl -s <SID> -t [OFFLINE|ONLINE] -b backup_host\n";
    exit (1);
}

sub ora_home
{
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_HOME'} = $oracle_home;
            $ENV{'ORACLE_SID'} = $oracle_sid;
        $ENV{'LD_LIBRARY_PATH'} = "$ora_home/lib";
        $ENV{'SHLIB_PATH'} = "$ora_home/lib";
        $ENV{'TNS_ADMIN'} = "$ora_home/network/admin";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;
        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }
        &StdDBPackage::which_lib();


        }
    }
    close(ORATAB);
}


