#!/bin/sh
# .....................................................................
#       Filename: flush_perfstat.sh
#       History:
#              swei     13-jul-2000     created
#	       swei     31-may-2001	modified to disable/enable 3 times
#	       swei     06-jan-2004     to use the sptrunc as standard
#	       swei     22-mar-2004     change subject to have alert/info/warn
# .....................................................................
#       Usage
# .....................................................................
if [ $# -lt 3 ];then
   echo "Usage: flush_perfstat.sh <SID> <exp Y/N> <maillist> "
   echo "flush_perfstat.sh CMRS Y cco-dba@cisco.com"
   exit 1
fi

# .....................................................................
#       Local Variable
# .....................................................................
SID="$1"
EXPFLAG="$2"
MAILLIST="$3"
LOGFILE=/tmp/sptrunc_`date "+%m%d%Y"`.log
EXPLOGFILE=/ora_dump/export/${SID}_exp/perfstat_exp_`date "+%m%d%Y"`.log
EXPFILE=/ora_dump/export/${SID}_exp/perfstat_exp_`date "+%m%d%Y"`.dmp.gz
SUBJECT="INFO: `uname -n` $SID Export on perfstat on `date`"
PATH=$PATH:/usr/local/bin
ORACLE_SID=$SID
ORAENV_ASK=NO
export PATH ORAENV_ASK
. /usr/local/bin/oraenv
export ORACLE_SID ORACLE_HOME
# .....................................................................
#       Set up pipe for export
#
#  for import: gunzip < file.gz > pipe &
# .....................................................................
#       Main Program
# .....................................................................
if [ "$EXPFLAG" = "Y" -o "$EXPFLAG" = "y" ]
then
mknod /tmp/exp_pipe p
/usr/local/bin/gzip < /tmp/exp_pipe > $EXPFILE &
$ORACLE_HOME/bin/exp \
userid=/ \
owner=perfstat \
file=/tmp/exp_pipe \
compress=N \
buffer=131072 \
STATISTICS=NONE \
log=$EXPLOGFILE
fi

$ORACLE_HOME/bin/sqlplus / > $LOGFILE <<EOF
alter session set current_schema=PERFSTAT;
@$ORACLE_HOME/rdbms/admin/sptrunc

exit
EOF
# .....................................................................
#       Mail and CleanUp
# .....................................................................
ERRCNT=`ps -aef|grep -i ora- $LOGFILE|wc -l`
if [ $ERRCNT -gt 0 ]
then
     #/usr/bin/mailx -s "Error: Perfstat Clean $SID at `date`" $MAILLIST < $LOGFILE
     /usr/bin/mailx -s "ALERT: `uname -n` $SID Perfstat Clean at `date`" $MAILLIST < $LOGFILE
     exit
fi

if [ "$EXPFLAG" = "Y" -o "$EXPFLAG" = "y" ]
then
/usr/bin/mailx -s "$SUBJECT" $MAILLIST < $EXPLOGFILE
rm /tmp/exp_pipe
fi
