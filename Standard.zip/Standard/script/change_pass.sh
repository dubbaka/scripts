#!/bin/sh
set -x
DB=$1
NEW_PASS=$2
PATH=$PATH:/usr/local/bin;export PATH
ORACLE_SID=${DB}; export ORACLE_SID
ORAENV_ASK=NO;export ORACLE_ASK

if [ -f /oracle/product/current/bin/oraenv ]
then 
        ORAENV=/oracle/product/current/bin/oraenv
elif [ -f /usr/local/bin/oraenv ]
then
        ORAENV=/usr/local/bin/oraenv
elif [ -f /oracle/product/8.1.7.4/bin/oraenv ]
then
        ORAENV=/oracle/product/8.1.7.4/bin/oraenv
elif [ -f /oracle/product/9.2.0.4/bin/oraenv ]
then
        ORAENV=/oracle/product/9.2.0.4/bin/oraenv
else
	ORAENV=/oracle/product/9.2.0.5/bin/oraenv
fi
export ORAENV
. $ORAENV

SHLIB_PATH=$ORACLE_HOME/lib; export SHLIB_PATH 
LD_LIBRARY_PATH=$ORACLE_HOME/lib export LD_LIBRARY_PATH

sqlplus "/ as sysdba" << EOF
alter user sys identified by $NEW_PASS;
alter user system identified by $NEW_PASS;
exit
EOF
