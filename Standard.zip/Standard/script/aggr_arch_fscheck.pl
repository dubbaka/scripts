#!/usr/local/bin/perl
# 
# Changelog
#
# Original Author: Rajesh Subramanain - 03/01/2005
#
# Script checks aggregate filesystem usage of /arch_ctsprd_* filesystems and alerts through VPO

use Getopt::Std;

getopt('s');
if ( defined($opt_s) )
 {
  $sid = $opt_s;                                                                                                                            
  $upper_sid = uc $sid;
  $lower_sid = lc $sid;
  }                                                                                                                                           
else                                                                                                                                         
  {                                                                                                                                           
  print "Usage:aggr_arch_fscheck.pl -s SID \n";                                                                                              
  exit;
  }

my $upper_sid = $upper_sid;
my $lower_sid = $lower_sid;

package VPO::Common;

	$os{"df"} = "/usr/bin/bdf";
	$os{"mount"} = "/sbin/mount -p";
	$os{"OPCPATH"} = "/opt/OV/bin/OpC";
	$os{"mount_index"} = 1;
	$os{"type_index"} = 2;
	$os{"fstab"} = "/etc/fstab";
	$os{"fstab_mount_index"} = 2;
	my $warning_threshold = 50;
	my $critical_threshold = 70;

# main stuff

# KNOWN GLOBAL VARIABLES

$OPCPATH = $os{OPCPATH};

&read_fstab($os{fstab},$os{fstab_mount_index});

#&checkfs(); 
#&check_mounts();

sub read_fstab($fstab,$index) {
	my ($fstab,$index) = @_;
	my $sum_avail_p = 0;
	my $counter = 0;
	open (FSTAB,"<$fstab") || warn "can't open $fstab";
	while (<FSTAB>) {
		next if ( /^#/ );
		next if ( ! /[a-z]/);
		if ((/arch/) && (/$lower_sid/)) {
			chomp;
			@entries=split(/ /);
			@df_out=`bdf $entries[$index-1]`;
			if (scalar(@df_out) > 2) {      #joins two lines together for long names/diskpaces
				chomp($df_out[1]);
				$df_out[1] = $df_out[1] .  $df_out[2];
				$#df_out  = 1;          #get rid of the third line
						}
	                ($device,$avail_k, $avail_p) =  (split(/\s+/, $df_out[1]))[5,3,4];
			$avail_p =~ s/%$//; #strip out percentage sign.
			$sum_avail_p = $sum_avail_p + $avail_p;		
			$counter = $counter + 1 ;		
		}
	}
	close (FSTAB);
	$aggr_arch_usage = $sum_avail_p/$counter ;
	if ( $critical_threshold <= $aggr_arch_usage ) {
		       $message_text="CRITICAL : Sum of arch filesystems usage for $upper_sid at $aggr_arch_usage\n";
		       print $message_text;
		       if ( -x "$OPCPATH/opcmsg" ) {
		       system(qq($OPCPATH/opcmsg s=critical a=aggr_arch_fscheck o=arch_usage msg_grp=oracle msg_text="$message_text"));
		       } else {
		       print "No opcmsg found: would have sent:\n" ;
		       print "$OPCPATH/opcmsg s=critical a=aggr_arch_fscheck o=arch_usage msg_grp=oracle msg_text=\"$message_text\"\n";
		       }
		exit;
		}
	if ( $warning_threshold <= $aggr_arch_usage ) {
		       $message_text="WARNING : Sum of arch filesystems usage for $upper_sid at $aggr_arch_usage\n";
		       print $message_text;
   		     	if ( -x "$OPCPATH/opcmsg" ) {
		     	system(qq($OPCPATH/opcmsg s=warning a=aggr_arch_fscheck o=arch_usage msg_grp=oracle msg_text="$message_text"));       
			} else {
		       	print "No opcmsg found: would have sent:\n" ;
			print "$OPCPATH/opcmsg s=$alert_level a=fscheck o=fs_usage msg_grp=oracle msg_text=\"$message_text\"\n";
			}                         
			exit;
 			}

}

exit 0;
