#!/usr/local/bin/perl

#
# Name    : sad (Switch Archive Destination)
# Version : 1.2
# Date    : 08/15/2000
# Modified: 05/17/2001
#

require "ctime.pl";
use lib '/oracle/product/perlmods/clnt964/lib';
require "/usr/tools/oracle/Standard/script/perllib.pl";
use DBI;
use Getopt::Std;
use Time::Local;

$maillist = "coe-dba\@cisco.com";
$pagelist = "coe-dba";
$pname = "sad";
getopt('smp');
$sid = $opt_s if defined($opt_s) || &usage("");
$logfile = "/var/tmp/${pname}_$sid.log";
$mailto = $opt_m ? $opt_m: $maillist;
$pageto = $opt_p ? $opt_p: $pagelist;

    chomp($host = `/bin/uname -n`);
    &get_pageexe();
    &set_cmds();
    open(LOGFILE, ">${logfile}") || die "Cannot open logfile $logfile. $!\n";

    print "Start time ", &ctime(time), "\n";
    print LOGFILE "Start time ", &ctime(time), "\n";

    $oracle_sid = $sid;
    $database = $sid;
    $ENV{'ORACLE_SID'}=$oracle_sid;
    &ora_home($oracle_sid);

    if ($oracle_home eq "")
    {
        &show_err("${pname} on $host: Cannot find Oracle Home for $sid. Aborting");
        die;
    }
    
    #&get_threshold();
    #print "Warning                     - $warn\n";
    #print "Critical                    - $crit\n";
    #print LOGFILE "Warning                     - $warn\n";
    #print LOGFILE "Critical                    - $crit\n";
    
    #$warn = 30;
    #$crit = 40;
    &get_current_arch_dest();
    print "Current Archive Destination - $log_archive_dest\n";
    print LOGFILE "Current Archive Destination - $log_archive_dest\n";

    if (!&pct_full($archive_file_sys))
    {
        print "ARCHIVE DESTINATION IS NOT CHANGED.\n\n";
        print LOGFILE "ARCHIVE DESTINATION IS NOT CHANGED.\n\n";
        print "End time ", &ctime(time), "\n";
        print LOGFILE "End time ", &ctime(time), "\n";
        close(LOGFILE);
        #&mailit_1("$pname on $host: Archive Destination is not changed", $logfile);
        exit(0);
    }

    $dbh = DBI->connect("dbi:Oracle:", "", "",{ ora_session_mode => ORA_SYSDBA}) || 
        &show_err("$pname on $host: Connect to $sid failed. $DBI::errstr");

    &get_archive_fs();
    &next_arch_dest();


#------------------------------------------------------
# switch archive dest.
#------------------------------------------------------

#    $stmt = "alter system archive log start to '".$new_archive_dest."'";
    $stmt = "alter system set log_archive_dest_1='location=".$new_archive_dest."'";
    print "$stmt\n";
    print LOGFILE "$stmt\n";

    if (!defined($dbh))
    {
	print "connect failed.\n";
    }
    $dbh->do($stmt) || 
        &show_err("$pname on $host: $stmt - Do failed. $DBI::errstr");

#--------------------------------------------------------------------------
# Switch Archiving Destination init /oracle/admin/GESPROD/pfile/initGESPROD.ora
#---------------------------------------------------------------------------

    $init_ora = "/oracle/admin/${database}/pfile/init${database}.ora";
    open(ORA, "$init_ora") || 
        &show_err("$pname on $host: Cannot open $init_ora. $!");
    rename($init_ora, $init_ora . '.bak');
    open(INIT_ORA_OUT, ">$init_ora");
    while (<ORA>) {
        s/log_archive_dest_1.*/log_archive_dest_1 ='location=$new_archive_dest'/;
        print INIT_ORA_OUT $_;  # this prints to original filename
    }
    close(INIT_ORA_OUT);
    close(ORA);
    $rc = $dbh->disconnect;

    $date = &ctime(time);
    print "\nEnd time ", &ctime(time), "\n";
    print LOGFILE "\nEnd time ", &ctime(time), "\n";
    close(LOGFILE);
    &mailit_1("Switched archive log destination to $new_archive_dest for $oracle_sid", $logfile);
    exit (0);


#----------------------------------------------------------------
# gets a list of archive filesystems
#----------------------------------------------------------------
sub get_archive_fs
{

    open(MOUNT, "/etc/mount|") || die $!;
    @mounted_fs = <MOUNT>;
    close(MOUNT);

    $archive_file_sys_count = 0;
    (@arch_fs = grep (/^\/arch_coeprd_?/,@mounted_fs));
    $archive_file_sys_count = @arch_fs;
    #print "Archive Filesystems :\n@arch_fs\nCount - $archive_file_sys_count\n";
    #print LOGFILE "Archive Filesystems :\n@arch_fs\nCount - $archive_file_sys_count\n";
    $arch_space = `$DF | grep arch`;
    #print "Archive Filesystems :\n$arch_space\nCount - $archive_file_sys_count\n";
    #print LOGFILE "Archive Filesystems :\n$arch_space\nCount - $archive_file_sys_count\n";
}

#----------------------------------------------------
# determine the next archive file system
#----------------------------------------------------
sub next_arch_dest
{

    $archive_file_sys =~ /(\/arch_coeprd_)([1-4]+)/;
    $next_dir_no = $2;

    #
    # If the next arch dest directory is inaccessible or removed, we
    # will try to switch to the next next directory after this one. In this
    # way we ensure that the script will not die if it finds a wrong/non existing
    # directory
    #
    for ($i=1; $i<$archive_file_sys_count; $i++)
    {
      print "inside for loop iteration :$i:\n";
      if ($next_dir_no == $archive_file_sys_count)
      {
        $next_dir_no = 0;
        $new_archive_dest = $1.($next_dir_no + 1).$tail_string_total;
        $new_archive_base_dir = $1.($next_dir_no + 1).$tail_string_dir;
        $next_dir_no++;

        if (-d $new_archive_base_dir) {last;}
      }
      else
      {
        $new_archive_dest = $1.($next_dir_no+1).$tail_string_total;
        $new_archive_base_dir = $1.($next_dir_no + 1).$tail_string_dir;
        $next_dir_no++ ;
        if (-d $new_archive_base_dir) {last};
      }
      print "tried for next_directory no :$next_dir_no\n";
      print "tried for next archive base directory :$new_archive_base_dir\n";
      print "tried for next archive location value : $new_archive_dest\n";
    }# End of for loop
    
    print "stopping at archive_location : $new_archive_dest\n";
    if (! -d $new_archive_base_dir) {die "Cannot switch to any of the next archive dirs\n";}
    print "New Archive Destination - $new_archive_dest\n";
    print LOGFILE "New Archive Destination - $new_archive_dest\n";
}


sub ora_home
{
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_HOME'} = $oracle_home;
        }
    }
    close(ORATAB);
}

sub pct_full()
{
my ($archive_fs) = @_;

    $diskfree = `$DF $archive_fs | tail -1`;
    $_ = $diskfree;
    /.* (\d+)\% (.*)\n/;
    $pct_full = $1;
    $arch_fs = $2;
    $threshold_file = "/.THRESHOLD";
    &get_threshold($threshold_file, $arch_fs);
    print "Threshold File - $threshold_file\n";
    print "Full                        - ${pct_full}%\n";
    print LOGFILE "Full                        - ${pct_full}%\n";
    if ($pct_full < $fs_warn+2)
    {
	return(0);
    }
    else
    {
        return(1);
    }
}

sub get_threshold()
{
my ($threshold_file, $arch_fs) = @_;


    open(THRESHOLD, "$threshold_file") ||
        &show_err("${pname} on $host: Cannot open $threshold_file file. $!");

    @lines = <THRESHOLD>;
    @arr = (grep /fs:$arch_fs:/, @lines);
    $fs_warn = (split(':', $arr[0]))[3];
    if (!defined($fs_warn))
    {
        print "Warn is not defined for $arch_fs\n";
        print LOGFILE "Warn is not defined for $arch_fs\n";
        @arr = (grep /fs:default:/, @lines);
        $def_warn = (split(':', $arr[0]))[3];
        print "Default value is defined. It is - $def_warn\n";
        print LOGFILE "Default value is defined. It is - $def_warn\n";
	$fs_warn = $def_warn;
    }
    else
    {
	print "Warn is defined. It is - $fs_warn\n";
	print LOGFILE "Warn is defined. It is - $fs_warn\n";
    }
    close(THRESHOLD);

    if (!defined($fs_warn))
    {
        print "WARN is not defined in $threshold_file file. Assigining default value 85";
        print LOGFILE "WARN is not defined in $threshold_file file. Assigining default value 85";
        $fs_warn = 85;
    }
}

sub get_pageexe
{
    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    if (!defined($pageexe))
    {
        print("${pname} on $host: epage/pageme executable not found. Aborting..."
);
        exit (1);
    }
}

sub get_current_arch_dest()
{

    open(SQLDBA, "$oracle_home/bin/sqlplus \"/ as sysdba \"  << END
archive log list
exit
END |") || &show_err("${pname} on $host: cannot find sqlplus: $!");

    @data = <SQLDBA>;
    (@arch_dest = grep(/^Archive destination/, @data)) || 
        die("${pname} on $host: Cannot find Archive destination in the array @data");
        #&show_err("${pname} on $host: Cannot find Archive destination in the array @data");
    $log_archive_dest = (split(' ', @arch_dest[0]))[2];
    
#-----------------------------------------------------------------------------
# gets file system from the archive destination
#-----------------------------------------------------------------------------

   # $log_archive_dest =~ /(\/\w+)\/(.*)/;
    $log_archive_dest =~ /(\/\w+)\/(\w+)\/(.*)/; 
    $archive_file_sys = $1;
    $tail_string_dir = "/$2";
    $tail_string = "/$3";
    $tail_string_total=$tail_string_dir.$tail_string;

    print "tail string directory is $tail_string_dir\n";
    print "tail string is $tail_string\n";
    print "tail string total is $tail_string_total\n";

}

sub mailit_1()
{
    if (-f $_[1]) {
        #open (MAIL, "|/usr/bin/mailx -s \"$_[0]\"  $mailto < $_[1]");
        #close (MAIL);
        $errmsg = &msgfmt("i",,,"$_[0]");
        &mailit("$errmsg",$_[1]);
        print "";
    }
}

sub pageit1
{
my @pagemsg = @_;

    while ($pagemsg = pop(@pagemsg))
    {
        `$pageexe \"$pageto\" \'$pagemsg\'`;
    }
}


sub show_err()
{

    if (LOGFILE)
    {
        close(LOGFILE);
        &mailit_1("$_[0]", $logfile);
    }
    &pageit1("$_[0]");
}

sub set_cmds()
{
    $os = `/usr/bin/uname`;
    if ($os =~ /HP-UX/)
    {
	$DF = "/usr/bin/bdf";
    }
    elsif ($os =~ /SunOS/)
    {
	$DF = "/usr/bin/df -k";
    }

}
