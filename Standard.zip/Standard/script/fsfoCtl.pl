#!/oracle/product/perl
#
#
# Description
#   Script to enable or disable Fast-Start Failover
# Modification History:
# 06/07/2010: rmalikia: Created
# 06/30/2010: rmalikia: Added functionality to not enable FSFO if a file present in
#	                /usr/tools/oracle/Standard/script/flags/".$ORACLE_SID."_DONOT_ENABLE_FSFO"
#                       during startup only
sub print_usage() {
        print "\n\n\tusage: $0 ORACLE_SID ACTION\n";
        print "\tusage: $0 CA2STG stop|start\n\n";
        exit(1);
}
if ($#ARGV != 1 ) {
        &print_usage;
}

$ORACLE_SID="$ARGV[0]";
&getorahome("$ORACLE_SID");
$ORACLE_HOME=$oracle_home;
$ACTION="$ARGV[1]";

$ORACLE_HOME=~ s/\s+$//; #remove trailing spaces
$ORACLE_SID=~ s/\s+$//;
$ACTION=~ s/\s+$//; 

$ENV{"ORACLE_HOME"} = "$ORACLE_HOME";
$ENV{"ORACLE_SID"} = "$ORACLE_SID";

$remote_cmd_dis_fsfo = "";
$remote_cmd = "";

if (! open DBEXC, "$oratab") {
      die "/etc/oratab does not exist.  unable to determine ORACLE_HOME $!";
}

#Need to check and make sure data entered are valid!!!
if (-f "$ORACLE_HOME/bin/dgmgrl") {
        $dgmgrl = "$ORACLE_HOME/bin/dgmgrl";
};

if (-f "$ORACLE_HOME/bin/sqlplus") {
        $sqlplus = "$ORACLE_HOME/bin/sqlplus";
};

if ( $ORACLE_SID eq ""  ||  $ACTION eq "" ) {
        print "\n\n\tMust give a none null values \n\n";
        exit(1);
};
$logfile   = "/tmp/enable_disable_fsfo_$ORACLE_SID.log";
open(LOGFILE, ">$logfile") || die "enable_disable_fsfo: cannot open $logfile for writing. $!";

#the file that will have the host name for startup
#/usr/tools/oracle/Standard/script/DBexceptions.par

#######################################
#This needs to be further down as here not true if starting the database
##########################################
#Get the host name for start or stop FSFO
$mysql = "select fs_failover_observer_host ||':'|| name ||':'|| dataguard_broker from v\\\$database;";
$sqlres=`$ORACLE_HOME/bin/sqlplus -silent /nolog << EOF
                connect / as sysdba
                set head off
                set pagesize 0
                $mysql
                exit;
        EOF`;

($observerhost,$dbname,$dgbroker) = split(/:/,$sqlres); 

if ($dgbroker eq  "DISABLED") {
	print "This database has not Data Guard setup.\n";
	print LOGFILE "This database has not Data Guard setup.\n";
	exit(0);
} else {
	#Get the hostname from file
	$exceptiondb = "/usr/tools/oracle/Standard/script/exceptionDB.par";

	if (! open EXCEPTIONDB, "$exceptiondb") {
      		die "/usr/tools/oracle/Standard/script/exceptionDB.par does not exist.  unable to determine database name or observer host name";
		print LOGFILE "/usr/tools/oracle/Standard/script/exceptionDB.par does not exist.  unable to determine database name or observer host name";
	}

	my @expdb= <EXCEPTIONDB>;
	#OBSERVER:DBNAME:OBSERVER_HOST_NAME
 	foreach(@expdb) {
   		if ($_=~ /^OBSERVER:(.*):(.*)/) {
			if ($1 eq $dbname){
        			#$dbname = $1;
        			$hostname = $2;

			}
    		}
 	}

	if ( $hostname eq "" ) {
        	print "There is nothing to done as observer is not configured.\n";
        	print LOGFILE "There is nothing to done as observer is not configured.\n";
        	exit(0);
	}

	if ( lc($ACTION) eq "stop" ) {
        	#Stop FSFO
		print LOGFILE "Stoping FSFO\n";
        	$lc = `$dgmgrl   << EOF 
				connect /
				DISABLE FAST_START FAILOVER;
				exit; 
				EOF `;
        	print "Stop $lc \n";
        	print LOGFILE "Stop $lc \n";
		#To make sure it will connect to remote machine 
		# and start the observer on that host and not on the primary database
                $ENV{"ORACLE_HOME"} = "";
                $ENV{"ORACLE_SID"} = "";
		$startfile = $dbname."_stop_observer";
        	$rc = `ssh $hostname -l oracle "cd $dbname;./$startfile "`;
		print "Stop $_\n";
		print LOGFILE "Stop $_\n";
		print "Stop $rc\n";
		print LOGFILE "Stop $rc\n";
		print LOGFILE "\n\n\n";
                # sleep as it take a bit of time for FSFO to show stopped in log file
                sleep 30;
		print "The following lines are from observer host. \n";
		print "########################################### \n";
		print LOGFILE "The following lines are from observer host. \n";
		print LOGFILE "########################################### \n";
                $chkstatlogfile =  "/tmp/observer_".$dbname.".log";
        	$chklog = `ssh $hostname -l oracle "cat $chkstatlogfile "`;
		print LOGFILE "$chklog\n";
		print "$chklog\n";
		print LOGFILE "########################################### \n";
	} else {
        	#Start FSFO
		$chk_file = "/usr/tools/oracle/Standard/script/flags/".$ORACLE_SID."_DONOT_ENABLE_FSFO";
		if ( -f $chk_file ) {
			print "Not Starting FSFO\n";
			print LOGFILE "Not Starting FSFO\n";
		} else {
			print LOGFILE "Starting FSFO\n";
        		$lc = `$dgmgrl   << EOF 
				connect /
				ENABLE FAST_START FAILOVER;
				exit; 
				EOF `;
			print "Start $_\n";
			print LOGFILE "Start $_\n";
        		print "Start $lc \n";
        		print LOGFILE "Start $lc \n";

			#To make sure it will connect to remote machine 
			# and start the observer on that host and not on the primary database
                	$ENV{"ORACLE_HOME"} = "";
                	$ENV{"ORACLE_SID"} = "";
			$startfile = $dbname."_start_observer";
        		$rc = `ssh $hostname -l oracle "cd $dbname;./$startfile "`;
			print "Start $_\n";
			print LOGFILE "Start $_\n";
			print "Start $rc\n";
			print LOGFILE "Start $rc\n";
			print LOGFILE "\n\n\n";
                        sleep 20;
			print "The following lines are from observer host. \n";
			print "########################################### \n";
			print LOGFILE "The following lines are from observer host. \n";
			print LOGFILE "########################################### \n";
                        $chkstatlogfile =  "/tmp/observer_".$dbname.".log";
        	        $chklog = `ssh $hostname -l oracle "cat $chkstatlogfile "`;
		        print LOGFILE "$chklog\n";
		        print "$chklog\n";
			print LOGFILE "########################################### \n";
		}	
	}
	close(LOGFILE);
	exit(0);
} #End IF from not a enabled for dataguard

sub getorahome {

$oratab="/etc/oratab" ;
if ( ! -f "/etc/oratab" and -f "/var/opt/oracle/oratab" ) {
   $oratab="/var/opt/oracle/oratab";
   print "\nWARNING!! no /etc/oratab exists ! ";
}

if (! open ORATAB, "$oratab") {
      die "/etc/oratab does not exist.  unable to determine ORACLE_HOME";
}

my @myoratab= <ORATAB>;

 foreach(@myoratab) {
   if ($_=~ /^$ORACLE_SID:(.*):(.*)/) {
       $oracle_home = $1;
       $ENV{"ORACLE_HOME"} = $oracle_home;
    }
 }
} #End of getorahome sub
