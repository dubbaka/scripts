#!/oracle/product/perl
#!/usr/local/bin/perl
###################################################################################
$pname   = qq(archivelog_utl.pl);
$version = qq(3.0);

# Name    : archivelog_utl.pl
# Version : 1.0
# Date    : 07-25-2005
# Author  : raraveet
#
# Description :
#   ------------- on PROD and DR hosts ----------------------------------------------
#   * This utility purges the archive-dir directory of all  /archdir/SID*.dbf.gz
#       o Starts purging if %usage > pct_upper_limit 
#			 and until %usage < pct_lower_limit  
#	  		 and archivelog is applied on the standby 
#			 and archivelog exists on tape  
#			  (currently any log morethan 1d is considered to be on tape)
#   * Ability to zip/unzip in multiple streams & Option to ENABLE/DISABLE zipping 
#   * Other parameters can be specified through cron exception form from DBTS
#
#   ------------- on PROD host ------------------------------------------------------   
#   * If sad_parfile exists , then switch archive destination is auto enabled 
#	o if %used is > pct_upper_limit even after purge then looks for 
#	  possible switch archive log
#   * If DR exists then,
#	o oracle logswitch is auto enabled,
#	  if last archivelog generated is more than 20m,then logswitch happens.
#   * If DR exists then following alerts are auto enabled,
#               Alert1-> alerts if DR host ARCHIVELOG LAGS BEHIND production host
#                        by certain no. of minutes
#               Alert2-> alerts if DR APPLIED LOG LAGS BEHIND production log archive
#                        by certain no. of minutes
#		o touch flag like INSTANCE.nodrhost.2h in case of know dr host issues 
#                 at prodhost:/usr/tools/oracle/Standard/script/flag
#
#   ------------- on DR host --------------------------------------------------------   
#   * If host is DR, 
#	o zips archive logs applied on DR ,
#	o unzips window of logs and 
#	o purges applied archive logs
#           o touch flag like SID.nopage.24h at drhost:/usr/tools/oracle/recovery/norecover 
#             to disable email/paging dr alerts during know issues
#

$Synopsis = <<X;
 This is $pname,v$version built for you :-)

  Available features:
  -------------------
  :On PROD Host: 		:On DR Host:
  zipping			unzipping
  purging			zipping
  DR health cheks		purging
  Switch Oracle log
  Switch Archive Destination
  Find duplicate archive logs


  Syntax  : archivelog_utl -i<INSTANCE|ALL>
  ------------------------------------
  Example1: archivelog_utl -iCAPPROD
  Example2: archivelog_utl -iALL [ scans oratab ]

  Other Options:
  --------------
  Example: archivelog_utl -iCAPPROD -O ziponly|purgeonly|sadonly|nosad
           archivelog_utl -iCAPPROD -O drmonitoronly|nodrmonitor
           archivelog_utl -iCAPPROD -O force_sadonly
           archivelog_utl -iCAPPROD -P3 -S120m

  Defaults: [command line options]
  --------------------------------
  MAXPROCS       (opt -P) = 4   [multiple process for zip/unzip]
  TIMEOUT        (opt -S) = 30m [script timeout]
  TAPE_CHECK_TIME(opt -T) = 1d  [check if backup exists in tape 
				 (use this option with CAUTION) ]

  Defaults: [Modifiable thro' DBTS cron exception]
  ------------------------------------------------
  pct_upper_limit  = 85		(upper % threshold)
  pct_lower_limit  = 65		(lower % threshold)
  throttle_window  = 100	(No. of logs to be unzipped on DR)
  zip_option       = ENABLE	(option to enable/disable zipping)

  All about Flags:
  ----------------
  On DR Host: 	To disable DR alerts 
   	      	  /usr/tools/oracle/recovery/norecover/SID.nopage.2h
  On PROD host:	To disable DR host temporarily
		  /usr/tools/oracle/Standard/script/flags/INSTANCE.nodrhost.10h
		To disable/blackout DR host in case of DR rebuild
		  /usr/tools/oracle/Standard/script/flags/INSTANCE.nodrhost.blackout
                To check if script is Active(Running) or got stuck(used internally)
                  /usr/tools/oracle/standard/script/flags/INSTANCE.wip.30m


X
##############################################################################################
# MODIFICATION HISTORY:
# NAME		DATE		COMMENTS
# raraveet	07/25/2005	Initial Version (1.0)
# raraveet	12/20/2005	Bug fixes after testing
# raraveet      01/18/2006      Done with Final modifications to v1.0   
# raraveet	06/16/2006	Fixed bug related to fuser 
# raraveet	07/17/2006	Enhanced script to look at log_archive_format 
#				while deriving log_archive_dest .
# raraveet 	08/02/2006	fix issue related to high archive
#				generation to check %usage inbetween  
#				zipping process
# raraveet	08/04/2006	Introduce checkNopage to disable paging
#				related to dr logs during known issues/refreshes
# raraveet 	11/10/2006	Added fuseropt,sshopt,document,alarm,
#				      drhost,retry options, etc., ...
# raraveet      --/--/----	Version (2.0)
#				Fixed the dr last_arcive shipped using 'ls' instead of 'find'
#				Display version of the script when executed with no parameters
#				check thread file on prod and remove it appropiately to handle
#				scenarious during DG switch over.
# raraveet      03/01/2011      Version (3.0)
#				Replace all alert/warn keyword from messages to ARCHUTL
#				Issue when multiple entries with incompatible option found in cron
#				Check if log_archive_dest is the same as set in database, if not page
#				Perform switch oracle log for all databases
#					(in v2.0 its being done only for databases where DR/DG exists)
#				Fixes an issue during zipping the logs generated from someother node
#				(usually during coldbackups)
#				Default email to ats-dba-mon if no email from any other source
#				Page duty if the script gets stuck for more than 30m
#				Disable DR option when drhost is not available during DR rebuild
##############################################################################################

use POSIX						;
$SIG{PIPE} ='IGNORE'					; 
require "stat.pl"					;
use Getopt::Std						;
use FileHandle						;
use File::Basename					;
use Time::Local						;
require "/usr/tools/oracle/Standard/script/perllib.pl"	;
use lib "/usr/tools/oracle/Standard/lib/"		;
use StdDBPackage					;
use Lock						;

$| = 1; # don't buffer output , flush std out
$SIG{ALRM} = sub (){ alarm($TIMEOUT_EVERY);
                     &showError("$pname:running long ... ,please check ",$instanceI) };
############################ MAIN ############################################
&mainFnc();
############################ MAIN ############################################

#-----------------------------------------------------------------------------
# mainFnc :
#     This is the main function that calls all other modules
#-----------------------------------------------------------------------------
sub mainFnc()
{
	#------------ Read/process Input parameters -------------------------#
	&readInput();

	#------------ check if process already running ----------------------#
        eval{
	&Lock::lock("$lockfile");
        };

        if($@){
          if($@ =~ /Already running with pid/){
            chomp($@);
            print "\n got signal [$@]";
            &checkProcessProgress($instanceI);
          }
          else{
            print "\nDiffernet error\n";
          }
          exit 1;
        }

	#------------ Set oraenv,drthread,mountFilesystems ---{---------------#
	&setEnv() ;
	eval { alarm($TIMEOUT);

        #------------ Force Swicth Archive Destination ----------------------#
        &switchArchDestOnly($instance) if ( lc($opt_O) eq "sadonly" );
        &switchArchDest($instance) if ( lc($opt_O) eq "force_sadonly" );

        #------------ Zip and Purge process ---------------------------------#
	&zipArchive("compress")   if ( $option_O eq "Y" or lc($opt_O) eq "ziponly" );
	&purgeArchive()           if ( $option_O eq "Y" or lc($opt_O) eq "purgeonly" );
	&zipArchive("uncompress") if ( $isdrhost_f eq "YES" ) ;
        &findDupLogs() ;
	&checkDRhealth()          if ( $option_O eq "Y" or lc($opt_O) eq "drmonitoronly" );
        &exitProgram(0); };
}

#-----------------------------------------------------------------------------
# readInput :
#	o sets env paths
#	o sets defaults
#-----------------------------------------------------------------------------
sub readInput()
{
	&Usage if ( !getopts('h:d:u:l:a:w:z:i:P:L:O:T:Z:S:') || defined($opt_h) );
	$instance       	= $opt_i ? uc($opt_i) : uc($ARGV[0]) ;
	&Usage if ( !$instance ); 
	$instanceI		= $instance ;

        # as constants for most envs, but can be overwritten 
        # from command line arguments
        $MAXPROCS               = int($opt_P) ? $opt_P : 4;
	$MAXLOGCYCLE		= int($opt_L) ? $opt_L : 7;
	$TAPE_CHECK_TIME        = $opt_T      ? $opt_T :"1d";
	$ZIP_ARCHIVE_TIME       = $opt_Z      ? $opt_Z :"2m"; 
        #actually this can be ignore , now we have a diff logic to alert on scripts timeouts
        #setting to high value 90m
	$SCRIPT_TIMEOUT         = $opt_S      ? $opt_S :"90m";
        &Usage if ( defined($opt_O) and  !( lc($opt_O) eq "ziponly"  or lc($opt_O) eq "purgeonly" or
		         	         lc($opt_O) eq "sadonly"     or lc($opt_O) eq "nosad"     or
                                         lc($opt_O) eq "force_sadonly" or
					 lc($opt_O) eq "nodrmonitor" or lc($opt_O) eq "drmonitoronly" 
					) ) ;
        $option_O               = "Y" if ( ! defined($opt_O)     or 
					   lc($opt_O) eq "nosad" or 
				           lc($opt_O) eq "nodrmonitor" );
	# set default paths
	$pname          	= "archivelog_utl.pl";
	$exceptfile  		= "/usr/tools/oracle/Standard/script/exceptionDB.par";
	$sad_parfile		= $exceptfile ;
	$thread_path		= "/usr/tools/oracle/recovery/thread";
	$norecover_path         = "/usr/tools/oracle/recovery/norecover";
	$sync_arch_path		= "/usr/tools/oracle/sync_arch/adm";
	$tape_parfile  		= "/usr/tools/oracle/tapefiles" ; #currently not in use
        $FLAG_DIR		= "/usr/tools/oracle/Standard/script/flags";
        system("mkdir -p $FLAG_DIR");

	# these values should be modified thro' cron exception
	# if cron exception exists then command line input parameters are ignored
	$pct_upper_limit_d      = $opt_u ? $opt_u : 85;
	$pct_lower_limit_d      = $opt_l ? $opt_l : 65;
        $archive_retain_time_d  = $opt_a ? $opt_a : "1d" ;
	$throttle_window_d	= $opt_w ? $opt_w : 100 ;
	$zipmode_d		= $opt_z ? uc($opt_z) : "ENABLE";
        $sync_arch_mail_limit_d = "2h";
        $sync_arch_page_limit_d = "4h";
        $drlog_mail_limit_d     = "6h";
        $drlog_page_limit_d     = "10h";

	# derived or almost like constants variables
	$LOGSWITCH_TIME	    = "19m";
	$DEFAULT_THREAD     = 10000000000;
	$TIMEOUT            = &convertTime($SCRIPT_TIMEOUT);
	$TIMEOUT_EVERY	    = 3600 ; # this is in seconds (default 20m) 
	$instance_number    = 1;
	chomp($local_host   = `hostname`);
        $archformat         = "(.*)\\/(\\w*).arch[_]*(\\d)_(\\d*)[_]*(.*).dbf";
        $archformatG        = "(.*)\\/[GZIP\\.]*(\\w*).arch[_]*(\\d)_(\\d*)[_]*(.*).dbf";
	$archsuffix	    = ".gz"; #currently in use for DG envs., only
	$lockfile	    = "$pname.$instance";
	$lockfile	    = "$pname.$instance.".lc($opt_O) if ( defined($opt_O));
        $logfile            = "/var/tmp/${lockfile}.LOG";
	$statfile	    = "/var/tmp/${lockfile}.statfile";

	# sets os specific commands
	&setOSCommands();

	# log rotation 
	&logRotation();

}

#-----------------------------------------------------------------------------
# setEnv :
#     set env , defaults certain parameters
#     calls modules getDRInfo and prepareMountFS to get archive mount points
#-----------------------------------------------------------------------------
sub setEnv(){

        #set script progress flag
        system("rm $FLAG_DIR/$instanceI.wip* 2>/dev/null");
        system("touch $FLAG_DIR/$instanceI.wip.30m");

        open(LOGFILE, ">>${logfile}") || die "ARCHUTL:$pname:Cannot open logfile $logfile. $!\n";
        LOGFILE->autoflush(1);
        print "\n$pname: Started : ",&ctime(time);
        print LOGFILE "\n$pname: Started : ",&ctime(time);
	print "\nsetEnv:";
	print LOGFILE "\nsetEnv:";
	$isdrhost_f  = "NO"; # indicates whether the host is production or DR server

	if($instanceI eq "ALL"){
	   pop(@instanceA);
	   open (ALLTAB,"/var/opt/oracle/oratab") || &showError("$pname:Can't Open oratab $!");
   	   while (<ALLTAB>) {
    		next if (/^#/ || /^\s/ );
		next if (/OIDPRD/ or /LISTENER:/ or /CLIENT:/ or /CRS:/ or /CURRENT:/) ;
    		($instance,$ora_home,$db_flag) = split(/:/);
		push(@instanceA,$instance);
	   }
	   close(ALLTAB);
	}
	else{
	   @instanceA          = $instanceI; 
	   @instanceA          = split(',',$instanceI) if ( $instanceI =~ /,/);
	}

        my $flagonce=0;
	foreach(@instanceA){
	$instance=$_;
	$dbinfo_arr{$instance}{zip_cnt}   = 0;
	$dbinfo_arr{$instance}{unzip_cnt} = 0;
        $dbinfo_arr{$instance}{unzip_num} = 0;
	$dbinfo_arr{$instance}{purge_cnt} = 0;
	$drthread{$instance} 	          = 0;
	$drexists_f{$instance}	          = "NO";
	$dbinfo_arr{$instance}{isDataguard}= "NO";
	$dbinfo_arr{$instance}{isSetlog_archive_dest_1}= "NO";

	&setOraclehome($instance);
        #checking if this cron is scheduled in incompatible mode:) meaning we can't
        #have two entries one with -iALL and another one with -i<SID>
        if($instanceI eq "ALL"){
           my $cronCmd=qq(\\crontab -l|grep $pname|grep -v ALL|grep -v grep|grep -v "#"|wc -l);
           $cnt=qx($cronCmd); $cnt=int($cnt);
           if ($cnt != 0 and $flagonce == 0){
              $flagonce=1;
              print "\n Error!!found incompatible entries in cron with this script";
              print "\n        Do not setup two entries one with -iALL and another one with -i<SID>";
              print "\n        my recommendation to use this option -i<SID> in prod host if you have DR/DG";
              #very hard coding required here 
              $mailto=$pageto="db-monitor-duty";
              &showError("$pname:found incompatible entries in cron with this script",$instanceI,1);
           }
        }
        else{
	   my $cronCmd=qq(\\crontab -l|grep $pname|grep ALL|grep -v grep|grep -v "#"|wc -l);
           $cnt=qx($cronCmd); $cnt=int($cnt);
           if ($cnt != 0 and $flagonce == 0){
              $flagonce=1;
              print "\n Error!!found incompatible entries in cron with this script";
              print "\n        Do not setup two entries one with -iALL and another one with -i<SID>";
              print "\n        my recommendation to use this option -i<SID> in prod host if you have DR/DG";
              #very hard coding required here
              $mailto=$pageto="db-monitor-duty";
              &showError("$pname:found incompatible entries found in cron with this script",$instanceI,1);
           }
        }

        &prepareMountFS($instance);
        &getExceptionValues();
        &getDbParameters($instance);
        &getDRInfo($instance) ; 

        if( $dbinfo_arr{$instance}{connected} eq "Y" and $isdrhost_f eq "NO" ){
            &setOraclehome($instance)   ;

            #check if log_archive_dest set in database and in init.ora are same
            &checkArchDestInSync($instance);
       
            #perform log switch in case there is no archivelog in the past 20m
            &switchOracleLog($instance) ;
        }
    }
	print "\n";
	print LOGFILE "\n";
}

#-----------------------------------------------------------------------------
# checkProcessRunning :
#     Check if process is already running,
#     Uses 'ps' to find if there is same job is already running and also 
#     doing grep for 'perl' to distinguish same job being open by diff 
#     commands like 'vi'
#-----------------------------------------------------------------------------
sub checkProcessRunning()
{
	print "checkProcessRunning:";
        if ( -f "/tmp/$pname.${instance}.lock") {
                open (PID, "/tmp/$pname.${instance}.lock")
			|| &showError("$pname:Cannot open /tmp/$pname.${instance}.lock $!");
                $old_pid = <PID>;
		print "old pid=$old_pid ,new pid=$$ ,";
                close (PID);
                $pcnt=`$PS -ef |grep -v grep |grep perl |grep -w $old_pid |grep $pname|wc -l`;
		#print "$PS -ef |grep -v grep |grep perl |grep -w $old_pid |grep $pname|wc -l";
                chomp($pcnt);
                if ( $pcnt != 0 )
                {
                        print "The $pname process is already running under pid $old_pid\n";
                        exit
                }
        }
        open (NEW_PID, ">/tmp/$pname.${instance}.lock");
        print NEW_PID $$;
        close (NEW_PID);
}

#-----------------------------------------------------------------------------
# setOraclehome :
#    Sets  ORACLE_HOME based on /etc/oratab
#    sets envs like mailto ,pageto from standard package, job exists if database
#    is not found in /etc/oratab
#-----------------------------------------------------------------------------
sub setOraclehome()
{
    my $dbname = shift;
    $db_check="N";
    open(ORATAB, "/var/opt/oracle/oratab") || &showError("$pname:setOraclehome:Can't Open oratab $!");
    while (<ORATAB>) {
        if (/^${dbname}:/)
        {
            $db_check		   = "Y";
            $oracle_home 	   = (split(':'))[1];
            $ENV{'ORACLE_SID'}     = $dbname;
            $ENV{'ORACLE_HOME'}    = $oracle_home;
            $ENV{'LD_LIBRARY_PATH'}= "$oracle_home/lib";
            $ENV{'SHLIB_PATH'}     = "$oracle_home/lib";
            ($mailto_d,$pageto_d,$warn_d,$alert_d)=&StdDBPackage::get_default_value($dbname);
	    #$mailto_d=$pageto_d="raraveet"; # for TESTing
	    $dbinfo_arr{$dbname}{mailto} = $mailto_d;
	    $dbinfo_arr{$dbname}{pageto} = $pageto_d;
	    $dbinfo_arr{$dbname}{pageto} = "ats-dba-mon" 
					if ( ! defined($dbinfo_arr{$dbname}{pageto}) );
	}

    }
    close(ORATAB);

    if( $db_check eq "N"){   
	    print "$pname:!! Invalid database name\n";
	    print LOGFILE "$pname:!! Invalid database name\n";
	    exit;
    }
}

#-----------------------------------------------------------------------------
# setOSCommands :
#    Set os independant commands ,
#    - Using grep % on HP/Linux but not on Solaris as the command 'df' 
#      not working along with grep
#    - force gzip is required in case if prev run is killed for some
#      reason and have both dbf and dbf.gz files 
#-----------------------------------------------------------------------------
sub setOSCommands()
{
        $os=`uname`;
        chomp($os);
        if ( $os eq "HP-UX" ) {
		$dfopt  ="| grep %";
                $DF     ="/usr/bin/bdf";
                $PS     ="/usr/bin/ps";
                $MOUNT  ="/etc/mount";
                $MAILX  ="/usr/bin/mailx";
                $GZIP   ="/usr/local/bin/gzip -f";
                $SSH    ="/usr/local/bin/ssh";
		$sshopt ="-o BatchMode=yes -o NumberOfPasswordPrompts=1 -o KeepAlive=no " ;
		$FUSER  ="/usr/tools/oracle/fuser";
		$FUSER  ="/usr/sbin/fuser" if(! -x "$FUSER");
        }
        elsif ( $os eq "SunOS" ) {
                $DF     ="/usr/bin/df -k";
                $PS     ="/usr/bin/ps";
                $MOUNT  ="/etc/mount";
                $MAILX  ="/usr/bin/mailx";
                $GZIP   ="/usr/local/bin/gzip -f";
                $SSH    ="/usr/local/bin/ssh";
		$sshopt ="-o BatchMode=yes -o NumberOfPasswordPrompts=1 -o KeepAlive=no " ;
		$FUSER  ="/usr/sbin/fuser";
        }
        elsif ( $os eq "Linux" ) {
		$dfopt    ="| grep %";
                $DF       ="/usr/local/bin/df";
                $PS       ="/bin/ps";
                $MOUNT    ="/etc/mount";
                $MAILX    ="/bin/mailx";
                $GZIP     ="/usr/local/bin/gzip";
                $SSH      ="/usr/local/bin/ssh";
		$sshopt ="-o BatchMode=yes -o NumberOfPasswordPrompts=1 -o KeepAlive=no " ;
		$fuseropt = "-t ";
                $FUSER    ="/usr/local/bin/lsof";
        }
        # validation of os commands
	if(! -x "$FUSER"){
		print "\n  Error!!Unable to find $FUSER executable ";
		print "\n  Program terminated ";
		exit(1);
	}
}

#-----------------------------------------------------------------------------
# getCurrArchDest :
#  - Wrapper function that invokes appropiate functions 
#    based on whether DR exists or not
#  - thread_file is verified to determine DR host
#-----------------------------------------------------------------------------
sub getCurrArchDest()
{
	my $dbname      = shift;
        $thread_file    = "$thread_path/${dbname}_thread1.dat";
	if ( -f "$thread_file" ){
		&getCurrArchDestFromFile($dbname);
	}
	else {
		&getCurrArchDestFromDB($dbname);
	}
}
	
#-----------------------------------------------------------------------------
# getCurrArchDestFromDB :
#  -Determines current archive destination from database.
#   if database is in NOARCHIVE mode or cannot be connected then the 
#   function returns null log_archive_dest and the DB is IGNORED
#   for archive management.
#  -the format expected ( need atleast SID,arch,dbf in archivelog
#         Ex:  log_archive_dest      = /archive/CAPPROD_arch/CAPPROD.arch
#              log_archive_format    = %t_%s.dbf
#  -log_archive_dest_2 is used to determine if DG is implemented
#-----------------------------------------------------------------------------
sub getCurrArchDestFromDB()
{
    my $instance_l       = shift;
    my $log_archive_dest = "";
    my $log_archive_dir  = "";
    undef($dg_dbname);
    undef($db_unique_name);
	
    my $init_ora =qq($ENV{ORACLE_HOME}/dbs/init${instance_l}.ora);
    if ( -f "${init_ora}" ) {
	print "\n getCurrArchDestFromDB:$instance_l:";
	print LOGFILE "\n getCurrArchDestFromDB  : $instance_l:";
	my $sqlstmt="SELECT name,'string' string ,value
		     FROM   v\\\$parameter
		     WHERE  name IN ('instance_number','db_name','log_archive_format','log_archive_dest_1',
				     'log_archive_dest_2','standby_archive_dest','compatible')
                     UNION  select 'no_of_racnodes','string',to_char(count(*)) from gv\\\$instance";
	open(SQLDBA, "$oracle_home/bin/sqlplus /nolog << END
	connect /as sysdba
	archive log list
	col type for a10
        col name for a24
	col string for a6
        col value for a45
        --show parameter instance_number
        --show parameter db_name
        --show parameter log_archive_format
	--show parameter log_archive_dest_2
	--show parameter standby_archive_dest
	$sqlstmt ;
	exit
	END |") || &showError("$pname:getCurrArchDestFromDB:sqlplus error: $!",$instance_l,1);

	@data = <SQLDBA>;
	(@data1 = grep (/Database log mode/,@data)) ;
	$archive_mode=(split(' ', $data1[0]))[4];

        #$archive_mode=""; #TEST-simulate node is down 
	if ( $archive_mode eq "" ){
		print "ARCHUTL:$instance_l: Ignore/Unable to connect ";
		print LOGFILE "ARCHUTL:$instance_l: Ignore/Unable to connect ";
  		return(1); 
        }
        else{
	if ( $archive_mode =~ /No/ ) {
		print " is in No Archivemode";
		print LOGFILE " is in No Archivemode";
		return(1);
	}

        # find db_name
        (@data3  = grep(/^db_name/, @data)) || &showError("$pname:Can't Find db_name: @data",$instance_l,1);
        $db_name = (split(' ', $data3[0]))[2];

        (@data4  = grep(/^log_archive_format/, @data)) 	
			|| &showError("$pname:Can't Find instance_number: @data",$instance_l);
        $log_archive_format = (split(' ', $data4[0]))[2];

	(@data2  = grep(/^Archive destination/, @data)) 
			|| &showError("$pname:Can't Find Archive Location: @data",$instance_l,1);
	$log_archive_dest   = (split(' ', $data2[0]))[2];
 	$log_archive_dest   = $log_archive_dest."/" 
			if ( -d $log_archive_dest and !($log_archive_dest =~/\/$/) );	
	$log_archive_dest   = $log_archive_dest.$log_archive_format;
	$log_archive_dest   = (split('%',$log_archive_dest))[0];
	($log_archive_dir)  =  $log_archive_dest  =~ /(.*)\/(\w*).arch/ ;

	# forcing standard format
	if ( !($2 eq ${db_name} or $2 eq ${instance_l}) ){
	     print "ARCHUTL:$instance_l: Invalid log_archive_dest format ";
	     print LOGFILE "ARCHUTL:$instance_l: Invalid log_archive_dest format :$log_archive_dest";
      	     $log_archive_dir ="";
	     return(1);
	   }

        # find last log sequence
        (@data3 = grep(/^Next log sequence to archive/, @data))
				||&showError("$pname:Can't Find Next log sequence: @data",$instance_l,1);
        $next_log_sequence 	= (split(' ', $data3[0]))[5];
        $last_arch_sequence 	= int($next_log_sequence) - 1;

	# find instance number
        (@data4  = grep(/^instance_number/, @data)) 
			|| &showError("$pname:Can't Find instance_number: @data",$instance_l);
        $instance_number 	= (split(' ', $data4[0]))[2];
        $instance_number 	= $instance_number +1 if ( $instance_number  == 0 )  ;
        #print "$instance_number:";
        #print LOGFILE "$instance_number:";

        (@data4  = grep(/^compatible/, @data))
                        || &showError("$pname:Can't Find compatible: @data",$instance_l);
        $compatible        = (split(' ', $data4[0]))[2];

        (@data4  = grep(/^no_of_racnodes/, @data))
                        || &showError("$pname:Can't Find no_of_racnodes: @data",$instance_l);
        $no_of_racnodes        = (split(' ', $data4[0]))[2];

        # find log_archive_dest_1
        (@data4  = grep(/^log_archive_dest_1/, @data))
                        || &showError("$pname:Can't Find log_archive_dest_1: @data",$instance_l);
        $log_archive_dest_1     = (split(' ', $data4[0]))[2];
        $dbinfo_arr{$instance_l}{isSetlog_archive_dest_1}="YES"
        		if ( defined($log_archive_dest_1) ) ;

	# find log_archive_dest_2 and standby_archive_dest for Datagaurd
	(@data4  = grep(/^log_archive_dest_2/, @data))
                        || &showError("$pname:Can't Find log_archive_dest_2: @data",$instance_l);
        $log_archive_dest_2     = (split(' ', $data4[0]))[2];
        if ( defined($log_archive_dest_2) ) {
		$dg_dbname=(split('=',$log_archive_dest_2))[1];
		$dg_dbname=(split(' ',$dg_dbname))[0];

        	# find standby arch dest
        	(@data4  = grep(/^standby_archive_dest/, @data))
                        || &showError("$pname:Can't Find standby_archive_dest: @data",$instance_l);
        	$standby_archive_dest     = (split(' ', $data4[0]))[2];
		if ( $standby_archive_dest =~ /$db_name/ ){
			print "DG=Y";
			print LOGFILE "DG=Y";
			$standby_archive_dest = "$standby_archive_dest/"
			  if ( !($log_archive_format =~ /^%t/) and !($standby_archive_dest =~/\/$/));
			$standby_archive_dest = $standby_archive_dest.$log_archive_format;
			$standby_archive_dest = (split('%',$standby_archive_dest))[0];
        		$dbinfo_arr{$instance_l}{standby_archive_dest} = $standby_archive_dest;
			$dbinfo_arr{$instance_l}{isDataguard}          = "YES";
		        $dbinfo_arr{$instance_l}{db_unique_name}       = &getDBUniqueName($instance_l)
							if ( $compatible =~ /^10/ );
		}

	}

        $dbinfo_arr{$instance_l}{instance}           = $instance_l;
        $dbinfo_arr{$instance_l}{database}           = $db_name;
	$dbinfo_arr{$db_name}{instance}              = $instance_l;
        $dbinfo_arr{$instance_l}{last_arch_sequence} = $last_arch_sequence;
        $dbinfo_arr{$instance_l}{log_archive_dest}   = $log_archive_dest;
        $dbinfo_arr{$instance_l}{log_archive_dest_2} = $log_archive_dest_2;
        $dbinfo_arr{$instance_l}{log_archive_dir}    = $log_archive_dir;
        $dbinfo_arr{$instance_l}{log_archive_format} = $log_archive_format;
        $dbinfo_arr{$instance_l}{dg_dbname}          = $dg_dbname ;
        $dbinfo_arr{$instance_l}{compatible}          = $compatible ;
        $dbinfo_arr{$instance_l}{no_of_racnodes}      = $no_of_racnodes ;
        $dbinfo_arr{$instance_l}{last_archfile}      = &findArchFile($instance_l,$last_arch_sequence);
        }

	if ( $dbinfo_arr{$instance_l}{log_archive_dir} ){
        print "\n  db_name                 = $dbinfo_arr{$instance_l}{database}";
        print LOGFILE "\n  db_name                 = $dbinfo_arr{$instance_l}{database}";
	print "\n  instance_number         = $instance_number";
	print LOGFILE "\n  instance_number         = $instance_number";
        print "\n  log_archive_dest        = $dbinfo_arr{$instance_l}{log_archive_dest}" ;
        print LOGFILE "\n  log_archive_dest        = $dbinfo_arr{$instance_l}{log_archive_dest}" ;
        print "\n  log_archive_dest_2      = $dbinfo_arr{$instance_l}{log_archive_dest_2}" 
							if(defined($log_archive_dest_2)) ;
        print LOGFILE "\n  log_archive_dest_2      = $dbinfo_arr{$instance_l}{log_archive_dest_2}" 
							if(defined($log_archive_dest_2)) ;
        print "\n  prod_last_archfile      = $dbinfo_arr{$instance_l}{last_archfile}";
        print LOGFILE "\n  prod_last_archfile      = $dbinfo_arr{$instance_l}{last_archfile}";
        print "\n  last_arch_sequence      = $dbinfo_arr{$instance_l}{last_arch_sequence}";
        print LOGFILE "\n  last_arch_sequence      = $dbinfo_arr{$instance_l}{last_arch_sequence}";
        print "\n  dg_dbname               = $dbinfo_arr{$instance_l}{dg_dbname}" 
							if(defined($dg_dbname));
	print "\n  db_unique_name          = $dbinfo_arr{$instance_l}{db_unique_name}" 
							if(defined($dbinfo_arr{$instance_l}{db_unique_name}));
        print LOGFILE "\n  dg_dbname               = $dbinfo_arr{$instance_l}{dg_dbname}" 
							if(defined($dg_dbname));
        print "\n  no_of_racnodes          = $dbinfo_arr{$instance_l}{no_of_racnodes}";
        print LOGFILE "\n  no_of_racnodes          = $dbinfo_arr{$instance_l}{no_of_racnodes}";
	}
    }
}

#-----------------------------------------------------------------------------
# getCurrArchDestFromFile :
#  - Finds log_archive_dest from init ora if there exists a DR or DG
#  - this function is effective on DR hosts 
#  - on certain cases when one of RAC node is down , this function is used
#    to get required init parameters from init file
#-----------------------------------------------------------------------------
sub getCurrArchDestFromFile()
{
	my $instance_l = shift;
	my $db_name_l;
	my $instance_number_l;
	my $log_archive_format_l;
	my $ifile;
	my $log_archive_dest_init_l;
        my $init_ora = qq($ENV{ORACLE_HOME}/dbs/init${instance_l}.ora);

        print "\n getCurrArchDestFromFile:$instance_l:";
        print LOGFILE "\n getCurrArchDestFromFile: $instance_l ";
	$log_archive_format = "";

	for ($retry=1;$retry <=10;$retry++){
		last if ( -f "$init_ora" );
		&mysleep(5);
	}
        open(INITORA, "cat $init_ora |  ")
                || &showError("$pname:getCurrArchDestFromFile:Cannot open $init_ora",$instance_l,1);
        while (<INITORA>) {
        	next if (/^#/ ); 
		chomp; 
                s/['"]//g;
                $log_archive_dest_init= $_ if ( /log_archive_dest[_1]*\b/i );
		s/\s+//g; 
		$ifile		      = $_ if (/ifile/i);
		$db_name              = $_ if (/db_name/i);
		$compatible  	      = $_ if (/compatible/i);
                $log_archive_format   = $_ if (/log_archive_format/i) ;
		$instance_number      = $_ if (/instance_number/i);
        }
        close(INITORA);
        $ifile             = (split('=', $ifile))[1];
	if ( -f $ifile ) {
	   open(IFILEORA,"cat $ifile |");
	   while(<IFILEORA>){
		next if (/^#/);
		chomp; 
                s/['"]//g;
		$log_archive_dest_init= $_ if ( /log_archive_dest[_1]*\b/i );
		s/\s+//g; 
		$db_name              = $_ if (/db_name/i );
		$compatible           = $_ if (/compatible/i );
		$log_archive_format   = $_ if (/log_archive_format/i );
		$instance_number      = $_  if (/instance_number/i );
	   }
	   close(IFILEORA);
	}
        $db_name           = (split('=', $db_name  ))[1];
	$instance_number   = (split('=', $instance_number  ))[1] if($instance_number  );
	$instance_number   = 1 if ( not $instance_number or (-f "$thread_path/${db_name}_thread1.dat"));
	$compatible        = (split('=', $compatible  ))[1];
        $log_archive_format= (split('=', $log_archive_format  ))[1];
        $log_archive_dest  = (split('=', $log_archive_dest_init  ))[1];
	if ( lc($log_archive_dest_init  ) =~/log_archive_dest_1/ ) {
          $log_archive_dest  = (split('=', $log_archive_dest_init  ))[2];
          $log_archive_dest  = (split(' ', $log_archive_dest  ))[0];
	}
	$log_archive_dest   = $log_archive_dest."/" 
				if ( -d $log_archive_dest and !($log_archive_dest =~/\/$/) );
        $log_archive_dest  = $log_archive_dest.$log_archive_format;
        $log_archive_dest  = (split('%',$log_archive_dest))[0];                                          
	($log_archive_dir)  = $log_archive_dest =~ /(.*)\/(\w*).arch/;

	if ( ! ($2 =~ m/${db_name}/) ){
                print "ARCHUTL:$instance_l: Invalid log_archive_dest format ";
                print LOGFILE "ARCHUTL:$instance_l: Invalid log_archive_dest format ";
		$log_archive_dir ="";
		return(1);
        }

	$dbinfo_arr{$instance_l}{instance} 	    = $instance_l;
	$dbinfo_arr{$instance_l}{database}  	    = $db_name;
	$dbinfo_arr{$db_name}{instance}  	    = $instance_l;
        $dbinfo_arr{$instance_l}{log_archive_dest}  = $log_archive_dest;
        $dbinfo_arr{$instance_l}{log_archive_dir}   = $log_archive_dir;
        $dbinfo_arr{$instance_l}{log_archive_format}= $log_archive_format;

        print "\n  log_archive_dest        = $dbinfo_arr{$instance_l}{log_archive_dest}" ;
        print LOGFILE "\n  log_archive_dest        = $dbinfo_arr{$instance_l}{log_archive_dest}" ;
        print "\n  log_archive_dir         = $dbinfo_arr{$instance_l}{log_archive_dir} " ;
        print LOGFILE "\n  log_archive_dir         = $dbinfo_arr{$instance_l}{log_archive_dir} " ;
	#print "\n  log_archive_format      = $dbinfo_arr{$instance_l}{log_archive_format} " ;
        print LOGFILE "\n  log_archive_format      = $dbinfo_arr{$instance_l}{log_archive_format} " ;
}

#-----------------------------------------------------------------------------
# getUsedSpace :
#	gets %usgae using commands 'dbf' or 'df'
#       'df' returns either 5 or 6 columns on some os and hence doing a 
#	left shift if first column is null
#-----------------------------------------------------------------------------
sub getUsedSpace
{
    local($file_system) = shift;

    open(DF, "$DF $file_system $dfopt |") || 
		&showError("$pname:getUsedSpace:Unable to do $DF $file_system $!",$instanceI,1);
    while (<DF>) {
        ($total = <DF>) || &showError("$pname:getUsedSpace:can't read total from $DF $file_system $!",$instanceI,1);
        @data = split(' ',$total);
	shift(@data) if( $#data == 5);

        $file_system = $data[4];
        $usage_p     = $data[3];
        $free_blocks = $data[2];
	$used_blocks = $data[1];
        $total_blocks= $data[0];

	#print "\n data|0=$total_blocks|1=$used_blocks|2=$free_blocks|";
        #print "3=$usage_p|4=$file_system == \n ";
    }
    $usage_pct = (split('%',$usage_p))[0] ;
    return ( int ( $usage_pct ) );
}

#-----------------------------------------------------------------------------
# purgeArchive :
#  - purge algorithm checks 
#     %usage, 
#     if archive log is applied to DR and 
#     if exists in tape ( default 1d, assuming that files older than 1d exists
#     in tape.
#  - recent_files is used to track if recent logs are purged and to send 
#  - expects format of archivelog *SID*arch*dbf* , it also purges *.dbf files  
#    in case of DG
#  - sends email if recent logs ( ARCHIVE_RETAIN_TIME) are removed sothat dba 
#    knows how recent the logs are removed
#  - sends alert if %usage is > upper_threshold even after purging 
#-----------------------------------------------------------------------------
sub purgeArchive()
{
  print "\npurgeArchive:";
  print LOGFILE "\npurgeArchive:";
  my $logdate_l=qx(date +'[%T]');chomp($logdate_l);
  print $logdate_l; print LOGFILE $logdate_l;
  my $status = 'NO';

  undef %recentFiles;
  foreach $mfs ( keys %mountfs){
    $archive_file_sys=$mountfs{$mfs};
    next if ( ! defined($archive_file_sys ) );
    $archive_file_dir=(split(' ',$archive_file_sys))[0];
    $archive_file_dir =~ s/\*//;
    &getParameters($mfs);

    print "\n mount filesystem         = $mfs";
    print LOGFILE "\n mount filesystem         = $mfs";
    print "\n archive_file_sys         =";
    print LOGFILE "\n archive_file_sys         =";
    my @ptmp=split(' ',$archive_file_sys);                                                                   
    # this piece of junk is very much required for easy 
    # reading on the output .
    my $pflag = 1;
    foreach (@ptmp) { 
      if ( $pflag == 1 ){ 
	  print " $_" ; 
	  print LOGFILE " $_" ; 
	  $pflag =0; 
	  next; 
      }
      print "\n                            $_";
      print LOGFILE "\n                            $_";
   }

    $ARCHIVE_RETAIN_SEC = &convertTime($archive_retain_time);
    print "\n  Parameters              = $mfs:$pct_lower_limit:";
    print LOGFILE "\n  Parameters              = $mfs:$pct_lower_limit:";
    print "$pct_upper_limit:$archive_retain_time:$mailto:$pageto";
    print LOGFILE "$pct_upper_limit:$archive_retain_time:$mailto:$pageto";
    $pct_used = &getUsedSpace($archive_file_dir);
    print "\n  Before purge:pct_used   = $pct_used% ";
    print LOGFILE "\n  Before purge:pct_used   = $pct_used% ";
    print "\n";
    print LOGFILE "\n";

    if ($pct_used >= $pct_upper_limit - 2)
    {
      open(PURGEFILES, "find ${archive_file_sys} -follow -name \"*dbf*\" |")
			|| &showError("$pname:Cannot open archive files. $!");;
      chomp(@pfiles=<PURGEFILES>);
      @spfiles=(map{$_->[0]} sort{$a->[1]<=>$b->[1]} map{[$_,(stat $_)[9]]} @pfiles);

      foreach (@spfiles) {
	 chomp($archfile=$_);
	 ($db_log_archive_dir,$dbname) = $archfile =~ /${archformat}(.*)/ ;
	 my $instance_l = $dbinfo_arr{$dbname}{instance};
	 $archsuffix= ".gz";
	 #$archsuffix= "" if ($dbinfo_arr{$instance_l}{isDataguard} eq "YES" );
         &getDbParameters($instance_l);
	 $archsuffix= "(\.\*)" if ( $zipmode eq "DISABLE" );
	 next if ( ! /${archformat}${archsuffix}$/ );

         &Stat("${archfile}");
	 if ( (&checkDRApplied("${archfile}") eq "YES")  && 
	     ( &checkTapeExists("${archfile}") eq "YES") &&
	     ( &isOpen("${archfile}") =~ /no/)             )
	 {
	       if ($st_mtime >= (time - $ARCHIVE_RETAIN_SEC)){
			$recentFiles{$dbname}=$db_log_archive_dir;
		}
		printf " (%10d)",$threadno if ( $threadno != $DEFAULT_THREAD) ;
		print LOGFILE "  ($threadno)" if ( $threadno != $DEFAULT_THREAD) ;
		print " unlink:${archfile}:$pct_used %:";
		print LOGFILE "  unlink:${archfile}:$pct_used %:";
		print "\n";
		print LOGFILE "\n";
	       	unlink("${archfile}") 
		  || print "$pname:Can't Unlink $_: $!" if (-e ${archfile});
		$dbinfo_arr{$instance_l}{purge_cnt}++;
		alarm($TIMEOUT);
		#print ".";
	 }
	 else {
		print "";
		print LOGFILE "";
		#print "\n No delete: ${archfile}";
	 }

         $pct_used = &getUsedSpace($archive_file_dir);
	 last if ($pct_used <= $pct_lower_limit);
	}
 	close(PURGEFILES);
  }
  
  #$pct_used=100; #TEST-simulate sad
  print "  After  purge:pct_used   = $pct_used% ";
  print LOGFILE "  After  purge:pct_used   = $pct_used% ";
  if ( $pct_used > $pct_upper_limit ){
     $dbname="";
     foreach $db ( keys %dbinfo_arr){
	if ( "$dbinfo_arr{$db}{log_archive_dir}" eq "$archive_file_dir" ){
		$instance_l=$db;
		last;
	}
      }
      &getDbParameters($instance_l);
      if( &isSwitch($instance_l) eq "YES" and 
          defined(lc($opt_O)) ne "nosad" ) {
		$status=&switchArchDest($instance_l);
		if ( $status eq "NO" ) {
		  print "\n  ERROR! Unable to do Switch Archive ";
		  print LOGFILE "\n  ERROR! Unable to do Switch Archive ";
                  &showError("$pname:Unable to do Switch Archive",$instance_l);
	       }
      }
      else{
        print "\n  Sending page $pageto :$local_host:$mfs:%usage ";
	print "is greater than $pct_upper_limit% after purge. ";
        print LOGFILE "\n  Sending page $pageto :$local_host:$mfs:%usage ";
	print LOGFILE "is greater than $pct_upper_limit% after purge. ";
        &showError("$mfs:%usage is greater than $pct_upper_limit% after purge.",$instance_l);
     }
  }
  }

  foreach $db ( keys %dbinfo_arr ){
    if ( $dbinfo_arr{$db}{connected} eq "Y" ) {
       printf "\n No. of logs purged(%-8s) = %2d",$db, $dbinfo_arr{$db}{purge_cnt};
       printf LOGFILE "\n No. of logs purged(%-8s) = %2d",$db, $dbinfo_arr{$db}{purge_cnt};
    }
  }

  foreach $db ( keys %recentFiles ){
    if( $isdrhost_f eq "NO" ) {
	&getDbParameters($instance_l);
        &showError("Recent Archive logs removed.",$recentFiles{$db},0,'N');
    }
  }
  print "\n";
  print LOGFILE "\n";
  &purgeNextArchive() ;
}

#-----------------------------------------------------------------------------
# getDRInfo :
#  - Finds DR host based on the below sync arch file
#         /usr/tools/oracle/sync_arch/adm/sync_arch_CAPPROD.cfg
#        or from standby_archive_dest in case of DG
#  - Gets the lastest archive log sequence applied to DR  ,
#    location of thread file  on a DR host
#         /usr/tools/oracle/recovery/thread/CAPPROD_thread1.dat
#  - set thread=DFAULT_THREAD if no DR 
#  - set thread=-1 in case  unable to read thread file
#-----------------------------------------------------------------------------
sub getDRInfo()
{
  my $instance_l 	= shift;
  my $dbname		= $dbinfo_arr{$instance_l}{database};
  my $nodrhost_alert ;
  my $dr_log_archive_dir,$dr_log_archive_dest;
  $ENV{sid}             = $instance_l ;
  $sync_arch_file  	= "sync_arch_${dbname}.cfg";
  $sync_arch_file  	= "sync_arch_${dbname}_thread${instance_number}.cfg";
  $sync_arch_file  	= "sync_arch_${dbname}.cfg" 
			   if(!-f "$sync_arch_path/$sync_arch_file");

  for ($racnode=1;$racnode <=8;$racnode++){
     $thread_file          = "${dbname}_thread$racnode.dat";
     #precheck for dir uto/recovery/thread
     &chkDatabaseRole("${thread_path}/${thread_file}");

     if ( -f "${thread_path}/${thread_file}" ){
      #print "\ngetDRInfo: $instance_l:";
      $drthread{$instance_l.$racnode} = qx(cat ${thread_path}/${thread_file});
      chomp($drthread{$instance_l.$racnode});
      $drthread{$instance_l.$racnode}  = int($drthread{$instance_l.$racnode});
      $isdrhost_f                = "YES";
      $drthread{$instance_l.$racnode} = $DEFAULT_THREAD 
				if( !$drthread{$instance_l.$racnode});
     }
  }
   $thread_file          = "${dbname}_thread${instance_number}.dat";
   #precheck for dir uto/recovery/thread
   &chkDatabaseRole("${thread_path}/${thread_file}");

   if ( -f "${thread_path}/${thread_file}" ){
       #print "\ngetDRInfo: $instance_l:";
       $drthread{$instance_l} = qx(cat ${thread_path}/${thread_file});
       chomp($drthread{$instance_l});
       $drthread{$instance_l}       = int($drthread{$instance_l});
       $isdrhost_f             = "YES";
       $drthread{$instance_l}  = $DEFAULT_THREAD if( !$drthread{$instance_l});
       return;
   }

   if ($dbinfo_arr{$instance_l}{isDataguard} eq "YES" or -f "$sync_arch_path/$sync_arch_file"){
       $drexists_f{$instance_l} = "YES";
   }

   #check for nodrhost flag and take decision whether drhost is unavilable 
   #temporarily or DR is being rebuild (blackout)
   &checkNodrhost($instance_l);
   
   if ($drexists_f{$instance_l} eq "YES"){

     if( $dbinfo_arr{$instance_l}{isDataguard} eq "YES")
     {
        print "\n getDRInfo:$instance_l:DG=Y:";
        print LOGFILE "\n getDRInfo:$instance_l:DG=Y:";
        $tnsping_data 		 = qx($ENV{'ORACLE_HOME'}/bin/tnsping $dg_dbname);
        $tnsping_data 		 =~s/\s+//g ;
        $remote_host  		 = (split('\)',(split('host=',lc($tnsping_data) ))[1]))[0];
        $dr_log_archive_dest 	 = $dbinfo_arr{$instance_l}{standby_archive_dest};
        $drexists_f{$instance_l}   = "YES";
      }
      else{
        if(-f "$sync_arch_path/$sync_arch_file") {
    	   print "\n getDRInfo:$instance_l:";
  	   print LOGFILE "\n getDRInfo:$instance_l:";
	   open(DRHOST,"$sync_arch_path/$sync_arch_file")
		    || &showError("$pname:Can't Open $sync_arch_path/$sync_arch_file ",$instance_l);
	   while(<DRHOST>){
	    if ( /^remote_sys/ ) {
		chomp($remote_host=(split('='))[1]) ;
		$drexists_f{$instance_l} = "YES";
	    }
            if ( /^remote_arch_dir/ ) {
                chomp($dr_log_archive_dir  = (split('='))[1]);
		chomp($dr_log_archive_dir  = qx{echo ${dr_log_archive_dir}}) ;
        	$dr_log_archive_dest	   = ${dr_log_archive_dir}."${dbname}\.arch";
		#print "\n  dr_log_archive_dest     = $dr_log_archive_dest";
            }
	   }
	   close(DRHOST);
	}
      }

      if (( -f "$sync_arch_path/$sync_arch_file") ||($dbinfo_arr{$instance_l}{isDataguard} eq "YES") ) {
	   print "\n  dr_host                 = $remote_host";
	   print LOGFILE "\n  dr_host                 = $remote_host";
	   print "\n  dr_log_archive_dest     = $dr_log_archive_dest";
	   print LOGFILE "\n  dr_log_archive_dest     = $dr_log_archive_dest";

           #alert if remote host doesn't exists                                                    
	   if(not $remote_host ){
	      print "\n  Error!!Unable to get DR hostname";
	      print LOGFILE "\n  Error!!Unable to get DR hostname";
              &showError("$pname: Unable to get DR host",$instance_l);
	   }

	   if ( &checkNodrhost($instance_l) eq 'N'){
#	   $ssh_status=0;
	   for ($retry=1;$retry <=10;$retry++){
	     chomp($drthread{$instance_l} = qx{$SSH -qn ${remote_host} $sshopt "cat ${thread_path}/${thread_file}"});
             last if ( $drthread{$instance_l} );
             &mysleep(6);
	   }
	   }

	  #$drthread{$instance_l}=""; #TEST-simulate drhost is down
#	  $ssh_status=1 if ( not  $drthread{$instance_l} ) ;
#	  system("rm $FLAG_DIR/$instance_l.nodrhost.* 2>/dev/null" )
#						if ($ssh_status == 0);

           #alert if thread is not found
           if ( $remote_host and not $drthread{$instance_l} ){
#                $nodrhost_alert = &checkNodrhost($instance_l);
                &showError("$pname: Unable to get DR thread info",$instance_l,0,$nodrhost_alert,$nodrhost_alert)
				if ( &checkNodrhost($instance_l) eq 'N' );
           }                                                                                       
	   $drthread{$instance_l}       = -1  if( !$drthread{$instance_l});

	   $drthread{$instance_l}       = int($drthread{$instance_l});
##	   print "\n  dr_thread               = $drthread{$instance_l}";
##	   print LOGFILE "\n  dr_thread               = $drthread{$instance_l}";

           #get for racnodes
           if ( &checkNodrhost($instance_l) eq 'N'){
           for ($racnode=1;$racnode <=$dbinfo_arr{$instance_l}{no_of_racnodes};$racnode++){
                my $thread_file          = "${dbname}_thread$racnode.dat";
                chomp($drthread{$instance_l.$racnode}  =qx{$SSH -qn ${remote_host} $sshopt "cat ${thread_path}/${thread_file} 2>/dev/null"});
                $drthread{$instance_l.$racnode} = int($drthread{$instance_l.$racnode});
                $drthread{$instance_l.$racnode} = -1 if (!$drthread{$instance_l.$racnode});
                print "\n  dr_thread$racnode              = $drthread{$instance_l.$racnode}";
                print LOGFILE "\n  dr_thread$racnode              = $drthread{$instance_l.$racnode}";
           }
           }
           

	   # trying to get last arch sequence shipped to DR site
	   my $drlogpath="${dr_log_archive_dest}${instance_number}";
	if ( &checkNodrhost($instance_l) eq 'N'){
	   for ($retry=1;$retry <=10;$retry++){
             ($dr_log_archive_dir)  =  $dr_log_archive_dest  =~ /(.*)\/(\w*).arch/ ;
             #@dr_last_archfile_a = qx($SSH -qn ${remote_host} $sshopt "ls -1tr ${drlogpath}\* | tail -50" 2>/dev/null);
             #@dr_last_archfile_a = qx($SSH -qn ${remote_host} $sshopt "find $dr_log_archive_dir/ -name '${dbname}\.arch$instance_number\*'|xargs ls -1tr|tail -50" 2>/dev/null) if (! @dr_last_archfile_a and $dr_log_archive_dir);

             #got the below line to avoid 'Aruments too long' when there are large no. of files in a dir
             @dr_last_archfile_a = qx($SSH -qn ${remote_host} $sshopt "ls -1tr $dr_log_archive_dir |grep '${dbname}\.arch$instance_number'|tail -20 ");

	     last if ( @dr_last_archfile_a );
	     &mysleep(6);
	   }

	   # sorting by sequence is required for possibility of zip/unzip happening on DR/DG host
	   # at the time of polling
           $dr_last_archfile=(map{$_->[0]} sort{$b->[1]<=>$a->[1]} map{[$_,/_(\d+)[\._]/]} @dr_last_archfile_a)[0];
	   chomp($dr_last_archfile);

           if (!$dr_last_archfile) {
               print "\n       $SSH -qn ${remote_host} ls -1tr ${dr_log_archive_dest}${instance_number}\*|tail -1";
               print LOGFILE "\n       $SSH -qn ${remote_host} ls -1tr ${dr_log_archive_dest}${instance_number}\*|tail -1";
               $nodrhost_alert = &checkNodrhost($instance_l);
	       print "\n  nodrhost_alert = $nodrhost_alert ";
	       &showError("$pname: Unable to get archinfo($dr_last_archfile) from DR host ${remote_host} ",$instance_l,0,$nodrhost_alert,$nodrhost_alert);
           }
	 }
           $dr_last_archfile				   = qq($dr_log_archive_dir/$dr_last_archfile);
           $dr_last_archfile				   =~ /${archformat}(.*)/ ;
           $dr_last_arch_sequence 	                   = int(${4});
	   $dbinfo_arr{$instance_l}{dr_last_arch_sequence} = $dr_last_arch_sequence;
           print "\n  dr_last_arch_sequence   = $dr_last_arch_sequence ";
           print LOGFILE "\n  dr_last_arch_sequence   = $dr_last_arch_sequence ";
      }
   }
   else{
          print "\n  DR_exists?              = None"
			if( $dbinfo_arr{$instance_l}{connected} eq "Y");
   }

   $drthread{$instance_l} = $DEFAULT_THREAD if( !$drthread{$instance_l});
   $drinfo_arr{$instance_l}{dr_log_archive_dest} = $dr_log_archive_dest;
   if (&checkNodrhost($instance_l) eq 'Y' ){
	print "\n  Ignore DR pages due to nodrhost flag set at $nodrhost_f \n";
	print LOGFILE "\n  Ignore DR pages due to nodrhost flag set at $nodrhost_f \n";
   }
}

#-----------------------------------------------------------------------------
# checkDRApplied :
#     Checks whether a log has been applied to DR
#-----------------------------------------------------------------------------
sub checkDRApplied()
{
  return("YES") if ($drexists_f{$instance} eq "NO");

  my $log=shift;
  my ($archdir,$archname,$instance_node,$logseq) = $log =~ /${archformat}(.*)/;

  foreach $db ( keys %dbinfo_arr ){
     if ( $dbinfo_arr{$db}{instance} eq $archname ){
		$instance_l = $archname;
		last;
      }
      if ( $dbinfo_arr{$db}{database} eq $archname ){
                 $instance_l = $dbinfo_arr{$db}{instance} ;
		 last;
      }
  }

  $threadno=$drthread{$instance_l};
  $threadno=$drthread{${instance_l}.${instance_node}} if ( $isdrhost_f eq "YES" ) ;

  #print " ($threadno)" if ( $logseq < $threadno && $threadno != $DEFAULT_THREAD) ;
  return("YES") if ( $logseq < $threadno ) ;
  return("NO");
}

#-----------------------------------------------------------------------------
# checkTapeExists :
#     Checks whether a log has been backuped on tape, currently it is assumed 
#     that archive logs older than 1day exists in tape.
#     BUT once sysadmins provide a standard file on all servers to look for 
#     logs that are in tape , at that moment we  have to change this algorithm
#-----------------------------------------------------------------------------
sub checkTapeExists()
{
	my $archfile=shift;
        # if it is a DR host , no need to check for tape
        return("YES") if ( $isdrhost_f eq "YES" ) ;

	$TAPE_CHECK_SEC=&convertTime($TAPE_CHECK_TIME);
	&Stat("${archfile}");
	return("NO")  if ( ! defined($st_mtime) );
	return("YES") if ( (time - $st_mtime)  > $TAPE_CHECK_SEC ) ;
	print "\n $archfile:Cannot remove latest files" if ( -f $tape_parfile ) ;
	print LOGFILE "\n $archfile:Cannot remove latest files" if ( -f $tape_parfile ) ;
	return("NO");	

	# below code will be used once sysadmin give us file for checking tape file
	$cnt=`cat $tape_parfile | grep $archfile | wc -l`;
	print "Tape cnt = $cnt ";
	print LOGFILE "Tape cnt = $cnt ";
	return("YES") if ( $cnt == 1 )   ;
        return("NO");
}

#-----------------------------------------------------------------------------
# convertTime :
#  - convert time variable from days ,hours or minutes into seconds 
#    for later comparison
#-----------------------------------------------------------------------------
sub convertTime()
{
    $purge_param = shift;
    if ( $purge_param =~ /(\d*)h$/ ) {
   	$purge_param = ${1};
   	$purge_time = int(${1}) * 60 * 60;
   	$interval   = "hours";
    }
    elsif ( $purge_param =~ /(\d*)m$/ ) {
        $purge_param = ${1};
        $purge_time = int(${1}) * 60;
        $interval   = "minutes";
    }
    elsif ( $purge_param =~ /(\d*)d$/ ) {
   	$purge_param = ${1};
   	$purge_time = int(${1}) * 24 * 60 * 60;
   	$interval   = "days";
    }
    elsif ( $purge_param =~ /(\d*)s$/ ) {
        $purge_param = ${1};
        $purge_time = int(${1}) ;
        $interval   = "seconds";
    }
    else {
   	$purge_time = $purge_param * 24 * 60 * 60;
   	$interval   = "days";
    }
    return(int($purge_time));
}

#-----------------------------------------------------------------------------
# getNewArchDest :
# - this function is used in switchArchive to find the next archive dest 
#   available for switching
# - read list of archive dests available from a sad parfile ,if any archive
#   dest is not available it scans through for next available destination .
# - The format expected in sad parfile is SWITCH:INSTANCE_ID:log_archive_dest:ENABLE:
#    Ex: SWITCH:CTSPRD1:/archive1/CTSPRD/CTSPRD.arch:ENABLE:
#    ( use cron exception form to add/modify this parameter )
#-----------------------------------------------------------------------------
sub getNewArchDest()
{
	my ($instance_l,$curr_log_archive_dir)=@_;
        $currIndex=-99;

	if ( -r $sad_parfile ) {
	   open(SADFILE, $sad_parfile	) || &showError("$pname:Can't Open $sad_parfile. $!",$instance_l);
	   while(<SADFILE>) {
	     if ( /^SWITCH/ and /$instance_l/ and !/DISABLE/ ){
		my ($logfile) = (split(/:/))[2];
		chomp($logfile);
		push(@sadarr,$logfile);
		if($logfile =~ /$curr_log_archive_dir/){
		  #print "\nlogfile=$logfile curr_log_archive_dir=$curr_log_archive_dir ::$#sadarr";
		  print "($#sadarr)";
		  print LOGFILE "($#sadarr)";
		  $currIndex=$#sadarr;
	        }
	      }
	   }
	}
	else {
		&showError("$pname:Unable to read sad_parfile:$sad_parfile",$instance_l);
	}

        if($currIndex == -99 ){
           print "\n config file:[$sad_parfile]";
           print "\n Looks like we have an issue with the above  config file";
           print "\n Please make sure the current archive dest [$curr_log_archive_dir] exists in config file";
           print "\n Please use cron exception in DBTS to modify the config file";
           print "\n format- <SWITCH>:<INSTANCE>:<archive log dest>:";
           &showError("$pname:Unable to get new archive dest, please check log",$instance_l);
           return;
        }

	# running a forloop in case if next archive dest in sequence is either 
	# incorrect or unavailable then proceed with the list until one found
	for ($cnt=1;$cnt < @sadarr; $cnt++){
	    $index=($currIndex+$cnt)%@sadarr;
	    $sadarr[$index] =~ /(.*)\/(\w*).arch/ ;
	    my $new_log_archive_dir=$1;
	    if ( -d $new_log_archive_dir ) {
		if ( $sadarr[$index] =~ /(.*)\/(\w*).arch/ ){
		    if ( $2 eq $dbinfo_arr{$instance_l}{database} or 
			 $2 eq $dbinfo_arr{$instance_l}{instance} ){
			return($sadarr[$index],$new_log_archive_dir);
		    }
		}
	    }
	    else{
	       print "\n not a valid arch dest [$new_log_archive_dir] .. skipping";
	       print LOGFILE "\n not a valid arch dest [$new_log_archive_dir] .. skipping";
	    }
	}
        &showError("$pname:Unable to get new archive dest, please check log",$instance_l);
	return;
}

#-----------------------------------------------------------------------------
# switchArchDest :
# - swtiches archive dest in database and also in init.ora file
#-----------------------------------------------------------------------------
sub switchArchDest()
{
	my $instance_l=shift;
	print "\n switchArchDest:$instance_l:";
	print LOGFILE "\n switchArchDest:$instance_l:";
	my ($new_log_archive_dest,$new_log_archive_dir) 
				= &getNewArchDest($instance_l,$dbinfo_arr{$instance_l}{log_archive_dir});
	$switch_archive_dest	= $new_log_archive_dest;
	$switch_archive_dest    = "$new_log_archive_dir/" 
			if ( !($dbinfo_arr{$instance_l}{log_archive_format} =~ /^%t/ ) ) ;
	$curr_log_archive_dir   = $dbinfo_arr{$instance_l}{log_archive_dir};

	print "\n  curr_log_archive_dir    = $curr_log_archive_dir";
	print "\n  new_log_archive_dir     = $new_log_archive_dir";
	print "\n  new/switch_archive_dest = $switch_archive_dest";
	print LOGFILE "\n  curr_log_archive_dir    = $curr_log_archive_dir";
	print LOGFILE "\n  new_log_archive_dir     = $new_log_archive_dir";
	print LOGFILE "\n  new/switch_archive_dest = $switch_archive_dest";

	if ( $new_log_archive_dest eq "" ){
		print "\n  ERROR:Possible invalid file format $sad_parfile";
		print LOGFILE "\n  ERROR:Possible invalid file format $sad_parfile";
		print "\n  ERROR:Archive destination is not changed";
		print LOGFILE "\n  ERROR:Archive destination is not changed";
		&showError("$pname:Unable to get new archive dest",$instance_l);
		return;
	}

	my $lad_options="";
	if ($dbinfo_arr{$instance_l}{compatible} =~ /^10/ ){
	   #if ($dbinfo_arr{$instance_l}{isDataguard} eq "YES" )
            if ($dbinfo_arr{$instance_l}{standby_archive_dest} =~ /$instance_l/){
	   $lad_options=" VALID_FOR=(ALL_LOGFILES, ALL_ROLES) DB_UNIQUE_NAME=".$dbinfo_arr{$instance_l}{db_unique_name}
				if(defined($dbinfo_arr{$instance_l}{db_unique_name}));
	   }
	  $lad_cmd1="select sysdate from dual";
	  my $switch_archive_dest_sql = "LOCATION=".$switch_archive_dest.$lad_options;
          $lad_cmd2="alter system set log_archive_dest='$switch_archive_dest'";
          $lad_cmd2="alter system set log_archive_dest_1='$switch_archive_dest_sql'"
          		if ( $dbinfo_arr{$instance_l}{isSetlog_archive_dest_1} eq "YES" );
	}
	else{
	  my $switch_archive_dest_sql = "LOCATION=".$switch_archive_dest.$lad_options;
	  $lad_cmd1="select sysdate from dual";
	  $lad_cmd2="alter system archive log start to '$switch_archive_dest'";
          $lad_cmd2="alter system set log_archive_dest_1='$switch_archive_dest_sql'"
          		if ( $dbinfo_arr{$instance_l}{isSetlog_archive_dest_1} eq "YES" );
	}
	&setOraclehome($instance_l);
	open(SQLDBA, "$oracle_home/bin/sqlplus /nolog << END
	connect /as sysdba
	$lad_cmd1;
	$lad_cmd2;
	archive log list
	exit
	END |") || &showError("$pname:Cannot do switch archive dest. $! ",$instance_l);
	@data = <SQLDBA>;
	(@data2  = grep(/^Archive destination/, @data))
                   || &showError("$pname:Can't Find Archive Location: @data",$instance_l);
	$check_log_archive_dest = (split(' ', $data2[0]))[2];
	$check_log_archive_dest =~ /(\/\w+)\/(.*)/;

	if ( $check_log_archive_dest ne $switch_archive_dest ){
		print "\n  ERROR!After DB switch :";
		print LOGFILE "\n  ERROR!After DB switch :";
		print "\n  check_log_archive_dest = $check_log_archive_dest=";
		print LOGFILE "\n  check_log_archive_dest = $check_log_archive_dest=";
		print "\n  new_log_archive_dest   = $new_log_archive_dest=";
		print LOGFILE "\n  new_log_archive_dest   = $new_log_archive_dest=";
		print "\n  @data ";
		print LOGFILE "\n  @data ";
		return("NO") ;
	}
	print "\n  Alter system command executed successfully";
	print LOGFILE "\n  Alter system command executed successfully";

	# modify file init.ora
        my $init_ora =qq($ENV{ORACLE_HOME}/dbs/init${instance_l}.ora);
	open(ORA, "$init_ora") || &showError("$pname:Cannot open $init_ora  file. $!",$instance_l);
	rename($init_ora, $init_ora . '.bak');
	open(INIT_ORA_OUT, ">$init_ora");
	while (<ORA>) {
	   if ( /log_archive_dest[_1]*\b/i and !/^#/ ){
		s/$curr_log_archive_dir/$new_log_archive_dir/;
           }
	   print INIT_ORA_OUT $_;  # this prints to original filename
    	}
	close(INIT_ORA_OUT);
	close(ORA);
	print "\n  Changes applied to ${init_ora}";
	print LOGFILE "\n  Changes applied to ${init_ora}";
	
	#after switch , modify array elements to reflect changes for multiple runs 
	$new_mfs=&getMountFS("$new_log_archive_dir");
	undef($mountfs{$dbinfo_arr{$instance_l}{mfs}});
	$mountfs{$new_mfs}	  = "$new_log_archive_dir/* ";
	$dbinfo_arr{$instance_l}{mfs} = $new_mfs ;
	
	$dbinfo_arr{$instance_l}{log_archive_dest} = $new_log_archive_dest;
	$dbinfo_arr{$instance_l}{log_archive_dir}  = $new_log_archive_dir;
        &getExceptionValues();
	print "\n";
	print LOGFILE "\n";
        return('YES');
}

#-----------------------------------------------------------------------------
# zipArchive :
# - zip/unzip depending on zipaction , by default zipmode=ENABLE
# - For DG and in cases where sync_arch is doing the job of zipping
#   you may have to disable zipping thro' cron exception
# - archformatG is required for dbs that starts with G* and also for 
#   logs that have GZIP because of prev incomplete unzip 
#-----------------------------------------------------------------------------
sub zipArchive()
{
  print "\nzipArchive:";
  print LOGFILE "\nzipArchive:";
  my $zipaction;
  my $dbname;
  my $time_s = time;
  $zipaction = shift ;
  print "$zipaction:";
  print LOGFILE "$zipaction:";
  my $logdate_l=qx(date +'[%T]');chomp($logdate_l);
  print $logdate_l; print LOGFILE $logdate_l;
  $ZIP_ARCHIVE_SEC=&convertTime($ZIP_ARCHIVE_TIME);

  foreach $mfs ( keys %mountfs){
    $archive_file_sys = $mountfs{$mfs};
    $archive_file_sys =~ s/[0-9]+/*[0-9]/g;
    print "\n archive_file_sys         =";
    print LOGFILE "\n archive_file_sys         =";
    my @ptmp=split(' ',$archive_file_sys);
    my $pflag = 1;
    foreach (@ptmp) { 
      if ( $pflag == 1 ){
        print " $_" ;
        print LOGFILE " $_" ;
        $pflag =0;
        next;
      }
      print "\n                            $_"; 
      print LOGFILE "\n                            $_"; 
    }

    open(ZIPFILES, "find $archive_file_sys -follow -name '*dbf*' |") 
			|| &showError("$pname:Cannot open zip files");;
    chomp(@zfiles=<ZIPFILES>);
    @szfiles=(map{$_->[0]} sort{$a->[1]<=>$b->[1]} map{[$_,(stat $_)[9]]} @zfiles);

    foreach (@szfiles)
    {
	chomp($ziplog  = $_);
	$ziplog        =~/$archformat(.*)/;
        $ziplog        =~/$archformatG(.*)/ if ( $ziplog =~ /GZIP/) ;
	$dbname        = $2;
	$logseq        = $4;
	$instance_node = $3;
	next if (!$dbname) ;
	$instance_l  = $dbinfo_arr{$dbname}{instance};
	&getDbParameters($instance_l);
        next if ( ($zipaction =~ /^compress/) && ($zipmode eq "DISABLE") );
	$threadno=$drthread{$instance_l};
        $threadno=$drthread{${instance_l}.${instance_node}} if ( $isdrhost_f eq "YES" ) ;
	$threadno=$DEFAULT_THREAD if ( $isdrhost_f eq "NO" &&
				       $dbinfo_arr{$instance_l}{isDataguard} ne "YES" );
	&getDbParameters($instance_l);

	if( ($zipaction =~ /^compress/) && 
	    ($ziplog =~ /$archformat$/ ) )
	{
	    if ($logseq < $threadno){
                if ( ((stat ${ziplog})[9]  < (time - $ZIP_ARCHIVE_SEC )) &&
                     (&isOpen("${ziplog}") =~ /no/) ) {
			$dbinfo_arr{$instance_l}{zip_cnt}++;
			# Check inbetween zipping for possible purge and switchArchive
		        if ( !(defined($opt_O) and (lc($opt_O) eq "ziponly" )) ){
			  if ( (time - $time_s) > 300 ) {
   		   	    print "\n\n";
   		   	    print LOGFILE "\n\n";
			    print "--------------------HELLO,I am checking %used ----------------";
			    print LOGFILE "--------------------HELLO,I am checking %used ----------------";
		            alarm($TIMEOUT);
  		   	    &purgeArchive();
			    $time_s = time;
  		   	    print "--------------------HELLO,I am done with checking ------------\n";
  		   	    print LOGFILE "--------------------HELLO,I am done with checking ------------\n";                           }
                         }
			 &processFork($zipaction,$ziplog);
		}
		else{
			&mysleep(4);
                        print "\n  ${ziplog} is in use or was cut ";
                        print LOGFILE "\n  ${ziplog} is in use or was cut ";
			print "less than $ZIP_ARCHIVE_SEC seconds ago";
			print LOGFILE "less than $ZIP_ARCHIVE_SEC seconds ago";
                }
	    }
	}
	# unzip ONLY in dr host 
	if ( $zipaction =~ /^uncompress/ ) {
	   if ( $logseq >= $threadno ) {
	        next if( $dbinfo_arr{$dbname}{unzip_num} == $throttle_window ) ;
		if ( ${ziplog} =~ /\.gz$/ or  ${ziplog} =~ /GZIP/ ){
		   if (&isOpen("${ziplog}") =~ /yes/) {
			print "\n  ${ziplog} is in use ...";
			next;
		   }
		   $dbinfo_arr{$instance_l}{unzip_cnt}++;
                   &processFork($zipaction,$ziplog) ;
		}
	        $dbinfo_arr{$instance_l}{unzip_num}++;
	   }
	}   
    }
    close(ZIPFILES);
    &mysleep(4);
    &processForkEnd();
  }

  #send info on no. of logs unzipped for each database
  foreach $db ( keys %dbinfo_arr ){
     if ( $dbinfo_arr{$db}{connected} eq "Y" ) {
	printf ("\n No. of logs zipped(%-8s) = %2d",$db,$dbinfo_arr{$db}{zip_cnt}) 
				if( $db && $zipaction eq "compress" );
	printf LOGFILE ("\n No. of logs zipped(%-8s) = %2d",$db,$dbinfo_arr{$db}{zip_cnt}) 
				if( $db && $zipaction eq "compress" );
	printf ("\n No. of logs unzipped(%-8s) = %2d",$db,$dbinfo_arr{$db}{unzip_cnt}) 
				if( $db && $zipaction =~ /uncompress/ );
	printf LOGFILE ("\n No. of logs unzipped(%-8s) = %2d",$db,$dbinfo_arr{$db}{unzip_cnt}) 
				if( $db && $zipaction =~ /uncompress/ );
     }
  }
  print "\n";
  print LOGFILE "\n";
}

#-----------------------------------------------------------------------------
# isOpen :
#     checks  if log in use by other process using fuser
#-----------------------------------------------------------------------------
sub isOpen {
	my $file = $_[0];

	unlink "${statfile}";
   	system "$FUSER $fuseropt $file > ${statfile} 2>/dev/null";
	if ( -s "${statfile}"){
	  open(FUSERFILE, "${statfile}") ;
          chomp($pid2 = <FUSERFILE>);
	  close(FUSERFILE);
        }
        return "no" if ($pid2 eq "");
        return "yes";
} 

#-----------------------------------------------------------------------------
# switchOracleLog :
# - Does archive log switch if no log generated for certain period .
# - This is required in DR envs wherein there is low activity  to 
#   avoid alerts due to log waiting 
#   variable - ZIP_ARCHIVE_SEC 
#-----------------------------------------------------------------------------
sub switchOracleLog()
{
	my $dbname = shift;

	$last_archfile=$dbinfo_arr{$dbname}{last_archfile};
	$last_archthread=$dbinfo_arr{$dbname}{last_arch_sequence};
        $last_archfile=$last_archfile.".gz" if ( ! -f $last_archfile );

	#print "\n  $last_archfile $last_archthread ";
	&Stat("${last_archfile}");
	$LOGSWITCH_SEC=&convertTime($LOGSWITCH_TIME);

	$a=(time - $st_mtime);
	#print "\nst_mtime=$st_mtime diff=$a LOGSWITCH_SEC=$LOGSWITCH_SEC";

        if ( (time - $st_mtime) >= $LOGSWITCH_SEC){
        	print "\n\nswitchOracleLog:$dbname:";
        	print LOGFILE "\nswitchOracleLog:$dbname:";
        	print "\n last_archthread = $last_archthread";
        	print LOGFILE "\n last_archthread = $last_archthread";
        	print "\n last_archfile   = $last_archfile:";
        	print LOGFILE "\n last_archfile   = $last_archfile:";
		open(SQLDBA, "$oracle_home/bin/sqlplus -s /nolog << END
		connect /as sysdba
	        alter system switch logfile ;
	        exit
	        END |") || &showError("$pname:Cannot do alter system switch logfile. $!",$dbname);
	        @data = <SQLDBA>;
		print "\n Alter system command executed successfully.";
		print LOGFILE "\n Alter system command executed successfully.";
	}
   	print "\n";
   	print LOGFILE "\n";
}

#-----------------------------------------------------------------------------
# isSwitch :
#    this function is used to find if switch archive is enabled or not 
#    if sad_parfile exists then script archive destination is enabled.
#-----------------------------------------------------------------------------	
sub isSwitch()
{
	my $dbname=shift;
	
	#print "\n$dbname : $sad_parfile :\n";
	#return("NO") if ( lc($opt_O) eq "nosad");
	return("NO") if( !-f $sad_parfile) ;
	my $cnt=`cat $sad_parfile | grep "SWITCH:$dbname" |grep -v "DISABLE"| wc -l`;
	chomp($cnt);
	#print "\ncnt:$cnt:";
	if ( $cnt == 0  ) {
		return("NO");
	}
	else{
		return("YES");
	}
}

#-----------------------------------------------------------------------------
# Usage:
#     Displays about script usage when no arguments specified
#-----------------------------------------------------------------------------
sub Usage {
       $exit = shift(@_) || 0;
       print STDERR "\n $Synopsis";
       exit $exit;
}

#-----------------------------------------------------------------------------
# prepareMountFS :
#     This is the main function for driving zip and purge process.
#     This function prepares mount points for all database archive locations 
#-----------------------------------------------------------------------------
sub prepareMountFS()
{
	my $dbname = shift;

	&getCurrArchDest($dbname);
	return(0) if ( $dbinfo_arr{$dbname}{log_archive_dir} eq "" ) ;

	$dbinfo_arr{$dbname}{connected} = "Y";
	$mfs 			 = &getMountFS("$dbinfo_arr{$dbname}{log_archive_dir}");
	$mountfs{$mfs}          .= "$dbinfo_arr{$dbname}{log_archive_dir} ";
	#mount_fscnt - currently not in use
	#$mount_fscnt{$mfs}       = $mount_fscnt{$mfs} + 1;
	$dbinfo_arr{$dbname}{mfs}= $mfs ;
}
		
#-----------------------------------------------------------------------------
# processFork :
#	used for forking multiple streams
#	currently this is used for modules zipping and unzipping
#-----------------------------------------------------------------------------
sub processFork()
{
    my ($zipaction,$ziplog) = @_;

    if ($pid = fork) {   # PARENT
	#system(date);
        push @pids_running, $pid;
        while ($#pids_running >= $MAXPROCS - 1 ) {
            foreach $pid (@pids_running) {
                if (($return = POSIX::waitpid( $pid, &POSIX::WNOHANG )) > 0) {
                    @pids_running = grep !/^${pid}$/, @pids_running;
                }
            }
            &mysleep(5);
        }
    }
    elsif (defined $pid) {  # CHILD
        select(STDOUT); $| = 1;
        select(STDERR); $| = 1;
        select(STDOUT);
	zipCmd($zipaction,$ziplog);
        exit 0;
    }
    else {
        &showError("$pname:Can't Fork: $!\n");
    }
}

#-----------------------------------------------------------------------------
# processForkEnd :
#     function to do cleanup after child processes are done 
#-----------------------------------------------------------------------------
sub processForkEnd()
{
	#print "\nprocess end $#pids_running";
	print "\n  in pids_running         = ";
	print LOGFILE "\n  in pids_running         = ";
	while ($#pids_running >= 0)
	{
    		foreach $pid (@pids_running)
    		{
        	if (($return = POSIX::waitpid( $pid, &POSIX::WNOHANG )) > 0)
        	{
            	@pids_running = grep !/^${pid}$/, @pids_running;
        	}
    	}
    	#print "\n in pids_running=$#pids_running ";
	print "$#pids_running";
	print LOGFILE "$#pids_running";
    	&mysleep(5);
	}
}

#-----------------------------------------------------------------------------
# zipCmd :
#     function for actual gzip and gunzip
#     in case of uncompress the logs are renamed as GZIP.archlog before actual 
#     gunzip to avoid standby to grab incomplete archive logs 
#-----------------------------------------------------------------------------
sub zipCmd(){
	my $zipaction;
	my $flogfile;
	my $archfilename;
	my $dbname;
	($zipaction,$flogfile) = @_;
 	($archdir,$archfile)   = $flogfile =~ /(.*)\/(\w+.*)/;
	
	print "\n";
	print LOGFILE "\n";
        printf " (%10d)",$threadno if ( $threadno != $DEFAULT_THREAD) ;
	print LOGFILE " ($threadno)" if ( $threadno != $DEFAULT_THREAD) ;
	if ( $zipaction =~ /^compress/ ){
		print " zipping:${flogfile}:";
		print LOGFILE "  zipping:${flogfile}:";
		`$GZIP --fast ${flogfile}`;
	}
	if ( $zipaction =~ /uncompress/ ){
		if ( ${flogfile} =~ /\.gz$/ ) {
                        if ( ${flogfile} =~ /GZIP/ )  {
                                #print " Type2:GZIP.File.dbf.gz     unzipping ${archdir}/${archfile}";
                                print " unzipping:${archdir}/${archfile}:";
                                print LOGFILE " unzipping:${archdir}/${archfile}:";
                                `$GZIP -d ${archdir}/${archfile}`;
                                $archfile =~ s/\.gz$// ;
                                $archfile =~ s/GZIP\.// ;
                                rename("${archdir}/GZIP.${archfile}", "${archdir}/${archfile}");
                        }
                        else{
                                #print " Type1:File.dbf.gz:     unzipping ${flogfile}:";
                                print " unzipping:${flogfile}:";
                                print LOGFILE " unzipping:${flogfile}:";
                                rename("${archdir}/${archfile}", "${archdir}/GZIP.${archfile}");
                                `$GZIP -d ${archdir}/GZIP.${archfile}`;
                                $archfile =~ s/\.gz$// ;
                                rename("${archdir}/GZIP.${archfile}", "${archdir}/${archfile}");
                        }
	 	}
                else {
                        if ( ${archfile} =~ /GZIP/ ){
                                #print " Type3:GZIP.File.dbf:unzipping ${flogfile}:";
                                print " unzipping:${flogfile}:";
                                print LOGFILE " unzipping:${flogfile}:";
                                $archfile =~ s/GZIP\.// ;
                                rename("${archdir}/GZIP.${archfile}", "${archdir}/${archfile}");
                        }
                }
	}
}

#-----------------------------------------------------------------------------
# getExceptionValues:
# 	Reads exceptionDB.par file for non-default parameters
#-----------------------------------------------------------------------------
sub getExceptionValues
{
    my $mfs_e ;
    my $archive_e ;
    my $pct_upper_limit_e ;
    my $pct_lower_limit_e ;
    my $archive_retain_e ;
    my $zipmode_e ;

    if (-r $exceptfile) {
        open(EXCEPTFILE, $exceptfile) || &showError("$pname:Can't Open $exceptfile. $!");
        while (<EXCEPTFILE>)
        {
           next unless (/^ARCHIVE:/ );
           {
	     @data_e = split(/:/);
	     $data_n = @data_e;
	     chomp($data_e[$data_n-1]);

	     $sid_e				= $data_e[1];
	     $mfs_e=$dbinfo_arr{$sid_e}{mfs};
             $pct_lower_limit_ea{$mfs_e} 	= $data_e[2];
             $pct_upper_limit_ea{$mfs_e} 	= $data_e[3];
             $archive_retain_ea{$mfs_e}  	= $data_e[4];
             $zipmode_ea{$mfs_e}         	= $data_e[5];
             $zipmode_ea{$sid_e}         	= $data_e[5];

	     $mailto_ea{$sid_e}			= $data_e[6];
	     $pageto_ea{$sid_e}			= $data_e[7];
             $sync_arch_mail_limit_ea{$sid_e}   = $data_e[8];
             $sync_arch_page_limit_ea{$sid_e}   = $data_e[9];
             $drlog_mail_limit_ea{$sid_e}  	= $data_e[10];
             $drlog_page_limit_ea{$sid_e}  	= $data_e[11];
             $throttle_window_ea{$sid_e}  	= $data_e[12];
             $throttle_window_ea{$mfs_e}  	= $data_e[12];

             #print "\n ";
	     #print "getExceptionValues:$mfs_e:";
	     #print "\n  $sid_e:$pct_lower_limit_ea{$mfs_e}:";
	     #print "$pct_upper_limit_ea{$mfs_e}:$archive_retain_ea{$mfs}:";
             #print "$zipmode_ea{$mfs_e}:";
	     #print "$mailto_ea{$sid_e}:$pageto_ea{$sid_e}:";
             #print "$sync_arch_mail_limit_ea{$sid_e}:$sync_arch_page_limit_ea{$sid_e}:";
	     #print "$drlog_mail_limit_ea{$sid_e}:$drlog_page_limit_ea{$sid_e}:";
	     #print "$manual_drstop_limit_ea{$sid_e}:$throttle_window_ea{$sid_e}";

           }
        }
        close(EXCEPTFILE);
    }
}

#-----------------------------------------------------------------------------
# getParameters :
#     gets exception/default values based on mount filesystem
#     these values will be specific to a mount fs
#-----------------------------------------------------------------------------
sub getParameters()
{
    my $mfs          	 = shift;
    $pct_lower_limit 	 = $pct_lower_limit_ea{$mfs} ? $pct_lower_limit_ea{$mfs} : $pct_lower_limit_d;
    $pct_upper_limit 	 = $pct_upper_limit_ea{$mfs} ? $pct_upper_limit_ea{$mfs} : $pct_upper_limit_d;
    $archive_retain_time = $archive_retain_ea{$mfs} ? $archive_retain_ea{$mfs} : $archive_retain_time_d;
    $zipmode 		 = $zipmode_ea{$mfs} ? $zipmode_ea{$mfs} : $zipmode_d;
    $throttle_window     = $throttle_window_ea{mfs}?$throttle_window_ea{$mfs}:$throttle_window_d;
}

#-----------------------------------------------------------------------------
# getDbParameters :
#  - gets exception/default values based on database name
#-----------------------------------------------------------------------------
sub getDbParameters()
{
    $dbname 	          = shift;
    #$mailto		  = $mailto_ea{$dbname} ? $mailto_ea{$dbname} : $mailto_d ;
    #$pageto		  = $pageto_ea{$dbname} ? $pageto_ea{$dbname} : $pageto_d ;
    $mailto		  = $mailto_ea{$dbname} ? $mailto_ea{$dbname} : $dbinfo_arr{$dbname}{mailto} ;
    $pageto		  = $pageto_ea{$dbname} ? $pageto_ea{$dbname} : $dbinfo_arr{$dbname}{pageto} ;
    $sync_arch_mail_limit = $sync_arch_mail_limit_ea{$dbname}?$sync_arch_mail_limit_ea{$dbname}:$sync_arch_mail_limit_d;
    $sync_arch_page_limit = $sync_arch_page_limit_ea{$dbname}?$sync_arch_page_limit_ea{$dbname}:$sync_arch_page_limit_d;
    $drlog_mail_limit     = $drlog_mail_limit_ea{$dbname}?$drlog_mail_limit_ea{$dbname}:$drlog_mail_limit_d;
    $drlog_page_limit     = $drlog_page_limit_ea{$dbname}?$drlog_page_limit_ea{$dbname}:$drlog_page_limit_d;
    $zipmode 		  = $zipmode_ea{$dbname} ? $zipmode_ea{$dbname} : $zipmode_d;
    $throttle_window      = $throttle_window_ea{$dbname}?$throttle_window_ea{$dbname}:$throttle_window_d;
}
	
#-----------------------------------------------------------------------------
# findArchFile :
#  - Input parameter is sequence number and finds the last archfile
#    based on sequence which is used to determine timestamp of the
#    later in getSyncArchLogLag()
#-----------------------------------------------------------------------------
sub findArchFile()
{
  	my ($instance_l,$seq)      = @_;
	my $log_archive_dest       = $dbinfo_arr{$instance_l}{log_archive_dest};
    	my $star_log_archive_dest  = $log_archive_dest ;
	#$star_log_archive_dest    =~ s/[0-9]+/*/;
	$star_log_archive_dest     =~ s/[0-9]+/*[0-9]/g;

	my $archfile ;
        open(LASTFILE, "ls -1tr $star_log_archive_dest${instance_number}*${seq}*dbf* | tail -1 |") 
				|| &showError("$pname:Cannot find last archive log. $!");
        while (<LASTFILE>) {
            chomp($archfile=$_);
       }
        close(LASTFILE);
        return ( $archfile ) ;
}

#-----------------------------------------------------------------------------
# getDRLogLag :
#  - Connects to database and gets the data and time of archive logs 
#    of last sequence available on DR host and last archive sequence 
#     applied on DR ,
#  - If required data is not available in database , then it tries to 
#    get the same info from archive logs available on server
#-----------------------------------------------------------------------------
sub getDRLogLag()
{
   my $instance_l = shift ;
   my $dbname     = $dbinfo_arr{$instance_l}{database};
   my $log_arch_dest = $dbinfo_arr{$instance_l}{log_archive_dest};
   $current_thrd        = $dbinfo_arr{$instance_l}{last_arch_sequence};
   $dr_last_arch_seq    = $dbinfo_arr{$instance_l}{dr_last_arch_sequence};
   $remote_thrd 	= $drthread{$instance_l};
   return if ( $remote_thrd == -1 );
   return if ( $dr_last_arch_seq == 0 );
   $logs_behind	        = $current_thrd - $remote_thrd ;
   print "\ngetDRLogLag :$instance_l:";
   print LOGFILE "\ngetDRLogLag :$instance_l:";
 
   my $str		= qq(date +'%S:%M:%H:%d:%m:%Y';ls -1tr ${norecover_path}/${dbname}|wc -l);
   chomp(($cdate,$dbinfo_arr{$instance_l}{norecover_flag})=qx($SSH -qn ${remote_host} $sshopt "$str" 2>/dev/null));

   $norecover_flag  	= int($dbinfo_arr{$instance_l}{norecover_flag} );
   print "$norecover_flag:";
   print LOGFILE "$norecover_flag:";

   $sync_arch_mail_sec = &convertTime($sync_arch_mail_limit);
   $sync_arch_page_sec = &convertTime($sync_arch_page_limit);
   $drlog_mail_sec     = &convertTime($drlog_mail_limit) ;
   $drlog_page_sec     = &convertTime($drlog_page_limit) ;

   $sql_stmt = "SELECT  'to_be_recovered_sec  ' ||
                        ROUND((plog.FIRST_TIME - dlog.FIRST_TIME)*24*60*60)
                FROM    v\\\$log_history dlog , v\\\$log_history plog,
			v\\\$instance ins
                WHERE   dlog.SEQUENCE# = $remote_thrd
                AND     plog.SEQUENCE# = $current_thrd
		AND     d.log.thread#  = plog.thread#
		AND     p.log.thread#  = ins.instance_number
                UNION
		SELECT  'sync_arch_lag_sec '||
                        ROUND((plog.FIRST_TIME - slog.FIRST_TIME)*24*60*60)
                FROM    v\\\$log_history plog,v\\\$log_history slog,
			v\\\$instance ins
                WHERE   slog.SEQUENCE# = $dr_last_arch_seq
                AND     plog.SEQUENCE# = $current_thrd
		AND     d.log.thread#  = plog.thread#
		AND     p.log.thread#  = ins.instance_number";

   open(SQLDBA, "$oracle_home/bin/sqlplus /nolog << END
        connect /as sysdba
        show parameter db_name
        alter session set nls_date_format = 'DD-MON-YY HH24:MI:SS';
        set heading off
        $sql_stmt ;
        exit
        END |") || &showError("$pname:getDRLogLag:sqlplus error: $!",$instance_l);
        @data = <SQLDBA>;

   if ( (@data1  = grep(/^to_be_recovered_sec/, @data)) ) {
      $to_be_recovered_sec= (split(' ', $data1[0]))[1];
   } 
   else{
	$to_be_recovered_sec = &getArchTimeFromHost($instance_l,$current_thrd,$remote_thrd);
   }
   $to_be_recovered_d   = &convertSecToHrs($to_be_recovered_sec);

   if( (@data1  = grep(/^sync_arch_lag_sec/, @data))  ) {
      $sync_arch_lag_sec 	= (split(' ', $data1[0]))[1];
   }
   else{
	$sync_arch_lag_sec = &getArchTimeFromHost($instance_l,$current_thrd,$dr_last_arch_seq);
   }
   $sync_arch_lag_d     = &convertSecToHrs($sync_arch_lag_sec);

   print "\n mailto            :pageto                 = [$mailto:$pageto]";
   print LOGFILE "\n mailto            :pageto                 = [$mailto:$pageto]";
   print "\n current_thread    :dr_last_arch_seq       = [$current_thrd:$dr_last_arch_seq]";
   print LOGFILE "\n current_thread    :dr_last_arch_seq       = [$current_thrd:$dr_last_arch_seq]";
   print "\n current_thread    :dr_last_applied_thread = [$current_thrd:$remote_thrd]";
   print LOGFILE "\n current_thread    :dr_last_applied_thread = [$current_thrd:$remote_thrd]";
   print "\n dr_host           :No. of Logs behind     = [${remote_host}:$logs_behind]";
   print LOGFILE "\n dr_host           :No. of Logs behind     = [${remote_host}:$logs_behind]";
   print "\n to_be_recovered   :sync_arch_lag          = [$to_be_recovered_d($to_be_recovered_sec):";
   print LOGFILE "\n to_be_recovered   :sync_arch_lag          = [$to_be_recovered_d($to_be_recovered_sec):";
	print "$sync_arch_lag_d($sync_arch_lag_sec)]";
	print LOGFILE "$sync_arch_lag_d($sync_arch_lag_sec)]";
   print "\n";
   print LOGFILE "\n";

   # check for nopage flag on dr host ,
   # if flag exists ignore alerts 
   return if ( &checkNopage($dbname) eq "YES" );

   if ( $sync_arch_lag_sec > $sync_arch_mail_sec )
   {
    print "\n   Sending email ... ";
    print LOGFILE "\n   Sending email ... ";
    #$errmsg = &msgfmt("w","$local_host","$dbname","sync_arch lags log shipping by more than $sync_arch_lag_d ");
    $errmsg =qq(ARCHUTL).qq($local_host $dbname $pname).qq(:sync_arch lags log shipping by more than $sync_arch_lag_d );
    print " \n $errmsg \n";
    print LOGFILE " \n $errmsg \n";
    &mailit("$errmsg","/dev/null");
   }

   if ( $sync_arch_lag_sec > $sync_arch_page_sec )
   {
    print "\n   Sending epage ... ";
    print LOGFILE "\n   Sending epage ... ";
    &showError("sync_arch lags log shipping by more than $sync_arch_lag_d",$dbname);
   }
   #print "\n";

   if ( ($norecover_flag != 1 && $to_be_recovered_sec  > $drlog_mail_sec) ) {
        print "\n  Sending email ... ";
        print LOGFILE "\n  Sending email ... ";
        #$errmsg = &msgfmt("w","$local_host","$dbname","DR is $to_be_recovered_d behind production db");
        $errmsg =qq(ARCHUTL).qq($local_host $dbname $pname).qq(:DR is $to_be_recovered_d behind production db);
        print " \n $errmsg \n";
        print LOGFILE " \n $errmsg \n";
        &mailit("$errmsg","/dev/null");
   }

   if ( ($norecover_flag != 1 && $to_be_recovered_sec  > $drlog_page_sec)   ) {
        print "\n  Sending epage ... ";
        print LOGFILE "\n  Sending epage ... ";
        &showError("DR is $to_be_recovered_d behind production db",$dbname);
  }
}

#-----------------------------------------------------------------------------
# checkNopage :
#  - This function takes care of alerts during know issues with DR recovery,
#    in case DR is unavailable for known time , we could stop DR alerts by
#    creating below flag ,
#    drhost:/usr/tools/oracle/recovery/norecover/SID.nopage.24h
#  - By default script itself creates a 24h flag to ignore pages when DR
#    is stopped for refreshes .This way it stops paging alerts during refresh  
#    and certain time after the refresh 
#-----------------------------------------------------------------------------
sub checkNopage(){
   my $dbname = shift;
   $ENV{dbname} = $dbname;
   if ( $norecover_flag == 1 && $to_be_recovered_sec > 6*60*60 ) {
      print "\n  checkNopage:$dbname:$norecover_flag:${remote_host}";
      print LOGFILE "\n  checkNopage:$dbname:$norecover_flag:${remote_host}";
      $ssh_script='perl -e \' if ( system(\"ls -1tr /usr/tools/oracle/recovery/norecover/${dbname}.nopage.* \") != 0 ) {
                                        system(\"touch /usr/tools/oracle/recovery/norecover/${dbname}.nopage.24h\") ;
                                }
                                \' ';
      #print "\n ssh_script = $ssh_script ";
      @nopage_value_a = `$SSH -qn ${remote_host} $sshopt "$ssh_script" 2>/dev/null `;
      print "\n nopage_value_a = @nopage_value_a";
      print LOGFILE "\n nopage_value_a = @nopage_value_a";
   }
      #print "\n checkNopage:$dbname:$norecover_flag:";
      #print LOGFILE "\n checkNopage:$dbname:$norecover_flag:";
      $npv=qq("ls -ltr ${norecover_path}/${dbname}.nopage.*" 2>/dev/null| tail -1| tr -s ' '|);
      $npv=$npv."/usr/local/bin/perl -ne '`date`;";
      $npv=$npv."chomp(\@b=split(/ /,\$_)); print \"\$b[5]:\$b[6]:\$b[7]:\$b[8]\"' ";
      $nopage_value=qx($SSH -qn ${remote_host} $sshopt $npv);

      if ( $nopage_value ){
      	 print " nopage_value=$nopage_value";
         print LOGFILE " nopage_value=$nopage_value";
         chomp(($mon,$dd,$hh,$mm,$ff) =split(/:/,$nopage_value));
         $nopage_value_time   = (split(/\./,$ff))[2];
         $nopage_value_sec = &convertTime($nopage_value_time) if ( $nopage_value );
         print "($nopage_value_sec)";
         print LOGFILE "($nopage_value_sec)";

         %month=('Jan',0,'Feb',1,'Mar',2,'Apr',3,'May',4,'Jun',5,
                 'Jul',6,'Aug',7,'Sep',8,'Oct',9,'Nov',10,'Dec',11);
         ($ssc,$mmc,$hhc,$ddc,$monc,$yyc) = (split(/:/,$cdate));

         $tdiff=timelocal($ssc,$mmc,$hhc,,$ddc,$monc-1,$yyc)-timelocal(1,$mm,$hh,$dd,$month{$mon},$yyc);
         print "\n time passed after refresh/manual DR stop=$tdiff sec";
         print LOGFILE "\n time passed after refresh/manual DR stop=$tdiff sec";
         if ( $tdiff < $nopage_value_sec ) {
              print "\n Ignore pages due to refresh/manual DR stop ...\n";
              print LOGFILE "\n Ignore pages due to refresh/manual DR stop ...\n";
              return "YES";
         }
        # remove file after 1hr sothat pages can go for sometime(1hr) for dbas to respond
         `$SSH -qn ${remote_host} $sshopt rm ${norecover_path}/${dbname}.nopage.* 2>/dev/null ` 
                        if($tdiff > ($nopage_value_sec+3600) );
      }
}

#-----------------------------------------------------------------------------
# convertSecToHrs:
#	Converts seconds to minutes/hrs for reporting purpose
#-----------------------------------------------------------------------------
sub convertSecToHrs(){
	my $sec = shift;
	my $time;
	if ( $sec/60 > 60 ) {
                $hrsa = floor( $sec/(60*60));
		$hrsb = ceil( ($sec-$hrsa*60*60)/60 ) ;
                #$hrsb = $sec % 60 ;
                $time = $hrsa."h".$hrsb."m";
	}
	else {
		if ( $sec > 60 ){
                  $mina = floor($sec/60);
                  $time = $mina."m";
		}
		else{
	        	$time=$sec."s";
		}
	}
	return($time);
}

#-----------------------------------------------------------------------------
# getMountFS :
#  - gets root mount filesystem for archive destination 
#  - this is put as seperate function inorder being called at 
#    multiple places .
#-----------------------------------------------------------------------------
sub getMountFS(){
	my $log_archive_dir_l = shift;
	my $mfs;
        open(DF, "$DF  $log_archive_dir_l $dfopt |") 
			|| &showError("$pname:getMountFS:Cannot do $DF $log_archive_dir_l $dfopt $!");
        while(<DF>){
                ($total = <DF>) || &showError("$pname:getMountFS:can't read total. $!");
                @data = split(' ',$total);
                shift(@data) if( $#data == 5);
                $mfs=$data[4];
        }
	return($mfs);
}

#-----------------------------------------------------------------------------
# getArchTimeFromHost :
#  - gets lag times from archivelogs available from server
#    in case the info is not available in v$archived_logs
#-----------------------------------------------------------------------------
sub getArchTimeFromHost()
{
        print "-";
        print LOGFILE "-";
        my ( $instance_l,$current_seq,$arch_seq) = @_;
        my $current_archfile= &findArchFile($instance_l,$current_seq);
        my $archfile        = &findArchFile($instance_l,$arch_seq);                     

        &Stat("${current_archfile}");
        $current_archfile_s = $st_mtime;
        &Stat("${archfile}");
        $archfile_s = $st_mtime;

        $archfile_s = &getArchTimeFromDRhost($instance_l,$arch_seq ) if ( ! $archfile_s );
        &showError("$pname:getArchTimeFromHost:Unable to get info about archseq $arch_seq",$instance_l)
        if ( ! $archfile_s ) ;

        $archlag_sec   = $current_archfile_s - $archfile_s ;                  
        return($archlag_sec);
}

#-----------------------------------------------------------------------------
# getArchTimeFromDRhost :
#  gets arch times from archivelogs available from DR server
#  in case the info is not available in v$archived_logs and on prod host
#-----------------------------------------------------------------------------
sub getArchTimeFromDRhost(){
    #print "\ngetArchTimeFromDRhost:";
    #print LOGFILE "\ngetArchTimeFromDRhost:";
    my ( $instance_l,$arch_seq) = @_;
    my $archfile_s;
    my $drarchfile_info;

    my $ssh_script = qq("ls -ltr $drinfo_arr{$instance_l}{dr_log_archive_dest}*$arch_seq*"|  tail -1| tr -s ' '|);
    $ssh_script = $ssh_script."/usr/local/bin/perl -ne 'chomp(\@b=split(/ /,\$_)); print \"\$b[5]:\$b[6]:\$b[7]:\$b[8]\"' ";
    chomp($drarchfile_info=qx($SSH -qn ${remote_host} $sshopt $ssh_script)) ;
    #print "\n drarchfile_info=$drarchfile_info";

    if (  $drarchfile_info ){
       chomp(($mon,$dd,$hh,$mm,$ff) =split(/:/,$drarchfile_info));
       #print "\n == $mon,$dd,$hh,$mm,$ff ";

       my  %month=('Jan',0,'Feb',1,'Mar',2,'Apr',3,'May',4,'Jun',5,
                   'Jul',6,'Aug',7,'Sep',8,'Oct',9,'Nov',10,'Dec',11);
       my ($ssc,$mmc,$hhc,$ddc,$monc,$yyc) = (split(/:/,$cdate));
       $archfile_s=timelocal(1,$mm,$hh,$dd,$month{$mon},$yyc);
       #print "\n archfile_s=$archfile_s==\n";
   }
   return($archfile_s);
}


#-----------------------------------------------------------------------------
# checkDRhealth ;
#  - just wrapper to make code easy readable.
#  - If DR exists do switch log and 
#    find sync_arch lag and dr applied log lag 
#  - this is as seperate function to make code easy reading and handling
#    at main fnc .
#-----------------------------------------------------------------------------
sub checkDRhealth()
{
        #------------ DR and log Option in PROD ------------------------------#
	# do not check DR if option = nodrmonitor
	return("NO") if ( lc($opt_O) eq "nodrmonitor");
        foreach  $instance_l ( keys %dbinfo_arr ) {
           if(  $isdrhost_f eq "NO"             &&
                $drexists_f{$instance_l} eq "YES" )
           {  
                 &setOraclehome($instance_l)   ;
                 &switchOracleLog($instance_l) ;
                 &getDbParameters($instance_l) ;
                 &getDRLogLag($instance_l)     ;
           }
        }
	return("YES");
}

#-----------------------------------------------------------------------------
# switchArchDestOnly:
#  wrapper sub module to provide swicth Archive dest functioanlity alone.
#  This function is same as old script sad.pl
#  The upper threshold for switching archive dest is got from cron exception
#-----------------------------------------------------------------------------
sub switchArchDestOnly()
{
   print "\nswitchArchDestOnly:$instance:";
   print LOGFILE "\nswitchArchDestOnly:$instance:";
   my $logdate_l=qx(date +'[%T]');chomp($logdate_l);
   print $logdate_l; print LOGFILE $logdate_l;
   foreach $mfs ( keys %mountfs){
     $archive_file_sys=$mountfs{$mfs};
     next if ( ! defined($archive_file_sys ) );
     my $archive_file_dir=(split(' ',$archive_file_sys))[0];
     print "\n archive_file_dir         = $archive_file_dir";
     print LOGFILE "\n archive_file_dir         = $archive_file_dir";

     &getParameters($mfs);
     print "\n Parameters               = $mfs:$pct_lower_limit:";
     print LOGFILE "\n Parameters               = $mfs:$pct_lower_limit:";
     print "$pct_upper_limit:$archive_retain_time:$mailto:$pageto";

     my $pct_used = &getUsedSpace($archive_file_dir);
     print "\n current %usage           = $pct_used% ";
     print LOGFILE "\n current %usage           = $pct_used% ";

    if ( $pct_used > $pct_upper_limit -1 ){
	&switchArchDest($instance);
    }
    else{
	print "\n ARCHIVE Destination NOT changed\n";
	print LOGFILE "\n ARCHIVE Destination NOT changed\n";
    }
  }
}

#-----------------------------------------------------------------------------
# findDupLogs:
#  - finds duplicate sequences/archive logs if any on a 
#    multi archive dest envs., 
#  - This is fired only if isSwitch = YES ie., when multiple archive 
#    dest specfied for a sad functionality
#-----------------------------------------------------------------------------
sub findDupLogs(){
  my $log_archive_dir ;
  my %archdir ;
  my $instance_node;
  #print "\n findDupLogs:$instance_l:";

  foreach $instance_l ( keys %dbinfo_arr ){
    %got="";
    if( $dbinfo_arr{$instance_l}{connected} eq "Y" and
        &isSwitch($instance_l)  eq "YES" ) {
        $log_archive_dir = $dbinfo_arr{$instance_l}{log_archive_dir};
        $log_archive_dir    =~s/[0-9]+/*[0-9]/g;
        for $dir (<${log_archive_dir}>) {
          for $_ (<$dir/*>) {
            #if( /${archformat}[\.gz]*$/ ){
            if( /${archformat}.gz$/ ){
              $curr_archfile = $_;
              $curr_archdir  = $1;
              $thread        = $4;
              $instance_node = $3;
	      $node_thread="${instance_node}_${thread}";

              if($got{$node_thread} and $curr_archdir ne $prev_archdir{$node_thread}){
                print "\nfindDupLogs:$instance_l:" if (! defined($pflag)) ;
                print LOGFILE "\nfindDupLogs:$instance_l:" if (! defined($pflag)) ;
                print "\n Found dup archive logs for threads:$thread";
                print LOGFILE "\n Found dup archive logs for threads:$thread";
                $curr_archsize = (stat($curr_archfile))[7];
                $prev_archsize = (stat($prev_archfile{$node_thread}))[7] ;
                print "\n  $curr_archfile(size-$curr_archsize) ";
                print LOGFILE "\n  $curr_archfile(size-$curr_archsize) ";
                print "\n  $prev_archfile{$node_thread}:(size-$prev_archsize)";
                print LOGFILE "\n  $prev_archfile{$node_thread}:(size-$prev_archsize)";
                $pflag = 1;
                if ( $curr_archsize  < $prev_archsize ){
                    print "\n  renaming... $curr_archfile ";
                    print LOGFILE "\n  renaming... $curr_archfile ";
                    rename($curr_archfile,$curr_archfile.'.dup') if (&isOpen("${curr_archfile}") =~ /no/);
                }
                else{
                    print "\n  renaming... $prev_archfile{$node_thread}";
                    print LOGFILE "\n  renaming... $prev_archfile{$node_thread}";
                    rename($prev_archfile{$node_thread},$prev_archfile{$node_thread}.'.dup')  if ( &isOpen("$prev_archfile{$node_thread}") =~ /no/) ;
                }
               }
              push(@duplogs, $node_thread)
                        if($got{$node_thread} and $curr_archdir ne $prev_archdir{$node_thread});
              $prev_archdir{$node_thread}  = $curr_archdir;
              $prev_archfile{$node_thread} = $curr_archfile;
              $got{$node_thread}           = 1;
            }
          }
        }
    }
 }
 print "\n";
 print LOGFILE "\n";
}

#-----------------------------------------------------------------------------
# logRotation:
#  - takes copy of log in /var/tmp and keeps logs for 
#    MAXLOGCYCLE no. of days
#-----------------------------------------------------------------------------
sub logRotation(){

        $ldate  = (localtime((stat("$logfile"))[9]))[3];
        $ndate  = (localtime(time))[3];

        if ( $ldate != $ndate ){
           for (my $o=$MAXLOGCYCLE-2,$n=$MAXLOGCYCLE-1; $o >=0; $o--,$n--){
                $old=$o?"$logfile.$o":$logfile ; $new="$logfile.$n";
                `$GZIP $old` if ( -e $old );
                `$GZIP $new` if ( -e $new );
                rename "$old.gz","$new.gz" if ( -e "$old.gz" );
           }
        }
}

#-----------------------------------------------------------------------------
# checkNodrhost:
#  - This function takes care of alerts during know issues of with drhosts,
#    in case drhost is down for known time , we could stop DR alerts by
#    creating below flag ,
#	prodhost:$FLAG_DIR/SID.nodrhost.2h
#  - By default script itself touches a 2hr flag and ignores alerts in case
#    of drhost is unavailable momentarily .
#-----------------------------------------------------------------------------
sub checkNodrhost(){
        my $instance_l       = shift ;
        my $nodrhost_noalert = 'N';
        chomp($nodrhost_f=`ls -1tr $FLAG_DIR/$instance_l.nodrhost.* 2>/dev/null| tail -1 `);
        if ( not $nodrhost_f ){
                return($nodrhost_noalert);
        }

        $nodrhost_v = (split(/\./,$nodrhost_f))[2];
        if ($nodrhost_v =~/blackout/i){
            print "\n\n WARNING!!Found the flag which indicates that there is no dr host available";
            print "\n          [$nodrhost_f]";
            print "\n          This script will be run as if there is no DR configured and the flag";
            print "\n          will be invalidated after 24h";
            $nodrhost_v=qq(24h);
            $drexists_f{$instance}             = "NO";
            $dbinfo_arr{$instance}{isDataguard}= "NO";
        }

        &Stat("$nodrhost_f");
        $nodrhost_fs = $st_mtime;
        $nodrhost_vs = &convertTime($nodrhost_v);
        $diff = ( time - $nodrhost_fs );
        if ( $nodrhost_vs < (time - $nodrhost_fs) ){
                system("rm $FLAG_DIR/$instance_l.nodrhost.* 2>/dev/null" )
        }
        else{
                $nodrhost_noalert = 'Y';
        }
        return ( $nodrhost_noalert);
}

sub mysleep() {
        my ($sleept)=@_;
        $timeleft=alarm(0);
        sleep $sleept;
        $timeleft= $timeleft - $sleept if ( $timeleft > $sleept );
        alarm($timeleft);
}

#-----------------------------------------------------------------------------
# exitProgram:
#  - exit program gracefully .
#  - removes lock file and also updates logfile 
#-----------------------------------------------------------------------------
sub exitProgram($){
        &Lock::unlock("${lockfile}");
        print "\n$pname: End : ",&ctime(time),"\n";
        print LOGFILE "\n$pname: End : ",&ctime(time),"\n";
        close(LOGFILE);
	exit(shift);
}

#-----------------------------------------------------------------------------
# showError :
#  - sends alert/warning  on all errors captured .
#    one exit path for all page alerts
#  - try your best to  maintain this function at the end of this prg for 
#    easy reading 
#-----------------------------------------------------------------------------
sub showError
{
        my ($errmsg,$instance_l,$exit_status,$page_flag,$email_flag) = @_;
        $instance_l = $instance if( ! defined($instance_l) );
        $instance_l = "" if( $instance_l eq "NONE" );
        $page_flag  = "Y" if ( $page_flag eq "" );
        $email_flag = "Y" if ( $email_flag eq "" );
        #$errmsg     = &msgfmt("w","$local_host","$instance_l","$errmsg");
        $errmsg     =qq(ARCHUTL:).qq($local_host $instance_l $errmsg);
        print "\n $errmsg";
        print LOGFILE "\n $errmsg";
	&getDbParameters($instance_l) if ( $mailto eq "");

	#$mailto=$pageto="raraveet"; #for TESTing
        &mailit("$errmsg","/dev/null") if ( $email_flag eq "Y" );
        &pageit($errmsg) if ( $page_flag eq "Y" ) ;
        if ( $exit_status == 1 ){
                print "\n PProgram terminated ";
                print LOGFILE "\n PProgram terminated ";
                exit(1);
        }
}

#-----------------------------------------------------------------------------
# purgeNextArchive :
#  - This sub module executes ONLY if database has multiple archive destination
#  - tries to purge the next available archive destination and keep it 
#    ready in case Switch archive destination occurs(sad)
#-----------------------------------------------------------------------------
sub purgeNextArchive(){
  return if( !( $instanceI ne "ALL" and  
                &isSwitch($instance_l) eq "YES" and
                $dbinfo_arr{$instanceI}{connected} eq "Y" 
               )
           ) ;

  print "\npurgeNextArchive:";
  print LOGFILE "\n purgeNextArchive:";
 ($next_log_archive_dest,$next_log_archive_dir)
                                   = &getNewArchDest($dbname,$dbinfo_arr{$dbname}{log_archive_dir});
   $curr_mfs			   = &getMountFS($dbinfo_arr{$dbname}{log_archive_dir});
   $next_mfs                       = &getMountFS("$next_log_archive_dir");
   $next_mountfs{$next_mfs}       .= $next_log_archive_dir;
   $dbinfo_arr{$dbname}{next_mfs}  = $next_mfs ;

  foreach $mfs ( keys %next_mountfs){
    $archive_file_sys=$next_mountfs{$mfs};
    next if ( ! defined($archive_file_sys ) );
    $archive_file_dir=(split(' ',$archive_file_sys))[0];
    $archive_file_dir =~ s/\*//;
    print "\n mount filesystem         = $mfs";
    print LOGFILE "\n mount filesystem         = $mfs";
    print "\n archive_file_sys         = $archive_file_dir";
    print LOGFILE "\n archive_file_sys         = $archive_file_dir";

    &getParameters($curr_mfs);
    $pct_upper_limit  = $pct_upper_limit-10 if ($pct_upper_limit >20);
    $pct_lower_limit = 20;
    print "\n  Parameters              = $mfs:$pct_lower_limit:";
    print LOGFILE "\n  Parameters              = $mfs:$pct_lower_limit:";
    print "$pct_upper_limit:$archive_retain_time:$mailto:$pageto";
    print LOGFILE "$pct_upper_limit:$archive_retain_time:$mailto:$pageto";
    $pct_used = &getUsedSpace($archive_file_dir);
    print "\n  Before purge:pct_used   = $pct_used% ";
    print LOGFILE "\n  Before purge:pct_used   = $pct_used% ";
    print "\n";
    print LOGFILE "\n";

    if ($pct_used >= $pct_upper_limit - 2)
    {
      open(PURGEFILES, "find ${archive_file_sys} -follow -name \"*dbf*\" |")
                        || &showError("$pname:Cannot open archive files. $!");;
      chomp(@pfiles=<PURGEFILES>);
      @spfiles=(map{$_->[0]} sort{$a->[1]<=>$b->[1]} map{[$_,(stat $_)[9]]} @pfiles);
      foreach (@spfiles) {
         chomp($archfile=$_);
         ($db_log_archive_dir,$dbname) = $archfile =~ /${archformat}(.*)/ ;
         my $instance_l = $dbinfo_arr{$dbname}{instance};
         $archsuffix= ".gz";
         #$archsuffix= "" if ($dbinfo_arr{$instance_l}{isDataguard} eq "YES" );
         &getDbParameters($instance_l);
         $archsuffix= "(\.\*)" if ( $zipmode eq "DISABLE" );
         next if ( ! /${archformat}${archsuffix}$/ );

         &Stat("${archfile}");
         if ( (&checkDRApplied("${archfile}") eq "YES")  &&
             ( &checkTapeExists("${archfile}") eq "YES") &&
             ( &isOpen("${archfile}") =~ /no/)             )
         {
               if ($st_mtime >= (time - $ARCHIVE_RETAIN_SEC)){
                        $recentFiles{$dbname}=$db_log_archive_dir;
                }
                printf " (%10d)",$threadno if ( $threadno != $DEFAULT_THREAD) ;
                print LOGFILE "  ($threadno)" if ( $threadno != $DEFAULT_THREAD) ;
                print "  unlink:${archfile}:$pct_used %:";
                print LOGFILE "   unlink:${archfile}:$pct_used %:";
                print "\n";
                print LOGFILE "\n";
                unlink("${archfile}")
		 	  || print "$pname:Can't Unlink $_: $!" if (-e ${archfile});
                $dbinfo_arr{$instance_l}{purge_cnt}++;
                alarm($TIMEOUT);
                #print ".";
         }
         else {
                print "";
                print LOGFILE "";
                #print "\n No delete: ${archfile}";
         }

         $pct_used = &getUsedSpace($archive_file_dir);
         last if ($pct_used <= $pct_lower_limit);
        }
        close(PURGEFILES);
     }
     print "  After  purge:pct_used   = $pct_used% ";
     }

  foreach $db ( keys %dbinfo_arr ){
    if ( $dbinfo_arr{$db}{connected} eq "Y" ) {
       printf "\n No. of logs purged(%-8s) = %2d",$db, $dbinfo_arr{$db}{purge_cnt};
       printf LOGFILE "\n No. of logs purged(%-8s) = %2d",$db, $dbinfo_arr{$db}{purge_cnt};
    }
  }

}

sub getDBUniqueName()
{
	my $instance_l = shift;
	my $sqlstmt="SELECT 'DB_UNIQUE_NAME' name,DB_UNIQUE_NAME 
                     FROM   v\\\$archive_dest
	             WHERE  dest_id = 1";

	open(SQLDBA, "$oracle_home/bin/sqlplus /nolog << END
        connect /as sysdba
	set heading off
	set echo on
        $sqlstmt ;
        exit
        END |") || &showError("$pname:getDBUniqueName:sqlplus error: $!",$instance_l,1);
        my @data = <SQLDBA>;

	my @data1;
        (@data1  = grep(/^DB_UNIQUE_NAME/, @data)) || &showError("$pname:Can't Find db_unique_name: @data",$instance_l,1);
        my $db_unique_name = (split(' ', $data1[0]))[1];
	return($db_unique_name);

}

sub chkDatabaseRole()
{
  my $thread_file=shift;
  if (-f "$thread_file"){
    my $sqlstmt="SELECT 'DATABASE_ROLE:'||database_role||':'
                FROM   v\\\$database";
    open(SQLDBA, "$oracle_home/bin/sqlplus /nolog << END
    connect /as sysdba
    set heading off
    set echo on
    $sqlstmt ;
    exit
    END |") ;
    my @data = <SQLDBA>;

    my @data1;
    (@data1  = grep(/^DATABASE_ROLE/,@data));
    my $database_role=(split(/:/ , $data1[0]))[1];
   if ($database_role eq "PRIMARY"){
       qx(mv ${thread_file} ${thread_file}.not_needed_in_prod);
   }
  }
}
                                                          

sub checkArchDestInSync(){
  my $instance_l=shift;
  my $init_ora =qq($ENV{ORACLE_HOME}/dbs/init${instance_l}.ora);
  my $log_archive_dest_from_init;
  my $db_log_archive_dir   =$dbinfo_arr{$instance_l}{log_archive_dir};
  my $db_log_archive_dest  =$dbinfo_arr{$instance_l}{log_archive_dest};

  open(ORA, "$init_ora") || &showError("$pname:Cannot open $init_ora  file. $!",$instance_l);
  while (<ORA>) {
    if (/log_archive_dest[_1]*\b/i and !/^#/){
        s/\s+//g;s/['"]//g;
        #TEST
        #s/fs01/fs03/;
        $log_archive_dest_from_init  = $_;
        if ( lc($log_archive_dest_from_init  ) =~/log_archive_dest_1/ ) {
             $log_archive_dest_from_init  = (split('=', $log_archive_dest_from_init))[2];
             $log_archive_dest_from_init  = (split(' ', $log_archive_dest_from_init))[0];
        }
        else{
          $log_archive_dest_from_init  = (split('=', $log_archive_dest_from_init  ))[1];
        }
        if($log_archive_dest_from_init !~ /$db_log_archive_dir/){
           print "\n\n Error!!log_archive_dest in init${instance_l}.ora is not same as set in database";
           print "\n          in database=[$db_log_archive_dest]";
           print "\n          in init.ora=[$log_archive_dest_from_init]";
           print LOGFILE "\n\n Error!!log_archive_dest in init${instance_l}.ora is not same as set in database";
           print LOGFILE "\n          in database=[${db_log_archive_dest}]";
           print LOGFILE "\n          in init.ora=[$log_archive_dest_from_init]";
           &showError("$pname:log_archive_dest parameter in init.ora is not same as set in database");
        }
    }
  }
}

sub checkProcessProgress(){
  my $instance_l = shift;
  chomp(my $scriptProgress_f =`ls -1tr $FLAG_DIR/$instance_l.wip.* 2>/dev/null| tail -1 `);
  if (!-f "$scriptProgress_f"){
      print "\ntouch $FLAG_DIR/$instance_l.wip.30m";
      system("touch $FLAG_DIR/$instance_l.wip.30m");
  }
  else{
  print "\n found [$scriptProgress_f]";
  $scriptProgress_v = (split(/\./,$scriptProgress_f))[2];

  &Stat("$scriptProgress_f");
  $scriptProgress_fs = $st_mtime;
  $scriptProgress_vs = &convertTime($scriptProgress_v);
  $diff = ( time - $scriptProgress_fs );
  if ( $scriptProgress_vs < (time - $scriptProgress_fs) ){
      system("rm $FLAG_DIR/$instance_l.wip.* 2>/dev/null" );
      system("touch $FLAG_DIR/$instance_l.wip.30m");
      #very hard coding required here
      $mailto=$pageto="db-monitor-duty";
      &showError("$pname:this script is running long, please check log");
  }
  else{
    print "\n no issues, previous process still running good";
  }
  }
  exit 1;
}
                                               
