#!/usr/local/bin/perl
#===============================================================================
# SCCS INFO : smartclone.pl [1.135] 09/18/06 11:42:45
# CREATED   : ckarthik
# DATE      : 04/27/2004
# DESC      : 11i Cloining Script
#===============================================================================
# Description						     Version Bef. Modfiy
#-------------------------------------------------------------------------------
#
#===============================================================================

#require "ctime.pl"   ;
use      Getopt::Std  ;
use      Time::Local  ;
use      File::stat   ;
select(STDERR); $| = 1;
select(STDOUT); $| = 1;

$DbEnvOk       = "N"  ;
$AppsEnvOk     = "N"  ;
$NotAllowed    = 0 ;
chomp($Machine = `uname -n`)                   ;
chomp($Os      = uc(`uname`))                  ;
$Home          = $ENV{'HOME'}                  ;
chomp($Owner   = `whoami` )                    ;
$DBSID         = $ENV{'ORACLE_SID'}            ;
#$Sid           = substr($Owner,2)             ;
$Banner        = $Sid                          ;
$Banner        = $DBSID if ($Owner eq "oracle");
$Dbh           = ""                            ;
$NotHere       = 0                             ;
$WhereIam      = ""                            ;
$Debug         = 0                             ;
getopt('d');
$Debug         = 1 if ($opt_d eq "1");
$Skip          = 0;

system("clear screen");
&Main_Menu;
exit 0;

#**************
# SUB Main_Menu 
#**************
sub Main_Menu {
    $NotHere = 0;
    &Screen_Scroll;

    print "\n\t\t\t\tMain Menu - ($Banner)"             ;
    print "\n\t\t\t\t==============================\n\n";
    print "\t\t\t\t1. Database task\n"                  ;
    print "\t\t\t\t2. Application task\n\n"             ;
    print "\t\t\t\tEnter your choice (ENTER to exit): " ;
    chomp($OptM = <STDIN>);
    print "\n\n";

    if    ($OptM == 1) { &Menu_Database ;}
    #CCK elsif ($OptM == 2) { &Menu_Application ;}
    elsif ($OptM == 2) { &Menu_Destination_App ;}
    else { 
       system("rm -f $Home/DBA/clone/.* 2>/dev/null");
       exit (0);
    }
}

#*****************
#SUB Menu_Database 
#*****************
sub Menu_Database {
    $NotHere = 0;
    @ToDoList = ();
    &Env_Database ;
    &Screen_Scroll;

    print "\n\t\t\t\tDatabase Menu - ($Banner)"                 ;
    print "\n\t\t\t\t==============================\n\n"        ;
    print "\t\t\t\t1. Pre refresh\n"                            ;
    print "\t\t\t\t2. Post refresh\n"                           ;
    print "\t\t\t\t3. OTHER tasks\n\n"                          ;
    print "\t\t\t\tEnter your choice (ENTER to previous menu): ";
    chomp($OptMD = <STDIN>);
    print "\n\n";

    &Main_Menu if ($OptMD eq "");

    if ($OptMD == 0) {  # TEST4
       &Get_Fnd_Table_List;
    } 
    elsif ($OptMD == 1) { 
       print "\t\t\t\tFollowing Tasks will be performed :-\n\n";
       print "\t\t\t\t* Create xpr_dba_users table\n";
       print "\t\t\t\t* Create xpr_fnd_user table\n";
       print "\t\t\t\t* Create xpr_fnd_oracle_userid table\n";
       print "\t\t\t\t* Create xpr_fnd_user_resp_group table\n";
       print "\t\t\t\t* Export Link\$, above tables and FND related tables with data\n";
       print "\n\n\t\t\t\tContinue?(Y/N) : ";
       chomp($QQ = <STDIN>);
       print "\n\n";

       &Opt_Db_Pre_Refresh if (uc("$QQ") eq "Y") ; 
    }
    elsif ($OptMD == 2) { 
       print "\t\t\t\tFollowing Tasks will be performed :-\n\n";
       print "\t\t\t\t* Importing 7 XPRE tables from dmp file\n";
       print "\t\t\t\t* Restoring FND_USER passwords\n";
       print "\t\t\t\t* Restoring FND_ORACLE_USERID passwords\n";
       print "\t\t\t\t* Restore DBA_USERS password\n";
       print "\t\t\t\t* Re-create the missing users\n";
       print "\n\n\t\t\t\tContinue?(Y/N) : ";
       chomp($QQ = <STDIN>);
       print "\n\n";

       &Opt_Db_Post_Refresh if (uc("$QQ") eq "Y") ; 
    }
    elsif ($OptMD == 3) { 
       print "\n\t\t\t\tOther Task Menu - ($Banner)";
       print "\n\t\t\t\t==============================\n\n";
       print "\t\t\t\t1.  Import the link\$\n";
       print "\t\t\t\t2.  Restore Dba_users password\n";
       print "\t\t\t\t3.  Restore Fnd_user passwords\n";
       print "\t\t\t\t4.  Restore Fnd_responsiblity\n";
       print "\t\t\t\t5.  Re-create missing Dba users\n";
       print "\t\t\t\t6.  Generate Db listener entry\n";
       print "\t\t\t\t7.  Setup cron job\n";
       print "\t\t\t\t8.  New Instance Setup\n";
       print "\t\t\t\t9.  Setup utl dir under /apps/orarpt for 11i Env\n";
       print "\t\t\t\t10. Cleanup Concurrent Nodes\n";
       print "\t\t\t\t11. Validate Before Release steps\n";
       print "\n\n\t\t\t\tEnter your choice (ENTER to previous menu): ";
       chomp($QQ = <STDIN>);
       print "\n\n";

       &Menu_Database if ($QQ eq "");

       if ($NotHere) {
          print "\t\t\t\tTHIS IS NOT DATABASE SERVER or Your are not ORACLE user!!! Can't Perform this task\n";
          $NotHere = 0; 
       }
       else {
          foreach $SN (split(',',$QQ)) {
             &Import_Tables('DBLINK') if ($SN == 1);
             &Restore_Dba_User_Pwds   if ($SN == 2);
             &Restore_Fnd_User_Pwds   if ($SN == 3);
             &Restore_Fnd_Resp        if ($SN == 4);
             &Add_Missing_Dba_User    if ($SN == 5);
             &Gen_Listener_Entry      if ($SN == 6);
             &Db_Cron_Jobs            if ($SN == 7);
             &New_Instance_Setup      if ($SN == 8);
             &Setup_Utl_For_11i       if ($SN == 9);
             &Cleanup_Conc_Node       if ($SN == 10);
             &Db_Before_Release       if ($SN == 11);
          }
       }
    }
    &Menu_Database;
}

#*******************
# Opt_Db_Pre_Refresh
#*******************
sub Opt_Db_Pre_Refresh {

    &Env_Database ;
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT DATABASE SERVE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }

    $RefDir = "/oracle/admin/$DBSID/refresh";
    system("mkdir -p $RefDir");
    print "Preserving information before refresh under $RefDir. \n\n";  

    &Create_Backup_Tables      ;
    &Export_Tables             ;

    print "\n";
}

#===================
# Get_Fnd_Table_List
#===================
sub Get_Fnd_Table_List {    

    $WhereIam = "Get_Fnd_Table_List";

    $St0 = qq{SELECT release_name FROM apps.fnd_product_groups};
    $Sh0 = $Dbh->prepare($St0) || die "\nPrep Faild [ $St0 ]\n",$Dbh->errstr;
    $Sh0->execute;

    (($Rn) = $Sh0->fetchrow_array) ;
    $AppsExists=1 if ($Rn ne "10.7.0" && ($Rn));
    $Sh0->finish;

    if ($AppsExists) {
        #CCK $St1 = qq{SELECT substr('XPR_'||table_name,1,30) FROM dba_tables WHERE owner IN ('SSOSDK', 'APPLSYS')
        #CCK           AND  table_name IN ('FND_USER', 'FND_ORACLE_USERID', 'FND_RESPONSIBILITY_TL', 
        #CCK                               'FND_USER_RESP_GROUPS','WWSEC_ENABLER_CONFIG_INFO\$')};

        $St1 = q{SELECT substr('XPR_'||object_name,1,30) FROM dba_objects WHERE owner IN ('SSOSDK','APPLSYS') 
                 AND  object_name IN ('FND_USER', 'FND_ORACLE_USERID', 'FND_RESPONSIBILITY_TL',
                                      'FND_USER_RESP_GROUPS','WWSEC_ENABLER_CONFIG_INFO$') and object_type='TABLE' };
        $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n",$Dbh->errstr;
        $Sh1->execute;

        while(($Tbl) = $Sh1->fetchrow_array) {
           push(@PreRefBackupTable, "$Tbl");
        }
        $Sh1->finish;
        push(@PreRefBackupTable, "PRE_REF_XX_FND_USER_RESP_GROUP");
        push(@PreRefBackupTable, "PRE_REF_XX_FND_USER");
    }
    &Debug_Now if ($Debug);
}

#=====================
# Create_Backup_Tables
#=====================
sub Create_Backup_Tables {    

    $WhereIam = "Create_Backup_Tables";
    &Print_Header("Creating Required Tables as part of Pre Refresh");

    $Dbh = &Connect_Db;

    &Get_Fnd_Table_List ;

    $St1 = qq{SELECT count(*) FROM dba_tables WHERE owner='OPS\$ORACLE' AND table_name=?};
    
    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;

    foreach $RefTname (@PreRefBackupTable ) {

       $OrgTname = $RefTname;
       $OrgTname =~ s/^XPR_//g;

       if (($OrgTname =~ /^XX_FND_/)) {
         &Print_Line("Creating $RefTname using custom query");
       }
       else {
         &Print_Line("Creating $RefTname, copy of $OrgTname");
       }
       $OrgTname = "APPLSYS.$OrgTname" if (($OrgTname =~ /^FND_/));
       $OrgTname = "SSOSDK.$OrgTname" if (($OrgTname =~ /^WWSEC_/));

       $Sh1->execute($RefTname);

       chomp($TExt = `date +\%d\%b\%H\%M\%S`);

       ($Cnt) = $Sh1->fetchrow_array;

       $Str = qq{DROP TABLE ops\$oracle.$RefTname};

       $Dbh->do($Str) || die "\nStmt Faild [ $Str ]\n",$Dbh->errstr if ("$Cnt" ne "0" ) ;

       if ($RefTname eq "PRE_REF_XX_FND_USER_RESP_GROUP") {

          $Str = qq{CREATE TABLE ops\$oracle.$RefTname (user_name varchar2(30),
                                    responsibility_name varchar2(120) , end_date date, start_date date,
                                    security_group_id number, description varchar2(1000))};
          $Dbh->do($Str) || die "\nStmt Faild [ $Str ]\n",$Dbh->errstr;
 
          $Str = qq{insert into ops\$oracle.$RefTname
                    SELECT a.user_name, b.responsibility_name, c.end_date, c.start_date,
                           c.security_group_id, nvl(c.description,'null') description
                    FROM   applsys.fnd_user a, applsys.fnd_responsibility_tl b, apps.fnd_user_resp_groups c
                    WHERE  c.user_id = a.user_id
                    AND    c.responsibility_id= b.responsibility_id
                    AND    c.responsibility_application_id = b.application_id};
       }
       elsif ($RefTname eq "PRE_REF_XX_FND_USER" ) {
          $Str = qq{CREATE TABLE ops\$oracle.$RefTname as 
                    SELECT user_name, start_date, end_date, last_logon_date, description,
                           password_lifespan_days, employee_id, email_address
                    FROM   applsys.fnd_user};
       }
       else {
          $Str ="CREATE TABLE ops\$oracle.$RefTname as select * from $OrgTname";
          #CCK $Dbh->do("CREATE TABLE ops\$oracle.$RefTname as select * from $OrgTname") || die $Dbh->errstr;
       }
       $Dbh->do($Str) || die "\nStmt Faild [ $Str ]\n",$Dbh->errstr;
       print " Done\n";
    }
    $Sh1->finish;
    $Dbh->disconnect  ;
    &Debug_Now if ($Debug);
    print "\n";
}

#==============
# Export_Tables
#==============
sub Export_Tables {    

    $WhereIam = "Export_Tables";
    $ExpTblList = "";

    foreach $RefTname (@PreRefBackupTable ) {
       $ExpTblList .= "OPS\\\$ORACLE.$RefTname," ;
    }

    $ExpTblList .= 'APPLSYS.WF_RESOURCES,'                     .
                   'APPLSYS.FND_RUN_REQUESTS,'                 .
                   'APPLSYS.FND_CONC_STAT_LIST,'               .
                   'APPLSYS.FND_RESPONSIBILITY,'               .
                   'APPLSYS.FND_CONC_PP_ACTIONS,'              .
                   'APPLSYS.FND_PROFILE_OPTIONS,'              .
                   'APPLSYS.FND_PROFILE_OPTIONS_TL,'           .
                   'APPLSYS.FND_CONCURRENT_QUEUES,'            .
                   'APPLSYS.FND_CONCURRENT_QUEUES_TL,'         .
                   'APPLSYS.FND_CONC_STAT_SUMMARY,'            .
                   'APPLSYS.FND_RUN_REQ_PP_ACTIONS,'           .
                   'APPLSYS.FND_CONCURRENT_REQUESTS,'          .
                   'APPLSYS.FND_CONCURRENT_PROCESSES,'         .
                   'APPLSYS.FND_CONC_RELEASE_CLASSES,'         .
                   'APPLSYS.FND_CONC_RELEASE_CLASSES_TL,'      .
                   'APPLSYS.FND_CONCURRENT_QUEUE_SIZE,'        .
                   'APPLSYS.FND_PROFILE_OPTION_VALUES,'        .
                   'APPLSYS.FND_CONC_REQUEST_ARGUMENTS,'       .
                   'APPLSYS.FND_CONCURRENT_QUEUE_CONTENT,'     if ($AppsExists);
    
    $ExpTblList .= 'SYS.LINK\$';

    system("rm ${RefDir}/${DBSID}_data.dmp 2>/dev/null");

    $Fname = "${RefDir}/${DBSID}_data";
    &Print_Line("Exporting tables to $Fname.dmp");
    &Get_Char_Set;

    open(EXP, "$ENV{'ORACLE_HOME'}/bin/exp userid=/ file=$Fname.dmp compress=n log=$Fname.exp.log tables=$ExpTblList 2>/dev/null |");

    $ErrMsg = "";
    while (<EXP>) {
       print;
       $ErrMsg = "$_\n" if ((/^EXP-/ || /^ORA-/) && (! /^EXP-00067/)) ;
    }

    close(EXP);

    die "Error in Export : $ErrMsg\n see the log file for me info $Fname.log" if ($ErrMsg);
    system("mv $Fname.dmp ${Fname}_$Ext.dmp");
    system("ln -s ${Fname}_$Ext.dmp $Fname.dmp");
    print " Done\n";
    print "\n     !!!!! Verify the export log $Fname.exp.log !!!!!\n\n";
    &Debug_Now if ($Debug);
}

#********************
# Add_Missing_Dba_User
#********************
sub Add_Missing_Dba_User {

    &Env_Database ;
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT DATABASE SERVE!!! Can't Perform this task\n";
       return;
       $NotHere = 0; 
    }

    $RefDir = "/oracle/admin/$DBSID/refresh";

    &Import_Tables('NODBLINK')  ;
    &Users_Creation ;
    print "\n";
}
#********************
# Opt_Db_Post_Refresh
#********************
sub Opt_Db_Post_Refresh {

    &Env_Database ;
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT DATABASE SERVE!!! Can't Perform this task\n";
       return;
       $NotHere = 0; 
    }


    $RefDir = "/oracle/admin/$DBSID/refresh";

    &Import_Tables('ALL')  ;
    &Restore_Db_Pwds;
    &Users_Creation ;

    if ($AppsExists) {
       &Restore_11i_Pwds    ;
       &Add_Missing_Fnd_User;
       &Add_Missing_Fnd_Resp;
    }
    print "\n";
}

#*****************
# Restore_Fnd_Resp
#*****************
sub Restore_Fnd_Resp {

    &Env_Database ;
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT DATABASE SERVE!!! Can't Perform this task\n";
       return;
       $NotHere = 0; 
    }

    $RefDir = "/oracle/admin/$DBSID/refresh";

    &Import_Tables('NODBLINK')  ;
    &Add_Missing_Fnd_Resp if ($AppsExists) ;

    print "\n";
}
#**********************
# Restore_Fnd_User_Pwds
#**********************
sub Restore_Fnd_User_Pwds {

    &Env_Database ;
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT DATABASE SERVE!!! Can't Perform this task\n";
       return;
       $NotHere = 0; 
    }

    $RefDir = "/oracle/admin/$DBSID/refresh";

    &Import_Tables('NODBLINK')  ;
    &Add_Missing_Fnd_User if ($AppsExists) ;

    print "\n";
}

#**********************
# Restore_Dba_User_Pwds
#**********************
sub Restore_Dba_User_Pwds {

    &Env_Database ;
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT DATABASE SERVE!!! Can't Perform this task\n";
       return;
       $NotHere = 0; 
    }

    $RefDir = "/oracle/admin/$DBSID/refresh";

    &Import_Tables('NODBLINK')  ;
    &Restore_Db_Pwds;
    &Restore_11i_Pwds if ($AppsExists) ;
    print "\n";
}

#==============
# Import_Tables
#==============
sub Import_Tables {    

    $What2Import  = $_[0];
    $What2Import  = 'ALL' if (! $What2Import);

    $RefDir = "/oracle/admin/$DBSID/refresh";

    $WhereIam = "Import_Tables";

    $Fname = "${RefDir}/${DBSID}_data";
    &Print_Header("Building 7 pre_ref tables using $Fname.dmp");

    die " Not exists\n" if (!(-f "$Fname.dmp"));
    $Dbh = &Connect_Db("","","");

    &Get_Fnd_Table_List  ;
    foreach $RefTname (@PreRefBackupTable ) {
       $ImpTblList .= "$RefTname," ;
    }
    $ImpUser   = 'OPS\$ORACLE' ;

    if ( $What2Import eq 'DBLINK' || $What2Import eq 'ALL') {

       $ImpTblList .= 'LINK\$' ;
       $ImpUser   .= ',SYS' ;

       chomp($TExt = `date +\%d\%b\%H\%M\%S`);
       &Print_Line("Creating backup table SYS.LINK\$_${TExt}");
       $Dbh->do(qq{Create table SYS.LINK\$_${TExt} as select * from sys.LINK\$});
       print " Done\n\n";

       &Print_Line("Truncating table SYS.LINK\$");
       $Dbh->do('TRUNCATE TABLE SYS.LINK$'); 
       print " Done\n";
    }


    foreach $iTbl (@PreRefBackupTable ) {
        &Print_Line("Truncating table OPS\$ORACLE.$iTbl");
        $Dbh->do("TRUNCATE TABLE ops\$oracle.$iTbl"); 
        print " Done\n";
    }

    $Dbh->disconnect;
    print "\n";

    &Get_Char_Set("","","");

    &Print_Line("Importing data to the above truncated tables");
    open(IMP, "$ENV{'ORACLE_HOME'}/bin/imp userid=/ file=$Fname.dmp fromuser=$ImpUser, tables=$ImpTblList full=n ignore=y log=$Fname.imp.log grants=n indexes=n constraints=n 2>/dev/null|");

    $ImpErrMsg = "";
    while (<IMP>) {
       print;
       $ImpErrMsg = "$_\n" if (/^IMP-/ || /^ORA-/) ;
    }
    close(IMP);

    die "Error in Import : $ImpErrMsg\n\nSee log file $Fname.imp.log" if ("$ImpErrMsg");

    print " Done\n\n";

    &Debug_Now if ($Debug);
}

#=============
# Get_Char_Set
#=============
sub Get_Char_Set {    

    $WhereIam = "Get_Char_Set";
    $Dbh = &Connect_Db;
    #CCK $St1 = q{SELECT VALUE$ FROM sys.props$ WHERE name = 'NLS_CHARACTERSET'};
    $St1 = q{ select value from V$NLS_PARAMETERS where parameter = 'NLS_CHARACTERSET'};
    $Sh1 = $Dbh->prepare($St1) || die "Prep Failed [$St1]\n",$Dbh->errstr;
    $Sh1->execute;
    ($CharSet) = $Sh1->fetchrow_array;
    $Sh1->finish;
    die "Unable to set Char Set to $CharSet\n" if (!($CharSet));
    $ENV{NLS_LANG} = "American_America.$CharSet";
    $Dbh->disconnect;
    &Debug_Now if ($Debug);
}

#=================
# Restore_11i_Pwds
#=================
sub Restore_11i_Pwds {

    $WhereIam = "Restore_11i_Pwds";
    chomp($TExt = `date +\%d\%b\%H\%M\%S`);
    &Print_Header("Restoring the FND_USER and FND_ORACLE_USERID Passwords");

    $Dbh = &Connect_Db;

    $DoStmt = q{analyze table ops$oracle.pre_ref_xx_fnd_user_resp_group compute statistics};
    $Dbh->do($DoStmt) || die "\nStmt Faild [ $DoStmt ]\n", $Dbh->errstr;
    $DoStmt = q{analyze table ops$oracle.pre_ref_xx_fnd_user compute statistics};
    $Dbh->do($DoStmt) || die "\nStmt Faild [ $DoStmt ]\n", $Dbh->errstr;

    &Backup_Tables("apps.fnd_user","fnd_user_$TExt");

    #CCK &Print_Line("Creating backup table OPS\$ORACLE.FND_USER_${TExt}");
    #CCK $Dbh->do(qq{Create table ops\$oracle.fnd_user_${TExt} as select * from apps.fnd_user});
    #CCK print " Done\n";

    #---------------------------------------------------
    # Create Index on XPR_FND_USER for Faster update
    #---------------------------------------------------
    &Print_Line("Creating unique index on XPR_FND_USER(USER_NAME)");

    $St1 = q{SELECT count(*) FROM dba_indexes where index_name = 'XPR_FND_USER_U1' and owner = 'OPS$ORACLE'};

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    ($ExistNdx) = $Sh1->fetchrow_array;
    $Sh1->finish;

    if ($ExistNdx) { 
       $DoStmt= q{DROP INDEX ops$oracle.xpr_fnd_user_u1 };
       $Row   = $Dbh->do($DoStmt) || die "\nStmt Faild [ $DoStmt ]\n", $Dbh->errstr;
       print " Done\n";
    }

    $DoStmt= q{CREATE UNIQUE INDEX ops$oracle.xpr_fnd_user_u1 ON ops$oracle.xpr_fnd_user(user_name)}; 
    $Row   = $Dbh->do($DoStmt) || die "\nStmt Faild [ $DoStmt ]\n", $Dbh->errstr;
    print " Done\n";
          
    #-------------------------------------
    # Update FND_USER for possword columns
    #-------------------------------------

    &Print_Line("Updating password fields in FND_USER...(may take sometime)");
    $DoStmt= q{UPDATE applsys.fnd_user d
                SET   (d.encrypted_foundation_password,d.encrypted_user_password) =
                      (SELECT p.encrypted_foundation_password,p.encrypted_user_password
                       FROM   ops$oracle.xpr_fnd_user p
                       WHERE  p.user_name = d.user_name )
                WHERE  d.user_name IN (SELECT e.user_name 
                                       FROM   ops$oracle.xpr_fnd_user e)};

    $Row   = $Dbh->do($DoStmt) || die "\nStmt Faild [ $DoStmt ]\n", $Dbh->errstr;

    print " $Row Row Updated\n\n";

    #----------------------------------------------
    # Update FND_ORACLE_USERID for possword columns
    #----------------------------------------------
    &Backup_Tables("applsys.fnd_oracle_userid","fnd_oracle_userid_${TExt}");

    &Print_Line("Updating Passwords in FND_ORACLE_USERID...(may take sometime)");
    $DoStmt = q{UPDATE applsys.fnd_oracle_userid d
                SET    d.encrypted_oracle_password = (SELECT p.encrypted_oracle_password
                                                      FROM   ops$oracle.xpr_fnd_oracle_userid p
                                                      WHERE  p.oracle_username = d.oracle_username )
                WHERE d.oracle_username IN (SELECT e.oracle_username 
                                            FROM   ops$oracle.xpr_fnd_oracle_userid e)};

    $Row   = $Dbh->do($DoStmt) || die "\nStmt Faild [ $DoStmt ]\n", $Dbh->errstr;
    print " $Row Row Updated\n\n";

    #-----------------------------------------------------
    # Update FND_USER_RESP_GROUPS for sync end_date column
    #-----------------------------------------------------
    #CCK &Print_Line("Creating backup table ops\$oracle.fnd_user_resp_groups_${TExt}");
    #CCK $Dbh->do(qq{Create table ops\$oracle.fnd_user_resp_groups_${TExt} as select * from apps.fnd_user_resp_groups});
    #CCK print " Done\n";
    
    #CCK &Print_Line("Updating Passwords in FND_USER_RESP_GROUPS");
    #CCK $Row = $Dbh->do(q{UPDATE applsys.fnd_user_resp_groups d
    #CCK                   SET    d.end_date = (SELECT p.end_date
    #CCK                                        FROM   ops$oracle.xpr_fnd_user_resp_groups p
    #CCK                                        WHERE  p.user_id = d.user_id )
    #CCK                   WHERE d.user_id IN (SELECT  e.user_id 
    #CCK                                       FROM  ops$oracle.xpr_fnd_user_resp_groups e)}) || die $Dbh->errstr;
    #CCK print " $Row Row Updated\n\n";

}

#================
# Restore_Db_Pwds
#================
sub Restore_Db_Pwds { 

    $WhereIam = "Restore_Db_Pwds";
    chomp($TExt = `date +\%d\%b\%H\%M\%S`);
    &Print_Header("Restoring DB Passwords");

    $Dbh = &Connect_Db;

    #-----------------------------------------
    # Alter DBA_USERS with old password values
    #-----------------------------------------
    &Backup_Tables("dba_users","dba_users_${TExt}");

    #CCK &Print_Line("Creating backup table OPS\$ORACLE.DBA_USERS_${TExt}");
    #CCK $Dbh->do(qq{Create table ops\$oracle.dba_users_${TExt} as select * from dba_users});
    #CCK print " Done\n";
    
    &Print_Line("Updating Passwords in DBA_USERS");
    $St1 = q{SELECT username, password FROM ops$oracle.xpr_dba_users 
             WHERE  username IN (SELECT username FROM dba_users)};

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    $i = 0;
    #&Set_Password_Verification_Function("OFF");
    while(($AltUsr, $AltPwd) = $Sh1->fetchrow_array) {
       $i++;
       $DoStmt = qq{alter user $AltUsr identified by values '$AltPwd'};
       #CCK1 $Dbh->do(qq{alter user $AltUsr identified by values '$AltPwd'}) || die $Dbh->errstr;
       $Dbh->do($DoStmt) || die "\nStmt Faild [ $DoStmt ]\n",$Dbh->errstr;
    }
    #&Set_Password_Verification_Function("ON");

    $Sh1->finish;
    $Dbh->disconnect;
    print " $i Users altered\n\n";
    &Debug_Now if ($Debug);
}

#=======================
# Alter_Fnd_User_Trigger
#=======================
sub Alter_Fnd_User_Trigger {    

    ($What2Do) = @_;
    $WhereIam = "Alter_Fnd_User_Trigger";
    &Print_Header("Creating Missing Fnd Users");
    $Dbh = &Connect_Db;

    if ($What2Do eq "DISABLE") {
       $DoSt = q{CREATE table post_ref_xx_fnd_user_trig AS 
                 SELECT SELECT owner, trigger_name, status 
                 FROM   dba_triggers WHERE status = 'ENABLED'};
       #CCK1 $Dbh->do(q{CREATE table post_ref_xx_fnd_user_trig AS 
       #CCK1            SELECT SELECT owner, trigger_name, status 
       #CCK1            FROM   dba_triggers WHERE status = 'ENABLED'}) || die $Dbh->errstr;

       $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr; 

       $St1 = q{SELECT owner||'.'||trigger_name||' status is '||status
                FROM   dba_triggers where table_name = 'FND_USER' and status = 'ENABLED'};

       $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
       $Sh1->execute;
       while(($trig) = $Sh1->fetchrow_array) {
          &Print_Line("Trigger $trig");
          print " FYI\n";
       }
       $Sh1->finish;
    }
    $Dbh->disconnect;
}
#===============
# Users_Creation
#===============
sub Users_Creation {    

    $WhereIam = "Users_Creation";
    #-----------------------------------------
    # Create those users exists before refresh
    #-----------------------------------------
    &Print_Header("Creating Missing Users");
    $Dbh = &Connect_Db;

    $Fname = "/oracle/admin/$DBSID/clone/${DBSID}_create_missing_users.sql";
    open(FW, ">$Fname") || die "Cannot open new file $FName $!\n";

    $St0 = q{ SELECT 1 from  dba_tablespaces where UPPER(tablespace_name) = ? };
    $Sh0 = $Dbh->prepare($St0) || die "\nPrep Failed [$St0]\n", $Dbh->errstr;

    $St1 = q{ SELECT username, password, LOWER(default_tablespace), LOWER(temporary_tablespace)
              FROM   ops$oracle.xpr_dba_users
              WHERE  username NOT IN (SELECT username FROM sys.dba_users)
              ORDER  BY username };

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;

    $St2 = q{SELECT DECODE(max_bytes,-1,'UNLIMITED',max_bytes), LOWER(tablespace_name)
             FROM   ops$oracle.xpr_dba_ts_quotas WHERE upper(username) = ? };
    $Sh2 = $Dbh->prepare($St2) || die "\nPrep Faild [ $St2 ]\n", $Dbh->errstr;

    $St3 = q{SELECT LOWER(granted_role), DECODE(admin_option,'YES',' WITH ADMIN OPTION','')
             FROM   ops$oracle.xpr_dba_role_privs WHERE upper(grantee) = ? };

    $Sh3 = $Dbh->prepare($St3) || die "\nPrep Faild [ $St3 ]\n", $Dbh->errstr;

    $St4 = q{SELECT LOWER(privilege), DECODE(admin_option,'YES',' WITH ADMIN OPTION','')
             FROM   ops$oracle.xpr_dba_sys_privs WHERE upper(grantee) = ? };

    $Sh4 = $Dbh->prepare($St4) || die "\nPrep Faild [ $St4 ]\n", $Dbh->errstr;

    $j = 0;
    $m = 0;
    $MissingTS = "";
    #&Set_Password_Verification_Function("OFF");
    while(( $UName, $UPwd, $UDef, $UTmp ) = $Sh1->fetchrow_array) {
       $j++;
       &Print_Line("Creating user $UName which existed before refresh");
       $TsExists=0;
       $Sh0->execute(uc($UDef));
       (( $TsExists) = $Sh0->fetchrow_array) ;
     
       if ($TsExists) {
          
          $DoSt = qq{CREATE USER $UName IDENTIFIED BY VALUES '$UPwd' 
                    DEFAULT TABLESPACE $UDef TEMPORARY TABLESPACE $UTmp};
          #CCK1 $Dbh->do("CREATE USER $UName IDENTIFIED BY VALUES '$UPwd' 
          #CCK1           DEFAULT TABLESPACE $UDef TEMPORARY TABLESPACE $UTmp") || die $Dbh->errstr;
          $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr;
       }
       else {
          $m++;
       
          $MissingTS .= "$UDef,"  if (!(grep /$UDef/ ,$MissingTS));
          print FW "CREATE USER $UName IDENTIFIED BY VALUES '$UPwd' \n";
          print FW "DEFAULT TABLESPACE $UDef TEMPORARY TABLESPACE $UTmp;\n"; 
       }
         
       $Sh2->execute($UName);
       while(( $Quota, $Ts) = $Sh2->fetchrow_array) {
          if ($TsExists) {
             $DoSt = qq{ALTER USER $UName QUOTA $Quota ON $Ts}; 
             #CCK1 $Dbh->do("ALTER USER $UName QUOTA $Quota ON $Ts") || die $Dbh->errstr;
             $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr;
          }
          else {
             print FW "ALTER USER $UName QUOTA $Quota ON $Ts;\n";
          }
       }

       $Sh3->execute($UName);
       while(( $Role, $Admin) = $Sh3->fetchrow_array) {
          if ($TsExists) {
             $DoSt = qq{GRANT $Role TO $UName $Admin}; 
             #CCK1 $Dbh->do("GRANT $Role TO $UName $Admin") || die $Dbh->errstr;
             $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr;
          }
          else {
             print FW "GRANT $Role TO $UName $Admin;\n";
          }
       }

       $Sh4->execute($UName);
       while(( $Priv, $Admin) = $Sh4->fetchrow_array) {
          if ($TsExists) {
             $DoSt = qq{GRANT $Priv TO $UName $Admin};
             #CCK1 $Dbh->do("GRANT $Priv TO $UName $Admin") || die $Dbh->errstr;
             $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr;
          }
          else {
             print FW "GRANT $Priv TO $UName $Admin;\n\n\n";
          }
       }
       print " Done\n";
    }
    #&Set_Password_Verification_Function("ON");

    $Sh0->finish;
    $Sh1->finish;
    $Sh2->finish;
    $Sh3->finish;
    $Sh4->finish;
    $Dbh->disconnect;
    close(FW);
    if($m) {
       chop($MissingTS);
       print "\n";
       &Print_Info(uc($MissingTS)." tablespace MISSING(was Exists in $DBSID?), Create those and run following script");
       &Print_Info("$Fname to create $m users");
    }

    if (!($j)) {
       &Print_Line("No Additional user found, which existed before refresh");
       print " Done\n";
    }
    &Debug_Now if ($Debug);
}

#=====================
# Add_Missing_Fnd_User
#=====================
sub Add_Missing_Fnd_User{    

    $WhereIam = "Add_Missing_Fnd_User";
    #-----------------------------------------
    # Create those users exists before refresh
    #-----------------------------------------
    &Print_Header("Adding Missing Fnd Users");
    $Dbh = &Connect_Db;

    &Print_Line("Removing special char from description col of PRE_REF_XX_FND_USER");
    $Ust = q{update PRE_REF_XX_FND_USER set DESCRIPTION=replace(DESCRIPTION,'''','')};
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER set DESCRIPTION=replace(DESCRIPTION,'"','')};
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER set DESCRIPTION=replace(DESCRIPTION,'&','')};
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER set DESCRIPTION=replace(DESCRIPTION,'%','')};
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER set DESCRIPTION=replace(DESCRIPTION,'$','')};
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER set DESCRIPTION=replace(DESCRIPTION,'@','')};
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    print " Done\n";

    &Print_Line("Adding missing FND_USER ... (may take sometime)");                                              

    $St1 = q{ SELECT distinct 'fnd_user_pkg.createuser(x_user_name=>'''||x.user_name||''', x_owner=>'''''||
                     ', x_start_date =>TO_DATE('''||TO_CHAR(x.start_date,'DD-MON-YYYY HH24:MI:SS')|| 
                     ''',''DD-MON-YYYY HH24:MI:SS''), x_end_date => to_date('''||
                     TO_CHAR(x.end_date,'DD-MON-YYYY HH24:MI:SS')||
                     ''',''DD-MON-YYYY HH24:MI:SS''), x_last_logon_date => to_date('''||
                     TO_CHAR(x.last_logon_date,'DD-MON-YYYY HH24:MI:SS')||
                     ''',''DD-MON-YYYY HH24:MI:SS''), x_description => '''||x.description||
                     ''', x_password_lifespan_days=> TO_NUMBER('''||x.password_lifespan_days||
                     '''), x_employee_id=>to_number('''||x.employee_id||
                     '''), x_email_address=>'''||x.email_address||''')'
              FROM   pre_ref_xx_fnd_user x 
              WHERE  x.user_name IN (SELECT a.user_name FROM pre_ref_xx_fnd_user a 
                                     MINUS  select b.user_name FROM applsys.fnd_user b) };

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;

    $FName = "/tmp/${DBSID}_1_fnd_user_add";
    $FNameErr = "/tmp/${DBSID}_1_fnd_user_add_error";
    open(FW, ">${FName}.sql") || die "Cannot open new file ${FName}.sql $!\n";
    open(FWE, ">${FNameErr}.sql") || die "Cannot open new file ${FNameErr}.sql $!\n";

    $j = 0;
    while(( $AddUserStmt) = $Sh1->fetchrow_array) {
       if (++$j == 1 ) {
          $St1 = q{alter session set current_schema=APPS};
          $Row = $Dbh->do("$St1") || die "\nStmt Faild [ $St1 ]\n", $Dbh->errstr;
          print FWE "-----------------------------------------------------------------------------\n";
          print FWE "-- If any below add user statement appears, those are issue in adding.\n";
          print FWE "-- Connect as Apps and run manually and fix the issue.\n";
          print FWE "-- If a particular user is end dataed you can ignore those user add stmnt\n";
          print FWE "-----------------------------------------------------------------------------\n";
       }
       
       print FW "\n$AddUserStmt\n";

       $Dbh->do(qq{begin
                     $AddUserStmt;
                     end;
                  \
                 }) || print FWE "exec $AddUserStmt ;\n\n";
    }

    $Sh1->finish;
    print " $j Users added\n";
    &Print_Line("Review ${FNameErr}.sql which may have error stmt. Run those mannually\n\n");
    close(FW);
    close(FWE);
    system("chmod 600 ${FName}.sql  ${FNameErr}.sql");

    $Dbh->disconnect;
    &Debug_Now if ($Debug);

    &Print_Line("Updating Missing FND_USER ... (may take sometime)");
    $Dbh = &Connect_Db;

    $St1 = q{ SELECT distinct 'fnd_user_pkg.updateuser(x_user_name=>'''||x.user_name||
                     ''', x_owner=>'''', x_start_date=>TO_DATE('''||
                     TO_CHAR(x.start_date,'DD-MON-YYYY HH24:MI:SS')||
                     ''',''DD-MON-YYYY HH24:MI:SS''), x_end_date=>TO_DATE('''||
                     TO_CHAR(x.end_date,'DD-MON-YYYY HH24:MI:SS')||
                     ''',''DD-MON-YYYY HH24:MI:SS''), x_last_logon_date => TO_DATE('''||
                     TO_CHAR(x.last_logon_date,'DD-MON-YYYY HH24:MI:SS')||
                     ''',''DD-MON-YYYY HH24:MI:SS''), x_description=>'''||
                     x.description||''', x_password_lifespan_days=>TO_NUMBER('''||
                     x.password_lifespan_days||'''), x_employee_id=>TO_NUMBER('''||
                     x.employee_id||'''), x_email_address=>'''||x.description||''')'
              FROM   pre_ref_xx_fnd_user x, applsys.fnd_user b
              WHERE  x.user_name = b.user_name
              AND   (NVL(x.end_date,SYSDATE) <> NVL(b.end_date,SYSDATE ) OR
                     x.start_date <> b.start_date) };

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;

    $FName = "/tmp/${DBSID}_2_fnd_user_upd";
    $FNameErr = "/tmp/${DBSID}_2_fnd_user_upd_error";
    open(FW, ">${FName}.sql") || die "Cannot open new file ${FName}.sql $!\n";
    open(FWE, ">${FNameErr}.sql") || die "Cannot open new file ${FNameErr}.sql $!\n";

    $j = 0;
    while(( $UpdUserStmt) = $Sh1->fetchrow_array) {
       if (++$j == 1 ) {
          $St1 = q{alter session set current_schema=APPS};
          $Row = $Dbh->do("$St1") || die "\nStmt Faild [ $St1 ]\n", $Dbh->errstr;
          print FWE "-----------------------------------------------------------------------------\n";
          print FWE "-- If any below update user statement appears, those are issue in adding.\n";
          print FWE "-- Connect as Apps and run manually and fix the issue.\n";
          print FWE "-- If a particular user is end dataed you can ignore those user update stmnt\n";
          print FWE "-----------------------------------------------------------------------------\n";
       }
       print FW "\n$UpdUserStmt\n";

       $Dbh->do(qq{begin
                     $UpdUserStmt;
                     end;
                  \
                 }) || print FWE "exec $UpdUserStmt ;\n\n"; 
    }

    $Sh1->finish;
    $Dbh->disconnect;
    print " $j Users updated\n";
    &Print_Line("Review ${FNameErr}.sql which may have error stmt. Run those mannually\n\n");

    &Debug_Now if ($Debug);

    close(FW);
    close(FWE);
    system("chmod 600 ${FName}.sql ${FNameErr}.sql");
}

#=====================
# Add_Missing_Fnd_Resp
#=====================
sub Add_Missing_Fnd_Resp {    

    $WhereIam = "Add_Missing_Fnd_Resp";
    &Print_Header("Adding Missing Responsibilities");
    $Dbh = &Connect_Db;

    &Print_Line("Removing special char from description field of PRE_REF_XX_FND_USER_RESP_GROUP");
    $Ust = q{update PRE_REF_XX_FND_USER_RESP_GROUP set DESCRIPTION=replace(DESCRIPTION,'''','') };
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER_RESP_GROUP set DESCRIPTION=replace(DESCRIPTION,'"','') };
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER_RESP_GROUP set DESCRIPTION=replace(DESCRIPTION,'&','') };
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER_RESP_GROUP set DESCRIPTION=replace(DESCRIPTION,'%','') };
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER_RESP_GROUP set DESCRIPTION=replace(DESCRIPTION,'$','') };
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;
    $Ust = q{update PRE_REF_XX_FND_USER_RESP_GROUP set DESCRIPTION=replace(DESCRIPTION,'@','') };
    $Row = $Dbh->do("$Ust") || die "\nStmt Faild [ $Ust ]\n", $Dbh->errstr;

    print " Done.\n";

    &Print_Line("Adding Missing Responsibilities ... (may take sometime)");

    $St1 = q{SELECT distinct 'fnd_user_resp_groups_api.insert_assignment(user_id=>'||u.user_id||
                    ', responsibility_id=>'||r.responsibility_id||', responsibility_application_id=>'||
                    r.application_id||', start_date=>to_date('''||
                    TO_CHAR(x.start_date,'DD-MON-YYYY HH24:MI:SS')||
                    ''',''DD-MON-YYYY HH24:MI:SS''), end_date=>NULL, description=>'''||x.description||''')'
             FROM   pre_ref_xx_fnd_user_resp_group x, applsys.fnd_responsibility_tl r, applsys.fnd_user u
             WHERE  x.user_name = u.user_name
             AND    r.responsibility_name = x.responsibility_name
             AND   (x.user_name, x.responsibility_name ) IN
                   (SELECT x1.user_name, x1.responsibility_name
                    FROM   pre_ref_xx_fnd_user_resp_group x1
                    MINUS
                    SELECT u1.user_name, r1.responsibility_name
                    FROM   applsys.fnd_user u1, 
                           applsys.fnd_responsibility_tl r1, 
                           applsys.fnd_user_resp_groups g1
                    WHERE  u1.user_id = g1.user_id
                    AND    g1.responsibility_id = r1.responsibility_id
                    AND    g1.responsibility_application_id = r1.application_id) };

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;

    $FName = "/tmp/${DBSID}_3_fnd_resp_add";
    $FNameErr = "/tmp/${DBSID}_3_fnd_resp_add_error";
    open(FW, ">${FName}.sql ") || die "Cannot open new file ${FName}.sql $!\n";
    open(FWE, ">${FNameErr}.sql ") || die "Cannot open new file ${FNameErr}.sql $!\n";

    $j = 0;
    while(( $AddRespStmt) = $Sh1->fetchrow_array) {
       if (++$j == 1 ) {
          $St1 = q{alter session set current_schema=APPS};
          $Row = $Dbh->do("$St1") || die "\nStmt Faild [ $St1 ]\n", $Dbh->errstr;
          print FWE "-----------------------------------------------------------------------------\n";
          print FWE "-- If any below add Resp statement appears, those are issue in adding.\n";
          print FWE "-- Connect as Apps and run manually and fix the issue.\n";
          print FWE "-- If a particular user is end dataed you can ignore those resp. add stmnt\n";
          print FWE "-----------------------------------------------------------------------------\n";
       }
       print FW "\n$AddRespStmt\n";

       $Dbh->do(qq{begin
                     $AddRespStmt;
                     end;
                  \
                 }) || print FWE "exec $AddRespStmt;\n\n";

    }

    $Sh1->finish;
    $Dbh->disconnect;
    print " $j resp. added\n";
    &Print_Line("Review ${FNameErr}.sql which may have error stmt. Run those mannually\n\n");

    &Debug_Now if ($Debug);
    close(FW);
    close(FWE);
    system("chmod 600 ${FName}.sql   ${FNameErr}.sql");

    &Print_Line("Updating Missing responsibilities ... (may take sometime)");
    $Dbh = &Connect_Db;

    $St1 = q{SELECT distinct 'fnd_user_resp_groups_api.update_assignment(user_id=>'||furg.user_id||
                    ', responsibility_id=>'||furg.responsibility_id||', responsibility_application_id=>'||
                    r.application_id||', security_group_id=>'||furg.security_group_id||
                    ', start_date=>TO_DATE('''||TO_CHAR(xxdba.start_date,'DD-MON-YYYY HH24:MI:SS')||
                    ''',''DD-MON-YYYY HH24:MI:SS''), end_date=>TO_DATE('''||
                    TO_CHAR(xxdba.end_date,'DD-MON-YYYY HH24:MI:SS')||
                    ''',''DD-MON-YYYY HH24:MI:SS''), description=>'''||xxdba.description||''')'
            FROM    applsys.fnd_responsibility_tl r,
                    applsys.fnd_user_resp_groups furg,
                    applsys.fnd_user fu,
                    pre_ref_xx_fnd_user_resp_group xxdba
            WHERE   fu.user_id = furg.user_id
            AND     r.responsibility_id = furg.responsibility_id
            AND     fu.user_name = xxdba.user_name
            AND     xxdba.responsibility_name = r.responsibility_name
            AND     (NVL(xxdba.end_date,sysdate) <> nvl(furg.end_date,sysdate) OR
                     xxdba.start_date <> furg.start_date)
            AND     furg.responsibility_application_id = r.application_id };

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;

    $FName = "/tmp/${DBSID}_4_fnd_resp_upd";
    $FNameErr = "/tmp/${DBSID}_4_fnd_resp_upd_error";
    open(FW, ">${FName}.sql") || die "Cannot open new file ${FName}.sql $!\n";
    open(FWE, ">${FNameErr}.sql") || die "Cannot open new file ${FNameErr}.sql $!\n";

    $j = 0;
    while(( $UpdRespStmt) = $Sh1->fetchrow_array) {
       if (++$j == 1 ) {
          $St1 = q{alter session set current_schema=APPS};
          $Row = $Dbh->do("$St1") || die "\nStmt Faild [ $St1 ]\n", $Dbh->errstr;
          print FWE "-----------------------------------------------------------------------------\n";
          print FWE "-- If any below add Resp statement appears, those are issue in update.\n";
          print FWE "-- Connect as Apps and run manually and fix the issue.\n";
          print FWE "-- If a particular user is end dataed you can ignore those resp. update stmnt\n";
          print FWE "-----------------------------------------------------------------------------\n";
       }
       print FW "\n$UpdRespStmt\n";
       $Dbh->do(qq{begin
                     $UpdRespStmt;
                     end;
                  \
                 }) || print FWE "exec $UpdRespStmt;\n\n";
    }

    $Sh1->finish;
    $Dbh->disconnect;
    print " $j Resp updated\n";
    &Print_Line("Review ${FNameErr}.sql which may have error stmt. Run those mannually\n\n");
    &Debug_Now if ($Debug);
    close(FW);
    close(FWE);
    system("chmod 600 ${FName}.sql ${FNameErr}.sql");
}

#===================
# Gen_Listener_Entry
#===================
sub Gen_Listener_Entry {

    $WhereIam = "Gen_Listener_Entry"; 

    chomp($DbPort = `grep local_listener $ENV{'ORACLE_HOME'}/dbs/init$DBSID.ora |cut -d\"=\" -f7`);
    $DbPort = s/\)//g; 
    $DbPort = s/"//g; 
    $DbPort = 'xxxx' if ($DbPort eq "") ;

    chomp($IsItEntered = `grep ^LISTENER_${DBSID} /var/opt/oracle/listener.ora`);

    if ("$IsItEntered" eq "" ) {
       $Fname = "/tmp/${DBSID}_listener_entry.lst";
       &Print_Line("Generating LISTENER_${DBSID} to $Fname");
       open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";
      
       my $MyHost = lc(${DBSID}-db);
       chomp($TExt = `date +\%d-\%b-\%Y`);
       print FW "#--------------------------------------------------------------------------------\n";
       print FW "# Listener Entry for $DBSID add on $TExt\n";
       print FW "#--------------------------------------------------------------------------------\n";
       print FW "LISTENER_${DBSID}=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(Host=$MyHost)(Port=$DbPort)))\n\n";
       print FW "SID_LIST_LISTENER_${DBSID}=\n";
       print FW "        (SID_LIST=\n";
       print FW "                (SID_DESC=\n";
       print FW "                        (SID_NAME=${DBSID})\n";
       print FW "                        (ORACLE_HOME=$ENV{'ORACLE_HOME'})\n";
       print FW "                )\n";
       print FW "        )\n\n";
       print FW "STARTUP_WAIT_TIME_LISTENER_${DBSID}=0\n";
       print FW "CONNECT_TIMEOUT_LISTENER_${DBSID}=10\n";
       print FW "TRACE_LEVEL_LISTENER_${DBSID}=OFF\n\n";
       print FW "LOG_DIRECTORY_LISTENER_${DBSID}=$ENV{'ORACLE_HOME'}/network/admin\n";
       print FW "LOG_FILE_LISTENER_${DBSID}=LISTENER_${DBSID}\n";
       print FW "TRACE_DIRECTORY_LISTENER_${DBSID}=$ENV{'ORACLE_HOME'}/network/admin\n";
       print FW "TRACE_FILE_LISTENER_${DBSID}=LISTENER_${DBSID}\n\n";
       print FW "#----------------End of $DBSID Listener entry------------------------------------\n";
       close(FW);
       print "Done\n";
       system("chmod 600 $Fname");
       &Print_Line("Review $Fname and add it to /var/opt/oracle/listener.ora");
    }
    else {
       &Print_Line("Listener Entry already exist in /var/opt/oracle/listener.ora");
       print " NotDone\n";
    }
    &Debug_Now if ($Debug);
}

#=============
# Db_Cron_Jobs
#=============
sub Db_Cron_Jobs {
    $WhereIam = "Db_Cron_Jobs";
    $Fname = "$Home/${DBSID}.cron";
    #system("crontab -l > $Home/${DBSID}.cron");

    $MyScriptDir = "/usr/tools/oracle/Standard/script";

    &Print_Line("Creating the cronjobs file in $Fname");
    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";
    print FW"#--------------------------------------------------------------------\n";
    print FW"#  $DBSID Cron Jobs\n";
    print FW"#--------------------------------------------------------------------\n";

    chomp($SrchCnt = `/usr/bin/crontab -l|grep "check_sqlnet_all.pl" |wc -l`);
    $SrchCnt =~ s/ //g;

    if ($SrchCnt eq "0") {
       $CJob = "$MyScriptDir/check_sqlnet_all.pl";
       print FW "#* * * * * $CJob > /usr/tmp/check_sqlnet_all.err 2>\&1\n";
       print FW "#-----\n";
    }

    $CJob = "$MyScriptDir/dbstats.pl -s $DBSID -p PagerId -n 1";
    print FW "01 * * * * $CJob > /usr/tmp/${DBSID}_dbstats.log 2>\&1\n";
    print FW "#-----\n";

    $CJob = "$MyScriptDir/flush_perfstat.sh $DBSID Y MailId";
    print FW "02 1 1 * * $CJob > /usr/tmp/${DBSID}_flush_perfstat_all.err 2>\&1\n";
    print FW "#-----\n";

    $CJob = "$MyScriptDir/analyze_database.pl -s $DBSID -f /usr/tools/oracle/analyze_database.par";
    print FW "00 00 * * 0 $CJob -l /usr/tmp/${DBSID}_analyze_database.log \n";
    print FW "#-----\n";

    $MyScriptDir = "/usr/tools/oracle";
    print FW "0 6 * * 0 $MyScriptDir/agefile.pl -f /oracle/admin/${DBSID}/bdump/alert_${DBSID}.log 2>\&1\n";
    print FW "#-----\n";

    $CJob = "$MyScriptDir/i2i_gen_pin_package.pl -s $DBSID";
    print FW "0 6 * * 0 $CJob 1>/usr/tmp/${DBSID}_gen_pin_package.log 2>\&1\n";
    print FW "#-----\n";

    $CJob = "$MyScriptDir/listener_monitor.pl -s $DBSID -l LISTENER_$DBSID -p PagerId -t 240";
    print FW "* * * * * $CJob > /usr/tmp/${DBSID}_listener_monitor.out 2>\&1\n"; 
    print FW "#-----\n";

    $CJob = "$MyScriptDir/check_extents.pl -s $DBSID -f check_extents.par";
    print FW "00,10,20,30,40,50 * * * * $CJob >/usr/tmp/${DBSID}_check_extents.log 2>\&1\n";
    print FW "#-----\n";

    $CJob = "$MyScriptDir/analyze_report.pl -s $DBSID -d 7 -m MailId";
    print FW "00 10 * * 1 $CJob > /usr/tmp/${DBSID}_analyze_report.out 2>\&1\n";
    print FW "#-----\n";

    $CJob = "$MyScriptDir/weekly_monitor.pl -s $DBSID -m MailId";
    print FW "00 10 * * 4 $CJob > /usr/tmp/${DBSID}_weekly_monitor.out 2>\&1\n";
    print FW "#-----\n";

    $CJob = "$MyScriptDir/db_connect.pl -s $DBSID -m MailId -p PagerId";
    print FW "0 * * * * $CJob > /usr/tmp/${DBSID}_db_connect.out 2>\&1\n";
    print FW "#-----\n";
    print FW "00 1,5,9,13,17,21 * * * find /oracle/admin/$DBSID/perf/* -mtime +30 -exec rm -rf {} \\; > /dev/null 2>\&1\n";
    print FW "#-----\n";
    print FW "00 1,5,9,13,17,21 * * * find /oracle/admin/$DBSID/bdump/*.trc -mtime +4 -exec rm {} \\; >/dev/null 2>\&1\n";
    print FW "#-----\n";
    print FW "00 1,5,9,13,17,21 * * * find /oracle/admin/$DBSID/udump/*.trc -mtime +4 -exec rm {} \\; >/dev/null 2>\&1\n";
    print FW "#-----\n";
    print FW "00 1,5,9,13,17,21 * * * find /oracle/admin/$DBSID/audit/*.aud -mtime +4 -exec rm {} \\; >/dev/null 2>\&1\n";
    print FW "#-----\n";
    print FW "00 1,5,9,13,17,21 * * * find /apps/orarpt/$DBSID/utl/* -mtime +4 -exec rm {} \\; > /dev/null 2>\&1\n";
    print FW "#-----\n";
    print FW "#\n#\n";
    print FW "#-----End of $DBSID Cron Jobs----------------------------------------\n";
    close(FW);
    print " Done\n\n";
    &Debug_Now if ($Debug);
}

#===================
# New_Instance_Setup
#===================
sub New_Instance_Setup {
    $WhereIam = "New_Instance_Setup";
    
    print "\t\t\t\tTasks will be performed :-\n\n"                ;
    print "\t\t\t\t* Adding entry to /etc/oratab\n"               ;
    print "\t\t\t\t* Creating required dir under /oracle/admin\n" ;
    print "\t\t\t\t* Softlink init$DBSID.ora to dbs dir\n"        ;
    print "\t\t\t\t* Creating listener entry \n"                  ;

    print "\n\t\t\t\tEnter the SID you want to setup : ";
    chomp($NewSid = uc(<STDIN>));
    return if ($NewSid eq "");
    print "\n";
    
    chomp(@AvailOH=`grep -v "^#" /etc/oratab |cut -d":" -f2|sort -u`);
    $i=0;
    foreach $Oh (@AvailOH) {
       print "\t\t\t\tAvaliable Oracle Versions :-\n\n" if (++$i == 1 );
       print "\t\t\t\t\t$Oh\n";
    }
    print "\n\t\t\t\tEnter the ORACLE_HOME : ";
    chomp($NewOraHome = <STDIN>);
    return if ($NewOraHome eq "");
    print "\n";

    print "\n\t\t\t\tEnter the Listener Port : ";
    chomp($NewDbPort = <STDIN>);
    return if ($NewDbPort eq "");
    print "\n";

    @NAdmDir = ("/oracle/admin/$NewSid/pfile", 
                "/oracle/admin/$NewSid/control",
                "/oracle/admin/$NewSid/create", 
                "/oracle/admin/$NewSid/clone", 
                "/oracle/admin/$NewSid/bdump");

    $SoftLink = 0;
    $SoftLink = 1 if ( -w "/ora_dump" && -d "/ora_dump" );

    @NAdmDir = (@NAdmDir, "/oracle/admin/$NewSid/udump", 
                          "/oracle/admin/$NewSid/cdump",
                          "/oracle/admin/$NewSid/audit",
                          "/oracle/admin/$NewSid/perf",
                          "/oracle/admin/$NewSid/refresh") if (! $SoftLink);

    foreach $ndir (@NAdmDir) {
       &Print_Line("Creating $ndir");
       if (-d "$ndir") {
          print " Already Exists\n"; 
       }
       else{
          system("mkdir -p $ndir");
          system("chmod 770 $ndir") if ($ndir =~ /clone/ || $ndir =~ /refresh/);
          print " Done\n"; 
       }
    }

    if ($SoftLink) {
       foreach $ndir ("udump", "cdump", "audit", "perf", "refresh") {
          &Print_Line("Creating /oracle/admin/$NewSid/$ndir");
          if (-d "/oracle/admin/$NewSid/$ndir") {
             print " Already Exists\n"; 
          }
          else{
            system("mkdir -p /ora_dump/$NewSid/$ndir") if( ! -d "/ora_dump/$NewSid/$ndir");
            system("chmod 770 /ora_dump/$NewSid/$ndir") if ($ndir eq 'refresh');
            system("ln -s /ora_dump/$NewSid/$ndir /oracle/admin/$NewSid/$ndir") if (! -d "/oracle/admin/$NewSid/$ndir");
            print " Done\n"; 
          }
       }
    }

    &Print_Line("Adding $NewSid:$NewOraHome:N to /etc/oratab");

    chomp($SrchCnt = `grep "^${NewSid}:" /etc/oratab |wc -l`);
    $SrchCnt =~ s/ //g;

    if ($SrchCnt ne "0") {
       print " Already Exists\n";
    }
    else {
       chomp($TExt = `date +\%d\%b\%H\%M\%S`);
       system("cp -p /etc/oratab /oracle/admin/$NewSid/clone/oratab.$TExt");
       open(FW, ">>/etc/oratab") || die "Cannot open new file /etc/oratab $!\n";
       print FW "${NewSid}:${NewOraHome}:N\n";
       close(FW);
       print " Done\n";
    }

    if ($NewDbPort == 1521) {
       &Print_Line("!!! ToDo : Add listener entry manually to /etc/listner.ora since the port is 1521");
       print " NotDone\n";
    }
    else {
       chomp($SrchCnt = `grep -i $NewSid /etc/listener.ora|grep -v grep |wc -l`);
       $SrchCnt =~ s/ //g;
       if ($SrchCnt ne "0") {
          &Print_Line("!!! ToDo : $NewSid listener entry exists in /etc/listner.ora, verify the entry");
          print " NotDone\n";
       }
       else {
          &Print_Line("Adding listener entry /etc/listener.ora");
          chomp($TExt = `date +\%d\%b\%H\%M\%S`);
          system("cp -p /etc/listener.ora /oracle/admin/$NewSid/clone/listener.ora.$TExt");
          open(FW, ">>/etc/listener.ora") || die "Cannot open new file /etc/listener.ora $!\n";
          print FW "#-----------------------------------------------\n";
          print FW "#Listener Entry for $NewSid\n";
          print FW "#-----------------------------------------------\n";
          print FW "LISTENER_${NewSid}=\n";
          print FW "  (ADDRESS_LIST=\n";
          print FW "        (ADDRESS=(PROTOCOL=TCP)(Host=".lc($NewSid)."-db)(Port=$NewDbPort)(QUEUESIZE=1000))\n";
          print FW "  )\n";
          print FW "SID_LIST_LISTENER_$NewSid =\n";
          print FW "  (SID_LIST =\n";
          print FW "    (SID_DESC =\n";
          print FW "      (SID_NAME = $NewSid)\n";
          print FW "      (ORACLE_HOME=$NewOraHome)\n";
          print FW "    )\n";
          print FW "  )\n\n";
          print FW "STARTUP_WAIT_TIME_LISTENER_$NewSid = 0\n";
          print FW "CONNECT_TIMEOUT_LISTENER_$NewSid = 0\n";
          print FW "TRACE_LEVEL_LISTENER_$NewSid = OFF\n\n";
          print FW "LOG_DIRECTORY_LISTENER_$NewSid = ${NewOraHome}/network/admin\n";
          print FW "LOG_FILE_LISTENER_$NewSid = LISTENER_$NewSid\n";
          print FW "TRACE_DIRECTORY_LISTENER_$NewSid = ${NewOraHome}/network/admin\n";
          print FW "TRACE_FILE_LISTENER_$NewSid = LISTENER_$NewSid\n";
          print FW "#\n";
          print FW "#---------End of Listener Entry $NewSid---------------------------\n\n";
          close(FW);
          print " Done\n";
       }
    }

    &Print_Line("Linking /oracle/admin/$NewSid/pfile/init$NewSid.ora to dbs dir");
    if (-f "$NewOraHome/dbs/init$NewSid.ora" || -l "$NewOraHome/dbs/init$NewSid.ora") {
       print " NotDone\n";
       &Print_Line("!!! ToDo : $NewOraHome/dbs/init$NewSid.ora already exist. Validate the link and file\n");
    }
    else {
       system("ln -s /oracle/admin/$NewSid/pfile/init$NewSid.ora $NewOraHome/dbs/init$NewSid.ora");
       print " Done\n";
       &Print_Line("!!! ToDo : You need to create the file /oracle/admin/$NewSid/pfile/init$NewSid.ora\n");
    }

    $ENV{'ORACLE_SID'} = $NewSid;
    $DBSID = $NewSid;
    &Env_Database ;
    $Banner = $DBSID ;
    &Debug_Now if ($Debug);
    print "\n";
}

#==================
# Setup_Utl_For_11i
#==================
sub Setup_Utl_For_11i {    
    $WhereIam = "Setup_Utl_For_11i";
    
    print "\t\t\t\tTasks will be performed :-\n\n"                ;
    print "\t\t\t\t* Create dir /apps/orarpt/$DBSID/utl\n"        ;

    print "\n\t\t\t\tDo you want to continue(Y/N) : ";
    chomp($QUt = uc(<STDIN>));
    return if ($QUt eq "");
    print "\n";

    &Print_Header("Setting up utl Dir for 11i Env.");
    #if (-w "/apps/orarpt" || -d "/apps/orarpt/$DBSID") {
    if (-w "/apps/orarpt" ) {
       &Print_Line("Creating /apps/orarpt/$DBSID/utl directory");
       system("mkdir -p /apps/orarpt/$DBSID/utl");
       print " Done\n";
    }
    else {
       &Print_Line("/apps/orarpt does not exists, Create this and re-run this");
       print " Notdone\n";
    }
    &Debug_Now if ($Debug);
    print "\n";
}

#==================
# Db_Before_Release
#==================
sub Db_Before_Release {    
    $WhereIam = "Db_Before_Release";
    &Print_Header("Validation Db Before release steps");
    $Dbh = &Connect_Db;
}

#==================
# Cleanup_Conc_Node
#==================
sub Cleanup_Conc_Node {    

    $WhereIam = "Cleanup_Conc_Node";
    &Print_Header("Cleaning Concurrent for New Cloning");
    print "\n\n\tWARNING : Cleanup needs to be done only before cloning an instance. !!!\n";
    print "\n\tDo you want to Continue?(Y/N) : " ;
    chomp($NQS = <STDIN>);

    if (uc("$NQS") ne "Y")  {
       print "\n\tReturning without execution...\n";
       return ;
    }
    print "\n\n";
    
    $Dbh = &Connect_Db;

    &Print_Line("Checking FND_CONC_CLONE package existance");
    $St1 = q{select 1 from dba_objects 
             where  object_name='FND_CONC_CLONE' 
             and    object_type='PACKAGE' 
             and    owner like 'APP%' };

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    ($PkgExists) = $Sh1->fetchrow_array;
    $Sh1->finish;
    if (! $PkgExists) {
       print " Not Exists.\n";
    }
    print " Exists.\n";

    &Print_Line("Becoming APPS user");
    $St1 = q{alter session set current_schema=APPS};  
    $Row = $Dbh->do("$St1") || die "\nStmt Faild [ $St1 ]\n", $Dbh->errstr;
    print " Done\n";

    &Print_Line("Cleaning up FND_NODES using fnd_conc_clone.setup_clean package");
    $St1 = q{begin fnd_conc_clone.setup_clean; end;};
    $Dbh->do(qq{$St1
                \
               }) || die "\nStmt Faild [ $St1 ]\n", $Dbh->errstr;
    print " Done\n";
    $Dbh->disconnect;

    &Debug_Now if ($Debug);
    print "\n";
}

#--------END-OF-DATABASE-ACTIVITY----------------------------------------------

#*****************
# Menu_Application
#*****************
sub Menu_Application {

    &Env_Application; 
print "NotAllowed : $NotAllowed\n";
    return if ($NotAllowed);
    @ToDoList = ();
    $NotHere = 0;
    $OptMA   = 0;
    &Screen_Scroll;
    #CCK print "\n\t\t\t\tApplication Menu ($Sid)"                                    ;
    #CCK print "\n\t\t\t\t===========================\n\n"                            ;
    #CCK print "\t\t\t\t1. Verify Environment (Eg. xml File, Dir permission etc)\n"   ;
    #CCK print "\t\t\t\t1. Source environment Task\n"                                 ;
    #CCK print "\t\t\t\t2. Destination environment Task\n"                            ;
    #CCK print "\n\t\t\t\tEnter your choice (ENTER to previous menu): "               ;
    #CCK chomp($OptMA = <STDIN>)                                                      ;
    print "\n\n"                                                                 ;

    &Main_Menu if (uc($OptMA) eq "");
    #CCK if ($OptMA == 1) { 
    #CCK    $AppsEnvOk = "N";
    #CCK    &Env_Application; 
    #CCK }
    #CCK elsif ($OptMA == 2) { &Menu_Source_App; }

    #CCK if ($OptMA == 1) { &Menu_Source_App; }
    #CCK elsif ($OptMA == 2) { &Menu_Destination_App;}
    &Menu_Destination_App;
    #CCK &Menu_Application;
}

#*****************
# Menu_Source_App
#*****************
sub Menu_Source_App {

    @ToDoList = ();
    $NotHere = 0;
    &Screen_Scroll;
    $OptMSA=0;

    print "\n\t\t\t\tSource Application Menu ($Sid)"                  ;
    print "\n\t\t\t\t==================================\n\n"          ;
    print "\t\t\t\t1. Pre-clone before source codetree copy\n"        ;
    print "\t\t\t\t2. Backup target config files before refresh\n"    ;
    print "\n\t\t\t\tEnter your choice (ENTER to previous menu): "    ;
    chomp($OptMSA = <STDIN>)                                          ;
    print "\n"                                                        ;
    &Menu_Application if (uc($OptMSA) eq "")                          ;

    if ($OptMSA == 1) { 
       print "\t\t\t\tTasks will be performed :-\n\n"                 ;
       print "\t\t\t\t* Pointing /etc/OraInventory.loc\n"             ;
       print "\t\t\t\t* Run the Source Cloning\n"                     ;
       print "\t\t\t\t* Re-pointing /etc/OraInventory.loc\n"          ;
       print "\n\n\t\t\t\tContinue?(Y/N) : "                          ;
       chomp($QS = <STDIN>)                                           ;
       print "\n\n"                                                   ;

       &Opt_Apps_Source_Clone if (uc("$QS") eq "Y") ; 
    }
    elsif ($OptMSA == 2) { 
       print "\t\t\t\tTasks will be performed :-\n\n"                 ;
       print "\t\t\t\t* Backup Context File \n"                       ;
       print "\t\t\t\t* Backup CGIcmd.dat File\n"                     ;
       print "\t\t\t\t* Backup wdbsvr.app File\n"                     ;
       print "\n\n\t\t\t\tContinue?(Y/N) : "                          ;
       chomp($QQ = <STDIN>)                                           ;
       print "\n\n"                                                   ;
       &Opt_Apps_Pre_Refresh if (uc("$QQ") eq "Y")                    ; 
    }
    &Menu_Application; 
}

#*********************
# Menu_Destination_App
#*********************
sub Menu_Destination_App {

    &Env_Application;
    return if ($NotAllowed);
    $NotHere = 0;
    $OptMDA   = 0;
    @ToDoList = ();
    $NotHere = 0;
    &Screen_Scroll;
    print "\n\t\t\t\tDestination Application Menu ($Sid)\n";
    print "\t\t\t\t=======================================\n\n";
    print "\t\t\t\t1.  Clone Sj Instance\n";
    print "\t\t\t\t2.  Clone Qtc Instance\n";
    print "\t\t\t\t3.  Clone Bv Instance\n";
    print "\t\t\t\t4.  Clone Emea Instance\n";
    print "\t\t\t\t5.  Clone Asia Instance\n";
    print "\t\t\t\t6.  Clone C3 Instance\n";
    print "\t\t\t\t7.  Clone Ecust Instance\n";
    print "\t\t\t\t8.  OTHER tasks\n\n";
    print "\t\t\t\tEnter your choice (ENTER to previous menu): " ;
    chomp($OptMDA = <STDIN>)                                     ;
    print "\n"                                                   ;
       
    #CCK &Menu_Application if (uc($OptMDA) eq ""); 
    &Main_Menu if (uc($OptMDA) eq ""); 
    if ($OptMDA==1 || $OptMDA==2 || $OptMDA==3 || $OptMDA==4 || $OptMDA==5 || $OptMDA==6 || $OptMDA==7) { 
       print qq{\t\t\t\tTasks will be performed for "$Sid" Cloning\n};
       print qq{\t\t\t\t********************************************\n};
       print qq{\t\t\t\t* Re-create the soft links, modify oraInst.loc\n};
       print qq{\t\t\t\t* Runs the destination cloning\n};
       print qq{\t\t\t\t* Backup config files\n};
       print qq{\t\t\t\t* Move log and out to /apps/orarpt\n};
       print qq{\t\t\t\t* NAS setup\n} if ($AppsNas);
       print qq{\t\t\t\t* Virtual name setup\n};
       print qq{\t\t\t\t* Create admin scripts\n};
       print qq{\t\t\t\t* Sync old patch logs\n};
       print qq{\t\t\t\t* Create apps tier cron job script\n};
       print qq{\t\t\t\t* Create ldap/sqlnet.ora link\n};
       print qq{\t\t\t\t* Add an entry to appstab\n};
       print qq{\t\t\t\t* Backup critical tables(fnd_profile etc)\n};
       print qq{\t\t\t\t* Schedule purge jobs\n};
       print qq{\t\t\t\t* Change adcmctl.sh for ABORT\n};
       print qq{\t\t\t\t* Secure the files and dir's\n};
       print qq{\t\t\t\t* Update site name,java color schema,singon pwd length profiles\n};
       print qq{\t\t\t\t* Grant utlrecomp to apps\n};
       print qq{\t\t\t\t* Setup environment file for apps team\n};
       print qq{\t\t\t\t* Impliment hide to executables(sqlplus,imp,exp etc)\n};
       print qq{\t\t\t\t* SSO setup+\n} if ($OptMDA == 1);
       print qq{\t\t\t\t* Update iproc releated profiles+\n} if ($OptMDA == 1);
       print qq{\n\n\t\t\t\tContinue?(Y/N) : };
       chomp($QQ = <STDIN>);
       print "\n";
    } 

    &Menu_Destination_App if ((uc("$QQ") ne "Y") && ($OptMDA != 8));

    if    ($OptMDA == 1)  { &Opt_Apps_Sj_Instance_Clone; }
    elsif ($OptMDA == 2)  { &Opt_Apps_Qtc_Instance_Clone; }
    elsif ($OptMDA == 3)  { &Opt_Apps_Bv_Instance_Clone; }
    elsif ($OptMDA == 4)  { &Opt_Apps_Emea_Instance_Clone; }
    elsif ($OptMDA == 5)  { &Opt_Apps_Asia_Instance_Clone; }
    elsif ($OptMDA == 6)  { &Opt_Apps_Cts_Instance_Clone; }
    elsif ($OptMDA == 7)  { &Opt_Apps_Ecustomer_Instance_Clone; }
    elsif ($OptMDA == 8) { &Opt_Apps_Other_Tasks; }
    &Menu_Destination_App;
}

#***************************
# Opt_Standard_Cloning_Tasks 
#***************************
sub Opt_Standard_Cloning_Tasks {
    &Opt_Apps_Destination_Clone;
    &Opt_Correct_Begin_End_Customization;
    &Opt_ReCreate_Log_Out;
    #CCK &Opt_Nas_Setup if ( $AppsNas );
    &Opt_Nas_Setup ;
    &Opt_Vname_setup;
    &Opt_Gen_Script;
    &Opt_Custom_Env;
    &Opt_Sync_Old_Patch_Logs;
    &Opt_Setup_Apps_Cron_Job;
    &Opt_Add_Entry_To_Appstab;
    #CCK &Opt_Add_Entry_To_Threshold;
    &Opt_Backup_Critcal_Tables;
    &Opt_Schedule_Purge_Jobs;
    &Opt_Add_Abort_In_Adcmctl;
    &Opt_Secure_Config_Files;
    &Opt_Update_Site_Name;
    &Grant_On_Utl_Recomp;
    &Opt_Usr_Env_File;
    &Opt_Impliment_Hide;
    &Opt_Create_Sqlnet_Ldap_Link;
}

#***************************
# Opt_Apps_Sj_Instance_Clone 
#***************************
sub Opt_Apps_Sj_Instance_Clone {
    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }

    system("touch $Home/DBA/clone/.RunningInBundle");
    &Opt_Standard_Cloning_Tasks;
    &Opt_Update_Sso_Files_For_Sj;
    &Opt_Update_Sso_Tables_For_Sj;
    &Opt_iProc_Setup;
    &Update_WF_Global_Pref('SJ');
    &Sabrix_Update;
    #&Update_Profile_After_Clone;
    system("rm $Home/DBA/clone/.RunningInBundle");
    &Print_ToDos;
}

#****************************
# Opt_Apps_Qtc_Instance_Clone 
#****************************
sub Opt_Apps_Qtc_Instance_Clone {
    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }

    system("touch $Home/DBA/clone/.RunningInBundle");
    &Opt_Standard_Cloning_Tasks;
    #&Opt_Update_Sso_Tables_For_Qtc_And_Bv ;    
    &Update_Profile_After_Clone;
    &Update_Fnd_User_For_User_Guid;
    &Update_Ipay_Related;
    &Java_Io_File_Permission;
    &Update_WF_Global_Pref('QTC');
    system("rm $Home/DBA/clone/.RunningInBundle");
    &Print_ToDos;
}
#***************************
# Opt_Apps_Bv_Instance_Clone 
#***************************
sub Opt_Apps_Bv_Instance_Clone {
    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }

    system("touch $Home/DBA/clone/.RunningInBundle");
    &Opt_Standard_Cloning_Tasks;
    &Update_Profile_After_Clone;
    &Update_Fnd_User_For_User_Guid;
    &Update_Ipay_Related;
    &Java_Io_File_Permission;
    &Update_WF_Global_Pref('BV');
    system("rm $Home/DBA/clone/.RunningInBundle");
    &Print_ToDos;
}

#*****************************
# Opt_Apps_Emea_Instance_Clone 
#*****************************
sub Opt_Apps_Emea_Instance_Clone {
    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    system("touch $Home/DBA/clone/.RunningInBundle");
    &Opt_Standard_Cloning_Tasks;
    &Update_Profile_After_Clone;
    system("rm $Home/DBA/clone/.RunningInBundle");
    &Print_ToDos;
}

#*****************************
# Opt_Apps_Asia_Instance_Clone 
#*****************************
sub Opt_Apps_Asia_Instance_Clone {
    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    system("touch $Home/DBA/clone/.RunningInBundle");
    &Opt_Standard_Cloning_Tasks;
    &Update_Profile_After_Clone;
    system("rm $Home/DBA/clone/.RunningInBundle");
    &Print_ToDos;
}

#**********************************
# Opt_Apps_Ecustomer_Instance_Clone 
#**********************************
sub Opt_Apps_Ecustomer_Instance_Clone {
    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    system("touch $Home/DBA/clone/.RunningInBundle");
    &Opt_Standard_Cloning_Tasks;
    &Update_Profile_After_Clone;
    &Print_ToDos;
    system("rm $Home/DBA/clone/.RunningInBundle");
}

#****************************
# Opt_Apps_Cts_Instance_Clone 
#****************************
sub Opt_Apps_Cts_Instance_Clone {
    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    system("touch $Home/DBA/clone/.RunningInBundle");
    &Opt_Standard_Cloning_Tasks;
    &Update_Profile_After_Clone;
    &Implement_For_SidDbc;
    system("rm $Home/DBA/clone/.RunningInBundle");
    &Print_ToDos;
}

#**********************
# Opt_Apps_Source_Clone
#**********************
sub Opt_Apps_Source_Clone {

    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    &Opt_Point_Orainst ;
    if (-f "$ScriptDir/adpreclone.pl") {
       system("$ScriptDir/adpreclone.pl appsTier");
    }
    &Opt_Redirect_Orainst;
}

#*********************
# Opt_Apps_Pre_Refresh
#*********************
sub Opt_Apps_Pre_Refresh {

    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    print "Saving the following files to $CloneBackupDir :- \n";

    &Apps_Pre_Refresh ;
    system("chmod 700 $ConfDir/CloneBackup");
    system("chmod 400 $ConfDir/CloneBackup/*");
}

#=================
# Apps_Pre_Refresh
#=================
sub Apps_Pre_Refresh {    
    $WhereIam = "Apps_Pre_Refresh";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    foreach $Fname (("$ApplAdm/${ContextName}.xml", "$AppsPwdFile", "$ModTop/wdbsvr.app")) {
       &Print_Line("Saving $Fname");
       &Backup_File("${Fname},Apps_Pre_Refresh");
       print " Done\n";
   }
   &Debug_Now if ($Debug);
   system("touch $Home/DBA/clone/.${WhereIam}");
}

#***************************
# Opt_Apps_Destination_Clone
#***************************
sub Opt_Apps_Destination_Clone {

    &Print_Header("Cloning the Application");
    $WhereIam = "Opt_Apps_Destination_Clone";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }

    chomp($OldProc=`ps -eaf |grep oa$Sid |egrep -v "ksh|smartclone|perl|grep|tail|vi|su -|ps -"|wc -l`);
    if ($OldProc > 1) {
        print "\n\n\n\t\tWARNING : $OldProc Old Process are running, terminate those and restart this.\n";
        print "\t\t    FYI : Run this [ps -eaf |grep oa$Sid |egrep -v \"ksh|smartclone|perl|grep|tail|vi|su -|ps -\"] to see those\n";
        exit(1);
    }

    chomp($OldProc=`ps -eaf |grep smartclone |grep -v oa$Sid |wc -l`);
    if ($OldProc > 1) {
        print "\n\n\n\t\tWARNING : Another smartclone is running on this server, WAIT for that to complete.\n";
        print "\t\t    FYI : Run this [ ps -eaf |grep smartclone |grep -v oa$Sid ] to see those\n";
        exit(1);
    }
    &Opt_Point_Orainst ;
    &Opt_Recreate_Soft_Links ;    

    system("cd /tmp; rm -rf templbac");

    &Print_Header("Running TechStack Cloning(~15min)");

    if(! -f "$ModTop/wdbsvr.smartclone.org") {
        system("cp -p $ModTop/wdbsvr.app $ModTop/wdbsvr.smartclone.org") ;
        system("chmod 400 $ModTop/wdbsvr.smartclone.org") ;
    }

    if (-f "$CommTop/clone/bin/adcfgclone.pl") {
       $OldPath = $ENV{'PATH'};
       $OldPerl4Lib = $ENV{'PERL5LIB'};
       $ENV{'PERL5LIB'} = "$Home/product/iAS/Apache/perl/lib/5.00503:$Home/product/iAS/Apache/perl/lib/site_perl/5.005:$Home/appl_top/au/11.5.0/perl";
       $ENV{'PATH'} = "/bin:$Home/product/iAS/Apache/perl/bin:$OldPath";
       print qq{cd $CommTop/clone/bin; $CommTop/clone/bin/adcfgclone.pl appsTier $XmlFile\n};
       print "\n\nEnter Apps Password [ $CurApsPwd ], just copy and paste then <ENTER> \n";
       system("cd $CommTop/clone/bin; $CommTop/clone/bin/adcfgclone.pl appsTier $XmlFile");
       $ENV{'PERL5LIB'} = $OldPerl4Lib;
       $ENV{'PATH'} = $OldPath;
    }
    else {
       chomp($Stg=`ls $Stage|wc -l`);
       die "\n\n!!! $Stage directory is Empty, copy the stage from the source !!!\n" if (! $Stg);

       print qq{$ApplTop/ad/11.5.0/bin/adclone.sh java=/opt/java1.3 mode=apply stage=$Stage component=atTechStack method=CUSTOM appctxtg=$XmlFile pwd=$CurApsPwd\n};
       system("$ApplTop/ad/11.5.0/bin/adclone.sh java=/opt/java1.3 mode=apply stage=$Stage component=atTechStack method=CUSTOM appctxtg=$XmlFile pwd=$CurApsPwd");
    
       print "\n";
       &Print_Header("Running Appltop Cloning(\~5min)");
       print qq{$ApplTop/ad/11.5.0/bin/adclone.sh java=/opt/java1.3 mode=apply stage=$Stage component=appltop method=CUSTOM appctxtg=$XmlFile pwd=$CurApsPwd\n};
       system("$ApplTop/ad/11.5.0/bin/adclone.sh java=/opt/java1.3 mode=apply stage=$Stage component=appltop method=CUSTOM appctxtg=$XmlFile pwd=$CurApsPwd ");
   }

   system("cd /tmp; rm -rf templbac");
   $Msg = "Review the cloning log for errors, if any, fix and re-start this process";
   push(@ToDoList, $Msg);
   print "\n\n\t!!!!! $Msg !!!!!\n";
   print "\tHave you verified the log? (Y/N) : " ;
   chomp($QX = <STDIN>);
   print "\n\n";
   exit(1) if (uc("$QX") ne "Y") ; 


   &Debug_Now if ($Debug);

   &Opt_Redirect_Orainst;
   &Backup_After_Clone;

   $ENV{'TWO_TASK'} = $SID;
   print "\n";

   system("touch $Home/DBA/clone/.${WhereIam}");

}

#********************
# Opt_Apps_Post_Clone
#********************
sub Opt_Apps_Post_Clone {

    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }

    &Opt_ReCreate_Log_Out;
    &Opt_Nas_Setup;
    &Opt_Vname_setup;
    &Opt_Gen_Script;
    &Opt_Custom_Env;
    &Opt_Update_Sso_Files_For_Sj;
    &Opt_Update_Sso_Tables_For_Sj;
}

#***********************
# Opt_Apps_Befor_Release
#***********************
sub Opt_Apps_Befor_Release {

    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    &Opt_Sync_Old_Patch_Logs;
    &Opt_Add_Entry_To_Appstab;
    #CCK &Opt_Add_Entry_To_Threshold;
    &Opt_CronJob_Setup;
    &Opt_Backup_Critcal_Tables;
    &Opt_Schedule_Purge_Jobs;
    &Opt_Add_Abort_In_Adcmctl;
    &Opt_Secure_Config_Files;
    &Opt_Create_Sqlnet_Ldap_Link;
    &Update_Profile;
    &Grant_On_Utl_Recomp;
    &Update_Profile("SIGNON_PASSWORD_LENGTH","8");    
    &Update_Profile("FND_COLOR_SCHEME","blue");    
}
#****************
# Opt_iProc_Setup
#****************
sub Opt_iProc_Setup { 
    if ($SID =~ /SJ/ && !($SID =~ /SJOE/)) {
       &iProc_Setup ;
    }
    else {
       print "     !!! iProc configured only in SJ instance, Modify smartclone in ".
             "Opt_iProc_Setup section and rerun if needed !!!\n";
    }
    print "\n";
}

#===========================
# Update_Profile_After_Clone 
#===========================
sub Update_Profile_After_Clone {

    $WhereIam = "Update_Profile_After_Clone";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Update_Profile_After_Clone");
    if (! "$ClonedFrom") {
       print "Update_Profile_After_Clone return ... \n";
       return;
    } 

    my $Row;
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    chomp($TExt = `date +\%d\%b\%H\%M\%S`);
    &Backup_Tables("applsys.fnd_profile_option_values","fnd_profile_optval_$TExt");

    $St1 = qq{ UPDATE fnd_profile_option_values SET profile_option_value = REPLACE(profile_option_value,?,?)
               WHERE  profile_option_value LIKE ?
               AND    profile_option_id NOT IN (SELECT profile_option_id FROM fnd_profile_options_vl
                                                WHERE  profile_option_name = 'SITENAME')};

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;

    $ClonedFrom = uc($ClonedFrom);
    &Print_Line("Update profiles to Change $ClonedFrom to $SID");
    $Row = $Sh1->execute( "$ClonedFrom", "$SID", "\%$ClonedFrom\%");
    print " $Row Rows Updated\n";

    $ClonedFrom = lc($ClonedFrom);
    &Print_Line("Update profiles to Change $ClonedFrom to $Sid");
    $Row = $Sh1->execute( "$ClonedFrom", "$Sid", "\%$ClonedFrom\%");
    print " $Row Rows Updated\n";

    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}
#=====================
# Implement_For_SidDbc 
#=====================
sub Implement_For_SidDbc {

    $WhereIam = "Implement_For_SidDbc";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Implement_For_SidDbc");

    foreach $Files2Change (("$JservTop/etc/jserv.properties",
                            "$JservTop/etc/ssp_init.txt",
                            "$JservTop/etc/xmlsvcs.properties",
                            "$JservTop/etc/zone.properties")) {

       chomp($SrchCnt = `grep \"${DbTierGiven}_${Sid}.dbc\" $Files2Change |grep -v "^#" |wc -l`);
       $SrchCnt =~ s/ //g;

       @iFile = split('/',$Files2Change);
       &Print_Line("Changing ${DbTierGiven}_${Sid}.dbc to ${SID}.dbc in $iFile[$#iFile]");

       if ($SrchCnt ne "0") {
          &Backup_File("${Files2Change},$WhereIam");

          $Fname = "${Files2Change}.sclone";
          open(FR, "$Files2Change") || die "Cannot open new file $Files2Change $!\n";
          open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";
          while(<FR>) {
             $LnTxt = $_;
             $LnTxt =~ s/${DbTierGiven}_${Sid}.dbc/${Sid}.dbc/g  if (/${DbTierGiven}_${Sid}.dbc/) ;
             print FW $LnTxt;
          }
          close(FR);
          close(FW);
          system("mv $Fname $Files2Change");
       }
       print " $SrchCnt enter Changed\n";
       &Debug_Now if ($Debug);
    }
}


#==============
# Sabrix_Update 
#==============
sub Sabrix_Update {

    $WhereIam = "Sabrix_Update";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Update Sabrix Related profiles");
    my $Row;
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    &Print_Line("Updating all Sabrix Profiles to NULL");
    $St1 = q{SELECT count(*) FROM apps.fnd_profile_option_values
             WHERE  profile_option_value IS NOT NULL 
             AND    profile_option_id IN (SELECT profile_option_id
                                          FROM  apps.fnd_profile_options
                                          WHERE upper(profile_option_name) like '%SABRIX%') };

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;

    $Up1 = qq{UPDATE apps.fnd_profile_option_values
              SET    profile_option_value = NULL 
              WHERE  profile_option_id IN (SELECT profile_option_id
                                           FROM   apps.fnd_profile_options
                                           WHERE  upper(profile_option_name) like '%SABRIX%' )};
    $RtnVal=0;
    $Sh1->execute;
    ($RtnVal) = $Sh1->fetchrow_array;
    if ($RtnVal) {
       $Row = $Dbh->do($Up1) || die "\nUpdate Failed [ $Up1 ]\n", $Dbh->errstr; 
       print " Updated $Row Rows\n";
    }
    else {
       print " Already Updated\n";
    }
    $Sh1->finish;

    print "\n";

    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#============
# iProc_Setup 
#============
sub iProc_Setup {

    $WhereIam = "iProc_Setup";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Update iProc Related profiles");
    my $Row;
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    $St1 = qq{SELECT profile_option_value FROM apps.fnd_profile_option_values
              WHERE  profile_option_id = (SELECT profile_option_id
                                           FROM   apps.fnd_profile_options
                                           WHERE  profile_option_name= ?)};

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;

    $Up1 = qq{UPDATE apps.fnd_profile_option_values
              SET    profile_option_value = ?
              WHERE  profile_option_id = (SELECT profile_option_id
                                           FROM   apps.fnd_profile_options
                                           WHERE  profile_option_name= ?)};

    $Uh1 = $Dbh->prepare($Up1) || die "\nUpd Faild [ $Up1 ]\n", $Dbh->errstr;

    foreach $Prof (("PO_CXML_FROM_IDENTITY,AN01000000101-T",
                    "POR_CACERT_FILE_NAME,$ApacheConfDir/ssl.crt/ca-bundle.crt",
                    "POR_PROXY_SERVER_NAME,",
                    "ECX_UTL_LOG_DIR,/apps/orarpt/$SID/utl",
                    "ECX_UTL_XSLT_DIR,/apps/orarpt/$SID/utl")) {
       ($PName,$PVal) = split(",",$Prof);

       $PVal  = "AN01000000101" if ($SID eq "SJPROD" && $PVal eq "AN01000000101-T");
       $PVal  = "" if ($PName eq "POR_PROXY_SERVER_NAME");
   
       &Print_Line("$PName with $PVal");
       $Sh1->execute($PName);
       ($cPVal) = $Sh1->fetchrow_array;
       if ($cPVal ne $PVal) {
          $Row = $Uh1->execute($PVal,$PName) || die $Dbh->errstr; 
          print " Updated $Row Rows\n";
       }
       else {
          print " Value Exists\n";
       }
    }
    $Sh1->finish;
    $Uh1->finish;

    &Print_Line("UPDATE wf_item_attribute_values TO SET text_value='fin-workflow-emails'");
    $DoSt = q{UPDATE applsys.wf_item_attribute_values SET text_value = 'fin-workflow-emails'
              WHERE  item_type = 'APINV' AND UPPER(text_value) IN
                     (UPPER('ap_invoice'),UPPER('is-fin-erp-support'))
              AND    NAME IN ('XXCFI_APBUS_ALIAS','XXCFI_APEMAIL_ALIAS')
              AND    SUBSTR (item_key, 1,INSTR (item_key, '_')- 1) IN 
                     (SELECT invoice_id FROM ap_invoices_all
                     WHERE wfapproval_status = 'INITIATED') };
    #CCK1 $Row = $Dbh->do(q{UPDATE applsys.wf_item_attribute_values SET text_value = 'fin-workflow-emails'
    #CCK1                   WHERE  item_type = 'APINV' AND UPPER(text_value) IN
    #CCK1                         (UPPER('ap_invoice'),UPPER('is-fin-erp-support'))
    #CCK1                   AND    NAME IN ('XXCFI_APBUS_ALIAS','XXCFI_APEMAIL_ALIAS')
    #CCK1                   AND    SUBSTR (item_key, 1,INSTR (item_key, '_')- 1) IN 
    #CCK1                         (SELECT invoice_id FROM ap_invoices_all
    #CCK1                          WHERE wfapproval_status = 'INITIATED') }) || die $Dbh->errstr;

    $Row = $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr;

    print " $Row Updated\n";

    $Fname = "$ApacheConfDir/httpd.conf";
    &Print_Line("Commenting the entry 'options -FollowSymLinks'");

    $SrchStg = "FollowSymLinks";
    chomp($SrchCnt = `grep \"$SrchStg\" $Fname |grep -v \"^#\" |wc -l`);

#Newly added
    $SrchCnt =~ s/ //g;


    if ($SrchCnt ne "0") {
       &Backup_File("${Fname},iProc_Setup");
       open(FR, "$Fname") || die "Cannot open new file $Fname $!\n";
       open(FW, ">${Fname}.new") || die "Cannot open new file ${Fname}.new $!\n";
       while(<FR>) {
          $NeedToComment = 1 if (/^\<Directory \/\>/);
          $NeedToComment = 0 if (/^\<\/Directory\>/);
          $LnTxt = $_;
          $LnTxt = "\#$_" if ((/FollowSymLinks/) && ($NeedToComment)) ;
          print FW "$LnTxt";
       }
       close(FW);
       close(FR);
       system("cp ${Fname}.new ${Fname}");
       system("rm ${Fname}.new");
    }
    print " Done\n";
    $Fname = "$JservTop/etc/jserv.properties";
    &Print_Line("Change old sid value to $Sid with Begin & End Customization jserv.properties");

    &Backup_File("${Fname},iProc_Setup");
    open(FR, "$Fname") || die "Cannot open new file $Fname $!\n";
    open(FW, ">${Fname}.new") || die "Cannot open new file ${Fname}.new $!\n";
    $Modified = 0;
    while(<FR>) {
       $LnTxt = $_;
       if ((/support_addon.zip/) && (! /^#/))  {
          $LnTxt = "wrapper.classpath=$CommTop/java/support_addon.zip\n";
          $Modified = 1;
       }
       if ((/XXCFI_ICX.jar/) && (! /^#/)) {
          $LnTxt = "wrapper.classpath=$ApplTop/xxcfi/11.5.0/java/XXCFI_ICX.jar\n";
          $Modified = 1;
       }
       print FW "$LnTxt";
   }
   close(FW);
   close(FR);
   system("cp ${Fname}.new ${Fname}") if ($Modified);
   system("rm ${Fname}.new");
   print " Done\n";
   print "\n";

   &Debug_Now if ($Debug);
   system("touch $Home/DBA/clone/.${WhereIam}");

}
#************************************
# Opt_Correct_Begin_End_Customization
#************************************
sub Opt_Correct_Begin_End_Customization {
    &Print_Header("Correct the Directory name with in Begin...End Customization");
    &Correct_Begin_End_Customization ;
    print "\n";
}
#================================
# Correct_Begin_End_Customization
#================================
sub Correct_Begin_End_Customization {

    $WhereIam = "Correct_Begin_End_Customization";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    my @MyFiles;
    my $MyFix = 0;
    my $MyFileName;
    my $i = 0;
    
    chomp(@MyFiles = `ls $ApacheConfDir/*.conf $JservTop/etc/*.properties $ModTop/*.conf $ApplTop/*env $ApplTop/admin/*env $IasTop/*env $OraHome/*env $JtfTop/admin/scripts/ojspCompile.conf`);

    foreach $Fname(@MyFiles){

       @MyFname = split("/", $Fname);

       $SrchStg = "^# Begin customizations";
       #CCK chomp($SrchCnt = `grep -i \"$SrchStg\" $Fname |wc -l`);
       chomp($SrchCnt = `grep -i customizations $Fname |grep -i begin |grep "#" |wc -l`);

#Newly added
    $SrchCnt =~ s/ //g;

       $MyFix = 0;
       if ($SrchCnt > 0) {

          $MyFileName = $MyFname[$#MyFname] ;
          &Print_Line("Correcting Begin-End customization entry in $MyFileName");
          &Backup_File("${Fname},Correct_Begin_End_Customization");

          open(FR, "$Fname") || die "Cannot open new file $Fname $!\n";
          open(FW, ">/tmp/${Sid}_$MyFileName") || die "Cannot open new file /tmp/${Sid}_$MyFileName $!\n";
          while(<FR>) {
             $LnTxt = lc($_);
             $LnTxt =~ s/ //g; 
             $i = 1 if ($LnTxt =~ /#begincustomizations/);
             $i = 0 if ($LnTxt =~ /#endcustomizations/);

             $LnTxt = $_;
             if ( ($i) && (length($_) > 1 ) && ! ($_ =~ /^#/) )  {
                $ClonedFrom = lc($ClonedFrom);
                $LnTxt =~ s/\/$ClonedFrom\//\/$Sid\//g;

                $ClonedFrom = uc($ClonedFrom);
                $LnTxt =~ s/\/$ClonedFrom\//\/$SID\//g;
                
                print FW "# $_" if ("$_" ne "$LnTxt");
                $MyFix++;
             }
             print FW $LnTxt;
          }
          close(FW);
          close(FR);
          if ($MyFix) {
             system("cp /tmp/${Sid}_$MyFileName $Fname");
             system("rm /tmp/${Sid}_$MyFileName");
          }
          print " $MyFix Entry Corrected\n";
       }
   }
   &Debug_Now if ($Debug);
   system("touch $Home/DBA/clone/.${WhereIam}");

}

#*********************
# Opt_ReCreate_Log_Out
#*********************
sub Opt_ReCreate_Log_Out { 
    &Print_Header("Recreate Log and Out to Pointing to $OrarptTop");
    &ReCreate_Log_Out ;
    print "\n";
}

#=================
# ReCreate_Log_Out 
#=================
sub ReCreate_Log_Out {

    $WhereIam = "ReCreate_Log_Out";
    &Check_For_Restart($WhereIam);
    return if ($Skip);


    system("mkdir -p $ApplTop/xxkintana/log");
    system("mkdir -p $ApplTop/xxkintana/out");
    system("mkdir -p $ApplTop/xxau/11.5.0/admin");
    system("mkdir -p $ApplTop/xxau/11.5.0/bin");
    system("mkdir -p $ApplTop/xxau/11.5.0/forms/US");
    system("mkdir -p $ApplTop/xxau/11.5.0/help");
    system("mkdir -p $ApplTop/xxau/11.5.0/html");
    system("mkdir -p $ApplTop/xxau/11.5.0/java");
    system("mkdir -p $ApplTop/xxau/11.5.0/lib");
    system("mkdir -p $ApplTop/xxau/11.5.0/media");
    system("mkdir -p $ApplTop/xxau/11.5.0/mesg");
    system("mkdir -p $ApplTop/xxau/11.5.0/patch");
    system("mkdir -p $ApplTop/xxau/11.5.0/reports");
    system("mkdir -p $ApplTop/xxau/11.5.0/resource");
    system("mkdir -p $ApplTop/xxau/11.5.0/sql");
    system("mkdir -p $ApplTop/xxau/11.5.0/src");


    @TopDir = `ls -d $ApplTop/*/11.5.0`;

    foreach $Dir (@TopDir) {
       chomp($Dir);
       $Prod = (split('/',$Dir))[4];

       &Print_Line("Re-pointing log and out for ".uc($Prod));


       system("mkdir -p $OrarptTop/$Prod/log") ;
       system("mkdir -p $OrarptTop/$Prod/out") ;
 
       #----------------------
       #-- Log Directory setup
       #----------------------
       if ( -l "$Dir/log" ) {
          system("rm -f $Dir/log") ;
       }
       else {
          system("mv -f $Dir/log  $OrarptTop/$Prod 2>/dev/null");
          #CCK system("rmdir $Dir/log 2>/dev/null");
       }
       system("ln -s  $OrarptTop/$Prod/log $Dir/log");
 
       #----------------------
       #-- Out Directory setup
       #----------------------
       if ( -l "$Dir/out" ) {
          system("rm -f $Dir/out") ;
       }
       else {
          system("mv -f $Dir/out  $OrarptTop/$Prod 2>/dev/null");
          #CCK system("rmdir $Dir/out 2>/dev/null");
       }
       system("ln -s  $OrarptTop/$Prod/out $Dir/out");
       print " Done\n";
    }

    if (-d "$OrarptTop") {
       &Print_Line("Re-pointing common_top/temp");

       #CCK system("mkdir -p $OrarptTop/common_top/temp/$SID"); 
       if ( -l "$CommTop/temp" ) {
          system("rm -f $CommTop/temp");
       }
       else {
          chomp($TExt = `date +\%d\%b\%H\%M\%S`);
          system("mv $CommTop/temp $CommTop/temp_$TExt") if (-d "$OrarptTop/common_top/temp");
          system("mv -f $CommTop/temp $OrarptTop/common_top 2>/dev/null");
       }
       system("ln -s $OrarptTop/common_top/temp $CommTop/temp");
       print " Done\n";
    }

    &Print_Line("Re-pointing edi and interface directories");
    chomp(@TopDir = `find $ApplTop/xx* -type l  |egrep "edi|interface" 2>/dev/null`);

    foreach $myDir (@TopDir) {
      $myFile = $myDir;
      $myFile =~ s/$ApplTop\///;
      $myFile =~ s/11.5.0\///;
      #CCK print "$myDir ---> $myFile \n";;
      system("mkdir -p $OrarptTop/$myFile");
      system("rm -f $myDir");
      system("ln -s $OrarptTop/$myFile $myDir");

    }
    print " Done\n\n";
    $Msg = "Generate edi & interface sub dir from $Sid source env and create here, user OTHER tasks option to generate";
    push(@ToDoList, $Msg);

    &Debug_Now if ($Debug);

    system("touch $Home/DBA/clone/.${WhereIam}");

}

#**************
# Opt_Nas_Setup 
#**************
sub Opt_Nas_Setup { 

    $Str = qq{Moving the following files to $ConfDir as part of NAS};
    $Ln = length($Str);
    print "$Str\n","-"x$Ln,"\n";

    &Nas_Setup if ( $AppsNas );
    &Http_Lock_Change ;
    print "\n";
}

#==========
# Nas_Setup
#==========
sub Nas_Setup {

    $WhereIam = "Nas_Setup";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    my $MyToFile;
    my $MyFromFile;

    system("mkdir -p $ConfDir/Jserv/logs") ;
    system("mkdir -p $ConfDir/Apache/logs");
    system("mkdir -p $ConfDir/afile")      ;

    chomp($TExt = `date +\%d\%b\%H\%M\%S`);

#commented as per discusson with ravi "$ApplAdm/adconfig.txt,$ConfDir/afile/adconfig.txt"            
    foreach $Files2Move(("$JservTop/logs,$ConfDir/Jserv/logs"                           ,
                         "$ApacheTop/logs,$ConfDir/Apache/logs"                         ,
                         "$ApacheConfDir/httpd.conf,$ConfDir/afile/httpd.conf"          ,
                         "$ApacheConfDir/httpd_pls.conf,$ConfDir/afile/httpd_pls.conf"  ,
                         "$ApacheConfDir/oprocmgr.conf,$ConfDir/afile/oprocmgr.conf"    ,
                         "$ApacheConfDir/WebAgent.conf,$ConfDir/afile/WebAgent.conf"    ,
                         "$ModTop/plsql.conf,$ConfDir/afile/plsql.conf"                 ,
                         "$TnsAdmin/listener.ora,$ConfDir/afile/listener.ora")) {

                         #CCK "$iTnsAdmin/tnsnames.ora,$ConfDir/afile/tnsnames.ora"          ,
                         #CCK "$TnsAdmin/tnsnames.ora,$ConfDir/afile/tnsnames.ora"           ,

       ($MyFromFile, $MyToFile) = split(',',"$Files2Move");


       next if (! -e "$MyFromFile" );

       &Print_Line("$MyFromFile");

       if ( -l "$MyFromFile" ) {
          system("rm  $MyFromFile");
       }
       elsif ( -d "$MyFromFile" ) {
          system("mv -f $MyToFile ${MyToFile}_$TExt 2>/dev/null") if (-d "$MyToFile");
          system("mv -f $MyFromFile $MyToFile 2>/dev/null");
          #CCK system("rmdir $MyFromFile");
       }
       else {
          system("mv -f $MyFromFile $MyToFile 2>/dev/null");
       }

       system("ln -s $MyToFile $MyFromFile");
       print " Done\n";
   } 
   &Debug_Now if ($Debug);
   system("touch $Home/DBA/clone/.${WhereIam}");

} 

#=================
# Http_Lock_Change 
#=================
sub Http_Lock_Change {

    $WhereIam = "Http_Lock_Change";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    foreach $Fname (("$ApacheConfDir/httpd.conf", "$ApacheConfDir/httpd_pls.conf")) {
       if ($Fname =~ /httpd_pls/) {
          &Print_Line("Changing lock directory to $ApacheLockDir in httpd_pls.conf") ;
       }
       else {
          &Print_Line("Changing lock directory to $ApacheLockDir in httpd.conf") ;
       }

       $SrchStg = "LockFile $ApacheTop/logs/httpd.lock";
       $SrchStg = "LockFile $ApacheTop/logs/httpd_pls.lock"  if ($Fname =~ /httpd_pls/);

       chomp($SrchCnt = `grep \"$SrchStg\" $Fname |grep -v "^#" |wc -l`);
       $SrchCnt =~ s/ //g;

       $SrchStg = "LockFile $ApacheLockDir/logs/httpd.lock";
       $SrchStg = "LockFile $ApacheLockDir/logs/httpd_pls.lock"  if ($Fname =~ /httpd_pls/);

       chomp($ExistCnt = `grep \"$SrchStg\" $Fname |grep -v "^#" |wc -l`);
       $ExistCnt =~ s/ //g;

       if ($ExistCnt) {
          print " Already exists\n";
       }
       elsif ($SrchCnt ne "0") {
          system("mkdir -p $ApacheLockDir/logs");
          &Backup_File("${Fname},Http_Lock_Change");

          open(FW, ">>$Fname") || die "Cannot open new file $Fname $!\n";
          print FW "\n\n# Begin customizations\n";
          if ($Fname =~ /httpd_pls/) {
              print FW "LockFile $ApacheLockDir/logs/httpd_pls.lock\n";
          }
          else {
              print FW "LockFile $ApacheLockDir/logs/httpd.lock\n";
          }
          print FW "# End customizations \n";
          close(FW);
          print " Done\n";
       }
    }

    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#****************
# Opt_Vname_setup
#****************
sub Opt_Vname_setup { 

    if ($ApVName) {
       print "$ApTierGiven is not a virtural Name, No setup need to do ....\n" ;
       return;
    }

    &Print_Header("Modifying the following files for Virtual Name");
    &VN_Link_Dbc_File;
    &VN_Http_Change;
    &VN_Http_Pls_Change;
    &VN_Oprocmgr_Change;
    &VN_Adconfig_Change;
    &VN_Tnsnames_Change;
    &VN_Plsql_Conf_Change;
    print "\n";
}

#=================
# VN_Link_Dbc_File 
#=================
sub VN_Link_Dbc_File {

    $WhereIam = "VN_Link_Dbc_File";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    if ($DbTierGiven ne $DbTierActual) {
       &Print_Line("Linking ${DbTierActual}_${Sid}.dbc -> ${DbTierGiven}_${Sid}.dbc");
       system("rm $DbcTop/${DbTierActual}_${Sid}.dbc") if (-e "$DbcTop/${DbTierActual}_${Sid}.dbc");
       system("cd $DbcTop; ln -s ${DbTierGiven}_${Sid}.dbc ${DbTierActual}_${Sid}.dbc");
       system("cd $DbcTop; ln -s ${DbTierGiven}_${Sid}.dbc ${SID}.dbc");
       print " Done\n";
    }
    &Debug_Now if ($Debug);

    system("touch $Home/DBA/clone/.${WhereIam}");
}

#===============
# VN_Http_Change 
#===============
sub VN_Http_Change {

    $WhereIam = "VN_Http_Change";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    $Fname = "$ApacheConfDir/httpd.conf";
    &Backup_File("${Fname},VN_Http_Change");

    &Print_Line("$Fname");
    open(FW, ">${Fname}.new") || die "Cannot open new file ${Fname}.new $!\n";
    open(FR, "$Fname")        || die "Cannot open file $Fname $!\n";

    while(<FR>) {
       $LnTxt = $_;
       $LnTxt =~ s/$ApTierGiven/$ApTierActual/ if ((/ProcNode $ApTierGiven.cisco.com/) && !(/#/)) ;
       $LnTxt =~ s/$ApTierGiven/$ApTierActual/ if (/Allow from $ApTierGiven/) ;
       $LnTxt = "MinSpareServers 10\n" if (/^MinSpareServers/) ;
       $LnTxt = "MaxSpareServers 15\n" if (/^MaxSpareServers/) ;
       $LnTxt = "StartServers 5\n" if (/^StartServers/) ;
       $LnTxt = "MaxClients 512\n" if (/^MaxClients/) ;
       $LnTxt = "SSLLogLevel warn\n" if (/^SSLLogLevel/) ;

       print FW $LnTxt;
    }
    close(FW);
    close(FR);

    system("cp ${Fname}.new $Fname");
    system("rm ${Fname}.new");
    print " Done\n";

    &Debug_Now if ($Debug);

    system("touch $Home/DBA/clone/.${WhereIam}");
}

#===================
# VN_Http_Pls_Change 
#===================
sub VN_Http_Pls_Change {

    $WhereIam = "VN_Http_Pls_Change";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    $Fname = "$ApacheConfDir/httpd_pls.conf";

    if ( -f "$Fname" ) {

       &Backup_File("${Fname},VN_Http_Pls_Change");

       &Print_Line("$Fname");
       open(FW, ">$Fname.new") || die "Cannot open new file $Fname.new  $!\n";
       open(FR, "$Fname")      || die "Cannot open file $Fname $!\n";

       while(<FR>) {
          $LnTxt = $_;
          $LnTxt =~ s/$ApTierGiven/$ApTierActual/ if ((/ProcNode $ApTierGiven.cisco.com/) && !(/#/)) ;
          if ((/Allow from $ApTierGiven/) && !(/#/)) {
             $LnTxt =~ s/$ApTierGiven/$ApTierActual/ ;
          }
          print FW $LnTxt;
       }
       close(FW);
       close(FR);
       system("cp ${Fname}.new $Fname");
       system("rm ${Fname}.new");
       print " Done\n";
    }
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#===================
# VN_Oprocmgr_Change 
#===================
sub VN_Oprocmgr_Change {

    $WhereIam = "VN_Oprocmgr_Change";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    $Fname = "$ApacheConfDir/oprocmgr.conf";
    return  if (! -e "$Fname");

    &Backup_File("${Fname},VN_Oprocmgr_Change");

    &Print_Line("$Fname");
    open(FW, ">${Fname}.new") || die "Cannot open new file ${Fname}.new $!\n";
    open(FR, "$Fname")        || die "Cannot open file $Fname $!\n";

    while(<FR>) {
       $LnTxt = $_;
       $LnTxt =~ s/$ApTierGiven/$ApTierActual/ if ((/ProcNode $ApTierGiven.cisco.com/) && !(/#/)) ;
       $LnTxt =~ s/$ApTierGiven/$ApTierActual/ if (/Allow from $ApTierGiven/) ;
       print FW $LnTxt;
    }
    close(FW);
    close(FR);

    system("cp ${Fname}.new $Fname");
    system("rm ${Fname}.new");
    print " Done\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#===================
# VN_Adconfig_Change 
#===================
sub VN_Adconfig_Change {

    $WhereIam = "VN_Adconfig_Change";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    $Fname = "$ApplAdm/adconfig.txt";

    if ( -f "$Fname" ) {

       &Backup_File("${Fname},VN_Adconfig_Change");

       &Print_Line("$Fname");
       open(FW, ">${Fname}.new") || die "Cannot open new file ${Fname}.new $!\n";
       open(FR, "$Fname") || die "Cannot open new file $Fname $!\n";

       while(<FR>) {
          $LnTxt = $_;
          $LnTxt =~ s/$ApTierGiven/$ApTierActual/ if (/$ApTierGiven/) ;
          print FW $LnTxt;
       }
       close(FW);
       close(FR);
       system("cp ${Fname}.new $Fname");
       system("rm ${Fname}.new");
       print " Done\n";
   }
   &Debug_Now if ($Debug);
   system("touch $Home/DBA/clone/.${WhereIam}");
}

#===================
# VN_Tnsnames_Change 
#===================
sub VN_Tnsnames_Change {

    $WhereIam = "VN_Tnsnames_Change";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    for $Fname ("$TnsAdmin/tnsnames.ora", "$iTnsAdmin/tnsnames.ora") {
        &Backup_File("${Fname},VN_Tnsnames_Change");

        &Print_Line("$Fname");
        open(FR, "$Fname") || die "Cannot open new file $Fname $!\n";
        open(FW, ">${Fname}.new") || die "Cannot open new file ${Fname}.new $!\n";
        while(<FR>) {
           $LnTxt = $_;
           $LnTxt =~ s/$ApTierGiven/$ApTierActual/i if (/^FND/) ;
           $LnTxt =~ s/$SID/$SID,${SID}.cisco.com/i if ((/^$SID/ && /\(DESCRIPTION=/) && ! (/${SID}.cisco.com/));
           $LnTxt =~ s/$SID/$SID,${SID}.cisco.com/i if ((/^$SID=/) && ! (/${SID}.cisco.com/));
           $LnTxt =~ s/FNDSM_${ApTierActual}.cisco.com_${SID}/FNDSM_${ApTierActual}_${SID}.cisco.com/i if (/^FND/);
           print FW $LnTxt;
        }
        close(FR);

        if ($ApOtherNode ne ""){
           open(FR, "$Fname") || die "Cannot open new file $Fname $!\n";
           while(<FR>) {
              $LnTxt = $_;
              $LnTxt =~ s/$ApTierGiven/$ApOtherNode/g if (/^FND/) ;
              print FW $LnTxt;
           }
           close(FR);
        }
        close(FW);
        system("cp ${Fname}.new $Fname");
        system("rm ${Fname}.new");
        print " Done\n";
    }

    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#=====================
# VN_Plsql_Conf_Change 
#=====================
sub VN_Plsql_Conf_Change {

    $WhereIam = "VN_Plsql_Conf_Change";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    $Fname = "$ModTop/plsql.conf";
    if ( -f "$Fname" ) {

       &Backup_File("${Fname},VN_Plsql_Conf_Change");

       &Print_Line("$Fname");
       open(FR, "$Fname") || die "Cannot open new file $Fname $!\n";
       open(FW, ">$Fname.new") || die "Cannot open new file $Fname.new $!\n";
       while(<FR>) {
          $LnTxt = $_;
          $LnTxt =~ s/$ApTierGiven/$ApTierActual/g if (/ProxyPass/ && /$ApTierGiven/) ;
          print FW $LnTxt;
       }
       close(FR);
       close(FW);
       system("cp -f ${Fname}.new $Fname");
       system("rm ${Fname}.new");

       print " Done\n";
    }
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#*************** 
# Opt_Gen_Script  
#*************** 
sub Opt_Gen_Script { 

    &Print_Header("Genarating scripts in $ScriptDir");
    &Script_Gen ;
    &Dba_Tools;
    print "\n";
}

#===========
# Script_Gen 
#===========
sub Script_Gen {

    $WhereIam = "Script_Gen";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    chomp($My_ContName = `grep ^CONTEXT_NAME $Home/appl_top/${SID}.env | cut -d\"=\" -f2`);
    $My_ContName =~ s/\"//g;

    foreach $Fname (("start_all.sh"  , "stop_all.sh", "bounce_apache.sh",
                     "kill_apache.sh", "kill_all.sh", "kill_cm.sh", "kill_nocm.sh" )) {

       &Print_Line("Creating $Fname");

       open(FW, ">$ScriptDir/$Fname") || die "Cannot open new file $Fname $!\n";

       print FW qq{#!/bin/ksh\n\n};
       print FW qq{. \$HOME/appl_top/APPSORA.env\n\n};


       print FW qq{HOST=`uname -n`\n};
       print FW qq{SID=`echo \$TWO_TASK|tr "[:lower:]" "[:upper:]"`\n};
       print FW qq{sid=\$(echo \$LOGNAME | cut -c3-)\n};
       print FW qq{VnamePointsHere="NO"\n};
       print FW qq{VnameExist="NO"\n\n};

       print FW qq{AppsPwdFile=\$ORACLE_HOME/reports60/server/CGIcmd.dat\n};
       print FW qq{Usr=`grep -i "userid=APPS" \$AppsPwdFile|awk {'print \$2'}|cut -d'\@' -f1|sort -u|cut -d'=' -f2`\n};
       if ("$My_ContName") {
          print FW qq{ContextName="\$CONTEXT_NAME"\n};
       }
       else {
          print FW qq{ContextFile=$XmlFile\n\n};
          print FW qq{ContextName=\`grep oa_context_name \$ContextFile |cut -d'>' -f2|cut -d'<' -f1\`\n};
          print FW qq{ContextName=\`echo \$ContextName|tr " " ""\`\n};
          print FW qq{chmod 700 \$HOME/common_top/admin/scripts/\$ContextName/adcmctl.sh\n};
       }

       if ($Fname eq "start_all.sh") {
print FW q{



#------------------------------------------------------------------------------------------
# Check for virtual existance
#------------------------------------------------------------------------------------------
if ( `ping -c 1 cm-$sid > /dev/null 2>&1` )
then
    VnameExist="YES"
fi


#------------------------------------------------------------------------------------------
# Check for cluster(cm-<sid>) existance and pointing here or not
#------------------------------------------------------------------------------------------
(
  ( test -x /usr/bin/host && host cm-$sid | tail -3 ) || nslookup cm-$sid 2>/dev/null | tail +2
  ( test -x /sbin/ifconfig && /sbin/ifconfig -a ) || netstat -niv
) | awk -F'[: ]+' '/address |Address: / { inet = $NF; }
                   /inet addr:|^lan/ && $4 == inet { here = 1; }
    END            { exit here ? 0 : 1 }
  ' && VnamePointsHere="YES";


#------------------------------------------------------------------------------------------
# Start concurren process in case of cluser point here or virtual name doesnot exist
#------------------------------------------------------------------------------------------
if [ "$VnamePointsHere" = "YES" -o "$VnameExist" = "NO" ]
then
   echo
   echo "****************************************************************************"
   if [ "$VnamePointsHere" = "YES" ]
   then
      echo "cm-$sid is pointing here, Starting ONLY Concurrent Manager"
   else
      echo "cm-$sid does not exists, Starting Concurrent Manager"
   fi
   echo "****************************************************************************"
   echo

   $HOME/common_top/admin/scripts/$ContextName/adalnctl.sh start

   #--------------------------------------------
   # Update the node name in case of CM failover
   #--------------------------------------------
   sqlplus -s $Usr <<EOF

   COL logfile_node_name FORMAT A30
   COL outfile_node_name FORMAT A30
   
   SELECT DISTINCT logfile_node_name, outfile_node_name FROM applsys.fnd_concurrent_requests;

   PROMPT
   PROMPT Updating fnd_concurrent_requests for the node name in case of CM Failover
   PROMPT

   UPDATE applsys.fnd_concurrent_requests
   SET outfile_node_name= UPPER('$HOST'), logfile_node_name= UPPER('$HOST')
   WHERE ( outfile_node_name <> UPPER('$HOST') OR
           logfile_node_name <> UPPER('$HOST') ) ;
   COMMIT;

   SELECT DISTINCT logfile_node_name, outfile_node_name FROM applsys.fnd_concurrent_requests;

EOF

   chmod 700 $HOME/common_top/admin/scripts/$ContextName/adcmctl.sh
   $HOME/common_top/admin/scripts/$ContextName/adcmctl.sh  start $Usr
fi


#------------------------------------------------------------------------------------------
# Start non-concurren process in case of Cluser not point here or virtual name doesnot exist
#------------------------------------------------------------------------------------------
if [ "$VnamePointsHere" = "NO" -o "$VnameExist" = "NO" ]
then
   echo
   echo "****************************************************************************"
   if [ "$VnamePointsHere" = "NO" ]
   then
      echo "cm-$sid is not pointing here, Starting All EXCEPT Concurrent Manager"
   else
      echo "cm-$sid does not exists, Starting other Process"
   fi
   echo "****************************************************************************"
   echo

   chmod 000 $HOME/common_top/admin/scripts/$ContextName/adcmctl.sh
   $HOME/common_top/admin/scripts/$ContextName/adstrtal.sh $Usr
   chmod 700 $HOME/common_top/admin/scripts/$ContextName/adcmctl.sh
fi

rm -f $HOME/common_top/${HOST}_${SID}_DOWN 2>/dev/null

};
       }
       elsif ($Fname eq "stop_all.sh") {

print FW q{

WHAT2KILL="kill_all.sh"
CMPROCESS="-v grep"
NONCMPROCESS="-v grep"

touch $HOME/common_top/${HOST}_${SID}_DOWN 

#------------------------------------------------------------------------------------------
# Check for virtual existance
#------------------------------------------------------------------------------------------
if ( `ping -c 1 cm-$sid > /dev/null 2>&1` )
then
    VnameExist="YES"
fi


#------------------------------------------------------------------------------------------
# Check for cluster(cm-<sid>) existance and pointing here or not
#------------------------------------------------------------------------------------------
(
  ( test -x /usr/bin/host && host cm-$sid | tail -3 ) || nslookup cm-$sid 2>/dev/null | tail +2
  ( test -x /sbin/ifconfig && /sbin/ifconfig -a ) || netstat -niv
) | awk -F'[: ]+' '/address |Address: / { inet = $NF; }
                   /inet addr:|^lan/ && $4 == inet { here = 1; }
    END            { exit here ? 0 : 1 }
  ' && VnamePointsHere="YES";


#------------------------------------------------------------------------------------------
# Stop non-concurren process in case of cluser not point here or virtual name doesnot exist
#------------------------------------------------------------------------------------------
if [ "$VnamePointsHere" = "NO" -o "$VnameExist" = "NO" ]
then
   echo
   echo "****************************************************************************"
   if [ "$VnamePointsHere" = "NO" ]
   then
      echo "cm-$sid is not pointing here, Stopping All EXCEPT Concurrent Manager"
   else
      echo "cm-$sid does not exists, Stopping other Process"
   fi
   echo "****************************************************************************"
   echo
   NONCMPROCESS="-v FND"
   WHAT2KILL="kill_nocm.sh"

   chmod 000 $HOME/common_top/admin/scripts/$ContextName/adcmctl.sh
   $HOME/common_top/admin/scripts/$ContextName/adstpall.sh $Usr
   chmod 700 $HOME/common_top/admin/scripts/$ContextName/adcmctl.sh
fi


#------------------------------------------------------------------------------------------
# Stop concurren process in case of cluser point here or virtual name doesnot exist
#------------------------------------------------------------------------------------------
if [ "$VnamePointsHere" = "YES" -o "$VnameExist" = "NO" ]
then
   echo
   echo "****************************************************************************"
   if [ "$VnamePointsHere" = "YES" ]
   then
      echo "cm-$sid is pointing here, Stopping ONLY Concurrent Manager"
   else
      echo "cm-$sid does not exists, Stopping Concurrent Manager"
   fi
   echo "****************************************************************************"
   echo

   CMPROCESS="FND"
   WHAT2KILL="kill_cm.sh"

   chmod 700 $HOME/common_top/admin/scripts/$ContextName/adcmctl.sh
   $HOME/common_top/admin/scripts/$ContextName/adcmctl.sh stop $Usr
   $HOME/common_top/admin/scripts/$ContextName/adalnctl.sh stop
fi


#------------------------------------------------------------------------------------------
# Waiting for the process to come down, if not kill script will used to clean the process
#------------------------------------------------------------------------------------------
echo; echo;
x=0
while true
do
   ps -ef|grep ^$LOGNAME |grep $NONCMPROCESS |grep $CMPROCESS |egrep -v "ksh|grep|vi|su -|ps -ef" >/dev/null
   if [ $? -ne 0 ]
   then
      break
   fi
   echo "Waiting for $RUNNINGS process to come down ... Sleeping 30 sec [$x/300]"
   sleep 30
   x=`expr $x + 30`
   if [ "$x" -eq 300 ]
   then
      echo
      echo Killing the process using $HOME/common_top/admin/scripts/$ContextName/$WHAT2KILL
      echo

      $HOME/common_top/admin/scripts/$ContextName/$WHAT2KILL
      break
      echo
      echo All process are down now.
      echo
   fi
done

};
       }
       elsif ($Fname eq "kill_all.sh") {
          print FW "for proc in \`ps -ef|grep ^\$LOGNAME|egrep -v \"grep|ksh|vi|smartclone\" |awk \'{print \$2}\'\`\n";
          print FW "do\n";
          print FW "   kill -9 \$proc\n";
          print FW "done\n";
       }
       elsif ($Fname eq "kill_apache.sh") {
          print FW "for proc in \`ps -ef|grep ^\$LOGNAME|grep -v grep |egrep \"httpd|java\" |".
                   "grep -v ksh |awk \'{print \$2}\'\`\n";
          print FW "do\n";
          print FW "   kill -9 \$proc\n";
          print FW "done\n";
       }
       elsif ($Fname eq "kill_cm.sh") {
          print FW "for proc in \`ps -ef|grep ^\$LOGNAME|grep -v grep |egrep \"FND|APPS\" |".
                   "grep -v ksh |awk \'{print \$2}\'\`\n";
          print FW "do\n";
          print FW "   kill -9 \$proc\n";
          print FW "done\n";
       }
       elsif ($Fname eq "kill_nocm.sh") {
          print FW "for proc in \`ps -ef|grep ^\$LOGNAME|grep -v grep |egrep -v \"FND|APPS\" |".
                   "grep -v ksh |awk \'{print \$2}\'\`\n";
          print FW "do\n";
          print FW "   kill -9 \$proc\n";
          print FW "done\n";
       }
       elsif ($Fname eq "bounce_apache.sh") {
          print FW "cd \$HOME/common_top/admin/scripts/$ContextName\n";

          print FW "SID=\`echo \$TWO_TASK|tr \"[:lower:]\" \"[:upper:]\"\`\n";
          print FW "sid=\`echo \$SID|tr \"[:upper:]\" \"[:lower:]\"\`\n";

          print FW "Ext=\`date \+\%d\%b\%Y\%H\%M\%S\`\n";
          print FW "Dt=\`date\`\n";
          print FW "MailUser=\"release2-dba,user1,user2\"\n";
          print FW "WhoDid=\`ls -l /tmp/$SID/apache_bounce | cut -d \" \" -f5\`\n";

          print FW "echo \$WhoDid\n";

          print FW "if [ \"\$WhoDid\" = \"user1\" -o \"\$WhoDid\" = \"user2\" ]\n";
          print FW "then\n";

          print FW "   DefHttpds=\`grep \"\^MaxSpareServers\" \$HOME/product/iAS/Apache/".
                   "Apache/conf/httpd.conf |cut -d \" \" -f2\`\n";
          print FW "   echo Bouncing .....\n\n";
          print FW "   /usr/bin/rm -f /tmp/$SID/apache_bounce\n";
          print FW "   ./adapcctl.sh stop\n";

          print FW "   rm -rf \$OA_HTML/_pages\n";


          print FW "   echo; echo;\n";
          print FW "   x=0\n";
          print FW "   while true\n";
          print FW "   do\n";
          print FW "      CurHttpds=\`ps -eaf |grep ^\$LOGNAME|grep -v grep |grep httpd |wc\`\n";
          print FW "      if [ \"\$CurHttpds\" = \"0\" ]\n";
          print FW "      then\n";
          print FW "         break\n";
          print FW "      fi\n";
          print FW "      echo \"Waiting for Httpd process to come down ... Sleeping 30 sec [\$x/180]\"\n";
          print FW "      sleep 30\n";
          print FW "      x=\`expr \$x + 30\`\n";
          print FW "      if [ \"\$x\" -eq 180 ]\n";
          print FW "      then\n";

          print FW "         for proc in \`ps -ef|grep ^\$LOGNAME|grep -v grep |".
                   "egrep \"httpd|java\" |awk \'{print \$2}\'\`\n";
          print FW "         do\n";
          print FW "            kill -9 \$proc\n";
          print FW "         done\n";
          print FW "         break\n";
          print FW "      fi\n";
          print FW "   done\n";

          print FW "   sleep 60\n";

          print FW "   ./adapcctl.sh start\n";
          print FW "   mailx -s \"\$SID Apache bounced by \$WhoDid at \$Dt\" \$MailUser </dev/null;\n";

          print FW "fi\n";
          print FW "echo Done .....\n";

       }
       print FW "\n\n";
       close(FW);
       system("chmod 700 $ScriptDir/$Fname");
       print " Done\n";
   }
   &Debug_Now if ($Debug);

    system("touch $Home/DBA/clone/.${WhereIam}");
}

#==========
# Dba_Tools
#==========
sub Dba_Tools {

    $WhereIam = "Dba_Tools";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    system("mkdir -p $Home/DBA/bin");
    $Fname = "$Home/DBA/bin/s";

    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";

print FW  q{#!/bin/ksh
export Usr=`grep -i "userid=APPS" $ORACLE_HOME/reports60/server/CGIcmd.dat |awk {'print $2'} |cut -d'@' -f1 |sort -u|cut -d'=' -f2`
sqlplus $Usr @$HOME/DBA/bin/set

};
    close(FW);

    $Fname = "$Home/DBA/bin/set.sql";

    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";

print FW  q{
set lines 120 feedback off pagesize 3 heading off serverout on verify off

col new_prompt noprint new_value nprompt
col t_sid       noprint new_value nsid

btitle left '------------------------------------------------------------------------------------------------------------------------'
ttitle left '------------------------------------------------------------------------------------------------------------------------'

alter session set nls_date_format= 'MON-DD-YYYY HH24:MI'
/
SELECT a.instance_number||'.'||c.name||' | Host : '|| a.host_name ||' | '||
       user||' | Started -> '||to_char(a.startup_time, 'DD-MON HH24:MI:SS') ||
       ' | Cr -> '|| to_char(c.created, 'DD-MON HH24:MI:SS') || ' | '||
       log_mode ||' | ' || logins , name new_prompt
FROM   v$instance a, v$database c
/
ttitle off
btitle off
select to_char(sid) t_sid from v$session where audsid = USERENV('sessionid')
/

alter session set nls_date_format= 'MON-DD-YYYY HH24:MI:SS'
/
PROMPT

set pagesize 100 heading on long 9999999 sqlprompt "&nprompt-&nsid> "
set feedback on

define _EDITOR=vi

undefine nprompt nsid
clear buffer

};
    close(FW);

    $Fname = "$Home/DBA/bin/chg_application_pwd.sh";
    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";

print FW  q{#!/bin/ksh

. $HOME/.profile

Dfile=$ORACLE_HOME/reports60/server/CGIcmd.dat

Usr=`grep -i "userid=APPS" $Dfile |awk {'print $2'} |cut -d'@' -f1 |sort -u|cut -d'=' -f2`
sqlplus -s $Usr <<EOF
declare
   p_out boolean ;
begin
   p_out := fnd_user_pkg.changepassword('$1', 'WELCOME');
end ;
/
EOF

};
    close(FW);

    $Fname = "$Home/DBA/bin/genfrm.sh";
    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";

print FW  q{#!/bin/ksh

Usr=`grep -i "userid=APPS" $ORACLE_HOME/reports60/server/CGIcmd.dat |awk {'print $2'} |cut -d'@' -f1 |sort -u|cut -d'=' -f2`
export FORMS60_PATH=$AU_TOP/resource:$AU_TOP/forms/US:.
f60gen module=$AU_TOP/forms/US/$1 userid=$Usr output_file=./$1.fmx module_type=form batch=yes compile_all=special Statistics=yes

ls -l $AU_TOP/forms/US/$1.err ./$1.fmx

};
    close(FW);
    system("chmod -R 700 $Home/DBA/bin");
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}


#*************** 
# Opt_Custom_Env 
#*************** 
sub Opt_Custom_Env { 
    &Print_Header("Implementing XXCUSTOM.env");
    &Custom_Env;
    print "\n";
}

#===========
# Custom_Env
#===========
sub Custom_Env {
  
    $WhereIam = "Custom_Env";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    if (-f "$ApplTop/XXCUSTOM.env" ) {

       &Print_Line("XXCUSTOM.env exists, adding to $ApplTop/${ContextName}.env");

       $Fname   = "$ApplTop/${ContextName}.env";
       $SrchStg = "$ApplTop/XXCUSTOM.env";

       chomp($SrchCnt = `grep \"$SrchStg\" $Fname |wc -l`);
       $SrchCnt =~ s/ //g;

       if ($SrchCnt) {
           print " Already Exists\n";
       }
       else {
           &Backup_File("${Fname},Custom_Env");
           open(FW, ">>$Fname") || die "Cannot open the file $Fname $!\n";
           print FW "\n# Begin customizations\n";
           print FW ". $ApplTop/XXCUSTOM.env\n";
           print FW "# End customizations\n\n";
           close(FW);
           print " Done\n";
       }
    }
    else {
       $Msg = '$APPL_TOP/XXCUSTOM.env doesnot exist, Copy from other env. if needed';
       push(@ToDoList, $Msg);
       print "     $Msg\n";
    }
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#************************ 
# Opt_Sync_Old_Patch_Logs  
#************************ 
sub Opt_Sync_Old_Patch_Logs { 
    &Print_Header("Syncing Old Patch Logs");
    &Sync_Old_Patch_Logs;
    print "\n";
}

#====================
# Sync_Old_Patch_Logs
#====================
sub Sync_Old_Patch_Logs {
    $WhereIam = "Sync_Old_Patch_Logs";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    my $t;
    my $x = 0;

    chomp(@OldLog = `ls -d $ApplAdm/*/log |grep -v $SID`);

    foreach $pLog (@OldLog) {
       $x++;  
       $t=$pLog;
       $t =~ s/$ApplAdm\///;
       next if ($t =~ /_/);
       &Print_Line("Moving old Patch Logs from $t to $SID/log");
       system("mv $pLog/* $ApplAdm/$SID/log 2>/dev/null");
       print " Done\n";
    }
    if (!($x)) {
       &Print_Line("No old Patch Logs exist to move");
    }
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#********************* 
# Opt_Update_Site_Name
#********************* 
sub Opt_Update_Site_Name {    

    $WhereIam = "Opt_Update_Site_Name";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Updating Site Level profile");  
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    $St1 = q{SELECT to_char(created,'MON DD, YYYY') from v$database};
    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    ($CreatedDt) = $Sh1->fetchrow_array;
    $Sh1->finish;
    $UpdSiteName = "$SID (Copy of $ClonedFrom as of $CreatedDt)";

    #CCK print "     Enter The Site Name to Update : ";
    #CCK chomp($UpdSiteName = <STDIN>);
    #CCK print "\n";
    #CCK die "     Site Name cannot be NULL as per our standard \n\n" if ("$UpdSiteName" eq "");

    chomp($TExt = `date +\%d\%b\%H\%M\%S`);
    &Backup_Tables("applsys.fnd_profile_options","fnd_profile_option_$TExt");
    &Backup_Tables("applsys.fnd_profile_option_values","fnd_profile_optval_$TExt");
    &Update_Profile("SITENAME", "$UpdSiteName");    
    &Update_Profile("SIGNON_PASSWORD_LENGTH","8");    
    &Update_Profile("FND_COLOR_SCHEME","blue")   ;    
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
    $Dbh->disconnect;
}

#========================
# Java_Io_File_Permission
#========================
sub Java_Io_File_Permission {    

    $WhereIam = "Java_Io_File_Permission";
    
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    &Print_Line("Graning I/O Read,Write File permission to APPS");
    $St1 = qq{begin 
                dbms_java.grant_permission('APPS','java.io.FilePermission','/apps/orarpt/$SID/utl','write,read');
              end;
              \
             };
    $Dbh->do($St1) || die "\nStmt Faild [ $St1 ]\n", $Dbh->errstr;
    print " Done\n";
    $Dbh->disconnect;

    &Debug_Now if ($Debug);
    print "\n";
}

#======================
# Update_WF_Global_Pref
#======================
sub Update_WF_Global_Pref {    

    $WhereIam = "Update_WF_Global_Pref";

    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    chomp($TExt = `date +\%d\%b\%H\%M\%S`);
    &Backup_Tables("apps.wf_resources","wf_resources_$TExt");
    ($File, $Phase) = split(',',$_[0]);

    $WfValue = "Workflow Administrator";
    $WfValue = "Cisco Workflow Administrator" if ($_[0] eq "SJ");

    $St1 = qq{UPDATE apps.wf_resources SET text=(SELECT name FROM apps.wf_roles  
                     WHERE display_name ='$WfValue')
              WHERE name='WF_ADMIN_ROLE'};
    $Row = $Dbh->do($St1) || die "\nStmt Faild [ $St1 ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";
    $Dbh->disconnect;
    print "\n";
}

#====================
# Update_Ipay_Related
#====================
sub Update_Ipay_Related {    

    $WhereIam = "Update_Ipay_Related";

    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    chomp($TExt = `date +\%d\%b\%H\%M\%S`);

    $St1 = qq{SELECT fnd_profile.VALUE('APPS_SERVLET_AGENT') FROM dual};

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    $iPayVal = 0;
    ($iPayVal) = $Sh1->fetchrow_array;
    $Sh1->finish;

    &Print_Line("Updating IBY.IBY_BEPINFO Url to $iPayVal");
    $UpdStr= qq{ UPDATE iby.iby_bepinfo bi SET bi.baseurl='$iPayVal' 
                 WHERE bi.name IN ('CyberSource','SamplePaymentSystem') };

    $Row = $Dbh->do("$UpdStr") || die "\nPrep Faild [ $UpdStr ]\n", $Dbh->errstr;

    print " $Row Row Updated\n";

    &Print_Line("Validating the above update IBY.IBY_BEPINFO");
    $St1 = qq{ SELECT count(*) FROM iby.iby_bepinfo
               WHERE  baseurl = '${HomeUrl}/oa_servlets' 
               AND    name IN ('CyberSource','SamplePaymentSystem') };

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    $iPayVal = 0;
    ($iPayVal) = $Sh1->fetchrow_array;
    $Sh1->finish;

    if ($iPayVal eq 2 ) {
       print " Vaild\n"; 
    }
    else {
       print " Not Vaild\n"; 
       print "        Execute and see the following sql \n";
       print "        $UpdStr\n"; 
       die;
    }

    &Print_Line("Updating Profile IBY_SYS_SEC_KEY to null");
    $UpdStr= qq{ UPDATE apps.fnd_profile_option_values
                 SET    profile_option_value = null
                 WHERE  profile_option_id = (SELECT profile_option_id 
                                             FROM   apps.fnd_profile_options 
                                             WHERE  profile_option_name='IBY_SYS_SEC_KEY') };

    $Row = $Dbh->do($UpdStr) || die "\nStmt Failed [$UpdStr]\n",$Dbh->errstr;
    print " $Row Row Updated\n";

    &Print_Line("Validating Profile IBY_SYS_SEC_KEY");
    $St1 = qq{SELECT count(*) FROM apps.fnd_profile_option_values
              WHERE  profile_option_id = (SELECT profile_option_id 
                     FROM apps.fnd_profile_options WHERE profile_option_name='IBY_SYS_SEC_KEY')
              AND profile_option_value is null };

    $Sh1 = $Dbh->prepare($St1) || die "Prep Faile [$St1]\n",$Dbh->errstr;
    $Sh1->execute;
    $iPayVal = 0;
    ($iPayVal) = $Sh1->fetchrow_array;
    $Sh1->finish;

    if ($iPayVal eq 1 ) {
       print " Vaild\n"; 
    }
    else {
       print " Not Vaild\n"; 
       print "        Execute and see the following sql \n";
       print "        $UpdStr\n"; 
       die;
    }
    
    $Dbh->disconnect;

    &Debug_Now if ($Debug);
}

#==============================
# Update_Fnd_User_For_User_Guid
#==============================
sub Update_Fnd_User_For_User_Guid {    

    $WhereIam = "Update_Fnd_User_For_User_Guid";

    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    chomp($TExt = `date +\%d\%b\%H\%M\%S`);
    &Backup_Tables("applsys.fnd_user","fnd_user_$TExt");

    &Print_Line("Updating FND_USER to set NULL for the col USER_GUID");
    $UpdStr= qq{UPDATE applsys.fnd_user SET user_guid = NULL};

    $Row = $Dbh->do("$UpdStr") || die "\nUpdt Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";
    $Dbh->disconnect;
    &Debug_Now if ($Debug);
}

#===============
# Update_Profile
#===============
sub Update_Profile {    

    $WhereIam = "Update_Profile";
    ($ProfileName, $ProfileValue) = @_;

    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    $St1 = qq{SELECT profile_option_value FROM apps.fnd_profile_option_values
              WHERE  profile_option_id = (SELECT profile_option_id
                                          FROM   apps.fnd_profile_options
                                          WHERE  profile_option_name= '$ProfileName')
              AND    level_id = 10001};

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    ($cPVal) = $Sh1->fetchrow_array;
    $Sh1->finish;

    if ($cPVal eq $PVal) {
       &Print_Line("Updating Profile $ProfileName to \"$ProfileValue\"");
       print " Value already set\n";
    }
    else {
       &Print_Line("Updating Profile $ProfileName to \"$ProfileValue\"");
       $UpdStr= qq{UPDATE applsys.fnd_profile_option_values
                   SET    profile_option_value = '$ProfileValue'
                   WHERE  profile_option_id    = (SELECT profile_option_id 
                                                  FROM   applsys.fnd_profile_options
                                                  WHERE  profile_option_name ='$ProfileName')
                   AND    level_id = 10001};

       $Row = $Dbh->do("$UpdStr") || die "\nUpdt Faild [ $UpdStr ]\n", $Dbh->errstr;
       print " $Row Row Updated\n";
    }
    $Dbh->disconnect;
    &Debug_Now if ($Debug);
}

#====================
# Grant_On_Utl_Recomp
#====================
sub Grant_On_Utl_Recomp {

    $WhereIam = "Grant_On_Utl_Recomp";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Granting privilege on UTL_RECOMP under APPS");
    $UtlReCompGranted = 0;
    $UtlReCompSynonymExists = 0;

    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    &Print_Line("Creating synonym UTL_RECOMP under APPS");
    $St1 = q{SELECT /*+ RULE */ 1 FROM dba_synonyms 
             WHERE  synonym_name ='UTL_RECOMP' 
             AND    table_owner = 'SYS' 
             AND    owner = 'APPS' };
    #CCK1 $Sh1 = $Dbh->prepare(q{SELECT /*+ RULE */ 1 FROM dba_synonyms 
    #CCK1                        WHERE  synonym_name ='UTL_RECOMP' 
    #CCK1                        AND    table_owner = 'SYS' 
    #CCK1                        AND    owner = 'APPS' }) || die $Dbh->errstr;

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    ($UtlReCompSynonymExists) = $Sh1->fetchrow_array;

    $Sh1->finish;
    if ( $UtlReCompSynonymExists ) {
       print " Already Exists\n";
    }
    else {
     
       $DoSt = qq{CREATE SYNONYM utl_recomp FOR sys.utl_recomp};
       #CCK1 $Row = $Dbh->do("CREATE SYNONYM utl_recomp FOR sys.utl_recomp") || die $Dbh->errstr;
       $Row = $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr;
       print " Done\n";
    }
    
    &Print_Line("Verifying  Execute privilege on sys.utl_recomp for APPS");

    $St1 = q{SELECT /*+ RULE */ 1 FROM dba_tab_privs 
             WHERE  grantor = 'SYS' 
             AND    grantee = 'APPS'     
             AND    table_name ='UTL_RECOMP'
             AND    privilege = 'EXECUTE'};

    #CCK1 $Sh1 = $Dbh->prepare(q{SELECT /*+ RULE */ 1 FROM dba_tab_privs 
    #CCK1                        WHERE  grantor = 'SYS' 
    #CCK1                        AND    grantee = 'APPS'     
    #CCK1                        AND    table_name ='UTL_RECOMP'
    #CCK1                        AND    privilege = 'EXECUTE'}) || die $Dbh->errstr;

    $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
    $Sh1->execute;
    ($UtlReCompGranted) = $Sh1->fetchrow_array;
    $Sh1->finish;

    $Dbh->disconnect;

    if ( $UtlReCompGranted ) {
       print " Already Exists\n";
    }
    else {
       print " not Exists, Creating...\n";
       if (! defined($SystemPwd) ) {
          print "     Enter The SYS Password is : ";
          chomp($SystemPwd = <STDIN>);

          die "     SYS Password cannot be NULL\n\n" if ("$SystemPwd" eq "");

       }
       &Print_Line("Verifying SYS password");
       $Dbh = &Connect_Db("SYS","$SystemPwd", "$SID");
       print " Done\n\n";

       &Print_Line("Granting Execute privilege on sys.utl_recomp to APPS");
       $DoSt = qq{GRANT EXECUTE ON utl_recomp TO apps} || die $Dbh->errstr;
       #CCK1 $Row = $Dbh->do("GRANT EXECUTE ON utl_recomp TO apps") || die $Dbh->errstr;
       $Row = $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr;
       print " Done\n";
       $Dbh->disconnect;
    }
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#====================== 
# Opt_Gen_Edi_Interface
#====================== 
sub Opt_Gen_Edi_Interface {
    $WhereIam = "Opt_Gen_Edi_Interface";
    print "\n";
    &Print_Line("Generating edi, interface creation script");
    chomp(@Edi = `find $OrarptTop/*/edi -type d`);
    chomp(@Interface = `find $OrarptTop/*/interface -type d 2>/dev/null`);

    $Fname = "$CloneBackupDir/create_edi_interface_directory.sh";
    system("chmod 600 $Fname") if ( -f $Fname);;
    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";

    foreach $eDir (@Edi, @Interface) {

       $file=stat("$eDir");
       $mode=$file->mode;
       $permission=sprintf("%o",$mode);
       $permission = substr($permission,2);

       $eDir =~ s/$SID/\$TWO_TASK/;

       print FW "mkdir -p $eDir\n";
       print FW "chmod $permission $eDir\n\n";

    }
    close(FW);
    print " Done\n";

    print "     Use $Fname to create directories in Target env.\n";
    print "\n";
    &Debug_Now if ($Debug);
}

#CCK #*************************** 
#CCK # Opt_Add_Entry_To_Threshold
#CCK #*************************** 
#CCK sub Opt_Add_Entry_To_Threshold {
    #CCK &Print_Header("Adding an entry to /.THRESHOLD for this Filesystem $Home");
    #CCK &Threshold_Entry ;
    #CCK print "\n";
#CCK }

#CCK #================
#CCK # Threshold_Entry 
#CCK #================
#CCK sub Threshold_Entry {
#CCK 
    #CCK $WhereIam = "Threshold_Entry";
    #CCK $Fname = "/.THRESHOLD";
    #CCK &Print_Line("Adding $Machine:fs:$Home:97:email:$MailId:99:page:$PagerId:");
#CCK 
    #CCK $SrchStg = "$Home";
    #CCK chomp($SrchCnt = `grep \"$SrchStg\" $Fname |wc -l`);
#CCK 
    #CCK $SrchCnt =~ s/ //g;
#CCK #Newly added
#CCK 
    #CCK if ($SrchCnt eq "0") {
       #CCK &Backup_File("${Fname},Threshold_Entry");
#CCK 
       #CCK $MailId       = 'erp-db-monitor';
       #CCK $PagerId      = 'erp-db-duty';
       #CCK chomp($MailId = `grep ^mailto $ApplTop/XXCUSTOM.env |cut -d \"=\" -f2`) if (-f "$ApplTop/XXCUSTOM.env");
       #CCK $PagerId      = "r2-dba-duty" if ($MailId eq "release2-monitor") ;
       #CCK $PagerId      = "everest-dba-duty" if ($MailId eq "rel-everest-monitor");
#CCK 
       #CCK open(FW, ">>$Fname") || die "Cannot open new file $Fname $!\n";
       #CCK print FW "$Machine:fs:$Home:97:email:$MailId:99:page:$PagerId:\n";
       #CCK close(FW);
    #CCK }
    #CCK print " Done\n";
    #CCK &Debug_Now if ($Debug);
#CCK }

#************************* 
# Opt_Add_Entry_To_Appstab
#************************* 
sub Opt_Add_Entry_To_Appstab {
    return if ($Os eq "LINUX");
    &Print_Header("Adding an entry to /etc/appstab");
    &AppsTab_Entry ;
    print "\n";
}

#==============
# AppsTab_Entry 
#==============
sub AppsTab_Entry {

    $WhereIam = "AppsTab_Entry";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    if (! ( -f "/var/opt/oracle/appstab")) {
       print "/var/opt/oracle/appstab Not exists!!!.\n";
       return;
    }
    chomp($IsItEntered = `grep ^$SID /var/opt/oracle/appstab`);

    if ("$IsItEntered" eq "" ) {
       &Print_Line("Adding $SID:$Owner:$Home:$ApsVersion:$ApTierGiven:$DbTierGiven:Y to /etc/appstab");
       system("echo $SID:$Owner:$Home:$ApsVersion:$ApTierGiven:$DbTierGiven:Y >> /var/opt/oracle/appstab");
    }
    else {
       &Print_Line("Entry already exist in /etc/appstab");
    }
    print " Done\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#************************ 
# Opt_Setup_Apps_Cron_Job  
#************************ 
sub Opt_Setup_Apps_Cron_Job { 
    &Print_Header("Creating cron job for apps");
    &Apps_CronJob_Setup;
    print "\n";
}

#===================
# Apps_CronJob_Setup
#===================
sub Apps_CronJob_Setup { 

    $WhereIam = "Apps_CronJob_Setup";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    $Fname = "$Home/${Sid}.cron";
    #system("crontab -l > $Home/${Sid}.cron");

    $MyScriptDir = "/usr/tools/oracle/apps/monitor" ;
    $MyScriptDir = "/apps/share/oracle/monitor" if ($Os eq "LINUX");

    push(@ToDoList, "Enable the commented cron jobs appropriately");
    &Print_Line("Creating cron job file $Fname");
    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";
#j----
#skovi
#j----
    print FW "#-------- End of CM node cron--------------------------------\n";

    close(FW);
    print " Done\n";
    system("crontab $Fname");
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#************************ 
# Opt_Schedule_Purge_Jobs  
#************************ 
sub Opt_Schedule_Purge_Jobs { 
    $WhereIam = "Opt_Schedule_Purge_Jobs";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Scheduling purge concurrent job");

    chomp($PurgeStDt=uc(`date +"%d-%b-%Y %X"`));

    &Print_Line("Submitting Purge Concurrent Request to delete 4 days old");
    print " Done\n     ";

    $Fname = "./smartconcsub.ksh";
    open(CONC, ">$Fname") || die "Cannot open new file $Fname $!\n";

    print CONC ". $ApplTop/APPSORA.env\n";
    print CONC "$FndTop/bin/CONCSUB APPS/$CurApsPwd SYSADMIN \'System Administrator\' SYSADMIN WAIT=N CONCURRENT FND FNDCPPUR START='\"$PurgeStDt\"' REPEAT_DAYS=1 ALL Age 4\n";
    close(CONC);

    system("sh $Fname");
    system("rm $Fname");
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#**************************** 
# Opt_Create_Sqlnet_Ldap_Link 
#**************************** 
sub Opt_Create_Sqlnet_Ldap_Link  {
    $WhereIam = "Opt_Create_Sqlnet_Ldap_Link";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Setting up softlink for ldap.ora/sqlnet.ora");

    &Print_Line('Linking $TNS_ADMIN/sqlnet.ora -> /etc/sqlnet.ora');
    system("rm -f $TnsAdmin/sqlnet.ora");
    system("ln -s /etc/sqlnet.ora $TnsAdmin/sqlnet.ora");

    if (-f "/var/opt/oracle/ldap.ora") {
       &Print_Line("Linking \$TNS_ADMIN/ldap.ora -> /etc/ldap.ora");
       system("rm -f $TnsAdmin/ldap.ora");
       system("ln -s /etc/ldap.ora $TnsAdmin/ldap.ora");
    }
    print " Done\n\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#************************* 
# Opt_Add_Abort_In_Adcmctl
#************************* 
sub Opt_Add_Abort_In_Adcmctl {    
    $WhereIam = "Opt_Add_Abort_In_Adcmctl";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    $Fname = "$ScriptDir/adcmctl.sh";
    &Backup_File("${Fname},Opt_Add_Abort_In_Adcmctl");

    &Print_Header("Changing adcmctl.sh");

    &Print_Line("Modifying adcmctl.sh for Abort");

    open(FR, "$Fname") || die "Cannot open file $Fname $!\n";
    open(FW, ">${Fname}.new") || die "Cannot open new file ${Fname}.new $!\n";
    while(<FR>) {
       $LnTxt = $_;
       $LnTxt =~ s/SHUTDOWN/ABORT/g if (/SYSADMIN CONCURRENT FND SHUTDOWN/i ) ;
       print FW $LnTxt;
    }
    close(FW);
    close(FR);

    system("cp ${Fname}.new $Fname");
    system("rm -f ${Fname}.new  2>/dev/null");
    print " Done\n\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#************************** 
# Opt_Backup_Critcal_Tables
#************************** 
sub Opt_Backup_Critcal_Tables {    
    $WhereIam = "Opt_Backup_Critcal_Tables";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Backup the Critical Tables");
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    chomp($TExt = `date +\%d\%b\%H\%M\%S`);
    &Backup_Tables("applsys.fnd_profile_options","fnd_profile_option_$TExt");
    &Backup_Tables("applsys.fnd_profile_option_values","fnd_profile_optval_$TExt");
    $Dbh->disconnect;
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#************************ 
# Opt_Secure_Config_Files
#************************ 
sub Opt_Secure_Config_Files {    
    $WhereIam = "Opt_Secure_Config_Files";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Securing Files and Directories");

    foreach $Fname (("$CloneBackupDir", "$ScriptDir", "$Home/DBA", "$ApplAdm/$SID/log")) {
       &Print_Line("Changing 700 for $Fname");
       system("chmod 700 $Fname 2>/dev/null");
       print " Done\n";
    } 
    foreach $Fname (("$CloneBackupDir/*.*", "$AppsPwdFile", "$ModTop/wdbsvr.app")) {
       &Print_Line("Changing 400 for $Fname");
       system("chmod 600 $Fname 2>/dev/null");
       print " Done\n";
    } 
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#**************************** 
# Opt_Update_Sso_Files_For_Sj 
#**************************** 
sub Opt_Update_Sso_Files_For_Sj { 
    &Print_Header("Configuring for SSO");
    if ($SID =~ /SJ/ && !($SID =~ /SJOE/)) {
       &Sso_Setup_For_Sj;
    }
    else {
       print "     $SID is not Configuring for SSO, Only enabled in SJ Instances\n";
    }
    push(@ToDoList,'hostconfigfile set to policy-dev-1 in $A/WebAgent.conf, '.
                   'uncomment policy-stage-1 if it is configured to stage');
    $Msg = '$APPL_TOP/XXCUSTOM.env doesnot exist, Copy from other env. if needed';
    print "\n";
}

#=================
# Sso_Setup_For_Sj
#=================
sub Sso_Setup_For_Sj {

    $WhereIam = "Sso_Setup_For_Sj";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    my $Chg ="NO";
  
    #------------------
    # sso_httpd.conf Change
    #------------------
    $Fname = "$ApacheConfDir/sso_httpd.conf";
    &Print_Line("Creating sso_httpd.conf and include this in httpd.conf");

    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";

    print FW "#","-"x80,"\n";
    print FW "# SSO Configuration \n";
    print FW "#","-"x80,"\n\n";
    print FW "LoadModule hpaCCso_module /opt/netegrity/webagent/lib/mod_hpaCCso.sl\n";
    print FW "HPaCCLoadModule sm_module /opt/netegrity/webagent/lib/mod_sm.sl\n";
    print FW "#\n\n";

    print FW "AddModule mod_sm.c\n";
    print FW "SmInitFile $ApacheConfDir/WebAgent.conf\n";
    print FW "#\n\n";

    print FW "PassEnv SHLIB_PATH\n";
    print FW "PassEnv LD_LIBRARY_PATH\n";
    print FW "PassEnv LIBS\n";
    print FW "#\n\n";

   
    print FW qq{Alias /siteminderagent/forms/ "/opt/netegrity/webagent/samples/forms/"\n};
    print FW qq{<Directory "/opt/netegrity/webagent/samples/forms/">\n};
    print FW qq{    Options Indexes MultiViews\n};
    print FW qq{   AllowOverride None\n};
    print FW qq{   Order allow,deny\n};
    print FW qq{   Allow from all\n};
    print FW qq{</Directory>\n};
    print FW "#\n\n";

    print FW qq{Alias /siteminderagent/pwcgi/ "/opt/netegrity/webagent/pw/"\n};
    print FW qq{<Directory "/opt/netegrity/webagent/pw/">\n};
    print FW qq{   Options Indexes MultiViews ExecCGI\n};
    print FW qq{   AllowOverride None\n};
    print FW qq{   Order allow,deny\n};
    print FW qq{   Allow from all\n};
    print FW qq{</Directory>\n};
    print FW "#\n\n";

    print FW qq{Alias /siteminderagent/pw/ "/opt/netegrity/webagent/pw/"\n};
    print FW qq{<Directory "/opt/netegrity/webagent/pw/">\n};
    print FW qq{Options Indexes MultiViews ExecCGI\n};
    print FW qq{AllowOverride None\n};
    print FW qq{Order allow,deny\n};
    print FW qq{Allow from all\n};
    print FW qq{</Directory>\n};
    print FW "#\n\n";

    print FW qq{AddHandler cgi-script .cgi\n};
    print FW qq{AddHandler smformsauth-handler .fcc\n};
    print FW "\n\n#","-"x80,"\n\n";

    close(FW);
    $SrchStg = "sso_httpd.conf";
    chomp($SrchCnt = `grep \"$SrchStg\" $ApacheConfDir/httpd.conf |wc -l`);
    $Fname = "$ApacheConfDir/sso_httpd.conf";

#Newly added
    $SrchCnt =~ s/ //g;

    if ($SrchCnt eq "0") {
        &Backup_File("$ApacheConfDir/httpd.conf".",Sso_Setup_For_Sj");
        open(FW, ">>$ApacheConfDir/httpd.conf") || die "Cannot open new file $ApacheConfDir/httpd.conf $!\n";
        print FW "\n# Begin customizations\n";
        print FW "include \"$ApacheConfDir/$SrchStg\"\n";
        print FW "# End customizations\n\n";
       close(FW);
    }

    print " Done\n";

    #------------
    # sync.config
    #------------
    $Fname = "$JservTop/servlets/sync.config";
    &Print_Line("Modifying $Fname");
    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";

    print FW "#--------\n";
    print FW "#Env List\n";
    print FW "#--------\n";
    print FW "envs=$SID\n";
    print FW "#---\n";
    print FW "#CEC\n";
    print FW "#---\n";
    print FW "cec.instanceName=OIDSTG\n";
    print FW "cec.hostName=deer.cisco.com\n";
    print FW "cec.port=1583\n";
    print FW "cec.dbUser=xxssoadm\n";
    print FW "cec.dbPassword=d0ttss0\n";
    print FW "cec.table=xxsso_passwd\n";
    print FW "#----\n";
    print FW "#EMCO\n";
    print FW "#----\n";
    print FW "emco.instanceName=MCOPROD\n";
    print FW "emco.hostName=mcodb.cisco.com\n";
    print FW "emco.port=1521\n";
    print FW "emco.dbUser=mcoadm\n";
    print FW "emco.dbPassword=admmco9\n";
    print FW "emco.table=mco_passwd\n";
    print FW "#emco.instanceName=ODSPROD\n";
    print FW "#emco.hostName=miracle.cisco.com\n";
    print FW "#emco.port=1521\n";
    print FW "#emco.dbUser=mcoadm\n";
    print FW "#emco.dbPassword=admmco\n";
    print FW "#emco.table=mco_passwd\n";
    print FW "#---\n";
    print FW "#OID\n";
    print FW "#---\n";
    print FW "oid.searchBase=ou=mcousers,ou=mcoentities,o=mco.cisco.com\n";
    print FW "oid.hostname=rhea.cisco.com\n";
    print FW "oid.port=8889\n";
    print FW "oid.user=uid=user-administrator,ou=mcoentities,o=mco.cisco.com\n";
    print FW "oid.password=me4nadm!\n";
    print FW "#--------\n";
    print FW "#11i Envs\n";
    print FW "#--------\n";
    print FW "envurl.${SID}=${HomeUrl}/\n";

    close(FW);
    print " Done\n";

    #---------------------
    # WebAgent.conf Change
    #---------------------
    $Fname = "$ApacheConfDir/WebAgent.conf";
    &Print_Line("Modifying $Fname");

    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";

    print FW qq{# WebAgent.conf - configuration file for SiteMinder Web Agent\n};
    print FW qq{# Web Agent Version=5QMR5, Build Label=348\n};
    print FW qq{# Web Agent InstallPath=/opt/netegrity\n};
    print FW qq{# Do not remove or edit the preceding lines, or you may not\n};
    print FW qq{#   be able to perform upgrades in the future\n};
    print FW "#\n\n";

    print FW qq{agentconfigobject="Oracle11i-conf"\n};
    print FW qq{hostconfigfile="/opt/netegrity/webagent/config/SmHost.conf.policy-dev-1"\n};
    print FW qq{#hostconfigfile="/opt/netegrity/webagent/config/SmHost.conf.policy-stage-1"\n};
    print FW qq{enablewebagent="YES"\n};
    print FW qq{LogFileName="$ApacheTop/logs/WebAgent.log"\n};
    print FW qq{defaultagentname="${Machine}.cisco.com:${UrlPort}"\n};
    print FW qq{Logfile="YES"\n};
    print FW qq{LogLevel="2"\n};
    print FW qq{LogAppend="NO"\n};
    print FW qq{LogoffUri="/pls/$SID/icx_admin_sig.Startover"\n};
    print FW qq{IgnoreUrl="$HomeUrl/siteminderagent/pwcgi/smpwservicescgi.cgi"\n};
    print FW qq{IgnoreUrl="$HomeUrl/siteminderagent/pwcgi/smpwservicescgi.exe"\n};
    print FW qq{IgnoreUrl="$HomeUrl/pls/${Sid}_portal30_sso/PORTAL30_SSO.wwui_api_util.render_css"\n};
    print FW qq{IgnoreUrl="$HomeUrl/pls/${Sid}_portal30_sso/PORTAL30_SSO.wwsso_app_admin.ls_logout"\n};
    print FW qq{ServerErrorFile=/opt/netegrity/webagent/config/ServerErrorFile.html\n};
    print FW qq{CSSErrorFile=/opt/netegrity/webagent/config/CSSErrorFile.html\n};


    close(FW);
    print " Done\n";

    #-----------------
    # apps.conf Change
    #-----------------
    $Fname = "$ApacheConfDir/apps.conf";
    &Print_Line("Modifying $Fname");

    $SrchStg = "SetEnv SHLIB_PATH /apps/$Sid/product/8.0.6/lib:/apps/$Sid/product/8.0.6/network/jre11/lib/PA_RISC/native_threads:/opt/netegrity/webagent/lib";
    chomp($SrchCnt = `grep \"$SrchStg\" $Fname |wc -l`);

#Newly added
    $SrchCnt =~ s/ //g;

    if ($SrchCnt eq "0") {
        open(FW, ">>$Fname") || die "Cannot open new file $Fname $!\n";
        print FW "$SrchStg\n";
       close(FW);
    }

    print " Done\n";

    #-----------------
    # wdbsvr.app Change
    #-----------------
    $Fname = "$IasTop/Apache/modplsql/cfg/wdbsvr.app";
    &Print_Line("Modifying $Fname");

    $SrchStg = "cgi_env_list = HTTP_SM_USER,HTTP_SM_USERDN";
    chomp($SrchCnt = `grep \"$SrchStg\" $Fname |wc -l`);

#Newly added
    $SrchCnt =~ s/ //g;

    if ($SrchCnt eq "0") {
        &Backup_File("${Fname},Sso_Setup_For_Sj");
        open(FW, ">>$Fname") || die "Cannot open new file $Fname $!\n";
        print FW "$SrchStg\n";
        close(FW);
    }
    print " Done\n";

    #-------------------
    # iAS/SID.env Change
    #-------------------
    $Fname = "$IasTop/${SID}.env";
    &Print_Line("Modifying $Fname");

    foreach $SrchStg (( "export LD_LIBRARY_PATH=\$LD_LIBRARY_PATH:/opt/netegrity/webagent/lib",
                        "export SHLIB_PATH=\$SHLIB_PATH:/opt/netegrity/webagent/lib")) {
       chomp($SrchCnt = `grep \"$SrchStg\" $Fname |wc -l`);

#Newly added
    $SrchCnt =~ s/ //g;

       if ($SrchCnt eq "0") {
           &Backup_File("${Fname},Sso_Setup_For_Sj");
           open(FW, ">>$Fname") || die "Cannot open new file $Fname $!\n";
           print FW "$SrchStg\n";
          close(FW);
       }
    }
    print " Done\n";

    #--------------------
    # aplogon.html Change
    #--------------------
    $Fname = "$CommTop/portal/aplogon.html";
    $Fname = "$CommTop/portal/$ContextName/aplogon.html" if (-f "$CommTop/portal/$ContextName/aplogon.html") ;
    &Print_Line("Modifying $Fname");

    &Backup_File("${Fname},Sso_Setup_For_Sj");
    open(FR, "$Fname") || die "Cannot open file $Fname $!\n";
    open(FW, ">${Fname}.new") || die "Cannot open new file ${Fname}.new $!\n";
    $Chg ="NO";
    while(<FR>){
        if (/OA_HTML\/US\/ICXINDEX\.htm/) {
           $_ =~ s/OA_HTML\/US\/ICXINDEX\.htm/pls\/$SID\/OracleMyPage.home/;
        }
        if (/OA_HTML\/US\/ICXINDEX_$SID\.htm/) {
           $_ =~ s/OA_HTML\/US\/ICXINDEX_$SID\.htm/pls\/$SID\/OracleMyPage.home/;
        }
        print FW "$_";
    }
    close(FW);
    close(FR);

    system("cp ${Fname}.new $Fname");
    system("cp ${Fname}.new $CommTop/portal/aplogon.html") if (-f "$CommTop/portal/aplogon.html");
    system("rm -f ${Fname}.new");
    print " Done\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#**************************
# Opt_Instance_Related_Task
#**************************
#CCK This can be deleted after setting instancewise
#CCK
sub Opt_Instance_Related_Task {
  #CCK  &Screen_Scroll;
    print "\n\t\t\t\tInstance Related Task Menu ($Sid)";
    print "\n\t\t\t\t=====================================\n\n";
    print "\t\t\t\t1.  SJ iProce Related Setup\n\n";
    print "\t\t\t\tEnter your choice(ENTER to previous menu) : ";
    chomp($OptIRT = <STDIN>);
    print "\n";

    &Menu_Destination_App if ($OptIRT eq "");

    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    $NotHere = 0;

    foreach $SN (split(',',$OptIRT)) {
       &Opt_iProc_Setup if ($SN == 1);
    }
}

#*********************
# Opt_Apps_Other_Tasks
#*********************
sub Opt_Apps_Other_Tasks {
  #CCK  &Screen_Scroll;
    print "\n\t\t\t\tOther Task Menu ($Sid)";
    print "\n\t\t\t\t==============================\n";
    print "\t\t\t\t1.  Move Log and out to orarpt\n";
    print "\t\t\t\t2.  NAS setup\n";
    print "\t\t\t\t3.  Virtual name setup\n";
    print "\t\t\t\t4.  Create admin scripts\n";
    print "\t\t\t\t5.  Add XXCUSTOM.env\n";             
    print "\t\t\t\t6.  Sync old patch logs\n";
    print "\t\t\t\t7.  Update site name\n";
    print "\t\t\t\t8.  Add an entry to appstab\n";
    print "\t\t\t\t9.  Schedule cron jobs\n";   
    print "\t\t\t\t10. Schedule purge jobs\n";
    print "\t\t\t\t11. Create ldap.ora/sqlnet.ora link\n";
    print "\t\t\t\t12. Setup user env file /usr/local/bin/$Sid\n";
    print "\t\t\t\t13. Setup a custom top\n";
    print "\t\t\t\t14. Change adcmctl.sh for ABORT\n";
    print "\t\t\t\t15. Secure the files and dir's\n";
    print "\t\t\t\t16. Grant UTL_RECOMP to APPS\n";
    print "\t\t\t\t17. SSO Setup (Files update)\n";
    print "\t\t\t\t18. SSO Setup (Tables update)\n";
    print "\t\t\t\t19. Change apps password\n";                             
    print "\t\t\t\t20. Change reg. user password\n";
    print "\t\t\t\t21. Change Sysadmin Password\n";
    print "\t\t\t\t22. Truncat Conc.Req and Disable Alert\n";
    print "\t\t\t\t23. Impliement hide for executables\n";
    print "\t\t\t\t24. Create Dabase Link in SCMPRD Db\n";
    print "\t\t\t\t25. Backup Critical Tables\n";
    print "\t\t\t\t26. Add an entry to .THRESHOLD\n";
    print "\t\t\t\t27. Generate Edi,Inferface Dir creation\n";
    print "\t\t\t\t28. Run adclone\n";
    print "\t\t\t\t29. Post clone configuration\n";
    print "\t\t\t\t30. Before releasing configuration\n";
    print "\t\t\t\t31. Instance Related Task\n";
    #print "\t\t\t\t32. Test\n";
    print "\n\t\t\t\tEnter your choice(ENTER to previous menu) : ";
    chomp($OptOt = <STDIN>);
    print "\n";

    &Menu_Destination_App if ($OptOt eq "");

    &Env_Application; 
    if ($NotHere) {
       print "\t\t\t\tTHIS IS NOT APPLICATION CODE TREE!!! Can't Perform this task\n";
       $NotHere = 0; 
       return;
    }
    $NotHere = 0;

    foreach $SN (split(',',$OptOt)) {
       &Opt_ReCreate_Log_Out                         if ($SN == 1)  ;
       &Opt_Nas_Setup                                if ($SN == 2)  ;
       &Opt_Vname_setup                              if ($SN == 3)  ;
       &Opt_Gen_Script                               if ($SN == 4)  ;
       &Opt_Custom_Env                               if ($SN == 5)  ;
       &Opt_Sync_Old_Patch_Logs                      if ($SN == 6)  ;
       &Opt_Update_Site_Name                         if ($SN == 7)  ;
       &Opt_Add_Entry_To_Appstab                     if ($SN == 8)  ;
       &Opt_Setup_Apps_Cron_Job                      if ($SN == 9)  ;
       &Opt_Schedule_Purge_Jobs                      if ($SN == 10) ;
       &Opt_Create_Sqlnet_Ldap_Link                  if ($SN == 11) ;
       &Opt_Usr_Env_File                             if ($SN == 12) ;
       &Opt_Define_Custom_Top                        if ($SN == 13) ;
       &Opt_Add_Abort_In_Adcmctl                     if ($SN == 14) ;
       &Opt_Secure_Config_Files                      if ($SN == 15) ;
       &Grant_On_Utl_Recomp                          if ($SN == 16) ;    
       &Opt_Update_Sso_Files_For_Sj                  if ($SN == 17) ;
       &Opt_Update_Sso_Tables_For_Sj                 if ($SN == 18) ;
       &Opt_Apps_Pwd_Change                          if ($SN == 19) ;
       &Opt_Reg_Usr_Pwd_Change                       if ($SN == 20) ;
       &Opt_AppsUser_Pwd_change                      if ($SN == 21) ;
       &Opt_Trunc_And_Disable                        if ($SN == 22) ;
       &Opt_Impliment_Hide                           if ($SN == 23) ;
       &Opt_Create_Migrate_Dblink                    if ($SN == 24) ;
       &Opt_Backup_Critcal_Tables                    if ($SN == 25) ;
       #CCK &Opt_Add_Entry_To_Threshold                   if ($SN == 26) ;
       &Opt_Gen_Edi_Interface                        if ($SN == 27) ;
       if ($SN == 28) { 
          print "\t\t\t\t--------------------------------------------------------------------------\n";
          print "\t\t\t\t- * Assuming .profile and $ContextName.xml are Corrected \n";
          print "\t\t\t\t- * $SID database is up without restricted session \n";
          print "\t\t\t\t- * Database listener listening on $DbLsnrPort\n";
          print "\t\t\t\t--------------------------------------------------------------------------\n\n";
          print "\t\t\t\tTasks will be performed :-\n\n"                       ;
          print "\t\t\t\t* Re-create the Soft Links\n"                         ;
          print "\t\t\t\t* Modify oraInst.loc to point this application\n"     ;
          print "\t\t\t\t* Runs the Destination Cloning\n"                     ;
          print "\t\t\t\t* Modify oraInst.loc to point some where \n"          ;
          print "\t\t\t\t* Backup Config files\n"                              ;
          print "\n\n\t\t\t\tContinue?(Y/N) : "                                ;
          chomp($QQ = <STDIN>)                                                 ;
          print "\n\n"                                                         ;
          &Opt_Apps_Destination_Clone if (uc("$QQ") eq "Y")                    ; 
       }
       if ($SN == 29) { 
          print "\t\t\t\tTasks will be performed :-\n\n"                       ;
          print "\t\t\t\t* Move Log and out to /apps/orarpt\n"                 ;
          print "\t\t\t\t* NAS Setup\n"                                        ;
          print "\t\t\t\t* Virtual Name Setup\n"                               ;
          print "\t\t\t\t* Create admin Scripts\n"                             ;
          print "\t\t\t\t* SSO Setup\n"                                        ;
          print "\n\n\t\t\t\tContinue?(Y/N) : "                                ;
          chomp($QQ = <STDIN>)                                                 ;
          print "\n\n"                                                         ;
          &Opt_Apps_Post_Clone if (uc("$QQ") eq "Y")                           ; 
       }
       if ($SN == 30) { 
          print "\t\t\t\tTasks will be performed :-\n\n"                       ;
          print "\t\t\t\t* Sync Old Patch Logs\n"                              ;
          print "\t\t\t\t* Schedule CronJobs\n"                                ;
          print "\t\t\t\t* Create sqlnet.ora Link\n"                           ;
          print "\t\t\t\t* Change adcmctl.sh for ABORT\n"                      ;
          print "\t\t\t\t* Create admin Scripts\n"                             ;
          print "\t\t\t\t* Update profile - Site Name\n"                       ;
          print "\t\t\t\t* Update profile - Singon Password Length to 8\n"     ;
          print "\t\t\t\t* Add an entry to appstab\n"                          ;
          print "\t\t\t\t* Add an entry to /.THRESHOLD\n"                      ;
          print "\t\t\t\t* Schedule Purge Jobs\n"                              ;
          print "\t\t\t\t* Create sqlnet.ora Link\n"                           ;
          print "\t\t\t\t* Secure the Files and Dir's\n"                       ;
          print "\t\t\t\t* Backup FND_PROFILE_OPTIONS\n"                       ;
          print "\t\t\t\t* Backup FND_PROFILE_OPTION_VALUES\n"                 ;
          print "\t\t\t\t* Grant execute privilege on UTL_RECOMP to apps\n"    ;
          print "\n\n\t\t\t\tContinue?(Y/N) : "                                ;
          chomp($QQ = <STDIN>)                                                 ;
          print "\n"                                                           ;
          &Opt_Apps_Befor_Release  if (uc("$QQ") eq "Y")                       ; 
       }
       #&Opt_Instance_Related_Task              if ($SN == 31) ;
       &Opt_Create_Migrate_Dblink    if ($SN == 32) ;
   }
   &Opt_Apps_Other_Tasks;
   print "\n\n";
}
#=============
# Usr_Env_file 
#=============
sub Usr_Env_file {

    $WhereIam = "Usr_Env_file";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    $Fname = "$Home/.$Sid";
    $Fname = "/apps/share/oracle/bin/$Sid" if ($Os eq 'LINUX') ;
    &Print_Line("Creating Env file $Fname");

    open(FW, ">$Fname") || die "Cannot open new file $Fname $!\n";
    print FW "PS1='$Sid:\$PWD>';export PS1\n";
    print FW "export HOME\n";
    print FW ". $ApplTop/APPSORA.env\n";
    print FW "unset LANG \n";
    print FW "echo \n";
    print FW "echo '###############################################################################'\n";
    print FW "echo\n";
    print FW "echo '                                    $SID'\n";
    print FW "echo '                            $ApsVersion environment'\n";
    print FW "echo\n";
    print FW "echo '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++'\n";
    print FW "echo \n";

    print " Done\n";
    close(FW);
    system("chmod 775 $Fname");
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#********************** 
# Opt_Define_Custom_Top 
#********************** 
sub Opt_Define_Custom_Top { 

    print "Setting up New Custom top :- \n";
    print "     Enter the Custom Directory you want to define : ";
    chomp($CustomTops = <STDIN>);

    if ($CustomTops eq "" ) {
       print "     You requested not to define any Custom Directory !!!\n";
       return;
    }
    $CustomTops = lc($CustomTops);

    &Create_Custom_Dir;
}

#==================
# Create_Custom_Dir
#==================
sub Create_Custom_Dir {
    
    $WhereIam = "Create_Custom_Dir";
    foreach $Dr (split(',',$CustomTops)) {
        &Print_Line("Defining Custom Directory '$Dr' with permission 777");

        system("mkdir -p $ApplTop/$Dr/11.5.0/bin")         ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/sql")         ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/lib")         ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/log")         ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/out")         ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/java")        ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/mesg")        ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/patch")       ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/media")       ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/html/US")     ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/html/US")     ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/help/US")     ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/forms/US")    ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/resource")    ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/admin/sql")   ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/reports/US")  ; 
        system("mkdir -p $ApplTop/$Dr/11.5.0/admin/import"); 
        system("chmod -R 777 $ApplTop/$Dr")                ;

        if ( -d "$OrarptTop/fnd/log" ) {
           if (!(-l "$ApplTop/$Dr/11.5.0/log")) {
              system("mkdir -p $OrarptTop/$Dr/log");
              system("mkdir -p $OrarptTop/$Dr/out");
              system("mv $ApplTop/$Dr/11.5.0/log/* $OrarptTop/$Dr/log 2>/dev/null");
              system("mv $ApplTop/$Dr/11.5.0/log/* $OrarptTop/$Dr/out 2>/dev/null");
              system("rmdir $ApplTop/$Dr/11.5.0/log ");
              system("rmdir $ApplTop/$Dr/11.5.0/out ");
           }
           else {
              system("rm $ApplTop/$Dr/11.5.0/log ");
              system("rm $ApplTop/$Dr/11.5.0/out ");
           }
           system("ln -s $OrarptTop/$Dr/log $ApplTop/$Dr/11.5.0");
           system("ln -s $OrarptTop/$Dr/out $ApplTop/$Dr/11.5.0");
        }
        print " Done\n";

        $Fname = "$ApplTop/XXCUSTOM.env";
        &Backup_File("${Fname},Create_Custom_Dir");
        open(FW, ">>$Fname") || die "Cannot open new file $Fname $!\n";
        $nTmp = uc($Dr);
        print FW "export ".uc($Dr)."_TOP=\"${Dr}/11.5.0\" \n";
        $fTmp .= "\$${nTmp}_TOP/resource:";
        print FW "export FORMS60_PATH=\$FORMS60_PATH:\$".uc($Dr)."_TOP/resource \n";
    }
    &Debug_Now if ($Debug);
}

#******************** 
# Opt_Point_Orainst
#******************** 
sub Opt_Point_Orainst {    

    $WhereIam = "Opt_Point_Orainst";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Modify_Orainst($Sid);    
    print "\n";

    system("touch $Home/DBA/clone/.${WhereIam}");
}

#********************* 
# Opt_Redirect_Orainst
#********************* 
sub Opt_Redirect_Orainst {    

    $WhereIam = "Opt_Redirect_Orainst";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Modify_Orainst ("nowhere");    
    print "\n";

    system("touch $Home/DBA/clone/.${WhereIam}");
}

#===============
# Modify_Orainst
#===============
sub Modify_Orainst {    
    
    my $NewLoc = $_[0];
    $WhereIam = "Modify_Orainst";
    &Print_Header("Modifying oraInst.loc to $NewLoc");

    $Fname = "/var/opt/oracle/oraInst.loc";
    &Print_Line("Modifying $Fname to point /apps/$NewLoc/oraInventory");

    &Backup_File("${Fname},Modify_Orainst");
    open(FR, "$Fname") || die "Cannot open file $Fname $!\n";
    open(FW, ">/tmp/$Ext.loc") || die "Cannot open new file /tmp/$Ext.loc $!\n";
    while(<FR>) {
       $LnTxt = $_;
       $LnTxt = "inventory_loc=/apps/$NewLoc/oraInventory\n" if (/^inventory_loc/i ) ;
       print FW $LnTxt;
    }
    close(FW);
    close(FR);
    system("cp /tmp/$Ext.loc $Fname");
    system("rm /tmp/$Ext.loc");
    print " Done\n";
    &Debug_Now if ($Debug);
}

#***************************** 
# Opt_Update_Sso_Tables_For_Sj
#***************************** 
sub Opt_Update_Sso_Tables_For_Sj {    

    &Print_Header("Updating Portal Tables for Sso Configuring");
    if ($SID =~ /SJ/ && !($SID =~ /SJOE/)) {
       &Update_Sso_Tables_For_Sj;
    }
    else {
       &Print_Line("$SID is not Configuring for SSO, Only enabled in SJ,SJOE and BV Instances\n");
       print " Not Done\n";
    }
    print "\n";
}

#************************************** 
# Opt_Update_Sso_Tables_For_Qtc_And_Bv
#************************************** 
sub Opt_Update_Sso_Tables_For_Qtc_And_Bv {    

    &Print_Header("Updating $Sid Sso Configuring");
    if (("$SID" =~ /BV/) || ("$SID" =~ /OE/)) {
       &Update_Sso_Tables_For_Qtc_And_Bv;
    }
    else {
       &Print_Line("$SID is not Configuring for SSO, Only enabled in SJ,SJOE and BV Instances\n");
       print " Not Done\n";
    }
    print "\n";
}

#==================================
# Update_Sso_Tables_For_Qtc_And_Bv
#==================================
sub Update_Sso_Tables_For_Qtc_And_Bv {

    $WhereIam = "Update_Sso_Tables_For_Qtc_And_Bv";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    my $Row;
    my $Idm;
    my $CurDir;
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");
    
    chomp($TmpTnsDir = `pwd`);

    $Fname = "$TmpTnsDir/tnsnames.ora";
    open(FWTNS , ">$Fname") || die "Cannot open file $Fname $!\n";
    print FWTNS "IDMSTG,IDMSTG.cisco.com=(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=idmstg-db)".
                "(PORT=1555))(CONNECT_DATA=(SID=IDMSTG)))\n";
    print FWTNS "IDMDEV,IDMDEV.cisco.com=(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=idmdev-db)".
                "(PORT=1555))(CONNECT_DATA=(SID=IDMDEV)))\n";
    print FWTNS "IDMPRF,IDMPRF.cisco.com=(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=idmprf-db)".
                "(PORT=1599))(CONNECT_DATA=(SID=IDMPRF)))\n";
    close(FWTNS);
    $OldTnsAdmin = $ENV{'TNS_ADMIN'};
    $ENV{'TNS_ADMIN'} = "$TmpTnsDir"; 
$p = $ENV{'TNS_ADMIN'};
print "Here is TNS_ADMIN : [$p]\n";
    &Print_Line("Updating ssosdk.wwsec_enabler_config_info\$");

    foreach $IdmDb (("IDMDEV", "IDMSTG", "IDMPRF")) {
       $RemoteDbh = &Connect_Db("ssoro","ss0read0nly", "$IdmDb");
       $RemoteSt = qq{ select 'update ssosdk.wwsec_enabler_config_info\$ 
                               set    LSNR_TOKEN = ''$SID'',
                                      SITE_TOKEN = '''||site_token||''', 
                                      site_id = '''||site_id||''', 
                                      encryption_key = '''||encryption_key||''', 
                                      encryption_mask_pre = '''||encryption_mask_pre||''',
                                      encryption_mask_post = '''||encryption_mask_post||''';'
                       FROM   orasso.wwsso_papp_configuration_info\$ 
                       WHERE  site_name LIKE '\%EOETCD\%'};
#print "$RemoteSt\n";

       $RemoteSh1 = $RemoteDbh->prepare($RemoteSt) || die "\nPrep Faild [ $RemoteSt ]\n", $RemoteDbh->errstr;
       $RemoteSh1->execute;
       ($SsoUpdStmt) = $RemoteSh1->fetchrow_array;
print "[$SsoUpdStmt]\n";
       $RemoteSh1->finish;
       $RemoteDbh->disconnect;
       $Idm = $IdmDb;
       last if (! $SsoUpdStmt);
    }
    $Row = $Dbh->do($SsoUpdStmt) || die "\nStmt Faild [ $SsoUpdStmt ]\n", $Dbh->errstr;
    $Dbh->disconnect;
    print " $Row update to $Idm\n";

    $ENV{'TNS_ADMIN'} = $OldTnsAdmin;
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#=========================
# Update_Sso_Tables_For_Sj
#=========================
sub Update_Sso_Tables_For_Sj {    

    $WhereIam = "Update_Sso_Tables_For_Sj";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    my $Row;
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");
    system("chmod 777 $CloneBackupDir/sso_upd_chk.sql");

    $Fname = "$CloneBackupDir/sso_upd_chk.sql";
    open(FW, ">$Fname") || die "Cannot open file $Fname $!\n";
    print FW "set echo on\n";

    #------------------------------------
    # Update SSO part SUCESS and HOME url
    #------------------------------------
    print FW "select success_url,home_url from portal30_sso.wwsso_papp_configuration_info\$\n".
             "where site_name  = 'Oracle Applications';\n\n";

    &Print_Line("Updating portal30_sso.wwsso_papp_configuration_info\$");

    $UpdStr= "UPDATE portal30_sso.wwsso_papp_configuration_info\$
              SET    success_url= '$HomeUrl/pls/$SID/OracleSSWA.sign_on',
                     home_url   = '$HomeUrl/pls/${SID}_portal30'
              WHERE  site_name  = 'Oracle Applications'";

    $Row = $Dbh->do("$UpdStr") || die "\nStmt Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    #----------------------------------------------------
    # Update SSO part SUCESS, FAILUR, HOME and LOGOUT url
    #----------------------------------------------------
    print FW "select success_url,failure_url,home_url,logout_url \n".
             "from portal30_sso.wwsso_papp_configuration_info\$\n".
             "where site_name  = 'Oracle Portal (portal30)';\n\n";

    &Print_Line("Updating portal30_sso.wwsso_papp_configuration_info\$");
    $UpdStr= "UPDATE portal30_sso.wwsso_papp_configuration_info\$
              SET    success_url= '$HomeUrl/pls/${Sid}_portal30/portal30.wwsec_app_priv.process_signon',
                     failure_url= '$HomeUrl/pls/${Sid}_portal30_sso/portal30_sso.wwsso_app_admin.ls_login',
                     home_url   = '$HomeUrl/pls/${Sid}_portal30/portal30.home',
                     logout_url = '$HomeUrl/pls/${Sid}_portal30/portal30.wwsec_app_priv.logout'
              WHERE  site_name  = 'Oracle Portal (portal30)'";

    $Row = $Dbh->do("$UpdStr") || die "\nUpd Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    #----------------------------------------------------
    # Update SSO part SUCESS, FAILUR, HOME and LOGOUT url
    #----------------------------------------------------
    print FW "select success_url,home_url,failure_url,logout_url \n".
             "from portal30_sso.wwsso_papp_configuration_info\$\n".
             "where site_name = 'The Login Server (portal30_sso)';\n\n";

    &Print_Line("Updating portal30_sso.wwsso_papp_configuration_info\$");

    $UpdStr= "UPDATE portal30_sso.wwsso_papp_configuration_info\$
              SET    success_url= '$HomeUrl/pls/${Sid}_portal30_sso/portal30_sso.wwsec_app_priv.process_signon',
                     failure_url= '$HomeUrl/pls/${Sid}_portal30_sso/portal30_sso.wwsso_app_admin.ls_login',
                     home_url   = '$HomeUrl/pls/${Sid}_portal30_sso/portal30_sso.home',
                     logout_url = '$HomeUrl/pls/${Sid}_portal30_sso/portal30_sso.wwsec_app_priv.logout'
              WHERE  site_name  = 'The Login Server (portal30_sso)'";

    $Row = $Dbh->do("$UpdStr") || die "\nUpd Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    #-----------------------------------------
    # Update SSO part LSNR_TOKEN, LS_LOGIN_URL
    #-----------------------------------------
    print FW "select lsnr_token,ls_login_url from portal30_sso.wwsec_enabler_config_info\$;\n\n";

    &Print_Line("Updating portal30_sso.wwsec_enabler_config_info\$");

    $UpdStr= "UPDATE portal30_sso.wwsec_enabler_config_info\$
               SET    lsnr_token  ='$HomeUrl',
                      ls_login_url='$HomeUrl/pls/${Sid}_portal30_sso/portal30_sso.wwsso_app_admin.ls_login'";

    $Row = $Dbh->do("$UpdStr") || die "\nUpd Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    #-----------------------------------------
    # Update SSO part LSNR_TOKEN, LS_LOGIN_URL
    #-----------------------------------------
    print FW "select lsnr_token,ls_login_url from portal30.wwsec_enabler_config_info\$;\n\n";

    &Print_Line("Updating portal30.wwsec_enabler_config_info\$");

    $UpdStr= "UPDATE portal30.wwsec_enabler_config_info\$
              SET    lsnr_token = '$HomeUrl',
                     ls_login_url='$HomeUrl/pls/${Sid}_portal30_sso/portal30_sso.wwsso_app_admin.ls_login'";

    $Row = $Dbh->do("$UpdStr") || die "\nStmt Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    #-------------------------
    # Update SSO part HTTP_URL
    #-------------------------
    print FW "select http_url from portal30.wwpro_providers\$ where id =12;\n\n";

    &Print_Line("Updating portal30.wwpro_providers\$");

    $UpdStr= "UPDATE portal30.wwpro_providers\$
              SET    http_url = '$HomeUrl/servlets/framework'
              WHERE  id = 12";

    $Row = $Dbh->do("$UpdStr") || die "\nStmt Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    #---------------------------
    # Update SSO part LSNR_TOKEN
    #---------------------------
    print FW "select lsnr_token, ls_login_url from ssosdk.wwsec_enabler_config_info\$;\n\n";

    &Print_Line("Updating ssosdk.wwsec_enabler_config_info\$");

    $ltoken = "${DbTierGiven}_${Sid}";

    $UpdStr= "UPDATE ssosdk.wwsec_enabler_config_info\$
              SET lsnr_token  ='$ltoken',
                  ls_login_url='$HomeUrl/pls/${Sid}_portal30_sso/portal30_sso.wwsso_app_admin.ls_login'";

    $Row = $Dbh->do("$UpdStr") || die "\nStmt Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    #------------------------
    # Update APPS_DATABASE_ID 
    #------------------------
    print FW "SELECT v.profile_option_value, p.profile_option_name 
              FROM   apps.fnd_profile_option_values v, apps.fnd_profile_options p
              WHERE  v.profile_option_id = p.profile_option_id
              AND    p.profile_option_name = 'APPS_DATABASE_ID'\n\n";

    &Print_Line("Updating Profile Option for APPS_DATABASE_ID");

    $UpdStr = "UPDATE apps.fnd_profile_option_values SET profile_option_value = '$ltoken'
               WHERE  profile_option_id = (SELECT profile_option_id
                                           FROM   apps.fnd_profile_options
                                           WHERE  profile_option_name='APPS_DATABASE_ID')";

    $Row = $Dbh->do("$UpdStr") || die "\nStmt Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    #---------------------------
    # Update SESSION_COOKIE_NAME 
    #---------------------------
    print FW "select home_url from apps.icx_parameters;\n\n";

    $UpdStr="UPDATE apps.icx_parameters
             SET    home_url='$HomeUrl/pls/$SID/OracleMyPage.home' , session_cookie_name='$SID'";

    &Print_Line("Updating icx_parameters");
    $Row = $Dbh->do("$UpdStr") || die "\nStmt Faild [ $UpdStr ]\n", $Dbh->errstr;
    print " $Row Row Updated\n";

    $Dbh->disconnect;
    print FW "set echo off\n";
    close(FW);
    push(@ToDoList, "If need verify sso entries in the database, use $Fname");

    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#******************** 
# Opt_Apps_Pwd_Change 
#******************** 
sub Opt_Apps_Pwd_Change { 
    print "Changing Apps and Applsys passwords :- \n";
    &Apps_Pwd_Change;
    print "\n";
}

#================
# Apps_Pwd_Change
#================
sub Apps_Pwd_Change { 

    $WhereIam = "Apps_Pwd_Change";
    #-------------------------------------------------------------------#
    # * Get the New Password                                          * #
    # * Take a backup of DBA_USERS, FND_ORACLE_USERID and FND_USER    * #
    # * Change the password using FNDCPAS                             * #
    # * Update the new password in CGIcmd.dat and  wdbsvr.app         * #
    #-------------------------------------------------------------------#
 
    #------------------------------------------------------------------
    # Get System, New Apps Passwd and Verify Curr.Apps, SYSTEM Password 
    #------------------------------------------------------------------
    &Print_Line("Verifying Current APPS password");
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");

    $Dbh->disconnect;
    print " Done\n\n";
    print "     Enter the SYSTEM Password : ";
    chomp($SystemPwd = <STDIN>);

    die "     SYSTEM Password cannot be NULL\n\n" if ("$SystemPwd" eq "");

    &Print_Line("Verifying SYSTEM password");

    $Dbh = &Connect_Db("SYSTEM","$SystemPwd", "$SID");
    print " Done\n\n";

    print "     Enter New Apps Password   : ";
    chomp($NewAPwd = <STDIN>);

    die "     New password is mandatory, you entered [$NewAPwd]\n\n" if ("$NewAPwd" eq "") ;

    $Dbh->disconnect;
    chomp($TExt = `date +\%d\%b\%H\%M\%S`);

    #------------------------------------------------------------------
    # Create backup of DBA_USERS, FND_USER, FND_ORACLE_USERID
    #------------------------------------------------------------------
    &Print_Line("Creating backup table for DBA_USERS");
    $Dbh->do("Create table ops\$oracle.DBA_USERS_${TExt} as select * from sys.DBA_USERS");
    print " Done\n";

    &Print_Line("Creating backup table for FND_ORACLE_USERID");
    $Dbh->do("Create table ops\$oracle.FND_ORACLE_USERID_${TExt} as select * from applsys.FND_ORACLE_USERID");
    print " Done\n";

    &Print_Line("Creating backup table for FND_USER");
    $Dbh->do("Create table ops\$oracle.FND_USER_${TExt} as select * from applsys.FND_USER");
    print " Done\n";
    #&Set_Password_Verification_Function("OFF");
    $Dbh->disconnect;

    #------------------------------------------------------------------
    # Change the Apps Password
    #------------------------------------------------------------------
    print "\n     $FndTop/bin/FNDCPASS apps/$CurApsPwd 0 Y system/$SystemPwd SYSTEM APPLSYS $NewAPwd\n\n";
    &Print_Line("Changing Apps Passwrod");
    system("$FndTop/bin/FNDCPASS apps/$CurApsPwd 0 Y system/$SystemPwd SYSTEM APPLSYS $NewAPwd 2>/dev/null");

    $Dbh = &Connect_Db("APPS","$NewAPwd", "$SID");
    print " Done\n";

    &Print_Line("Re-Creating Db Link APPS_TO_APPS and EDW_APPS_TO_WH");

    $Dbh->do("drop database link APPS_TO_APPS");
    $Dbh->do("create database link APPS_TO_APPS connect to APPS identified by $NewAPwd using '$SID'");

    $Dbh->do("drop database link EDW_APPS_TO_WH");
    $Dbh->do("create database link EDW_APPS_TO_WH connect to APPS identified by $NewAPwd using '$SID'");
    $Dbh->disconnect;
    print " Done\n";
     
    $Dbh = &Connect_Db("SYSTEM","$SystemPwd", "$SID");
    #&Set_Password_Verification_Function("ON");
    $Dbh->disconnect;

    #------------------------------------------------------------------
    # Update the new password entry in CGIcmd.dat and wdbsvr.app
    #------------------------------------------------------------------
    foreach $Fname (("$OraHome/reports60/server/CGIcmd.dat", "$IasTop/Apache/modplsql/cfg/wdbsvr.app")) {
       &Print_Line("Updating Password $Fname");

       &Backup_File("${Fname},Apps_Pwd_Change");
       open(FR, "$Fname") || die "Cannot open file $Fname $!\n";
       open(FW, ">${Fname}.${Ext}") || die "Cannot open new file ${Fname}.${Ext} $!\n";
       while (<FR>) {
          $LnTxt = $_;
          $LnTxt =~ s/userid=APPS\/$CurApsPwd\@$SID/userid=APPS\/$NewAPwd\@$SID/i if (/userid=APPS\/$CurApsPwd\@$SID/i) ;
          $LnTxt =~ s/$CurApsPwd/$NewAPwd/i if(/^password/);
          print FW $LnTxt;
       }
       close(FR);
       close(FW);
       print " Done\n";
       system("cp ${Fname}.${Ext} $Fname");
       system("rm ${Fname}.${Ext}");
       system("chmod 600 ${Fname}*");
    }
    $CurApsPwd = $NewAPwd;
    &Debug_Now if ($Debug);
}

#---------------
# Sub Connect_Db
#---------------
sub Connect_Db {
    $WhereIam = "Connect_Db";
    $ConUsr = $_[0];
    $ConPwd = $_[1];
    $ConSid = $_[2];
    my $dbh;

    $OldHome = $ENV{'ORACLE_HOME'};
    $OldTns  = $ENV{'TNS_ADMIN'};

    if ($ConUsr) {
       if    (-l "/oracle/product/current") { $ENV{'ORACLE_HOME'} = '/oracle/product/current'; }
       elsif (-d "/oracle/product/8.1.7.4") { $ENV{'ORACLE_HOME'} = '/oracle/product/8.1.7.4'; }
       elsif (-d "/oracle/product/9.2")     { $ENV{'ORACLE_HOME'} = '/oracle/product/9.2'    ; }

       eval "use DBI";

       $ENV{'TNS_ADMIN'} = "$TnsAdmin";
       $dbh = DBI->connect("dbi:Oracle:", "$ConUsr/$ConPwd\@$ConSid", "",{PrintError=>0} );
       $ENV{'TNS_ADMIN'} = "$OldTns";
    }
    else {
       $dbh = DBI->connect("dbi:Oracle:", "", "",{PrintError=>0} );
    }


    if ("$DBI::errstr" ne "") {
       print "\n     FAILED to Connect as [$ConUsr] with the password [$ConPwd] to [$ConSid]";
       print "\n     FYI: TNS_ADMIN used [$TnsAdmin] and ORACLE_HOME is $ENV{'ORACLE_HOME'}\n\n";
       die "\n     ERROR : [$DBI::errstr]\n\n";
    }
    $ENV{'ORACLE_HOME'} = "$OldHome";

    return($dbh) if (uc($ConUsr) eq "AI" ||uc($ConUsr) eq "CLM") ;

    if ($ConUsr ne "ssoro") {
       $Sh1 = $dbh->prepare('SELECT name from v$database') || die $dbh->errstr;
       $Sh1->execute;
       ($ConnectedDbName) = $Sh1->fetchrow_array;
       $Sh1->finish;
    }

    return($dbh);
    &Debug_Now if ($Debug);
}

#************************ 
# Opt_Recreate_Soft_Links
#************************ 
sub Opt_Recreate_Soft_Links {    
    &Print_Header("Correcting the Soft Links...may take some time");
    &Recreate_Soft_Links;    
    print "\n";
}

#====================
# Recreate_Soft_Links
#====================
sub Recreate_Soft_Links {    

    $WhereIam = "Recreate_Soft_Links";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    system("mkdir -p $ConfDir") ;

    foreach $LDir (("$ApacheConfDir"              ,
                    "$ModTop"                     ,
                    "$CommTop/portal/$ContextName",
                    "$CommTop/portal"             ,
                    "$JservTop/servlets"          ,
                    "$JservTop/etc"               ,
                    "$ApplAdm"                    ,
                    "$TnsAdmin"                   ,
                    "$iTnsAdmin")) {

       chomp(@LFiles = `/usr/bin/find $LDir -type l 2>/dev/null`);
       foreach $Lnk (@LFiles) {
           &Print_Line("Breaking Link $Lnk");
           unlink "$Lnk";
           system("touch $Lnk");
           print " Done\n";
          }
       }

       foreach $LFile (("$ApacheTop/logs", "$JservTop/logs", "$CommTop/temp")) {
          &Print_Line("Breaking Link $LFile");

          system("rm -f $LFile") if (-l "$LFile") ;
          system("mkdir -p $LFile");
          print " Done\n";
       }
   &Debug_Now if ($Debug);

   system("touch $Home/DBA/clone/.${WhereIam}");
}

#************************ 
# Opt_AppsUser_Pwd_change  
#************************ 
sub Opt_AppsUser_Pwd_change { 
    print "Changing Application user password :- \n";
    &AppsUser_Pwd_change;
    print "\n";
}

#====================
# AppsUser_Pwd_change
#====================
sub AppsUser_Pwd_change {

    $WhereIam = "AppsUser_Pwd_change";
    #----------------------------------
    # Verify Curr.Apps, SYSTEM Password 
    #----------------------------------
    &Print_Line("Verifying Current APPS password");
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");
    $Dbh->disconnect;
    print " Done\n\n";

    if (!($SystemPwd)) {
       print "     Enter The SYSTEM Password is : ";
       chomp($SystemPwd = <STDIN>);

       die "     SYSTEM Password cannot be NULL\n\n" if ("$SystemPwd" eq "");
    }

    &Print_Line("Verifying SYSTEM password");
    $Dbh = &Connect_Db("SYSTEM","$SystemPwd", "$SID");
    print " Done\n\n";

    print "     Enter Application User Name(sysadmin,mfg_admin...): ";
    chomp($PwdChangeAUsrs = <STDIN>);

    die "     User Name cannot be NULL\n\n" if ("$PwdChangeAUsrs" eq "");

    print "     Enter The New Password       : ";
    chomp($NewAPwd = <STDIN>);

    die "     Password cannot be NULL\n\n" if ("$NewAPwd" eq "");

    foreach $PUsr (split(',',$PwdChangeAUsrs)) {
       &Print_Line("Changing the Password for $PUsr to $NewAPwd");
       system("$FndTop/bin/FNDCPASS apps/$CurApsPwd 0 Y system/$SystemPwd USER $PUsr $NewAPwd 2>/dev/null");
       print " Done\n\n";
    }

   &Debug_Now if ($Debug);
}

#*********************** 
# Opt_Reg_Usr_Pwd_Change  
#*********************** 
sub Opt_Reg_Usr_Pwd_Change { 
    print "Changing Application user password :- \n";
    print "Not Ready \n";
    &Reg_Usr_Pwd_Change;
    print "\n";
}

#===================
# Reg_Usr_Pwd_Change
#===================
sub Reg_Usr_Pwd_Change {

    $WhereIam = "Reg_Usr_Pwd_Change";

    #----------------------------------
    # Verify Curr.Apps, SYSTEM Password 
    #----------------------------------
    &Print_Line("Verifying Current APPS password");
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");
    $Dbh->disconnect;
    print " Done\n\n";

    print "     Enter The SYSTEM Password is : ";
    chomp($SystemPwd = <STDIN>);

    die "     SYSTEM Password cannot be NULL\n\n" if ("$SystemPwd" eq "");

    &Print_Line("Verifying SYSTEM password");
    $Dbh = &Connect_Db("SYSTEM","$SystemPwd", "$SID");
    $Dbh->disconnect;
    print " Done\n\n";

    print "     Enter The User Name(oe,fnd..): ";
    chomp($PwdChangeUsrs = <STDIN>);

    die "     User Name cannot be NULL\n\n" if ("$PwdChangeUsrs" eq "");

    print "     Enter The New Password       : ";
    chomp($NewPwd = <STDIN>);

    die "     Password cannot be NULL\n\n" if ("$NewPwd" eq "");

    foreach $PUsr (split(',',$PwdChangeUsrs)) {
       &Print_Line("Changing the Password for $PUsr to $NewPwd");
       system("$FndTop/bin/FNDCPASS apps/$CurApsPwd 0 Y system/$SystemPwd ORACLE $PUsr $NewPwd");
       print " Done\n\n";
    }
    &Debug_Now if ($Debug);
}

#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

#*************
# Env_Database
#*************
sub Env_Database {

    #CCK if (!(($Home =~ /oracle/) && ($Owner eq "oracle"))) {
    if (!($Owner eq "oracle")) {
       $NotHere = 1 ;
       die "\n\n You are not authorized to run Database task as $Owner, login as oracle and run it on db server!!!\n\n";
    }

    return if (uc($DbEnvOk) eq "Y");

    chomp($Ext = `date +\%d\%b\%Y\%H\%M\%S`)  ;

    $DBSID = $ENV{'ORACLE_SID'};
    &Set_Ora_Home($DBSID);
    $DbEnvOk = "Y";
    $AppsExists=0 ;
    @PreRefBackupTable=("XPR_DBA_TS_QUOTAS"  , 
                        "XPR_DBA_ROLE_PRIVS" , 
                        "XPR_DBA_SYS_PRIVS"  , 
                        "XPR_DBA_USERS"      , 
                        "XPR_DBA_DB_LINKS" );   

}

#-------------------
#SUB Env_Application
#-------------------
sub Env_Application {

    if (!(($Home =~ /\/apps/) && ($Owner =~ /^oa/))) {
       $NotHere = 1 ;
       $NotAllowed = 1 ;
       die "\n\n You are not authorized to run Application task as $Owner, login as applmgr id and run it on application node !!!\n\n";
    }
    return if (uc($AppsEnvOk) eq "Y");

    $Stage = "$Home/stage" if (-d "$Home/stage");
    $Stage = "$Home/stage/clone" if (-d "$Stage/clone");
    $Stage = "$Home/common_top/clone" if (!($Stage) && (-d "$Home/common_top/clone"));


    #------------------------------------------------------------------------------ 
    # Variable Declaration and Detect the Values 
    #------------------------------------------------------------------------------ 
    $CustomTops = "";
    chomp($Ext = `date +\%d\%b\%Y\%H\%M\%S`);
    #CCK $Sid = substr($Owner,2);
    #CCK $SID = uc($Sid);
    chomp($XmlFile = `ls $Home/appl_top/admin/*xml`);
    #CCK $ApplTop = "$Home/appl_top";
    chomp($SID = `grep 'oa_var="s_dbSid">' $XmlFile |cut -d '>' -f2|cut -d '<' -f1`);
    $SID =~ s/ //g;

    chomp($Sid = `grep 'oa_var="s_dbSidLower">' $XmlFile |cut -d '>' -f2|cut -d '<' -f1`);
    $Sid =~ s/ //g;

    $Banner  = $Sid ;
    $ApacheLockDir = "/var/local/$SID";

    chomp($ApplTop = `grep '<APPL_TOP oa_var="s_at">' $XmlFile |cut -d '>' -f2|cut -d '<' -f1`);
    $ApplTop =~ s/ //g;

    chomp($JtfTop = `grep '<JTF_TOP' $XmlFile |cut -d '>' -f2|cut -d '<' -f1`);
    $JtfTop =~ s/ //g;

    $ApplAdm = "$ApplTop/admin";
    #CCK $CommTop = "$Home/common_top";
    chomp($CommTop = `grep '<COMMON_TOP oa_var="s_com">' $XmlFile |cut -d '>' -f2 |cut -d '<' -f1`);
    $CommTop =~ s/ //g;

    #CCK $OraHome = "$Home/product/8.0.6";
    chomp($OraHome = `grep '<ORACLE_HOME oa_var="s_tools_oh">' $XmlFile |cut -d '>' -f2 |cut -d '<' -f1`);
    $OraHome =~ s/ //g;

    #CCK $IasTop = "$Home/product/iAS";
    chomp($IasTop = `grep '<ORACLE_HOME oa_var="s_weboh_oh">' $XmlFile |cut -d '>' -f2 |cut -d '<' -f1`);
    $IasTop =~ s/ //g;

    $ApacheTop = "$IasTop/Apache/Apache";
    $ApacheConfDir = "$ApacheTop/conf";
    $ModTop = "$IasTop/Apache/modplsql/cfg";
    $JservTop = "$IasTop/Apache/Jserv";

    #CCK $DbcTop = "$ApplTop/fnd/11.5.0/secure";
    chomp($DbcTop = `grep '<fnd_secure oa_var="s_fnd_secure">' $XmlFile |cut -d '>' -f2 |cut -d '<' -f1`);
    $DbcTop =~ s/ //g;

    #CCK $FndTop = "$ApplTop/fnd/11.5.0";
    chomp($FndTop = `grep '<formsfndtop oa_var="s_formsfndtop">' $XmlFile |cut -d '>' -f2 |cut -d '<' -f1`);
    $FndTop =~ s/ //g;

    $MailId = "erp-db-monitor";
    $PagerId = "erp-dba-duty";
    @ToDoList = ();
    chomp($ApTierActual= `uname -n`);

    if (-f "$ApplTop/XXCUSTOM.env") {
        chomp($MailId =`grep "mailto" "$ApplTop/XXCUSTOM.env" |grep "="|cut -d "=" -f2`) ;
        chomp($PagerId =`grep "pageto" "$ApplTop/XXCUSTOM.env" |grep "="|cut -d "=" -f2`) ;
    }


    #CCK if (-f "$ApplAdm/${SID}_wwwin-${Sid}.xml") {
    #CCK    $XmlFile = "$ApplAdm/${SID}_wwwin-${Sid}.xml";
    #CCK }
    #CCK elsif (-f "$ApplAdm/${SID}_${ApTierActual}.xml") {
    #CCK    $XmlFile = "$ApplAdm/${SID}_${ApTierActual}.xml";
    #CCK }
    #CCK elsif (-f "$ApplAdm/${SID}.xml") {
    #CCK    $XmlFile = "$ApplAdm/${SID}.xml";
    #CCK }
    #CCK else {
    #CCK    die "${SID}_wwwin-${Sid}.xml or ${SID}_${ApTierActual}.xml or ${SID}.xml not found \$APPL_TOP/admin \n";
    #CCK }

    $AppsNas = 1;
    chomp($Chk = ` grep "$Home" /etc/fstab|grep "^/dev/" |grep -v grep`);
    $AppsNas = 0 if ($Chk =~ /$Home/);

    chomp($ContextName = `grep oa_context_name $XmlFile |cut -d'>' -f2|cut -d'<' -f1`);
    $ContextName =~ s/ //g;

    chomp($ApTierGiven = `grep s_admhost $XmlFile |cut -d'>' -f2|cut -d'<' -f1`);
    chomp($DbTierGiven = `grep s_dbhost $XmlFile |cut -d'>' -f2|cut -d'<' -f1`);
    $ApTierGiven =~ s/ //g;
    $DbTierGiven =~ s/ //g;

    $OldWdbsrv = "$ModTop/wdbsvr.app";
    $OldWdbsrv = "$ModTop/wdbsvr.smartclone.org" if (-f "$ModTop/wdbsvr.smartclone.org") ;

    chomp($ClonedFrom = `grep ^defaultDAD $OldWdbsrv |cut -d'=' -f2`);
    $ClonedFrom =~ s/ //g;
    $ClonedFrom = "" if ( "$ClonedFrom" eq "$SID" );

    $Lflag = '-sil';
    $Lflag = '' if ($Os eq "HP-UX") ;

    #CCK chomp($NsLookUpValue  = `nslookup $Lflag $ApTierGiven |grep '^Name'|cut -d ':' -f2| cut -d '.' -f1`);
    #CCK $NsLookUpValue        =~ s/\t//g;
    #CCK $NsLookUpValue        =~ s/ //g;

    # ----- In case of CSM/LD the following step will get the other Apps node name ----- #
    #CCK $ApVName = 0;
    #CCK if (($NsLookUpValue eq "${ApTierGiven}-csm" || $NsLookUpValue eq $ApTierGiven) && $NsLookUpValue ne $ApTierActual) {
        #CCK $i       = 0;
        #CCK $ApVName = 1;
        #CCK do {
        
           #CCK print "\t\t\t\t$ApOtherNode not a valid server: " if (++$i > 1);

           #CCK $ApOtherNode   = "";
           #CCK $NsLookUpValue = "";
           #CCK print "\t\t\t\tEnter the 2nd node of the CSM/LD [$ApTierGiven], ENTER if none : ";
           #CCK chomp($ApOtherNode = <STDIN>);
           #CCK print "\n\n";

           #CCK chomp($NsLookUpValue = `nslookup $Lflag $ApOtherNode |grep '^Name'|cut -d ':' -f2| cut -d '.' -f1`);
           #CCK $NsLookUpValue =~ s/\t//g;
           #CCK $NsLookUpValue =~ s/ //g;
        #CCK } until ($NsLookUpValue eq $ApOtherNode || $ApOtherNode eq "") ;

    #CCK }

    chomp($DbTierActual = `nslookup $Lflag $DbTierGiven |grep '^Name:'|cut -d ':' -f2| cut -d '.' -f1`);
    $DbTierActual =~ s/\t//g;
    $DbTierActual =~ s/ //g;
 
    # ----- In case of Virtual Name the following step will get the other DB node name ----- #
    #CCK if ($DbTierActual eq $DbTierGiven ) {
        #CCK $i = 0;
        #CCK do {
           #CCK print "\t\t\t\t$DbTierActual not a valid server: " if (++$i > 1);

           #CCK $DbTierActual = "";
           #CCK $NsLookUpValue = "";
           #CCK print "\t\t\t\tEnter the 1st node of the CSM/LD [$DbTierGiven] : ";
           #CCK chomp($DbTierActual = <STDIN>);
           #CCK print "\n\n";

           #CCK chomp($NsLookUpValue = `nslookup $Lflag $DbTierActual |grep '^Name'|cut -d ':' -f2| cut -d '.' -f1`);
           #CCK $NsLookUpValue =~ s/\t//g;
           #CCK $NsLookUpValue =~ s/ //g;
        #CCK } until ($NsLookUpValue eq $DbTierActual);

        #CCK $i = 0;
        #CCK do {
           #CCK print "\t\t\t\t$DbOtherNode not a valid server: " if (++$i > 1);

           #CCK $DbOtherNode = "";
           #CCK $NsLookUpValue = "";
           #CCK print "\t\t\t\tEnter the 2nd node of the CSM/LD [$DbTierGiven], ENTER if none : ";
           #CCK chomp($DbOtherNode = <STDIN>);
           #CCK print "\n\n";

           #CCK chomp($NsLookUpValue = `nslookup $Lflag $DbTierGiven |grep '^Name'|cut -d ':' -f2| cut -d '.' -f1`);
           #CCK $NsLookUpValue =~ s/\t//g;
           #CCK $NsLookUpValue =~ s/ //g;
        #CCK } until ($NsLookUpValue eq $DbOtherNode || $DbOtherNode eq "") ;

    #CCK }

    $AppsPwdFile = "$OraHome/reports60/server/CGIcmd.dat";
    chomp($CurApsPwd = `grep -i "_APPS:server" $AppsPwdFile`);
    $CurApsPwd =~ s/^.* userid=apps\///ig;
    $CurApsPwd =~ s/@.*$//ig;
    $CurApsPwd =~ s/ //g;

    chomp($DbLsnrPort = `grep dbport $XmlFile |cut -d'>' -f2|cut -d'<' -f1`)                  ;
    $DbLsnrPort =~ s/ //g;

    $ApsVersion = "11.5.8";
    chomp($VersionStr = `grep installloc $XmlFile`);
    $ApsVersion = "11.5.9" if ($VersionStr =~ /11.5.9/);

    chomp($UrlPort = `grep "</web_port>" $XmlFile |cut -d'>' -f2|cut -d'<' -f1|cut -d'/' -f4`);
    $UrlPort =~ s/ //g;

    $ScriptDir = "$Home/common_top/admin/scripts/$ContextName";
    $TnsAdmin = "$OraHome/network/admin/$ContextName"        ;
    $iTnsAdmin = "$IasTop/network/admin/$ContextName"         ;
    $OrarptTop = "/apps/orarpt/$SID";
    $HomeUrl = "http://${ApTierGiven}.cisco.com:${UrlPort}";
    $HomeUrl =~ s/ //g;

    $ConfDir = "/apps/config/$SID";
    $ConfDir = "/apps/local/$SID"     if ($AppsNas) ;
    $CloneBackupDir = "$ConfDir/CloneBackup";
    chomp($CurP30Pwd = `grep ^password $ModTop/wdbsvr.app |grep -v $CurApsPwd|sort -u |cut -d"=" -f2|head -1`);
    $CurP30Pwd =~ s/ //g;

    &Get_Apps_Version if ($ApsVersion eq "" ) ;

    system("mkdir -p $CloneBackupDir");
    system("mkdir -p /apps/orarpt/$SID/utl");

    &Verify_Apps_Env;
    &Display_Apps_Info if (uc($AppsEnvOk) ne "Y");

}


#***************** 
# Opt_Usr_Env_File  
#***************** 
sub Opt_Usr_Env_File { 
    &Print_Header("Create user environment script");
    &Usr_Env_file;
}

#******************** 
# Opt_Aft_Auto_Config
#******************** 
sub Opt_Aft_Auto_Config {    
    print "Doing After Auto Config Process\n";  
    &Opt_Vname_setup;
    &Opt_Nas_Setup;
    &Opt_Gen_Script;
    &Opt_Create_Sqlnet_Ldap_Link;
    &Opt_Usr_Env_File;
    &Opt_Custom_Env;
    &Adcmctl_Abort;    
    print "\n";
}

#********************** 
# Opt_Trunc_And_Disable
#********************** 
sub Opt_Trunc_And_Disable {    

    $WhereIam = "Opt_Trunc_And_Disable";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    &Print_Header("Cleaning up tables and Alerts");
 
    #------------------------------------------------------------------
    # Get System, New Apps Passwd and Verify Curr.Apps, SYSTEM Password 
    #------------------------------------------------------------------
    &Print_Line("Verifying Current APPS password");
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");
    print " Done\n\n";

    &Print_Line("Truncating FND_CONCURRENT_REQUEST, backup in FND_CONCURRENT_REQUEST_CLONE");
    $Dbh->do(q{CREATE TABLE ops$oracle.fnd_concurrent_request_clone AS SELECT * FROM apps.fnd_concurrent_requests});
    $Dbh->do(q{TRUNCATE TABLE applsys.fnd_concurrent_requests});
    print " Done\n\n";

  #CCK  &Print_Line("Truncating SYS.LINK\$, backup in LINK$_CLONE");

  #CCK  $Dbh->do(q{CREATE TABLE ops$oracle.link$_clone AS SELECT * FROM sys.link$});
  #CCK  $Dbh->do(q{TRUNCATE TABLE sys.link$});
  #CCK  print " Done\n\n";

    &Print_Line("Disabling Alerts");
    $Dbh->do(q{UPDATE apps.alr_alerts SET enabled_flag = 'N' WHERE enabled_flag <> 'N'});
    print " Done\n\n";

    $Dbh->disconnect;
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#*********************************** 
# Opt_Sj_Instance_Truncate_Interface
#*********************************** 
sub Opt_Sj_Instance_Truncate_Interface {    

    $WhereIam = "Opt_Sj_Instance_Truncate_Interface";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    @SjTrucTables = ( 'APPLSYS.FND_ORACLE_USERID_TMP',
                      'APPLSYS.FND_USER_TMP',
                      'APPLSYS.FND_CONCURRENT_REQUESTS',
                      'APPLSYS.FND_CONCURRENT_PROCESSES',
                      'APPLSYS.FND_RUN_REQUESTS',
                      'CSM.CSM_FS_RUN_REQUESTS',
                      'CSM.CSM_FS_CONC_REQUESTS',
                      'SYSTEM.DEF$_AQCALL',
                      'SYSTEM.DEF$_AQERROR',
                      'SYSTEM.DEF$_CALLDEST');

    print qq{\t\t\t\tFollowing Tasks will be performed :-\n\n};
    print qq{\t\t\t\t* Create xpr_dba_users table\n};
    foreach $t ( @SjTrucTables ) {
       print qq{\t\t\t\t* truncate table $t\n};
    }
    print qq{\n\n\t\t\t\tContinue?(Y/N) : };
    chomp($SITI = <STDIN>);
    print "\n\n";

    if (uc("$SITI") eq "Y") { 
       &Print_Header("Cleaning up tables and Alerts");
       &Print_Line("Verifying Current APPS password");
       $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");
       print " Done\n\n";
       chomp($TExt = `date +\%d\%b\%H\%M\%S`);

       $Dbh->do(q{alter table system.def$_calldest disable constraint def$_calldest_call}) ;
       foreach $t (@SjTrucTables ) {
          ($Own,$Tbl) = split('.',$t);
          &Print_Line("Backingup Table and Truncating $t");
          $Tbl = substr($Tbl,1,19);
          print qq{CREATE TABLE ops\$oracle.${Tbl}_${TExt} AS SELECT * FROM $t};
          #$Dbh->do(qq{CREATE TABLE ops\$oracle.${Tbl}_${TExt} AS SELECT * FROM $t});
          #$Dbh->do(qq{TRUNCATE TABLE $t});
          print qq{TRUNCATE TABLE $t};
          print " Done\n\n";
       }
       $Dbh->do(q{alter table system.def$_calldest enable constraint def$_calldest_call});
    }
    $Dbh->disconnect;
    print "\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");
}

#********************** 
# Opt_Impliment_Hide
#********************** 
sub Opt_Impliment_Hide {    

    $WhereIam = "Opt_Impliment_Hide";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

     &Print_Header("Implimenting Hide to the Executables");

     if (-e "/usr/tools/oracle/Standard/script/imp_hide.sh") {
        system("sh . $Home/.profile ; /usr/tools/oracle/Standard/script/imp_hide.sh");
     }
     else { print "/usr/tools/oracle/Standard/script/imp_hide.sh not exists\n"; }

    system("touch $Home/DBA/clone/.${WhereIam}");
}

#************************** 
# Opt_Create_Migrate_Dblink
#************************** 
sub Opt_Create_Migrate_Dblink {    

    $WhereIam = "Opt_Create_Migrate_Dblink";
    &Print_Line("Verifying Current APPS password");
    $Dbh = &Connect_Db("APPS","$CurApsPwd", "$SID");
    $Dbh->disconnect;
    print " Done\n\n";

    foreach $Musr (("AI", "CLM")) {

       while (1) {
          $MusrPwd = "";
          print "     Enter $Musr\@SCMPRD Password(ENTER to previous menu) : ";
          chomp($MusrPwd = <STDIN>);
          last if ($MusrPwd eq "");

          &Print_Line("Verifying $Musr\@SCMPRD password");
          $Dbh = &Connect_Db("$Musr","$MusrPwd", "SCMPRD");
          if ("$Dbh->errstr" ne "") {
             print " FAILED\n\n";
             #CCKdie "\n     ERROR : [$Dbh->errstr]\n\n"
          }
          else {
             print " Done\n\n";
             last;
          }
       }
       if ($MusrPwd eq "") {
          print "\n     Exiting without Creating/Changing the Migrate Db Link\n";
          last ;
       }
       $St1 = qq{SELECT DB_LINK FROM user_db_links WHERE db_link like 'APPS_$SID\%'};
       $Sh1 = $Dbh->prepare($St1) || die "\nPrep Faild [ $St1 ]\n", $Dbh->errstr;
       $Sh1->execute;


       $LinkStatus = "NOTEXISTS";
       while(($DbLink) = $Sh1->fetchrow_array ) {
          &Verify_Migrate_Db_Link;
       }
       $Sh1->finish;

       if ($LinkStatus ne "VALID") {

          $DbLink = "APPS_$SID";
          $Str   = "     Db link $DbLink does not exists for $Musr\@SCMPRD, Creating";
          if ($LinkStatus eq "NOTVALID") {
             &Print_Line("Dropping invalid Db link $DbLink from $Musr\@SCMPRD");
             $r = $Dbh->do("drop database link $DbLink");
             print " Done\n";
             &Print_Line("Creating Db link $DbLink for $Musr\@SCMPRD");
          }
          $r = $Dbh->do("create database link $DbLink connect to APPS identified by $CurApsPwd using '$SID'");
          print " Done\n";
          &Verify_Migrate_Db_Link;
       }
       $Dbh->disconnect;
    }
    &Debug_Now if ($Debug);
}

# **********************
# Verify_Migrate_Db_Link
# **********************
sub Verify_Migrate_Db_Link {

    $WhereIam = "Verify_Migrate_Db_Link";
    $LinkStatus = 'NOTVALID';
    &Print_Line("Verifying the link $DbLink");

    $St2 = qq{SELECT global_name FROM global_name\@$DbLink};
    $Sh2 = $Dbh->prepare($St2); 

    if ("$Dbh->errstr" ne "") {
       print " Not Valid\n\n";
       print "     $Dbh->errstr\n";
       print "     Fix this error and re-try this option.\n\n";
       $LinkStatus = 'VALID';
       return;
    }
    $Sh2->execute; 

    if ("$Dbh->errstr" ne "") {
       print " Not Valid\n\n";
    }
    else {
       print " Valid Link\n\n";
    }
    $Sh2->finish;
    $LinkStatus = 'VALID';
    &Debug_Now if ($Debug);
}
#EEEENNNNDDDDD


#==============
# Screen_Scroll
#==============
sub Screen_Scroll {
    #system("clear screen");
    #$Ssln = $ENV{'LINES'};
    #$Ssln = $Ssln/2;
    #print "\n"x$Ssln;
    print "\n"x9;
}

#=================
# Get_Apps_Version 
#=================
sub Get_Apps_Version {

    #CCK &Connect_Db("APPS","$CurApsPwd", "$SID");
    #CCK $Sh1 = $Dbh->prepare("SELECT release_name FROM apps.fnd_product_groups") || die $Dbh->errstr;
    #CCK $Sh1->execute;
    #CCK ($ApsVersion) = $Sh1->fetchrow_array;
    #CCK $Sh1->finish;
    #CCK $Dbh->disconnect;
}

#===============
# Apps_Pre_Check 
#===============
sub Apps_Pre_Check {
 #CCK    if (!(-d "/apps/local")) {
 #CCK        &Print_Line("Linking /apps/local not exist, Unable to move Apache log directory");
 #CCK        print " Not Done\n";;
 #CCK        return;
 #CCK    }
}

#============
# Backup_File 
#============
sub Backup_File {
    my $File;
    my $Phase;
    my @BackupFile ;

    chomp($TExt = `date +\%d\%b\%H\%M\%S`);
    ($File, $Phase) = split(',',$_[0]);

    @BackupFile = split('/',$File);
    system("mkdir -p $CloneBackupDir");

    if (!(-f "$CloneBackupDir/$BackupFile[$#BackupFile].$Phase.$Ext")) {
       system("cp $File $CloneBackupDir/$BackupFile[$#BackupFile].$Phase.$Ext");
       system("chomod 600 $CloneBackupDir/$BackupFile[$#BackupFile].$Phase.$Ext");
    }
}

#==================
# Display_Apps_Info
#==================
sub Display_Apps_Info {

    #&Verify_Apps_Env;
    print "\n\t\t\t\t","="x50,"\n";
    print "\t\t\t\t$SID application information\n";
    print "\t\t\t\t","="x50,"\n";
    print  "\t\t\t\t$SID copy of       : $ClonedFrom\n" if ($ClonedFrom);
    print  "\t\t\t\tApplication Owner    : $Owner\n";
    print  "\t\t\t\tApplication          : $Sid\n";
    print  "\t\t\t\tApplication Vname    : $ApTierGiven\n";
    print  "\t\t\t\tApplication Server   : $ApTierActual\n";
    print  "\t\t\t\tDatabase Vname       : $DbTierGiven\n";
    print  "\t\t\t\tDatabase Server      : $DbTierActual\n";
    print  "\t\t\t\tStage Directory      : $Stage\n";
    print  "\t\t\t\tApplTop              : $ApplTop\n";
    print  "\t\t\t\tJtfTop               : $JtfTop\n";
    print  "\t\t\t\tCommTop              : $CommTop\n";
    print  "\t\t\t\tOraHome              : $OraHome\n";
    print  "\t\t\t\tIasTop               : $IasTop\n";
    print  "\t\t\t\tApacheTop            : $ApacheTop\n";
    print  "\t\t\t\tJservTop             : $JservTop\n";
    print  "\t\t\t\tApacheLockDir        : $ApacheLockDir\n";
    print  "\t\t\t\tCurrent Apps Pwd     : $CurApsPwd\n";
    print  "\t\t\t\tCurren Portal30 Pwd  : $CurP30Pwd\n";
    if ( $AppsNas ) {
       print  "\t\t\t\tIs it NAS            : Yes\n";
    }
    else {
       print  "\t\t\t\tIs it NAS            : No\n";
    }
    print  "\t\t\t\tXmlFile name         : $XmlFile\n";
    print  "\t\t\t\tContext Name         : $ContextName\n";
    print  "\t\t\t\tDb Listner Port      : $DbLsnrPort\n";
    print  "\t\t\t\tApplication Version  : $ApsVersion\n";
    print  "\t\t\t\tHomeUrl              : $HomeUrl\n";
    print  "\t\t\t\tConfDir              : $ConfDir\n";
    print  "\t\t\t\tMail Id              : $MailId\n";
    print  "\t\t\t\tPager Id             : $PagerId\n";
    print "\n\t\t\t\tAre the above informations Correct?(Y/N) : ";
    chomp($AppsEnvOk = <STDIN>);
    print "\n\n";
    if (uc($AppsEnvOk) ne "Y") {
       die "\t\t\t\t!!! Fix the information which you think not correct and re-run smartclone !!!\n\n";
    }
    $GetxStr='klmnopabcdefqrstuvwghijxyz';
}

#================
# Verify_Apps_Env
#================
sub Verify_Apps_Env {

    $WhereIam    = "Verify_Apps_Env";
    my $MyErr    = 0;
    my $MyFixErr = "";
    my $MyStrg   = "";
    my $MyNum    = 0 ;
    my $MyAbort  = 0 ;

    chomp($MyNum = `ls $ApplAdm/*xml |wc -l`);

    if ($MyNum > 1) {
       $MyErr++;
       $MyFixErr .= "\t\t* Multiple xml files found in $ApplAdm, Keep only required file.\n\n" ;
    }
    if ($MyNum < 1) {
       $MyErr++;
       $MyFixErr .= "\t\t* No xml files found in $ApplAdm, Copy the xml file \n\n" ;
       $MyAbort  = 1;
    }

    if ($MyErr) {
       print "\n\n\n\t\t------------------------------------------------------\n" ;
       print "\t\t!!! Fix the following error/s and rerun smartclone !!!\n" ;
       print "\t\t------------------------------------------------------\n" ;
       print "$MyFixErr";
       exit(1);
    }


    foreach $F (("/var/local","/apps/orarpt","/var/opt/oracle/oraInst.loc","/etc/appstab" )) {

       $Fname = $F;
       $Fname = readlink $Fname  if (-l "$Fname");
    
       if (! -f "$Fname" && ! -d "$Fname" ) {
          $MyFixErr .= "\t\t* \"$Fname\" does not Exists\n";
       }
       elsif (! -f "$Fname" && $Fname ne $F && defined($Fname) ) {
          $MyErr++;
          $MyFixErr .= "\t\t* \"$Fname\" does not Exists\n";
       }
       else {
           chomp($Per = `ls -ld $Fname | cut -d " " -f1`);
           if ( substr($Per,5,1) ne 'w' ) {
              $MyErr++;
              $MyFixErr .= "\t\t* \"$Fname\" not writable by $Owner\n" ;
           }
       }
    }

    foreach $F (('/tmp/templbac', "$ConfDir")) {
       $Fname = $F;
       if ( -d "$Fname" && ! -o "$Fname" ) {
           $MyErr++;
           $MyFixErr .= "\t\t* [$Fname] notowned by [$Owner], remove this directory.\n\n" ;
       }
    }

    chomp($Stg=`ls $Stage|wc -l`) if ($Stage);
    if (! $Stg) {
       $MyErr++;
       $MyFixErr .= "\t\t* [$Stage] directory is Empty, copy the stage from the source.\n\n" ;
    }
   
    $MyStrg = "/etc/cron.allow";
    $MyStrg = "/var/adm/cron/cron.allow" if ($Os eq "HP-UX") ;
    chomp($MyNum = `grep $Owner $MyStrg`);
    if (! $MyNum) {
       $MyErr++;
       $MyFixErr .= "\t\t* [$Owner] doesnot have crontab privilege, request sysadmin team to add it.\n\n" ;
    }

    #CCK chomp($MyNum = `grep wwwin-$Sid /etc/hosts`);
    chomp($MyNum = `grep $ApTierGiven /etc/hosts`);
    if (! $MyNum) {
       $MyErr++;
       $MyFixErr .= "\t\t* Loop back entry not added in /etc/hosts for $ApTierGiven.\n\n" ;
       $MyAbort  = 1;
    }
    chomp($MyStrg = `groups $Owner |cut -d ":" -f2`);
    $MyStrg =~ s/^ //;

    if (!($MyStrg =~ /gcc296/) && ($Os eq 'LINUX')) {
       $MyErr++;
       $MyFixErr .= "\t\t* $Owner not assinged to gcc296 group, ask Sysadmins to add.\n\n" ;
    }

    $MyStrg = (split(' ',$MyStrg))[0];
    if ($MyStrg ne 'dba') {
       $MyErr++;
       $MyFixErr .= "\t\t* $Owner not having dba as primary group, ask sysadmin's to add then restart smartclone.\n\n" ;
       $MyAbort  = 1;
    }


    if ($MyErr) { 
       print "\n\n\n\t\t------------------------------------------------------\n" ;
       print "\t\t!!! Fix the following error/s and rerun smartclone !!!\n" ;
       print "\t\t------------------------------------------------------\n" ;
       print "$MyFixErr";
       exit(1) if ($MyAbort);
       print "\n\t\tif these are not required for your task, you can ignore temporarly for now\n"; 
       print "\n\t\tDo you want to continue?(Y/N) : ";
       chomp($MyStrg = <STDIN>);
       print "\n\n";
       exit(1) if (uc($MyStrg) ne "Y") ;
    }
    &Debug_Now if ($Debug);
}

#===================
# Backup_After_Clone
#===================
sub Backup_After_Clone {
    $WhereIam = "Backup_After_Clone";
    &Check_For_Restart($WhereIam);
    return if ($Skip);


    my $BackDir = "$CloneBackupDir/after_clone";
    my $Fname1 = "$CloneBackupDir/after_clone/restore_after_clone_backup.sh";
    my $Fname2 = "$CloneBackupDir/after_clone/diff_before_after_clone_files.sh";
    system("mkdir -p $BackDir");
    system("chmod 700 $BackDir");
    system("chmod 700 $BackDir/*sh");
    
    open(FW1, ">$Fname1") || die "Cannot open new file $Fname1 $!\n";
    open(FW2, ">$Fname2") || die "Cannot open new file $Fname2 $!\n";
    print FW1 "#---------------------------------------------------------------------------------------\n";
    print FW1 "# This script will restore the config files which are taken backup followed by the cloing\n";
    print FW1 "# Use this in case of issue or want to compare after the cloning\n";
    print FW1 "#---------------------------------------------------------------------------------------\n\n";

    print FW2 "#---------------------------------------------------------------------------------------\n";
    print FW2 "# This script will display the changes made between config files and backup files which \n";
    print FW2 "# are taken after destination cloning\n";
    print FW2 "#---------------------------------------------------------------------------------------\n\n";


    foreach $Files2Move(("$ApacheConfDir/httpd.conf",
                         "$ApacheConfDir/httpd_pls.conf",
                         "$ApacheConfDir/oprocmgr.conf",
                         "$ApacheConfDir/WebAgent.conf",
                         "$ModTop/plsql.conf",
                         "$ApacheConfDir/apps.conf",
                         "$IasTop/Apache/modplsql/cfg/wdbsvr.app",
                         "$IasTop/${SID}.env",
                         "$CommTop/portal/aplogon.html",
                         "$ApplAdm/adconfig.txt",
                         "$iTnsAdmin/tnsnames.ora",
                         "$TnsAdmin/tnsnames.ora",
                         "$TnsAdmin/listener.ora")) {

       next if (! -f  "$Files2Move");
       my @BackupFile = split('/',$Files2Move);

       if ($Files2Move =~ /iAS\/network/ ) {
          system("cp -p $Files2Move $BackDir/$BackupFile[$#BackupFile].iAs.$Ext");
          print FW1 "cp -p $BackDir/$BackupFile[$#BackupFile].iAs.$Ext $Files2Move\n";
          print FW2 "echo\necho\n";
          print FW2 "echo =================================================================================\n";
          print FW2 "echo Difference between Backup file and Current file of $BackupFile[$#BackupFile]\n";
          print FW2 "echo =================================================================================\n";
          print FW2 "diff $BackDir/$BackupFile[$#BackupFile].iAs.$Ext $Files2Move |pg\n";
       }
       else {
          system("cp -p $Files2Move $BackDir/$BackupFile[$#BackupFile].$Ext");
          print FW1 "cp -p $BackDir/$BackupFile[$#BackupFile].$Ext $Files2Move\n";
          print FW2 "echo\necho\n";
          print FW2 "echo =================================================================================\n";
          print FW2 "echo Difference between Backup file and Current file of $BackupFile[$#BackupFile]\n";
          print FW2 "echo =================================================================================\n";
          print FW2 "diff $BackDir/$BackupFile[$#BackupFile].$Ext $Files2Move |pg\n";
       }
    }
    close(FW1);
    close(FW2);
    system("chmod 700 $BackDir/*.$Ext");
    system("chmod 700 $Fname1 $Fname2");
    &Print_Header("Following files can be used in case of any issue");
    &Print_Line("To Restore the original files use $Fname1\n");
    &Print_Line("To check difference use $Fname2\n");
    print "\n";
    &Debug_Now if ($Debug);

    system("touch $Home/DBA/clone/.${WhereIam}");
}

#============== 
# Backup_Tables
#============== 
sub Backup_Tables {    

    ($SrcTable, $CopyTable) = @_;

    &Print_Line("Backingup $SrcTable to $CopyTable");
    $DoSt = qq{Create table ops\$oracle.$CopyTable as select * from $SrcTable};
    #$Dbh->do("Create table ops\$oracle.$CopyTable as select * from $SrcTable");
    $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n",$Dbh->errstr;
    print " Done\n";
}

#===================================
# Set_Password_Verification_Function
#=================================== 
sub Set_Password_Verification_Function {    

    $WhereIam = "Set_Password_Verification_Function";
    &Check_For_Restart($WhereIam);
    return if ($Skip);

    ($ToVal) = @_;

    $Str   = "     Enabling password Verification function";
    $ToVal = "VERIFY_FUNCTION";
    if ($ToVal eq "OFF") {
       $Str   = "     Disabling password Verification function";
       $ToVal = "NULL";
    }
    &Print_Line($Str);
    $DoSt = qq{alter profile default limit password_verify_function $ToVal}; 
    #CCK1 $Dbh->do(qq{alter profile default limit password_verify_function $ToVal}) || die $Dbh->errstr;
    $Dbh->do($DoSt) || die "\nStmt Faild [ $DoSt ]\n", $Dbh->errstr;
    print " Done\n";
    &Debug_Now if ($Debug);
    system("touch $Home/DBA/clone/.${WhereIam}");

}

#===============
# Print_Header
#===============
sub Print_Header {
    ($Str) = @_;
    $Ln = length($Str);
    print "\n$Str\n","-"x$Ln,"\n";
}

#=============
# Print_Line
#=============
sub Print_Line {
    ($Str) = @_;
    $Ln = 80 - length($Str);
    print "     $Str ","."x$Ln;
}

#===========
# Print_Info
#===========
sub Print_Info {
    ($Str) = @_;
    print "     $Str\n";
}

#==============
# Print_ToDos
#==============
sub Print_ToDos {
   return if ($#ToDoList == -1);
    $j = 1;
    &Print_Header("Here is the do list for you");
    if ($Owner =~ /^oa/) {
       push(@ToDoList, "Change apps, sysadmin user password if needed using OTHER tasks option");
       push(@ToDoList, "Create DB Link in SCMPRD Database for Kintana workflow if needed using OTHER tasks option");
       push(@ToDoList, "Add Concurrent Manager node to FND_NODES thru Application before testing Concurrent manager");
    }
    foreach $st (@ToDoList) {
       print "$j  $st\n";
       $j++;
    }
}

#==============
# Debug_Now
#==============
sub Debug_Now {

    $DN="";
    print "\n***** Debug> Executed step {$WhereIam}, Continue?(Y/N) : ";
    chomp($DN = <STDIN>);
    print "\n";
    exit  if (uc("$DN") ne "Y") ; 
    
}

#==================
# Check_For_Restart
#==================
sub Check_For_Restart {

    $Skip = 0;

    if (-f "$Home/DBA/clone/.${WhereIam}"  && -f "$Home/DBA/clone/.RunningInBundle" ){
       print "\n\t$WhereIam Already Completed. Skiping .....\n";
       $Skip=1;
    }
}

#=================
# Set_Ora_Home
#=================
sub Set_Ora_Home {

    require "/usr/tools/oracle/Standard/script/perllib.pl";
    use lib "/usr/tools/oracle/Standard/lib/";
    use StdDBPackage;

    my $oracle_sid;
    my $oracle_home;
    $oracle_sid  = $_[0];
    $oracle_home = "$OraHome";

    if ($oracle_sid) {
       open(ORATAB, "/etc/oratab") || &dbstats_error("Can't Open /etc/oratab. $!\n");
       while (<ORATAB>) {
           if (/^${oracle_sid}:/) {
               $oracle_home = (split(':'))[1];
               $ENV{'ORACLE_HOME'} = $oracle_home;
               $ENV{'ORACLE_SID'}  = $oracle_sid;
           }
       }
       close(ORATAB);

       if (! ($oracle_home) ) {
          die "\n\n\n Invalid ORACLE_SID <$oracle_sid> passed \n";
       }
    }

    $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
    $ENV{'SHLIB_PATH'} = "$oracle_home/lib";
    $ENV{'TNS_ADMIN'} = "$oracle_home/network/admin";
    ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
    ($nls)=&StdDBPackage::check_nls;

    if ($oracle7 eq "Y") {
       $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
       $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
    }
    else {
       if ($nls eq "Y" ) {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
       }
       else {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
       }
    }

    &StdDBPackage::which_lib();
}

#-----------------------------------------------------------------------------------------------------------#
#--------------------------------------> End of Smartclone <------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------#
