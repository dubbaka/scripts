#!/oracle/product/perl
##!/usr/local/bin/perl
#####################################################################################
# Name    : check_sync_and_recover.pl
# Version : 1.0
# Date    : 05-03-2006
# Author  : raraveet

# Description :
#       This scripts alerts in below scenarious
#               Alert1-> alerts if DR host archives lags production host
#                        by certain no. of minutes
#               Alert2-> alerts if DR applied logs lags production log archive
#                        by certain no. of minutes
#               Alert3-> alerts if DR is manually stopped ( in case of refreshes/
#                        maintainence) for morethan a day
#
$Synopsis = <<X;
 Syntax:check_sync_and_recover.pl -i<Instance_name> 
				  -t<sync_arch_mail_limit> -r<drlog_mail_limit>
	Example: check_sync_and_recover.pl -iCTSPRD2 -t20m -r40m
        
	Defaults:
	<sync_arch_mail_limit> 	(opt_t) = 2h
	<sync_arch_page_limit> 	(opt_p)	= 4h
	<drlog_mail_limit>	(opt_r)	= 5h
	<drlog_page_limit>	(opt_e)	= 6h
	<manual_dr_stoplimit>   (opt_d) = 1d


X
#
# MODIFICATION HISTORY:
# NAME          DATE            COMMENTS
# raraveet      05/03/2006      Initial Version (1.0)
# rarveet       05/12/2006      Modified to support RAC
# raraveet	05/16/2006	Added check on logs behind in terms of time
#				If norecover is NOT set AND 
#				   drlog lagtime > certain time then Alert
#				If norecover is SET and lagtime > 10hrs - Alert 
# raraveet	06/01/2006	Modified to accept page and email thresholds
# raraveet	06/04/2006	Added option to input no. of days to ignore alerts 
#				during manulay dr stop or refreshes ,
#				By default alerts if norecover_flag is set for more 
#				than a day.
#				touch below flag to ignore pages during maintenance/know 
#				issues
#				/usr/tools/oracle/recovery/norecover/SID.nopage.24h or
#				/usr/tools/oracle/recovery/norecover/SID.nopage.2d
#
##########################################################################
use POSIX;
require "stat.pl";
require "ctime.pl";
use Getopt::Std;
use Time::Local;
use File::Basename;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;

############################ MAIN ########################################

$pname=basename($0);
print "\n$pname: Started : ",&ctime(time);
&readInput();
&getProdLastArch($instance);
&getDRLastArch($database);
&getSyncArchLogLag();
&getDRLogLag();
print "\n";
print "\n$pname: End : ",&ctime(time);
print "\n";

############################ MAIN ########################################

#-----------------------------------------------------------------------------
# readInput :
#     Process command line switches and options: print usage msg. on error
#-----------------------------------------------------------------------------
sub readInput()
{

        &Usage if ( !getopts('h:i:t:r:p:e:d:') );
        $instance               = $opt_i ? $opt_i : uc($ARGV[0]) ;
	$sync_arch_mail_limit   = $opt_t ? $opt_t : "2h";
	$sync_arch_page_limit	= $opt_p ? $opt_p : "4h";
	$drlog_mail_limit	= $opt_r ? $opt_r : "5h";
	$drlog_page_limit	= $opt_e ? $opt_e : "6h";
	$manual_dr_stoplimit	= $opt_d ? $opt_d : "1d";
        &Usage if ( !$instance );

        $sync_arch_path         = "/usr/tools/oracle/sync_arch/adm";
	$norecover_path		= "/usr/tools/oracle/recovery/norecover";
	$SSH			= "/usr/local/bin/ssh";
	$local_host		= `hostname`;
	chomp($local_host);
	
	$ENV{sid}		= $instance ; #support sid reads from sync_arch cfg file
	&setOraclehome($instance);
}

sub Usage {
       $exit = shift(@_) || 0;
       print STDERR "\nusage:\n$Synopsis";
       exit $exit;
}

#-----------------------------------------------------------------------------
# setOraclehome :
#    Sets  ORACLE_HOME based on /etc/oratab
#    sets envs like mailto ,pageto from standard package, job exists if database
#    is not found in /etc/oratab
#-----------------------------------------------------------------------------
sub setOraclehome()
{
    my $dbname = @_[0];
    $db_check="N";
    open(ORATAB, "/var/opt/oracle/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>) {
        if (/^${dbname}:/)
        {
            $db_check			= "Y";
            $oracle_home 		= (split(':'))[1];
            $ENV{'ORACLE_SID'} 		= $dbname;
            $ENV{'ORACLE_HOME'} 	= $oracle_home;
            $ENV{'LD_LIBRARY_PATH'} 	= "$oracle_home/lib";
            $ENV{'SHLIB_PATH'} 		= "$oracle_home/lib";
            ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($dbname);
	    # remove below line after testing 
            #$mailto="raraveet";
	    $pageto="db-monitor-duty";
        }
    }
    close(ORATAB);

    if( $db_check eq "N"){
            print "Error! Invalid Database/Instance name:$dbname";
	    print "\nAborting ...\n\n";
            exit;
    }
}


#-----------------------------------------------------------------------------
# getProdLastArch :
#   Determines current archiving destination from  database.
#   if database is in NOARCHIVE mode or cannot be connected then the
#   function returns null log_archive_dest
#   the format expected log_archive_dest=/archive/SCEPROD_arch/SCEPROD.arch
#                       log_archive_format=%t_%s.dbf
#-----------------------------------------------------------------------------
sub getProdLastArch()
{
    $log_archive_dest = "";
    $log_archive_dir  = "";

    print "\n getProdLastArch  : $instance";
    if ( -f "$ENV{ORACLE_HOME}/dbs/init${instance}.ora" ) {
        open(SQLDBA, "$oracle_home/bin/sqlplus /nolog << END
        connect /as sysdba
        archive log list
	show parameter instance_number
	show parameter db_name
	show parameter log_archive_format
        exit
        END |") || die "sqlplus error: $!";

        @data = <SQLDBA>;
        (@data1 = grep (/Database log mode/,@data)) ;
        $archive_mode=(split(' ', @data1[0]))[4];
       
        if ( $archive_mode =~ /No/ ) {
                print " is in No Archivemode";
                return(1);
        }

	# find db_name
	(@data3  = grep(/^db_name/, @data)) || die "Can't Find db_name: @data";;
	$db_name = (split(' ', @data3[0]))[2];
	print "\n	db_name = $db_name";
	$database = $db_name;

        (@data4  = grep(/^log_archive_format/, @data)) || die "Can't Find instance_number: @data";;
        $log_archive_format = (split(' ', @data4[0]))[2];
        #print "\nlog_archive_format=$log_archive_format";

	# find archive dest
        (@data2  = grep(/^Archive destination/, @data)) || die "Can't Find Archive Location: @data";;
        $log_archive_dest = (split(' ', @data2[0]))[2];
	$log_archive_dest=$log_archive_dest.$log_archive_format;
	$prod_log_archive_dest=(split('%',$log_archive_dest))[0];

        $prod_log_archive_dest =~ /(.*)\/(\w*)/;
        $log_archive_dir =$1;
        if ( $2 ne $database ){
                print "\n	Error! $database: Invalid PROD log_archive_dest format \n\n";
		print "\n 	Aborting ...";
                exit ;
        }
        print "\n	prod_log_archive_dest   = $prod_log_archive_dest";

	# find last log sequence
        (@data3 = grep(/^Next log sequence to archive/, @data))||die "Can't Find Next log sequence: @data";;
	$next_log_sequence = (split(' ', @data3[0]))[5];
	$prod_last_arch_sequence = int($next_log_sequence) - 1;
	print "\n	prod_last_arch_sequence = $prod_last_arch_sequence";

	(@data4  = grep(/^instance_number/, @data)) || die "Can't Find instance_number: @data";;
	$instance_number = (split(' ', @data4[0]))[2];
	$instance_number = $instance_number +1 if ( $instance_number  == 0 )  ;
	print "\n	instance_number         = $instance_number";

    }
    $star_log_archive_dest  = $prod_log_archive_dest;
    $star_log_archive_dest =~ s/[123456789]/*/;
    print "\n";
}

#-----------------------------------------------------------------------------
# getDRLastArch :
#   Connects to DR host and gets last archfile shipped  
#
#-----------------------------------------------------------------------------
sub getDRLastArch()
{
	print "\n getDRLastArch    : $database ";
	$init_ora = "/oracle/admin/${database}/pfile/init${database}.ora";

	$sync_arch_file  = "sync_arch_${database}_thread${instance_number}.cfg";
	$sync_arch_file  = "sync_arch_${database}.cfg" if(!-f "$sync_arch_path/$sync_arch_file");
	if(!-f "$sync_arch_path/$sync_arch_file"){
		print "\n	Error! Unable to read $sync_arch_path/$sync_arch_file" ;
                print "\n       Error! Unable to get info(dr_last_archfile) from DR host ${remote_host} ";
                print "\n       Program terminated \n\n";
                exit 1;
	}

        if ( -f "$sync_arch_path/$sync_arch_file") {
                open(DRHOST,"$sync_arch_path/$sync_arch_file")|| die "Can't Open $sync_arch_path/$sync_arch_file ";
                while(<DRHOST>){
                        if ( /^remote_sys/ ) {
                                $remote_host=(split('='))[1];
                                chomp($remote_host);
                        }
                        if ( /^remote_arch_dir/ ) {
                                $dr_log_archive_dest=(split('='))[1];
                                chomp($dr_log_archive_dest);
				$dr_log_archive_dest=`echo ${dr_log_archive_dest}`;
                                chomp($dr_log_archive_dest);
                        }
                }
                close(DRHOST);
	}
	$dr_log_archive_dest=${dr_log_archive_dest}."${database}\.arch";
        $dr_log_archive_dest =~ /(.*)\/(\w*)/;
        $dr_log_archive_dir =$1;
        if ( $2 ne $database ){
                print "\n	Error! $database: Invalid DR log_archive_dest format \n\n";
		print "\n	Aborting ...";
                exit;
        }
        print "\n	dr_log_archive_dest   = $dr_log_archive_dest";

#	$dr_last_archfile=`$SSH -n ${remote_host} "ls -1tr ${dr_log_archive_dest}${instance_number}\* | tail -1"`;
        @dr_last_archfile_a=`$SSH -n ${remote_host} "ls -1tr ${dr_log_archive_dest}${instance_number}\* | tail -50"`;
        @dr_last_archfile_sa=sort(@dr_last_archfile_a);
        $last = @dr_last_archfile_sa;
        $dr_last_archfile= $dr_last_archfile_sa[$last-1];

	chomp($dr_last_archfile);
	if (!$dr_last_archfile) {
        	print "\n	$SSH -n ${remote_host} ls -1tr ${dr_log_archive_dest}${instance_number}\* | tail -1";
		print "\n	Error! Unable to get info(dr_last_archfile) from DR host ${remote_host} ";
		print "\n	Program terminated \n\n";
		exit 1;
	}

	$dr_last_archfile=~ /(.*)\/(\w+)(.*)_(\d*).dbf(.*)/ ;
        $dr_last_arch_sequence = int(${4});
	print "\n	dr_last_arch_sequence = $dr_last_arch_sequence ";
	print "\n";
}

#-----------------------------------------------------------------------------
# findLastArchFile :
#	Input parameter is sequence number and finds the last archfile
#	based on sequence which is used to determine timestamp of the 
#	later in getSyncArchLogLag()
#-----------------------------------------------------------------------------
sub findLastArchFile()
{
        my $seq = @_[0];
        open(LASTFILE, "ls -1tr $star_log_archive_dest* | grep dbf | grep $seq | tail -1 |") || die;
        while (<LASTFILE>) {
            $archfile=$_;
            chomp ${archfile};
        }
        close(LASTFILE);
        return ( $archfile ) ;
}

#-----------------------------------------------------------------------------
# getSyncArchLogLag :
#	Invokes findLastArchFile to get last timestamp of last archfile 
#	from production and dr and does time diff , alerts if the time diff
#	is greated than the input value (sync_arch_mail_limit )
#-----------------------------------------------------------------------------
sub getSyncArchLogLag()
{
  print "\n getSyncArchLogLag :";
  $prod_last_archfile= &findLastArchFile($prod_last_arch_sequence);
  $dr_last_archfile  = &findLastArchFile($dr_last_arch_sequence);

  &Stat($prod_last_archfile ) ;
  $prod_mtime = $st_mtime;

  &Stat($dr_last_archfile);
  $dr_mtime = $st_mtime ;

  $lagtime =  $prod_mtime - $dr_mtime ;
  $sync_arch_mail_sec = &convertTime($sync_arch_mail_limit);
  $sync_arch_page_sec = &convertTime($sync_arch_page_limit);

  print "\n	prod_last_archfile   = $prod_last_archfile";
  print "\n	dr_last_archfile     = $dr_last_archfile ";
  print "\n	sync_arch_mail_limit = $sync_arch_mail_sec sec";
  print "\n	sync_arch_page_limit = $sync_arch_page_sec sec";
  print "\n	current lag 	     = $lagtime sec";
  $lagtime_m = int($lagtime/60);

  if ( $lagtime > $sync_arch_mail_sec ) 
  {
    print "\n	Sending email ... ";
    $errmsg = &msgfmt("w","$local_host","$database","sync_arch lags log shipping by more than $lagtime_m minutes");
    print " \n	WARN:$local_host:$database sync_arch lags log shipping by more than  $lagtime_m minutes \n";
    &mailit("$errmsg","/dev/null");
  }
  if ( $lagtime > $sync_arch_page_sec ) 
  {
    print "\n	Sending epage ... ";
    $errmsg = &msgfmt("w","$local_host","$database","sync_arch lags log shipping by more than $lagtime_m minutes");
    print " \n	WARN:$local_host:$database sync_arch lags log shipping by more than  $lagtime_m minutes \n";
    &pageit("$errmsg");
  }
  print "\n";
}

#-----------------------------------------------------------------------------
# convertTime :
#     convert time variable from days ,hours or minutes into seconds
#     for later comparison
#-----------------------------------------------------------------------------
sub convertTime()
{
  $purge_param=@_[0];
  if ( $purge_param =~ /(\d*)h$/ ) {
        $purge_param = ${1};
        $purge_time = int(${1}) * 60 * 60;
        $interval   = "hours";
  }
  elsif ( $purge_param =~ /(\d*)m$/ ) {
        $purge_param = ${1};
        $purge_time = int(${1}) * 60;
        $interval   = "minutes";
  }
  elsif ( $purge_param =~ /(\d*)d$/ ) {
        $purge_param = ${1};
        $purge_time = int(${1}) * 24 * 60 * 60;
        $interval   = "days";
  }
  else {
        $purge_time = $purge_param * 60;
        $interval   = "minutes";
  }
 return(int($purge_time));
}

#-----------------------------------------------------------------------------
# getDRLogLag :
#	Connects to DR host and get the last thread/sequence applied to DR 
#	and determines the time diff between the last archlog from prod and 
#	and last archlog applied on DR and alerts if the time diff is greater
#	than the input value ( drlog_mail_limit ) 
#-----------------------------------------------------------------------------
sub getDRLogLag()
{
   print "\n getDRLogLag :";
   $current_thrd	= $prod_last_arch_sequence;
   $thread_path	= "/usr/tools/oracle/recovery/thread";

   if ( $instance_number != 0 ) {
        $thread_file  = "${database}_thread${instance_number}.dat";
   }
   else {
        $thread_file  = "${database}_thread1.dat" ;
   }

   #print "\n	$SSH $remote_host cat $thread_path/$thread_file";
   $remote_thrd	= `$SSH $remote_host cat $thread_path/$thread_file `;
   chomp($remote_thrd);
   print "\n 	remote_thrd  	= $remote_thrd";
   print "\n 	current_thrd 	= $current_thrd ";

   $stmt = "SELECT 	'to_be_recovered  ' ||
			ROUND((plog.FIRST_TIME - dlog.FIRST_TIME)*24*60)
	    FROM 	v\\\$log_history dlog , v\\\$log_history plog
	    WHERE 	dlog.SEQUENCE# = $remote_thrd 
	    AND 	plog.SEQUENCE# = $current_thrd";

   open(SQLDBA, "$oracle_home/bin/sqlplus /nolog << END
        connect /as sysdba
        show parameter db_name
	alter session set nls_date_format = 'DD-MON-YY HH24:MI:SS';
	set heading off
	$stmt ;
        exit
        END |") || die "sqlplus error: $!";
        @data = <SQLDBA>;

   (@data1  = grep(/^to_be_recovered/, @data)) || die "Can't Find to_be_recovered: @data";;
   $to_be_recovered = (split(' ', @data1[0]))[1];
   $to_be_recovered_sec = int($to_be_recovered * 60) ;
   #print "\n        to_be_recovered = $to_be_recovered";

   $drlog_mail_sec = &convertTime($drlog_mail_limit) ;
   $drlog_page_sec = &convertTime($drlog_page_limit) ;
   $manual_dr_stop_sec = &convertTime($manual_dr_stoplimit);
   #print "\n        manual_dr_stop_limit = $manual_dr_stoplimit $manual_dr_stop_sec\n";

   my $str              = qq(date +'%S:%M:%H:%d:%m:%Y';ls -1tr ${norecover_path}/${database}|wc -l);
   chomp(($cdate,$norecover_flag)=qx($SSH -n ${remote_host} "$str"));
   print "\n        norecover_flag   = $norecover_flag";

   print "\n        drlog_mail_limit = $drlog_mail_sec sec";	
   print "\n        drlog_page_limit = $drlog_page_sec sec";	
   print "\n        to_be_recovered  = $to_be_recovered_sec sec";

   return if ( &checkNopage($database) eq "YES" );
   print "\n        After checkNoPage";
   if ( ($norecover_flag != 1 && $to_be_recovered_sec  > $drlog_mail_sec)  ||
	($norecover_flag == 1  && $to_be_recovered_sec  > $manual_dr_stop_sec)
      )
  {
    	print "\n   	Sending email ... ";
    	$errmsg = &msgfmt("w","$local_host","$database","DR is $to_be_recovered minutes behind production db");
    	print " \n  	WARN:$local_host:$database DR is $to_be_recovered minutes behind PROD\n";
    	&mailit("$errmsg","/dev/null");
  }
   if ( ($norecover_flag != 1 && $to_be_recovered_sec  > $drlog_page_sec)  ||
	($norecover_flag == 1  && $to_be_recovered_sec  > $manual_dr_stop_sec)
      )
  {
    	print "\n   	Sending epage ... ";
    	$errmsg = &msgfmt("w","$local_host","$database","DR is $to_be_recovered minutes behind production db");
    	print " \n  	WARN:$local_host:$database DR is $to_be_recovered minutes behind PROD\n";
    	&pageit("$errmsg");
  }
  print "\n";
}

sub checkNopage(){
   my $dbname = @_[0];
   $ENV{dbname}=$dbname;
   if ( $norecover_flag == 1 && $to_be_recovered_sec > 6*60*60 ) {
        print "\n         checkNopage:$dbname:$norecover_flag:";
        $ssh_script='perl -e \' if ( system(\"ls -1tr /usr/tools/oracle/recovery/norecover/${dbname}.nopage.* \") != 0 ) {
                                        system(\"touch /usr/tools/oracle/recovery/norecover/${dbname}.nopage.24h\") ;
                                }
                                \' ';
        #print "\n ssh_script = $ssh_script ";
        chomp(@nopage_value_a = `$SSH -n ${remote_host} "$ssh_script" `);
	print "\n        nopage_value_a = @nopage_value_a";
       	print "\n        Ignore pages due to refresh/manual DR stop ....";
        return "YES";
   }
   else{
       	print "\n       checkNopage:$dbname:$norecover_flag:";
	$npv="ls -ltr ${norecover_path}/${dbname}.nopage.*| tail -1| tr -s ' '|";
	$npv=$npv."/usr/local/bin/perl -ne '`date`;";
	$npv=$npv."chomp(\@b=split(/ /,\$_)); print \"\$b[5]:\$b[6]:\$b[7]:\$b[8]\"";
       	$nopage_value=`$SSH -n ${remote_host} $npv`;
       	print "\n        nopage_value=$nopage_value";

       	if ( $nopage_value ){
		chomp(($mon,$dd,$hh,$mm,$ff) =split(/:/,$nopage_value));
        	$nopage_value_time   = (split(/\./,$ff))[2];
        	$nopage_value_sec = &convertTime($nopage_value_time) if ( $nopage_value );
       	        print "($nopage_value_sec)";

		%month=('Jan',0,'Feb',1,'Mar',2,'Apr',3,'May',4,'Jun',5,
			'Jul',6,'Aug',7,'Sep',8,'Oct',9,'Nov',10,'Dec',11);

		($ssc,$mmc,$hhc,$ddc,$monc,$yyc) = (split(/:/,$cdate));
		#chomp(($ssc,$mmc,$hhc,$ddc,$monc,$yyc)
		#	=split(/:/,`$SSH -n ${remote_host} date +'%S:%M:%H:%d:%m:%Y'`));
		#print "\n         mm=$mm hh=$hh dd=$dd mon=$month{$mon} yy=$yy ";
		#print "\n         mmc=$mmc hhc=$hhc ddc=$ddc monc=$monc yyc=$yyc ";
		$tdiff=timelocal($ssc,$mmc,$hhc,,$ddc,$monc-1,$yyc)-timelocal(1,$mm,$hh,$dd,$month{$mon},$yyc);

		print "\n        time passed after refresh/manual DR stop=$tdiff sec";
        	if ( $tdiff < $nopage_value_sec ) {
       			print "\n        Ignore pages due to refresh/manual DR stop ...";
                	return "YES";
        	}
	        `$SSH -n ${remote_host} "rm ${norecover_path}/${dbname}.nopage.* `;
        }
  }
}
