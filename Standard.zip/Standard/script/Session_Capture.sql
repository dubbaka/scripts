col interval format a40
col SCHEMA_USER format a20
col what format a60
col interval format a30
col opname format a20
col target format a30
col sid format 9999
col username format a20
col machine format a25
col event format a30
col program format a30
col module format a35
col COMMAND format a20
col sql_text format a40
set lines 200


spool /usr/tools/oracle/Standard/script/log/Session_$ORACLE_SID.log

select to_char(sysdate,'DD-MON-YYYY HH24:MI:SS') "Start Time" from dual;

select INSTANCE_NAME from v$instance;


prompt "Active Sessions"

select s.sid,  username,  module,program, logon_time,sw.EVENT,sql_hash_value from v$session s,v$session_wait sw where s.sid=sw.sid and status='ACTIVE' and username is not null ;

Prompt "Active Sessions Summary"

select username,machine,status,count(*) from v$session group by username,machine,status;


prompt "Temporary tablespace recover"

Select f.R "Recovered", u.nr "Need Recovered" from (select count(block#) R, 1 ch from sys.fet$ ) f,(select count(block#) NR, 1 ch from sys.uet$) u where f.ch=u.ch ;

prompt "Long Running Query"

select sid,serial#,to_char(START_TIME,'DD-MON-YYYY HH24:MI:SS') START_TIME,to_char(LAST_UPDATE_TIME,'DD-MON-YYYY HH24:MI:SS') LAST_UPDATE_TIME,SOFAR,TOTALWORK,TIME_REMAINING,target,USERNAME,SQL_HASH_VALUE from v$session_longops where time_remaining > 0;


Prompt "Progress of the transactions that Oracle is recovering"

select * from v$fast_start_transactions;

Prompt "Parallel Transactions"

select * from v$fast_start_servers;

prompt "Undo Usage more than 100MB"

select sq.sql_text sql_text, t.USED_UREC Records, t.USED_UBLK Blocks, (t.USED_UBLK*8192/1024) KBytes from v$transaction t,
v$session s,
v$sql sq
where t.addr = s.taddr
and s.SQL_HASH_VALUE = sq.HASH_VALUE
and t.USED_UBLK*8192/1024 > 100000;

prompt "Jobs running"

select sid,ID2 from V$LOCK where type = 'JQ';

select '    SID                         : '||v.sid      || chr(10)||
       '    Serial Number               : '||v.serial#  || chr(10) ||
       '    Oracle User Name            : '||v.username         || chr(10) ||
       '    Oracle PID                  : '||p.pid      || chr(10) ||
       '    OS Process ID(spid)         : '||p.spid     || chr(10) ||
       '    Session''s Status           : '||v.status   || chr(10) ||
       '    Logon Time                  : '||to_char(v.logon_time, 'MM/DD HH24:MIpm')  "JOB Queue Process details" 
from v$session v, v$process p
where v.paddr = p.addr
and sid in (select sid from V$LOCK where type = 'JQ')
order by logon_time, v.status, 1;


select job,schema_user,NEXT_DATE,NEXT_SEC,last_date,last_sec,interval,what from dba_jobs where job in (select ID2 from V$LOCK where type = 'JQ');

select to_char(sysdate,'DD-MON-YYYY HH24:MI:SS') "End Time" from dual;

spool off
