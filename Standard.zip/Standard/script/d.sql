
select distinct host from admin_user.dbts_instance
where host in (
select host from admin_user.dbts_instance
where sid in (
select sid
from admin_user.dbts_instance where prod_db_group in (
'CASHPROD', 'STARRCVR', 'CATSPROD', 'CAPPROD', 'CPNRPROD', 'SOLARCH', 'CPNPROD', 'EQPPROD', 'SLSPROD', 'GFO9PRD',
'EWHPROD', 'LABPROD', 'EPUBPRD', 'GFOPRD', 'BVEWHPRD', 'ATMGPRD', 'BVESOPD')
)
)
and prod_db_group not in (
'CASHPROD', 'STARRCVR', 'CATSPROD', 'CAPPROD', 'CPNRPROD', 'SOLARCH', 'CPNPROD', 'EQPPROD', 'SLSPROD', 'GFO9PRD',
'EWHPROD', 'LABPROD', 'EPUBPRD', 'GFOPRD', 'BVEWHPRD', 'ATMGPRD', 'BVESOPD')
/


select distinct host from admin_user.dbts_instance
where sid in (
select sid
from admin_user.dbts_instance where prod_db_group in (
'CASHPROD', 'STARRCVR', 'CATSPROD', 'CAPPROD', 'CPNRPROD', 'SOLARCH', 'CPNPROD', 'EQPPROD', 'SLSPROD', 'GFO9PRD',
'EWHPROD', 'LABPROD', 'EPUBPRD', 'GFOPRD', 'BVEWHPRD', 'ATMGPRD', 'BVESOPD')
)
/

