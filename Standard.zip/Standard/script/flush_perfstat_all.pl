#!/oracle/product/perl
##!/usr/local/bin/perl
# Name: flush_perfstat_all.pl
# History:
#	swei  01-APR-2004 created flush perfstat data per oratab
#		
#  01/08/07 raraveet            Std compliance phase-2
#
require "stat.pl";
require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


use DBI;
use Getopt::Std;
use Time::Local;

#Perfstat password is set here
$perfstat_pwd="pfst15sjc";
$parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
$exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";

##################  STD Compliance     ##########################
#  Pl add this piece of code in all Std Scripts at the beginning  
#  before staring any operations                                  
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!             
$thisScriptName="flush_perfstat_all.pl";  # << Change this to standard script name
#
$stddate=`date -u +%Y%m%d%H%M`; chomp($stddate);
$stdlogfile="${thisScriptName}_${stddate}";
$stdlibpath="/usr/tools/oracle/Standard/lib";
$stdpidval="$$";
$actscriptname="$0";
$stdjobseq="${stddate}-${stdpidval}";
$stdcksum=`/oracle/product/perl $stdlibpath/StdCompProc.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname`;
if ( $stdcksum =~ "FAILED" ) {
        print "This script $actscriptname is not same as standard script $thisScriptName\nExiting..\n";
       exit 1;
} elsif ( $stdcksum =~ "SUCCESS" ) {
        print "This script is $actscriptname matching checksum with standard script $thisScriptName..Continuing..\n";
} elsif ( $stdcksum =~ "NOT_FOR_LINUX" ) {
        print "This script is $actscriptname and it is valid NOT for Linux server..\nExiting..\n";
       exit 1;
} else {
        print "This script is $actscriptname error getting checksum with standard script $thisScriptName\nExiting..\n";
       exit 1;
}
###################################################################


#............................................................................
#		Main
#............................................................................
    chomp($host = `/bin/uname -n`);
    #&get_pageexe();

    open (ALLTAB,"/var/opt/oracle/oratab")  || &show_error("Can't Open oratab", "$!");
    while (<ALLTAB>)
    {
    next if (/^#/ || /^\s/);
    ($sid, $ora_home, $db_flag) = split(/:/);
    print "$sid $db_flag \n";
    next if ($db_flag =~ /^N/ || $db_flag =~ /^n/ );

    ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($sid);

##################  STD Compliance     ##########################
# If the script is used for all the database in this server
# like check_extend_all.pl, put this piece of code inside the loop
# for each databases using ORATAB.  Change the value for
# the variable "$mysid" to actual variable for each database
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
$stdsid="$sid";  # << Change "$sid" to actual variable
system("/oracle/product/perl $stdlibpath/StdCompProc.pl begin_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName");
###############################################################

    &ora_home($sid); 
    $tmpfile = "/tmp/flush_perfstat_$sid.log";
    print "$oracle_home \n";
    $cmd = "${oracle_home}/bin/sqlplus perfstat/$perfstat_pwd << !
set echo on
set termout on
-- alter session set current_schema=PERFSTAT;
@?/rdbms/admin/sptrunc

exit
!";
    
     open(CMD, "| $cmd > $tmpfile") || die "Cannot run $cmd. $!";
     close(CMD);

##################  STD Compliance     ##########################
# Place this piece of code at the end of LOOP job for each database.
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName");
###############################################################

    }
    close (ALLTAB);

##################  STD Compliance     ##########################
########  Pl add this piece of code in all Std Scripts ########
#     after completion of the script and before exit  #########
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_alljob $stdjobseq ALL $stdlogfile $thisScriptName");
###############################################################

    exit;

sub ora_home()
{
my $oracle_sid;

    $oracle_sid = $_[0];
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || &show_error("Can't Open /etc/oratab", "$!");
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_SID'}  = $oracle_sid;
            $ENV{'ORACLE_HOME'} = $oracle_home;
        }
    }
    close(ORATAB);
}

