#!/oracle/product/perl
##!/usr/local/bin/perl
# History Modified:
#  swei  Mar-19-2004 Add Which_Lib and msgfmt/mailit function
#  swei  Mar-30-2004 Add rows parameter
# ........................................................................
#use DBI;
use POSIX;
use Getopt::Std;

getopt('dsmpu');
if ($opt_u )
{ &usage(); }

chomp($hostname = `uname -n`);
$hostname =~ tr /a-z/A-Z/;
$MAX_PROCS = $opt_p ? $opt_p : 3;
$sids = $opt_s ? $opt_s : &usage();
#$mailto = $opt_m ? $opt_m : "jselvara";
$mailto = $opt_m if defined($opt_m);
$exp_all = ($sids eq "exptab") ? "Y" : "N";
$direct = $opt_d if defined($opt_d);
$status = "ERROR" ;

undef @sids;
undef @sidarr;
require "/usr/tools/oracle/Standard/script/perllib.pl";
$count=0;
sub Which_Lib {
$val = $ENV{'ORACLE_HOME'};
if (-f "$val/bin/svrmgrl") {
                 $one = clnt8;
        }
        elsif (-d "$val/lib32") {
                 $one = clnt964;
        }
        else {
                 $one = clnt9;
        }
if (-d "/oracle/product/perlmods/$one/lib") {
        use lib "/oracle/product/perlmods/$one/lib";
        use DBI;
        }
else    {
        use DBI;
        }
}

open(EXPORT, "/usr/tools/oracle/exptab") || 
    &show_error("Can not open /usr/tools/oracle/exptab. ", "$!");
while (<EXPORT>)
{
    next if (/^#/);
    ($sid, $yn, $direct_export, $exp_dir, $dba_mail, $rows) = split(/:/);
    next if ($yn =~ /^N/);
    chomp($rows);
    $dba_mail = $mailto if defined($mailto);
    $direct_export = $direct if defined($direct);
    $direct_export = ($direct_export eq "Y") ? "Y" : "N";
    #print "$sid $yn $exp_dir $dba_mail $exp_flag\n";
    @{$sidarr[$count]} = ($exp_dir, $dba_mail, $exp_all, $direct_export);
    $exp_hash{$sid} = \@{$sidarr[$count]};
    $count++;
}
close(EXPORT);
if ($sids ne "exptab")
{
    @sids = split(',', $sids);
    foreach $sid (@sids)
    {
        if (exists($exp_hash{$sid}))
        {
            $aref = $exp_hash{$sid};
            ${$aref}[2] = "Y";
        } 
        else
        {
            $dba_mail = $mailto ? $mailto : "mis-dba\@cisco.com";
            @{$sidarr[$count]} = ("/ora_exp", $dba_mail, "Y", "N");
            $exp_hash{$sid} = \@{$sidarr[$count]};
            $count++;
        }
    }
}
foreach $sid (sort keys %exp_hash)
{
    $aref = $exp_hash{$sid};
    @data = @{$aref};
    $exp_dir = $data[0];
    $mailto2 = $data[1];
    $exp_yn = $data[2];
    $direct_export = $data[3];
    next if ($exp_yn =~ /^N/);
    print "Data <$sid> <$exp_dir> <$mailto2> <$exp_yn>\n";
}

#exit(0);
foreach $sid (keys %exp_hash)
{
    $aref = $exp_hash{$sid};
    @data = @{$aref};
    $exp_dir = $data[0];
    $mailto2 = $data[1];
    $exp_yn = $data[2];
    $direct_export = $data[3];
    next if ($exp_yn =~ /^N/);
    if ($pid = fork)
    {                                  # PARENT  
        system(date);
        print "Exporting $sid\n";
        push @pids_running, $pid;
        while ($#pids_running >= $MAX_PROCS - 1)
        {
            foreach $pid (@pids_running)
            {
                if (($return = POSIX::waitpid( $pid, &POSIX::WNOHANG )) > 0)
                {
                    @pids_running = grep !/^${pid}$/, @pids_running;
                }
            }
            sleep 5;
        }
    }
    elsif (defined $pid)
    {                                  # CHILD   
        select(STDOUT);
        $| = 1;
        select(STDERR);
        $| = 1;
        select(STDOUT);
        &export_fn($sid, $exp_dir, $mailto2, $direct_export);
        exit 0;
    }
    else
    {
        die("Can't Fork: $!\n");
    }
}

while ($#pids_running >= 0)
{
    foreach $pid (@pids_running)
    {
        if (($return = POSIX::waitpid( $pid, &POSIX::WNOHANG )) > 0)
        {
            @pids_running = grep !/^${pid}$/, @pids_running;
        }
    }
    sleep 5;
}

sub export_fn()
{
my ($sid, $exp_dir, $mailto1, $direct_export);

    $start_date = `date`;
    ($sid, $exp_dir, $mailto1, $direct_export)  = @_;
    &ora_home($sid);    
    &check_ops_login($sid);
    $mknod_file = "/tmp/$$.pipe";
    $output_dir = "$exp_dir/${sid}_exp";
    $output_file = "$exp_dir/${sid}_exp/${sid}_full.dmp";
    $log_file = "$exp_dir/${sid}_exp/${sid}_full.log";
    (mkdir($output_dir, 0755) || &show_error("mkdir $output_dir failed.", "$!")) unless -d $output_dir;
    $ENV{'ORA_NLS33'} = "";
    `/etc/mknod $mknod_file p`; 
    system("/usr/local/bin/gzip < $mknod_file > ${output_file}.gz &");
    open(EXP, "$ENV{'ORACLE_HOME'}/bin/exp userid=/ consistent=y buffer=8000000 file=$mknod_file rows=$rows full=y compress=n log=$log_file direct=$direct_export 2>&1 |");

    undef(@errorlog);
    while (<EXP>)
    {
        print;
        if (/^EXP-/ || /^ORA-/)
        {
            $error = 1;
            push(@errorlog, $_);
        }
    }
    close(EXP);
    unlink($mknod_file) || &show_error("$mknod_file unlink error. ", "$!");
    $end_date = `date`;

    $message = "Start Date: $start_date\nEnd Date:  $end_date\n" .
             join("", @errorlog) .
             "\nPlease check $log_file for more details.\n";
    $status = "Successful" unless $error;
    $status = "ERROR" if $error;
    $mailto = $mailto1;

    if ( "$status" eq "ERROR" )
    {
    $errmsg = &msgfmt("w","`uname -n`","$sid","Export Completed With $status Status");
    }
    else
    {
    $errmsg = &msgfmt("i","`uname -n`","$sid","Export Completed With $status Status");
    }

    &mailit("$errmsg",$log_file);

#    `mailx -s "$sid Export Completed With $status Status" $mailto <<EOF\n$message\nEOF\n`;
}

sub ora_home()
{
my $oracle_sid;

    $oracle_sid = $_[0];
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || &show_error("Can't Open /etc/oratab", "$!");
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_SID'}  = $oracle_sid;
            $ENV{'ORACLE_HOME'} = $oracle_home;
            $ENV{'PATH'} = "${oracle_home}/bin:".$ENV{'PATH'};
            $ENV{'LD_LIBRARY_PATH'} = "${oracle_home}/lib";
        $ENV{'SHLIB_PATH'} = "$ora_home/lib";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        print "Sid $oracle_sid home $ora_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &Which_Lib();

            print "$ENV{'PATH'}\n";
        }
    }
    close(ORATAB);
}

sub check_ops_login()
{
my $oracle_sid;

    $oracle_sid = $_[0];
    undef $dbh;
    if (!($dbh = DBI->connect("dbi:Oracle:", "", "")))
    {
        print "Creating ops\$oracle account.\n";
        $dbh = DBI->connect("dbi:Oracle:", "internal", "") || &show_error("Can not connect to $oracle_sid.", "$DBI::errstr");
        $dbh->do("create user ops\$oracle identified externally") || &show_error("Create user failed.", "SID - $oracle_sid, $DBI::errstr");
        $dbh->do("grant connect, resource, dba to ops\$oracle") || &show_error("Grant failed.", "SID - $oracle_sid, $DBI::errstr");
    }
    $sth = $dbh->prepare("select value\$ from sys.props\$ \
        where name = 'NLS_CHARACTERSET'")  
        || &show_error("SID - $oracle_sid Prepare failed.", "$DBI::errstr");
    $rc = $sth->execute() 
        || &show_error("SID - $oracle_sid Excute failed.", "$DBI::errstr");
    ($charset, @dummy) = $sth->fetchrow_array();
    $sth->finish();
    $dbh->disconnect();
    print "Database $oracle_sid    Charset - $charset\n";
    $ENV{NLS_LANG} = "American_America.$charset";
}


sub usage()
{
    print "\n";
    print "Usage:\n\nexport_oracle.pl -s SID1[,SID2,...] -p MAX_PROCESS\n";
    print "\n";
    print "To export all databases in /usr/tools/oracle/exptab,\n";
    print "run export_oracle.pl -s exptab -p 5\n\n";
    exit (1);
}

sub show_error()
{
my $subject;
my $mesg_body;

   
    ($subject, @mesg_body) = @_;
    #$mesg_body = "\nError - $_[0].$message\n";
    ##$mesg_body = "Host  - $hostname Error - $message";
    #print "mailto is <$mailto2>";
    #print "subject is <$subject>";
    #print "body is <$mesg_body>";
    $errmsg = &msgfmt("w","`uname -n`","$sid","Export Completed With Error Status");
    &mailit("$errmsg",$log_file);
#   `mailx -s "$subject" $mailto2 <<EOF\n@mesg_body\nEOF\n`;
    exit(0);
}
