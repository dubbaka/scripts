#!/oracle/product/perl
##!/usr/local/bin/perl
# ....................................................................
# program:  /usr/tools/oracle/Standard/script/agefile.pl
# par file: /usr/tools/oracle/Standard/script/agefile.par
#
# Description:
#   script to remove age files.
#
# scope:
#   rm sqlnet.log in /oracle
#   mv listener*.log listener*.log.date in /oracle/product/*/network/admin/
#      if size of listener.log is > 5M
#   rm files older than -d days in /ora_dump if -d defined
#   rm files older than 30 days in /ora_dump by default if not -d defined
#   rm files older than 10 days in /ora_dump whenever file_system > 60% full
#   rm files older than  5 days in /ora_dump whenever file_system > 80% full
# 
# History
#       Ruby    24-oct-2003  created as a standard
#  swei  Mar-19-2004 Add msgfmt/mailit function
#  plaporte 	     Use standard DB Package
# ....................................................................

require "ctime.pl";
require "stat.pl";
require "getopts.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";

use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;

use Getopt::Std;
use POSIX  ":sys_wait_h";
use Time::Local;

select(STDERR); $| = 1;
select(STDOUT); $| = 1;

if ( !getopts('hm:p:s:') || defined($opt_h)) 
{ &usage(); }

$date     = `/usr/bin/date`;
$curr     = time();
chomp($hostname = `uname -n`);
$mail_default  = "mis-dba";
$mail_list  = $opt_m ? $opt_m : $mail_default;

$days_default = 30;
$days_60_full = 10;
$days_80_full = 5;
$days_old  = $opt_d ? $opt_d : $days_default;

$listener_size_default = 5000000;
$listener_size = $opt_s ? $opt_s : $listener_size_default;
$date = (localtime)[3];
$year = (localtime)[5] + 1900;
$month = (localtime)[4]+1;
$min = (localtime)[1];
$hour = (localtime)[2];
$day = (localtime)[6];

$Standard = "/usr/tools/oracle/Standard/script";
$logfile  = "$Standard/agefile.removed";
$file_sys = "/ora_dump";
$par_default = "$Standard/agefile.par";
$file_dir = $opt_p ? $opt_p : $par_default; 

# ................................................................
#       main
# ................................................................

open(LOGFILE, ">${logfile}") || die "Can not open logfile. $!\n";
print LOGFILE "Start time ", &ctime(time), "\n";

print LOGFILE "listener_size = $listener_size \n\n";
&rm_sqlnet_log();
&new_listener_log();

&loop_dir_rm_files($file_dir,$days_old);

if ($pct_used > 60) 
{
&loop_dir_rm_files($file_dir,$days_60_full);
$pct_used = &check_file_system_size($file_sys);
}

if ($pct_used > 80) 
{
&loop_dir_rm_files($file_dir,$days_80_full);
$pct_used = &check_file_system_size($file_sys);
    $mailto=$mail_list;
    $errmsg = &msgfmt("w","`uname -n`","","$file_sys is $pct_used full after agefile.pl cleanup");
    &mailit("$errmsg",$file_dir);

#`cat $file_dir|/usr/bin/mailx -s "Warning: $hostname:$file_sys is $pct_used full after agefile.pl cleanup" $mail_list`;
}

$pct_used = &check_file_system_size($file_sys);
print LOGFILE "\n$file_sys is $pct_used used after clean up. \n";

rm_empty_dir();

print LOGFILE "\nFinish time ", &ctime(time), "\n";

# ................................................................
#   usage()
# ................................................................
sub usage()
{
    print "\n";
    print "Usage:\n\nagefile.pl -h y[Y,null] -m who1[,who2,...] -p parfile -s size\n";
    print "\n";
    print "\t-h print this usage text. \n";
    print "\t-m default mail is to mis-dba, \n";
    print "\t-p default parfile is /usr/tools/oracle/Standard/script/agefile.par. \n";
    print "\t-s default listener log archive size is 5000000 (5M). \n";
    exit (0);
}

# ................................................................
#   rm_sqlnet_log()
# ................................................................
sub rm_sqlnet_log()
{
`cd /oracle; find . -name sqlnet.log -print | awk '{print "rm "\$1}'> /tmp/rm_sqlnet_log`;
`chmod +x /tmp/rm_sqlnet_log`;
`cd /oracle; /tmp/rm_sqlnet_log`;
}
# ................................................................
#   new_listener_log()
# ................................................................
sub new_listener_log()
{
  open(LISTEN_FILE, "ls -1 /oracle/product/*/network/log/listener*.log|");
  while(<LISTEN_FILE>)
  {
     chomp;
     $file_name = $_;
     @aref = stat("$file_name");
     $size = @{aref[7]};
     print LOGFILE "file_name = $file_name file_size = $size\n";
     if ($size > $listener_size ) {
        $new_file = sprintf("$file_name.%02d.%02d.%02d.%02d.%02d",
                            $year, $month, $date, $hour, $min);
        print LOGFILE "new_file = $new_file \n";
        `cp $file_name $new_file`;
        `gzip $new_file`;
        `cat /dev/null > $file_name`;
     }
  }
}

# ................................................................
#   loop_dir_rm_files($file_dir, $days)
# ................................................................
sub loop_dir_rm_files()
{
my ($file_dir, $days) = @_;

  open(INFILE, "$file_dir") || die "Cannot open file"; 
  while(<INFILE>)
  {
    next if (/^#/);
    chomp;
    $dir = $_;
    &rm_files($dir,$days);
  }
  close(INFILE);
}

# ................................................................
#   check_file_system_size($file_system)
# ................................................................
sub check_file_system_size()
{
my ($file_system) = @_;
my $pct_used;

  $first_line="Y";
  system("df -k $file_system > /tmp/check_file_sys.lis");
  open(FS,"/tmp/check_file_sys.lis"); 
  while (<FS>)
  {
    if ($first_line eq "Y")
    {
        $first_line="N";
    }
    else
    {
       $pct_used = (split /\s+/) [4];
    }
  }
  return($pct_used);
}

# ................................................................
#   rm_files($$dir, $days)
# ................................................................
sub rm_files()
{
my ($dir, $days) = @_;
my $secs = 60*60*24*$days;   

  @files  = `ls -lat $dir`;
  foreach $file (@files) {
     @tmp=split(/[ \t]+/, $file);
     $cnt = @tmp;
     $filename=@tmp[$cnt-1]; chop($filename);
     @info = stat($filename);
     $mod = $info[9];
     $diff = $curr - $mod;
     if ($diff > $secs) {
        system("/usr/bin/rm $filename");
     }
  }
}
# ................................................................
#   rm_empty_dir()
# ................................................................
sub rm_empty_dir()
{
  system("/usr/bin/rmdir /oracle/admin/*/perf/[1-9]* > /tmp/agefile_rmdir.log");
  system("/usr/bin/rmdir /oracle/admin/*/perf/top*/[1-9]* >> /tmp/agefile_rmdir.log");
  system("/usr/bin/rmdir /oracle/admin/*/cdump/core* >> /tmp/agefile_rmdir.log");
}
