#!/bin/sh
# ......................................................................
# History
#       swei    27-may-2004 Implement Hide executable
# ......................................................................
STDDIR=/usr/tools/oracle/Standard/script
OSNAME=`uname -s`
PATH=$PATH:/usr/bin/ls:/bin/ls
export PATH

case $OSNAME in
        HP-UX)	HIDE=hide.hp ;;
        SunOS)  HIDE=hide.sun ;;
        Linux)  HIDE=hide.linux ;;
esac

if [ ! -f $STDDIR/$HIDE ]
then	
    echo "---------------------------------------------------------------------"
    echo "Abort.... the $HIDE does not exist "
    echo "---------------------------------------------------------------------"
    exit
fi

for Dir in `ls -d $ORACLE_HOME $IAS_ORACLE_HOME $FND_TOP`
do
    cd $Dir/bin
    echo 
    echo "---------------------------------------------------------------------"
    echo "Implementing hide to the executables in $Dir/bin ...."
    echo "---------------------------------------------------------------------"
    echo

    
       echo "Copying the file $HIDE to $Dir/bin "
       cp $STDDIR/$HIDE $Dir/bin
       chmod 755 $HIDE

    for File in `ls sqlplus imp exp sqlldr sqlload tkprof CONCSUB `
    do
      if [ -r $File ]
      then
        if [ -h $File ]
        then
           echo "Skipping ..... $Dir/bin/$File is already a Link."
        else
           echo "Implementing hide for $Dir/bin/$File" 
           mv $File $File.hide
           ln -s $HIDE $File
           chmod 755 $File
        fi
      fi
    done
    echo 
done

echo
