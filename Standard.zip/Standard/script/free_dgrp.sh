#!/bin/ksh
#set -x
#############################################################################
# Name          : free_dgrp.sh                                              #
# Purpose       : To check and display ASM DiskGroup Details                #
#                                                                           #
# Parameters    : SID                                                       #
#                                                                           #
# Usage         : free_dgrp.sh -s SID                                       #
#                                                                           #
#                                                                           #
# Created By    :  Melvin Gerold (mgerold)                                  #
# Creation Date :  July 2011                                                #
#############################################################################


get_db_name()
{
export PATH=$PATH:/usr/local/bin
        export ORACLE_SID=$sid
        export ORAENV_ASK=NO
. /usr/local/bin/oraenv

DBNM=`sqlplus -s /nolog <<SQLCODE
      connect / as sysdba;
      set head on pagesize 0  verify off feedback off trimspool on time off timing off
      select upper(name) name from v\\$database;
SQLCODE`

}

check_asm_instance()
{

export PATH=$PATH:/usr/local/bin
        export ORACLE_SID=$asm_instance
        export ORAENV_ASK=NO
. /usr/local/bin/oraenv
OUTPUT=`sqlplus -s /nolog <<SQLCODE
      connect / as sysdba;
      set head off
      set feedback off
      select count(*) from v\\$asm_client where instance_name='$sid';
SQLCODE`

#If you are not using ASM why do I bother ....let me get out of here !!!! 

if [ $OUTPUT -le 0 ]; then
  echo "Instance not using ASM ......"
  exit;
fi

}

display_disk_group()
{
 export ORACLE_SID=$asm_instance
        export ORAENV_ASK=NO
. /usr/local/bin/oraenv 
unset ORA_TZFILE
echo "=========================================================="
echo "                      D I SK    G R O U P   I N F O       "
echo "Name                          Total (MB)   Free(MB)       "
echo "=========================================================="

$ORACLE_HOME/bin/sqlplus -s /nolog  <<SQLCODE
connect / as sysdba;
set head on pagesize 0  verify off feedback off trimspool on time off timing off
col name format a28
select name,round(TOTAL_MB) "Total (MB)",
round(FREE_MB) "Free (MB)"
from v\$asm_diskgroup
where name like '%$DBNM%' and name like '%DT%' order by 2 desc ;
SQLCODE

echo "--------------------------------------------------------------"
echo ""
echo ""
echo "================================================================================================"
echo "                      D I S K S      A V A I L A B L E    T O    A D D                          "
echo "  DISK                               Target Disk Group                             OS Size (MB) "     
echo "================================================================================================"

$ORACLE_HOME/bin/sqlplus -s /nolog  <<SQLCODE
connect / as sysdba;
set pagesize 0 echo off verify off feedback off trimspool on time off timing off
set line 100
column path form a40
column target form a40
select path ,
'DG_' || substr(path,instr(path,'$DBNM'),instr(path,'_',3) ) target,
round(os_mb) "OS Size"
from v\$asm_disk
where name is null and group_number=0  and path like '%$DBNM%'
and header_status in('CANDIDATE','PROVISIONED','FORMER') order by 3 desc; 
SQLCODE
echo ""
echo "------------------------------------------------------------------------------------------------"

}


######################################   M  A  I  N ################

while getopts s: OPTION
do
  case $OPTION in

        s)     sid=$OPTARG
                ;;
  esac

done
shift `expr $OPTIND - 1`

if [ -z "$sid" ]; then
 echo "Usage : ./free_dgrp.sh -s SID"
 exit
fi

AWK=/usr/local/bin/awk


#Hey Mr. ASM , are you there !!!!  

rc=0
rc=`ps -ef | grep pmon | grep +ASM | grep -v grep | wc -l `

if [ $rc -le 0 ]; then
    echo "ASM instance not running.....\n";
    exit 0;
fi

asm_instance=`ps -ef | grep pmon_+ASM | grep -v grep | awk '{print $NF }' | awk -F_ '{print $NF }'` 

# Hello Mr, Instance, are you using ASM !!!, let me find out 

 check_asm_instance

 get_db_name

 
# All good sir,  let me get more details on disk group and disks.... 
 
 display_disk_group
