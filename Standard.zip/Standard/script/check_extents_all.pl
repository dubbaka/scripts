#!/oracle/product/perl
##!/usr/local/bin/perl
#
# Name    : check_extents_all.pl
# Version : 1.0
# Date    : 31-MAR-2004
#
# Modification History:
#    	    swei        read ORATAB to check all databases
#			if oracleDB.par exists, will get mailto/pageto
#			otherwise, default to mis-dba, dba-duty
#			if exception.par has EXTENTS, take the values
#  01/03/06 raraveet    fixed env setup issue in ora_home, 
#  01/08/07 raraveet            Std compliance phase-2
#  09/28/08 rarumuga    Added features for OMF and works for Linux also
#  11/13/08 rarumuga    It will check entries in oratab for flag Y       
# ........................................................................

require "ctime.pl";
use Getopt::Std;
use Time::Local;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


$parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
$exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";
$OPCPATH     = "/opt/OV/bin/OpC";
$OPCMSG      = "$OPCPATH/opcmsg";
$SEVERITY    = "critical";
$METHOD      = "PAGE";
$out_subject = "Serious space problem on $sid";
$out_message = "Serious space problem on $sid";

##################  STD Compliance     ##########################
#  Pl add this piece of code in all Std Scripts at the beginning  
#  before staring any operations                                  
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!             
$thisScriptName="check_extents_all.pl";  # << Change this to standard script name
#
$stddate=`date -u +%Y%m%d%H%M`; chomp($stddate);
$stdlogfile="${thisScriptName}_${stddate}";
$stdlibpath="/usr/tools/oracle/Standard/lib";
$stdpidval="$$";
$actscriptname="$0";
$stdjobseq="${stddate}-${stdpidval}";
$stdcksum=`/oracle/product/perl $stdlibpath/StdCompProc.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname`;
$stdcksum = "SUCCESS" ;  # For testing only - Rama
if ( $stdcksum =~ "FAILED" ) {
        print "This script $actscriptname is not same as standard script $thisScriptName\nExiting..\n";
#       exit 1;
} elsif ( $stdcksum =~ "SUCCESS" ) {
        print "This script is $actscriptname matching checksum with standard script $thisScriptName..Continuing..\n";
#} elsif ( $stdcksum =~ "NOT_FOR_LINUX" ) {
#        print "This script is $actscriptname and it is NOT valid for Linux server..\nExiting..\n";
#       exit 1;
} else {
        print "This script is $actscriptname error getting checksum with standard script $thisScriptName\nExiting..\n";
#       exit 1;
}
###################################################################


chomp($host = `/bin/uname -n`);
&get_pageexe();
# ........................................................................
#               Main
# ........................................................................

   open (ALLTAB,"/var/opt/oracle/oratab") || &show_error("Can't Open oratab", "$!");
   while (<ALLTAB>)
   {
    next if (/^#/ || /^\s/ );
    ($sid, $ora_home, $db_flag) = split(/:/);
    	#print "$sid $db_flag \n";
	    #next if ($db_flag =~ /^N/ || $db_flag =~ /^n/ ); #to work for all DBs
             next if ($sid =~ /^\+ASM/ || $sid =~ /^GRID/ ); #to exclude ASM and GRID

	$sid_running = `ps -ef | grep -v grep | grep ora_pmon_${sid} | wc -l `;
	print "Checking $sid\n";
	if ( $sid_running < 1 ) 
	{ 	print "$sid is not running or invalid instance\n";
		next;
	}
    ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($sid);

    #&get_default_value();
    &get_exception_value();
    print "$sid $mailto $pageto $warn $alert \n";
    $logfile     = "/tmp/check_extents_$sid.log";
    $errorfile   = "/tmp/check_extents_$sid.err";
    open(LOGFILE, "> $logfile") || die "Cannot open logfile. $!\n";
    print "Start time ", &ctime(time), "\n";
    $oracle_sid = $sid;
    &ora_home($oracle_sid);

#$runVolumeAutoAdd=`/usr/tools/oracle/Standard/script/volumeAutoAdd.sh $oracle_sid`;
##################  STD Compliance     ##########################
# If the script is used for all the database in this server
# like check_extend_all.pl, put this piece of code inside the loop
# for each databases using ORATAB.  Change the value for
# the variable "$mysid" to actual variable for each database
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
$stdsid="$oracle_sid";  # << Change "$sid" to actual variable
system("/oracle/product/perl $stdlibpath/StdCompProc.pl begin_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName");
###############################################################
    
    #$dbh = DBI->connect("dbi:Oracle:", "", "") || die $DBI::errstr;
    $dbh = DBI->connect("dbi:Oracle:", "", "") || next;
    &get_block_size();
    &get_db_version();
    &get_free_space();
    &get_total_space();
    #&get_user_name();
#    ($dummy, $mailto2, $esc_time, $pageto2)  = &get_esc_ids($oracle_sid);
    $esc_time *= 60;
    $pageto = $pageto ? $pageto : ($pageto2 ? $pageto2 : $pagelist);
    $mailto = $mailto ? $mailto : ($mailto2 ? $mailto2 : $maillist);
    @esc_ids = split(',', $pageto);
 
    $ec1 = 0;
    $wc1 = 0;
    undef(@pagemsg1);
    &check_free_space();
    $dbh->disconnect;
    if ($ec1)
    {
        print "\nERROR: Maximum Free Space <= 200M and Pct Free <= $alert%\n";
        print LOGFILE "\nERROR: Maximum Free Space <= 200M and Pct Free <= $alert%\n";
        &print_hdr1();
        $i = 0;
        for $i (0..($ec1 - 1))
        {
            @data = @{$errorarr1[$i]};
            printf "%-19s %8d          %8d        %8d  %6.2f\n", 
                $data[0], $data[1], $data[2], $data[3], $data[4];
            printf LOGFILE "%-19s %8d          %8d        %8d  %6.2f\n", 
                $data[0], $data[1], $data[2], $data[3], $data[4];
            $msg = sprintf  "%s check_extents_all.pl on %s: %s Tablespace is running out of space. Size - %dM, Free - %dM, Max free - %dM, Pct Free - %6.2f", 
           $host,$oracle_sid, $data[0], $data[1], $data[2], $data[3], $data[4];
            push(@pagemsg1, $msg);
        }
        print "\n";
        print LOGFILE "\n";
    }
    if ($wc1)
    {
        print "\nWARNING: Total Free <= 700M Max Free <= 250M and Pct Free <= $warn%\n";
        print LOGFILE "\nWARNING: Total Free <= 700M Max Free <= 250M and Pct Free <= $warn%\n";
        &print_hdr1();
        $i = 0;
        for $i (0..($wc1 - 1))
        {
            @data = @{$warnarr1[$i]};
            printf "%-19s %8d          %8d        %8d  %6.2f\n", 
                $data[0], $data[1], $data[2], $data[3], $data[4];
            printf LOGFILE "%-19s %8d          %8d        %8d  %6.2f\n", 
                $data[0], $data[1], $data[2], $data[3], $data[4];
        }
        print "\n";
        print LOGFILE "\n";
    }
    close(LOGFILE);
    print "\nEnd time ", &ctime(time), "\n";

    if ($wc1 || $ec1)
    {
        $errmsg = &msgfmt("w","$host","$oracle_sid","Database Space Alert");
        &mailit("$errmsg",$logfile);
        #&mailit("SPACE ALERT: Database $oracle_sid on $host", $logfile);
    }
    if ($ec1 > 4)
    {
        $errmsg = &msgfmt("a","$host","$oracle_sid","Database Space Alert");
        &mailit("$errmsg",$logfile);
        @pagemsg1 = ("$host check_extents_all.pl on $oracle_sid: Serious space problem on $sid. PLEASE CHECK.");
    }
    if ($ec1 > 0)
    {
        $errortime = &get_error_time($oracle_sid, $errorfile);
        {
            use integer;
            if ($esc_time > 0)
            {
                $e2 = $errortime/$esc_time;
                $pageaddr = $esc_ids[$e2] ? $esc_ids[$e2] : $esc_ids[$#esc_ids];
                $pageto = $pageaddr;
            }
        }
    }
    if ($ec1 == 0)
    {
        unlink($errorfile) if (-f $errorfile);
    }
    if ( $pageto eq "null" )
    {
	print "here \n";
    }
    else
    {
    &pageit(@pagemsg1);
    #&pageit(@pagemsg2);
    }

##################  STD Compliance     ##########################
# Place this piece of code at the end of LOOP job for each database.
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName");
###############################################################

    }
    close(ALLTAB);

##################  STD Compliance     ##########################
########  Pl add this piece of code in all Std Scripts ########
#     after completion of the script and before exit  #########
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_alljob $stdjobseq ALL $stdlogfile $thisScriptName");
###############################################################

    exit(0);

# ........................................................................
#               End of Main
# ........................................................................



sub get_exception_value
{

    if (-r $exceptfile)
    {

    open(EXCEPTFILE, $exceptfile) || die "Can't Open $exceptfile. $!";
    while (<EXCEPTFILE>)
    {

       next unless (/^EXTENTS:/ && /$sid:/ );
       {
          ($extents, $sid, $mailto, $pageto, $warn, $alert) = split(/:/);
          chomp($alert);
          #print "$sid $mailto $pageto $warn $alert \n";
       }
    } 
    close(EXCEPTFILE);
    }
}

sub ora_home
{
my $oracle_sid;

    $oracle_sid = $_[0];

    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home            = (split(':'))[1];
            $ENV{'ORACLE_HOME'}     = $oracle_home;
            $ENV{'ORACLE_SID'}      = $oracle_sid;
            $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
            $ENV{'SHLIB_PATH'}      = "$oracle_home/lib";
            $ENV{'TNS_ADMIN'}       = "$oracle_home/network/admin";
	    ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
            ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }

        print "Sid $oracle_sid home $oracle_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();
        }
    }
    close(ORATAB);
}


sub usage 
{
    print "$_[0]";
    print "Usage:\ncheck_extents_all.pl\n";
    exit (1);
}

sub get_pageexe
{
    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");
    $pageexe = "/usr/tools/oracle/itopage.pl" if (-f "/usr/tools/oracle/itopage.pl");

    if (!defined($pageexe))
    {
        print("check_extents.pl on $host: epage/pageme executable not found. Aborting...");
        exit (1);
    }
}
sub print_hdr1
{
    print "\nTablespace          Size(Mb)    Total Free(Mb)    Max Free(Mb)  Pct Free\n";
    print LOGFILE "\nTablespace          Size(Mb)    Total Free(Mb)    Max Free(Mb)  Pct Free\n";
    &print_dash(STDOUT);
    &print_dash(LOGFILE);
}

sub print_hdr2
{
    print "\nTablespace          Size(Mb)    Total Free(Mb)    Max Free(Mb) Pct. Free\n";
    print LOGFILE "\nTablespace          Size(Mb)    Total Free(Mb)    Max Free(Mb) Pct. Free\n";
    &print_dash(STDOUT);
    &print_dash(LOGFILE);
}

sub print_dash
{
    $FH = @_[0];

    print $FH "-"x79;
    print $FH "\n";
}

sub show_error()
{

    print "$_[0]. $DBI::errstr\n";
    exit (1);
}

sub get_block_size()
{
    $stmt = "select value  from v\$parameter where name = 'db_block_size'";
    $sth = $dbh->prepare($stmt) || 
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || 
        &show_error("Error while executing $stmt");
    ($blocksize) = $sth->fetchrow_array();
    $sth->finish();
}

sub get_db_version()
{
    $stmt = "select banner  from v\$version where rownum < 2";
    $sth = $dbh->prepare($stmt) || 
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || 
        &show_error("Error while executing $stmt");
    ($typeval) = $sth->fetchrow_array();
    $sth->finish();
    
    if ($typeval =~ /Oracle7/)
    {
        $typecol = "type";
    }
    else
    {
        $typecol = "type#";
    }
}


sub check_next_extent()
{
    $stmt2 = "select o.obj#, o.owner#, o.name
        from sys.tab\$ t, sys.obj\$ o
        where t.obj# = o.obj# 
        and t.ts# = $tsnum and t.file# = $filenum and t.block# = $blocknum";
    $sth2 = $dbh->prepare($stmt2) || &show_error("Error while preparing $stmt2");
    $stmt3 = "select o.obj#, o.owner#, o.name
        from sys.ind\$ t, sys.obj\$ o
        where t.obj# = o.obj# 
        and t.ts# = $tsnum and t.file# = $filenum and t.block# = $blocknum";
    $sth3 = $dbh->prepare($stmt3) || &show_error("Error while preparing $stmt3");
    if ($type == 5)        #   table
    {
        $sth2->execute() ||
            &show_error("Error while executing $stmt2");
        ($objnum, $ownernum, $objname) = $sth2->fetchrow_array();
    }
    if ($type == 6)        #   index
    {
        $sth3->execute() ||
            &show_error("Error while executing $stmt3");
        ($objnum, $ownernum, $objname) = $sth3->fetchrow_array();
    }
    if ($next > $maxfreearr{$tsnum})
    {
        @{$errorarr1[$ec1++]} = ($ownernum, $objname, $type, $tsnum, $size, $extents, $next);
    }
    else 
    {
        @{$warnarr1[$wc1++]} = ($ownernum, $objname, $type, $tsnum, $size, $extents, $next);
    }
    $sth2->finish;
    $sth3->finish;
}

sub get_free_space()
{
    $stmt = "select tablespace_name, 
            round(sum(bytes)/1024/1024),
            round(max(bytes)/1024/1024)
        from dba_free_space
        where tablespace_name not in
          (select tablespace_name from dba_rollback_segs
		where tablespace_name != 'SYSTEM')
	and tablespace_name not in
	( select distinct tablespace_name from dba_data_files
	        where autoextensible = 'YES' )
        group by tablespace_name";
    $sth = $dbh->prepare($stmt) || &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || &show_error("Error while executing $stmt");
    $aref = $sth->fetchall_arrayref;
    $sth->finish();
    undef ($totfreearr);
    undef ($maxfreearr);
    foreach(@$aref)
    {
        ($tsname, $totfree, $maxfree)  = (@$_);
        $totfreearr{$tsname} = $totfree;
        $maxfreearr{$tsname} = $maxfree;
    }
}

sub get_total_space()
{

    $stmt = "select tablespace_name, 
            round(sum(bytes)/1024/1024)
        from dba_data_files
        where tablespace_name not in
          (select tablespace_name from dba_rollback_segs
		where tablespace_name != 'SYSTEM')
	and tablespace_name not in
	( select distinct tablespace_name from dba_data_files
	        where autoextensible = 'YES' )
        group by tablespace_name";
    $sth = $dbh->prepare($stmt) || &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || &show_error("Error while executing $stmt");
    $aref = $sth->fetchall_arrayref;
    $sth->finish();
    undef (%totarr);
    foreach(@$aref)
    {
        ($tsname, $tot)  = (@$_);
        $totarr{$tsname} = $tot;
    }
}

sub get_user_name()
{
    $stmt = "select user#, name from sys.user\$";
    $sth = $dbh->prepare($stmt) || &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || &show_error("Error while executing $stmt");
    $aref = $sth->fetchall_arrayref;
    $sth->finish();
    foreach(@$aref)
    {
        ($usernum, $username) = (@$_);
        $usernamearr{$usernum} = $username;
    }
}



sub get_error_time()
{
my ($sid, $errorfile, $mtime, $time, $tdiff);

    ($sid, $errorfile)  = @_;
    if (! -f $errorfile) 
    {
        system("touch $errorfile");
    }
    $mtime = (stat($errorfile))[9];
    $time = timelocal(localtime);
    $tdiff = $time - $mtime;
    return($tdiff);
}

sub check_free_space()
{
    
    $ec1 = 0;
    $wc1 = 0;
    undef(@errorarr1);
    undef(@warnarr1);
    foreach $tsname (sort keys %totarr)
    {
        $tot = $totarr{$tsname};
        $tot = 1 if (!defined($tot) || $tot == 0);

        $totfree = $totfreearr{$tsname};
        $totfree = 0 if (!defined($totfreearr{$tsname})) ;
        $maxfree = $maxfreearr{$tsname};
        $maxfree = 0 if (!defined($maxfreearr{$tsname})) ;
        $pctfree = $totfree * 100 / $tot;
        #
        # If Maxfree < 200M and Pctfree <= 5%, push to errorarr
        #
        if (($maxfree <= 200) && ($pctfree <= $alert))      
        {
          if ( $tsname eq "TEMP" )
          {
               &check_temp_space();
               if ($tempuser != 0 )
               {
               @{$errorarr1[$ec1++]} = ($tsname, $tot, $totfree, $maxfree, $pctfree);
               } 
          }
          else
          { 
           @{$errorarr1[$ec1++]} = ($tsname, $tot, $totfree, $maxfree, $pctfree);
          }
        }
        elsif (($maxfree <= 250) && ($pctfree <= $warn) && ($totfree <= 700))
        {
          if ( $tsname eq "TEMP" )
          {
               &check_temp_space();
               if ($tempuser != 0 )
               {
                @{$warnarr1[$wc1++]} = ($tsname, $tot, $totfree, $maxfree, $pctfree);
               }
           }
           else
           {
            @{$warnarr1[$wc1++]} = ($tsname, $tot, $totfree, $maxfree, $pctfree);
           }
        }
    }
}

sub check_temp_space()
{
    $stmt = "select count(*) from v\$sort_segment where current_users > 0";
    $sth = $dbh->prepare($stmt) || &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || &show_error("Error while executing $stmt");
    ($tempuser) = $sth->fetchrow_array();
    $sth->finish();
}
