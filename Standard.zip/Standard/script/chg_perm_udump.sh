#!/bin/ksh 
# 
# This script will change permissions on udump directories for all SIDs
# 
# Modification history: 
# 01/03/2007 raraveet   Modified to suppress warning if no file exists.
# 
#  01/08/07 raraveet            Std compliance phase-2

sid=$1

if [ $# -lt 1 ] 
then 
   echo
   echo Usage: $0 SID/ALL
   echo 
   echo 
exit 0
fi

if [ "$sid" = "ALL" ]
then
  sid='*'
fi

echo
echo  "chg_perm_dump.sh Start ... `date`";

##################  STD Compliance     ##########################
#  Pl add this piece of code in all Std Scripts at the beginning  
#  before staring any operations                                  
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!             
thisScriptName="chg_perm_udump.sh"  # << Change this to standard script name
#
stddate=`date -u +%Y%m%d%H%M`
stdlogfile="${thisScriptName}_${stddate}"
stdlibpath="/usr/tools/oracle/Standard/lib"
stdpidval=$$
actscriptname=$0
stdjobseq="${stddate}-${stdpidval}"
stdcksum=`/oracle/product/perl $stdlibpath/StdCompProc.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname`
if [ "$stdcksum" = "FAILED" ]
then
	echo
	echo "This script $actscriptname is not same as standard script $thisScriptName"
	echo "Exiting.."
	exit 1
fi

if [ "$stdcksum" = "SUCCESS" ]
then
	echo 
	echo "This script is $actscriptname matching checksum with standard script $thisScriptName..Continuing.."
fi

echo
###################################################################

for dir in `ls -Ld /oracle/admin/$sid/udump` 
do
	echo Changing the permission of $dir/\*.trc to read-all
	find  $dir -name "*.trc" -follow  -exec chmod  644 {} \;
done

##################  STD Compliance     ##########################
########  Pl add this piece of code in all Std Scripts ########
#     after completion of the script and before exit  #########
/oracle/product/perl $stdlibpath/StdCompProc.pl end_alljob $stdjobseq ALL $stdlogfile $thisScriptName
###############################################################


echo
echo  "chg_perm_dump.sh End  `date`";
echo
