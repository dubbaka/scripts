#!/oracle/product/perl

#######################################################################################
#
# Filename: analyze_database.pl
#
# Purpose: To analyze all objects in relavent schemas in the database,
#          to be called regularly from cron to keep statistics up to date.
#  		The algorith/theory behind this program is that analyze done on
#		a table only needs to be grossly estimated , but analyze on
#		an index needs a complete 'compute' analysis.
#		Therefore, a quick analyze table is done for everything, and
#		then a complete analysis for each index is done next.
#
#Enhancement: Kiran Hegde
#

#Following modification added by kihegde

#1)Exception list to exclude  some table from analyze
#2)Having an option of running analyze with DBMS_STAT or FND_STATS
#3)Running the analyze with user give order
#4)Having option to run in RAC,so that the speed will double. Or running a perticular schema analyze or single node.
#5)Skip option added not to analyze analyzed objects few hours back
#6)Multiple Os threads and database parallel options used to optimize the analyze
#7)Skipping tables introduced
#9)Different analyze percentage introduced

# Syntax: $0 [sid]
#
# Comments: This program should be run under the userid of someone with 
#           and OPS$ account as a DBA.
#
# Requirements: 
#     create table ops$oracle.analyze_todo_1 (db varchar2(9), tbl_owner varchar2(30), 
#						tbl_name varchar2(30), megs number,
#				 		ssize varchar2(5), degre number)
#     create table ops$oracle.EXCLUDE_TABLE_STATS(table_name varchar2(30));
#     create table ops$oracle.rac_schema_analyze (owner_name varchar2(30),node_no number);




#
# Parameter: All parameters but 3 are set using the par file. 
#            The 3 non-par parameters - LOGDIR, SKIP_HOURS, SCHEMA_FIRST - are here.
#
#######################################################################################
use Getopt::Std;
use POSIX;
require "ctime.pl";

require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;

#### PARAMETERS OUTSIDE OF PAR FILE  		#################################
##chomp($LOGDIR = `pwd`);
$SKIP_HOURS = 0;                             # Skip tables analyzed in the last 12 hours
#### END OF PARAMETERS OUTSIDE OF PAR FILE	#################################


select(STDERR); $| = 1;
select(STDOUT); $| = 1;

my $sleep_time = 20;	# Between checking if any thread has completed
%analyze_tbsize = (); %special_tables = ();
%max_dbms_threads = (); %max_dbms_threads_copy = (); 

@schema_order_by =();
@mschema_order_by =();


    &init_fn();
    $start_time=time;
    print "\nStart Date  ", &get_date("DD-MON-YYYY"), "   Time  ",
        &get_time("HH:MI:SS", $start_time), "\n";
    &log_message("\nStart Date  ", &get_date("DD-MON-YYYY"), "   Time  ",
        &get_time("HH:MI:SS", $start_time), "\n");
    &log_message("\n--------------------------------------------------------------------------------\n");
    sleep(1);

    &analyze_tables();

    foreach $mb ( sort numerically keys %max_dbms_threads) {
       foreach $thrds (@{$max_dbms_threads{$mb}})  {
        print " Thread $thrds, MB $mb \n";
          push(@{$max_dbms_threads_copy{$mb}}, $thrds);
       }
    }
    #print " Before analyze run \n";
    #exit(0);
    &analyze_run();
    #print " after analyze run \n";
    &analyze_iot();
# exit(0);
    $max_analyze_threads_for_final_run = 10;

    $rc = $dbh->disconnect;

    $PS_CMD="/bin/ps xaef | /bin/grep analyze";
#     if ($ana_type eq 'DBMS')  
         $running_cmd = "fnd_dbms_ana";
#       { $running_cmd = "analyze_dbms";}
#     else 
#	{ $running_cmd = "analyze_fnd";}
$imax=2;
 for ($i=1; $i<$imax; $i++)  {   # This is a forever loop
           # If total dbms_stats threads is less than maximum then out of this loop
            $count = 0;
           open(INPS,"$PS_CMD |") || die "Can not run $PS_CMD --   $!\n";
           while (<INPS>) {
              (/${running_cmd}/ && /${oracle_sid}/) or next;
#              /${running_cmd}/ or next;
              $count++;
           }
   
           close(INPS);
           $imax=$imax+1;
           if ($count < 1)  {
              last;
           }
          sleep 120;
                          } # End of forever loop

    $end_time=time;
    $time_taken = &print_time(time - $start_time);

    print "End Date  ", &get_date("DD-MON-YYYY"), "   Time  ",
        &get_time("HH:MI:SS", $start_time), "\n";
    &log_message("End Date  ", &get_date("DD-MON-YYYY"), "   Time  ",
        &get_time("HH:MI:SS", $start_time), "\n");

    print "\n--------------------------------------------------------------------------------\n";
    print "All analysis done.                                  Total Time Taken - $time_taken\n\n";
    &log_message("\n--------------------------------------------------------------------------------\n");
    &log_message("All analysis done.                                  Total Time Taken - $time_taken\n\n");

    &mailit("$oracle_sid Analyze Report.", $logfile);
    chomp($SrchCnt = `grep \"ORA-\" $log_file |wc -l`);
    if($SrchCnt)
      {
	&mailit("$oracle_sid Analyze report has some errors please check Error and Log file.",$log_file);
      }
    exit(0);


#############################################################
# SUBROUTINES
#############################################################

sub init_fn
{

    $usage = <<EOFEOF;

Usage:  
    $0 [-help] -s sid -e analyze_percent -u username[,username...] -m ch-p1db-monitor -p dba-duty


    -e analyze_percent     : Estimate analyze_percent of table data.
                             Default is 1.
    -h help                : Print this help.
    -m mailto              : Mail list. 
                             Default is imee-p1db-monitor.
    -p pageto              : Page list. 
                             Default is dba-duty.
    -s sid                 : Oracle SID. 
                             Default is SITRN.
    -u username            : Analyze objects owned by this user.
                             If not specified, analyzes all objects owned
                             by all users except SYS and SYSTEM users.
    -t analyze_type        : We can use either DBMS (for DBMS_STATS) or FND(for FND_STATS)
			     DBMS is default
    -o order_schema	   : Analyze order by schema vice,each schema comma
			     seperated and first schema analyzed first.
    -n node_number         : Node number, if it is 1 then all the schemas in
			     rac_schem_analyze table analyzed in node1 and rest
			     of the schemas in node2
Description:

    This program analyzes database objects (tables and indexes) of 
    specified users(s). This program uses compute option to 
    get statistics for indexes and estimate option for tables.

Note :
    The Oracle userid must have access to analyze the tables.
    OPS\$ORACLE account should exist. Should be run by Oracle user.

EOFEOF

    #get command line options
    &getopt('defhilmprsuton');
    if ($opt_h)
    {
        print $usage;
        exit(0);
    }

    undef($pfile);
    $pfile = $opt_f ;
    $estimate = 30;
    $ana_type = DBMS;
    $schema_order_by1=PERFSTAT;
    &get_params($pfile) if defined($pfile);

    $oracle_sid     = $opt_s ? $opt_s : "";
    $estimate       = $opt_e ? $opt_e : $estimate;
    $mailto         = $opt_m ? $opt_m : $mailto;
    $pageto         = $opt_p ? $opt_p : $pageto;
    $analyze_users  = $opt_u ? $opt_u : $analyze_users;
    $logfile        = $opt_l ? $opt_l : $logfile;
    $p_degree       = $opt_d ? $opt_d : $p_degree;
    $ana_type       = $opt_t ? $opt_t : $ana_type;
    $schema_order_by1= $opt_o ? $opt_o : $schema_order_by1;
    $rac_node       = $opt_n ? $opt_n : $rac_node;
    
    print "Analyze_percent   = $estimate\n";
    print "Analyze_users      = $analyze_users\n";
    print "Analyze_Type      = $ana_type\n";
    print "Analyze_Order     = $schema_order_by1\n";
    print "Rac_Node_No       = $rac_node\n";
    print "Degree            = $p_degree\n";
    print "Mailto            = $mailto\n";
    print "Pageto            = $pageto\n";
    print "Logfile           = $logfile\n";
@mschema_order_by=split(',',$schema_order_by1);
    if (!defined($oracle_sid) || $oracle_sid eq "")
    {
        printf "SID is not given.\n";
        &show_error("SID is not given"); 
    }
    if (!defined($estimate) || $estimate < 0 || $estimate > 100)
    {
        printf "Estimate - $estimate : Value is not given or invalid.\n";
        &show_error("Estimate - $estimate : Value is not given or invalid."); 
    }

    open(LOGFILE, ">$logfile") || die "Cannot open log file. $!";
    print LOGFILE "Analyze_percent = $estimate\n";
    print LOGFILE "Anlyze_users    = $analyze_users\n";
    print LOGFILE "Analyze_Type    = $ana_type\n";
    print LOGFILE "Analyze_Order   = $schema_order_by1\n";
    print LOGFILE "Rac_Node_no     = $rac_node \n";
    print LOGFILE "Mailto          = $mailto\n";
    print LOGFILE "Pageto          = $pageto\n";
    print LOGFILE "Logfile         = $logfile\n";
    close(LOGFILE);

    &ora_home($oracle_sid);
##    &get_ora_home($oracle_sid);
        &StdDBPackage::which_lib();
    #print "SID=$oracle_sid \n";
    #print " OH $ENV{'ORACLE_HOME'} \n";
    #$dbh = DBI->connect("", "", "", "dbi:Oracle:") ||
    $dbh = DBI->connect("DBI:Oracle:", '', '',{ ora_session_mode=>2})||
        &show_error("Cannot login to $oracle_sid. $DBI::errstr");
    
    #$r=$dbh->do('alter session set current_schema = OPS$ORACLE');
#    $r=$dbh->do(q{alter session set events '38019 trace name context forever, level 1' });
    #$r=$dbh->do(q{alter session set "_optim_adjust_for_part_skews"=false  });

#sasalian    $LOGDIR = "/usr/tools/oracle/Standard/dbms_stats" ;
    $LOGDIR = "/usr/tools/oracle/Standard/script/Custom/${oracle_sid}/analyze" ;
    $log_file = "${LOGDIR}/${oracle_sid}_analyze_times_gt_15mins.log";

    system("/bin/cp /dev/null $log_file");

}

sub analyze_tables
{
#    if ((!defined($analyze_users)) || ($analyze_users eq ""))
    if ((defined($analyze_users)) || ($analyze_users ne ""))
    {
#print "inside analyze_users \n";
     $analyze_users =~ s/,/','/g;
	     $analyze_users =~ s/^/'/g;
		     $analyze_users =~ s/$/'/g;
			     $where_condition = " and owner in ($analyze_users) ";

#        $where_condition = "and owner not in ('SYS', 'SYSTEM')";
        #and owner >= 'O'";
    }
    else 
    {
         if ($rac_node == 1)
	 {

	     $where_condition=" and owner in(select owner_name from ops\$oracle.rac_schema_analyze where node_no=1)";
         }
	 elsif ($rac_node == 2)
	 {

	    $where_condition=" and owner in(select username from dba_users minus select owner_name from ops\$oracle.rac_schema_analyze where node_no=1)";
         }
    #     else
#	 {
#if ($ana_type eq 'DBMS')
#       {  
#	 $where_condition = "and owner not in ('SYS', 'SYSTEM') and owner not in (select oracle_username from apps.fnd_oracle_userid )";
#        }
#     else
#        { 
#	 $where_condition = "and owner not in ('SYS', 'SYSTEM') and owner in (select oracle_username from apps.fnd_oracle_userid )";
#        }
#
#	 }

     if ($ana_type eq 'DBMS')
        {
$stms="select count(*) from dba_users where username='APPS'";
       #print $St1;
    $Sh1 = $dbh->prepare($stms) ||
        warn("Error while preparing $stms. $DBI::errstr");
        $Sh1->execute;
        ($row) = $Sh1->fetchrow_array;
        $Sh1->finish;
           if ($row <1)
              {
                $dbms_fnd="and owner not in ('SYS', 'SYSTEM', 'DP','XXCMF')";
#                #print "DBMS with Non 11i \n";
              }
           else
              {
               $dbms_fnd="and owner not in ('SYS', 'SYSTEM', 'DP','XXCMF') and owner not in (select oracle_username from apps.fnd_oracle_userid )";
               #print "DBMS with 11i \n";
              }
        }
     else
        {
         $dbms_fnd="and owner not in ('SYS', 'SYSTEM', 'DP','XXCMF') and owner in (select oracle_username from apps.fnd_oracle_userid )";
        }

#        $analyze_users =~ s/,/','/g;
#        $analyze_users =~ s/^/'/g;
#        $analyze_users =~ s/$/'/g;
#        $where_condition = " and owner in ($analyze_users) ";
    }



       
    $stmt = "select owner, segment_name, round(sum(bytes/1024/1024), 0) \
	from dba_segments ds \
	where 1=1 \
        and segment_type in ('TABLE', 'TABLE PARTITION','TABLE SUBPARTITION') \
        and segment_name not like 'BIN\$%' \
        $where_condition \
        $dbms_fnd \
	and not exists (select null  from ops\$oracle.EXCLUDE_TABLE_STATS ets  where ets.table_name=ds.segment_name) \
        group by owner, segment_name \
        order by owner, segment_name";

   #print " Select statement $stmt \n";
    $sth = $dbh->prepare($stmt) || 
        warn("Error while preparing $stmt. $DBI::errstr");
    $rc = $sth->execute() 
        || warn("Error while executing $stmt. $DBI::errstr");
    $usertableref = $sth->fetchall_arrayref;
    $sth->finish();

    foreach(@$usertableref)
    {
        ($owner, $table, $tsize) = (@$_);
        push(@{$analyze_tables{$owner}}, $table);
        $own_tbl = ${owner}."_".${table};
        push(@{$analyze_tbsize{$own_tbl}}, $tsize);
        $indx = "${owner}_${table}";
        $table_size{$indx} = $tsize;
        if ($tsize <= 1 )
        {
            $degree{$indx} = 1;
        }
        else
        {
            $degree{$indx} = $p_degree;
        }
        ($analyze_clause{$indx}, $degree{$indx}) = &get_analyze_clause($owner, $table, $indx);
#     print "Degree $$degree{$indx} Sample $analyze_clause{$indx} \n";
    }
    &analyze_fn(@analyze_tables);
}

sub get_analyze_clause()
{
my $owner;
my $table;
my $stmt;
my $sth;
my $rc;

    ($owner, $table, $indx) = @_;
    #
    # Get table size.
    #
    $tabsize = $table_size{$indx};
    #
    # Get analyze clause.
    #
    $r1 = "-1";
    for($i=0; $i<=$#tsizeinorder; $i++)
    {
        #print "Size $tabsize $tsizeinorder[$i]\n";
        if ($tabsize <= $tsizeinorder[$i]) 
        { 
	    $r1 = $percent_hash{$tsizeinorder[$i]}; 
	    $r3 = $percent_hash1{$tsizeinorder[$i]}; 
	    last; 
        }
    }
    if ($r1 eq "-1")              # Sample is not given. Use $estimate.
    {
        $r2 = "$estimate";
    }
    elsif ($r1 =~ /compute/i)
    {
        $r2 = 'NULL';
    }
    else
    {
        $r2 = "$r1";
    }
$r4 ="$r3";
#print "R4 $r4 anf R3 $r3 R2 $r2 \n";
    return($r2,$r4);
}

sub analyze_fn()
{
my @analyze_tables;

    @analyze_tables = @_;

    # Clean analyze_todo_1 and analyze_info tables
    $dbh->do("delete from ops\$oracle.analyze_todo_1 where db = \'$oracle_sid\'") ;
    $dbh->commit;

    foreach $owner (sort keys %analyze_tables)
    {
      foreach $table (@{$analyze_tables{$owner}})
      {
        $own_tbl = ${owner}."_".${table};
        foreach $megab (@{$analyze_tbsize{$own_tbl}})
        {
	   $mbytes = $megab;
           $towner = $owner;
           $ttable = $table;

           # Skip specific schema
           if ($owner eq 'OPS$ORACLE')  {
	      next;
           }

           # Skip index-organized overflow tables
	   if (substr($table,0,12) eq 'SYS_IOT_OVER')  {    
	      next;
	   }

           $indx = "${owner}_${table}";
           $sample_size = $analyze_clause{$indx};
           $degree = $degree{$indx};

           if ($sample_size eq "NULL") {
	     $degree = 1;
           }

           foreach $sp_size (@{$special_tables{$own_tbl}})  {
	     $sample_size = $sp_size;
           }

  #print "osid, owner, table, mb, size, degree ----- $oracle_sid, $towner, $ttable, $mbytes, $sample_size, $degree\n";
	   my $ins_sql = qq{ insert into ops\$oracle.analyze_todo_1 values (?,?,?,?,?,?) };
           $cth = $dbh->prepare($ins_sql) || die "Problem prepare ins_sql:  $DBI::errstr \n";

	   $cth->bind_param(1, $oracle_sid);
	   $cth->bind_param(2, $towner);
	   $cth->bind_param(3, $ttable);
	   $cth->bind_param(4, $mbytes, {TYPE=>SQL_INTEGER});
	   $cth->bind_param(5, $sample_size, {TYPE=>SQL_INTEGER});
	   $cth->bind_param(6, $degree, {TYPE=>SQL_INTEGER});
	   $cth->execute;
        }
      }
    }
    $dbh->commit;
}


sub analyze_run()
{
my $imax = 500;
my @analyze_tbl = (); 

    chomp($OS = `/bin/uname`);
    $PS_CMD="/bin/ps xaef | /bin/grep analyze";
#     if ($ana_type eq 'DBMS')  
         $running_cmd = "fnd_dbms_ana";
#     else 
#	{ $running_cmd = "analyze_fnd";}

    # Tables that have been analyzed in last SKIP_HOURS hours
    $chk_stmt = "select owner, table_name from dba_tables \
		where owner not in (\'SYS\', \'SYSTEM\', \'OPS\$ORACLE\', \'DP\',\'XXCMF\') \ 
		    and (trunc(last_analyzed)=trunc(sysdate) or trunc(last_analyzed)=trunc(sysdate-1)) \
		    and trunc( ( (86400*(sysdate-last_analyzed))/60)/60) < $SKIP_HOURS";
    $csh = $dbh->prepare($chk_stmt) || warn("Prepare failed for $chk_stmt. $DBI::errstr");
    $csh->execute || warn("Execute failed for $chk_stmt. $DBI::errstr");
    while (($town, $ttbl) = $csh->fetchrow_array)  { 
       push(@{$analyze_tbl{$town}}, $ttbl);
    }
$schema_count=0;      
foreach (@mschema_order_by) {
$order_by = "'$_',$schema_count,";                                                                                                           
push(@schema_order_by_num,$order_by);
$schema_count=$schema_count+1;
}
$schema_order_by_number="@schema_order_by_num";
$schema_order_by_number=~ s/$"//g;
$schema_order_by_number=~ s/,$//g;


#    $loop_stmt = "select * from ops\$oracle.analyze_todo_1 where db=\'$oracle_sid\' order by megs desc";
    $loop_stmt = "select * from ops\$oracle.analyze_todo_1 where db=\'$oracle_sid\' order by decode(tbl_owner,$schema_order_by_number),megs ";
    #print " Loop statement $loop_stmt \n";
    $lpsh = $dbh->prepare($loop_stmt) || warn("Prepare failed for $loop_stmt. $DBI::errstr");
    $lpsh->execute || warn("Execute failed for $loop_stmt. $DBI::errstr");

    my $threads_flag = 0;
    # Loop thru analyze_todo_1 to analyze tables
#     print "\n $towner , $ttable , $mbytes MB , $degree degrees , $sample_size percent"; 
    while (($dname, $towner, $ttable, $mbytes, $sample_size, $degree) = $lpsh->fetchrow_array)  { 

#       if ($towner eq $SCHEMA_FIRST)  {
#	  next;
#       }
      #print "mbytes $mbytes \n";
       # Skip recently analyzed tables 
       $not_analyze = 0;
       foreach $owner (sort keys %analyze_tbl)   {
          if ($not_analyze == 1)  {
	     last;
          }
          foreach $table (@{$analyze_tbl{$owner}})   {
	     if (($owner eq $towner) && ($table eq $ttable))  {
	         $not_analyze = 1;
	         last;
	     }
	  } 
       }
       if ($not_analyze == 1)  {
	  next;
       }
       
     #print "\n $towner , $ttable , $mbytes MB , $degree degrees , $sample_size percent"; 
       # Change max simultaneous analyze threads based on par file
       $exit_loop = 0;
#       foreach $mb (reverse sort keys %max_dbms_threads_copy) {
       foreach $mb ( sort numerically keys %max_dbms_threads_copy) {
             #print " \n kkMAX__ $mb \n";
	 if ($exit_loop == 1)  {
	    last;
	 }
         foreach $thrds (@{$max_dbms_threads_copy{$mb}})  {
	    if ($mbytes < $mb)  {
	       $max_analyze_threads = $thrds;
               #pop(@{$max_dbms_threads_copy{"$mb"}});
               #print "\n MBYTES $mbytes, MB $mb, MAX_THREAD $max_analyze_threads, THREAD $thrds \n";
	       $exit_loop = 1;
	       last;
	    }
         }
       }
#     print "own, megs, max_an_threads --> $towner  ,  $mbytes  ,  $max_analyze_threads \n";

       if (($sample_size eq "NULL") && ($threads_flag == 0))  {
          my $cur_time = time;
#         print "\nENDED ANALYZE OF NON-COMPUTE TABLES FOR OTHERS  ", &get_date("DD-MON-YYYY"), "   Time  ", &get_time("HH:MI:SS", $cur_time), "\n";
	  $threads_flag = 1;
       }

       my $total_sleep = 0;
       # Check for total dbms_stats threads 
       for ($i=1; $i<$imax; $i++)  {   # A forever loop ...
	   # If total dbms_stats threads is less than maximum then out of this loop
           my $count = 0;
           open(INPS,"$PS_CMD |") || die "Can not run $PS_CMD --   $!\n";
           while (<INPS>) {
              (/${running_cmd}/ && /${oracle_sid}/) or next;
              #/${running_cmd}/ or next;
              $count++;
           }
           close(INPS);
        #print "cnt IS $count and sid is ${oracle_sid}\n";
           if ($count < $max_analyze_threads)  {
              last;
           }

	   if ($total_sleep < 600)  {
              if ($i == 1)  {
                #print "\nsleeping at $towner , $ttable . ";
     print "\n $towner , $ttable , $mbytes MB , $degree degrees , $sample_size percent"; 
	      }  else  {
	        print ".";
	      }
	   }
           sleep $sleep_time;
	   $total_sleep = $total_sleep + $sleep_time;
	   if ($total_sleep >= 600)  {
	      if ($total_sleep == 600) {
	         print "\nSLEEPING more than $total_sleep secs . ";
	      }  else {
		 print ".";
	      }
           }
       }   # for forever loop

     #print "\n $oracle_sid,$towner , $ttable , $mbytes MB , $degree degrees , $sample_size percent \n"; 
# exit(0);
#print "Before calling start_analyze \n";
#     if ($ana_type eq 'DBMS')  {
#       system ("${LOGDIR}/analyze_dbms_v9.pl -s $oracle_sid -o '$towner' -t '$ttable' -z $sample_size -d $degree -m $mbytes -l $log_file &");
#	&start_analyze($oracle_sid,$towner,$ttable,$sample_size,$degree,$mbytes,$log_file,$ana_type);
#     }  else {
#	system ("${LOGDIR}/analyze_fnd_v9.pl -s $oracle_sid -o '$towner' -t '$ttable' -z $sample_size -d $degree -m $mbytes -l $log_file &");        #}

         system ("${LOGDIR}/fnd_dbms_ana.pl -s $oracle_sid -o '$towner' -t '$ttable' -z $sample_size -d $degree -m $mbytes -l $log_file -a $ana_type -p $pageto -k $mailto &");
    }
    $csh->finish;
    $lpsh->finish;

    my $cur_time = time;
   print "\nENDED ANALYZE OF OTHERS  ", &get_date("DD-MON-YYYY"), "   Time  ", &get_time("HH:MI:SS", $cur_time), "\n\n";

}



sub print_time()
{
use integer;

my $hours, $minutes, $seconds, $time_duration;

    $time_duration = $_[0];
    $hours = $time_duration / 3600;
    $seconds = $time_duration % 60;
    $minutes = ($time_duration % 3600) / 60;
    $ret_string = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);;
    return($ret_string);
}

sub get_params()
{
my $pfile;

    $pfile = $_[0];
    if (! -f $pfile)
    {
        print "File $pfile doesn't exist.\n";
        &show_error("File $pfile doesn't exist."); 
    }
    open(PFILE, "$pfile") || &show_error("Cannot open $pfile. $!");
    while(<PFILE>)
    {
    #print "\n indide pfile \n";
        chomp;
        next if /^#/;
        if (/analyze_percent/i)
        {
            $estimate = (split(" ")) [2];
        }
        elsif (/analyze_users/i)
        {
            ($dummy, $dummy, @usernames) = (split(" "));
            $analyze_users = join '', @usernames;
            $analyze_users =~ tr /a-z/A-Z/;
        }
        elsif (/mailto/i)
        {
            ($dummy, $dummy, @mailto) = (split(" "));
            $mailto = join '', @mailto;
        }
        elsif (/pageto/i)
        {
            ($dummy, $dummy, @pageto) = (split(" "));
            $pageto = join '', @pageto;
        }
        elsif (/logfile/i)
        {
            ($dummy, $dummy, $logfile) = (split(" "));
        }
        elsif (/degree/i)
        {
            ($dummy, $dummy, $p_degree) = (split(" "));
        }
        elsif (/table_size/i)
        {
            ($d1, $d2, $table_size, $d3, $sample, $degree1) = split(" ");
            chomp($table_size);
            #print "Sample $sample Degree $degree1 \n";
            $percent_hash{$table_size} = join ' ', $sample;
            $percent_hash1{$table_size} = join ' ', $degree1;
        }
        elsif (/max_simultaneous_dbms_threads/i)
        {
            ($dummy1, $dummy2, $change_mb, $dbms_threads) = (split(" "));
	    chop($change_mb);
             #print " Change MB $change_mb \n";
            push(@{$max_dbms_threads{"$change_mb"}}, $dbms_threads);
        }
        elsif (/special_table/i)
        {
            ($dummy, $sp_own, $sp_tbl, $sp_percent) = (split(" "));
            $sp_own_tbl = ${sp_own}."_".${sp_tbl};
            push(@{$special_tables{$sp_own_tbl}}, $sp_percent);
        }
	elsif (/order_of_analyze/i)
	{
	   ($dummy,$schema_order_by1) =(split(" "));
           @mschema_order_by=split(',',$schema_order_by1);

        }
    }
    @tsizeinorder = sort numerically (keys %percent_hash);
    close(PFILE);
}

sub numerically
{
    $a <=> $b;
}

sub analyze_error
{
    print "@_\n\n";
    ##&pageit(@_);
    system("/usr/bin/mailx -s \"$oracle_sid problem - Analyze Problem \" $maillist< /dev/null");
    $dbh->disconnect if (defined($dbh));
    exit(1);
}

sub pageit
{
my @pagemsg = @_;

    while ($pagemsg = pop(@pagemsg))
    {
        foreach $page (split /,/, $pageto)
        {
            #print "<$pageexe $page \"$pagemsg\">\n";
            `$pageexe $page \'$pagemsg\'`;
        }
    }
}


sub ora_home()
{
my $oracle_sid;

    $oracle_sid = $_[0];

    #-------------------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #-------------------------------------------------------------------------
    open(ORATAB, "/etc/oratab") ||
        &dbstats_error("Can't Open /etc/oratab. $!\n");

    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_HOME'}=$oracle_home;
        $ENV{'ORACLE_SID'}=$oracle_sid;
             #print "OHOME $ENV{'ORACLE_HOME'}, SID=$ENV{'ORACLE_SID'} \n";
        $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
        #$ENV{'SHLIB_PATH'} = "$oracle_home/lib32";
        $ENV{'TNS_ADMIN'} = "$oracle_home/network/admin";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;
        }

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
 	  $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }

#        print "Sid $oracle_sid home $oracle_home\n" if defined($opt_d);
#        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
#        &StdDBPackage::which_lib();

    }
    close(ORATAB);
}

sub analyze_iot()

{
     if ($ana_type eq 'DBMS')
      {$iot_stmt = "select owner,table_name from dba_tables where iot_type='IOT' and owner not in ('SYS', 'SYSTEM','DP','XXCMF') and owner not in (select oracle_username from apps.fnd_oracle_userid )";}
     else
       { $iot_stmt = "select owner,table_name from dba_tables where iot_type='IOT' and owner not in ('SYS', 'SYSTEM','DP','XXCMF') and owner  in (select oracle_username from apps.fnd_oracle_userid )";}

    $ipsh = $dbh->prepare($iot_stmt) || warn("Prepare failed for $iot_stmt. $DBI::errstr");
    $ipsh->execute || warn("Execute failed for $iot_stmt. $DBI::errstr");

    while (($itowner, $itable) = $ipsh->fetchrow_array)  {
         $isample_size=10;
         $idegree=20;
         $imbytes=10; 
         $ilog_file=$log_file;
         $iana_type=$ana_type;
         $ipageto=$pageto;
         $imailto=$mailto;
    system ("${LOGDIR}/fnd_dbms_ana.pl -s $oracle_sid -o '$itowner' -t '$itable' -z $isample_size -d $idegree -m $imbytes -l $ilog_file -a $iana_type -p ipageto -k imailto &");
   }

    $ipsh->finish;
}
