#!/bin/sh

SSH=/usr/local/bin/ssh

for host in  c7-a1-oa1-iprd-69 c7-a1-oa1-iprd-70 c7-a1-oa1-iprd-71 c7-a1-oa1-iprd-72
do
    echo "Running stop_all.sh on $host"
    $SSH $host -l oactsprd ". ./start_profile; /apps/ctsprd/common_top/admin/scripts/CTSPRD_$host/stop_all.sh >/var/local/CTSPRD/stop_all_${host}.log 2>&1"  &
done

