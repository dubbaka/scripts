#!/bin/sh

SSH=/usr/local/bin/ssh

for host in c7-a1-oa1-iprd-65 c7-a1-oa1-iprd-66 c7-a1-oa1-iprd-67 c7-a1-oa1-iprd-68 c7-a1-oa1-iprd-69 c7-a1-oa1-iprd-70 c7-a1-oa1-iprd-71 c7-a1-oa1-iprd- 72
do
    echo "Running stop_all.sh on $host"
    $SSH $host -l oactsprd ". ./start_profile; /apps/ctsprd/common_top/admin/scripts/CTSPRD_$host/stop_all.sh >/var/local/CTSPRD/stop_all_${host}.log 2>&1"
done


# Stop External Apps Server - connect to c7-a1-oa1-xprd-12 as oactsprd
echo "Running stop_all.sh on c7-a1-oa1-xprd-12"
$SSH c7-a1-oa1-xprd-12 -l oactsprd "/apps/ctsprd/common_top/admin/scripts/CTSPRD_c7-a1-oa1-xprd-12/stop_all.sh  >/var/local/CTSPRD/stop_all_c7-a1-oa1-xprd-12.log 2>&1"

# Stop External Apps Server - connect to c7-a1-oa1-xprd-13 as oactsprd
echo "Running stop_all.sh on c7-a1-oa1-xprd-13"
$SSH c7-a1-oa1-xprd-13 -l oactsprd "/apps/ctsprd/common_top/admin/scripts/CTSPRD_c7-a1-oa1-xprd-13/stop_all.sh  >/var/local/CTSPRD/stop_all_c7-a1-oa1-xprd-13.log 2>&1"






