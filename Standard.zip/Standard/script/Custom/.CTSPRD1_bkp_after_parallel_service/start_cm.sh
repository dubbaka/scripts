#!/bin/sh

SSH=/usr/local/bin/ssh
for host in c7-a1-oa1-iprd-65 c7-a1-oa1-iprd-66 c7-a1-oa1-iprd-67 c7-a1-oa1-iprd-68 
do
    echo "Running start_all.sh on $host"
    $SSH $host -l oactsprd ". ./start_profile; /apps/ctsprd/common_top/admin/scripts/CTSPRD_$host/start_all.sh >/var/local/CTSPRD/start_all_${host}.log 2>&1" &
done


