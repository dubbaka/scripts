#!/bin/ksh
#*************************************************************************************************************************
# Created By : Bidhu Das
# Creation Date : 08/22/2006
# Description : It verifies the raw volumes to be added by calling verify_file.sh which prevents the addition of wrong 
#               volumes to the instance after checking the instance status
# Constraint : You can not add space to both archive and standard tablespaces at the same time which is only applicable for SJPROD
#              Add space in terms of MB only i,e, 500M, 1000M, 2000M or 4000M
#
#  01/08/07 sramineni            Std compliance phase-2
#*************************************************************************************************************************
#
# Usage : add_space.sh (It does not take any parameter as it derives the instance name from current environment setting)
#
#set -x
#
#-----------------------------------------------------
#Check if the DB is running or not before adding space
#-----------------------------------------------------
#

##################  STD Compliance     ##########################
#  Pl add this piece of code in all Std Scripts at the beginning  
#  before staring any operations                                  
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!             
thisScriptName="add_space.sh"  # << Change this to standard script name
#
stddate=`date -u +%Y%m%d%H%M`
stdlogfile="${thisScriptName}_${stddate}"
stdlibpath="/usr/tools/oracle/Standard/lib"
stdpidval=$$
actscriptname=$0
stdjobseq="${stddate}-${stdpidval}"
stdcksum=`/oracle/product/perl $stdlibpath/StdCompProc.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname`
if [ "$stdcksum" = "FAILED" ]
then
	echo
	echo "This script $actscriptname is not same as standard script $thisScriptName"
	echo "Exiting.."
	exit 1
fi

if [ "$stdcksum" =  "SUCCESS" ]
then
	echo 
	echo "This script is $actscriptname matching checksum with standard script $thisScriptName..Continuing.."
fi

###################################################################

active=`ps -ef| grep -iw "ora_pmon_$ORACLE_SID" | grep -v grep | wc -l`
if [ $active -ne 1 ]
then
   echo "$ORACLE_SID is not running now, So u can not add space to it, Pl Add it later ............."
   exit
fi

##################  STD Compliance     ##########################
# If the script is used for all the database in this server
# like check_extend_all.pl, put this piece of code inside the loop
# for each databases using ORATAB.  Change the value for
# the variable "$mysid" to actual variable for each database
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
stdsid="$ORACLE_SID"  # << Change "$sid" to actual variable
/oracle/product/perl $stdlibpath/StdCompProc.pl begin_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName
###############################################################
status='N';
echo "You are adding the datafile to $ORACLE_SID ...confirm(Y/N):\c"
read status
if [ "$status" != 'Y' -a "$status" != 'y' ]
then
   echo "WARN!! datafile not added "
   exit
fi
echo "continue... "
/usr/tools/oracle/Standard/script/verify_file.sh
if [ $? -eq 1 ]
then
   exit
fi

if [ -f standby.ctl ]
then
mv standby.ctl standby.ctl.`date "+%m%d%y%H%M%S"`
fi

###########    IMPORTANT    IMPORTANT    IMPORTANT    #########
#
#             !!!!!   DONOT MODIFY THIS FILE   !!!!! 
#  This is script will call add_datafile.sh 
#  Please add/modify the add tablespace and DR related sections there
#  Donot add here in add_space.sh
###############################################################

thisprog=$0
thisscript=`basename $thisprog`
progpath=` echo $thisprog | sed -e 's/'$thisscript'/add_datafile.sh/' `
# Executing add tablespace & DR
$progpath STD

##################  STD Compliance     ##########################
# Place this piece of code at the end of LOOP job for each database.
/oracle/product/perl $stdlibpath/StdCompProc.pl end_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName
###############################################################


##################  STD Compliance     ##########################
########  Pl add this piece of code in all Std Scripts ########
#     after completion of the script and before exit  #########
/oracle/product/perl $stdlibpath/StdCompProc.pl end_alljob $stdjobseq ALL $stdlogfile $thisScriptName
###############################################################


exit
