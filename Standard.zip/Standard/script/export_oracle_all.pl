#!/oracle/product/perl
##!/usr/local/bin/perl
# History Modified:
#  swei 02-apr-2004 created to export all databases from /var/opt/oracle/oratab
#	            default rows=N and will read oracleDB.par exception.par 
#  erirobin 08-feb-2005 Modified topick up correct mknod not matter what platform.
# ........................................................................
#use DBI;
use POSIX;
use Getopt::Std;


chomp($hostname = `uname -n`);
$hostname =~ tr /a-z/A-Z/;
$MAX_PROCS = 3;
$status = "ERROR" ;
$parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
$exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";

undef @sids;
undef @sidarr;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;

$count=0;

if (-f "/sbin/mknod") {$mknod_exe="/sbin/mknod";}
elsif (-f "/etc/mknod") {$mknod_exe="/etc/mknod";}
elsif (-f "/usr/local/bin/mknod") {$mknod_exe="/usr/local/bin/mknod";}
else {print "mknod not found"; }

print $mknod_exe ;



# ........................................................................
#		Main
# ........................................................................


open(ALLTAB, "/var/opt/oracle/oratab") || 
    &show_error("Can not open /var/opt/oracle/oratab. ", "$!");
while (<ALLTAB>)
{

    next if (/^#/ || /^\s/);
    ($sid, $ora_home, $db_flag) = split(/:/);
    #print "$sid $db_flag \n";
    next if ($db_flag =~ /^N/ || $db_flag =~ /^n/ );

    ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($sid);

    $yn="Y";
    $direct_export="N";
    if ( -d "/oracle_exp" )
    {
    $exp_dir="/oracle_exp";
    }	
    else
    {
    $exp_dir="/ora_exp";
    }	
    
    $rows=""; 
    &get_exception_value();
 

    #($sid, $yn, $direct_export, $exp_dir, $dba_mail, $rows) = split(/:/);
    next if ($yn =~ /^N/);
    $dba_mail = $mailto ;
    print "$sid $yn $exp_dir $dba_mail $rows\n";
    @{$sidarr[$count]} = ($exp_dir, $dba_mail, $yn, $direct_export, $rows);
    $exp_hash{$sid} = \@{$sidarr[$count]};
    $count++;
}
close(ALLTAB);

if ($sids ne "exptab")
{
    @sids = split(',', $sids);
    foreach $sid (@sids)
    {
        if (exists($exp_hash{$sid}))
        {
            $aref = $exp_hash{$sid};
            ${$aref}[2] = "Y";
        } 
        else
        {
            $dba_mail = $mailto;
            @{$sidarr[$count]} = ("/ora_exp", $dba_mail, "Y", "N");
            $exp_hash{$sid} = \@{$sidarr[$count]};
            $count++;
        }
    }
}
foreach $sid (sort keys %exp_hash)
{
    $aref = $exp_hash{$sid};
    @data = @{$aref};
    $exp_dir = $data[0];
    $mailto2 = $data[1];
    $exp_yn = $data[2];
    $direct_export = $data[3];
    $rows_yn = $data[4];
    next if ($exp_yn =~ /^N/);
    print "Data <$sid> <$exp_dir> <$mailto2> <$exp_yn> <$rows_yn> \n";
}

#exit(0);
foreach $sid (keys %exp_hash)
{
    $aref = $exp_hash{$sid};
    @data = @{$aref};
    $exp_dir = $data[0];
    $mailto2 = $data[1];
    $exp_yn = $data[2];
    $direct_export = $data[3];
    $rows_yn = $data[4];
    next if ($exp_yn =~ /^N/);
    if ($pid = fork)
    {                                  # PARENT  
        system(date);
        print "Exporting $sid\n";
        push @pids_running, $pid;
        while ($#pids_running >= $MAX_PROCS - 1)
        {
            foreach $pid (@pids_running)
            {
                if (($return = POSIX::waitpid( $pid, &POSIX::WNOHANG )) > 0)
                {
                    @pids_running = grep !/^${pid}$/, @pids_running;
                }
            }
            sleep 5;
        }
    }
    elsif (defined $pid)
    {                                  # CHILD   
        select(STDOUT);
        $| = 1;
        select(STDERR);
        $| = 1;
        select(STDOUT);
        &export_fn($sid, $exp_dir, $mailto2, $direct_export, $rows_yn);
        exit 0;
    }
    else
    {
        die("Can't Fork: $!\n");
    }
}

while ($#pids_running >= 0)
{
    foreach $pid (@pids_running)
    {
        if (($return = POSIX::waitpid( $pid, &POSIX::WNOHANG )) > 0)
        {
            @pids_running = grep !/^${pid}$/, @pids_running;
        }
    }
    sleep 5;
}
# ........................................................................
#		End of Main
# ........................................................................

sub export_fn()
{
my ($sid, $exp_dir, $mailto1, $direct_export, $rows2);

    $start_date = `date`;
    ($sid, $exp_dir, $mailto1, $direct_export, $rows2)  = @_;
    &ora_home($sid);    
    $global_rows = $rows2;
    &check_ops_login($sid);
    $mknod_file = "/tmp/$$.pipe";
    $output_dir = "$exp_dir/${sid}_exp";
    $output_file = "$exp_dir/${sid}_exp/${sid}_full.dmp";
    $log_file = "$exp_dir/${sid}_exp/${sid}_full.log";
    (mkdir($output_dir, 0755) || &show_error("mkdir $output_dir failed.", "$!")) unless -d $output_dir;
    `$mknod_exe $mknod_file p`; 
    $ENV{'ORA_NLS32'} = "";
    $ENV{'ORA_NLS33'} = "";
    #system("/usr/local/bin/gzip < $mknod_file > ${output_file}.gz &");
    system("gzip < $mknod_file > ${output_file}.gz &");
    open(EXP, "$ENV{'ORACLE_HOME'}/bin/exp userid=/ consistent=y buffer=8000000 file=$mknod_file rows=$global_rows full=y compress=n log=$log_file direct=$direct_export 2>&1 |");

    undef(@errorlog);
    while (<EXP>)
    {
        print;
        if (/^EXP-/ || /^ORA-/)
        {
            $error = 1;
            push(@errorlog, $_);
        }
    }
    close(EXP);
    unlink($mknod_file) || &show_error("$mknod_file unlink error. ", "$!");
    $end_date = `date`;

    #$message = "Start Date: $start_date\nEnd Date:  $end_date\n" .
    #         join("", @errorlog) .
    #         "\nPlease check $log_file for more details.\n";
    $message_file = "/tmp/export_$sid.log";
    open(OUTFILE, "> $message_file");
        print OUTFILE "Start Date: $start_date\n";
        print OUTFILE "End Date:  $end_date\n";
        print OUTFILE "@errorlog\n";
        print OUTFILE "Please check $log_file for more details\n";
    close(OUTFILE);
    $status = "Successful" unless $error;
    $status = "ERROR" if $error;
    $mailto = $mailto1;
   
    if ("$status" eq "ERROR" )
    {
    $errmsg = &msgfmt("w","`uname -n`","$sid","Export Completed With $status Status");
    }
    else
    {
    $errmsg = &msgfmt("i","`uname -n`","$sid","Export Completed With $status Status");
    }
    &mailit("$errmsg",$message_file);
    #unlink($message_file); 

#    `mailx -s "$sid Export Completed With $status Status" $mailto <<EOF\n$message\nEOF\n`;
}

sub ora_home()
{
my $oracle_sid;

    $oracle_sid = $_[0];
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || &show_error("Can't Open /etc/oratab", "$!");
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_SID'}  = $oracle_sid;
            $ENV{'ORACLE_HOME'} = $oracle_home;
            $ENV{'PATH'} = "${oracle_home}/bin:/usr/local/bin:/usr/bin:/bin:".$ENV{'PATH'};
            $ENV{'LD_LIBRARY_PATH'} = "${oracle_home}/lib";
        $ENV{'SHLIB_PATH'} = "$ora_home/lib";
	($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = '$oracle_home/ocommon/nls/admin/data';
        $ENV{'ORA_NLS33'} = '/oracle/product/clntcurr/ocommon/nls/admin/data';
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = '/oracle/product/clntcurr/ocommon/nls/admin/data';
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }


        print "Sid $oracle_sid home $ora_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
	&StdDBPackage::which_lib();

            print "$ENV{'PATH'}\n";
        }
    }
    close(ORATAB);
}

sub check_ops_login()
{
my $oracle_sid;

    $oracle_sid = $_[0];
    undef $dbh;
    if (!($dbh = DBI->connect("dbi:Oracle:", "", "")))
    {
        print "Creating ops\$oracle account.\n";
        $dbh = DBI->connect("dbi:Oracle:", "internal", "") || &show_error("Can not connect to $oracle_sid.", "$DBI::errstr");
        $dbh->do("create user ops\$oracle identified externally") || &show_error("Create user failed.", "SID - $oracle_sid, $DBI::errstr");
        $dbh->do("grant connect, resource, dba to ops\$oracle") || &show_error("Grant failed.", "SID - $oracle_sid, $DBI::errstr");
    }
    $sth = $dbh->prepare("select value\$ from sys.props\$ \
        where name = 'NLS_CHARACTERSET'")  
        || &show_error("SID - $oracle_sid Prepare failed.", "$DBI::errstr");
    $rc = $sth->execute() 
        || &show_error("SID - $oracle_sid Excute failed.", "$DBI::errstr");
    ($charset, @dummy) = $sth->fetchrow_array();
    $sth->finish();
    print "rows: $global_rows \n";
    if ($global_rows eq "" )
    {
    $sth = $dbh->prepare("select round(sum(bytes)/1024/1024) \
        from dba_segments" )
        || &show_error("SID - $oracle_sid Prepare failed.", "$DBI::errstr");
    $rc = $sth->execute() 
        || &show_error("SID - $oracle_sid Get Size failed.", "$DBI::errstr");
    ($usedsize, @dummy) = $sth->fetchrow_array();
    $sth->finish();
    if ($usedsize > 10000)
       {  $global_rows="N"; }
    else
       {  $global_rows="Y"; }
    } 
    $dbh->disconnect();
    print "Database $oracle_sid    Charset - $charset $global_rows $usedsize\n";
    $ENV{NLS_LANG} = "American_America.$charset";
}


sub usage()
{
    print "\n";
    print "Usage:\n\nexport_oracle.pl -s SID1[,SID2,...] -p MAX_PROCESS\n";
    print "\n";
    print "To export all databases in /usr/tools/oracle/exptab,\n";
    print "run export_oracle.pl -s exptab -p 5\n\n";
    exit (1);
}

sub show_error()
{
my $subject;
my $mesg_body;

   
    ($subject, @mesg_body) = @_;
    #$mesg_body = "\nError - $_[0].$message\n";
    ##$mesg_body = "Host  - $hostname Error - $message";
    #print "mailto is <$mailto2>";
    #print "subject is <$subject>";
    #print "body is <$mesg_body>";
    $errmsg = &msgfmt("w","`uname -n`","$sid","Export Completed With Error Status");
    &mailit("$errmsg",$log_file);
#   `mailx -s "$subject" $mailto2 <<EOF\n@mesg_body\nEOF\n`;
    exit(0);
}

sub get_exception_value
{

    if (-r $exceptfile)
    {
    
    open(EXCEPTFILE, $exceptfile) || die "Can't Open $parfile. $!";
    while (<EXCEPTFILE>)
    {

       next unless (/^EXPORT:/ && /$sid:/ );
       {
          ($opt, $sid, $yn, $direct_export, $rows,$exp_dir,$mailto ) = split(/:/);
          chomp($mailto);
          print "$sid $mailto $rows \n";
       }
    }
    close(EXCEPTFILE);
    }
}

