#!/oracle/product/perl
#!/usr/local/bin/perl
#---------------------------------------------------------------------------------------------------
# SCCS INFO : rbs_tmp_monitor.pl [1.9] 10/14/02 21:35:46
# FILE INFO : rbs_tmp_monitor.pl
# CREATED   : ckarthik
# DATE      : 07/02/2000
# DESC      : Captures those session occupied more than the THRESHOLD with sql, explain plan. 
#---------------------------------------------------------------------------------------------------

require "ctime.pl";
#use lib '/oracle/product/perlmods/clnt9/lib';
#use lib '/usr/cisco/packages/oracle/current/Perlmod/lib';
#use      DBI;
use      Getopt::Std;
use      Time::Local;

require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;
&StdDBPackage::which_lib();


$DeBug      = 0;
$Send       = 0;
chomp($Host = `/bin/uname -n`);
$MailList   = 'ckarthik@cisco.com';
$PageList   = '';

$RbsSizeMb  = 1000;  
$TmpSizeMb  = 500;  

$RbsPageMb  = 0;  
$TmpPageMb  = 0;  

$PageRbsCtr = 0;
$PageTmpCtr = 0;

getopt('smprtex');

$SID        = "\U$opt_s\E" if defined($opt_s) || &Usage;
$MailTo     = $opt_m if defined($opt_m);
$PageTo     = $opt_p if defined($opt_p);
$RbsSizeMb  = $opt_r if defined($opt_r);
$TmpSizeMb  = $opt_t if defined($opt_t);
$RbsPageMb  = $opt_e if defined($opt_e);
$TmpPageMb  = $opt_x if defined($opt_x);

$LogFile    = "/tmp/${SID}_rbs_tmp_monitor.txt";
open(FP, ">${LogFile}") || &Mail_Error("Can not open logfile. $!");

&Set_Env($SID);

#$Dbh = DBI->connect("dbi:Oracle:", "", "") || &Mail_Error($DBI::errstr);
$Dbh = DBI->connect("dbi:Oracle:", "", "") ||  die "Error. $DBI::errstr";

#----------------------------------------------------------------------------------------------------------------
# Check total Used undo/Temp space before checking session level
# If total used undo/temp is over 70% then only script need to check session level thresholds and send email/page.
# If total used undo/temp is less than 70% then exit out without checking session level details.
#----------------------------------------------------------------------------------------------------------------
my $touch = 1 ;

## Check used space for temp segment
my $temp_used_percentage = &Get_Temp_Usage_Percentage;
if ( $temp_used_percentage > 70 ) {
   &Get_Temp_Usage_Session;
   $touch = 0 ;
}

#Check used space for rbs segment
my $undo_used_percentage = &Get_Undo_Usage_Percentage;
if ( $undo_used_percentage > 70 ) {
   &Get_Rbs_Usage_Session;
   $touch = 0 ;
}
 
sub Get_Undo_Usage_Percentage {
  
  my $tbspace= $Dbh->selectrow_array('select value from v$parameter where name=?', undef, 'undo_tablespace');

  #Get total undo space
  my $total_undo_space = $Dbh->selectrow_array('select sum(bytes)/1024/1024 from dba_data_files where tablespace_name =?', undef, $tbspace ); 
  my $db_version = `ls $ENV{'ORACLE_HOME'}/lib/libserver* | head -1 `;
  ($version) = ($db_version =~ /.*libserver(.*?)\./igsm);

  if ( $version < 10 ){
     $exp_space = $Dbh->selectrow_array("select nvl(ltrim(round(sum(bytes)/1024/1024)),0) from dba_undo_extents where status='EXPIRED' and tablespace_name=?",undef,$tbspace );
     $free_space = $Dbh->selectrow_array("select nvl(ltrim(round(sum(bytes)/1024/1024)),0) FSUM from dba_free_space where tablespace_name=?",undef,$tbspace); 
     $undo_usedspace = $total_undo_space - ($exp_space + $free_space);
  }else{
     $undo_usedspace = $Dbh->selectrow_array("select trim(round(nvl(sum(bytes),0)/1024/1024)) from dba_undo_extents where tablespace_name=? and status in ('ACTIVE','UNEXPIRED')", undef, $tbspace);
  }

  #Calculate percentage of usage
  my $undo_used_percentage = sprintf("%d",($undo_usedspace/$total_undo_space)*100);

  return $undo_used_percentage;
}

sub Get_Temp_Usage_Percentage {
  my $tempSth = $Dbh->prepare('select trim(ROUND(100-((1-(USD/TOT))*100)))
       from (
          select tf.tablespace_name space,tf.total tot,nvl(tu.used,0) usd
          from (select tablespace_name,round(sum(bytes)/1048576) total
                from dba_temp_files
                group by tablespace_name) tf,
                (select tablespace, round(sum(s.blocks*t.block_size)/1048576,2) used
                 from v$sort_usage s,dba_tablespaces t
                 where s.tablespace=t.tablespace_name
                 group by tablespace) tu
          where tf.tablespace_name=tu.tablespace )') || die "error !$ \n";
  $tempSth->execute || die "error in execute \n";
  my @Tdata = $tempSth->fetchrow_array;
  $temp_usedspace = $Tdata[0];
  $tempSth->finish;

  return $temp_usedspace;
}

$Dbh->disconnect;

close(FP);

## Exit if rbs/temp used space is not over 70%. No need to check session level details and send page/email
print "No need to check session level. Used space is not more than 70% \nUndo space used : $undo_used_percentage\%\nTemp space used : $temp_used_percentage\%\n" if $touch ;
exit (1) if $touch;

&Mail_It("$SID on $Host: Rollback/Temporary segments Occupied more than $RbsSizeMb/$TmpSizeMb MB", $LogFile) if ($Send); 

&Page_It("$SID on $Host: $PageRbsCtr Session/s Occupied more than $RbsPageMb MB Rollback segment.") if ($RbsPageMb > 0 && $PageRbsCtr > 0 ); 

&Page_It("$SID on $Host: $PageTmpCtr Session/s Occupied more than $TmpPageMb MB Temp segment.") if ($TmpPageMb > 0 && $PageTmpCtr > 0 ); 

exit (0);

#---------------------------------------------------------------------------------------------------
# SUB Get_Rbs_Usage_Session
#---------------------------------------------------------------------------------------------------
sub Get_Rbs_Usage_Session {

    $Stmt1 = qq{ SELECT rn.name, ROUND(rs.rssize/1024/1024), 
                        s.username, s.osuser, s.sid, NVL(s.machine,'N/A'), 
                        NVL(s.module,'N/A'), NVL(s.action,'N/A'), NVL(s.program,'N/A'), 
                        s.sql_address, s.sql_hash_value, p.spid,
                        s.status ||' for '||
                        LPAD(((last_call_et/60)-mod((last_call_et/60),60))/60,2,'0') ||':'||
                        LPAD(ROUND(mod((last_call_et/60),60)),2,'0') ||' Hr' ,
			round(ceil((t.used_ublk*8)/1024),1)
                 FROM   v\$rollname rn, v\$rollstat rs, 
                        v\$session s, v\$transaction t, v\$process p
                 WHERE  rn.usn = rs.usn
                 AND    round((t.used_ublk*8)/1024) >= $RbsSizeMb
                 AND    rs.usn = t.xidusn
                 AND    s.sid = p.pid (+)
                 AND    s.taddr = t.addr
                 AND    s.sid not in (select sid from ops\$oracle.ignore_monitor where category = 'UNDO') 
                 ORDER  BY 2 desc, s.sid ,s.status };

    $Sth1 = $Dbh->prepare($Stmt1) || &Mail_Error($DBI::errstr) ;
    $Sth1->execute;

    $Stmt2 = qq{ SELECT sql_text
                 FROM   v\$sqltext 
                 WHERE  address  =  ?
                 AND    hash_value = ? 
                 ORDER  BY piece };

    $Sth2 = $Dbh->prepare($Stmt2) || &Mail_Error($DBI::errstr) ;


    $Stmt4 = q{ SELECT  RTRIM(LPAD(' ',1*LEVEL) || RTRIM(operation) ||' '||
                        RTRIM(options) || ' '|| object_name) query_plan,
                        LTRIM(to_char(cost,'9,999,999')),
                        LTRIM(to_char(cardinality,'999,999,999'))
                FROM    plan_table
                START   WITH id = 0
                AND     statement_id = ?
                CONNECT BY PRIOR id = parent_id
                AND     statement_id = ?  };

    #$Sth4 = $Dbh->prepare($Stmt4) || &Mail_Error($DBI::errstr) ;


    $Rcnt = 0;
    while( ($Rbs, $Size, $OraUsr, $OsUsr, $Sid, $Machine, $Module, $Action, 
            $Program, $SqlAddr, $HashVal, $Spid, $Status, $UsedSize) = $Sth1->fetchrow_array ) {

       $St = "Rollback segments Occupied more than $RbsSizeMb Mb in $SID";

       if ( ++$Rcnt == 1 ) {
          print     "\n", "="x80, "\n\t\t$St\n", "=" x 80, "\n\n\n" ;
          print FP  "\n", "="x80, "\n\t\t$St\n", "=" x 80, "\n\n\n" ;
       }

       $i = length($Rcnt);
       $i = 3-$i;

       print    "${Rcnt}.", " "x$i, "Sid           : $Sid\n";
       print FP "${Rcnt}.", " "x$i, "Sid           : $Sid\n";
       print    "Oracle User       : $OraUsr\n";
       print FP "Oracle User       : $OraUsr\n";
       print    "OS User           : $OsUsr\n";
       print FP "OS User           : $OsUsr\n";
       print    "Machine           : $Machine\n";
       print FP "Machine           : $Machine\n";
       print    "Program           : $Program\n";
       print FP "Program           : $Program\n";
       print    "Module            : $Module\n";
       print FP "Module            : $Module\n";
       print    "Action            : $Action\n";
       print FP "Action            : $Action\n";
       print    "Session Status    : $Status \n";
       print FP "Session Status    : $Status \n";
       print    "Rollback Segment  : $Rbs (Current Size $Size MB)\n";
       print FP "Rollback Segment  : $Rbs (Current Size $Size MB)\n";
       print    "Rollback Occupied : $UsedSize MB\n";
       print FP "Rollback Occupied : $UsedSize MB\n";
       print    "SQL Text          : ";
       print FP "SQL Text          : ";

       $PageRbsCtr++ if ($UsedSize > $RbsPageMb && $RbsPageMb > 0 );

       $Sth2->execute( $SqlAddr, $HashVal);
 
       $SqnCnt = 0;
       $FullSql = "";

       while ($Txt = $Sth2->fetchrow_array) {
          if ( ++$SqnCnt == 1 ) {
             print    "\n" ;
             print FP "\n" ;
          }
          print    "\n$Txt" ;
          print FP "\n$Txt" ;

          $FullSql .= $Txt;
       }

       if ( $SqnCnt == 0 ) {
          print    "N/A\n" ;
          print FP "N/A\n" ;
       }

       print    "\n" ;
       print FP "\n" ;

#       &Explain($FullSql) if ($FullSql);

       print    "\n" ;
       print FP "\n" ;


   }
   if ($Rcnt > 0) {
      print    "\n","-"x21," End 0f Rollback Segment Usage Report ","-"x21,"\n\n\n";
      print FP "\n","-"x21," End 0f Rollback Segment Usage Report ","-"x21,"\n\n\n";
      $Send = 1; 
   }

   $Sth1->finish;
   $Sth2->finish;
   #$Sth4->finish;

}

#---------------------------------------------------------------------------------------------------
# SUB Get_Temp_Usage_Session
#---------------------------------------------------------------------------------------------------
sub Get_Temp_Usage_Session {

    $Stmt2 = qq{ SELECT sql_text
                 FROM   v\$sqltext 
                 WHERE  address  =  ?
                 AND    hash_value = ? 
                 ORDER  BY piece };

    $Sth2 = $Dbh->prepare($Stmt2) || &Mail_Error($DBI::errstr);

    $Stmt3 = qq{ SELECT  /*+ RULE */
                         s.username, s.osuser, s.sid, NVL(s.machine,'N/A'), 
                         NVL(s.module,'N/A'), NVL(s.action,'N/A'), NVL(s.program,'N/A'), 
                         s.status ||' for '||
                         LPAD(((last_call_et/60)-mod((last_call_et/60),60))/60,2,'0') ||':'||
                         LPAD(ROUND(mod((last_call_et/60),60)),2,'0') ||' Hr' ,
                         u.tablespace, u.contents, u.extents, round((u.blocks*8)/1024), 
                         s.sql_address, s.sql_hash_value
                 FROM    v\$session s, v\$sort_usage u
                 WHERE   s.saddr    = u.session_addr
                 AND     u.contents = 'TEMPORARY'
                 AND     s.audsid != USERENV('sessionid')
                 AND    (u.blocks*8)/1024 >= $TmpSizeMb 
                 AND    s.sid not in (select sid from ops\$oracle.ignore_monitor where category = 'SORT')
                 ORDER   BY 1,2,3,4,5 Desc };


    $Sth3 = $Dbh->prepare($Stmt3) || &Mail_Error($DBI::errstr);
    $Sth3->execute;

    $Stmt4 = q{ SELECT  RTRIM(LPAD(' ',1*LEVEL) || RTRIM(operation) ||' '||
                        RTRIM(options) || ' '|| object_name) query_plan,
                        LTRIM(to_char(cost,'9,999,999')),
                        LTRIM(to_char(cardinality,'999,999,999'))
                FROM    plan_table
                START   WITH id = 0
                AND     statement_id = ?
                CONNECT BY PRIOR id = parent_id
                AND     statement_id = ?  };

    #$Sth4 = $Dbh->prepare($Stmt4) || &Mail_Error($DBI::errstr);

    $Rcnt = 0;

    while( ($OraUsr, $OsUsr, $Sid, $Machine, $Module, $Action, $Program, $Status, $TSpace, 
            $Cont, $Ext, $Size, $SqlAddr, $HashVal ) = $Sth3->fetchrow_array ) {

       $St = "Temporary segments Occupied more than $TmpSizeMb Mb in $SID";

       if (++$Rcnt == 1) {
          print    "\n", "="x80, "\n\t\t$St\n", "=" x 80 , "\n\n\n" ;
          print FP "\n", "="x80, "\n\t\t$St\n", "=" x 80 , "\n\n\n" ;
       }

       $PageTmpCtr++ if ($Size > $TmpPageMb && $TmpPageMb > 0 );

       $i = length($Rcnt);
       $i = 3-$i;

       print    "${Rcnt}.", " "x$i, "Sid           : $Sid\n";
       print FP "${Rcnt}.", " "x$i, "Sid           : $Sid\n";
       print    "Oracle User       : $OraUsr\n";
       print FP "Oracle User       : $OraUsr\n";
       print    "OS User           : $OsUsr\n";
       print FP "OS User           : $OsUsr\n";
       print    "Machine           : $Machine\n";
       print FP "Machine           : $Machine\n";
       print    "Program           : $Program\n";
       print FP "Program           : $Program\n";
       print    "Module            : $Module\n";
       print FP "Module            : $Module\n";
       print    "Action            : $Action\n";
       print FP "Action            : $Action\n";
       print    "Session Status    : $Status \n";
       print FP "Session Status    : $Status \n";
       print    "Tablespace        : $TSpace\n";
       print FP "Tablespace        : $TSpace\n";
       print    "Temp Segment Used : $Size MB\n";
       print FP "Temp Segment Used : $Size MB\n";
       print    "Used Extents      : $Ext\n";
       print FP "Used Extents      : $Ext\n";
       print    "Content           : $Cont\n";
       print FP "Content           : $Cont\n";
       print    "SQL Text          : ";
       print FP "SQL Text          : ";


       $Sth2->execute( $SqlAddr, $HashVal);
 
       $SqnCnt = 0;
       $FullSql = "";

       while ($Txt = $Sth2->fetchrow_array) {
          if ( ++$SqnCnt == 1 ) {
             print    "\n" ;
             print FP "\n" ;
          }

          print    "\n$Txt" ;
          print FP "\n$Txt" ;

          $FullSql .= $Txt;
       }

       if ( $SqnCnt == 0 ) {
          print    "N/A\n" ;
          print FP "N/A\n" ;
       }

       print    "\n" ;
       print FP "\n" ;

#       &Explain($FullSql) if ($FullSql);

       print    "\n" ;
       print FP "\n" ;

   }

   if ($Rcnt > 0) {
      $Send = 1; 
      print    "\n","-"x23," End 0f Temp Segment Usage Report ","-"x23,"\n\n\n";
      print FP "\n","-"x23," End 0f Temp Segment Usage Report ","-"x23,"\n\n\n";
   }

   $Sth2->finish;
   $Sth3->finish;
   #$Sth4->finish;
}


#-------------------------------------------------------------------------------
# SUB Explain
#-------------------------------------------------------------------------------
sub Explain {

   $ExpTxt = $_[0];
   $ExpUsr = $OUsr ;

   return if ( ($ExpTxt =~ /declare/i) ||
               ($ExpTxt =~ /cursor/i ) ||
               ($ExpTxt =~ /insert/i ) ||
               ($ExpTxt =~ /rollback/i ) ||
               ($ExpTxt =~ /begin/i  ) );

   $ExpUsr = "APPS" if ($ExpUsr eq ""               ||
                        $ExpUsr eq "SYS"            ||
                        $ExpUsr eq "APPS_READ_ONLY" );

   $ExpTxt =~ s/ WHERE /\nWHERE /gi ;
   $ExpTxt =~ s/ FROM /\nFROM /gi ;
   $ExpTxt =~ s/ AND /\nAND /gi ;
   $ExpTxt =~ s/ TO_NUMBER/\nTO_NUMBER/gi ;
   $ExpTxt =~ s/ TO_CHAR/\nTO_CHAR/gi ;
   $ExpTxt =~ s/ EXISTS/\nEXISTS/gi ;
   $ExpTxt =~ s/ ADD_MONTHS/\nADD_MONTHS/gi ;
   $ExpTxt =~ s/ DECODE/\nDECODE/gi ;
   $ExpTxt =~ s/ TRUNC/\nTRUNC/gi ;
   $ExpTxt =~ s/ ORDER /\nORDER /gi ;
   $ExpTxt =~ s/ GROUP /\nGROUP /gi ;
   $ExpTxt =~ s/(\W+)DECODE\W+\(/\1\nDECODE(/gi ;
   $ExpTxt =~ s/ UNION /\nUNION /gi ;

   $r=$Dbh->do("DELETE FROM plan_table WHERE statement_id = \'exp2rbs\'") ;

   $ExpTxt = "EXPLAIN PLAN SET STATEMENT_ID \'exp2rbs\' FOR $ExpTxt";

   $r=$Dbh->do("alter session set current_schema = $ExpUsr");
   $r=$Dbh->do("$ExpTxt") || return;
   $r=$Dbh->do('alter session set current_schema = OPS$ORACLE');

   printf FP "\n\n%-58s %9s %11s\n","QUERY_PLAN", "COST","ROWS";
   printf    "\n\n%-58s %9s %11s\n","QUERY_PLAN", "COST","ROWS";
   printf FP "%-58s %9s %11s\n","-"x58, "-"x9,"-"x11;
   printf    "%-58s %9s %11s\n","-"x58, "-"x9,"-"x11;

   $Sth4->execute('exp2rbs','exp2rbs') ;

   while(($QryPln, $Cost, $Rows) = $Sth4->fetchrow_array) {
      printf    "%-58s %9s %11s\n",$QryPln, $Cost,$Rows;
      printf FP "%-58s %9s %11s\n",$QryPln, $Cost,$Rows;
   }

   print    "\n";
   print FP "\n";

}

#---------------------------------------------------------------------------------------------------
# SUB Set_Env ---> Sets  ORACLE_HOME based on /etc/oratab
#---------------------------------------------------------------------------------------------------
sub Set_Env {

    $NotFound = 1;
    open(ORATAB, "/etc/oratab") || &Mail_Error("Can't Open /etc/oratab");
    while (<ORATAB>) {

       if (/^${SID}:/) {
          $ENV{'ORACLE_HOME'} = (split(':'))[1];
          $ENV{'ORACLE_SID'}  = $SID;
          $NotFound = 0;
       }
    }
    close(ORATAB);
    &Mail_Error("$SID not found in /etc/oratab") if ($NotFound);
}

#---------------------------------------------------------------------------------------------------
# SUB Mail_It
#---------------------------------------------------------------------------------------------------
sub Mail_It {

    @MailTemp = split(',',$MailTo);

    for ($i = 0; $i <= $#MailTemp; $i++) {
      $MailTemp[$i]=$MailTemp[$i].'@cisco.com' if (!($MailTemp[$i] =~ /cisco/));
    }
    $MailTo =join(',',@MailTemp);

    open (MAIL, "|/usr/bin/mailx -s \"$_[0]\"  $MailTo < $_[1]");
    close (MAIL);
    print "";
}

#---------------------------------------------------------------------------------------------------
# SUB Page_It
#---------------------------------------------------------------------------------------------------
sub Page_It {

    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");

    if (!defined($pageexe)) {

       print("rbs_tmp_monitor.pl on $Host: epage/pageme executable ".
             "not found. Aborting...");
        exit (1);
    }

    my @pagemsg = @_;

    while ($pagemsg = pop(@pagemsg)) {

        foreach $page (split /,/, $PageTo) {
            `$pageexe $page \'$pagemsg\'`;
        }
    }
}

#---------------------------------------------------------------------------------------------------
# SUB Usage
#---------------------------------------------------------------------------------------------------
sub Usage {

    print "$_[0]";
    print "\n","-"x80,"\nUsage:$0 -s <SID> -r RbsMb -e RbsPageMb ".
          "-t TmpMb -x TmpPageMb -m MailId -p PagerId\n", "-"x80,"\n\n";
    exit (1);
}

#---------------------------------------------------------------------------------------------------
# SUB Mail_Error
#---------------------------------------------------------------------------------------------------
sub Mail_Error {

    print "Error : $0 on $Host : $_[0]" ;
    print FP "Error : $0 on $Host : $_[0]" ;
    &Mail_It("Error : $0 on $Host : $_[0]", "/dev/null");
    exit (1);
}

#---------------------------------------------------------------------------------------------------
# **** End of perl script 
#---------------------------------------------------------------------------------------------------

