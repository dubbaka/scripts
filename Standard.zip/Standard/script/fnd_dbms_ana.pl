#!/usr/local/bin/perl

###!/usr/local/perl5.6.1/bin/perl

#######################################################################################
#
# Filename: analyze_dbms.pl
#
# Purpose: To analyze all objects in relavent schemas in the database,
#          to be called regularly from cron to keep statistics up to date.
#  		The algorith/theory behind this program is that analyze done on
#		a table only needs to be grossly estimated , but analyze on
#		an index needs a complete 'compute' analysis.
#		Therefore, a quick analyze table is done for everything, and
#		then a complete analysis for each index is done next.
#
# Author: David Novice, Cisco Systems, Jan 20, 1997
#
# Syntax: $0 [sid]
#
# Comments: This program is called by analyze_database.pl 
#
#######################################################################################

use Getopt::Std;
use POSIX;
require "ctime.pl";

##################  STD Compliance     ##########################
#  Pl add this piece of code in all Std Scripts at the beginning  
#  before staring any operations
#
require "/usr/tools/oracle/Standard/script/lib/perllib.pl";
use lib "/usr/tools/oracle/Standard/script/lib/";
use StdDBPackage;
&StdDBPackage::which_lib();                                  
#
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!             
$thisScriptName="check_extents_all.pl";  # << Change this to standard script name
#
$stddate=`date -u +%Y%m%d`; chomp($stddate);
$stdlogfile="${thisScriptName}_${stddate}";
$stdlibpath="/usr/tools/oracle/Standard/lib";
$stdpidval="$$";
$actscriptname="$0";
$stdjobseq="${stddate}-${stdpidval}";
$stdcksum=`/oracle/product/perl $stdlibpath/StdCompProc.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname`;
if ( $stdcksum =~ "FAILED" ) {
        print "$actscriptname is not same as standard script $thisScriptName\nExiting..\n";
       exit 1;
} elsif ( $stdcksum =~ "SUCCESS" ) {
        print "$actscriptname matching checksum with standard script $thisScriptName..Continuing..\n";
} elsif ( $stdcksum =~ "NOT_FOR_LINUX" ) {
        print "$actscriptname is NOT valid for Linux server..\nExiting..\n";
       exit 1;
} else {
        print "$actscriptname is unable checksum with standard script $thisScriptName\nExiting..\n";
       exit 1;
}
###################################################################

select(STDERR); $| = 1;
select(STDOUT); $| = 1;

    &init_fn();

##################  STD Compliance     ##########################
# If the script is used for all the database in this server
# like check_extend_all.pl, put this piece of code inside the loop
# for each databases using ORATAB.  Change the value for
# the variable "$mysid" to actual variable for each database
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
$stdsid="$oracle_sid";  # << Change "$sid" to actual variable
system("/oracle/product/perl $stdlibpath/StdCompProc.pl begin_eachjob $stdjobseq $stdsid $stdlogfile");
###############################################################

    $start_time=time;
    $stime = &get_time("HH:MI:SS", $start_time);
if ($ana_type eq 'DBMS')
       {
 $analyze_stmt = qq{ begin DBMS_STATS.GATHER_TABLE_STATS (ownname => ?, tabname => ?, estimate_percent => ?, block_sample => TRUE, degree => ?, method_opt => 'FOR ALL COLUMNS SIZE 1', granularity => 'ALL', cascade => TRUE); end; };
       } else
       {
       print "Inside FND \n";
 $analyze_stmt = qq{ begin FND_STATS.GATHER_TABLE_STATS (ownname => ?, tabname => ?, percent => ?, degree => ?, granularity => 'ALL', cascade => TRUE); end; };
       }

#    my $analyze_stmt = qq{ begin FND_STATS.GATHER_TABLE_STATS (ownname => ?, tabname => ?, percent => ?, degree => ?, granularity => 'ALL', cascade => TRUE); end; };
    $sth = $dbh->prepare("$analyze_stmt") || warn("Prepare failed for $analyze_stmt. $DBI::errstr");

    #$ttable = "\"".${ttable}."\"";
 #   $ttable = "\'".${ttable}."\'";
    $sth->bind_param(1, $towner);
    $sth->bind_param(2, $ttable);
    $sth->bind_param(3, $sample_size, {TYPE=>SQL_INTEGER});
    $sth->bind_param(4, $degree, {TYPE=>SQL_INTEGER});
    $sth->execute; 

    # Error handling
    $error_num = $dbh->err();
    if ($error_num == 1401) {
        print "Erroring Analyze $analyze_stmt and values are $towner,$ttable,$sample_size,$degree \n";
       }
    # For parallel server problems, redo with degree=1
    if (($error_num == 12805) || ($error_num == 12801))  {
       $sth->finish;
       print "+++ PARALLEL QUERY SERVER PROBLEM --- $towner , $ttable \n";

       $start_time=time;
       $stime = &get_time("HH:MI:SS", $start_time);

       $degree = 1;
#    my $analyze_stmt = qq{ begin FND_STATS.GATHER_TABLE_STATS (ownname => ?, tabname => ?, estimate_percent => ?, degree => ?, granularity => 'ALL', cascade => TRUE); end; };

       $sth = $dbh->prepare("$analyze_stmt") || warn("Prepare failed for $analyze_stmt. $DBI::errstr");
       $sth->execute || warn("Execute failed for $analyze_stmt. $DBI::errstr");
       $sth->finish;
    }  elsif ($error_num == 3113) {
       $sth->finish;
       print "+++ END-OF-FILE on COMMUNICATION PROBLEM --- $towner , $ttable , $degree \n";

       $start_time=time;
       $stime = &get_time("HH:MI:SS", $start_time);

#       $analyze_stmt = "begin DBMS_STATS.GATHER_TABLE_STATS (ownname => '$towner', tabname => '\"$ttable\"', estimate_percent => $sample_size, block_sample => TRUE, degree => $degree, method_opt => 'FOR ALL COLUMNS SIZE 1', granularity => 'ALL', cascade => TRUE); end; ";

       $sth = $dbh->prepare("$analyze_stmt") || warn("Prepare failed for $analyze_stmt. $DBI::errstr");
       $sth->execute || warn("Execute failed for $analyze_stmt. $DBI::errstr");
       $sth->finish;
    }  else  {
       $sth->finish;
    }

    $end_time=time;
    $etime = &get_time("HH:MI:SS", $end_time);
    $duration = ($end_time - $start_time);
    $str1 = sprintf "%-55s       %s  %s %s\n", 
       ${towner}.".".${ttable}."__".${mbytes}." MB",
       $stime, 
       $etime,
       &print_time($duration);
    if ($duration > 900)  {
       open(LOGFILE, ">>$log_file") || warn "Cannot open log file. $!";
       print LOGFILE "$str1";
       close(LOGFILE);
    }
    #push(@logstr, $str1);
    #&log_message($str1);

    $dbh->disconnect;

##################  STD Compliance     ##########################
# Place this piece of code at the end of LOOP job for each database.
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_eachjob $stdjobseq $stdsid $stdlogfile");
###############################################################

##################  STD Compliance     ##########################
########  Pl add this piece of code in all Std Scripts ########
#     after completion of the script and before exit  #########
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_alljob $stdjobseq $stdsid $stdlogfile");
###############################################################

    exit(0);


################################################################
# SUBROUTINES
################################################################

sub init_fn
{

    $usage = <<EOFEOF;

Usage:  
    $0 [-help] -s sid -o table_owner -t table -z sample_size -d degree -m mbytes -l log_file

Description:

    This program analyzes database objects (tables and indexes) of 
    specified users(s). This program uses compute option to 
    get statistics for indexes and estimate option for tables.

Note :
    The Oracle userid must have access to analyze the tables.
    OPS\$ORACLE account should exist. Should be run by Oracle user.

EOFEOF

    #get command line options
    &getopt('hdostzmla');
    if ($opt_h)
    {
        print $usage;
        exit(0);
    }

    $oracle_sid     = $opt_s ? $opt_s : "";
    $towner         = $opt_o ? $opt_o : "";
    $ttable         = $opt_t ? $opt_t : "";
    $sample_size    = $opt_z ? $opt_z : "";
    $degree         = $opt_d ? $opt_d : "";
    $mbytes         = $opt_m ? $opt_m : "";
    $log_file       = $opt_l ? $opt_l : "";
    $ana_type       = $opt_a ? $opt_a : "";
    
    print "Oracle_sid        = $oracle_sid\n";
    print "Table_owner       = $towner\n";
    ##print "Table             = $ttable\n";
    ##print "Sample_size       = $sample_size\n";
    ##print "Degree            = $degree\n";

    if (!defined($oracle_sid) || $oracle_sid eq "")
    {
        printf "SID is not given.\n";
##      &show_error("SID is not given");
    }
    if (!defined($sample_size) || $sample_size < 0 || $sample_size > 100)
    {
        printf "Estimate - $sample_size : Value is not given or invalid.\n";
##      &show_error("Estimate - $sample_size : Value is not given or invalid.");
    }

    &get_ora_home($oracle_sid);
    $dbh = DBI->connect("DBI:Oracle:", '', '',{ ora_session_mode=>2})||
        &show_error("Cannot login to $oracle_sid. $DBI::errstr");
    
    $r=$dbh->do('alter session set current_schema = OPS$ORACLE');
    #$r=$dbh->do(q{alter session set "_optim_adjust_for_part_skews"=false  });
    #$r=$dbh->do(q{alter session set events '38019 trace name context forever, level 1' });

    $sample_size = $sample_size + 0;
    $degree = $degree + 0;

}

sub print_time()
{
use integer;

my $hours, $minutes, $seconds, $time_duration;

    $time_duration = $_[0];
    $hours = $time_duration / 3600;
    $seconds = $time_duration % 60;
    $minutes = ($time_duration % 3600) / 60;
    $ret_string = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);;
    return($ret_string);
}

sub numerically
{
    $a <=> $b;
}
log_file
