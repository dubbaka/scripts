#!/oracle/product/perl

#
# Name    : rbs_tmp_all.pl
#
# swei   05-apr-2004 created
#			default rollback 1000m; temp 500m
#
###############################################################################


require "ctime.pl";
use      Getopt::Std;
use      Time::Local;

require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


$parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
$exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";
chomp($host = `/bin/uname -n`);


$DeBug     = 0;


chomp($Host = `/bin/uname -n`);
&Get_Page_Exe;

 
open (ALLTAB,"/var/opt/oracle/oratab") || &show_error("Can't Open oratab", "$!");
while (<ALLTAB>)
{
    next if (/^#/ || /^\s/);
    ($sid, $ora_home, $db_flag) = split(/:/);
    print "$sid $db_flag \n";
    next if ($db_flag =~ /^N/ || $db_flag =~ /^n/ );


	$LogFile   = "/tmp/rbs_tmp_$sid.log";
	$RbsSizeMb  = 1000;  
	$TmpSizeMb  = 500;  
	$mailto = "mis-dba";
	$pageto = "dba-duty";
    ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($sid);


open(FP, ">${LogFile}") || die "Can not open logfile. $!\n";

$Oracle_Sid        = $sid;

&Get_Ora_Home($Oracle_Sid);

if ($DeBug) {

   print "\nSid         : $Sid"         ;
   print "\nOracle_Sid  : $Oracle_Sid"  ;
   print "\nOracle_Home : $Oracle_Home" ;
   print "\nLogFile     : $LogFile"     ;
   print "\nMailTo      : $MailTo"      ;
   print "\nPageTo      : $PageTo\n"    ;
}
    
$Dbh = DBI->connect("dbi:Oracle:", "", "") || next;

$Stmt1 = qq{ SELECT rn.name, rs.rssize/1024/1024, rs.xacts, rs.extents,
                    s.username, s.osuser, s.sid, s.serial#, s.process, 
                    s.program, s.sql_address, s.sql_hash_value, p.spid
             FROM   v\$rollname rn, v\$rollstat rs, 
                    v\$session s, v\$transaction t, v\$process p
             WHERE  rn.usn = rs.usn
             AND    rs.rssize/1024/1024 >= $RbsSizeMb
             AND    rs.usn = t.xidusn
             AND    s.sid = p.pid
             AND    s.taddr = t.addr
             ORDER  BY rn.name, s.sid };

$Sth1 = $Dbh->prepare($Stmt1) || warn $Dbh->errstr;
$Sth1->execute;

$Stmt2 = qq{ SELECT sql_text
             FROM   v\$sqltext 
             WHERE  address  =  ?
             AND    hash_value = ? 
             ORDER  BY piece };

$Sth2 = $Dbh->prepare($Stmt2) || warn $Dbh->errstr;


$Send = 0; 
$Rcnt = 0;
while( ($Rbs, $Size, $Tx, $Ext,$OraUsr, $OsUsr,$Sid, $Serial, 
        $Upid, $Program, $SqlAddr, $HashVal, $Spid) = $Sth1->fetchrow_array ) {

     $Send = 1; 
     $St = "Rollback segments Occupied more than $RbsSizeMb Mb in ".
	   "$Oracle_Sid";

     if ($Rcnt++ == 0) {
        print     "\n","*"x80,"\n\n          $St\n", "*" x 80 , "\n\n\n" ;
        printf FP "\n","*"x80,"\n\n          $St\n", "*" x 80 , "\n\n\n" ;
     }

     print  FP "-"x80,
               "\nRbs    SizeM   #Tx  Exts  Ora_User     Os_User    ",
               "Sid    Serial# Spid  UsrPid\n", "-"x80, "\n";
     printf FP "%-6s %5d %5d %5d  %-12s %-10s %-6d %-7d %-7d %-7d\n\n", $Rbs, 
               $Size, $Tx, $Ext, $OraUsr, $OsUsr, $Sid, $Serial, $Spid, $Upid;

     print  "-"x80,
            "\nRbs    SizeM   #Tx  Exts  Ora_User     Os_User    ",
            "Sid    Serial# Spid  UsrPid\n", "-"x80, "\n";
     printf "%-6s %5d %5d %5d  %-12s %-10s %-6d %-7d %-7d %-7d\n\n", $Rbs, 
             $Size, $Tx, $Ext, $OraUsr, $OsUsr, $Sid, $Serial, $Spid, $Upid;


     $Sth2->execute( $SqlAddr, $HashVal);

     while ($Txt = $Sth2->fetchrow_array) {
        print "$Txt\n" ;
        print FP "$Txt\n" ;
     }

     print "\n\n\n" ;
     print FP "\n\n\n" ;
}

$Sth1->finish;

$Stmt3 = qq{ SELECT  /*+ RULE */
	             s.username             ,
	             s.sid                  ,
	             u.tablespace  tspace   ,
	             u.contents             ,
	             u.extents              ,
	             (u.blocks*8)/1024 ||' M' , 
	             SUBSTR(s.status,1,3) ||' '||
	             LPAD(((s.last_call_et/60)-
			mod((s.last_call_et/60),60))/60,2,'0') ||':'||
		     LPAD(ROUND(mod((s.last_call_et/60),60)),2,'0')||' H' ,
	             s.sql_address          , 
	             s.sql_hash_value
             FROM    v\$session    s       ,
	             v\$sort_usage u
             WHERE   s.saddr    = u.session_addr
             AND     u.contents = 'TEMPORARY'
             AND    (u.blocks*8)/1024 >= $TmpSizeMb 
             ORDER   BY 1,2,3,4,5 Desc };


#$Sth3 = $Dbh->prepare($Stmt3) || warn $Dbh->errstr;
$Sth3 = $Dbh->prepare($Stmt3) || next;
$Sth3->execute;


$Rcnt = 0;

while( ($OraUsr, $Sid, $TSpace, $Cont, $Ext, $Size, $Act, 
	$SqlAddr, $HashVal ) = $Sth3->fetchrow_array ) {

     $Send = 1; 
     $St = "Temporary segments Occupied more than $TmpSizeMb Mb in ".
	   "$Oracle_Sid";

     if ($Rcnt++ == 0) {
        print     "\n","*"x80,"\n\n          $St\n", "*" x 80 , "\n\n\n" ;
        printf FP "\n","*"x80,"\n\n          $St\n", "*" x 80 , "\n\n\n" ;
     }

     print  FP "-"x80,
               "\nOra_User           Sid Tspace     Content       Extent      ",
	       "Size  Status", "\n", "-"x80, "\n";
     printf FP "%-15s %6d %-10s %-12s %7d %9s  %9s\n\n", $OraUsr, 
               $Sid, $TSpace, $Cont, $Ext, $Size , $Act;

     print     "-"x80,
               "\nOra_User           Sid Tspace     Content       Extent      ",
	       "Size  Status", "\n", "-"x80, "\n";
     printf    "%-15s %6d %-10s %-12s %7d %9s  %9s\n\n", $OraUsr, 
               $Sid, $TSpace, $Cont, $Ext, $Size , $Act;


     $Sth2->execute( $SqlAddr, $HashVal);

     while ($Txt = $Sth2->fetchrow_array) {
        print "$Txt\n" ;
        print FP "$Txt\n" ;
     }

     print "\n\n" ;
     print FP "\n\n" ;
}


$Sth3->finish;
$Sth2->finish;

print FP "\n ********** End 0f Reprot **********\n" if ($Rcnt > 0);

$Dbh->disconnect;

close(FP);

    $errmsg = &msgfmt("w","`uname -n`","$sid","Rollback/Temp Segment Monitor Report");
    &mailit("$errmsg",$LogFile) if ($Send);

#&Mail_It("$Oracle_Sid on $Host: Rollback/Temporary segments Occupied more than $RbsSizeMb/$TmpSizeMb Mb", $LogFile) if ($Send); 
}
close(ALLTAB);

#-------------------------------------------------------------------------------
# SUB Get_Ora_Home ---> Sets  ORACLE_HOME based on /etc/oratab
#-------------------------------------------------------------------------------
sub Get_Ora_Home {

    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>) {

       if (/^${Oracle_Sid}:/) {
          $Oracle_Home = (split(':'))[1];
          $ENV{'ORACLE_HOME'} = $Oracle_Home;
          $ENV{'ORACLE_SID'}  = $Oracle_Sid;
        ($oracle7)=&StdDBPackage::check_oracle7($Oracle_Sid);
        ($nls)=&StdDBPackage::check_nls;
        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$Oracle_Home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }

        &StdDBPackage::which_lib();

       }
    }
    close(ORATAB);
}

#-------------------------------------------------------------------------------
# SUB Mail_It
#-------------------------------------------------------------------------------
sub Mail_It {

    @MailTemp = split(',',$MailTo);

    for ($i = 0; $i <= $#MailTemp; $i++) {
      $MailTemp[$i]=$MailTemp[$i].'@cisco.com' if (!($MailTemp[$i] =~ /cisco/));
    }
    $MailTo =join(',',@MailTemp);


    open (MAIL, "|/usr/bin/mailx -s \"$_[0]\"  $MailTo < $_[1]");
    close (MAIL);
    print "";
}

#-------------------------------------------------------------------------------
# SUB Page_It
#-------------------------------------------------------------------------------
sub Page_It {

    my @pagemsg = @_;

    while ($pagemsg = pop(@pagemsg)) {

        foreach $page (split /,/, $PageTo) {
            `$pageexe $page \'$pagemsg\'`;
        }
    }
}

#-------------------------------------------------------------------------------
# SUB Page_It
#-------------------------------------------------------------------------------
sub Usage {

    print "$_[0]";
    print "\n","-"x80,"\nUsage:rbs_tmp_monitor.pl -s <SID> -r RbsSizeMb ".
          "-t TmpSize -m MailId, -p PagerId,\n", "-"x80,"\n\n";
    exit (1);
}

#-------------------------------------------------------------------------------
# SUB Get_Page_Exe
#-------------------------------------------------------------------------------
sub Get_Page_Exe {

    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");

    if (!defined($pageexe)) {

       print("rbs_tmp_monitor.pl on $Host: epage/pageme executable ".
             "not found. Aborting...");
        exit (1);
    }
}

#-------------------------------------------------------------------------------
# SUB Show_Error
#-------------------------------------------------------------------------------
sub Show_Error {

    print "$_[0]. $DBI::errstr\n";
    exit (1);
}


