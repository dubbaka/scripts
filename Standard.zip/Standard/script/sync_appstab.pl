#!/usr/local/bin/perl
#---------------------------------------------------------------------------------------------
# CREATED   : rangajal
# DESC      : to sync appstab with running 11i instances on this node
#		and also add entry on front end nodes of an instance
# Modified : 10/15 - Host:DB-Server has been appened to mail message
# Modified : 10/20 - Ignoring all 10.7 instances
#		   - Ignoring to ssh if front-end and back-end are same (example EMEA dbs)
# Modified : 05/14 - Added logic to handle RAC instance, i.e to build osuser from name:v$database instead of SID
#---------------------------------------------------------------------------------------------

require "ctime.pl";
use lib '/oracle/product/perlmods/clnt964/lib';
use      DBI;
use      Getopt::Std;
use      Time::Local;
use      File::Copy;
use      File::Compare;
use      File::stat;

getopt('m');
$mailto = $opt_m;

$be_server =`uname -a`;
$be_machine=(split(/ /,$be_server))[1];
$Host=$be_machine;

open(LOGFILE, ">/usr/tmp/sync_appstab.log") || die "Cannot open logfile. $!\n";
copy("/var/opt/oracle/appstab","/usr/tmp/appstab.old")||&Log_Exit("Error: $0 on $Host: appstab cannot be copied to /usr/tmp/appstab.old");
copy("/var/opt/oracle/appstab","/usr/tmp/appstab.new")||&Log_Exit("Error: $0 on $Host: appstab cannot be copied to /usr/tmp/appstab.new");

open(ORATAB, "/var/opt/oracle/oratab") ||&Log_Exit("Error: $0 on $Host: Cannot Open /var/opt/oracle/oratab");
open(APPSTAB_NEW, ">>/usr/tmp/appstab.new") ||&Log_Exit("Error: $0 on $Host: Cannot Open /usr/tmp/appstab.new for appending");

while (<ORATAB>)
{
 next if (/^\*/);next if (/^\#/);
 $oracle_home = (split(':'))[1];
 $oracle_sid = (split(':'))[0];
 system("ps -ef |grep smon | grep -i $oracle_sid|grep -v grep >/dev/null")&&next;
 $ENV{'ORACLE_SID'}  = $oracle_sid;
 $ENV{'ORACLE_HOME'} = $oracle_home;
 $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
 $ENV{'SHLIB_PATH'} = "$oracle_home/lib";

 $oracle_sid_lower = $oracle_sid;
 $oracle_sid_lower =~ tr/A-Z/a-z/;

 $Dbh = DBI->connect("dbi:Oracle:", "", "") || next ;

#**************************
### Get SID, FE sever, 11i Release Name
#**************************
 $release_11i=0;
 $Stmt0 = qq{select 1 from dba_tables where table_name='FND_USER_RESP_GROUPS'}; 
 $Sth0 = $Dbh->prepare($Stmt0) || &Log_Continue($DBI::errstr) ;
 $Sth0->execute;
 ($release_11i) = $Sth0->fetchrow_array ;
### Skip if not Oracle applications 11i
 next if ($release_11i == 0); 

 $release_name="";
 $Stmt1 = qq{select release_name from apps.fnd_product_groups}; 
 $Sth1 = $Dbh->prepare($Stmt1) || &Log_Continue($DBI::errstr) ;
 $Sth1->execute;
 ($release_name) = $Sth1->fetchrow_array ;

# Skip if still in the process of upgrade
 next if ($release_name =~ /10.7|11.5.0/);

# Build osuser
 $osuser="";
 $Stmt11 = qq{select name from v\$database}; 
 $Sth11 = $Dbh->prepare($Stmt11) || &Log_Continue($DBI::errstr) ;
 $Sth11->execute;
 ($oracle_db) = $Sth11->fetchrow_array ;
 $oracle_db_lower = $oracle_db;
 $oracle_db_lower =~ tr/A-Z/a-z/;
 $osuser="oa".$oracle_db_lower;

 $fe_machine="";

 $Stmt2 = qq{select distinct
          decode(substr(machine,length(machine)-9,10),'.cisco.com', substr(machine,1,instr(machine,'.cisco.com')-1), machine)
          from v\$session where osuser='$osuser'}; 
 $Sth2 = $Dbh->prepare($Stmt2) || &Log_Continue($DBI::errstr) ;
 $Sth2->execute;

#**************************
### For each front end machine of an SID, compare if an entry existing, if not append to appstab.new
#**************************
 $count=0;
 while (($fe_machine) = $Sth2->fetchrow_array ) {

   $found_flag=1;
   $count = $count + 1; 
   $be_appstab="/usr/tmp/appstab.old";
   &find_entry($be_appstab);

   if ($found_flag != 0) {
     $str_to_write="$oracle_db:$osuser:/apps/$oracle_db_lower:$release_name:$fe_machine:$be_machine:Y\n";
     print APPSTAB_NEW "$str_to_write";
   }

   $found_flag=1;
   $fe_appstab="/usr/tmp/appstab.old"."."."$fe_machine";
   $fe_appstab_new="/usr/tmp/appstab.new"."."."$fe_machine";

   unlink("$fe_appstab_new");
   unlink("$fe_appstab");

   if ($fe_machine eq $be_machine) {next;}

   system ("/usr/local/bin/scp -p $osuser\@$fe_machine:/etc/appstab $fe_appstab 2>/dev/null");

   if ( ! -e $fe_appstab ) {
     &Log_Continue("Error: $0 on $Host: cannot ssh or scp appstab from $fe_machine");next;
   } 

   $info=stat($fe_appstab);
   if ( ! ($info->mode & 020) ) { 
     &Log_Continue("Error: $0 on $Host: appstab on $fe_machine is not writable by group-id dba");next;
    }

   copy("$fe_appstab","$fe_appstab_new")||&Log_Continue("Error: $0 on $Host: $fe_appstab  cannot be copied to $fe_appstab_new");
   open(APPSTAB_FE_NEW, ">>$fe_appstab_new")||&Log_Continue("Error: $0 on $Host: Cannot Open $fe_appstab_new for appending");;

   &find_entry($fe_appstab);
   if ($found_flag != 0) {
     $str_to_write="$oracle_db:$osuser:/apps/$oracle_db_lower:$release_name:$fe_machine:$be_machine:Y\n";
     print APPSTAB_FE_NEW "$str_to_write";
   }

   close(APPSTAB_FE_NEW);
   if (compare("$fe_appstab","$fe_appstab_new") != 0) { 
     system ("/usr/local/bin/scp -p $fe_appstab_new $osuser\@$fe_machine:/etc/appstab 2>/dev/null");
     &Log_Continue("Append: $0 on $Host: appstab on host $fe_machine appended with $str_to_write");
   }

   unlink("$fe_appstab_new");
   unlink("$fe_appstab");

 }

# Ignoring for now...
# if ( $count == 0) {&Log_Continue("Info: $0 on $Host: Oracle Apps. not up on any fe-server for this Database");}

}
close(ORATAB);
close(APPSTAB_NEW);

#**************************
### Compare appstab.new with original appstab and overwrite
#**************************
if (compare("/var/opt/oracle/appstab","/usr/tmp/appstab.new") != 0) { 
   copy("/usr/tmp/appstab.new","/var/opt/oracle/appstab");
   `diff /usr/tmp/appstab.old /usr/tmp/appstab.new >/usr/tmp/appstab.diff`;
    open(DIFF,"</usr/tmp/appstab.diff");
    print LOGFILE "****************************************\n";
    print LOGFILE "Info: $0 on $Host: appstab has been appeneded on host $be_machine\n";
    while(<DIFF>) {print LOGFILE "$_\n";}
    print LOGFILE "****************************************\n";
}

close(LOGFILE);

#$info=stat("/usr/tmp/sync_appstab.log");
#if  ( $info->size > 0 ) {
if  ( -s "/usr/tmp/sync_appstab.log" ) {
     &Mail_It("$0 on $Host - Output","/usr/tmp/sync_appstab.log");
#     system("/usr/bin/mailx -s '$0 on $Host - Output' $mailto </usr/tmp/sync_appstab.log");
}

#**************************
### sub find_entry
#**************************
sub find_entry {
#   open(APPSTAB_OLD, "$_[0]") || die "Cannot Open $_[0]";
   open(APPSTAB_OLD, "$_[0]");
   while (<APPSTAB_OLD>) {
     next if (/^\*/);
     next if (/^\#/);
     @at_vals=split(/:/,$_);
     $actual_str="$oracle_db $fe_machine $be_machine";
     $at_str="$at_vals[0] $at_vals[4] $at_vals[5]";
     if ("$actual_str" eq "$at_str") {$found_flag=0;}
   }   
   close(APPSTAB_OLD);
}

#**************************
# SUB Mail_Error
#**************************
sub Mail_Error {
    print    "\n\n$_[0]\n\n" ;
    open (MAIL, "|/usr/bin/mailx -s '$_[0]' $mailto < /dev/null ");close (MAIL);
    exit (1);
}

#**************************
# SUB Mail_It
#**************************
sub Mail_It {
    open (MAIL, "|/usr/bin/mailx -s '$_[0]'  $mailto < $_[1]");
    close (MAIL);
}

#**************************
# SUB Log_Exit
#**************************
sub Log_Exit {
print LOGFILE "$oracle_db - $_[0]\n\n";
exit(2);
}

#**************************
# SUB Log_Continue
#**************************
sub Log_Continue {
print LOGFILE "$oracle_db - $_[0]\n\n";
}
