
1;

$LOCK_SH = 1;
$LOCK_EX = 2;
$LOCK_NB = 4;
$LOCK_UN = 8;

sub get_date()
{
local $fmt, $sec, $min, $hour, $mday, $mon;
local $year, $wday, $yday, $isdst, $date;
local @month = ('JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
                'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC');

    $fmt = $_[0];
    ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
    localtime(time);
    if ($fmt eq "DD-MON-YYYY")
    {
        $year += 1900;
        $date = sprintf( "%02d-%s-%4d", $mday, $month[$mon], $year);
    }
    elsif ($fmt eq "MM-DD-YYYY")
    {
        $mon++;
        $year += 1900;
        $date = sprintf( "%02d-%02d-%4d", $mday, $mon, $year);
    }
    elsif ($fmt eq "YYYY-MM-DD")
    {
        $mon++;
        $year += 1900;
        $date = sprintf( "%04d-%02d-%02d", $year, $mon, $mday);
    }
    elsif ($fmt eq "YYYYMMDD")
    {
        $mon++;
        $year += 1900;
        $date = sprintf( "%04d%02d%02d", $year, $mon, $mday);
    }
    return($date);
}

sub get_time
{
local $fmt, $sec, $min, $hour, $mday, $mon;
local $year, $wday, $yday, $isdst, $date;
local @month = ('JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
                'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC');

    $fmt = $_[0];
    ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
    localtime(time);
    if ($fmt eq "HH:MI:SS")
    {
        $time = sprintf( "%02d:%02d:%02d", $hour, $min, $sec);
    }
    return($time);
}

sub mailit
{
    if ("$_[0]" =~ /^INFO: /)
    {
    open (MAIL, "|mailx -s \"$_[0] - `date` \"  info-dba\@cisco.com < $_[1]");
    close (MAIL);
    }
    else
    {
    open (MAIL, "|mailx -s \"$_[0] - `date` \"  $mailto\@cisco.com < $_[1]");
    close (MAIL);
    }
    print "";
}

sub pageit
{
my @pagemsg = @_;

    &get_pageexe();
    while ($pagemsg = pop(@pagemsg))
    {
        foreach $page (split /,/, $pageto)
        {
            #print "<$pageexe $page \"$pagemsg\">\n";
            `$pageexe $page \"$pagemsg - \`date\` \"`;
        }
    }
}


sub get_pageexe
{
    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");

    if (!defined($pageexe))
    {
        print("epage/pageme executable not found. Aborting...\n");
        exit (1);
    }
}

sub get_ora_home
{
my $sid;

    $sid = $_[0];
    open(ORATAB, "< /etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        ($oracle_sid, $ora_home, $db_flag, $dummy) = split(/:/);
        last if ($sid eq $oracle_sid);
    }
    # Setup environment to run external shell programs
    $ENV{ORACLE_SID} = $sid;
    $ENV{ORACLE_HOME} = $ora_home;
    $ENV{PATH} = "${ora_home}/bin:${PATH}";
    $ENV{LD_LIBRARY_PATH} = "$ora_home/lib:$ENV{LD_LIBRARY_PATH}";
    $ENV{'EPC_DISABLED'} = "TRUE";
}

sub show_error()
{

    close(LOGFILE) if (LOGFILE);
    print "$_[0]. ";
    if (defined($dbh))
    { 
        print "$DBI::errstr\n";
        $rc = $dbh->disconnect;
    }
    exit (1);
}


sub log_message()
{

    open(LOGFILE, ">> $logfile") || die "Can not open log file.";
    #lock();
    print LOGFILE @_;
    #unlock(); 
    close(LOGFILE);
}

sub lock()
{
    flock LOGFILE, $LOCK_EX;
    seek LOGFILE, 0, 2;
}

sub unlock()
{
    flock LOGFILE, $LOCK_UN;
}

sub sendmail()
{
my ($subject, $msgfile, $fromemail, $fromname, $toemail, $toname, $ccemail1, $ccname1, $ccemail2, $ccname2 ) = @_;

    $fromemail =~ s/[^\w\-\@\.\_]//g;
    open MAIL, "|/usr/lib/sendmail -OIgnoreDots -t '$toemail' 2>/dev/null" || die;
    print MAIL "From: $fromname \<$fromemail\>\n";
    print MAIL "To:$toname \<$toemail\>\n";
    if ($ccemail1 ne '')
    {
        $ccstr = "$ccemail1";
        if ($ccemail2 ne '') { $ccstr .= ",$ccemail2"; }
        print MAIL "Cc: $ccstr\n";
    }
    print MAIL "Reply-To:dba-oncall-taskforce\@cisco.com\n";
    print MAIL "Subject: $subject\n\n";
    open(MSG, $msgfile) || die "Cannot open $msgfile. $!";
    my @arr = <MSG>;
    print MAIL "@arr\n\n";
    close(MSG);
    close MAIL;

}


sub msgfmt()
{
my ($option, $host, $sid, $message ) = @_;

#local $msgType;

    if ($option eq "a")
    {
        $msgType = "ALERT:"
    }
    elsif ($option eq "w")
    {
        $msgType = "WARN:"
    }
    elsif ($option eq "i")
    {
        $msgType = "INFO:"
    }
    $fmtedMsg =  "$msgType $host $sid $message\n";

return ($fmtedMsg);

}

