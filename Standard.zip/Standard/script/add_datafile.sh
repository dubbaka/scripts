#!/bin/ksh
#
#
#  This is script will be called by add_space.sh
#  Please add/modify the add tablespace and DR related sections here
#  Donot add in add_space.sh
#
#  Date        Name                History
#--------------------------------------------------------------------------------------
# 12-13-2006  Rama Arumugam        For Standard Compliance this is added to add_space.sh
# 01-08-2007  Rama Arumugam        Phase-2 implementation
#---------------------------------------------------------------------------------------

if [ $# -lt 1 ];then
   echo " "
   echo "This script can not be executed as standalone. Must be called by add_space.sh ONLY"
   echo " "
   exit 1
fi


# ------      Section for Add Tablespace  -------

sqlplus \/ <<EOF
spool /oracle/admin/$ORACLE_SID/control/add_space.log

rem ***  Add the sql command to add Tablespace below


create tablespace XXDSH_data datafile '+DG_CG1PRD_DT03/oradata/XXDSH_data_01.dbf' size 8600M;


rem ***  End of add tablespace 

spool off
exit
EOF


#------      Section for DR            ---------

#
# example: scp -p /oracle/admin/$ORACLE_SID/control/standby.ctl <dr_host>:/oracle/admin/$ORACLE_SID/control
#
# example: ssh <dr_host> /oracle/admin/$ORACLE_SID/control/add_space.sh


#--------      End of script           ---------

