#!/oracle/product/perl
#!/usr/local/bin/perl

#
# Name   : monitor_dr.pl
# Date   : 01/09/06
# Author : sraminen 
#
# Description : script that monitors the recovery, checks its health and any errors
#
# Domain : Oracle Data Gaurd
#

#---------------------- Health Checks performed by this script ------------------------
#
#1) is recovery stopped ? If norecover flag is set, don't start it yet. Else start it
#2) the archive gap should not be more than 0. 
#3) get the errors (if any) from the Dataguard error reporting views
#4) check for any offline datafiles or which are having errors
#5) check alert_<STANDBY>.log and report errors there in the last 60 min
# It also updates the thread file with the latest applied logfile sequence number.

#--------------------------------------------------------------------------------------

$Synopsis = <<X;
        $0 -s sid -m email -p epage 
        accepts the following arguments:
               sid             Standby SID name (Mandatory)
               email           recipient email address for errors (optional)
               epage           recipient epage address for errors (optional)

        Example 1.  monitor_dr.pl -s DGPOC -m erp-db-monitor -p erp_dba_duty
        Example 2.  monitor_dr.pl -s DGPOC 


Description:
       This program monitors the recovery process, check its health and reports
       any errors in the Datagaurd configuration. 

       It checks for errors in the alert log in the last 60 min
X

require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;
($nls)=&StdDBPackage::check_nls;


use Getopt::Std;
use Time::Local;

$default_degree = 4;
$default_lagtime = 15;

getopt('smp');
$sid     = $opt_s if defined($opt_s) || &usage("");
$pname   = $0;
#$logfile = "/tmp/${pname}_$sid.log";
$thread_file = "/usr/tools/oracle/recovery/thread/${sid}_thread1.dat";
$mailto  = $opt_m ? $opt_m: $maillist;
$pageto  = $opt_p ? $opt_p: $pagelist;
chomp($host = `/bin/uname -n`);

#
# The following are all the errors that will be reported from the alert logs.
# If there is a new error that we are interested in the future, all we have
# to do is to add the corresponding error code into this hash
#
# NOTE: Some errors that we want to check don't have an associated ORA error
#
# For example "Failed to request gap sequence". We shall use custom codes for these.
# starting from ORA-20001
#
my %error_codes =
    (
     "ORA-00600"  => "Any Internal programming exception",
     "ORA-07445"  => "Internal programming exception with mismatch of address",
     "ORA-04031"  => "Lack of sufficient memory to allocate in Shared Pool",
     "ORA-12154"  => "TNS: Could not resolve the service name",
     "ORA-12157"  => "TNS: Internal network communication error",
     "ORA-12224"  => "TNS: no listener",
     "ORA-2391"   => "exceeded simultaneous SESSIONS_PER_USER limit",
     "ORA-20001"  => "Failed to request gap sequence",
     "ORA-20002"  => "terminating instance due",
     "RFS Network" => "Possible network disconnect with primary database",
    );

$base_dir="/oracle/admin/$sid";
$bdump="$base_dir/bdump";

$current_time=localtime;

@week_days = qw ( Sun Mon Tue Wed Thu Fri Sat );

$time_hr_back;

$error_code;
$error_desc;
$alert_log_line;
$week_day;
$err_text = "";

#
# Define harmless errors here (if any) so we just send a warning and don't page people 
#

#
# End of harmless errors list
#

#open(LOGFILE, ">${logfile}") || die "Cannot open logfile $logfile. $!\n";
#print "Start time ", &ctime(time), "\n";
#print LOGFILE "Start time ", &ctime(time), "\n";

#
# exit if the program is already running currently
#
if (-f "/tmp/monitor_dr_${sid}.pid")
 {
  open(PID, "/tmp/monitor_dr_${sid}.pid") || die "Cannot open pid file. $!";
  $pid = <PID>;
  close(PID);

# A zero signal just checks to see if the process is alive

  $rc = kill 0, $pid;
  if ($rc)
   {
     print "monitor_dr.pl already running under $pid\n";
     exit(1);
   }
 }

  open(PID, "> /tmp/monitor_dr_${sid}.pid");
  print PID $$;
  close(PID);


$oracle_sid = $sid;
&ora_home($oracle_sid);

if ($oracle_home eq "")
{
 capture_err("$pname on $host : Cannot find Oracle Home for $sid. Aborting");
}

#
# If norecover flag is set, don't do any checks. Just exit
#

is_norecover_flag();

&StdDBPackage::which_lib();
$dbh = DBI->connect("dbi:Oracle:", "", "",{ora_session_mode=>2}) ||
        capture_err("$pname:$host:$sid Cannot Connect to Database: $DBI::errstr");

update_thread_file();
check_archive_gap();
#check_dataguard_status_view();
check_datafile_errors();

$dbh->disconnect;

#sanr check_alertlog();
close(LOGFILE);
exit(0);

sub mailit_1()
{
 if (-f $_[1]) 
 {
  #open (MAIL, "|/bin/mailx -s \"$_[0]\"  $mailto < $_[1]");
  #close (MAIL);
   #$errmsg = &msgfmt("i",,,"$_[0]");
   print "errmsg is $errmsg\n";
   print "$_[1]\n";
   &mailit($_[0],$_[1]);
   print "";
 }
}

sub pageit1
{
 my @pagemsg = @_;
 print "pageexe is :$pageexe:\n";

 $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
 $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
 $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");

 if (!defined($pageexe))
 {
     print("epage/pageme executable not found. Aborting...\n");
     exit (1);
 }

  while ($pagemsg = pop(@pagemsg))
  {
   `$pageexe \"$pageto\" \'$pagemsg\'`;
  }
}

sub is_norecover_flag()
{
 #
 # If norecover flag is not set in /usr/tools/oracle/recovery/norecover, start the recovery 
 #
 if ( -e "/usr/tools/oracle/recovery/norecover/$sid")
 {
  print "Exiting..No checks will be performed this time. norecover flag is set\n";
  print LOGFILE "Exiting..No checks will be performed. norecover flag is set", "\n";
  exit(1);
 }
  
 print "Checking if recovery needs to be run \n";
 print LOGFILE "Checking if  recovery needs to be started", "\n";
 system "/usr/tools/oracle/dataguard/start_recovery.pl -s $sid";

 if ($@)
 {
  capture_err("$sid:$host $@ Cannot open /usr/tools/oracle/dataguard/start_recovery.pl");
 }

}# End of routine is_norecover_flag

sub update_thread_file()
{
 #
 #We should not purge unapplied archived logs on the primary site
 #
 $get_latest_log_applied = $dbh->prepare("select max(sequence#) 
                                            from v\$archived_log 
                                           where applied='YES'")
                              or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $get_latest_log_applied->execute 
      or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 $latest_log_applied=$get_latest_log_applied->fetchrow_array;

 print "\n latest_log_applied=$latest_log_applied\n";
 if ( $latest_log_applied > 0 ) 
 {
 open(THREADFILE, ">${thread_file}") || die "Cannot open logfile $thread_file. $!\n";
 print THREADFILE "$latest_log_applied";
 print "updating $thread_file with latest log file $latest_log_applied\n";
 }
 else{
 print "\n File $thread_file NOT updated\n";
 }

 $get_latest_log_applied->finish;

}# End of routine update_thread_file

sub check_archive_gap()
{
 $arc_gap =$dbh->prepare("select count(*) from v\$archive_gap" )
                    or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $arc_gap->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 $archive_gap_count=$arc_gap->fetchrow_array;
 if ($archive_gap_count>10)
 {  
  capture_err("$pname:$host:$sid - standby archive gap count is $archive_gap_count");
 }

 print "archive gap on standby db $sid is 0\n\n";
 print LOGFILE "archive gap on standby $sid is 0", "\n";

 $arc_gap->finish;

}# End of routine check_archive_gap

sub check_dataguard_status_view()
{
 $err_list =$dbh->prepare("select message,to_char(timestamp,'DD-MON-YY HH:MI:SS') 
                             from v\$dataguard_status
                            where severity in ('Error','Fatal') 
                              and timestamp > (sysdate-1/24)")
                  or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $err_list->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 $errors_found = 0;

  while (( $message,$timestamp)=$err_list->fetchrow_array)
  {
   $errors_found = 1;
   print "$message at $timestamp\n";
   print LOGFILE "$message at $timestamp", "\n";
  }

  if ($errors_found)
  {
   print "----------------------------------\n";
   print LOGFILE "--------------------------", "\n";
   capture_err("$pname:$host:$sid  - Errors in v\$dataguard_status view");
  }
  else
  {
   print "No errors in v\$dataguard_status\n\n";
   print LOGFILE "No errors in v\$dataguard_status\n";
  }

 $err_list->finish;

}# End of routine check_dataguard_status_view

sub check_datafile_errors()
{
 $get_datafile_errs =$dbh->prepare("select file#,error
                                      from v\$datafile_header
                                     where status ='OFFLINE'
                                       and error is not null")
                  or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $get_datafile_errs->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

  $errors_found = 0;

  while (( $file,$err)=$get_datafile_errs->fetchrow_array)
  {
   $errors_found = 1;
   print "$err in $file\n";
   print LOGFILE "$err in $file", "\n";
  }

  if ($errors_found)
  {
   print "----------------------------------\n";
   print LOGFILE "--------------------------", "\n";
   capture_err("$pname:$host:$sid  - Datafile errors in v\$datafile_header");
  }
  else
  {
   print "No errors in v\$datafile_header\n";
   print LOGFILE "No errors in v\$datafile_header\n";
  }

 $get_datafile_errs->finish;

}# End of routine check_datafile_errors

sub check_alertlog()
{
#
# Every *statement* in alert_<SID>.ora will be seperated by a timestamp
# and this timestamp will be used for finding error messages and
# their corresponding trace files and other information. This timestamp
# also helps us delimit each error and its corresponding info in the
# alert_<SID>.log
#
# for example : "Sun Jul  6 13:13:48 2003"
#
$alert_log_file="$bdump/alert_$sid.log";

print "alert logfile used is $alert_log_file\n\n";
print LOGFILE "alert logfile used is $alert_log_file", "\n";

print "alert log errors in the last 1 hour are below....\n";
print LOGFILE "alert log errors in the last 1 hour are below....", "\n";


while ( ($error_code,$error_desc) = each %error_codes)
 {
  open (ALERT_LOG,$alert_log_file) ||
     print "Cannot open $alert_log_file: $!";

  &move_alert_log_hr_back($alert_log_file);

           while(<ALERT_LOG>)
           {
            #
            # this line will have the error code
            #
            $alert_log_line = <ALERT_LOG>;
            next unless (($alert_log_line =~ /$error_code/) or ($alert_log_line =~ /$error_desc/));

            capture_err("$pname:$host:$sid - Fatal alert log error $error_code $error_desc");
           }
           close ALERT_LOG;
 }

}# End of routine check_alertlog

#
# a subroutine that points the file handle to a timestamp that is 1 hours
# behind the current time in alert_<SID>.log file
#
sub move_alert_log_hr_back()
{
    my ($xx) = @_;
    my %months =
        (
         "Jan" => 1,
         "Feb" => 2,
         "Mar" => 3,
         "Apr" => 4,
         "May" => 5,
         "Jun" => 6,
         "Jul" => 7,
         "Aug" => 8,
         "Sep" => 9,
         "Oct" => 10,
         "Nov" => 11,
         "Dec" => 12
         );

    my $timestamp;

    $current_time =~ s/^(\w+)(.*)/\2/;
    $current_time =~ s/^\s+//;
 
    my ($mon,$day,$time,$year) = split('\s+',$current_time);
    $mon = $months{$mon};
    my ($hrs, $mins, $secs)    = split(':',$time);

    $current_time    = timelocal($secs,$mins,$hrs,$day,($mon-1),$year);

    $time_hr_back = $current_time - (60*60);

    $current_time    = scalar localtime($current_time);

    #
    # Stop the file handle when it reaches a line that contains
    # the $time_hr_back timestamp. We will start looking for
    # errors from this point till the end of the alert_<SID>.log file
    #
    $timestamp = <ALERT_LOG>;
    my $found = 0;

    while($found == 0 and $timestamp = <ALERT_LOG>)
    {
        #
        # Let's ignore alert log lines starting with a *
        # 
        if ($timestamp =~ /\*\**/)
        {
           $timestamp = <ALERT_LOG>;
        }

        $week_day  = $timestamp;
        $week_day  =~ s/(\w+)(.*)/\1/;
        chomp($week_day);

        if (grep(/^$week_day$/,@week_days))
        {
            $timestamp =~ s/^(\w+)(.*)/\2/;
            $timestamp =~ s/^\s+//;

            my ($mon,$day,$time,$year) = split('\s+',$timestamp);
            $mon = $months{$mon};
            my ($hrs, $mins, $secs)    = split(':',$time);

            $timestamp    = timelocal($secs,$mins,$hrs,$day,($mon-1),$year);

            if ($timestamp >= $time_hr_back)
            {
                $found = 1;
            }
        }

    }

}# End of routine move_alert_log_hr_back

sub capture_err()
{
 $err_str=$_[0];
 print "$err_str\n";
 print LOGFILE "$err_str", "\n";

 if (LOGFILE)
 {
    close(LOGFILE);
    &mailit_1($err_str, $logfile);
 }
 &pageit1($err_str);
 exit(1);
}# End of routine - capture_err

#
#Print program usage
#
sub usage()
{
 $exit = shift(@_) || 0;
 print STDERR "\nusage: $Synopsis";
 exit $exit;
}# End of subroutine usage

sub ora_home()
{
#---------------------------------------------------------------
# Sets  ORACLE_HOME based on /etc/oratab
#---------------------------------------------------------------
 open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
 while (<ORATAB>)
 {
  if (/^${oracle_sid}:/)
   {
    $ENV{'ORACLE_SID'}  = $oracle_sid;
    $oracle_home = (split(':'))[1];
    $ENV{'ORACLE_HOME'} = $oracle_home;
   }
 }
 close(ORATAB);
}# End of routine - ora_home

