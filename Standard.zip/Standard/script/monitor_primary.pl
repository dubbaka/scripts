#!/oracle/product/perl
#!/usr/local/bin/perl 

#
# Name   : monitor_primary.pl
# Date   : 01/09/06
# Author : sraminen 
#
# Description : script that monitors the primary db, checks its health and any errors
#
# Domain : Oracle Data Gaurd
#

#---------------------- Health Checks performed by this script ------------------------
#
#2) check for log shipping errors in v$archive_dest
#3) get the errors (if any) from the Dataguard error reporting views
#5) check if primary had to wait for longtimes on any datagaurd wait events
#6) check alert_<STANDBY>.log and report errors there in the last 60 min

#--------------------------------------------------------------------------------------

#Enhanced by sanr on 20th May 2007
#Enhancements: 1) Will not page for errors in standby if norecover flag is set in standby(for refreshes)
#              2) Will not page if the primary db is down for coldbackup or CR's	
$Synopsis = <<X;
        $0 -s sid -m email -p epage 
        accepts the following arguments:
               sid             SID name (Mandatory)
               email           recipient email address for errors (optional)
               epage           recipient epage address for errors (optional)

        Example 1.  monitor_primary.pl -s DGPOC -m erp-db-monitor -p erp_dba_duty
        Example 2.  monitor_primary.pl -s DGPOC 


Description:
       This program monitors the primary database, check its health and reports
       any errors in the Datagaurd configuration. 

       It checks for errors in the alert log in the last 60 min
X

require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;
($nls)=&StdDBPackage::check_nls;

use Getopt::Std;
use Time::Local;


getopt('smpd');
$sid     = $opt_s if defined($opt_s) || &usage("");
$drhost = $opt_d if defined($opt_d) || &usage("");
$pname   = $0;
#$logfile = "/var/tmp/${pname}_$sid.log";
$mailto  = $opt_m ? $opt_m: $maillist;
$pageto  = $opt_p ? $opt_p: $pagelist;
chomp($host = `/bin/uname -n`);

#
# The following are all the errors that will be reported from the alert logs.
# If there is a new error that we are interested in the future, all we have
# to do is to add the corresponding error code into this hash
#
# NOTE: Some errors that we want to check don't have an associated ORA error
#
# For example "Failed to archive log". We shall use custom codes for these.
# starting from ORA-20001
#
my %error_codes =
    (
     "ORA-19502"  => "write error on file",
     "ORA-16014"  => "no available destinations",
     "ORA-16166"  => "LGWR network server failed to send remote message",
     "ORA-20001"  => "Failed to archive log",
    );

$base_dir="/oracle/admin/$sid";
$bdump="$base_dir/bdump";

$current_time=localtime;

@week_days = qw ( Sun Mon Tue Wed Thu Fri Sat );

$time_hr_back;

$error_code;
$error_desc;
$alert_log_line;
$week_day;
$err_text = "";

#
# Define harmless errors here (if any) so we just send a warning and don't page people 
#

#
# End of harmless errors list
#

#open(LOGFILE, ">${logfile}") || die "Cannot open logfile $logfile. $!\n";
#print "Start time ", &ctime(time), "\n";
#print LOGFILE "Start time ", &ctime(time), "\n";

#
# exit if the program is already running currently
#
if (-f "/tmp/monitor_primary_${sid}.pid")
 {
  open(PID, "/tmp/monitor_primary_${sid}.pid") || die "Cannot open pid file. $!";
  $pid = <PID>;
  close(PID);

# A zero signal just checks to see if the process is alive

  $rc = kill 0, $pid;
  if ($rc)
   {
     print "monitor_primary.pl already running under $pid\n";
     exit(1);
   }
 }

  open(PID, "> /tmp/monitor_primary_${sid}.pid");
  print PID $$;
  close(PID);


$oracle_sid = $sid;
&ora_home($oracle_sid);

if ($oracle_home eq "")
{
 capture_err("$pname on $host : Cannot find Oracle Home for $sid. Aborting");
}

#
# If norecover flag is set, don't do any checks. Just exit
is_norecover_flag();
is_pmon_down();
#
#$dbh = DBI->connect("dbi:Oracle:", "", "",{ora_session_mode=>2}) ||
#        capture_err("$pname:$host:$sid Cannot Connect to Database: $DBI::errstr");
&StdDBPackage::which_lib();
$dbh = DBI->connect("DBI:Oracle:", '', '',{ ora_session_mode=>2});


is_dataguard_enabled();


check_dataguard_status_view();
check_for_logship_errors();

$dbh->disconnect;

#check_alertlog();
close(LOGFILE);
exit(0);

sub mailit_1()
{
 if (-f $_[1]) 
 {
  #open (MAIL, "|/usr/bin/mailx -s \"$_[0]\"  $mailto < $_[1]");
  #close (MAIL);
  #$Errmsg = &msgfmt("i",,,"$_[0]");
   &mailit($_[0],$_[1]);
   print "";
 }
}

sub pageit1
{
 my @pagemsg = @_;
 print "pageexe is :$pageexe:\n";

 $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
 $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
 $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");

 if (!defined($pageexe))
 {
     print("epage/pageme executable not found. Aborting...\n");
     exit (1);
 }


  while ($pagemsg = pop(@pagemsg))
  {
   `$pageexe \"$pageto\" \'$pagemsg\'`;
  }
}
sub is_norecover_flag()
{
 #
 # If norecover flag is not set in /usr/tools/oracle/recovery/norecover, start the recovery
 #
if (`/usr/local/bin/ssh $drhost /usr/bin/ls /usr/tools/oracle/recovery/norecover/$sid`)
 {
  print "Exiting..No checks will be performed this time. norecover flag is set\n";
  exit(1);
 }
}
sub is_pmon_down()
{
$sid_pmon=`ps -ef | grep \"pmon_$sid\$" | grep -v grep`;
print "pmon process is :$sid_pmon:\n";
if (!$sid_pmon)
{
print "Exitting as pmon is down...";
exit(1);
}
}
#
# A subroutine that checks whether remote_archive_enable  parameter is set or not
#
sub is_dataguard_enabled()
{
 $get_parameter = $dbh->prepare("select upper(value)
                                   from v\$parameter
                                  where upper(name) = 'REMOTE_ARCHIVE_ENABLE'")
                              or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $get_parameter->execute
      or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 $parameter_value=$get_parameter->fetchrow_array;

 if ($parameter_value != 'TRUE')
 {
  capture_err("$pname:$host:$sid - remote_archive_enable not set");
 }

 $get_parameter->finish;

}# End of routine is_norecover_flag

sub check_dataguard_status_view()
{
 $err_list =$dbh->prepare("select message,to_char(timestamp,'DD-MON-YY HH:MI:SS') 
                             from v\$dataguard_status
                            where severity in ('Error','Fatal') 
                              and timestamp > (sysdate-1/24)")
                  or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $err_list->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 $errors_found = 0;

  while (( $message,$timestamp)=$err_list->fetchrow_array)
  {
   $errors_found = 1;
   print "$message at $timestamp\n";
   print LOGFILE "$message at $timestamp", "\n";
  }

  if ($errors_found)
  {
   print "----------------------------------\n";
   print LOGFILE "--------------------------", "\n";
   capture_err("$pname:$host:$sid  - Errors in v\$dataguard_status view");
  }
  else
  {
   print "No errors in v\$dataguard_status\n\n";
   print LOGFILE "No errors in v\$dataguard_status\n";
  }

 $err_list->finish;

}# End of routine check_dataguard_status_view

sub check_for_logship_errors()
{
 $log_errs =$dbh->prepare("select status,destination,error 
                             from v\$archive_dest
                            where target='STANDBY'
                              and status != 'VALID'
                              and error is not null")
                  or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $log_errs->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 $errors_found = 0;

  while (( $status,$dest,$err)=$log_errs->fetchrow_array)
  {
   $errors_found = 1;
   print "v\$archive_dest has errors $status : $dest : $err\n";
   print LOGFILE "v\$archive_dest has errors $status : $dest : $err", "\n";
  }

  if ($errors_found)
  {
   print "----------------------------------\n";
   print LOGFILE "--------------------------", "\n";
   capture_err("$pname:$host:$sid  - Errors in v\$archive_dest view");
  }
  else
  {
   print "No errors in v\$archive_dest\n\n";
   print LOGFILE "No errors in v\$archive_dest\n";
  }

 $log_errs->finish;

}# End of routine check_for_logship_errors

sub check_alertlog()
{
#
# Every *statement* in alert_<SID>.ora will be seperated by a timestamp
# and this timestamp will be used for finding error messages and
# their corresponding trace files and other information. This timestamp
# also helps us delimit each error and its corresponding info in the
# alert_<SID>.log
#
# for example : "Sun Jul  6 13:13:48 2003"
#
$alert_log_file="$bdump/alert_$sid.log";
#$alert_log_file="$bdump/alert_DGPOC.log.24Nov";

print "alert logfile used is $alert_log_file\n\n";
print LOGFILE "alert logfile used is $alert_log_file", "\n";

print "alert log errors in the last 1 hour are below....\n";
print LOGFILE "alert log errors in the last 1 hour are below....", "\n";


while ( ($error_code,$error_desc) = each %error_codes)
 {
  open (ALERT_LOG,$alert_log_file) ||
     print "Cannot open $alert_log_file: $!";

  &move_alert_log_hr_back($alert_log_file);

           while(<ALERT_LOG>)
           {
            #
            # this line will have the error code
            #
            $alert_log_line = <ALERT_LOG>;
            next unless (($alert_log_line =~ /$error_code/) or ($alert_log_line =~ /$error_desc/));

            print "\n**** $error_code : $error_desc ****\n";
            print LOGFILE "**** $error_code : $error_desc ****", "\n";

            capture_err("$pname:$host:$sid - Fatal alert log error $error_code $error_desc");
           }
           close ALERT_LOG;
 }

}# End of routine check_alertlog

sub move_alert_log_hr_back()
{
    my ($xx) = @_;
    my %months =
        (
         "Jan" => 1,
         "Feb" => 2,
         "Mar" => 3,
         "Apr" => 4,
         "May" => 5,
         "Jun" => 6,
         "Jul" => 7,
         "Aug" => 8,
         "Sep" => 9,
         "Oct" => 10,
         "Nov" => 11,
         "Dec" => 12
         );

    my $timestamp;

    $current_time =~ s/^(\w+)(.*)/\2/;
    $current_time =~ s/^\s+//;

    my ($mon,$day,$time,$year) = split('\s+',$current_time);
    $mon = $months{$mon};
    my ($hrs, $mins, $secs)    = split(':',$time);

    $current_time    = timelocal($secs,$mins,$hrs,$day,($mon-1),$year);


    $time_hr_back = $current_time - (60*60);

    $current_time    = scalar localtime($current_time);

    #
    # Stop the file handle when it reaches a line that contains
    # the $time_hr_back timestamp. We will start looking for
    # errors from this point till the end of the alert_<SID>.log file
    #
    $timestamp = <ALERT_LOG>;
    my $found = 0;

    while($found == 0 and $timestamp = <ALERT_LOG>)
    {
        #
        # Let's ignore alert log lines starting with a *
        #
        if ($timestamp =~ /\*\**/)
        {
           $timestamp = <ALERT_LOG>;
        }

        $week_day  = $timestamp;
        $week_day  =~ s/(\w+)(.*)/\1/;
        chomp($week_day);

        if (grep(/^$week_day$/,@week_days))
        {
            $timestamp =~ s/^(\w+)(.*)/\2/;
            $timestamp =~ s/^\s+//;

            my ($mon,$day,$time,$year) = split('\s+',$timestamp);
            $mon = $months{$mon};
            my ($hrs, $mins, $secs)    = split(':',$time);

            $timestamp    = timelocal($secs,$mins,$hrs,$day,($mon-1),$year);

            if ($timestamp >= $time_hr_back)
            {
                $found = 1;
            }
        }

    }

}# End of routine move_alert_log_hr_back


sub capture_err()
{
 $err_str=$_[0];
 print "$err_str\n";
 print LOGFILE "$err_str", "\n";

 if (LOGFILE)
 {
    close(LOGFILE);

    &mailit_1($err_str, $logfile);
 }

 &pageit1($err_str);
 exit(1);
}# End of routine - capture_err

#
#Print program usage
#
sub usage()
{
 $exit = shift(@_) || 0;
 print STDERR "\nusage: $Synopsis";
 exit $exit;
}# End of subroutine usage

sub ora_home()
{
#---------------------------------------------------------------
# Sets  ORACLE_HOME based on /etc/oratab
#---------------------------------------------------------------
 open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
 while (<ORATAB>)
 {
  if (/^${oracle_sid}:/)
   {
    $ENV{'ORACLE_SID'}  = $oracle_sid;
    $oracle_home = (split(':'))[1];
    $ENV{'ORACLE_HOME'} = $oracle_home;
   }
 }
 close(ORATAB);
}# End of routine - ora_home

