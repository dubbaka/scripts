#!/oracle/product/perl
##!/usr/local/bin/perl
#---------------------------------------------------------------------------------------------------
# SCCS INFO : top10.pl [1.4] 07/28/03 15:10:39
# FILE INFO : top10.sql
# CREATED   : ckarthik
# DATE      : 07/02/2000
# DESC      : Collects Top 10 Cup used process
# 		need plan_table in ops$oracle account
#  swei  Mar-19-2004 Add msgfmt/mailit function
#  swei  Aug-17-2004 Add std function
#
#---------------------------------------------------------------------------------------------------

require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


#use      DBI;
use      Getopt::Std;
use      Time::Local;

chomp($Host = `/bin/uname -n`);
$MailTo     = 'mis-dba';
$PageTo     = '';
$SID        = '';
$Ctr        = 0 ;
$TopCnt     = 10;
@top_pid    = ();

getopt('htm');
&Usage if defined($opt_h);
$TopCnt     = $opt_t if defined($opt_t);
$MailTo     = $opt_m if defined($opt_m);

&Collect_Top_Process;
&Get_Process_Info;
exit(0);

#---------------------------------------------------------------------------------------------------
# SUB Collect_Top_Process
#---------------------------------------------------------------------------------------------------
sub Collect_Top_Process {

    print "\nGetting top $TopCnt process .....\n";
    system("top -h -n 50 -f /tmp/top.cck") ;
    system("tail -50 /tmp/top.cck > /tmp/top.cck2");
    system("grep oracle /tmp/top.cck2 > /tmp/top.cck1");
    system("head -${TopCnt} /tmp/top.cck1 > /tmp/top.cck");

    open (FR, "/tmp/top.cck");

    $j=0;
    while(<FR>) { 
       @ary=(split(' '));
       next if (substr($ary[$#ary],0,6) ne "oracle");
       $top_pid[$j++] = "$ary[2],$ary[9],$ary[11],$ary[12]";
    }

    close(FR);
    system("rm -f /tmp/top.cck1 /tmp/top.cck2 /tmp/top.cck");
}

#---------------------------------------------------------------------------------------------------
# SUB Get_Process_Info
#---------------------------------------------------------------------------------------------------
sub Get_Process_Info {

    open (FP, ">top10.log")||&Mail_Error("Can not open logfile. $!");
    foreach $a (@top_pid) {
       if (++$Ctr == 1) {
          print    "\n\n\t\t Top 10 CPU Sessions - ", &ctime(time), "\n\n";
          print FP "\n\n\t\t Top 10 CPU Sessions - ", &ctime(time), "\n\n";
       }

       ($Spid, $CpuTime, $Cpu, $SID) = split(',',$a);
       $SID =~ s/oracle//g;

       $Str = "${Ctr}. Db Name:[$SID]  Spid:[$Spid]  CpuTime:[$CpuTime]  Cpu\%:[$Cpu]";
       $StrLen = length($Str);

       print    "-"x$StrLen, "\n$Str\n", "-"x$StrLen, "\n";
       print FP "-"x$StrLen, "\n$Str\n", "-"x$StrLen, "\n";

       &ora_home($SID);

       #&Set_Env($SID)  ;
       $Dbh = DBI->connect("dbi:Oracle:", "", "") || &Mail_Error($DBI::errstr);
       &Get_Session_Info;
       $Dbh->disconnect ;
    }
    close (FP);
}


#---------------------------------------------------------------------------------------------------
# SUB Get_Session_Info
#---------------------------------------------------------------------------------------------------
sub Get_Session_Info {

    $Stmt1 = qq{SELECT v.sid, p.spid, NVL(rtrim(ltrim(v.process)), 'N/A') ,
                       NVL(v.username,'N/A'), NVL(v.osuser,'N/A'), NVL(v.machine,'N/A'), 
                       NVL(module,'N/A'), NVL(v.program,'N/A'), NVL(action,'N/A') ,
                       v.status||' '||
                       LPAD(((last_call_et/60)-mod((v.last_call_et/60),60))/60,2,'0') ||':'||
                       LPAD(ROUND(mod((v.last_call_et/60),60)),2,'0') ||' H', v.sql_address
                FROM   v\$session v, v\$process p
                WHERE  v.paddr = p.addr
                AND    v.username IS NOT NULL
                AND    p.spid = $Spid };

    $Sth1 = $Dbh->prepare($Stmt1) || &Mail_Error($DBI::errstr);
    $Sth1->execute;

    $Stmt2= q{SELECT sql_text from v$sqltext WHERE address = ? ORDER BY piece};
    $Sth2 = $Dbh->prepare($Stmt2) || &Mail_Error($DBI::errstr);

    $Stmt3 = q{ SELECT  RPAD(RTRIM(LPAD(' ',1*LEVEL)||RTRIM(operation)||' '||
                        RTRIM(options) || ' '|| object_name),58) query_plan,
                        LTRIM(to_char(cost,'9,999,999')), 
                        LTRIM(to_char(cardinality,'999,999,999'))
                FROM    plan_table
                START   WITH id = 0
                AND     statement_id = ?
                CONNECT BY PRIOR id = parent_id
                AND     statement_id = ?  };

    $Sth3 = $Dbh->prepare($Stmt3) || &Mail_Error($DBI::errstr);

    $FullSql = "";

    while (($Sid, $Spid, $Proc, $OraUsr, $OsUsr, $Mach, $Mod, $Prog, $Act, $St, $SqlAdr) = 
            $Sth1->fetchrow_array) {


       print    "Sid         : $Sid \n";
       print FP "Sid         : $Sid \n";
       print    "Spid        : $Spid \n";
       print FP "Spid        : $Spid \n";
       print    "Process Id  : $Proc \n";
       print FP "Process Id  : $Proc \n";
       print    "Oracle User : $OraUsr \n";
       print FP "Oracle User : $OraUsr \n";
       print    "Os User     : $OsUsr \n";
       print FP "Os User     : $OsUsr \n";
       print    "Machine     : $Mach \n";
       print FP "Machine     : $Mach \n";
       print    "Module      : $Mod \n";
       print FP "Module      : $Mod \n";
       print    "Program     : $Prog \n";
       print FP "Program     : $Prog \n";
       print    "Action      : $Act \n";
       print FP "Action      : $Act \n";
       print    "Status      : $St \n";
       print FP "Status      : $St \n";
       print    "SQL Text    : \n\n";
       print FP "SQL Text    : \n\n";

       $FullSql = "";
       $Sth2->execute($SqlAdr);
       while (($Sql) = $Sth2->fetchrow_array){
          $FullSql .= $Sql;
          print    "$Sql\n";
          print FP "$Sql\n";
       } 

       print    "\nExplain Plan:-\n**************\n\n";
       print FP "\nExplain Plan:-\n**************\n\n";
       &Explain($FullSql);
    }

    $Sth1->finish;
    $Sth2->finish;
    $Sth3->finish;
}


#---------------------------------------------------------------------------------------------------
# SUB Explain 
#---------------------------------------------------------------------------------------------------
sub Explain {

    $ExpTxt = $_[0];
    $ExpUsr = $OUsr ;

    return if ( ($ExpTxt =~ /declare/i) || 
                ($ExpTxt =~ /cursor/i ) || 
                ($ExpTxt =~ /begin/i  ) );


    $ExpTxt =~ s/\:0/\:1/gi; # fix error with :0 bind variable in next line
    $ExpTxt =~ s/\:o/\:1/gi; # fix error with :0 bind variable in next line
    $ExpTxt =~ s/\:d/\:1/gi; # fix error with :0 bind variable in next line
    $ExpTxt =~ s/\:rn/\:1/gi; # fix error with :0 bind variable in next line
    $ExpUsr = "APPS" if ($ExpUsr eq ""               || 
                         $ExpUsr eq "SYS"            || 
                         $ExpUsr eq "CIB_SCCUI"      || 
                         $ExpUsr eq "APPS_READ_ONLY" );

    $r=$Dbh->do("DELETE FROM plan_table WHERE statement_id = \'top2exp\'");

    $ExpTxt = "EXPLAIN PLAN SET STATEMENT_ID \'top2exp\' FOR $ExpTxt";

    $r=$Dbh->do("alter session set current_schema = $ExpUsr");
    $r=$Dbh->do("$ExpTxt");
    $r=$Dbh->do('alter session set current_schema = OPS$ORACLE');

    printf    "%-58s %9s %11s\n","QUERY_PLAN","COST","ROWS";
    printf FP "%-58s %9s %11s\n","QUERY_PLAN","COST","ROWS";
    printf    "%-58s %9s %11s\n","-"x58, "-"x9,"-"x11;
    printf FP "%-58s %9s %11s\n","-"x58, "-"x9,"-"x11;
 
    $Sth3->execute('top2exp','top2exp');

    while(($QryPln, $Cost, $Rows) = $Sth3->fetchrow_array) {
       printf    "%-58s %9s %11s\n",$QryPln, $Cost,$Rows;
       printf FP "%-58s %9s %11s\n",$QryPln, $Cost,$Rows;
    }
    print    "\n";
    print FP "\n";

}

#---------------------------------------------------------------------------------------------------
# SUB Set_Env 
#---------------------------------------------------------------------------------------------------
sub Set_Env {

    $NotFound = 1;
    open(ORATAB, "/etc/oratab") || &Mail_Error("Can't Open /etc/oratab");
    while (<ORATAB>) {

       if (/^${SID}:/) {
          $ENV{'ORACLE_HOME'} = (split(':'))[1];
          $ENV{'ORACLE_SID'} = $SID;
          $NotFound = 0;
       }
    }
    close(ORATAB);

    &Mail_Error("$SID not found in /etc/oratab") if ($NotFound);
}

#---------------------------------------------------------------------------------------------------
# SUB Mail_It
#---------------------------------------------------------------------------------------------------
sub Mail_It {

    @MailTemp = split(',',$MailTo);

    for ($i = 0; $i <= $#MailTemp; $i++) {
      $MailTemp[$i]=$MailTemp[$i].'@cisco.com' if (!($MailTemp[$i] =~ /cisco/));
    }
    $MailTo =join(',',@MailTemp);
    open(MAIL, "|/usr/bin/mailx -s \"$_[0]\"  $MailTo < $_[1]");
    close(MAIL);
    print "";
}

#---------------------------------------------------------------------------------------------------
# SUB Page_It
#---------------------------------------------------------------------------------------------------
sub Page_It {

    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");

    if (!defined($pageexe)) {

       print("$0 on $Host: epage/pageme executable ".
             "not found. Aborting...");
        exit (1);
    }

    my @pagemsg = @_;

    while ($pagemsg = pop(@pagemsg)) {

        foreach $page (split /,/, $PageTo) {
            `$pageexe $page \'$pagemsg\'`;
        }
    }
}

#---------------------------------------------------------------------------------------------------
# SUB Usage
#---------------------------------------------------------------------------------------------------
sub Usage {

    print "\n","-"x80,"\nUsage:$0 -t <Number_Of_Top_Process> -m MailId, -h Usage\n","-"x80,"\n\n";
    exit (1);
}

#---------------------------------------------------------------------------------------------------
# SUB Mail_Error
#---------------------------------------------------------------------------------------------------
sub Mail_Error {

    print    "\n\nError : $0 on $Host : $_[0]\n\n" ;
    &Mail_It("Error : $0 on $Host : $_[0]", "/dev/null");
    exit (1);
}

sub ora_home
{
my $oracle_sid;

    $oracle_sid = $_[0];

    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_HOME'} = $oracle_home;
        $ENV{'ORACLE_SID'}=$oracle_sid;
        $ENV{'LD_LIBRARY_PATH'} = "$ora_home/lib";
        $ENV{'SHLIB_PATH'} = "$ora_home/lib";
        $ENV{'TNS_ADMIN'} = "$ora_home/network/admin";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }


        print "Sid $oracle_sid home $ora_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();

        }
    }
    close(ORATAB);
}


#---------------------------------------------------------------------------------------------------
# **** End of Perl Script 
#---------------------------------------------------------------------------------------------------

