#!/oracle/product/perl
##!/usr/local/bin/perl 
###############################################################################
# Name:		Name - backup_oracle
#	
  $Synopsis = <<X;
	$0 -s SID [-m] [-p] [-help]
       accepts the following arguments:
               -s sid             [backup only this SID]
               -help             [displays help]
               -d              [displays debugging info on commands]
	       -m              [mailing alias]
               -p              [paging alias]

Description:
	online_backup_status.pl -s SID -m mis-dba@cisco.com -p dba-duty
X
# Description:	
#	
# Returns: 	
# On Error:	
# Location:     /usr/tools/oracle/online_backup_status.pl
# History:       Susan Wei
# History Modified:
#  swei  Mar-19-2004 Add Which_Lib and msgfmt/mailit function
#
# ........................................................................
###############################################################################
#use DBI;
use Getopt::Std;
require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


# Together with a copy of the datafiles, there should be a copy of the control
# file taken at the time of the end of the backup. This backup is made in this
# script, where oracle must be able to write to the location defined by 
# $backup_dir_base.$sid.$backup_dir_suffix
# and this directory should go to tape together with the datafiles. 

$backup_dir_base = "/oracle/admin/";
$backup_dir_suffix = "/bdump";


#-----------------------------------------------------------------------------
# Process command line switches and options: print usage msg. on error
#-----------------------------------------------------------------------------
#&Getopts('hdmp');
getopt('hsmp');

&Usage if (defined($opt_h));
$database    = $opt_s;
$maillist    = $opt_m ? $opt_m : "mis-dba\@cisco.com";
$pagelist    = $opt_p ? $opt_p : "dba-duty";


#-----------------------------------------------------------------------------
# Exit if wrong # of arguments
#-----------------------------------------------------------------------------
#print "$#ARGV\n";
#&Usage(1) if ( $#ARGV != 3 );


#$database = $ARGV[0]; print "Database $database\t"  if defined($opt_d);


# Exit if wrong userid running me
#($login,$loginname) = ((getpwuid($>))[0,6]) ;
#&Usage(2) if ($login ne "oracle");

    chomp($host = `/bin/uname -n`);
    &get_pageexe();
    print "Start Time: ", &ctime(time), "\n";
    $pageto= $pagelist;
    $mailto = $maillist;
    open(ORATAB,"</etc/oratab") || die "Can't open /etc/oratab\n";
    while (<ORATAB>)
    {
        next if /^#/;
        ($oracle_sid, $ora_home, $db_flag, $dummy) = split(/:/);
        chomp($db_flag);
        $db_flag =~ tr/[a-z]/[A-Z]/;
        $ENV{'ORACLE_SID'} = $oracle_sid;
        $ENV{'ORACLE_HOME'} = $ora_home;
        $ENV{'LD_LIBRARY_PATH'} = "$ora_home/lib";
        $ENV{'SHLIB_PATH'} = "$ora_home/lib";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }


        print "Sid $oracle_sid home $ora_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();

        next if (($db_flag eq "N" ) && ($database eq "oratab"));
        if (   ($database eq "all"   ) 
            || ($database eq "oratab") 
            || ($database eq $oracle_sid    ))
        {
            &change_tbs();
        } 
    }
    print "\nEnd Time: ", &ctime(time);
 




#
# End of Main
#


sub change_tbs 
{
    # Note: On error in this subroutine, the script will promptly die, 
    # thus not allowing any other tablespaces or databases to process.
    # This could be a problem .. in the event of an error, the database
    # must be fixed outside of this script by a DBA, depending on the error.

    $backup_dir =$backup_dir_base.$oracle_sid.$backup_dir_suffix;
    if (! -d $backup_dir)
    {
        &backup_error("backup_oracle on $host: $backup_dir does not exist. $!");
    }
    print "Connecting to sid $oracle_sid\n" if defined($opt_d);
    $dbh = DBI->connect("dbi:Oracle:", "", "") || 
        &backup_error("Can not connect to $oracle_sid. $DBI::errstr");


    $stmt = "select count(*)  from v\$backup 
        where status = 'ACTIVE' ";
#        and sysdate - time >= 1/48";

    $sth = $dbh->prepare($stmt) || 
        &backup_error("Database - $oracle_sid. Error while preparing $stmt. $DBI::errstr");
    $rc = $sth->execute() ||
        &backup_error("Database - $oracle_sid. Error while executing $stmt. $DBI::errstr");
    ($count) = $sth->fetchrow_array();
    $sth->finish;

    if ($count > 0)
    {
        &backup_error("Database - $oracle_sid. Database already in Active mode.");	
    }


    $dbh->disconnect;
}

sub Usage 
{
    $exit = shift(@_) || 0;
    print STDERR "\nusage: $Synopsis"; 
    exit $exit;
}

sub get_pageexe
{
    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");
    if (!defined($pageexe))
    {
        print("online_backup_status.pl on $host: epage/pageme executable not found. Aborting...");
        exit (1);
    }
}

sub pageit
{
my @pagemsg = @_;

    while ($pagemsg = pop(@pagemsg))
    {
        foreach $page (split /,/, $pageto)
        {
            #print "<$pageexe $page \"$pagemsg\">\n";
            `$pageexe $page \'$pagemsg\'`;
        }
    }
}

sub check_dbf
{
my $mode = $_[0];
my ($status, $sth, $rc, $count);

    $status = ($mode eq "BEGIN") ? "ACTIVE" : "NOT ACTIVE";
    #if ($mode eq "BEGIN")
    #{
	#$status = "ACTIVE";
    #}
    #else
    #{
	#$status = "NOT ACTIVE";
    #}
    $stmt = "select count(*) from v\$backup where status = '".$status."'";
    $sth = $dbh->prepare($stmt) || 
        &backup_error("Database - $oracle_sid. Error while preparing $stmt. $DBI::errstr");
    $rc = $sth->execute() ||
        &backup_error("Database - $oracle_sid. Error while executing $stmt. $DBI::errstr");
    ($count) = $sth->fetchrow_array();
    $sth->finish;
    if ($count > 0)
    {
        &backup_error("Database - $oracle_sid. Database already in Active mode.");	
    }
}

sub backup_error
{
    print "@_\n\n";
    &pageit(@_);
    $errmsg = &msgfmt("a","`uname -n`","$database","backup problem - Active Mode");
    &mailit("$errmsg","/dev/null");
#    system("/usr/bin/mailx -s \"$database backup problem - Active Mode \" $maillist< /dev/null");
    $dbh->disconnect if (defined($dbh));
    exit(1);
}

