#!/oracle/product/perl
##!/usr/local/bin/perl
#
# Name    : check_extents.pl
# Version : 1.7
# Date    : 07/19/1999
#
# Modification History:
# 01/02/2004: jselvara
# Modified to capture Uniform extent tablespaces
# Modified to capture tablespace with no rows in dba_free_space
# Modified swei  Mar-19-2004 Add Which_Lib and msgfmt/mailit function
#
# ........................................................................

require "ctime.pl";
#use DBI;
use Getopt::Std;
use Time::Local;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


getopt('fsmp');
$maillist    = "erp-db-monitor\@cisco.com";
$pagelist    = "erp-dba-duty";
$sid         = $opt_s if defined($opt_s) || &usage("");
$logfile     = "/tmp/check_extents_$sid.log";
$errorfile   = "/tmp/check_extents_$sid.err";
$parfile     = "/usr/tools/oracle/check_extents.par";
$OPCPATH     = "/opt/OV/bin/OpC";
$OPCMSG      = "$OPCPATH/opcmsg";
$SEVERITY    = "critical";
$contact     = "jselvara";
$METHOD      = "PAGE";
$out_subject = "Serious space problem on $sid";
$out_message = "Serious space problem on $sid";



    undef($mailto);
    undef($pageto);
    $mailto = $opt_m;
    $pageto = $opt_p;


    chomp($host = `/bin/uname -n`);
    &get_pageexe();
    print "Start time ", &ctime(time), "\n";
    open(LOGFILE, ">${logfile}") || die "Cannot open logfile. $!\n";
    $oracle_sid = $sid;
    $ENV{'ORACLE_SID'}=$oracle_sid;
    &ora_home($oracle_sid);

    $runVolumeAutoAdd=`/usr/tools/oracle/Standard/script/volumeAutoAdd.sh $oracle_sid`;
    
    $dbh = DBI->connect("dbi:Oracle:", "", "") || die $DBI::errstr;
#    $dbh = DBI->connect("", "internal", "","dbi:Oracle:") || die $DBI::errstr;
    &get_block_size();
    &get_db_version();
    &get_free_space();
    &get_total_space();
    #&get_user_name();
    $rc = $dbh->disconnect;
    ($dummy, $mailto2, $esc_time, $pageto2)  = &get_esc_ids($oracle_sid);
    $esc_time *= 60;
    $pageto = $pageto ? $pageto : ($pageto2 ? $pageto2 : $pagelist);
    $mailto = $mailto ? $mailto : ($mailto2 ? $mailto2 : $maillist);
    @esc_ids = split(',', $pageto);
 
    $ec1 = $wc1 = 0;
    &check_free_space();
    if ($ec1)
    {
        print "\nERROR: Maximum Free Space <= 200M and Pct Free <= 5%\n";
        print LOGFILE "\nERROR: Maximum Free Space <= 200M and Pct Free <= 5%\n";
        &print_hdr1();
        $i = 0;
        for $i (0..($ec1 - 1))
        {
            @data = @{$errorarr1[$i]};
            printf "%-19s %8d          %8d        %8d  %6.2f\n", 
                $data[0], $data[1], $data[2], $data[3], $data[4];
            printf LOGFILE "%-19s %8d          %8d        %8d  %6.2f\n", 
                $data[0], $data[1], $data[2], $data[3], $data[4];
            $msg = sprintf  "check_extents.pl on %s: %s Tablespace is running out of space. Size - %dM, Free - %dM, Max free - %dM, Pct Free - %6.2f", 
                $oracle_sid, $data[0], $data[1], $data[2], $data[3], $data[4];
            push(@pagemsg1, $msg);
        }
        print "\n";
        print LOGFILE "\n";
    }
    if ($wc1)
    {
        print "\nWARNING: Total Free <= 700M Max Free <= 250M and Pct Free <= 10%\n";
        print LOGFILE "\nWARNING: Total Free <= 700M Max Free <= 250M and Pct Free <= 10%\n";
        &print_hdr1();
        $i = 0;
        for $i (0..($wc1 - 1))
        {
            @data = @{$warnarr1[$i]};
            printf "%-19s %8d          %8d        %8d  %6.2f\n", 
                $data[0], $data[1], $data[2], $data[3], $data[4];
            printf LOGFILE "%-19s %8d          %8d        %8d  %6.2f\n", 
                $data[0], $data[1], $data[2], $data[3], $data[4];
        }
        print "\n";
        print LOGFILE "\n";
    }
    close(LOGFILE);
    print "\nEnd time ", &ctime(time), "\n";

    if ($wc1 || $ec1)
    {
        $errmsg = &msgfmt("w","$host","$oracle_sid","Database Space Alert");
        &mailit("$errmsg",$logfile);
        #&mailit("SPACE ALERT: Database $oracle_sid on $host", $logfile);
    }
    if ($ec1 > 4)
    {
        $errmsg = &msgfmt("a","$host","$oracle_sid","Database Space Alert");
        &mailit("$errmsg",$logfile);
        @pagemsg1 = ("check_extents.pl on $oracle_sid: Serious space problem on $sid. PLEASE CHECK.");
    }
    if ($ec1 > 0)
    {
        $errortime = &get_error_time($oracle_sid, $errorfile);
        {
            use integer;
            if ($esc_time > 0)
            {
                $e2 = $errortime/$esc_time;
                $pageaddr = $esc_ids[$e2] ? $esc_ids[$e2] : $esc_ids[$#esc_ids];
                $pageto = $pageaddr;
            }
        }
    }
    if ($ec1 == 0)
    {
        unlink($errorfile) if (-f $errorfile);
    }
    &pageit(@pagemsg1);
    &pageit(@pagemsg2);

    exit (0);

sub ora_home
{
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_HOME'} = $oracle_home;
        $ENV{'LD_LIBRARY_PATH'} = "$ora_home/lib";
        $ENV{'SHLIB_PATH'} = "$ora_home/lib";
        #$ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }

        print "Sid $oracle_sid home $ora_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();

        #&Which_Lib();

        }
    }
    close(ORATAB);
}

#sub mailit 
#{
#    open (MAIL, "|/usr/bin/mailx -s \"$_[0]\"  $mailto < $_[1]");
#    close (MAIL);
#    print "";
#}


sub pageit 
{
my @pagemsg = @_;

    while ($pagemsg = pop(@pagemsg))
    {
        foreach $page (split /,/, $pageto)
        {
            #print "<$pageexe $page \"$pagemsg\">\n";
            `$pageexe $page \'$pagemsg\'`;
        }
    }
}

sub usage 
{
    print "$_[0]";
    print "Usage:\ncheck_extents.pl -s <SID> -m mailaddr[,mailaddr...] -p pageraddr[,pageraddr...]\n";
    exit (1);
}

sub get_pageexe
{
    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");
    $pageexe = "/usr/tools/oracle/itopage.pl" if (-f "/usr/tools/oracle/itopage.pl");

    if (!defined($pageexe))
    {
        print("check_extents.pl on $host: epage/pageme executable not found. Aborting...");
        exit (1);
    }
}
sub print_hdr1
{
    print "\nTablespace          Size(Mb)    Total Free(Mb)    Max Free(Mb)  Pct Free\n";
    print LOGFILE "\nTablespace          Size(Mb)    Total Free(Mb)    Max Free(Mb)  Pct Free\n";
    &print_dash(STDOUT);
    &print_dash(LOGFILE);
}

sub print_hdr2
{
    print "\nTablespace          Size(Mb)    Total Free(Mb)    Max Free(Mb) Pct. Free\n";
    print LOGFILE "\nTablespace          Size(Mb)    Total Free(Mb)    Max Free(Mb) Pct. Free\n";
    &print_dash(STDOUT);
    &print_dash(LOGFILE);
}

sub print_dash
{
    $FH = @_[0];

    print $FH "-"x79;
    print $FH "\n";
}

sub show_error()
{

    print "$_[0]. $DBI::errstr\n";
    exit (1);
}

sub get_block_size()
{
    $stmt = "select value  from v\$parameter where name = 'db_block_size'";
    $sth = $dbh->prepare($stmt) || 
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || 
        &show_error("Error while executing $stmt");
    ($blocksize) = $sth->fetchrow_array();
    $sth->finish();
}

sub get_db_version()
{
    $stmt = "select banner  from v\$version where rownum < 2";
    $sth = $dbh->prepare($stmt) || 
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || 
        &show_error("Error while executing $stmt");
    ($typeval) = $sth->fetchrow_array();
    $sth->finish();
    
    if ($typeval =~ /Oracle7/)
    {
        $typecol = "type";
    }
    else
    {
        $typecol = "type#";
    }
}


sub check_next_extent()
{
    $stmt2 = "select o.obj#, o.owner#, o.name
        from sys.tab\$ t, sys.obj\$ o
        where t.obj# = o.obj# 
        and t.ts# = $tsnum and t.file# = $filenum and t.block# = $blocknum";
    $sth2 = $dbh->prepare($stmt2) || &show_error("Error while preparing $stmt2");
    $stmt3 = "select o.obj#, o.owner#, o.name
        from sys.ind\$ t, sys.obj\$ o
        where t.obj# = o.obj# 
        and t.ts# = $tsnum and t.file# = $filenum and t.block# = $blocknum";
    $sth3 = $dbh->prepare($stmt3) || &show_error("Error while preparing $stmt3");
    if ($type == 5)        #   table
    {
        $sth2->execute() ||
            &show_error("Error while executing $stmt2");
        ($objnum, $ownernum, $objname) = $sth2->fetchrow_array();
    }
    if ($type == 6)        #   index
    {
        $sth3->execute() ||
            &show_error("Error while executing $stmt3");
        ($objnum, $ownernum, $objname) = $sth3->fetchrow_array();
    }
    if ($next > $maxfreearr{$tsnum})
    {
        @{$errorarr1[$ec1++]} = ($ownernum, $objname, $type, $tsnum, $size, $extents, $next);
    }
    else 
    {
        @{$warnarr1[$wc1++]} = ($ownernum, $objname, $type, $tsnum, $size, $extents, $next);
    }
    $sth2->finish;
    $sth3->finish;
}

sub get_free_space()
{
    $stmt = "select tablespace_name, 
            round(sum(bytes)/1024/1024),
            round(max(bytes)/1024/1024)
        from dba_free_space
	where tablespace_name not in ('APPS_UNDOTS1','TEMP','RBS','RBS1','RBS2')
        group by tablespace_name";
    $sth = $dbh->prepare($stmt) || &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || &show_error("Error while executing $stmt");
    $aref = $sth->fetchall_arrayref;
    $sth->finish();
    foreach(@$aref)
    {
        ($tsname, $totfree, $maxfree)  = (@$_);
        $totfreearr{$tsname} = $totfree;
        $maxfreearr{$tsname} = $maxfree;
    }
}

sub get_total_space()
{

    $stmt = "select tablespace_name, 
            round(sum(bytes)/1024/1024)
        from dba_data_files
	where tablespace_name not in ('TEMP','RBS','RBS1','RBS2')
        group by tablespace_name";
    $sth = $dbh->prepare($stmt) || &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || &show_error("Error while executing $stmt");
    $aref = $sth->fetchall_arrayref;
    $sth->finish();
    foreach(@$aref)
    {
        ($tsname, $tot)  = (@$_);
        $totarr{$tsname} = $tot;
    }
}

sub get_user_name()
{
    $stmt = "select user#, name from sys.user\$";
    $sth = $dbh->prepare($stmt) || &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || &show_error("Error while executing $stmt");
    $aref = $sth->fetchall_arrayref;
    $sth->finish();
    foreach(@$aref)
    {
        ($usernum, $username) = (@$_);
        $usernamearr{$usernum} = $username;
    }
}


sub get_esc_ids()
{
my $sid;
my @esc_arr;

    $sid = $_[0];
    if (! -f $parfile)
    {
        return("");
    }
    open(PARFILE, $parfile) || die "Can't Open $parfile. $!";
    ($result, @dummy) = grep /^$sid:/, <PARFILE>;
    chomp($result);
    @esc_arr = split(':', $result);
    #foreach $i (@esc_arr)
    #{
        #print "<$i>\n";
    #}
    return(@esc_arr);
}

sub get_error_time()
{
my ($sid, $errorfile, $mtime, $time, $tdiff);

    ($sid, $errorfile)  = @_;
    if (! -f $errorfile) 
    {
        system("touch $errorfile");
    }
    $mtime = (stat($errorfile))[9];
    $time = timelocal(localtime);
    $tdiff = $time - $mtime;
    return($tdiff);
}

sub check_free_space()
{
    
    $ec1 = 0;
    $wc1 = 0;
    undef(@errorarr1);
    undef(@warnarr1);
    foreach $tsname (sort keys %totarr)
    {
        $tot = $totarr{$tsname};
        $tot = 1 if (!defined($tot) || $tot == 0);

        $totfree = $totfreearr{$tsname};
        $totfree = 0 if (!defined($totfreearr{$tsname})) ;
        $maxfree = $maxfreearr{$tsname};
        $maxfree = 0 if (!defined($maxfreearr{$tsname})) ;
        $pctfree = $totfree * 100 / $tot;
        #
        # If Maxfree < 200M and Pctfree <= 5%, push to errorarr
        #
        if (($maxfree <= 200) && ($pctfree <= 5))      
        {
             @{$errorarr1[$ec1++]} = ($tsname, $tot, $totfree, $maxfree, $pctfree);
        }
        elsif (($maxfree <= 250) && ($pctfree <= 10) && ($totfree <= 700))
        {
             @{$warnarr1[$wc1++]} = ($tsname, $tot, $totfree, $maxfree, $pctfree);
        }
    }
}

