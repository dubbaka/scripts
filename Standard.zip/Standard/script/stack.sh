#!/bin/sh
svrmgrl << !
set echo on
connect internal
oradebug setospid  $1
oradebug unlimit
oradebug dump TEST_STACK_DUMP 1
rem oradebug event 10046 trace name context off
exit
!
