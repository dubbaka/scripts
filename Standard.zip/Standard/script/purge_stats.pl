#!/usr/local/bin/perl

#
# Name    : purge_stat.pl
# Version : 1.1
# Date    : 05/14/2001
# Author  : Neeta Darragh
# Notes   : Deletes from perfstat tables data that is over 45 days old
#

#require "ctime.pl";
#use DBI;
#use Getopt::Std;

#!/usr/local/bin/perl
use lib '/oracle/product/perlmods/clnt9/lib';
#use lib '/oracle/product/perlmods/clnt964/lib';
use DBI;
use Getopt::Std;
require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";

$maillist = "coe-dba";
#$pagelist = "coe-dba-duty";
getopt('smp');
$sid = $opt_s if defined($opt_s) || &usage("");

    chomp($host = `uname -n`);
    print "Start time ", &ctime(time), "\n";
    $oracle_sid = $sid;
    # print "SID - $oracle_sid\n";
    &ora_home($oracle_sid);


    $dbh = DBI->connect("dbi:Oracle:", "", "") || die $DBI::errstr;
    #$dbh = DBI->connect("dbi:Oracle:$oracle_sid", "internal", "") || die $DBI::errstr;
    #$dbh = DBI->connect("$oracle_sid", "internal", "", "dbi:Oracle:") || die $DBI::errstr;
    #$dbh = DBI->connect("", "internal", "", "dbi:Oracle:") || die $DBI::errstr;

    $stmt = "select snap_id from perfstat.stats\$snapshot 
             where snap_time <= trunc(sysdate) - 10";
    $sth = $dbh->prepare($stmt) || &show_error("Error while preparing $stmt");
    $rc = $sth->execute() || &show_error("Error while executing $stmt");
    $aref = $sth->fetchall_arrayref;
    $sth->finish();

    foreach(@$aref)
    {
        ($snap_id)=(@$_);
        $dbh->do ("delete from perfstat.stats\$snapshot where snap_id=$snap_id");
    }

    print "End time ", &ctime(time), "\n";

sub ora_home
{
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    # print "SID - $oracle_sid\n";
    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            # print "Here $_\n";
            $oracle_home = (split(':'))[1];
            # print "$oracle_home - Home\n";
            # print "$oracle_sid - SID\n";
            $ENV{'ORACLE_SID'} = $oracle_sid;
            $ENV{'ORACLE_HOME'} = $oracle_home;
	    $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
        }
    }
    close(ORATAB);
}

