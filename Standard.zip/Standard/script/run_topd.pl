#!/oracle/product/perl

require "/usr/tools/oracle/Standard/script/perllib.pl";
require "getopts.pl";
require "stat.pl";
require "ctime.pl";

$database = $ARGV[0];
$ENV{'ORACLE_SID'} = $database;
$date = (localtime)[3];
$year = (localtime)[5];
$month = (localtime)[4]+1;
$min = (localtime)[1];
$hour = (localtime)[2];
$day = (localtime)[6];

##################  STD Compliance     ##########################
#  Pl add this piece of code in all Std Scripts at the beginning  
#  before staring any operations                                  
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!             
$thisScriptName="run_topd.pl";  # << Change this to standard script name
#
$stddate=`date -u +%Y%m%d`; chomp($stddate);
$stdlogfile="${thisScriptName}_${stddate}";
$stdlibpath="/usr/tools/oracle/Standard/lib";
$stdpidval="$$";
$actscriptname="$0";
$stdjobseq="${stddate}-${stdpidval}";
$stdcksum=`/oracle/product/perl $stdlibpath/StdCompProc.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname`;
if ( $stdcksum =~ "FAILED" ) {
	print "This script $actscriptname is not same as standard script $thisScriptName\nExiting..\n";
	exit 1;
} elsif ( $stdcksum =~ "SUCCESS" ) {
	print "This script is $actscriptname matching checksum with standard script $thisScriptName..Continuing..\n";
} elsif ( $stdcksum =~ "NOT_FOR_LINUX" ) {
	print "This script is $actscriptname and it is valid for Linux server..\nExiting..\n";
	exit 1;
} else {
	print "This script is $actscriptname error getting checksum with standard script $thisScriptName\nExiting..\n";
	exit 1;
}
###################################################################


chop($isoyear = `/bin/date +%Y`);
chop($isomon = `/bin/date +%m`);
chop($isodate = `/bin/date +%d`);
print "$isoyear $isomon $isodate";

#-----------------------------------------------------------------------------
##################  STD Compliance     ##########################
# If the script is used for all the database in this server
# like check_extend_all.pl, put this piece of code inside the loop
# for each databases using ORATAB.  Change the value for
# the variable "$mysid" to actual variable for each database
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
$stdsid="$database";  # << Change "$sid" to actual variable
system("/oracle/product/perl $stdlibpath/StdCompProc.pl begin_eachjob $stdjobseq $stdsid $stdlogfile");
###############################################################


&get_ora_home($oracle_sid);
$oracle_base = "/oracle";

`top_sqlarea.pl -s $database -b 2500 -d 10 |/usr/bin/tee $oracle_base/admin/$database/perf/topd/report.txt`;

(mkdir("$oracle_base/admin/$database/perf/topd/$isoyear.$isomon.$isodate",0755) || die "mkdir error") unless -d "$oracle_base/admin/$database/perf/topd/$isoyear.$isomon.$isodate";

`/bin/mv $oracle_base/admin/$database/perf/topd/report.txt $oracle_base/admin/$database/perf/topd/$isoyear.$isomon.$isodate/topd_rep.$database.$year.$month.$date.$hour.$min`;

##################  STD Compliance     ##########################
# Place this piece of code at the end of LOOP job for each database.
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_eachjob $stdjobseq $stdsid $stdlogfile");
###############################################################


##################  STD Compliance     ##########################
########  Pl add this piece of code in all Std Scripts ########
#     after completion of the script and before exit  #########
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_alljob $stdjobseq $stdsid $stdlogfile");
###############################################################



