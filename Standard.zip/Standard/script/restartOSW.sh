#!/bin/bash
NOTIFY2="$1"
if [ "$NOTIFY2 " = " " ]
then
NOTIFY2="ats-techops-cc-p1mon@cisco.com"
fi
echo $NOTIFY2
logfile="/tmp/OSWatcher.log"
cd /oracle/export/osw
dummy1=`ps -ef | grep OSWatcher.sh | grep -v grep | awk '{print $2}'`
if [ $dummy1 ]; then
echo OSW running pid ${dummy1} > $logfile
echo "*** OSWatcher running on pid ${dummy1} - Checked on "`date` >> $logfile
else
/oracle/export/osw/stopOSW.sh
echo OSW not running.. >> $logfile
echo OSW stopped >> $logfile
nohup /oracle/export/osw/startOSW.sh 60  48 gzip >> $logfile &
echo OSW started.. >> $logfile
cat $logfile | mailx -s "OSWatcher Status On  `hostname` ..  restarting OSW " $NOTIFY2
echo OSW started..
fi
echo OSW job done
