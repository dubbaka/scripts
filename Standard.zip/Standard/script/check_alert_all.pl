#!/oracle/product/perl
##!/usr/local/bin/perl
# Name: check_alert_all.pl
# History:
#	swei  01-APR-2004 created
#
require "stat.pl";
require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


use Getopt::Std;
use Time::Local;

$parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
$exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";


#............................................................................
#		Main
#............................................................................
    chomp($host = `/bin/uname -n`);
    #&get_pageexe();

    open (ALLTAB,"/var/opt/oracle/oratab")  || &show_error("Can't Open oratab", "$!");
    while (<ALLTAB>)
    {
    next if (/^#/ || /^\s/);
    ($sid, $ora_home, $db_flag) = split(/:/);
    print "$sid $db_flag \n";
    next if ($db_flag =~ /^N/ || $db_flag =~ /^n/ );

    ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($sid);

    $alertfile = "/oracle/admin/$sid/bdump/alert_$sid.log";
    $alerttemp = "/tmp/alert.$$";
    $lastline  = "/oracle/admin/$sid/bdump/.last_alert_line"; 
    $length    = `cat $alertfile|wc -l`; 

    if ( -r $lastline )
    {
       $lineno=`cat $lastline` ;
    }
    if ($lineno eq "" )
    {
       $lineno=0;
    } 
    $lineno =~ s/\s//g;
    $length =~ s/\s//g;
    system("tail +$lineno $alertfile > $alerttemp");
    $wc = `grep ORA- $alerttemp |grep -v ORA-01575 | grep -v ORA-01595 | wc -l`;
    if ($wc > 0 )
    {
       $errmsg = &msgfmt("i","`uname -n`","$sid","Alert File");
       &mailit("$errmsg",$alerttemp);
    }
    open(OUTFILE,"> $lastline");
       print OUTFILE "$length";
    close(OUTFILE);

    unlink($alerttemp);

    }
    close (ALLTAB);

