#!/usr/local/bin/perl
#-------------------------------------------------------------------------------
# SCCS INFO : passwd_change_tool.pl [1.21] 07/17/06 17:31:36
# CREATED   : ckarthik
# DATE      : 07/02/2003
# DESC      : Password Change utility
#-------------------------------------------------------------------------------
use    DBI             ;
use    Getopt::Std     ;
use    Time::Local     ;
use    File::stat      ;
select(STDERR); $| = 1 ;
select(STDOUT); $| = 1 ;
$Debug = 0;


#--->>> Begin Main 

&Set_Environment_Values ;
&Get_User_Names         ;
&Set_New_Passwords      ;
&Change_To_New_Password ;
&Update_Dblinks         ;
&Gen_Pwd_Verify_Function;
print"\n\n\n"           ;
exit(0)                 ;

#--->>> End Main 

#---------------------------
# 6. Gen_Pwd_Verify_Function
#---------------------------
sub Gen_Pwd_Verify_Function {

    foreach $Db (split(",",$DbList)) {
       $Ctr = 0;

       ($MyDb, $MyApsPwd, $MySysPwd, $MyOldSid) = (split(":",uc($Db)));
       $Msg   = "     * Generating Password verify function enable/disable in $MyDb";
       $Ln    = 70 - length($Msg);
       print "$Msg ","."x$Ln;

       $RemoteDbh = &Connect_Db("SYSTEM", "$MySysPwd", "$MyDb");

       $RSt6 = qq{SELECT upper(resource_name), upper(profile), limit FROM dba_profiles 
                  WHERE resource_name in ('PASSWORD_REUSE_MAX', 'PASSWORD_VERIFY_FUNCTION')};

       $RSh6 = $RemoteDbh->prepare($RSt6) ||  die "\n\n\n Prep Failed for [$RSt6]",$RemoteDbh->errstr,"\n\n\n";
       $RSh6->execute;

       $Fname6 = "${MyDb}_1_disable_pwd_verify.sql";
       $Fname7 = "${MyDb}_6_enable_pwd_verify.sql";
       open(FW6, ">${MyDb}/$Fname6") || die "\n\n\nCannot open new file $Fname6 $!\n\n\n";
       open(FW7, ">${MyDb}/$Fname7") || die "\n\n\nCannot open new file $Fname7 $!\n\n\n";

       while (($Resource, $Profile, $Limit) = $RSh6->fetchrow_array) {
          if ($Resource eq "PASSWORD_REUSE_MAX") {
             print FW6 "alter profile $Profile limit password_reuse_max unlimited;\n";
             print FW7 "alter profile $Profile limit password_reuse_max $Limit;\n";
          }
          elsif ($Resource eq "PASSWORD_VERIFY_FUNCTION") {
             print FW6 "alter profile $Profile limit password_verify_function null;\n";
             print FW7 "alter profile $Profile limit password_verify_function password_dontchange_function;\n";
          }
       }
       close(FW6);
       close(FW7);
       print "2 files Created.\n";
   }
}
      
#------------------
# 5. Update_Dblinks
#------------------
sub Update_Dblinks {

    if (! $OldSidList) {
       print "     * No Dblinks will be updated since OLDSID List not provided\n\n";
       return ;
    }

    foreach $Db (split(",",$DbList)) {
       $Ctr = 0;

       ($MyDb, $MyApsPwd, $MySysPwd, $MyOldSid) = (split(":",uc($Db)));
       $Msg   = "     * Updating Database link in $MyDb";
       $Ln    = 70 - length($Msg);
       print "$Msg ","."x$Ln;

       #$RemoteDbh = &Connect_Db("SYS", "$MySysPwd", "$MyDb");
       $RemoteDbh = &Connect_Db("SYSTEM", "$MySysPwd", "$MyDb");

       $Fname3 = "${MyDb}_4_dblink_change.sql";
       open(FWD, ">${MyDb}/$Fname3") || die "\n\n\nCannot open new file $Fname3 $!\n\n\n";
       $Fname4 = "${MyDb}_5_dblink_verify.sql";
       open(FWV, ">${MyDb}/$Fname4") || die "\n\n\nCannot open new file $Fname4 $!\n\n\n";

       $RSt1 = qq{SELECT DISTINCT userid||','||host FROM sys.link\$ WHERE upper(host) IN ($OldSidList) or host is null};

       $RSh1 = $RemoteDbh->prepare($RSt1) ||  die "\n Prep Failed [$RSt1]\n",$RemoteDbh->errstr,"\n\n\n";
       $RSh1->execute;

       $DblinkUsr = "";
       while (($DUsr) = $RSh1->fetchrow_array) {
          $DblinkUsr .= uc("${DUsr}:");
       }
       $DblinkUsr =~ s/:$//;

       $RSh1->finish;

       next if (! $DblinkUsr);

       $LSt1 = qq{SELECT password FROM OPS\$ORACLE.XXDBA_PASSWORD_CHANGE WHERE sid = ? AND username = ?};

       $LSh1 = $LocalDbh->prepare($LSt1) ||  die "\nPrep Failed [$LSt1]\n",$LocalDbh->errstr,"\n\n\n";
       
       foreach $CUsr (split(":",$DblinkUsr)) {

          ($UpdUsr,$UpdHost) = (split(",", $CUsr)); 

          $NewSid = $WhatIsOldSid{$UpdHost};

          $LSh1->execute($NewSid, $UpdUsr);

          $UpdPwd = "";
          ($UpdPwd) = $LSh1->fetchrow_array;

          if ($UpdPwd) {
             $RSt2 = qq{UPDATE sys.link\$ SET PASSWORD='$UpdPwd', HOST='$NewSid' WHERE upper(userid)=upper('$UpdUsr') AND upper(host)='$UpdHost'};
             $RSt3 = qq{UPDATE sys.link\$ SET HOST='$NewSid' WHERE userid is null AND upper(host)='$UpdHost'};
             $RSt4 = qq{$UpdUsr/$UpdPwd\@$NewSid};
          }
          else {
             foreach $BoundaryInfo (@BoundaryBbLink) {
                @MyBoundary = split(':', uc($BoundaryInfo)); 
                if (("$NewSid" eq "$MyBoundary[0]" ) && ("$UpdHost" eq "$MyBoundary[3]")) {
                   if (($MyBoundary[1] eq "$UpdUsr" ) && $MyBoundary[2]) {
                      $RSt2 = qq{UPDATE sys.link\$ SET PASSWORD='$MyBoundary[2]', HOST='$NewSid' WHERE upper(userid)=upper('$UpdUsr') AND upper(host)='$UpdHost'};
                      $RSt4 = qq{$UpdUsr/$MyBoundary[2]\@$NewSid};
                   }
                   elsif (("$MyBoundary[1]" eq "") && ($MyBoundary[2])) {
                      #---------------------------------------------------------------------------------
                      # Only password given, then all the users will have same password in that database
                      #--------------------------------------------------------------------------------- 
                      $RSt2 = qq{UPDATE sys.link\$ SET PASSWORD='$MyBoundary[2]', HOST='$NewSid' WHERE upper(host)='$UpdHost'};
                   }
                   elsif (("$MyBoundary[1]" eq "") && ("$MyBoundary[2]" eq "")) {
                      #---------------------------------------------------------------------------------
                      # Only password given, then all the users will have same password in that database
                      #--------------------------------------------------------------------------------- 
                      $RSt2 = qq{UPDATE sys.link\$ SET HOST='$NewSid' WHERE upper(host)='$UpdHost'};
                   }
                }
             }
             $RSt3 = "";
          }
          print FWD "$RSt2 ;\n" if ($RSt2);
          print FWD "$RSt3 ;\n" if ($RSt3);
          print FWV "Prompt >>>> Connecting to $RSt4\n" if ($RSt4);
          print FWV "connect $RSt4\n" if ($RSt4);
       }

       $RemoteDbh->disconnect;
       print FWD "UPDATE sys.link\$ SET PASSWORD='$MyCmsPwd' WHERE UPPER(userid) = 'CMS' AND host IS NULL;\n";
       print FWV "Prompt >>>> Connecting to CMS/$MyCmsPwd\n";
       print FWV "connect CMS/$MyCmsPwd\n";
       close(FWD) ;
       close(FWV) ;
       print " 2 file created\n";
    }
    print "\n";
}

#--------------------------
# 4. Change_To_New_Password
#--------------------------
sub Change_To_New_Password {

    foreach $Db (split(",",$DbList)) {
       ($MyDb, $MyApsPwd, $MySysPwd, $MyOldSid) = (split(":",uc($Db)));

       $Fname0 = "password_${MyDb}.sql";
       system("mkdir -p $MyDb");
       $Fname5 = "${MyDb}_0_backup_tables.sql";
       $Fname1 = "${MyDb}_2_password_change_by_fndcpass.sh";
       $Fname2 = "${MyDb}_3_password_change_by_alter.sql";
       open(FWF, ">${MyDb}/$Fname1") || die "\n\n\nCannot open new file $Fname1 $!\n\n\n";
       open(FWA, ">${MyDb}/$Fname2") || die "\n\n\nCannot open new file $Fname2 $!\n\n\n";

       chomp($TExt = `date +\%d\%b\%H\%M\%S`);
       open(FWB, ">${MyDb}/$Fname5") || die "\n\n\nCannot open new file $Fname5 $!\n\n\n";
       print FWB "create table ops\$oracle.link\$_$TExt as select * from sys.link\$;\n";
       print FWB "create table ops\$oracle.fnd_oracle_userid_$TExt as select * from apps.fnd_oracle_userid;\n";
       print FWB "create table ops\$oracle.fnd_user_$TExt as select * from apps.fnd_user;\n";
       print FWB "create table ops\$oracle.dba_user_$TExt as select * from sys.dba_users;\n";
       close(FWB);
       $Fname4 = "password_${MyDb}.csv";

       $RemoteDbh = &Connect_Db("SYSTEM", "$MySysPwd", "$MyDb");

       $Msg   = "     * Changing Password in $MyDb (Stored in $Fname0)";
       $Ln    = 70 - length($Msg);
       print "$Msg ","."x$Ln;

       $LSt1 = qq{ SELECT username, password,apusr FROM OPS\$ORACLE.$PwdTable 
                  WHERE sid = '$MyDb' and needtochange = 'Y' };
       $LSh1 = $LocalDbh->prepare($LSt1) ||  die "\nPrep Failed [$LSt1]\n",$LocalDbh->errstr,"\n\n\n";
       
       $LSh1->execute;

       open(FW, ">${MyDb}/$Fname0") || die "\n\n\nCannot open new file $Fname0 $!\n\n\n";
       open(FWX, ">${MyDb}/$Fname4") || die "\n\n\nCannot open new file $Fname4 $!\n\n\n";
       
       printf FW "%-23s %-20s\n","#*********************", "********************";
       printf FW "%-23s %-20s\n","# User Name","Password";
       printf FW "%-23s %-20s\n","#*********************", "********************";
       printf FWX "DB Name,USERNAME,Password\n";
       $Ctr=0;

       while (($NUsr, $NPwd, $NAps) = $LSh1->fetchrow_array) {
          next if ($NUsr eq "APPS");

          if ($NAps eq "Y") {
             print FWF "\$FND_TOP/bin/FNDCPASS apps/$MyApsPwd 0 Y system/$MySysPwd ORACLE $NUsr $NPwd\n";
             $Ctr++;
             $MyCmsPwd = $NPwd if ("$NUsr" eq "CMS"); 
          }
          else {
             print FWA "alter user $NUsr identified by $NPwd ;\n";
             $Ctr++;
          }
          printf FW "%-23s %-20s\n",$NUsr,$NPwd;
          #printf FWX "%-20s, \"%-23s\", \"%-20s\"\n", $MyDb, $NUsr,$NPwd;
          printf FWX "%-20s, %-23s, %-20s\n", $MyDb, $NUsr,$NPwd if ($NAps ne "Y");
       }

       $LSh1->finish;
       $RemoteDbh->disconnect;

       `chmod 600 ${MyDb}/$Fname0`;

       close(FW);
       close(FWX);
       close(FWF);
       close(FWA);
       print " 2 Files created.\n";
    }
    print "\n";
}


#---------------------
# 3. Set_New_Passwords
#---------------------
sub Set_New_Passwords {

    $Msg   = "     * Creating temporary table OPS\$ORACLE.$PwdTable";
    $Ln    = 70 - length($Msg);
    print "$Msg ","."x$Ln;

    $LSt1 = qq{SELECT 'X' FROM dba_tables WHERE table_name = '$PwdTable' AND owner = 'OPS\$ORACLE'};

    $LSh1 = $LocalDbh->prepare($LSt1) || die "\nPrep Faile[$LSt1]\n",$LocalDbh->errstr,"\n\n\n";
    $LSh1->execute;

    (($Exists) = $LSh1->fetchrow_array) ;
    $LSh1->finish;

    if ($Exists) {
       $Dst = "DROP TABLE OPS\$ORACLE.$PwdTable";
       $r  = $LocalDbh->do($Dst) || die "\nDo Failed[$Dst]\n",$LocalDbh->errstr,"\n\n\n" ;
    }

    
    $LSt1 = qq{CREATE TABLE OPS\$ORACLE.$PwdTable( sid          VARCHAR2(15) NOT NULL,
                                                   username     VARCHAR2(40) NOT NULL,
                                                   apusr        VARCHAR2(1)  DEFAULT 'N' NOT NULL,
                                                   password     VARCHAR2(40) , 
                                                   needtochange VARCHAR2(1)  DEFAULT 'Y' NOT NULL)};

    $r  = $LocalDbh->do($LSt1) || die "\nDo Failed[$LSt1]\n",$LocalDbh->errstr,"\n\n\n";

    print " Table Created\n";


    $Msg   = "     * Populating table with above collected usernames";
    $Ln    = 70 - length($Msg);
    print "$Msg ","."x$Ln;

    $Ctr = 0;
    foreach $MyIns  (@UserList) {
       ($InsSid,$InsUsr,$InsApUsr) = split(",",$MyIns);
       $LSt1 = qq{INSERT INTO OPS\$ORACLE.$PwdTable (sid,username,apusr) VALUES ('$InsSid','$InsUsr','$InsApUsr')};
       $r = $LocalDbh->do($LSt1) || die "\nDo.Failed[$LSt1]\n",$LocalDbh->errstr,"\n\n\n";
       $Ctr++;
    }

    print " $Ctr Rows Inserted\n\n";

    #--------------------------------------------------------------------------------------------
    # Following users will be added as not change, but these will be used for dblink update
    # Eg. DB Links connecting as apps will be changed to the new password
    #--------------------------------------------------------------------------------------------
    if ($Ctr) {
       foreach $Db (split(",",$DbList)) {
          ($MyDb, $MyApsPwd, $MySysPwd, $MyOldSid) = (split(":",uc($Db)));

          $LSt1 = qq{INSERT INTO OPS\$ORACLE.$PwdTable (sid, username, password, apusr, needtochange) 
                     VALUES ('$MyDb','APPS', '$MyApsPwd', 'Y', 'N')};
          $r = $LocalDbh->do($LSt1) || die "\nDo Failed [$LSt1]\n",$LocalDbh->errstr,"\n\n\n";
          $Ctr++;
       }
    }

    $Msg   = "     * Assinging new passwords in OPS\$ORACLE.$PwdTable";
    $Ln    = 70 - length($Msg);
    print "$Msg ","."x$Ln;

    $LSt1 = qq{ SELECT distinct username FROM OPS\$ORACLE.$PwdTable WHERE needtochange ='Y' AND password IS NULL };
    $LSh1 = $LocalDbh->prepare($LSt1) || die "\nPrep Failed[$LSt1]\n",$LocalDbh->errstr,"\n\n\n";
    $LSh1->execute;

    $LSt2 = qq{UPDATE OPS\$ORACLE.$PwdTable SET password = ? WHERE username = ?};
    $LSh2 = $LocalDbh->prepare($LSt2) || die "\nPrep Failed[$LSt2]\n",$LocalDbh->errstr,"\n\n\n";

    $i = 0;
    $Ctr = 0;
    while (($MyUsr) = $LSh1->fetchrow_array) {
       $x=$LSh2->execute($PwdList[$i],$MyUsr) || die "\nExec Failed[$LSt2]\n",$LocalDbh->errstr,"\n\n\n";
       $i = 0 if ($#PwdList <= $i++ );
       $Ctr = $Ctr + $x;
    }
    $LSh1->finish;
    $LSh2->finish;

    if ($#PwdExceptionList ge 0 ) {

       $LSt3 = qq{UPDATE OPS\$ORACLE.$PwdTable SET password = ? WHERE username = ? AND sid LIKE ?};
       $LSh3 = $LocalDbh->prepare($LSt3) || die "\nPrep Failed[$LSt3]\n",$LocalDbh->errstr,"\n\n\n";

       foreach $MyExp (@PwdExceptionList) {
          @MyTempExp = split(':', $MyExp);
          if ($#MyTempExp eq 2 ) {
             $MyExpSid = $MyTempExp[0];
             $MyExpUsr = $MyTempExp[1];
             $MyExpPwd = $MyTempExp[2];
          }
          else {
             $MyExpSid = '%';
             $MyExpUsr = $MyTempExp[0];
             $MyExpPwd = $MyTempExp[1];
          }
          $x=$LSh3->execute(uc($MyExpPwd), uc($MyExpUsr), uc($MyExpSid)) || die "\n\n\n",$LocalDbh->errstr,"\n\n\n";
       }
       $LSh3->finish;
    }

   
   $sp = 0;
   foreach $StdPwd (@StdPassword) {
      if (++$sp == 1) {
         $LSt4 = qq{UPDATE OPS\$ORACLE.$PwdTable SET password = ? WHERE username = ? };
         $LSh4 = $LocalDbh->prepare($LSt4) || die "\nPrep Faile [$LSt4]\n",$LocalDbh->errstr,"\n\n\n";
      }

      ($MyExpUsr,$MyExpPwd)  = split(':', $StdPwd);
      $x=$LSh4->execute(uc($MyExpPwd), uc($MyExpUsr)) || die "\n\n\n",$LocalDbh->errstr,"\n\n\n";
   }
   $LSh4->finish if ($sp);

   print " $Ctr Rows Updated\n\n";
}

#------------------
# 2. Get_User_Names
#------------------
sub Get_User_Names {

    print "\n\tList Database Names for Password Change.\n";
    print "\t----------------------------------------\n";
    print "\tEg.\n";
    print "\tFor     11i, SID:appspwd1:systempwd1:OLDSID(from where link\$ exported)1\n";
    print "\tFor Non 11i, SID:appspwd1:systempwd1:OLDSID(from where link\$ exported)1\n";
    print "\t    ESJTCC:apasswd:spaswd:OLDSID2\n\n";
    print "\t    EODTCC::spaswd:OLDSID2\n\n";
   
    print "\tEnter database Name........................ : ";
    $DbList = "";

    while (true) {
       chomp($GetList = <STDIN>);

       if (! $GetList) {
          $DbList =~ s/,$//;
          last ;
       }


       ($MyDb, $MyApsPwd, $MySysPwd, $MyOldSid) = (split(":",uc($GetList)));
     
       $RemoteDbh = &Connect_Db("SYSTEM", "$MySysPwd", "$MyDb");

       if ($DbList =~ /$GetList/) {
          $GetList = "";
          print "\tAlready Entered, Enter Next DB............. : ";
          next ;
       }

       if (! $RemoteDbh) {
          $GetList = "";
          print "\tEnter database Name........................ : ";
          next ;
       }

       $DbList.="${GetList},";
       print "\t<ENTER> if no more to enter................ : ";
    }

    die "\n\n\n\t!!! Not Entered Database Name..... Exiting\n\n\n" if (! $DbList);


    print "\n\n\tFYI : Password file may contain info like this\n";
    print "\t----------------------------------------------\n";
    print "\t<password>             - Pwd will be used for any user across above given db's.\n";
    print "\t<user>:<password>      - Pwd will be used only for the specified user across above given db's.\n";
    print "\t<db>:<user>:<password> - Pwd will be used only for the specified user and database.\n";
    print "\t<NewDb>:<user>:<password>:<OldDb> - Pwd will be used only for db link update(eg. Boundary system).\n\n";
    print "\n\n\tEnter password file............... : ";

    while(true) {
       chomp($PwdFile = <STDIN>);
       last if (-f $PwdFile) ;

       die "\n\n\n\t!!! Not Entered Password File Name..... Exiting\n\n\n" if (! $PwdFile) ;
       print "\tNot Exists, Enter File Name <Enter> to Exit : ";
    }

    print "\n\n";

    chomp(@PwdList = `grep -v : $PwdFile`);
    chomp(@PTemp = `grep : $PwdFile`);
    if ($#PTemp ge 0 ) {
       foreach $MyExp (@PTemp) {
          @MyTempExp = split(':', uc($MyExp));
          die "\n\n\n\t!!! Invalid Format in the Password File[$MyExp] ..... Exiting\n\n\n" if ($#MyTempExp gt 3 );
          if ($#MyTempExp eq 3) {
             push(@BoundaryBbLink, uc($MyExp)) ;
             $OldSidList .= "'$MyTempExp[3]',";
             $NewSidList .= "'$MyTempExp[0]',";
             %WhatIsOldSid = (%WhatIsOldSid, "$MyTempExp[3]", "$MyTempExp[0]" );
          }
          else {
             push(@PwdExceptionList,$MyExp);
          }
       }
    }

    $LocalDbh = &Connect_Db("", "", "");

    foreach $Db (split(",",$DbList)) {
       ($MyDb, $MyApsPwd, $MySysPwd, $MyOldSid) = (split(":",uc($Db)));

       %WhatIsOldSid = (%WhatIsOldSid, "$MyOldSid", "$MyDb" );

       $NewSidList .= "'$MyDb',";
       $OldSidList .= "'${MyOldSid}'," if ($MyOldSid);
       $Msg   = "     * Collecting user names from $MyDb";
       $Ln    = 70 - length($Msg);
       print "$Msg ","."x$Ln;

       $RemoteDbh = &Connect_Db("SYSTEM", "$MySysPwd", "$MyDb");
       $Ctr = $#UserList;

       $RSt1 = qq{SELECT '$MyDb'||','||username||',N'  FROM dba_users WHERE account_status = 'OPEN'
                 AND  username NOT IN ('APPS', 'APPLSYS','SYSTEM','SYS','ORDPLUGINS','EMAN_APMON',
                                            'ORDSYS', 'DUMMY','SSOSDK','OUTLN', 'APPLSYSPUB','CTXSYS',
                                            'XXCONC', 'PERFSTAT', 'DBA_REPORTS', 'JAVAADM', 'QUESTADM',
                                            'JSELVARA','JULIALEE','EEVANGEL','HISINGH','DOCALHOU','CHETHOMA',
                                            'KKALYANA','AJAVERMA','ERP_AGENT','PPAREEK','SCOTT',
                                            'UNIVDB','PHULAXIS','SPOTADM3','DBAREAD','JOB_MONITOR','DBA_MONITOR',
                                            'CHOKIM','TOAD','XXDBA','SPOTADM','CIBERADM',
                                            'I2I','KARTHIK','SPOTLIGHT','EXPUSER','EXPREAD','ASHOK','ASJOSHI',
                                            'MDSYS', 'OWAPUB','DBSNMP','SPATRICK', 'ORA_WEB_USR','CLRCONN')
                  AND    username NOT LIKE 'PORTAL%'
                  AND    username NOT LIKE '\%\$\%'};

       $RSt1 = qq{SELECT '$MyDb'||','||a.username||','||decode(b.apusr ,null,'N',b.apusr)
                  FROM   (SELECT username FROM dba_users WHERE account_status = 'OPEN') a,
                         (SELECT oracle_username ,'Y' apusr FROM applsys.fnd_oracle_userid) b
                  WHERE  a.username = b.ORACLE_USERNAME(+)
                  AND    a.username NOT IN ('APPS', 'APPLSYS','SYSTEM','SYS','ORDPLUGINS','EMAN_APMON',
                                            'ORDSYS', 'DUMMY','SSOSDK','OUTLN', 'APPLSYSPUB','CTXSYS',
                                            'XXCONC', 'DBA_REPORTS', 'JAVAADM', 'QUESTADM',
                                            'JSELVARA','JULIALEE','EEVANGEL','HISINGH','DOCALHOU','CHETHOMA',
                                            'KKALYANA','AJAVERMA','ERP_AGENT','PPAREEK','SCOTT',
                                            'UNIVDB','PHULAXIS','SPOTADM3','DBAREAD','JOB_MONITOR','DBA_MONITOR',
                                            'CHOKIM','TOAD','XXDBA','SPOTADM','CIBERADM',
                                            'I2I','KARTHIK','SPOTLIGHT','EXPUSER','EXPREAD','ASHOK','ASJOSHI',
                                            'MDSYS', 'OWAPUB','DBSNMP','SPATRICK', 'ORA_WEB_USR','CLRCONN')
                  AND    a.username NOT LIKE 'PORTAL%'
                  AND    a.username NOT LIKE '\%\$\%' } if ($MyApsPwd);

       $RSh1 = $RemoteDbh->prepare($RSt1) || die "\nPrep Failed [$RSt1]\n",$RemoteDbh->errstr,"\n\n\n";
       $RSh1->execute;

       $i = $Ctr;
       while(($Str) = $RSh1->fetchrow_array ){ 
          $Ctr++;
          $UserList[$Ctr] = $Str;
       }
       $RSh1->finish;
       $i = $Ctr - $i;

       print " $i Users Collected\n";
       $RemoteDbh->disconnect;
    }
    $OldSidList =~ s/,$//;
    $NewSidList =~ s/,$//;
    print "\n";

    if ($Debug) {
       $j=0;
       foreach $a (@UserList) {
          $j++;
          print "$j . $a\n";
       }
   }
}

#------------------
# 0. Sub Connect_Db
#------------------
sub Connect_Db {

    #&Connect_Db("APPS","$AppsPwd", "$SID");

    my $Dh;
    $ConUsr = $_[0];
    $ConPwd = $_[1];
    $ConSid = $_[2];

    $OldHome = $ENV{'ORACLE_HOME'};
    if ($ConUsr) {
       if    (-l "/oracle/product/current") { $ENV{'ORACLE_HOME'} = '/oracle/product/current'; }
       elsif (-d "/oracle/product/8.1.7.4") { $ENV{'ORACLE_HOME'} = '/oracle/product/8.1.7.4'; }
       elsif (-d "/oracle/product/9.2")     { $ENV{'ORACLE_HOME'} = '/oracle/product/9.2'    ; }

       $Dh = DBI->connect("dbi:Oracle:", "$ConUsr/$ConPwd\@$ConSid", "",{PrintError=>0} );
    }
    else {
       $Dh = DBI->connect("dbi:Oracle:", "", "",{PrintError=>0} );
    }

    if ("$DBI::errstr" ne "") {
       print "\n\t!!! FAILED to Connect [$ConUsr/$ConPwd\@$ConSid] due to\n\t!!! $DBI::errstr\n\n";
       return;
    }
    $St1 = 'SELECT name from v$database';
    $Sh1 = $Dh->prepare($St1) || die "\nPrep Failed [$St1]\n",$Dh->errstr,"\n\n\n";
    $Sh1->execute;
    ($ConnectedDbName) = $Sh1->fetchrow_array;
    $Sh1->finish;

    if ($ConUsr) {
       $St1 = 'SELECT count(*) from sys.link$';
       $Sh1 = $Dh->prepare($St1) || die "\nPrep Failed[$St1]\n",$Dh->errstr,"\n\n\n";
       $Sh1->execute;
       ($ConnectedDbName) = $Sh1->fetchrow_array;
       $Sh1->finish;
    }
    $ENV{'ORACLE_HOME'} = "$OldHome";
    return($Dh);
}

#--------------------------
# 1. Set_Environment_Values
#--------------------------
sub Set_Environment_Values {

   $AppsEnvOk        = "N"                     ;
   chomp($Owner   = $ENV{'LOGNAME'})           ;
   chomp($Machine    = `hostname`)             ;
   $FndPass          = '$FND_TO/bin/FNDCPASS'  ;
   $OracleHome       = $ENV{'ORACLE_HOME'}     ;
   $TwoTask          = $ENV{'TWO_TASK'}        ;
   $TnsAdmin         = $ENV{'TNS_ADMIN'}       ;
   $Sid              = $ENV{'ORACLE_SID'}      ;
   $PwdTable         = "XXDBA_PASSWORD_CHANGE" ;
   %WhatIsOldSid     = ()                      ; 
   $PwdFile          = ""                      ;
   @PwdList          = ()                      ;
   @PwdExceptionList = ()                      ;
   @BoundaryBbLink   = ()                      ;
   @UserList         = ()                      ;
   @StdPassword      = ('appsro:read0nly'      ,
                        'sabrix:teamw0rk'      ,
                        'tbm0:teamw0rk'        ,
                        'tax_server:teamw0rk'  ,
                        'gesadm:rep1icat3'     ,
                        'coreadm:rep1icat3'    ,
                        'aqadm:rep1icat3'      ,
                        'ops$coreadm:rep1icat3',
                        'ops$gesadm:rep1icat3' ,
                        'ops$odsadm:rep1icat3' ,
                        'odsmetaadm:rep1icat3' ,
                        'ods_web:guessme'     );
   $OldSidList       = ""                      ;
   $NewSidList       = ""                      ;
   $LocalDbh         = ""                      ;
   $RemoteDbh        = ""                      ;
   $MyCmsPwd         = ""                      ;
   $AppsPwd       =~ s/ //g;
      
    die "\n\n\n\t!!!!! Warning : You need to run this ONLY from database server !!!!!\n\n\n" if ($Owner ne 'oracle');

    print "\n\n\t","*"x66,"\n";
    print "\t\tYou are running from $Sid ($OracleHome)\n";
    print "\t","*"x66,"\n";
    print "\tDatabase     : $Sid\n";
    print "\tOracle Home  : $OracleHome\n";
    print "\tREQUIRED     : 1. SYS and SYSTEM passwords should be same\n";
    print "\t               2. If 9i, system \& ops\$oracle should have SELECT privs on sys.link\$\n\n";

}

