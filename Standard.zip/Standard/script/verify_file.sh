#!/bin/ksh
#set -x
#
#*************************************************************************************************************************
# Created by : Vaishalee
# Modified by : Bidhu Das
# Modified Date : 08/22/2006
# To be called from add_space.sh
# Modified Reason :1. verify while adding  multiple volumes for same tablespace
#		   2. verify while adding volumes to multiple tablespaces
#		   3. Checks the raw volume size with the size mentioned in add datafile command
#		   4. Checks the existence of ORACLE_SID in the volume to be added 
#		   5. Matches volume pattern with the controlfile volume pattern, in case it does not find ORACLE_SID in volume to be added
#		   6. Checks the use of this raw volume by using fuser as lsof takes lot of time for some instances
#		   7. Make sure that the correct volumes are getting added to archive tablespaces
#		   8. Also it has the provision i,e, not to add space to some tablespaces which can be defined under a variable
#
#	           For step 7 and 8, you need to add the tablespace name separated by spaces to the following variables :
#		       XXTBLSP => Contains the archive tablespace name  . For ex : XXTBLSP="XXCADD XXCADX"
#		       DONTADDTBLSP => Contains the tablespace name where space should not be added . For ex : DONTADDTBLSP="XXABC XXDEF"
#
# Constraint : You can not add space to both archive and standard tablespaces at the same time which is only applicable for SJPROD
#              Add space in terms of MB only i,e, 500M, 1000M, 2000M or 4000M
#
# Usage      : it will be called from add_space.sh script only
#*************************************************************************************************************************
#  01/08/07 raraveet            Std compliance phase-2
#  01/11/07 bidhu/srameneni     Will prompt user if vol name has diffrence
#
#
#Please set following variables as per the environment
#-----------------------------------------------------
##################  STD Compliance     ##########################
#  Pl add this piece of code in all Std Scripts at the beginning
#  before staring any operations
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
thisScriptName="verify_file.sh"  # << Change this to standard script name
#
stddate=`date -u +%Y%m%d%H%M`
stdlogfile="${thisScriptName}_${stddate}"
stdlibpath="/usr/tools/oracle/Standard/lib"
stdpidval=$$
actscriptname=$0
stdjobseq="${stddate}-${stdpidval}"
stdcksum=`/oracle/product/perl $stdlibpath/StdCompProc.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname`
if [ "$stdcksum" = "FAILED" ]
then
        echo
        echo "This script $actscriptname is not same as standard script $thisScriptName"
        echo "Exiting.."
        exit 1
fi

if [ "$stdcksum" =  "SUCCESS" ]
then
        echo
        echo "This script is $actscriptname matching checksum with standard script $thisScriptName..Continuing.."
fi

###################################################################

##################  STD Compliance     ##########################
# If the script is used for all the database in this server
# like check_extend_all.pl, put this piece of code inside the loop
# for each databases using ORATAB.  Change the value for
# the variable "$mysid" to actual variable for each database
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
stdsid="$ORACLE_SID"  # << Change "$sid" to actual variable
/oracle/product/perl $stdlibpath/StdCompProc.pl begin_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName
###############################################################


#This two parameters are valid for only SJPROD. Keep them empty for other DBs
#List of archive tablespaces to be checked
#if [ $ORACLE_SID = "PROD1" ] || [ $ORACLE_SID = "PROD2" ]
#then
XXTBLSP=""
XXRULE=arch
#fi

success=1
#List of tablespaces where files should not be added
DONTADDTBLSP=""

#pattern to be checked to verify the datafile
DBFLPTRN=$ORACLE_SID

#set required flags
CHKARCH=N
#
#-----------------------------------------------------------------
# Remove/Initialize the existing tmp files created by this script
#-----------------------------------------------------------------
#
if [ -f volsz_$ORACLE_SID ]
then
  rm volsz_$ORACLE_SID
fi
if [ -f filesz_$ORACLE_SID ]
then
  rm filesz_$ORACLE_SID
fi
#
#-------------------------------------------------------------
#get the tablespace name and filenames from add_datafile.sh
#-------------------------------------------------------------
#
tblspc=`grep -i "alter tablespace" add_datafile.sh|grep -v "^#" | grep -v "^--"|tr -s " " | tr " " "|" | awk -F"|" '{print $3}'`
filenm=`grep -i "\/dev\/" add_datafile.sh|grep -v "^#"|grep -v "^--"|awk -F' ' '{print $(NF-2)}'|tr "'" " "`

#grep -i "size" add_datafile.sh|grep -v "^#"|grep -v "^--"|awk -F'/' '{print $NF}'| awk  -F- '{print substr($1,3)}' > volsz_$ORACLE_SID
#grep -i "size" add_datafile.sh|grep -v "^#"|grep -v "^--"|awk -F' ' '{print $NF}'|awk -Fm '{print $1}'|awk -FM '{print $1}' > filesz_$ORACLE_SID

echo "\nVerifying the filenames and tablespaces.....\n" 

#
#-------------------------------------------------------------
#Check if files are being added into unwanted tablespaces
#-------------------------------------------------------------
#
for j in `echo $tblspc`
 do
   for i in `echo $DONTADDTBLSP`
     do
	if [ "$i" = $j ]
	then
		echo "No files should be added into $tblspc"
		echo "this tablespace data is of temporary nature."
		echo "Please mail to primary DBA if you get any alerts for this tablespace."
		echo "exiting..."
                return 1
		exit
	fi
    done
 done
#
#-------------------------------------------------------------
#Verify the volume size with the size mentioned in command line
#--------------------------------------------------------------
#
#   szdiff=`diff volsz_$ORACLE_SID filesz_$ORACLE_SID | wc -l`
#     if [ $szdiff -ne 0 ];then
#     echo "Please check the file size mentioned for $flnm."
#     echo "The size doesn't match with the file size."
#     echo "Exiting..."
#     return 1
#     exit
#  fi
#
#-------------------------------------------------------------
# Check if Volume Pattern contains ORACLE_SID
#-------------------------------------------------------------
#
pattern_match=0
for i in `echo $filenm`
do
	dbchk=`echo $i|grep -i $DBFLPTRN`
	
	if [ -z "$dbchk" ]
	then
                pattern_match=1
#		echo "Pattern $filenm Does not match with SID name $ORACLE_SID".
	fi
done

#
#
#----------------------------------------------------------
#Check if right file is being added for archive tablespaces
#----------------------------------------------------------
#
for j in `echo $tblspc`
 do
   for i in `echo $XXTBLSP`
    do
	if [ $j = $i ]
        then
		CHKARCH=Y
         fi
    done
 done
#
#----------------------------------------------------
#Check if arch files are added in archive tablespaces
#----------------------------------------------------
#
for i in `echo $filenm`
do
	chkarchfile=`echo $i|grep $XXRULE`
	if [ $CHKARCH = Y -a -z "$chkarchfile" ]
	then
		echo "Please add arch file to $XXTBLSP tablespaces"
		echo "file $i is not archive file"
		echo "Please use check_free_vol_arch.sh to find out the free volumes."
		echo "Exiting..."
                return 1
		exit
	elif [ $CHKARCH = N -a ! -z "$chkarchfile" ]
	then
		echo "You are trying to add archive volume to $tblspc tablespace."
		echo "file $i is archive volume"
		echo "Please select another file which is not arch file."
		echo "Exiting..."
                return 1
		exit
	fi

done
#
#------------------------------------------
#Check the existence of raw volume on host
#------------------------------------------
#
for i in `echo $filenm`
do
	if [ ! -c $i ]
	then
		echo "file $i is not found"
		echo "Please verify the filename." 
		echo "Exiting..."
                return 1
                exit
        fi
done
#
#------------------------------------------
#Check if file is already in use
#------------------------------------------
#
platform=`uname -s`
for i in `echo $filenm`
do
#lsof $i >/dev/null 2>/dev/null
#	if [ $? -eq 0 ]
 if [ $platform = 'SunOS' ]
  then
  ss=`fuser $i|awk '{print NF}'|wc -l`
 elif [ $platform = 'HP-UX' ]
  then
  ss=`fuser $i|awk '{print NF}'`
 fi
 if [ $ss -gt 0 ]
     then
      echo "file $i is being used."
      echo "Please select another file and try again."
      echo "Exiting..."
      return 1
      exit
 fi
done
#-----------------------------------------------------------------------------------------------------------------------
# Check Volume Pattern matches with the pattern of controlfile only when volume pattern does not contain ORACLE_SID
#-----------------------------------------------------------------------------------------------------------------------
#
#Check the pattern with Volumes already added to DB
if [ "$pattern_match" !=  0 ]
then
echo Checking the volume pattern with existing volume pattern of controlfile .............
sqlplus -s /nolog <<EOF
connect /
spool control_$ORACLE_SID
set head off
set pages 0
set termout off
select distinct substr(name,1,instr(name,'/',-1,1)+2)  from v\$controlfile;
spool off
EOF
src_pattern=`cat control_$ORACLE_SID.lst`
for i in `echo $filenm`
do
     dbchk1=`echo $i|grep -i $src_pattern`
     if [ -z "$dbchk1" ]
     then
	echo "Please check the filename $i."
        echo "because the file does neither contain $ORACLE_SID nor same as Controlfile Pattern ...................."
	echo
	echo
        echo "In case you want to add this volume , pl write Y"
	echo
	echo
        read ans
        if [ $ans = "Y" ] || [ $ans = "y" ]
        then
            echo "All other checks are completed successfully."
            return 0
        else
            echo "Exiting..."
            return 1
	    exit
        fi
    fi
done
fi
echo "All checks are completed successfully."

##################  STD Compliance     ##########################
# Place this piece of code at the end of LOOP job for each database.
/oracle/product/perl $stdlibpath/StdCompProc.pl end_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName
###############################################################


##################  STD Compliance     ##########################
########  Pl add this piece of code in all Std Scripts ########
#     after completion of the script and before exit  #########
/oracle/product/perl $stdlibpath/StdCompProc.pl end_alljob $stdjobseq ALL $stdlogfile $thisScriptName

###############################################################
