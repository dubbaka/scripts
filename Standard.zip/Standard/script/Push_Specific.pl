#!/usr/local/bin/perl 
# biddas Aug 31 2006 Modified : Exclude some hosts for not pushing the standard scripts
# swei  October 2, 2003 created
# ..............................................................................
# Create /usr/tools/oracle/Standard and subdirs on all hosts in dbts_instance
# Push contents of cruise:/dbcode/src/standard to all hosts in dbts_instance
#
# ..............................................................................
eval 'use Oraperl; 1' || die $@ if $] >= 5;
use POSIX;

$SCRIPT = "$ARGV[0]";
print "script name : $SCRIPT\n";
$CKSUM = ".cksum."."$SCRIPT";

$SIG{CHLD} = 'IGNORE';
&THE_INIT();
&SIDS();
exit;

sub show_error()
{

    print "$_[0]. $DBI::errstr\n";
#    exit (1);
}


sub THE_INIT
{
	$space_buffer = ' ' x 3000;
	$output_home = "/users/oracle/swei";
	$max_procs=16;
	$date=`/bin/date`;
	print "Starting: $date";

	chdir $output_home;
	`/bin/rm sqlnet.log 2>/dev/null`;

	$ENV{'ORACLE_HOME'} = '/oracle/product/9.2.0.5';
        $ENV{'ORACLE_SID'} = 'DBAPROD';
	$user_password = 'admin_user';
	$db_password = `/users/oracle/bin/.dbts_in`;

	$lda = &ora_login('', $user_password, $db_password) 
	       || die "Can't connect $ora_errstr\n";

	$statement = <<EOFEOF;
        select distinct host
          from dbts_instance
       where host not in ('swans','einfoprd-db','cdetsdb-qa','cdetsdb-prd','batis')
--       and host in ( 'triton','radian','cprdb-stage-1-new')
--       and host in ( 'hpquadpot')
         order by 1 asc
EOFEOF

	$csr = &ora_open($lda, $statement) || die $ora_errstr;
	$pcounter=0;
	while(@data = &ora_fetch($csr))
	{
	#	@tns_alias[$pcounter] = @data[0];
		@machines[$pcounter]  = @data[0];
	#	@passwd[$pcounter]    = @data[2];
		$pcounter++;
	}

	&ora_close($csr);
	&ora_logoff($lda);
} # INIT

sub SIDS
{
  $user = "system";
  $version_query = <<EOFEOF;
select version from v\$instance
EOFEOF

  while (@machines)
  {
        #$v2_two_task = pop(@tns_alias);
        $machine     = pop(@machines);
        #$password    = pop(@passwd);
#	print "$machine ";
        `ping $machine 1`;
        if ($? == 0 )
   {
      
       alarm 360;
       $SIG{ALRM} = sub { die "timeout" };
       eval 
       {  
	print "$SCRIPT : $CKSUM \n";
	system("/usr/local/bin/scp -o BatchMode=yes -o NumberOfPasswordPrompts=1 -o KeepAlive=no /dbcode/src/standard/script/$SCRIPT $machine:/usr/tools/oracle/Standard/script");
	system("/usr/local/bin/scp -o BatchMode=yes -o NumberOfPasswordPrompts=1 -o KeepAlive=no /dbcode/src/standard/script/$CKSUM $machine:/usr/tools/oracle/Standard/script");
#     system("/usr/local/bin/scp -o BatchMode=yes -o NumberOfPasswordPrompts=1 -o KeepAlive=no /dbcode/src/standard/lib/StdCompFunctions.pl $machine:/usr/tools/oracle/Standard/lib");
      };
       alarm 0;
        if ($@ =~ /timeout/ ) {  ## $@ is set by the eval block
           # Timeout is happening, don't keep trying
           print "Cannot ssh : -----------------------------> $machine\n";
	   open(PS, "ps -ef| grep -v grep |grep $machine|grep -i batch|");
	   @ps_data = <PS>;
	   close(PS);
	    foreach (@ps_data)
	   {
	   @r=split(/\s+/);
	    $pid=$r[2];
       	   kill (9,$pid);
	   }
        }

    if ($? != 0)
    {
	print "Problem MACHINE ================================== $machine \n";
    }
    else
    {
        print "$machine \n";
    } 
   }
  } #end of while

	$date=`/bin/date`;
	print "Ended: $date";
} # SIDS
