#!/oracle/product/perl
##!/usr/local/bin/perl
# .....................................................................
#	Name: kill_orphan.pl
#	History:
#		swei   08-mar-2003   created
#					to kill oracle orphan processes
#					first check the existence
#  swei  Mar-19-2004 Add msgfmt/mailit function
#
# .....................................................................
use Oraperl;
use DBI;
use Getopt::Std;

require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;
$parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
$exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";


getopt('smu');

if ($opt_u )
{ &usage(); }
chomp($hostname = `uname -n`);
$hostname =~ tr /a-z/A-Z/;
$sid = $opt_s ? $opt_s : &usage();
$mailto = $opt_m if defined($opt_m);
$output_file = "/tmp/kill_orphan.log";
$exp = "";

# ...................................................................
#		Main
# ...................................................................
    &ora_home($sid);
    if ($sid eq "CECPROD")
	{   $exp = "CECPROD8"; 
       #     print "$exp \n";
        }
    &get_pid(); 
    if ( -e $output_file )
    {
    $errmsg = &msgfmt("i","`uname -n`","$sid","Kill orphan process");
    &mailit("$errmsg",$output_file);

#	`/usr/bin/mailx -s "$sid: Kill orphan processes on \`date\` " $mailto < $output_file`;
    }
    unlink($output_file);
exit; 

sub ora_home()
{
my $oracle_sid;

    $oracle_sid = $_[0];
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || &show_error("Can't Open /etc/oratab", "$!");
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_SID'}  = $oracle_sid;
            $ENV{'ORACLE_HOME'} = $oracle_home;
        $ENV{'LD_LIBRARY_PATH'} = "$ora_home/lib";
        $ENV{'SHLIB_PATH'} = "$ora_home/lib";
        $ENV{'TNS_ADMIN'} = "$ora_home/network/admin";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = '$oracle_home/ocommon/nls/admin/data';
        $ENV{'ORA_NLS33'} = '/oracle/product/clntcurr/ocommon/nls/admin/data';
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = '/oracle/product/clntcurr/ocommon/nls/admin/data';
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }


        print "Sid $oracle_sid home $ora_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();

        }
    }
    close(ORATAB);
}


sub usage()
{
    print "\n";
    print "Usage: \n";
    print "kill_orphan.pl -s SID -m mailid\n";
    exit (1);
}

sub get_pid()
{
    if ($exp eq "")
    {
    @pids = (`ps -aef|grep oracle$sid|grep -v grep`);
    }
    else
    {
    @pids = (`ps -aef|grep -v "$exp"|grep oracle$sid|grep -v grep`);
    }

    $dbh = DBI->connect("", "", "","dbi:Oracle:$sid") || die $ora_errstr;

    $stmt="select spid from v\$process where spid= ?";

    $csr = $dbh->prepare($stmt) || print "Error while preparing $stmt";

    for (@pids) {
    @r=split(/\s+/);
    $pid=$r[2];
#    print "$pid\n";
     $csr->bind_param(1,"$pid");
     $csr->execute() || print "Error while executing $stmt";
     $rc=$csr->fetchrow_array();
     if ($rc eq "")
     {   print "empty $pid \n";
         open(LOGFILE,">>$output_file");
         select(LOGFILE);
         print "$_";
         close(LOGFILE); 
         kill(15,$pid);
         select(STDOUT);
     }

     }

}


