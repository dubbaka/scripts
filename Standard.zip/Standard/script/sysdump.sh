#!/bin/sh
svrmgrl << !
set echo on
connect internal
oradebug setmypid
oradebug unlimit
rem oradebug dump systemstate 1
oradebug dump systemstate  12
exit
!
