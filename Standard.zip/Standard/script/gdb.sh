#!/bin/sh
set -x
/usr/local/bin/gdb $ORACLE_HOME/bin/oracle $1
