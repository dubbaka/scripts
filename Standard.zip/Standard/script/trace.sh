#!/bin/sh
svrmgrl << !
set echo on
connect internal
oradebug setospid  $1
oradebug unlimit
oradebug event 10046 trace name context forever, level 12
rem oradebug event 10046 trace name context off
exit
!
