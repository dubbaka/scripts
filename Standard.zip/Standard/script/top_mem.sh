#!/bin/sh
# ....................................................................
# program:  /usr/tools/oracle/Standard/script/top_mem.sh
#
# Description:
#   script to check top memory hogger on the unix box
#
# scope:
# first column would display the memory consumed in bytes
# second column would display the  unix process id
# third column would display the program detail
# Work with the client to handle top memory hogging processes 
#
# History
#  skolathu  Mar-04-2005 
# ....................................................................
print  " Bytes   PID  COMMAND";
UNIX95=1 ps -eo vsz,pid,args | sort +0n -1 | tail -10
