#!/oracle/product/perl

##########################################################################################################
# Program Name : listeners.pl
# This program can be used to start/stop/check status for all the listeners in the host.  
# USAGE : listeners.pl [start/stop/status] [SID_NAME/ALL_SIDS] [no_sid_validate] [no_maint_validate]
# All the parameters are optional
# If no_sid_validate is passed, checking would be skipped whether the database (SID_NAME) is up and running
# If no_maint_validate is passed, checking would be skipped for maintenance flag for the database (SID_NAME)
# If no parameters are passed, the default values are : COMMAND = 'start' and SID_NAME = 'ALL_SIDS'
###########################################################################################################

#############################################################################################################
#  
#  Date  	By       	Details
############################################################################################################
# 05/13/08	std-team	Added 10g RAC listener control
# 08/29/11      S Venky         Maint flag checking enabled for stop option

############################################################################################################

require "stat.pl";
require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;
#use DBI;
use Getopt::Std;
use Time::Local;
use Text::ParseWords;

$input_cmd               = lc($ARGV[0]);
$input_sid_name          = uc($ARGV[1]);
$input_no_sid_validate   = lc($ARGV[2]);
$input_no_maint_validate = lc($ARGV[3]);

if ( $input_sid_name eq '' )
{   $input_sid_name = "ALL_SIDS"; }
if ($input_cmd eq '' )
{   $input_cmd = 'start'; }
if ($input_no_sid_validate eq '' )
{   $input_no_sid_validate = 'NULL'; }
if ($input_no_maint_validate eq '' )
{   $input_no_maint_validate = 'NULL'; }

printf("=========================================================================================\n");
printf("Program : listeners.pl called with the following parameters :                      \n");
printf("argv1=%s argv2=%s argv3=%s argv4=%s\n",$input_cmd, $input_sid_name, $input_no_sid_validate, $input_no_maint_validate);
printf("=========================================================================================\n\n");

select(STDERR); $| = 1;
select(STDOUT); $| = 1;
$timeout     = 120;
$OPCPATH     = "/opt/OV/bin/OpC";
$OPCMSG      = "$OPCPATH/opcmsg";
$SEVERITY    = "critical";
$METHOD      = "PAGE";
chomp($host  = `/bin/uname -n`);
$out_subject = "listeners.pl on $host: Problem with Oracle Listener";
$out_message = "listeners.pl on $host: Problem with Oracle Listener";
$logfile     = "/usr/tools/oracle/Standard/script/log/listeners_pl.log";
$tns_admin   = '';
$sid_found   = 0;
$oh_found    = 0;


###################################################################################################
# main 
###################################################################################################
#&stdcompliance_start();
open(LOGFILE, ">$logfile") || die "Unable to open $logfile\n"; 
&scan_listener_ora_files();
#&stdcompliance_end();
close(LOGFILE);
exit;

###################################################################################################
sub scan_listener_ora_files
###################################################################################################
{
  my $dirname='/var/opt/oracle';
  opendir(DIR, $dirname) or die "can't opendir $dirname: $!";
  while (defined($file = readdir(DIR))) 
  {
      if ( $file eq 'listener.ora' )
      {
         $tns_admin="/var/opt/oracle";
         &parse_listener_ora( "$dirname/$file" );
         if( $input_sid_name eq "ALL_SIDS") 
         {
            &check_listeners();
            print " called check_listeners.............\n";
         }
      }
      elsif (-l "$dirname/$file" && $file =~ /^listener/ && $file =~ /\.ora$/) 
      {
         $listener_file_name="$dirname/$file";
         $tns_admin="`ls -l $listener_file_name | awk '{ print \$11 }' | xargs dirname`";
         &parse_listener_ora( $listener_file_name );
         if( $input_sid_name eq "ALL_SIDS") 
         {
           &check_listeners();
         }
      }
  }
  closedir(DIR);

  if( $input_sid_name ne 'ALL_SIDS')
  {
       printf("No listener configured for SID : %s\n", $input_sid_name) ;
  }

}

###################################################################################################
sub parse_listener_ora
###################################################################################################
{
  ($listener_file_name)=@_;
  my $return_code=0;
  my $str='';
  my $spl_listener_name='';
  my $listener_name='';
  my $host_name=`/bin/hostname`;
  chomp($host_name);

  open ( LISTENERORA, $listener_file_name ) || &show_error("Can't Open $listener_file_name", "$!");
  while ( <LISTENERORA> )
  {
     chop ;
     if ( /#SPL_LISTENER/ )
     {
         $spl_listener=1;
     }
     else
     {
         next if ( /^#/ );
     }
     $str .= $_;
     $str .= ' ';
  }
  close( LISTENERORA );

  $str =~  s/\n/ /g;
  $str =~  s/\)/ /g;
  $str =~  s/\(/ /g;
  $str =~ s/\t/ /g;
  $str =~ s/ +/ /g;
  $str =~  s/=/ /g;

  @words = &quotewords ('\s+', 0, $str );
  foreach (@words) 
  {
    $word_read=$_;

    if ( $word_read =~ /SID_LIST_/i )
    {
      $listener_name=substr($word_read,9);
      print " $listener_name\n";
      $data =~ tr/a-z/A-Z/;
      if ( lc($listener_name) =~ /$host_name/i )
      {
        $sid_name = $listener_name;
        $sid_name =~ s/LISTENER_//g;
        $sid_name = substr ( $sid_name, 0, ( length($sid_name) - (length($host_name) + 1 )) );
        chomp($sid_name);
      }
      else
      {
        $sid_name='';
      }
      $oh='';
      $sid_found=0;
      $oh_found=0;
    }

    if ($sid_found == 1 ) 
    {
      if ( $word_read ne 'PLSExtProc' ) 
      {
          $sid_name=$word_read;
          $sid_found=0; 

      } 
      else
      {   
          $sid_found=0;
      }
    }

    if ( $spl_listener_found == 1 ) {
          $spl_listener_name=$word_read;
          $listener_name=$word_read;
          $spl_listener_found=0; }

    if ( $oh_found == 1 ) {
          $oh=$word_read;
          $oh_found=0; }

    if( $word_read =~ /SPL_LISTENER_NAME/i ) {
         $spl_listener_found=1; }

    if( $word_read =~ /SID_NAME/i ) {
         $sid_found=1; }

    if ( $word_read =~ /ORACLE_HOME/i ) {
         $oh_found=1; }

    if ( ($sid_name ne '')  && ($oh ne '')  && ($spl_listener_name ne '') )
    {
         printf("1. SPL :Checking LISTENER_NAME=$listener_name SID_NAME=$sid_name OH_lis=$oh OH=$sid_oh\n");

          if( $sid_name eq $input_sid_name) 
          {
              printf("1. Found listener=%s for sid_name=%s\n", $listener_name, $sid_name);
              printf("tns_admin=%s oracle_home=%s\n", $tns_admin, $oh);
              if (&check_exception($sid_name) != 1 )
              {
                   printf("1.Checking for exception for SID:%s returned zero.  Exiting ....\n", $sid_name);
                   exit 0;
              }
              &listener_cmd( $listener_name, $tns_admin, $oh);
              exit;
          }

         if ( $sid_name =~ /NO_SID/i )
         {
           $maint_flag="/usr/tools/oracle/Standard/script/flags/${sid_name}.MAINT";
           $maint_flag2="/usr/tools/oracle/Standard/script/flags/${sid_name}.maint";
           if  ( ( -e $maint_flag ) || ( -e $maint_flag2) ) 
           {
               printf("Not checking for $listener_name since maint flag is found\n");
           }
           else
           {
               printf("2. SPL :Checking LISTENER_NAME=$listener_name SID_NAME=$sid_name OH_lis=$oh OH=$sid_oh\n");
               $listener_list{$listener_name}=$oh;
               $listener_sid{$listener_name}=$sid_name;
           }
        }
        else
        {
            if ( &check_exception( $sid_name ) == 1 )
            {
              printf("2. SPL :Checking LISTENER_NAME=$listener_name SID_NAME=$sid_name OH_lis=$oh OH=$sid_oh\n");
              $listener_list{$listener_name}=$oh;
              $listener_sid{$listener_name}=$sid_name;
            }
            else
            {
               printf("check_exception returned code not to check for listener %s\n", $listener_name);
            }
        }
        $sid_name='';
        $oh='';
        $spl_listener_name='';
    }
    elsif ( $sid_name ne '' && $oh ne '')
    {
          if( $sid_name eq $input_sid_name) 
          {
              printf("2. Found listener=%s for sid_name=%s\n", $listener_name, $sid_name);
              printf("tns_admin=%s oracle_home=%s\n", $tns_admin, $oh);
              if (&check_exception($sid_name) != 1 )
              {
                   printf("2.Checking for exception for SID:%s returned zero.  Exiting ....\n", $sid_name);
                   exit 0;
              }
              &listener_cmd( $listener_name, $tns_admin, $oh);
              exit 0;
          }

       printf("1. Checking LISTENER_NAME=$listener_name SID_NAME=$sid_name OH_lis=$oh OH=$sid_oh\n");
       $return_code=&check_exception( $sid_name );
       if ($return_code == 1)
       {
          $sid_oh=&get_oh($sid_name, $listener_name);
          printf("2. Checking LISTENER_NAME=$listener_name SID_NAME=$sid_name OH_lis=$oh OH=$sid_oh\n");
          if($sid_oh gt $listener_list{$listener_name})
          {
             $gt_oracle_home = $sid_oh;
          }
          else
          {
             $gt_oracle_home = $listener_list{$listener_name};
          }
          $listener_list{$listener_name}=$gt_oracle_home;
          $listener_sid{$listener_name}=$sid_name;
      }
      $sid_name='';
      $oh='';
    }
  }
}

###################################################################################################
sub check_oratab
###################################################################################################
{
   my $ret_code=0;
   my $ora_sid;
   my $ora_home;
   my $ora_start;
   my $oracle_sid='';

   ($oracle_sid) = @_;
   
   open ( ORATAB, "/var/opt/oracle/oratab") || &show_error("Can't Open /var/opt/oracle/oratab", "$!");
   while ( <ORATAB> )
   {
     ($ora_sid,$ora_home,$ora_start)= split(/:/);
     if ( $ora_sid eq $oracle_sid )
     {
       if ( &check_exception( $ora_sid ) == 1 )
       {
        $ret_code = 1;
       }
     }
   }
   close ( ORATAB );
   return $ret_code;
}

###################################################################################################
sub check_exception
###################################################################################################
{
  my $ora_sid;
  ($ora_sid) = @_;

  my $ret_code=1;

  if ( ( $input_cmd eq 'start') || ( $input_cmd eq 'stop') ) 
  {
     if ( $input_no_sid_validate ne 'no_sid_validate' )
     {
        $pmon="ora_pmon_${ora_sid}";
        if ( `ps -ef|grep $pmon |wc -l` != 3 )
        {
          # database is NOT running
          printf("Database:<%s> is DOWN.  Exiting.... \n", $ora_sid);
          $ret_code = 0;
          return( $ret_code );
        }
        else
        {
          printf("Database:<%s> is UP and running \n", $ora_sid);
        }
     }
   
     if ($input_no_maint_validate ne 'no_maint_validate' )
     {
        $maint_flag="/usr/tools/oracle/Standard/script/flags/${ora_sid}.MAINT";
        $maint_flag2="/usr/tools/oracle/Standard/script/flags/${ora_sid}.maint";
   
        if ( -e $maint_flag )
        {
          printf("Maintenance flag:<%s> found. Exiting....\n", $maint_flag); 
          $ret_code = 0;
          return( $ret_code );
        }
      
        if ( -e $maint_flag2 )
        {
          printf("Maintenance flag:<%s> found. Exiting....\n", $maint_flag2); 
          $ret_code = 0;
          return( $ret_code );
        }

        printf("Database:<%s> maintenance flag is NOT found\n", $ora_sid);
     }
       
  }
  return $ret_code ;
}

###################################################################################################
sub check_listeners 
###################################################################################################
{
  my $cisco_lsnrctl="/usr/tools/oracle/Standard/script/cisco_lsnrctl";
  my %lis_list;
  my $ret_status;
  %lis_list = %listener_list;

  for my $abc ( keys %lis_list )
  {
     printf("LISTENER_NAME : %s \n", $abc );
  }

  for my $key (keys %listener_list ) 
  {
    $ret_status=system("ORACLE_HOME=$listener_list{$key};export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$cisco_lsnrctl status $key ");
    if( $input_cmd eq 'start' ) 
    {
       if (  $ret_status == 0 )
       {
          printf("\nListener:<%s> is UP and running.  Exiting....\n", $key );
       }
       else
       {
          system("ORACLE_HOME=$listener_list{$key};export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$listener_list{$key}/bin/lsnrctl start $key "); 
          if( system("ORACLE_HOME=$listener_list{$key};export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$cisco_lsnrctl status $key ") != 0 ) 
          {
            ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($listener_sid{$key});
            printf("\n\n Sending email for unable to start db:%s listener=%s mailto=%s pageto=%s\n", $key, $listener_sid{$key}, $mailto, $pageto );
            printf("\nlistener_name = %s tns_admin=%s \n", $key, $tns_admin);
            $errmsg = &msgfmt("a","`uname -n`","$key","listeners.pl");
            #&mailit("$errmsg",$logfile);
            #&pageit("$errmsg",$logfile);
            delete $listener_list{$key}; 
            next;
          }
       }
    }
    elsif ( $input_cmd eq 'stop' )
    {
       if (  $ret_status != 0 )
       {
          printf("\nListener:<%s> is already DOWN.  Exiting....\n", $key );
       }
       else
       {
          system("ORACLE_HOME=$listener_list{$key};export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$cisco_lsnrctl stop $key "); 
          if( system("ORACLE_HOME=$listener_list{$key};export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$cisco_lsnrctl status $key ") == 0 ) 
          {
            ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($listener_sid{$key});
            printf("\n\n Sending email for unable to stop db:%s listener=%s mailto=%s pageto=%s\n", $key, $listener_sid{$key}, $mailto, $pageto );
            printf("\nlistener_name = %s tns_admin=%s \n", $key, $tns_admin);
            $errmsg = &msgfmt("a","`uname -n`","$key","listeners.pl");
            #&mailit("$errmsg",$logfile);
            #&pageit("$errmsg",$logfile);
          }
       }
    }
    else
    {
          system("ORACLE_HOME=$listener_list{$key};export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$listener_list{$key}/bin/lsnrctl $input_cmd $key "); 
    }
    delete $listener_list{$key}; 
  }
}

###################################################################################################
sub get_oh
###################################################################################################
{
    my ($oracle_sid, $listener_name) = @_;
    my $listener_oracle_home=''; 
    my $oracle_home='';

    open(ORATAB, "/var/opt/oracle/oratab") || die "Can't Open /var/opt/oracle/oratab";
    while (<ORATAB>)
    {
        next if ( /^#/ );

        if (/^${listener_name}:/)
        {
            $listener_oracle_home =  (split(':'))[1];
        }
    }
    close ( ORATAB );

    if ( $listener_oracle_home ne '' )
    {
        return ( $listener_oracle_home );
    }

    # listener name not found in ORATAB file.  check for oracle_sid in ORATAB

    open(ORATAB, "/var/opt/oracle/oratab") || die "Can't Open /var/opt/oracle/oratab";
    while (<ORATAB>)
    {
        next if ( /^#/ );

        if (/^${oracle_sid}:/)
        {
            $oracle_home =  (split(':'))[1];
        }
       
    }
    close ( ORATAB );

    if ( $oracle_home eq '')
    {
         $oracle_home="/oracle/product/current";
    }

    return ( $oracle_home );
}

###################################################################################################
sub stdcompliance_start
###################################################################################################
{
  $thisScriptName="listeners.pl";  # << Change this to standard script name
  $stddate=`date -u +%Y%m%d%H%M`; chomp($stddate);
  $stdlogfile="${thisScriptName}_${stddate}";
  $stdlibpath="/usr/tools/oracle/Standard/lib";
  $stdpidval="$$";
  $actscriptname=`basename $0`;
  chomp($actscriptname);
  $actpath = `dirname $0`;
  chomp($actpath);
  $stdsid="ALL";
  $stdjobseq="${stddate}-${stdpidval}";
  $stdcksum=`/oracle/product/perl $stdlibpath/StdCompFunctions.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname $actpath`;
  if ( $stdcksum =~ "FAILED" ) 
  {
       print "This script $actscriptname is not same as standard script $thisScriptName\nExiting..\n";
       exit 1;
  } 
  elsif ( $stdcksum =~ "SUCCESS" ) 
  {
          print "This script is $actscriptname matching checksum with standard script $thisScriptName..Continuing..\n";
  } 
  elsif ( $stdcksum =~ "NOT_FOR_LINUX" ) 
  {
          print "This script is $actscriptname and it is NOT valid for Linux server..\nExiting..\n";
          exit 1;
  } 
  else 
  {
          print "$stdcksum\nExiting..\n";
         exit 1;
  }
}

###################################################################################################
sub stdcompliance_end
###################################################################################################
{
  system("/oracle/product/perl $stdlibpath/StdCompFunctions.pl log_job 99-END $stdjobseq $ORACLE_SID $stdlogfile $thisScriptName");
}

###################################################################################################
sub listener_cmd
###################################################################################################
{
  my ($listener_name, $tns_admin, $oh) = @_;
  my $cisco_lsnrctl="/usr/tools/oracle/Standard/script/cisco_lsnrctl";

  if( $input_cmd eq 'start')
  {
    # if input_cmd is 'start' check whether listener is already running
    if(system("ORACLE_HOME=$oh;export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$cisco_lsnrctl status $listener_name ")==0) 
    {
       printf("\nListener:<%s> for SID:<%s> is already running\n", $listener_name, $sid_name);
       exit 0;
    }
  }

  if ( $input_cmd eq 'stop')
  {
    # if input_cmd is 'stop' check whether listener is running first
    if(system("ORACLE_HOME=$oh;export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$cisco_lsnrctl status $listener_name ")!=0)
    {
       printf("\nListener:<%s> for SID:<%s> is currently DOWN.  Exiting .....\n", $listener_name, $sid_name);
       exit 0;
    }
  }

  if(system("ORACLE_HOME=$oh;export ORACLE_HOME;TNS_ADMIN=$tns_admin;export TNS_ADMIN;$cisco_lsnrctl $input_cmd $listener_name ")!=0) 
  {
            ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($listener_sid{$key});
            printf("\n\n Sending email for db:%s listener=%s mailto=%s pageto=%s\n", $key, $listener_sid{$key}, $mailto, $pageto );
            $errmsg = &msgfmt("a","`uname -n`","$key","listeners.pl");
            #&mailit("$errmsg",$logfile);
            #&pageit("$errmsg",$logfile);
  }
}
###################################################################################################
# end 
###################################################################################################
