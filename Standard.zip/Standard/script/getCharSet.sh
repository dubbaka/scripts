#!/bin/ksh
# Cisco Systems Yong Ke Wu 10/31/06

if [ $# -lt 1 ];then
   echo " "
   echo "Usage: $0 <SID> "
   echo " "
   exit 1
fi

ORACLE_SID=$1;export ORACLE_SID
ORAENV_ASK=NO;export ORACLE_ASK
. /usr/local/bin/oraenv
export SHLIB_PATH=$ORACLE_HOME/lib 

instance=`ps -ef|grep smon|grep ${ORACLE_SID}|wc -l`

if (( $instance==0 )); then
   echo "`hostname`:${ORACLE_SID} is Unavailable"
#   mailx -s "`hostname`:${ORACLE_SID} is Unavailable" yowu < /dev/null
   exit;
fi

$ORACLE_HOME/bin/sqlplus -s / <<EOF 
set lines 1000 verify off pages 0 echo off termout off feedback off wrap off
select VALUE from v\$nls_parameters where parameter='NLS_CHARACTERSET';
EOF

