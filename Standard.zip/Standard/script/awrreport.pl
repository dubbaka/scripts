#!/oracle/product/perl

#
# Name    : dbawr.pl
#	 
# Modification History:
#	modified plaporte	for all Oracle8i/9i
#       modified swei  		enhanced for Standard library
#				and for RAC too
#  01/03/06 raraveet    	fixed env setup issue in ora_home,
#  01/08/07 raraveet            Std compliance phase-2
# ........................................................................

require "stat.pl";
require "ctime.pl";
use Getopt::Std;
use Time::Local;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;

$username          = "";
$passwd            = "";
$oracle_base       = "/oracle";
$date              = (localtime)[3];
$year              = (localtime)[5] + 1900;
$month             = (localtime)[4]+1;
$min               = (localtime)[1];
$hour              = (localtime)[2];
$day               = (localtime)[6];
$maillist          = "mis-dba";
$outtype = "both";

    select(STDERR); $| = 1;
    select(STDOUT); $| = 1;
    getopt('sompd');
    &get_pageexe();
    $sysdate           = sprintf("%04d.%02d.%02d", $year, $month, $date);
    $mailto            = $opt_m || $maillist;
    $pageto            = $opt_p || $pagelist;
    $sid               = $opt_s if defined($opt_s) || &usage;
    $ENV{'ORACLE_SID'} = $sid;

    	if (!$opt_o) { $opt_o = "both"; }
    	if ( $opt_o ne "text" && $opt_o ne "html" && $opt_o ne "both") { &usage; }
	$outtype = $opt_o if defined($opt_o);

#############    Mandatory setting for DBI module setting   ######
&StdDBPackage::which_lib($sid);
##################################################################

##################  STD Compliance     ##########################
#  Pl add this piece of code in all Std Scripts at the beginning
#  before staring any operations
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
$thisScriptName="awrreport.pl";  # << Change this to standard script name
#
$stddate=`date -u +%Y%m%d%H%M`; chomp($stddate);
$stdlogfile="${thisScriptName}_${stddate}";
$stdlibpath="/usr/tools/oracle/Standard/lib";
$stdpidval="$$";
$actscriptname="$0";
$stdjobseq="${stddate}-${stdpidval}";
$stdcksum=`/oracle/product/perl $stdlibpath/StdCompProc.pl find_cksum $thisScriptName $stdjobseq $stdlogfile $actscriptname`;
 $stdcksum = "SUCCESS" ; # for debugging
if ( $stdcksum =~ "FAILED" ) {
        print "This script $actscriptname is not same as standard script $thisScriptName\nExiting..\n";
       exit 1;
} elsif ( $stdcksum =~ "SUCCESS" ) {
        print "This script is $actscriptname matching checksum with standard script $thisScriptName..Continuing..\n";
} elsif ( $stdcksum =~ "NOT_FOR_LINUX" ) {
        print "This script is $actscriptname and it is NOT valid for Linux server..\nExiting..\n";
       exit 1;
} else {
        print "This script is $actscriptname error getting checksum with standard script $thisScriptName\nExiting..\n";
       exit 1;
}
###################################################################

##################  STD Compliance     ##########################
# If the script is used for all the database in this server
# like check_extend_all.pl, put this piece of code inside the loop
# for each databases using ORATAB.  Change the value for
# the variable "$mysid" to actual variable for each database
#        !!!  IMPORTANT  !!!       !!! IMPORTANT  !!!
$stdsid="$sid";  # << Change "$sid" to actual variable
system("/oracle/product/perl $stdlibpath/StdCompProc.pl begin_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName");
###############################################################


    ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($sid);

    #print "$sid $mailto\n";	
    &ora_home($sid);

    &which_report();
    $dbh =  &ConnectDB(); 

    $stmt = "select a.snap_id from
        ( select snap_id from dba_hist_snapshot
        where instance_number=(select INSTANCE_NUMBER from v\$instance) and dbid=(select dbid from v\$database)
        order by snap_id desc) a
        where rownum < 3";
    $sth = $dbh->prepare($stmt) ||
        &dbawr_error("Prepare Failed for $stmt. $DBI::errstr\n");
    $sth->execute() ||
        &dbawr_error("Execute Failed for $stmt. $DBI::errstr\n");
    ($end_snpid) = $sth->fetchrow_array() ||
        &dbawr_error("01Fetchrow_array failed for $stmt. $DBI::errstr\n");
    ($begin_snpid) = $sth->fetchrow_array() ||
        &dbawr_error("02Fetchrow_array failed for $stmt. $DBI::errstr\n");
    $sth->finish ||
        &dbawr_error("Finish failed for $stmt. $DBI::errstr\n");

    print "Begin snapid - $begin_snpid\n";
    print "End   snapid - $end_snpid\n";

    $sqlplus     = "$oracle_home/bin/sqlplus";
    $report_txt  = "$oracle_base/admin/$sid/perf/report.txt";
    $log_dir     = "$oracle_base/admin/$sid/perf/$sysdate";
#    $log_file    = sprintf("$log_dir/dbawr_rep.$sid.$sysdate.%02d.%02d.html", $hour, $min);
    $ENV{'ORA_NLS33'} = "";
    if ( $outtype eq "text") {
print "Text report \n";
        $log_file    = sprintf("$log_dir/dbawr_rep.$sid.$sysdate.%02d.%02d.txt", $hour, $min);
        $cmd = "$sqlplus -s $username/$passwd \@$sqlscript $begin_snpid $end_snpid $log_file $outtype";
        (mkdir("$log_dir",0750) || &dbawr_error("mkdir $log_dir error. $!\n")) unless -d "$log_dir";
        system("$cmd");
    }
    if ( $outtype eq "html") {
print "html report \n";
        $log_file    = sprintf("$log_dir/dbawr_rep.$sid.$sysdate.%02d.%02d.html", $hour, $min);
        $cmd = "$sqlplus -s $username/$passwd \@$sqlscript $begin_snpid $end_snpid $log_file $outtype";
       (mkdir("$log_dir",0750) || &dbawr_error("mkdir $log_dir error. $!\n")) unless -d "$log_dir";
        system("$cmd");
    }
    if ( $outtype eq "both") {
print "all report \n";
        $log_file_txt= sprintf("$log_dir/dbawr_rep.$sid.$sysdate.%02d.%02d.txt", $hour, $min);
        $log_file_htm= sprintf("$log_dir/dbawr_rep.$sid.$sysdate.%02d.%02d.html", $hour, $min);
        $cmd = "$sqlplus -s $username/$passwd \@$sqlscript $begin_snpid $end_snpid $log_file_txt text";
        (mkdir("$log_dir",0750) || &dbawr_error("mkdir $log_dir error. $!\n")) unless -d "$log_dir";
        system("$cmd");
        $cmd = "$sqlplus -s $username/$passwd \@$sqlscript $begin_snpid $end_snpid $log_file_htm html";
        (mkdir("$log_dir",0750) || &dbawr_error("mkdir $log_dir error. $!\n")) unless -d "$log_dir";
        system("$cmd");
    }

##################  STD Compliance     ##########################
# Place this piece of code at the end of LOOP job for each database.
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_eachjob $stdjobseq $stdsid $stdlogfile $thisScriptName");
###############################################################

##################  STD Compliance     ##########################
########  Pl add this piece of code in all Std Scripts ########
#     after completion of the script and before exit  #########
system("/oracle/product/perl $stdlibpath/StdCompProc.pl end_alljob $stdjobseq ALL $stdlogfile $thisScriptName");
###############################################################

#
# Subroutines
#
sub usage
{
    	print "$_[0]\n";
    	print "$_[1]\n";
    	print "Usage:\n$0 -s <SID> [-o text | -o html]\n";
    	exit (1);
}

sub ora_home()
{
my $oracle_sid;

    $oracle_sid = $_[0];
    #-------------------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #-------------------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || 
	&dbawr_error("Can't Open /etc/oratab. $!\n");
    
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home            = (split(':'))[1];
            $ENV{'ORACLE_HOME'}     = $oracle_home;
            $ENV{'ORACLE_SID'}      = $oracle_sid;
            $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
            $ENV{'SHLIB_PATH'}      = "$oracle_home/lib";
            $ENV{'TNS_ADMIN'}       = "$oracle_home/network/admin";
            ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
            ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }
        print "Sid $oracle_sid home $oracle_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();
        }
    }
    close(ORATAB);
}

sub ConnectDB
{
my $dbh;

    print "sid is <$ENV{'ORACLE_SID'}>\n";
    $dbh = DBI->connect("dbi:Oracle:", $username, $passwd) ||
        &dbawr_error("Cannot connect to $oracle_sid. $DBI::errstr\n");
    return($dbh);
}

sub DisconnectDB
{
    $dbh->disconnect if ($dbh);
}

sub dbawr_error()
{
my $errmsg = $_[0];

    print "ERROR: $errmsg";
    &DisconnectDB();
    #&pageit($errmsg);
    $errmsg = &msgfmt("a","$host","$oracle_sid","Database Statspack Error");
    #&mailit("$errmsg",$logfile);
    exit(1);
}

sub pageit
{
my $pagemsg;

    $pagemsg = $_[0];
    chomp($pagemsg);
    foreach $page (split /,/, $pageto)
    {
        #print "<$pageexe $page \"$pagemsg\">\n";
        `$pageexe $page \'$pagemsg\'`;
    }
}

sub get_pageexe
{

    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");
    if (!defined($pageexe))
    {
        print("dbawr.pl on $host: epage/pageme executable not found. Aborting...");
    exit (1);
    }
}

sub which_report {
$val = $ENV{'ORACLE_HOME'};
if (-f "$val/bin/svrmgrl") {
                 $sqlscript   = "/usr/tools/oracle/Standard/sql/csco_spreport.sql";
        }
       # elsif (-f "$val/lib/libserver11.a"){
         elsif ( oraVersion () > 9 ) { 
                 $sqlscript   = "/usr/tools/oracle/Standard/sql/csco_awrreport_10g.sql";
        }
        else {
                 $sqlscript   = "/usr/tools/oracle/Standard/sql/csco_spreport_9i.sql";
	}
}

sub oraVersion {
        my ($version) = glob "${oracle_home}/lib/libserver*"; 
        $version =~ s/.*\/libserver(\d+).*/$1/;
        return $version;
}

