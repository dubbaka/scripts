#!/oracle/product/perl
##!/usr/local/bin/perl
#
# Name    : long_running_all.pl
# Version : 1.1
#
#
#  swei   05-apr-2004 created
#

require "/usr/tools/oracle/Standard/script/perllib.pl";
require "ctime.pl";
use Getopt::Std;
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


$parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
$exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";
chomp($host = `/bin/uname -n`);
&Get_Page_Exe;


#.....................................................................
#       Main
#.....................................................................

open (ALLTAB,"/var/opt/oracle/oratab") || &show_error("Can't Open oratab", "$!");
while (<ALLTAB>)
{
    next if (/^#/ || /^\s/);
    ($sid, $ora_home, $db_flag) = split(/:/);
    print "$sid $db_flag \n";
    next if ($db_flag =~ /^N/ || $db_flag =~ /^n/ );

    $RunningForHrs = 1;
    ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($sid);


    &get_exception_value();

    $LogFile = "/tmp/long_running_$sid.log";
     


print "Start time ", &ctime(time), "\n";
open(LOGFILE, ">${LogFile}") || die "Can not open logfile. $!\n";

$OracleSid = $sid;
&Set_Oracle_Home($OracleSid);

$dbh = DBI->connect("dbi:Oracle:", "", "") || next;
#       &Show_Error("$OracleSid Connect failed", "$DBI::errstr");

$Stmt = qq{SELECT p.spid, v.sid, v.serial#, v.username, v.osuser,
	          v.machine,to_char(v.logon_time,'DD-MON-YYYY HH24:MI:SS'),
		  ROUND(v.last_call_et/60)
           FROM   v\$session v, v\$process p
           WHERE  v.paddr       = p.addr
           AND    v.status      = 'ACTIVE'
	   AND    v.last_call_et >= ${RunningForHrs}*60*60
           AND    v.osuser     <> 'oracle'
           AND    v.serial#     > 1
           AND    p.background IS NULL
           AND    p.username   IS NOT NULL
           ORDER  BY 7 DESC };

$Sth = $dbh->prepare($Stmt) || &Show_Error("SID - $OracleSid Prepare failed ".
                                           "for $Stmt.", "$DBI::errstr");

$Rc  = $Sth->execute || &Show_Error("SID - $OracleSid Execute failed ".                                             "for $Stmt.", "$DBI::errstr");


$aref = $Sth->fetchall_arrayref;
$Sth->finish;

printf "  Spid  Sid   Serial# Username   Osuser     Machine       Logon_Time       Min_Running\n";

printf LOGFILE "-"x88;
printf LOGFILE "\n  Spid   Sid   Serial# Username   Osuser     Machine    ".
               "   Logon_Time       Min_Running\n";
printf LOGFILE "-"x88;
printf LOGFILE "\n";

$count = 0;

foreach(@$aref) {
   ($Spid, $SessId, $Sno, $UserName, $OsUser, $Machine, $LogOnTime, $LastCallET)  = (@$_);
   printf         "%7d %5d %8d %-10s %-10s %-7s %-21s %4d\n\n", 
                  $Spid,$SessId,$Sno,$UserName,$OsUser,$Machine,$LogOnTime,$LastCallET;
   printf LOGFILE "%7d %4d  %8d %-10s %-10s %-7s %-21s %4d\n\n", 
                  $Spid,$SessId,$Sno,$UserName,$OsUser,$Machine,$LogOnTime,$LastCallET;
   $count++;
   &Get_Sql_Text($SessId);
}
$dbh->disconnect;
close(LOGFILE);
print "\nEnd time ", &ctime(time), "\n";

  
    $errmsg = &msgfmt("w","`uname -n`","$sid","Long Running ( > ${RunningForHrs} Hrs. )Report");
    &mailit("$errmsg",$LogFile) if ($count>0);
}
close(ALLTAB);

#-------------------------------------------------------------------------------
# SUB Usage
#-------------------------------------------------------------------------------
sub Usage {

    print "$_[0]";
    print "\n","-"x80, "\nUsage:\n\nlong_running.pl -s <SID> -m MailId,... ".
          "-p PagerId,...\n\n","-"x80,"\n";
    exit (1);
}

#-------------------------------------------------------------------------------
# SUB GET_PAGE_EXE
#-------------------------------------------------------------------------------
sub Get_Page_Exe {

    $PageExe = "/usr/local/bin/epage"  if (-f "/usr/local/bin/epage");
    $PageExe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $PageExe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");


    if (!defined($PageExe)) {
       print("long_running.pl on $host: epage/pageme executable not ".
             "found. Aborting...");
        exit (1);
    }
}

#-------------------------------------------------------------------------------
# SUB SET_ORACLE_HOME
#-------------------------------------------------------------------------------
sub Set_Oracle_Home {
    open(ORATAB, "/etc/oratab") || &Show_Error("Can't Open /etc/oratab", "$!");

    while (<ORATAB>) {
       if (/^${OracleSid}:/i) {
          $oracle_home = (split(':'))[1];
          $ENV{'ORACLE_HOME'} = $oracle_home;
          $ENV{'ORACLE_SID'}  = $OracleSid;
        ($oracle7)=&StdDBPackage::check_oracle7($OracleSid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
	  $ENV{'ORA_NLS32'} = "";
	  $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
	  $ENV{'ORA_NLS32'} = "";
	  $ENV{'ORA_NLS33'} = "";
          }
        }
        &StdDBPackage::which_lib();
       }
    }
    close(ORATAB);
}

#-------------------------------------------------------------------------------
# SUB MAIL_IT
#-------------------------------------------------------------------------------
#sub Mail_It
#{
#    open (MAIL, "|/usr/bin/mailx -s \"$_[0]\"  $MailTo < $_[1]");
#    close (MAIL);
#    #print "";
#}

#-------------------------------------------------------------------------------
# SUB PAGE_IT
#-------------------------------------------------------------------------------
sub Page_It {

    my @PageMsg = @_;

    while ($PageMsg = pop(@PageMsg)) {
       print "$PageExe \"$PageTo\" \"$PageMsg\"";
       #`$PageExe \"$PageTo\" \'$PageMsg\'`;
    }
}

#-------------------------------------------------------------------------------
# SUB GET_SQL_TEXT
#-------------------------------------------------------------------------------
sub Get_Sql_Text {

    my ($Sid) = @_;
    my $Stmt = "";
 
    $Stmt = qq{ SELECT a.sql_text 
                FROM   v\$sqltext a, v\$session b 
                WHERE  b.sid            = :1 
                AND    b.sql_address    = a.address 
                AND    b.sql_hash_value = a.hash_value 
                ORDER  BY b.sid, a.piece };

    $Sth = $dbh->prepare($Stmt)||&Show_Error("SID - $OracleSid Prepare failed ".
                                             "for $Stmt.", "$DBI::errstr");
    $Rc  = $Sth->execute($Sid)||&Show_Error("SID - $OracleSid Execute failed ".                                             "for $Stmt.", "$DBI::errstr");

    $aref = $Sth->fetchall_arrayref;
    $Sth->finish;

    foreach(@$aref) {
        print "@$_\n";
        print LOGFILE "@$_\n";
    }
    print "\n";
    print LOGFILE "\n\n";
}

#-------------------------------------------------------------------------------
# Sub Show_Error
#-------------------------------------------------------------------------------
sub Show_Error {

    my $Subject;
    my $MesgBody;


    ($Subject, $MesgBody) = @_;

    $Subject   = "FAILED - [ $0 ] -  ".$Subject;
     
    $Subject   =~ s/\.\///;
    $MesgBody  = "\nHost  - $host, SID - $sid\n";
    $MesgBody .= "Error - $_[0].$message\n";

    #`mailx -s "$Subject" ${MailTo}\@cisco.com <<EOF\n$MesgBody\nEOF\n`;

    exit(0);
}


sub get_exception_value
{

    if (-r $exceptfile)
    {

    open(EXCEPTFILE, $exceptfile) || die "Can't Open $parfile. $!";
    while (<EXCEPTFILE>)
    {

       next unless (/^LONG:/ && /$sid:/ );
       {
          ($long, $sid, $mailto, $pageto, $RunningForHrs) = split(/:/);
          chomp($alert);
          #print "$sid $mailto $pageto $RunningForHrs \n";
       }
    } 
    close(EXCEPTFILE);
    }
}

