#!/usr/local/bin/perl

# Development log

# -> Feature Set
# - brought under RCS control
# - Added InstallPath and ServerType tags
# - Added -v (version) switch and version tracking
# -> Bug fix

# $Log: check_backup.pl,v $
# Revision 1.1.1.2  2004/10/08 15:19:16  fbicknel
# import package build files
#
# Revision 1.1.1.1  2004/10/08 14:08:21  fbicknel
# imported from old RCS system
#
# Revision 1.1  2002/08/06 12:41:22  fbicknel
# -> Feature Set
# - brought under RCS control
# - Added InstallPath and ServerType tags
# - Added -v (version) switch and version tracking
# swei 2004/11/15
# - fixed ORACLE_HOME and sqlplus/svrmgrl
# - incorporated initdb.ora in the file 

#InstallPath:/usr/tools/oracle
#ServerType:media

require "ctime.pl";
use DBI;
use Getopt::Std;
use Time::Local;

my $version_tag = ""; # This will be added at the end of the version (use for development work)
my $version = do { my @r = (q$Revision: 1.1.1.2 $ =~ /\d+/g); sprintf "%d".".%d" x $#r."%s", @r, $version_tag };

getopts ('f:s:m:p:t:o:v');
die "$version\n" if $opt_v;

print "This is version $version.\n";

    chomp($hostname = `/bin/uname -n`);
    if (-f "/usr/xpg4/bin/id" )
    {
        chomp($id=`/usr/xpg4/bin/id -un`);
    }
    elsif (-f "/usr/bin/id" )
    {
        chomp($id=`/usr/bin/id -un`);
    }
    else
    {
        `epage dba-duty "check_backup.pl on $hostname: id not found."`;
        exit(1);
    }
    print "ID is $id\n";

    if (! -f "/usr/tools/oracle/initdb.ora")
    {
	print "check_backup.pl on $hostname: /usr/tools/oracle/initdb.ora not found\n";
        #`epage dba-duty "check_backup.pl on $hostname: /usr/tools/oracle/initdb.ora not found."`;
        exit(1);
    }


    if ($id eq "root")
    {
        #print "su - oracle -c \"$0 @ARGV\"";
        #system("su - oracle -c \"$0 @ARGV\"");
        system("su - oracle -c \"$0 -t $opt_t -s $opt_s -o $opt_o \"");
		chomp (my $status = `/bin/cat /tmp/ora_chk_$opt_s`);
        exit($status);
    }

    $sid = $opt_s if defined($opt_s) || &usage("");

    undef($mailto);
    undef($pageto);
    undef($backup_mode);
    undef($oracle_home);
    $mailto = $opt_m;
    $pageto = $opt_p;
    $backup_mode = $opt_t;
    $oracle_home = $opt_o;

    chomp($host = `/bin/uname -n`);
    &get_pageexe();
    print "Database Backup Verification Test Started.\nStart time ", &ctime(time), "\n";
    
    $oracle_sid = $sid;
    &get_ora_home($oracle_sid, $oracle_home);
    &prepare_initora();
    $status = &check_db();

    print "\nDatabase Backup Verification Test Completed.\nEnd   time ", &ctime(time), "\n";

	print "Exiting with status <$status>\n";
	open STAT, "> /tmp/ora_chk_$opt_s" or die "cannot open status file! ($!)";
	print STAT "$status\n";
	close STAT;
    exit($status);
    

sub prepare_initora
{

    &get_cntrl_file();
    &create_dump_dirs();
    open(INITORA, ">/usr/tools/oracle/$oracle_sid/init${oracle_sid}.ora") ||
        die "Cannot open /usr/tools/oracle/$oracle_sid/init${oracle_sid}.ora file for writing. $!";
    print INITORA "#####################################################\n";
    print INITORA "# Created by check_backup.pl\n";
    print INITORA "#####################################################\n";
    print INITORA "audit_file_dest      = /oracle/admin/$oracle_sid/audit\n";
    print INITORA "background_dump_dest = /oracle/admin/$oracle_sid/bdump\n";
    print INITORA "core_dump_dest       = /oracle/admin/$oracle_sid/cdump\n";
    print INITORA "user_dump_dest       = /oracle/admin/$oracle_sid/udump\n";
    print INITORA "control_files        = ($cntrl_file)\n";
    print INITORA "db_name              = $oracle_sid\n";
    print INITORA "db_block_buffers                   = 6400 \n";
    print INITORA "db_block_size                      = 8192 \n";
    print INITORA "db_domain                          = cisco.com \n";
    print INITORA "db_file_multiblock_read_count      = 8 \n";
    print INITORA "dml_locks                          = 20 \n";
    print INITORA "log_archive_dest                   = /tmp \n";
    print INITORA "log_buffer                         = 2097152   \n";
    print INITORA "max_dump_file_size                 = 2097152  \n";
    print INITORA "nls_date_format                    = \"DD-MON-YYYY\" \n";
    print INITORA "parallel_max_servers               = 20 \n";
    print INITORA "processes                          = 20  \n";
    print INITORA "shared_pool_size                   = 10485760 \n";
    print INITORA "sort_area_retained_size            = 1048576  \n";
    print INITORA "sort_area_size                     = 1048576  \n";
    print INITORA "utl_file_dir                       = /tmp \n";
    print INITORA "recovery_parallelism               = 1 \n";
    close(INITORA); 
    #`/bin/cat /usr/tools/oracle/initdb.ora >> /usr/tools/oracle/$oracle_sid/init${oracle_sid}.ora`;

}

sub get_cntrl_file
{
$cntrl_file = "/usr/tools/oracle/$oracle_sid/control_backup.ctl";

    if ($backup_mode eq "ONLINE")
    {
        $cntrl_file = "/usr/tools/oracle/$oracle_sid/control_backup.ctl";
    }
    elsif ($backup_mode eq "OFFLINE")
    {
        open(CNTRL_NAME, "/usr/tools/oracle/$oracle_sid/cntrl_files_$oracle_sid.ora") ||
            die "Cannot Open /usr/tools/oracle/$oracle_sid/cntrl_files_$oracle_sid.ora. $!";
        #@cntrl_names = <CNTRL_NAME>;
        while(<CNTRL_NAME>)
        {
            chomp;
            $str = $_;
            next if ($str eq "");
            push(@cntrl_names, $str);
        }
        $cntrl_file = join(',', @cntrl_names);
    }
    else { die "$backup_mode - Invalid Backup Mode. Aborting!!!" };

}


sub get_pageexe
{
    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");
    $pageexe = "/usr/tools/oracle/itopage.pl" if (-f "/usr/tools/oracle/itopage.
pl");

    if (!defined($pageexe))
    {
        print("check_backup.pl on $host: epage/pageme executable not found. Aborting...");
        exit (1);
    }
}


sub check_db
{

    unlink("/tmp/check_backup_${oracle_sid}.log");
    if ( "$SQLPLUS_CMD" =~ /7.3/ )
    {
	`echo "db_files = 1021" >> /usr/tools/oracle/$oracle_sid/init$oracle_sid.ora `;
    }
    else
    {
	`echo "db_files = 3600" >> /usr/tools/oracle/$oracle_sid/init$oracle_sid.ora `;
    }
    
    $reco_vw = "v\\\$recover_file";
    $cmd = "$SQLPLUS_CMD \"$SQLPLUS_ARGS\" << !
$CONNECT
spool /tmp/check_backup_${oracle_sid}.log
set echo on
startup mount pfile=/usr/tools/oracle/$oracle_sid/init$oracle_sid.ora;
select 'COUNT = '||count(*) from $reco_vw
where time is null or time < sysdate - 1;
spool off
exit
!";
    $count = 0;
    undef(@errmsg);

    open(CMD, "$cmd 2>&1 | ") || die "Cannot open sqlplus. $!";
    while (<CMD>)
    {
        if (/^ORA-/)
        {
            print "ERROR: $_\n";
            push(@errmsg, $_);
        } 
        else
        {
            print;
        }
        if (/^COUNT = /)
        {
            $count = (split(' '))[2];
        }
    }
    close(CMD);

    $cmd = "$SQLPLUS_CMD \"$SQLPLUS_ARGS\" << !
$CONNECT
set echo on
shutdown immediate; 
exit
!";
    open(CMD, "$cmd 2>&1 | ") || die "Cannot open sqlplus. $!";
    while (<CMD>)
    {
        print ;
    }

    if ($count > 0)
    {
        print "$count volumes have less timestamp. Backup is not valid.\n";
        return(1);
    }
    elsif  (@errmsg)
    {
        print "Error occurred. Backup is not valid\n"; 
		return 1;
    }
    else
    {
        print "All the volumes have recent timestamp. Backup is valid.\n";
        return(0);
    }
}

sub create_dump_dirs
{
   
    `/bin/mkdir -p /oracle/admin/$oracle_sid`;

    if (! -d "/oracle/admin/$oracle_sid/audit")
    {
        mkdir("/oracle/admin/$oracle_sid/audit", "0751") ||
            die "Cannot create /oracle/admin/$oracle_sid/audit directory. $!";
    }
    if (! -d "/oracle/admin/$oracle_sid/bdump")
    {
        mkdir("/oracle/admin/$oracle_sid/bdump", "0751") ||
            die "Cannot create /oracle/admin/$oracle_sid/bdump directory. $!";
    }
    if (! -d "/oracle/admin/$oracle_sid/cdump")
    {
        mkdir("/oracle/admin/$oracle_sid/cdump", "0751") ||
            die "Cannot create /oracle/admin/$oracle_sid/cdump directory. $!";
    }
    if (! -d "/oracle/admin/$oracle_sid/udump")
    {
        mkdir("/oracle/admin/$oracle_sid/udump", "0751") ||
            die "Cannot create /oracle/admin/$oracle_sid/udump directory. $!";
    }
}

sub get_ora_home
{
my ($oracle_sid, $oracle_home) = @_;
my ($ora_ver, $ora_home);

  if ($oracle_home eq "" )
  {
    @ora_ver = split('/', $oracle_home);
    $ora_ver = $ora_ver[$#ora_ver];
    print "Ora ver is $ora_ver \n";
    if ($ora_ver =~ /^8.1/)
    {
        #print "8.1 database\n";
        $ora_home = "/oracle/product/8.1.7";
    }
    elsif ($ora_ver =~ /^7.0/)
    {
        #print "7.x database\n";
        $ora_home = "/oracle/product/7.3.4";
    }
    elsif ($ora_ver =~ /^8.0/)
    {
        #print "8.0 database\n";
        $ora_home = "/oracle/product/8.0.6";
    }
    elsif ($ora_ver =~ /^9.0/)
    {
        #print "9.0 database\n";
        $ora_home = "/oracle/product/9.0.2";
    }
    elsif ($ora_ver =~ /^9.1/)
    {
        #print "9.1 database\n";
        $ora_home = "/oracle/product/9.1.2";
    }
    elsif ($ora_ver =~ /^9.2/)
    {
        #print "9.1 database\n";
        $ora_home = "/oracle/product/9.2.0";
    }
    else
    {
        #print "No match found. Assume 8.1.7\n";
        $ora_home = "/oracle/product/8.1.7";
    }
  }
  else
  {
        $ora_home = $oracle_home;
  }
    $ENV{'ORACLE_SID'} = "$oracle_sid";
    $ENV{'ORACLE_HOME'} = "$ora_home";
    $ENV{'PATH'} = "${ora_home}/bin:$ENV{'PATH'}";
    if (-f "$ora_home/bin/svrmgrl")
    {
	$SQLPLUS_CMD = "$ora_home/bin/svrmgrl";
        $SQLPLUS_ARGS= "";
        $CONNECT= "connect internal";
    }
    else
    {
        $SQLPLUS_CMD = "$ora_home/bin/sqlplus";
        $SQLPLUS_ARGS= "/ as sysdba";
        $CONNECT= "";
    }
    #exit(0);
}

