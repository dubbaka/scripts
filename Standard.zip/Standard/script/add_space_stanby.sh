#!/bin/sh
set -x
cd /usr/tools/oracle/recovery/norecover
file=<SID>
if [ -f $file ]
  then
    {
      echo "Space not added to standby DB as refresh for another DB is running"
      #mailx warehouse-dba "Pls. run /oracle/admin/DB_NAME/control/add_space.sh as space is not added due to refresh of other DB"
    }
  else
    {
ORACLE_SID=<SID>;export ORACLE_SID
ORAENV_ASK=NO;export ORACLE_ASK
. /usr/local/bin/oraenv
cd /oracle/admin/<SID>/control
rm add_space.sql add_space_error.lst 
touch /usr/tools/oracle/recovery/norecover/$1
sqlplus internal <<EOF
spool /oracle/admin/<SID>/control/shutdown_<SID>.log
shutdown immediate;
exit
EOF
echo "Killing dbrecover processes"
kill -15 `ps -ef | grep dbrecover.pl | grep -v grep | awk ' { print $2 }'`
kill -15 `ps -ef | grep recover | grep -v grep | awk ' { print $2 }'`
echo "Done"
sleep 10
dd if=standby.ctl of=/dev/<control_file> bs=64k
dd if=standby.ctl of=/dev/<control_file> bs=64k
dd if=standby.ctl of=/dev/<control_file> bs=64k
sqlplus -s internal <<EOF
startup nomount;
alter database mount standby database;
set echo off feedback off pages 0 
select 'alter database create datafile '''||name||''';' x from v\$datafile_header where error like 'WRONG%' order by file#
.
spool add_space.sql
/
spool off
@add_space.sql
select name from v\$datafile_header where error like 'WRONG%' order by file#
.
spool add_space_error.lst
/
select * from v\$datafile_header where error is not null order by file#
.
spool add_space_all_errors.lst
/
spool off
exit
EOF
rm /usr/tools/oracle/recovery/norecover/<SID>
}
fi

