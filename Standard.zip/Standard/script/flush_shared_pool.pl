#!/oracle/product/perl
##!/usr/local/bin/perl
#
# Name    : flush_shared_pool.pl
# Version : 1.1
#
#
#  swei   05-apr-2004 created
#

require "/usr/tools/oracle/Standard/script/perllib.pl";
require "ctime.pl";
use Getopt::Std;
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


$parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
$exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";
chomp($host = `/bin/uname -n`);
getopt('s');
$sid         = $opt_s if defined($opt_s) || &Usage("");
&Get_Page_Exe;


#.....................................................................
#       Main
#.....................................................................
    ($mailto,$pageto,$warn,$alert)=&StdDBPackage::get_default_value($sid);
	$OracleSid   = $sid;
	&Set_Oracle_Home($OracleSid);
$dbh = DBI->connect("dbi:Oracle:", "", "") || die $ora_errstr;
        $dbh->do( "alter system flush shared_pool") || die $ora_errstr;
        $dbh->do( "alter system flush shared_pool") || die $ora_errstr;
        $dbh->do( "alter system flush shared_pool") || die $ora_errstr;
$dbh->disconnect() || die  $ora_errstr;



#-------------------------------------------------------------------------------
# SUB Usage
#-------------------------------------------------------------------------------
sub Usage {

    print "$_[0]";
    print "\n","-"x80, "\nUsage:\n\nflush_shared_pool.pl -s <SID> \n";
    exit (1);
}


#-------------------------------------------------------------------------------
# SUB GET_PAGE_EXE
#-------------------------------------------------------------------------------
sub Get_Page_Exe {

    $PageExe = "/usr/local/bin/epage"  if (-f "/usr/local/bin/epage");
    $PageExe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $PageExe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");


    if (!defined($PageExe)) {
       print("long_running.pl on $host: epage/pageme executable not ".
             "found. Aborting...");
        exit (1);
    }
}

#-------------------------------------------------------------------------------
# SUB SET_ORACLE_HOME
#-------------------------------------------------------------------------------
sub Set_Oracle_Home {
    open(ORATAB, "/etc/oratab") || &Show_Error("Can't Open /etc/oratab", "$!");

    while (<ORATAB>) {
       if (/^${OracleSid}:/i) {
          $oracle_home = (split(':'))[1];
          $ENV{'ORACLE_HOME'} = $oracle_home;
          $ENV{'ORACLE_SID'}  = $OracleSid;
        ($oracle7)=&StdDBPackage::check_oracle7($OracleSid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
	  $ENV{'ORA_NLS32'} = "";
	  $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
	  $ENV{'ORA_NLS32'} = "";
	  $ENV{'ORA_NLS33'} = "";
          }
        }
        &StdDBPackage::which_lib();
       }
    }
    close(ORATAB);
}

#-------------------------------------------------------------------------------
# SUB MAIL_IT
#-------------------------------------------------------------------------------
#sub Mail_It
#{
#    open (MAIL, "|/usr/bin/mailx -s \"$_[0]\"  $MailTo < $_[1]");
#    close (MAIL);
#    #print "";
#}

#-------------------------------------------------------------------------------
# SUB PAGE_IT
#-------------------------------------------------------------------------------
sub Page_It {

    my @PageMsg = @_;

    while ($PageMsg = pop(@PageMsg)) {
       print "$PageExe \"$PageTo\" \"$PageMsg\"";
       #`$PageExe \"$PageTo\" \'$PageMsg\'`;
    }
}

#-------------------------------------------------------------------------------
# Sub Show_Error
#-------------------------------------------------------------------------------
sub Show_Error {

    my $Subject;
    my $MesgBody;


    ($Subject, $MesgBody) = @_;

    $Subject   = "FAILED - [ $0 ] -  ".$Subject;
     
    $Subject   =~ s/\.\///;
    $MesgBody  = "\nHost  - $host, SID - $sid\n";
    $MesgBody .= "Error - $_[0].$message\n";

    #`mailx -s "$Subject" ${MailTo}\@cisco.com <<EOF\n$MesgBody\nEOF\n`;

    exit(0);
}


sub get_exception_value
{

    if (-r $exceptfile)
    {

    open(EXCEPTFILE, $exceptfile) || die "Can't Open $parfile. $!";
    while (<EXCEPTFILE>)
    {

       next unless (/^LONG:/ && /$sid:/ );
       {
          ($long, $sid, $mailto, $pageto, $RunningForHrs) = split(/:/);
          chomp($alert);
          #print "$sid $mailto $pageto $RunningForHrs \n";
       }
    } 
    close(EXCEPTFILE);
    }
}

