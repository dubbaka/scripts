#!/oracle/product/perl
###################################################################################
# Name    : verify_env.pl
# Version : 1.0
# Date    : 12-25-2006
# Author  : raraveet
# Description : 
#		- checks for perl link 
#		- checks perl version
#		  recommended minimum perl version 5.6.1
#		- checks oratab location
#		- scan through  oratab and connects to each database
#	          and reports success or failure .
###################################################################################

require "stat.pl";
require "ctime.pl";
use Getopt::Std;
use Time::Local;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;

$username          = "";
$passwd            = "";
getopt('sh');
$debug=$opt_d;
select(STDOUT); $| = 1;
select(STDERR); $| = 1;
select(STDOUT);

if (defined($opt_h)){
	&usage;
}

print "\nverify_env.pl:Start ...-------------------------------------------------\n";

# check perl version
if ($] < 5.006){
  print "\nERROR!!! Version $] is too old.";
  print "\nRecommended minimun perl version 5.6.1";
  print "\nChange the link /oracle/product/perl to minimun perl version of 5.6.1";
  print "\n\n";
  print "\nanyway continuing ...";
}

# check oratab
$oratab="/etc/oratab" ;
if ( ! -f "/etc/oratab" and -f "/var/opt/oracle/oratab" ) {
   $oratab="/var/opt/oracle/oratab";
   print "\nWARNING!! no /etc/oratab exists ! ";
}

# check default LISTENER
$lsnrcnt=qx(cat $oratab | grep "^LISTENER:" | wc -l);
if ( $lsnrcnt != 1 ) {
   print "\nWARNING!! no LISTENER defined in $oratab !";
}

if ( $^O eq "hpux" or $^O eq "solaris") {
 if ( ! -d "/oracle/product/perlmods" ) {
    print "\nWARNING!! perlmods doesn't exists in /oracle/product ";
    print "\nanyway continuing ...";
 }
 if (! -d "/oracle/product/perlmods/clnt964" ) {
    print "\nWARNING!! you do not have latest perlmods , ";
    print "\npossible that scripts may not work with some 9i databases , ";
    print "anyway continuing ...";
 }
}

print "\n\nConnecting to databases ...";
if ( defined($opt_s) ){
   $oracle_sid    = $opt_s ;
   chomp($cnt=`ps -aef | grep -v grep | grep -w "ora_pmon_$oracle_sid" |wc -l`);
   if ( $cnt == 1 ) {
	$dbstatus="DB UP";
   }
   else{
	  $dbstatus="DB DOWN";
   }
   #&ora_home($oracle_sid);
   &StdDBPackage::set_oraenv($oracle_sid);
   print "\n";
   $dbh =  &ConnectDB();
   print "Login to SID=$sid SUCCESS :) " if ( $dbh );
   print "Login to SID=$sid FAILED :()" if ( ! $dbh );
}
else{
  open (ALLTAB,"$oratab") || die 'cannot open $oratab';
  while (<ALLTAB>)
  {
   next if (/^#/ || /^\s/ );
   ($sid, $ora_home, $db_flag) = split(/:/);
   next if ($db_flag =~ /^N/ || $db_flag =~ /^n/ );
   $oracle_sid = $sid;
   chomp($cnt=`ps -aef | grep -v grep | grep -w "ora_pmon_$oracle_sid" |wc -l`);
   if ( $cnt == 1 ) {
	$dbstatus="DB UP";
   }
   else{
	$dbstatus="DB DOWN";
   }

    #&ora_home($oracle_sid);
    &StdDBPackage::set_oraenv($oracle_sid);
   print "\n";
   $dbh =  &ConnectDB(); 
   print "Login to SID=$sid SUCCESS :) " if ( $dbh );
   print "Login to SID=$sid FAILED :() " if ( ! $dbh );
  }
  close(ALLTAB);
}

print "\n\nverify_env.pl:End .-------------------------------------------------------\n\n";

sub usage
{
    print "$_[0]";
    print "\n";
    print "\nUsage:verify_env.pl OR "; 
    print "\n      verify_env.pl -s <SID>\n";
    print "\n";
    exit (1);
}

sub ora_home()
{
my $oracle_sid;

    $oracle_sid = $_[0];

    #-------------------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #-------------------------------------------------------------------------
	        open(ORATAB, "$oratab") || 
        		&dbstats_error("Can't Open $oratab $!\n");
    		while (<ORATAB>)
    		{
        		if (/^${oracle_sid}:/)
        		{
            			$oracle_home = (split(':'))[1];
            			$ENV{'ORACLE_HOME'} = $oracle_home;
        			$ENV{'ORACLE_SID'}=$oracle_sid;
        			$ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
        			$ENV{'SHLIB_PATH'} = "$oracle_home/lib";
        			$ENV{'TNS_ADMIN'} = "$oracle_home/network/admin";
        			($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        			($nls)=&StdDBPackage::check_nls;

        			if ($oracle7 eq "Y")
        			{
        				$ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        				$ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        			}
        			else
        			{
          			if ($nls eq "Y" )
          			{
				        $ENV{'ORA_NLS32'} = "";
          				$ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          			}
          			else
          			{
          				$ENV{'ORA_NLS32'} = "";
          				$ENV{'ORA_NLS33'} = "";
          			}
        		}

        		print "\nSID=$oracle_sid:ORACLE_HOME=$oracle_home:$dbstatus:" ;
        		&StdDBPackage::which_lib();
        		}
    		}
    		close(ORATAB);
}

sub ConnectDB
{
my $dbh;

    print "\nSID=$ENV{'ORACLE_SID'},ORACLE_HOME=$ENV{'ORACLE_HOME'},STATUS=$dbstatus\n";
    $dbh = DBI->connect("dbi:Oracle:", $username, $passwd) ;
    return($dbh);
}

sub DisconnectDB
{
    $dbh->disconnect if ($dbh);
}

sub dbstats_error()
{
my $errmsg = $_[0];

    print "ERROR: $errmsg";
    &DisconnectDB();
    exit(1);
}

