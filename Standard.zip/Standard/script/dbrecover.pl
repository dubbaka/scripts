#!/oracle/product/perl
# ....................................................................
#	Continuous database recovery dbrecover.pl
#	History:
#		 	jselvara	created
#	08-jun-2004	swei		modified for all databases
#	14-jun-2004	jselvara	modified for GMT
#       10-Sep-2005     raraveet        Introduced mail_after,
#                                       mails before paging duty
#	31-May-2006	raraveet	Modified def shutdown=Y  ,
#       31-May-2006     raraveet        Modified to take care lagtime
#	17-JUL-2006	raraveet	fixed bug related to sending email
#				
#
# ....................................................................
#	Declare Variables
# ....................................................................
require "/usr/tools/oracle/Standard/script/perllib.pl";
use Getopt::Std;
#$mailto = "mis-dba";
$pageto = "db-monitor-duty";
$sid = $ENV{'ORACLE_SID'};
$arch_suffix = "dbf";
$rtime = &get_time("HH:MI:SS");
$rdate = &get_date("YYYY-MM-DD");
$mailafter = 60;
$mailevery = 20;
$pageafter = 90;
$pageevery = 30;
$parallel = 20;
$shutdown = "Y";
$lagtime = 0;
$tz = "PST";
if ( -d "/opt/dce/tcl" )
{
$ENV{'TCL_LIBRARY'} = '/opt/dce/tcl';
}
$dbrecover_expect = "/usr/tools/oracle/recovery/scripts/recover_db";

# ....................................................................
#	get option
# ....................................................................
    getopt('abcdeklmpsthgz');
    &usage if (defined($opt_h));


    $sid         = $opt_s ? $opt_s: $sid;
    $arch_suffix = $opt_l ? $opt_l: $arch_suffix;
    $rtime       = $opt_t ? $opt_t: $rtime;
    $rdate       = $opt_d ? $opt_d: $rdate;
    $pageto      = $opt_p ? $opt_p: $pageto;
#    $mailafter   = $opt_a ? $opt_a: $mailafter;
#    $mailevery   = $opt_e ? $opt_e: $mailevery;
    $pageafter   = $opt_a ? $opt_a: $pageafter;
    $pageevery   = $opt_e ? $opt_e: $pageevery;
    $parallel    = $opt_c ? $opt_c: $parallel;
    $shutdown    = $opt_b ? $opt_b: $shutdown;
    $forcestart  = $opt_k ? $opt_k: 'N';
    $mailto      = $opt_m ? $opt_m: $mailto;
    $lagtime	 = $opt_g ? $opt_g: 0;
    $tz	         = $opt_z ? $opt_z: "PST";

# ....................................................................
#	set up LAG time if defined
# ....................................................................
if ($lagtime > 0 )
{
    if ($tz eq "GMT") {
        ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=gmtime(time-($lagtime*3600));
    } else {
        ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst)=localtime(time-($lagtime*3600));
    }
    $mon++;
    $year += 1900;
    $rdate = sprintf( "%04d-%02d-%02d", $year, $mon, $mday); 
    $rtime = sprintf( "%02s:%02s:%02s", $hour, $min, $sec);

#  if ($hour < $lagtime ) {
#	exit;  }
#  else
#  {  
#     $newhour = $hour - $lagtime;
#     $rtime = sprintf("%02s:%02s:%02s", $newhour, $min, $sec);
#  }
 
}
# ....................................................................
#	Main
# ....................................................................

    if (-f "/tmp/dbrecover_${sid}.pid")
    {
        open(PID, "/tmp/dbrecover_${sid}.pid") || die "Cannot open pid file. $!";
        $pid = <PID>;
        close(PID);

# A zero signal just checks to see if the process is alive

        $rc = kill 0, $pid;
        if ($rc)
        {
            if ($forcestart eq "Y")
            {
                `kill -15 $pid`;

            }
            else
            {
                print "db_recover.pl already running under $pid\n";
                exit(1);
            }
        }
    }

    open(PID, "> /tmp/dbrecover_${sid}.pid");
    print PID $$;
    close(PID);
    $parfile = "/usr/tools/oracle/recovery/par/dbrecover_${sid}.par";
    $logfile = "/usr/tools/oracle/recovery/log/dbrecover_${sid}_${rtime}.log";
    open(RPAR, ">$parfile") || die "Cannot open reco.par. $!";
    print RPAR "########################\n";
    print RPAR "# manditory Parameters #\n";
    print RPAR "########################\n";
    print RPAR "\n";
    print RPAR "db_name=", $sid, "\n";
    print RPAR "\n";
    print RPAR "#######################\n";
    print RPAR "# Optional Parameters #\n";
    print RPAR "#######################\n";
    print RPAR "\n";
    print RPAR "log_suffix=", $arch_suffix, "    #log or dbf, defaults to dbf\n";
    print RPAR "recover_to_time=", $rtime, "     #defaults to 23:00:00\n";
    print RPAR "recover_to_date=", $rdate, "     #defaults to sysdate\n";
    print RPAR "page_list=", $pageto, "          #comma seperated list to page on error\n";
    print RPAR "mail_after=", $mailafter, "      #minutes to wait for log before paging\n";
    print RPAR "mail_every=", $mailevery, "      #mail every X min until log is supplied\n";
    print RPAR "page_after=", $pageafter, "      #minutes to wait for log before paging\n";
    print RPAR "page_every=", $pageevery, "      #page every X min until log is supplied\n";
    print RPAR "pct_parallel=", $parallel, "     #parallel recovery processes\n";
    print RPAR "shutdown_db=", $shutdown, "      #shutdown database on succussful recovery\n";
    print RPAR "mail_to=", $mailto, "            #comma seperated list to email upon successful completion. Defaults to No one.\n" if ( $mailto );
    print RPAR "timezone=", $tz, "                #timezone settings. Defaults to PST.\n";
    close(RPAR); 
    print("$dbrecover_expect $parfile > $logfile 2>&1\n");
    system("$dbrecover_expect $parfile > $logfile 2>&1");
    unlink $parfile;
    exit(0);

# ....................................................................
#	 Sub 
# ....................................................................
sub usage()
{
    print "$_[0]";
    print "
usage is of either:

        $0 [ -h help ] | [ -s sid ] [ -l dbf ] [-t 23:00] [-d 2004-06-11] [-p db-monitor-duty] [-a 90 ] [-e 30 ] [-c 30] [-b Y] [-k N] [-m mis-dba] [-g lagtime]
where:

        -s sid  SID
        -h      help                    display this help
        -l	archive file suffix
	-t	recover time
	-d	recover date
	-p	page to
	-a	page after x minutes
	-e	page after every x minutes 
	-c	parallel degree
	-b	shutdown the database
	-k	force to restart
	-m	mail to
	-g	recover lag time in hours

    \n";
    exit(0);
}

