#!/oracle/product/perl
#############################################################################
# Name          : rman_arch_utl.pl                                          #
#                                                                           #
# Purpose       : To clear archive log                                      #
#                                                                           #
# Parameters    : (1) SID  (-s)                                             #
#                 (2) RMAN SID (-c)  - Optional,if omitted control file will#
#                                      be used for archive deletion         #  
#                 (3) Retention (-r)  - Optional,defaults to 1Hr            #
#                 (4) mailid (-m)                                           #
#                 (5) DataGuard or Non DG (-d) - Optional,default DG        #
#                 (6) Device type (-t)- Optional (disk/tape - default disk) # 
#                                                                           #
# Usage         : ./rman_arch_utl.pl -s SID -c RMAN SID -r Retention -d N   #
#                                                                           #
# Created By    :  Melvin Gerold (mgerold)                                  #
# Creation Date :  August 2011                                              #
#############################################################################
require "ctime.pl";
use Getopt::Std;
use Time::Local;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


getopt('scrpmdt');
$sid         = $opt_s if defined($opt_s) || &usage("");
$rcat        = $opt_c if defined($opt_c) ;
$ret         = 1 if !defined($opt_r);
$ret = $opt_r if defined($opt_r);
$data_guard  = "Y";
$data_guard  = $opt_d if defined($opt_d);
$device_type = "sbt_tape" if !defined($opt_t);
$device_type = $opt_t if defined($opt_t);
my $connect_mode = 2;

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
$mon++;
$year += 1900;
$date_str =  $mon.'_'.$mday.'_'.$hour.'_'.$min.'_'.$sec;

$logfile     = "/usr/tools/oracle/Standard/script/log/${sid}_clear_archive.${date_str}.log";

    undef($mailto);
    undef($pageto);
    $mailto = "dba-duty";
    $mailto = $opt_m if defined($opt_m);
    $pageto = $opt_p if defined($opt_p);

    my @recpA = split(',', $mailto);
    $mailto = "";
    foreach $recp (@recpA)
    {
       $recp =~ s/^\s+//; #remove leading spaces
       $recp =~ s/\s+$//; #remove trailing spaces
       $recp =~ s/\@cisco.com//; #removes @cisco.com
       $recp =~ s/\@epage.cisco.com//; #removes @epage.cisco.com
       $mailto .= $recp . "\@epage.cisco.com,"; #concatanate with @epage.cisco.com,
    }
    chop($mailto) if $mailto ne ""; #Remove last comma from mailto


    chomp($host = `/bin/uname -n`);
    #&get_pageexe();
    open(LOGFILE, ">${logfile}") || die "Cannot open logfile. $!\n";
    print LOGFILE "Start time ", &ctime(time), "\n";
    $oracle_sid = $sid;
    $ENV{'ORACLE_SID'}=$oracle_sid;
    &ora_home($oracle_sid);

    
    $dbh = DBI->connect("dbi:Oracle:", "", "",{ora_session_mode => $connect_mode} ) || die $DBI::errstr;

     # First get Database Name
 
     &get_dbname();

     $cred_file = "/usr/tools/oracle/.refresh/password_${db_name}.txt";

    #Connect to catalog if catalg name is passed 
    if (defined($opt_c))
      {  
            &get_credentials();
            $rmh = DBI->connect("dbi:Oracle:$rcat", ${user_name}, ${rman_pwd}) || 
            &notify_error("Cannot Connect to Catalog Database $rcat: $DBI::errstr");
      } 



    if (defined($opt_c))
      {
         &check_rman_cat();
      }

     #If the Database is Primary do the following
      if ( $db_role eq "PRIMARY")
       { 
         print  "Database is PRIMARY ........\n";
         print LOGFILE "Database is PRIMARY ........\n";
         # Get the thread number for this instance
         &get_thread();

         # Get Archive List
          &get_archive_seq();

         # Delete the archive files  

         if (defined($arch_seq))
          {
            if (defined($opt_c))
              {   
               &rman_delete_cat();
              }
            else 
             {
               &rman_delete_ncat();
             } 
          }
        else
          {
            print "No candidate archive log found for deletion which met the delete criteria !...\n";
            print LOGFILE "No candidate archive log found for deletion which met the delete criteria !...\n"; 
          }
       }
     else
       {
         print  "Database is STANDBY .....\n";
         print LOGFILE "Database is STANDBY .....\n"; 
        # Get Archive List to be deleted from Standby
         &get_archive_sby_seq();
         if (defined($sby_seq_arr))
          {
            foreach(@$sby_seq_arr)
               {
                ($db_thread, $arch_seq)  = (@$_);
                   if (defined($opt_c))
                     {
                      &rman_delete_cat_sby();
                     }
                   else
                     {
                      &rman_delete_ncat_sby();
                     }
               } 
          }
        else
          {
            print "No candidate archive log found for deletion which met the delete criteria !...\n";
            print LOGFILE "No candidate archive log found for deletion which met the delete criteria !...\n";
          }


       } 

    print "Archive log delete script completed successfully ! \n";
    print "Check log ${logfile} for details ....\n";
    $rc = $dbh->disconnect;
    if (defined($opt_c))
     {
      $rc = $rmh->disconnect;
     } 
    print LOGFILE  "\nEnd time ", &ctime(time), "\n";
    close(LOGFILE);
    exit (0);

sub ora_home
{
    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_HOME'} = $oracle_home;
        $ENV{'LD_LIBRARY_PATH'} = "$ora_home/lib";
        $ENV{'SHLIB_PATH'} = "$ora_home/lib";
        #$ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }

        #print "Sid $oracle_sid home $ora_home\n" if defined($opt_d);
        #print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();

        #&Which_Lib();

        }
    }
    close(ORATAB);
}


sub pageit 
{
my @pagemsg = @_;

    while ($pagemsg = pop(@pagemsg))
    {
        foreach $page (split /,/, $pageto)
        {
            `$pageexe $page \'$pagemsg\'`;
        }
    }
}

sub usage() 
{
    #print "$_[0]";
    print "Usage:\n rman_arch_utl.pl -s <SID> -c <RMAN SID> -r <Retention> \n";
    exit (1);
}

sub maildba
{
open (MAIL, "|mailx -s \"$_[0]\" $mailto ");
printf(MAIL "$_[0]");
close (MAIL);
}

sub pagedba
{
open (MAIL, "|mailx -s \"$_[0]\" $pageto ");
printf(MAIL "$_[0]");
close (MAIL);
}

sub get_pageexe
{
    $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
    $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
    $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");
    $pageexe = "/usr/tools/oracle/itopage.pl" if (-f "/usr/tools/oracle/itopage.pl");

    if (!defined($pageexe))
    {
        print("rman_arch_utl.pl on $host: epage/pageme executable not found. Aborting...");
        exit (1);
    }
}

sub show_error()
{

    print "$_[0]. $DBI::errstr\n";
    exit (1);
}


sub get_dbname()
{
   print LOGFILE "Getting the Database Name for  instance $sid...\n";

    $stmt = "select name,database_role from v\$database";
    $sth = $dbh->prepare($stmt) ||
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() ||
        &show_error("Error while executing $stmt");
    ($db_name,$db_role) = $sth->fetchrow_array();
    $sth->finish();
    print LOGFILE "Database Name  is ---> $db_name .....what a nice name !!!! \n\n";
}


sub check_rman_cat()
{
   print LOGFILE "Checking if Database $db_name is registered in RMAN Catalog...\n";

    $stmt = "select count(*)  from rc_database where name='$db_name'";
    $sth = $rmh->prepare($stmt) ||
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() ||
        &show_error("Error while executing $stmt");
    ($rman_reg) = $sth->fetchrow_array();
    $sth->finish();
    
    if ($rman_reg <= 0)
     {
       print LOGFILE "Database $db_name is not registered in RMAN....What is the point !!!\n";
       print "Database $db_name is not registered in RMAN....script cannot be used for archive deletion \n";
       exit 1; 
       &maildba("rman_arch_utl.pl ->  Database $db_name is not registered in RMAN....Cannot clear archive log \n ");
     }
    else
     {
       print LOGFILE "OK,  Database $db_name is registered in RMAN Catalog $rcat....proceeding...\n\n";
     }

}

sub get_thread()
{
   print LOGFILE "Getting the thread Info for instance $sid...\n";

    $stmt = "select thread# thread from v\$instance";
    $sth = $dbh->prepare($stmt) ||
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() ||
        &show_error("Error while executing $stmt");
    ($db_thread) = $sth->fetchrow_array();
    $sth->finish();
    print LOGFILE " The instance $sid is  Thread -> $db_thread \n\n"; 
}


sub get_archive_seq()
{
    print LOGFILE "Getting the target sequence# for deletion ...\n";

    if ( $data_guard eq "Y")
      {
        $stmt =  "select max(sequence#) from v\$archived_log
             where thread# = $db_thread and standby_dest='YES'
             and round(floor((((sysdate-completion_time)*24*60*60)/3600)*3600)/60,0) > $ret*60
             and  applied = 'YES' ";
      }
   else
     {
       $stmt =  "select max(sequence#) from v\$archived_log
             where thread# = $db_thread 
             and round(floor((((sysdate-completion_time)*24*60*60)/3600)*3600)/60,0) > $ret*60 ";
     }
   
    $sth = $dbh->prepare($stmt) ||
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() ||
        &show_error("Error while executing $stmt");
    ($arch_seq) = $sth->fetchrow_array();
    $sth->finish();
    if ($sth->rows <= 0)
      {
        print LOGFILE "No Archive files to be cleaned up  \n";
        $sth->finish();
        exit 0;
      }
    $sth->finish(); 

}


sub get_archive_sby_seq()
{
    print LOGFILE "Getting the  sequence# for deletion from Standby...\n";

       $stmt =  "select thread#,max(sequence#) from v\$archived_log where applied='YES'
                 and round(floor((((sysdate-completion_time)*24*60*60)/3600)*3600)/60,0) > $ret*60  group by thread# ";

    $sth = $dbh->prepare($stmt) ||
        &show_error("Error while preparing $stmt");
    $rc = $sth->execute() ||
        &show_error("Error while executing $stmt");
    $sby_seq_arr = $sth->fetchall_arrayref;

    $sth->finish();
    if ($sth->rows <= 0)
      {
        print LOGFILE "No Archive files to be cleaned up in Standby Database \n";
        $sth->finish();
        exit 0;
      }
    $sth->finish();

}



sub get_credentials()
{
open(CRED, ${cred_file}) || die "Cannot open credential file";
    while (<CRED>)
    {
            ($user_name,$pwd) = (split('='));
             chop($user_name);
              chomp($pwd);
              $pwd =~ s/^\s+//;  
             if ( ${user_name} eq "RMAN_CG1PRD")
               {
                  $rman_pwd = $pwd;
               }
    }

}

sub rman_delete_cat()
{
print LOGFILE "Archive logs eligible for cleanup is upto sequence# $arch_seq \n\n";
print LOGFILE "Deleting archive logs with sequence# less than $arch_seq for thread $db_thread \n\n";
print LOGFILE "Connecting to RMAN catalog ${rcat} for archive cleanup \n";
$rn=`$oracle_home/bin/rman  <<EOF
spool log to ${logfile} append;
connect catalog ${user_name}/${rman_pwd}\@${rcat};
connect target;
delete noprompt archivelog until sequence $arch_seq thread $db_thread backed up 1 times to device type $device_type ;
spool log off;
exit;
EOF`;
}

sub rman_delete_cat_sby()
{
print LOGFILE "Archive logs eligible for cleanup on Standby is upto Sequence# $arch_seq for Thread $db_thread \n\n";
print LOGFILE "Deleting archive logs with sequence# less than $arch_seq for thread $db_thread \n\n";
print LOGFILE "Connecting to RMAN catalog ${rcat} for archive cleanup \n";
$rn=`$oracle_home/bin/rman  <<EOF
spool log to ${logfile} append;
connect catalog ${user_name}/${rman_pwd}\@${rcat};
connect target;
delete noprompt archivelog until sequence $arch_seq thread $db_thread  ;
spool log off;
exit;
EOF`;
}


sub rman_delete_ncat()
{
print LOGFILE "Archive logs eligible for cleanup is upto sequence# $arch_seq \n\n";
print LOGFILE "Deleting archive logs with sequence# less than $arch_seq for thread $db_thread \n\n";
print LOGFILE "Using Controlfile  for archive cleanup \n";
$rn=`$oracle_home/bin/rman  <<EOF
spool log to ${logfile} append;
connect target;
delete noprompt archivelog until sequence $arch_seq thread $db_thread backed up 1 times to device type $device_type ;
spool log off;
exit;
EOF`;
}


sub rman_delete_ncat_sby()
{
print LOGFILE "Archive logs eligible for cleanup on Standby is upto Sequence# $arch_seq for Thread $db_thread \n\n";
print LOGFILE "Deleting archive logs with Sequence# less than $arch_seq for Thread $db_thread \n\n";
print LOGFILE "Using Controlfile  for archive cleanup \n";
$rn=`$oracle_home/bin/rman  <<EOF
spool log to ${logfile} append;
connect target;
delete noprompt archivelog until sequence $arch_seq thread $db_thread  ;
spool log off;
exit;
EOF`;
}


sub notify_error()
{
 $err_str=$_[0];
 print "$err_str\n";
 print LOGFILE "$err_str", "\n";

if ($err_str =~ /ORA-/)
 {
  print "Database Connectivity Issue...exiting....!\n";
  print LOGFILE "Oracle instance connectivity issue ....! \n";
  &maildba("rman_arch_utl.pl -> Archive log delete ....Cannot connect to Database ....... \n ");
  exit(1);
 }
}

