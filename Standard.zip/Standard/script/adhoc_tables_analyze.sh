#!/usr/bin/ksh

#==================================================
# Help Function
#==================================================

script_help()
{
echo "
NAME                : adhoc_tables_analyze.sh
Functionality       : This script will help to analyze a table in the database.
		      If the database is ERP, script will prompt for apps pwd and then will anlayze the table and also takes care of histograms if any on the table
		      If the database is non-ERP, script will analyse the table if it has no histograms. If histograms exists, script errors out.
SYNTAX

    adhoc_tables_analyze.sh       		        Options and Arguments:
           -s						# Sid Name (Mandatory argument)
	   -o						# Table Owner (Mandatory argument, if "-f" is not passed)
	   -t						# Table Name (Mandatory argument, if "-f" is not passed)
	   -p						# Analyze Percentage. If not passed, will analyze with the existing percentage.
							  If neither passed nor the table is analyzed till now, script will give a message and will not analyze the table.
	   -d						# Degree (If not passed, will analyze with default degree 8)
           -f                                           # If more than one table to be analyzed, put the details of the tables in a file 
	                                                  and pass it. Pattern is the file should be as below.(Mandatory argument, if "-o and -t" are not passed)
	         					  <Owner>|<Table name>|<Percentage>|<Degree>

Note:	If the table name or owner consists of '$', please replace the '$' with '\\$' and pass to script.
	For eg., OPS\$ORALCE should be passed as OPS\\\$ORALCE

EXAMPLES:
	./adhoc_tables_analyze.sh -s CTSPRD1 -o APPS -t XXCSS_QOT_ORDER_CTRL -p 10 -d 8
        ./adhoc_tables_analyze.sh -s CTSPRD1 -o APPS -t XXCSS_QOT_ORDER_CTRL -p 10
        ./adhoc_tables_analyze.sh -s CTSPRD1 -o APPS -t XXCSS_QOT_ORDER_CTRL -d 8
        ./adhoc_tables_analyze.sh -s CTSPRD1 -f /usr/tools/oracle/Standard/script/tables2analyze.txt
"
}

Set_Env()
{
Work_Dir=/usr/tools/oracle/Standard/script

if [ `ps -ef | grep "ora_smon_${ORA_SID}$" | grep -v grep  | wc -l` -eq 0 ]
then
       echo "===========@ Database $ORA_SID seems to be not running or exists on this host. Please check @==========="
        exit
fi

if [ -f /usr/local/bin/setdb ]
then
        . /usr/local/bin/setdb $ORA_SID > /dev/null 2>/dev/null
else
        export PATH=$PATH:/usr/local/bin
        export ORACLE_SID=$ORA_SID
        export ORAENV_ASK=NO
        . oraenv
fi

DBSTATUS=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select 'I_AM_OK' from dual;
EOF
)`
if [ "$DBSTATUS " != "I_AM_OK " ]; then
     echo $DBSTATUS
fi

DBVER=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select banner from v\\$version;
EOF
)`
db_ver=`echo $DBVER | grep "Enterprise Edition Release" | awk -F"Release" '{print $2}' | awk -F"." '{print $1}'`

ERPCHECK=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select 'YES' from applsys.fnd_product_groups where APPLICATIONS_SYSTEM_NAME=(select name from v\\$database);
EOF
)`
if [ "$ERPCHECK " == "YES " ]; then
	db_erp=Y
	echo "Please enter apps password: "
	read AppsPwd

AppsPwd_Chk=`(sqlplus -s /<<EOF
connect apps/$AppsPwd
set echo off verify off head off feed off pages0 trimspool on;
select 'Yes' from dual;
exit
EOF
)`
if [ "$AppsPwd_Chk " != "Yes " ]; then
echo "========@ Apps password entered is wrong @========"
exit
fi
export AppsPwd
else
	db_erp=N
fi

}

Check_Parameters()
{
OBJCOUNT=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select count(1) from dba_tables where upper(owner)=upper('${towner}') and upper(table_name)=upper('${tname}');
EOF
)`
if [ "$OBJCOUNT" -ne "1" ]; then
	echo "Table" $tname "does not exists under owner" $towner
fi
export OBJCOUNT

if [ -z ${percentage} ]; then
percentage=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages 0 trimspool on;
select trim(nvl(round((nvl(sample_size,0)/decode(num_rows,0,1,'',1,num_rows))*100,1),10)) from dba_tables where upper(owner)=upper('${towner}') and upper(table_name)=upper('${tname}');
EOF
)`
fi

if [ $percentage -eq 0 ]; then
echo " Analyze percentage is not passed for table" ${towner}"."${tname} "and there is no previous analyze done for this table. We request you to pass the percentage. "
continue
fi

if [ -z ${degree} ]; then
degree=8
fi

}

Chk4Errors()
{
##### Checking for errors from analyze spool file #####
if [ `cat $spool_log | grep "ORA-" | wc -l` -gt 0 ]; then
        echo "Analyze of ${towner}"."${tname} errored out. Please check the file $spool_log for more details."
else
        Time=`cat $spool_log | grep "Elapsed" | awk '{print $2}'`
        echo "Analyze of ${towner}"."${tname} completed. Time taken : $Time"
fi
}

Chk4Histograms()
{
if [ $db_ver -le 9 ]; then
Histogram_Chk=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select trim(count(1))
from (select owner,table_name,column_name,max(endpoint_number) endpoint_number from dba_histograms group by owner,table_name,column_name) dh,
dba_tables dt, dba_tab_col_statistics dts
where dh.owner=dt.owner
and dh.table_name=dt.table_name
and dh.table_name=dts.table_name
and dh.owner= dts.owner
and dh.column_name=dts.column_name
and dts.num_distinct > 1
and dt.num_rows >1 
and dh.endpoint_number > 2
and upper(dt.owner)=upper('${towner}') and upper(dt.table_name)=upper('${tname}');
EOF
)`
else
Histogram_Chk=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select trim(count(1))
from (select owner,table_name,column_name,max(endpoint_number) endpoint_number from dba_histograms group by owner,table_name,column_name) dh,
dba_tables dt, dba_tab_col_statistics dts
where dh.owner=dt.owner
and dh.table_name=dt.table_name
and dh.table_name=dts.table_name
and dh.owner= dts.owner
and dh.column_name=dts.column_name
and dts.histogram<>'NONE'
and dts.num_distinct > 1
and dt.num_rows >1 
and dh.endpoint_number > 2
and upper(dt.owner)=upper('${towner}') and upper(dt.table_name)=upper('${tname}');
EOF
)`
fi

export Histogram_Chk
}

Table_Analyse()
{
tabowner=`echo $towner | sed 's/\\$//g'`
tabname=`echo $tname | sed 's/\\$//g'`
spool_log=/tmp/${tabowner}_${tabname}.log
export spool_log
rm -f $spool_log
Chk4Histograms;
if [ $db_erp == "Y" ]; then
FND_HIST_CHK=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select count(1) from apps.fnd_histogram_cols where upper(owner)=upper('${towner}') and upper(table_name)=upper('${tname}');
EOF
)`
if [ "$Histogram_Chk" -ge "1" ] && [ $FND_HIST_CHK -lt 1 ]; then
	echo "Histogram entry for the table " ${towner}"."${tname} " found in dba_histograms but not in fnd_histogram_cols. Entry should be made in fnd_histogram_cols for this table.Please check with Primary DBA."
else
sqlplus -s "/ as sysdba"<<EOF > /dev/null
connect apps/$AppsPwd
set time on timing on feed on echo on
spool $spool_log
set echo on
exec FND_STATS.GATHER_TABLE_STATS (ownname => '${towner}', tabname => '${tname}', percent => ${percentage}, degree => ${degree}, granularity => 'ALL', INVALIDATE => 'N', cascade => TRUE);
EOF
Chk4Errors;
fi

else
if [ "$Histogram_Chk" -ge "1" ]; then
echo "Table" ${towner}"."${tname} "has histograms. We suggest you to analyze table through DBMS_STATS with method_opt option to collect histgrams."
else
sqlplus -s "/ as sysdba"<<EOF > /dev/null
set time on timing on feed on echo on
spool $spool_log
set echo on
exec DBMS_STATS.GATHER_TABLE_STATS (ownname => '${towner}', tabname => '${tname}', estimate_percent => ${percentage}, block_sample => TRUE, degree => ${degree}, method_opt => 'FOR ALL COLUMNS SIZE 1', granularity => 'ALL', cascade => TRUE);
EOF
Chk4Errors;
fi
fi

}

#===============
# MAIN
#===============

########## Reading Parameters ###########

while getopts s:o:t:p:d:f: OPTNAME
do
[ "$OPTNAME" = "?" ] && exit 1
  case $OPTNAME in
    s)  # Sid
        ORA_SID=${OPTARG};
        ;;
    o)  # Table Owner
        towner=${OPTARG};
        ;;		
    t)  # Table Name
        tname=${OPTARG};
        ;;
    p)  # Analyse percentage
        percentage=${OPTARG};
        ;;
    d)  # Degree of Analyze
        degree=${OPTARG};
        ;;		
    f) # File containg the Tables details
	  Table_details=${OPTARG};
        ;;
   esac
done

if [ -z ${ORA_SID} ]; then
        script_help
	exit
elif [ -z ${Table_details} ]; then
	if [ -z ${towner} ] || [ -z ${tname} ]; then
		script_help
		exit
	fi
fi

Set_Env;

if [ -z ${Table_details} ]; then
	Check_Parameters;
	if [ $OBJCOUNT -eq 1 ] && [ $percentage -ne 0 ]; then
		Table_Analyse;
	fi
	exit
else
	for i in `cat $Table_details | grep -v ^#`
	do
		towner=`echo $i | awk -F"|" '{print $1}'`
		tname=`echo $i | awk -F"|" '{print $2}'`
		percentage=`echo $i | awk -F"|" '{print $3}'`
		degree=`echo $i | awk -F"|" '{print $4}'`
		Check_Parameters;
		if [ $OBJCOUNT -eq 1 ] && [ $percentage -ne 0 ]; then
			Table_Analyse;
		fi
	done
fi
exit
