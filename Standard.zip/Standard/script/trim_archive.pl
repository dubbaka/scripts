#!/usr/local/bin/perl
#
#  FILE:        trim_archive.pl
#
#  DESCRIPTION: 
#     Removes old Oracle archive log files and 
#     compresses recent archive log files.
#
#  REVISION HISTORY:   
#     01May96 - CSDaily, Initial coding.
#     Modified by ilahiri Jun 18, 1996
#     Modified by swei    Jun 09, 2004 for generic use
# 
#
#------------------------------------------------------------------------------
# Declare
#------------------------------------------------------------------------------
use Getopt::Std;
$COMPRESSED_RETAIN_TIME  = 172800;     #  2 days in seconds
$ARCHIVED_RETAIN_TIME    = 60;         #  1 min in seconds

# ....................................................................
#       get option
# ....................................................................
getopt('hdcr');
&usage if (defined($opt_h));
$ARCHIVE_DIR  = $opt_d;
$COMPRESSED_RETAIN_DAY  = $opt_r ;
$ARCHIVED_RETAIN_MIN    = $opt_c ;
if ( !($opt_d) )
{
        &usage;
        exit;
}
if ($opt_r)
{
	$COMPRESSED_RETAIN_TIME = $COMPRESSED_RETAIN_DAY * 86400;
	print "Compress Retain Time:  $COMPRESSED_RETAIN_DAY Days =";
        print "$COMPRESSED_RETAIN_TIME seconds \n";
}
if ($opt_c)
{
	$ARCHIVED_RETAIN_TIME = $ARCHIVED_RETAIN_MIN * 60;
	print "Archive Time:  $ARCHIVED_RETAIN_MIN minutes =";
        print "$ARCHIVED_RETAIN_TIME seconds \n";
}

#------------------------------------------------------------------------------
# Main
#------------------------------------------------------------------------------
#


   &DoInit();

   &DoCompressedFiles();

   &DoArchivedFiles();

#   system("mailx -s \"$MAIL_SUBJECT\" $MAIL_RECIPIENTS < $MAIL_FILE");
#   unlink("$MAIL_FILE");

   exit 0;

# ....................................................................
#        Sub 
# ....................................................................
sub usage()
{
    print "$_[0]";
    print "
usage is of either:
        $0 [ -h help ] | [-d directory ] [-r Retain x Days] [-c compress x minute]
where:

        -h      help                    display this help
        -d directory
        -r Retain compress files x days (default : 2 days)
	-c compress archive logs if the log is > x minutes (default : 1 min) 	

\n";
    exit(0);
}

#------------------------------------------------------------------------------
# DoCompressedFiles
#------------------------------------------------------------------------------
sub DoCompressedFiles {

   print "\nRemoving Compressed ArchiveLog Files More Than $COMPRESSED_RETAIN_TIME Seconds Old...\n";

#   if (! opendir(DIR, "$ARCHIVE_RETAIN_DIR")) {
   if (! opendir(DIR, "$ARCHIVE_DIR")) {
#      print "...**ERROR** Can't open $ARCHIVE_RETAIN_DIR\n";
      print "...**ERROR** Can't open $ARCHIVE_DIR\n";
      return 1
   }
   local(@filenames) = readdir(DIR);
   closedir(DIR);
   
   $current_time = time();

   for (@filenames) {
      if (/\.dbf.gz$/) { 
         ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
#             $atime,$mtime,$ctime,$blksize,$blocks) = stat("$ARCHIVE_RETAIN_DIR/$_");
             $atime,$mtime,$ctime,$blksize,$blocks) = stat("$ARCHIVE_DIR/$_");

         $seconds_old = $current_time - $mtime;
         # print "**DEBUG**  $_  so[$seconds_old] ct[$current_time] mt[$mtime]\n";

         print "Seconds old $seconds_old \n";
         if ($seconds_old > $COMPRESSED_RETAIN_TIME) {
            print "Removing ... $_ ($seconds_old seconds old)\n";
#            unlink "$ARCHIVE_RETAIN_DIR/$_";
            unlink "$ARCHIVE_DIR/$_";
         }
      }
   }

   return 0;
}

#------------------------------------------------------------------------------
# DoArchivedFiles
#------------------------------------------------------------------------------
sub DoArchivedFiles {

   print "\nCompressing ArchiveLog Files More Than $ARCHIVED_RETAIN_TIME Seconds Old...\n";

   if (! opendir(DIR, "$ARCHIVE_DIR")) {
      print "...**ERROR** Can't open $ARCHIVE_DIR\n";
      return 1
   }
   local(@filenames) = readdir(DIR);
   closedir(DIR);
   
   $current_time = time();

   for (@filenames) {
      if (/\.dbf$/) { 
         ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
             $atime,$mtime,$ctime,$blksize,$blocks) = stat("$ARCHIVE_DIR/$_");

         $seconds_old = $current_time - $mtime;
         # print "**DEBUG**  $_  so[$seconds_old] ct[$current_time] mt[$mtime]\n";

         if ($seconds_old > $ARCHIVED_RETAIN_TIME) {
            print "... $_ ($seconds_old seconds old)\n";
            `/usr/local/bin/gzip "$ARCHIVE_DIR/$_"`;
#            system("mv $ARCHIVE_DIR/*gz $ARCHIVE_RETAIN_DIR"); 
         }
      }
   }

   return 0;
}
#------------------------------------------------------------------------------
# DoInit
#------------------------------------------------------------------------------
#
sub DoInit {


    # Security Blankets.
    $ENV{'IFS'} = '' if $ENV{'IFS'};
    $ENV{'PATH'} = '/usr/bin:/usr/sbin:/usr/ucb:/usr/local/bin';
    umask(022);

#    open(STDOUT, ">$MAIL_FILE") || die "Can't redirect stdout.\n";
    open(STDERR, ">&STDOUT")   || die "Can't dup stdout.\n";

    select(STDERR); $| = 1;    # Force flush after every write or print
    select(STDOUT); $| = 1;

}
