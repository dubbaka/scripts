#!/oracle/product/perl
use Oraperl;
use Getopt::Std;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;



if (!getopts('hu:b:d:') || defined($opt_h))
{
    print "Usage: top_sqlarea.pl -h -u <user> -b <buffer gets>";
    print " -d <disk reads>\n";
    print "\t-h Prints Usage Text\n";
    print "\t-u Run for Specified User e.g. (\"APPS\")\n";
    print "\t-b Prints SQL Stmts Over This # of Buffer Gets\n";
    print "\t-d Prints SQL Stmts Over This # of Disk Reads\n";
    exit 0;
}

if (defined($opt_u))
{
    $user_where = "and PARSING_SCHEMA_ID = (select user_id from dba_users \
                   where username = '" . uc($opt_u) . "') ";
}

if (defined($opt_b))
{
    $condition_where = " and buffer_gets >= $opt_b ";
    $order = " order by buffer_gets desc ";
}
elsif (defined($opt_d))
{
    $condition_where = " and disk_reads >= $opt_d ";
    $order = " order by disk_reads desc ";
}
else
{
    $condition_where = " and buffer_gets >= 10000000 ";
    $order = " order by buffer_gets desc ";
}

open (DEBUG, ">debug.lst");

#$lda = &ora_login("", "internal", "") || die $ora_errstr;
$lda = DBI->connect("dbi:Oracle:", "", "") || die $DBI::errstr;

$csr = &ora_open($lda,"select sql_text,FIRST_LOAD_TIME,address,buffer_gets,disk_reads,parse_calls,executions,PARSING_SCHEMA_ID,rows_processed,optimizer_mode \
from v\$sqlarea \
where 1=1 $condition_where $user_where $order ") || die $ora_errstr;

$csr2 = &ora_open($lda, "select username from dba_users \
                         where user_id = :1") || die $ora_errstr;

$csr3 = &ora_open($lda, "select sql_text,piece from v\$sqltext_with_newlines where address = :1 order by piece") || die $ora_errstr;

while (@data = &ora_fetch($csr))
{
    $data[0] =~ tr/[a-z]/[A-Z]/;
    next unless $data[0] =~ /^SELECT/ || $data[0] =~ /^INSERT/ || 
                $data[0] =~ /^UPDATE/ || $data[0] =~ /^DELETE/;
    &ora_bind($csr2, $data[7]) || die $ora_errstr;
    (($username) = &ora_fetch($csr2)) ;
    &ora_bind($csr3, $data[2]) || die $ora_errstr;
    $sql = "EXPLAIN PLAN SET STATEMENT_ID = 'A' INTO system.plan_table FOR ";
    undef $print_sql;
    $lines = 0;
    while(($text,$piece) = &ora_fetch($csr3))
    {   
        $lines++ if $piece eq "0";
        $sql .= $text;
        $print_sql .= "\n" if $piece eq "0";
        $print_sql .= $text;
    }
    &ora_do($lda, "alter session set current_schema = $username") || die $ora_errstr;
print DEBUG $sql, "\n";
    &ora_do($lda, "delete system.plan_table where statement_id = 'A'") || warn $ora_errstr;
    &ora_commit($lda);
    &ora_do($lda, "$sql") || warn "$ora_errstr\n";
    &ora_commit($lda);

    $print_sql =~ s/ WHERE /\nWHERE /gi if $lines == 1;
    $print_sql =~ s/ FROM /\nFROM /gi if $lines == 1;
    $print_sql =~ s/ AND /\nAND /gi if $lines == 1;
    $print_sql =~ s/ ORDER /\nORDER /gi if $lines == 1;
    $print_sql =~ s/ GROUP /\nGROUP /gi if $lines == 1;
    $print_sql =~ s/(\W+)DECODE\W+\(/\1\nDECODE(/gi if $lines == 1;
    $print_sql =~ s/ UNION /\nUNION /gi if $lines == 1;
    @print_sql_lines = split(/\n/, $print_sql);
    print "SQL Statement: \n";
    foreach $line (@print_sql_lines)
    {
         $line =~ s/ *$//g;
         next if length($line) == 0;
         if (length($line) > 240)
         {
             #print "LINE TO LONG\n";
             while (length($line) >= 80)
             { 
                 $x = 70;
                 while ((substr($line, $x, 1) ne " ")  &&
                        (substr($line, $x, 1) ne ",")  &&
                        ($x < length($line)) &&
                        ($x < 500))
                 { 
                     $x++;
                 }
                 $pl =  substr($line, 0, $x + 1);
                 $pl =~ s/ *$//g;
                 print $pl, "\n" if length($pl) != 0;
                 $line = substr($line, $x + 1);
                 print $line,"\n" if length($line) < 80;
             }
         }
         else
         {
              print "$line\n";
         }
    }
    print "\nUsername: $username\n";
    print "First Load Time: $data[1]\n";
    print "Buffer Gets: $data[3]\n";
    print "Disk Reads: $data[4]\n";
    print "Parse Calls: $data[5]\n";
    print "Execution: $data[6]\n";
    print "Rows Processed: $data[8]\n";
    print "Optimizer: $data[9]\n";
    print "Explain Plan: \n";

    $csr4 = &ora_open($lda, "select LPAD(' ',2*(LEVEL-1))||operation||' '||\
                     options||' '||object_name ||' ' \
                     from system.plan_table \
                     start with id = 0 and statement_id = 'A' \
            connect by prior id = parent_id and statement_id = 'A'")
            || warn $ora_errstr;

    while (($plan_text) = &ora_fetch($csr4))
    {
        print "$plan_text\n";
    }
    print "\n\n";
    &ora_close($csr4);

    &ora_do($lda, "alter session set current_schema = sys") || die $ora_errstr;
}
&ora_logoff($lda);
