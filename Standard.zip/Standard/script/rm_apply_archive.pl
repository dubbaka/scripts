#!/usr/local/bin/perl
#................................................................
#	Name : rm_apply_archive.pl
#	Descritipn: remove applied archive log per last recovery no
#	            and keep the last 5 applied archive logs		
#	History:
#		swei	04-apr-2000	created
#		cer	23-mar-2001	corrected problem with '/n' caused by
#					perl upgrade. Added msg.
#		swei	09-jun-2004	modified for generic use
#					added options,etc
#................................................................
use File::Basename;
use Getopt::Std;
$keepno=5;
# ....................................................................
#       get option
# ....................................................................
getopt('shdk');
&usage if (defined($opt_h));
$sid         = $opt_s;
$archivedir  = $opt_d;
$keepno      = $opt_k ? $opt_k: $keepno;
if ( !($opt_s) || !($opt_d) )
{
	&usage;
	exit;
}

$last_archive_no=`cat /usr/tools/oracle/recovery/thread/${sid}_thread1.dat`;
print "Last Archive log: ";
print $last_archive_no;

# ....................................................................
#       Main
# ....................................................................
open(LISTFILE,"ls -rt ${archivedir}/*.dbf*|");
while (<LISTFILE>)
{
#       print $_;
       ($name,$dir,$ext)=fileparse($_,'\..*');
#       print "$ext\n";
#       $fileno = substr($ext,7);
#        print  "$fileno\n";
#	$fileno =~ s/.dbf.*//;
#	print "$fileno\n";
        if ( $_ =~ /(\D*)(\d*)\.dbf(.*)/) {
                     $fileno = int(${2});
                                     }

       if ($fileno < $last_archive_no - $keepno)
	{
	   print "$fileno\n";
 	   print "Removing Archive log: $_";
	   system ("/bin/rm ${archivedir}/*$fileno*.dbf*");
         }
}
# ....................................................................
#        Sub 
# ....................................................................
sub usage()
{
    print "$_[0]";
    print "
usage is of either:
        $0 [ -h help ] | [ -s sid ] [-d directory ] [-k keeplastno]
where:

        -s sid  SID
        -h      help                    display this help
	-d directory
	-k number  to keep the last x number of applied archive logs
		   (default: 5)

\n";
    exit(0);
}
