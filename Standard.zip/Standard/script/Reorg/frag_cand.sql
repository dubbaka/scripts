col owner format a25;
col table_name format a32;
col tablespace_name format a20;
set echo off verify off feed off pages0 lines 300;
spool frag_cand.lst;
select /*+ parallel(a,8) */ owner,
table_name,
decode(partitioned, 'NO','TABLE','PART') table_type,
tablespace_name,
num_rows,
round((blocks*8192)/1024/1024) Current_Size,
--avg_row_len,
round((avg_row_len*NUM_ROWS)/1024/1024) Size_After_Reorg,
round(((blocks*8192)-(avg_row_len*NUM_ROWS))/1024/1024) Diff_in_MB,
round((100-(avg_row_len*NUM_ROWS)*100/(blocks*8192))) "% of Frag"
from dba_tables a where
owner not in ('SYS','SYSTEM','OPS\$ORACLE')
--owner in ('OPS\$ORACLE')
--and PARTITIONED = 'NO'
and (avg_row_len*NUM_ROWS) < (blocks*8192)
and ((blocks*8192)-(avg_row_len*NUM_ROWS))/(blocks*8192)*100 >= 10
and ((blocks*8192)-(avg_row_len*NUM_ROWS))/1024/1024 > 1000
and table_name not in (select table_name from dba_tab_columns where data_type in
('LONG','LONG RAW','CLOB','BLOB','NCLOB','RAW','BFILE'))
and table_name not in (select TABLE_NAME from dba_lobs)
order by 7;
