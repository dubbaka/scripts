#!/oracle/product/perl

#############################################################################
# Name          : monitor_dg.pl                                             #
#                                                                           #
# Purpose       : Health Check on Data Guard                                #
#                                                                           #
#---------------- Health Checks performed by this script ------------------ #
#                                                                           #
#1) Recovery - If norecover flag is set, don't start it yet. Else start it  #
#2) Archive gap should not be more than 0.                                  #
#3) DG Down and norecover flag not set, bring up DG and start reco          #
#4) DG in nomount, mount and start revovery if norecover flag is not set    # 
#5) get the errors (if any) from the Dataguard error reporting views        #
#6) check for any offline datafiles or which are having errors              #
#7) check alert_<STANDBY>.log and report errors there in the last 60 min    #
#8) Updates the thread file with the latest applied logfile sequence number.#
#                                                                           #
# Parameters    : INSTANCE NAME, mailing alias ,pager alias                 #
#                                                                           #
# Usage         : ./monitor_dg.pl  -s INSTANCE -m mail -p pager -d degree   #
#                                                                           #
# Log file loc  :  /tmp/$sid_monitor_dg.logi                                #
#                 (Eg: /tmp/DMPROD_monitor_dg.log)                          #
#                                                                           #
# Created By    :  sraminen                                                 #
# Creation Date :  January  2006                                            #
#                                                                           #
# Modification History                                                      #
# =====================                                                     #
# Modified By   :  Melvin Gerold(mgerold)                                   #  
# Modified Date :  August 2011                                              #
#                                                                           # 
# Created single script by combining dependant scripts                      #  
# Created one version for RAC/Non-RAC instances                             #
#############################################################################


$Synopsis = <<X;
        $0 -s sid -m email -p epage 
        accepts the following arguments:
               sid             Standby SID name (Mandatory)
               email           recipient email address for errors (optional)
               epage           recipient epage address for errors (optional)
               degree          degree of parallelism for recovery (optional)

        Example 1.  monitor_dg.pl -s DGPOC -m erp-db-monitor -p erp_dba_duty
        Example 2.  monitor_dg.pl -s DGPOC 


Description:
       This program monitors the recovery process, check its health and reports
       any errors in the Datagaurd configuration. 

       It checks for errors in the alert log in the last 60 min
X

require "ctime.pl";
use lib "/usr/cisco/packages/oracle/oracle-10.2.0.1/Perlmod/lib/i686-linux/";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;
($nls)=&StdDBPackage::check_nls;


use Getopt::Std;
use Time::Local;

$default_degree = 4;
$default_lagtime = 15;

getopt('smpd');
$sid     = $opt_s if defined($opt_s) || &usage("");
$degree  = $opt_d ? $opt_d: $default_degree;
$pname   = $0;
$logfile = "/tmp/${sid}_monitor_dg.log";
$thread_file = "/usr/tools/oracle/recovery/thread/${sid}_thread1.dat";
$mailto  = $opt_m ? $opt_m: $maillist;
$pageto  = $opt_p ? $opt_p: $pagelist;
chomp($host = `/bin/uname -n`);

$mailto =~ s/^\s+//; #remove leading spaces
$mailto =~ s/\s+$//; #remove trailing spaces
$mailto =~ s/\@cisco.com//; #removes @cisco.com

$pageto =~ s/^\s+//; #remove leading spaces
$pageto =~ s/\s+$//; #remove trailing spaces
$pageto =~ s/\@epage.cisco.com//; #removes @epage.cisco.com

#
# The following are all the errors that will be reported from the alert logs.
# If there is a new error that we are interested in the future, all we have
# to do is to add the corresponding error code into this hash
#
# NOTE: Some errors that we want to check don't have an associated ORA error
#
# For example "Failed to request gap sequence". We shall use custom codes for these.
# starting from ORA-20001
#
my %error_codes =
    (
     "ORA-00600"  => "Any Internal programming exception",
     "ORA-07445"  => "Internal programming exception with mismatch of address",
     "ORA-04031"  => "Lack of sufficient memory to allocate in Shared Pool",
     "ORA-12154"  => "TNS: Could not resolve the service name",
     "ORA-12157"  => "TNS: Internal network communication error",
     "ORA-12224"  => "TNS: no listener",
     "ORA-2391"   => "exceeded simultaneous SESSIONS_PER_USER limit",
     "ORA-20001"  => "Failed to request gap sequence",
     "ORA-20002"  => "terminating instance due",
     "RFS Network" => "Possible network disconnect with primary database",
    );

$base_dir="/oracle/admin/$sid";
$bdump="$base_dir/bdump";

$current_time=localtime;

@week_days = qw ( Sun Mon Tue Wed Thu Fri Sat );

$time_hr_back;

$error_code;
$error_desc;
$alert_log_line;
$week_day;
$err_text = "";

#
# Define harmless errors here (if any) so we just send a warning and don't page people 
#

#
# End of harmless errors list
#

open(LOGFILE, ">${logfile}") || die "Cannot open logfile $logfile. $!\n";
print "Start time ", &ctime(time), "\n";
print LOGFILE "Start time ", &ctime(time), "\n";

#
# exit if the program is already running currently
#
if (-f "/tmp/monitor_dg_${sid}.pid")
 {
  open(PID, "/tmp/monitor_dg_${sid}.pid") || die "Cannot open pid file. $!";
  $pid = <PID>;
  close(PID);

# A zero signal just checks to see if the process is alive

  $rc = kill 0, $pid;
  if ($rc)
   {
     print "monitor_dg.pl already running under $pid\n";
     print LOGFILE "monitor_dg.pl already running under $pid\n";
     exit(1);
   }
 }

  open(PID, "> /tmp/monitor_dg_${sid}.pid");
  print PID $$;
  close(PID);


$oracle_sid = $sid;
&ora_home($oracle_sid);

if ($oracle_home eq "")
{
 capture_err("$pname on $host : Cannot find Oracle Home for $sid. Aborting");
}


#
# If norecover flag is set, don't do any checks. Just exit
#
print "Checking if flag is set for the instance $sid in /usr/tools/oracle/recovery/norecover\n";  
print LOGFILE "Checking if flag is set for the instance $sid in /usr/tools/oracle/recovery/norecover\n"; 
if ( is_norecover_flag()) 
  {
   print "DG checking skipped since  $sid flag is set in /usr/tools/oracle/recovery/norecover\n";
   print LOGFILE "DG checking skipped since  $sid flag is set in /usr/tools/oracle/recovery/norecover", "\n";
   exit(1);
  }

$just_started=0;
#
#Check if Standby database has been started. If not call the startup script
#

print "Checking if the instance $sid is started and running.......\n";
print LOGFILE "Checking if the instance $sid is started and running.......\n";

$sid_pmon=`ps -ef | grep \"pmon_$sid\$" | grep -v grep`;
print "pmon process is :$sid_pmon:\n";
if (!$sid_pmon)
{
 print "Instance $sid not started....starting it.....\n";
 print LOGFILE "Instance $sid not started....starting it.....\n";
 $just_started=1;
 start_dr();
}

print "Connecting to instance $sid .....\n";
print LOGFILE "Connecting to instance $sid .....\n";
&StdDBPackage::which_lib();
$dbh = DBI->connect("dbi:Oracle:", "", "",{ora_session_mode=>2}) ||
        capture_err("$pname:$host:$sid Cannot Connect to Database: $DBI::errstr");

print "Connected to $sid ....\n";
print LOGFILE "Connected to $sid ....\n";



if ( $just_started == 1 or db_not_mounted() )
 {
  print "Mounting the Standby database since it is not mounted yet ...\n";
  print LOGFILE "Mounting the Standby database since it is not mounted yet ...\n";
  mount_standby();  
 }        

print "Checking if mananged recovery  needs to be started......\n";
print LOGFILE "Checking if mananged recovery  needs to be started......\n";
start_recovery();

print "Updating thread files ........\n";
print LOGFILE "Updating thread files ........\n";
update_thread_file();

print "Checking archive log gap.......\n";
print LOGFILE "Checking archive log gap.......\n";
check_archive_gap();
#check_dataguard_status_view();

print "Checking alert log for any data file errors ......\n";
print LOGFILE "Checking alert log for any data file errors ......\n";
check_datafile_errors();

print "Monitor DG script completed ....\n";
print LOGFILE "Monitor DG script completed ....\n";
$dbh->disconnect;

#sanr check_alertlog();
close(LOGFILE);
exit(0);

sub mailit_1()
{
 if (-f $_[1]) 
 {
  #open (MAIL, "|/bin/mailx -s \"$_[0]\"  $mailto < $_[1]");
  #close (MAIL);
   #$errmsg = &msgfmt("i",,,"$_[0]");
   print "errmsg is $errmsg\n";
   print "$_[1]\n";
   &mailit($_[0],$_[1]);
   print "";
 }
}

sub pageit1
{
 my @pagemsg = @_;
 print "pageexe is :$pageexe:\n";

 $pageexe = "/usr/local/bin/epage" if (-f "/usr/local/bin/epage");
 $pageexe = "/usr/local/bin/pageme" if (-f "/usr/local/bin/pageme");
 $pageexe = "/usr/tools/oracle/epage" if (-f "/usr/tools/oracle/epage");

 if (!defined($pageexe))
 {
     print("epage/pageme executable not found. Aborting...\n");
     exit (1);
 }

  while ($pagemsg = pop(@pagemsg))
  {
   `$pageexe \"$pageto\" \'$pagemsg\'`;
  }
}

sub is_norecover_flag()
{
 #
 # If norecover flag is not set in /usr/tools/oracle/recovery/norecover, start the recovery 
 #
 if ( -e "/usr/tools/oracle/recovery/norecover/$sid")
 {
  return 1;
 }
 else
  {
    return 0;
  }

}# End of routine is_norecover_flag

sub update_thread_file()
{

 $get_latest_log_applied = $dbh->prepare("select thread#,max(sequence#)
                                            from v\$archived_log
                                           where applied='YES' group by thread#")
                              or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $get_latest_log_applied->execute
      or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 while(($thread,$latest_log_applied)=$get_latest_log_applied->fetchrow_array)
        {
                $thread_file = "/usr/tools/oracle/recovery/thread/${sid}_thread${thread}.dat";
                 open(THREADFILE, ">${thread_file}") || die "Cannot open logfile $thread_file. $!\n";
                 print THREADFILE "$latest_log_applied";
                 print "updating $thread_file with latest log file $latest_log_applied\n";
                 close THREADFILE;
        }

 $get_latest_log_applied->finish;

print "Thread files updated ........\n";
print LOGFILE "Thread files updated ........\n";
}# End of routine update_thread_file

sub check_archive_gap()
{

 $thread_stmt =$dbh->prepare("select distinct thread# from v\$archived_log")
                    or die "Cannot prepare SQLSTMT: $DBI::errstr \n";
  
 $thread_stmt->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 while ($thrd = $thread_stmt->fetchrow_array()) {
      push(@threadinfo,$thrd);
  }

 foreach $thread (@threadinfo) {

 $arc_gap =$dbh->prepare("select count(*) from v\$archive_gap where thread#=$thread and low_sequence# not in (select a.sequence# from (select sequence# from v\$archived_log where thread#=$thread order by 1 desc) a where rownum<10)" )
                    or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $arc_gap->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 $archive_gap_count=$arc_gap->fetchrow_array;

 if ($archive_gap_count > 0)
 {  
  if (-e "/usr/tools/oracle/recovery/norecover/${sid}.nopage.* ") {
        chomp($nopage_f=`ls -1tr /usr/tools/oracle/${sid}.nopage.* 2>/dev/null| tail -1 `);
        $nopage_v = (split(/\./,$nopage_f))[2];
        &Stat("$nopage_f");
        $nopage_fs = $st_mtime;
        $nopage_vs = &convertTime($nopage_v);
        $diff = ( time - $nopage_fs );
        if ( $nodrhost_vs < (time - $nopage_fs) ){
                system("rm /usr/tools/oracle/${sid}.nopage.* 2>/dev/null" );
                capture_err("$pname:$host:$sid - standby archive gap count is $archive_gap_count");
        }
     }
  else {     
  capture_err("$pname:$host:$sid - standby archive gap count is $archive_gap_count");
   }
 }

}
 print "Archive gap on standby db $sid is 0\n\n";
 print LOGFILE "Archive gap on standby $sid is 0", "\n";

$thread_stmt->finish; 
$arc_gap->finish;

}# End of routine check_archive_gap

sub db_not_mounted()
{

$dbh->{RaiseError}    = 0;
$dbh->{PrintError}    = 0;
 print "Checking if the database is already mounted .....\n";
 print LOGFILE "Checking if the database is already mounted .....\n";

 eval
   {
     $db_status =$dbh->prepare("select open_mode from v\$database" )
                    or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

     $db_status->execute;

      $db_mounted=$db_status->fetchrow_array;
      $db_status->finish;
   };

 $dbh->{RaiseError}    = 1;
 $dbh->{PrintError}    = 1; 
 if (!defined($db_mounted))
   {  
      print "Database is not mounted .....\n";
      print LOGFILE  "Database is not mounted .....\n";
      return 1;
   }
   else
     { 
       print "Database is already mounted .....\n";
       print LOGFILE  "Database is already mounted .....\n";
       return 0;
     }

}

sub check_dataguard_status_view()
{
 $err_list =$dbh->prepare("select message,to_char(timestamp,'DD-MON-YY HH:MI:SS') 
                             from v\$dataguard_status
                            where severity in ('Error','Fatal') 
                              and timestamp > (sysdate-1/24)")
                  or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $err_list->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

 $errors_found = 0;

  while (( $message,$timestamp)=$err_list->fetchrow_array)
  {
   $errors_found = 1;
   print "$message at $timestamp\n";
   print LOGFILE "$message at $timestamp", "\n";
  }

  if ($errors_found)
  {
   print "----------------------------------\n";
   print LOGFILE "--------------------------", "\n";
   capture_err("$pname:$host:$sid  - Errors in v\$dataguard_status view");
  }
  else
  {
   print "No errors in v\$dataguard_status\n\n";
   print LOGFILE "No errors in v\$dataguard_status\n";
  }

 $err_list->finish;

}# End of routine check_dataguard_status_view

sub check_datafile_errors()
{
 $get_datafile_errs =$dbh->prepare("select file#,error
                                      from v\$datafile_header
                                     where status ='OFFLINE'
                                       and error is not null")
                  or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

 $get_datafile_errs->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

  $errors_found = 0;

  while (( $file,$err)=$get_datafile_errs->fetchrow_array)
  {
   $errors_found = 1;
   print "$err in $file\n";
   print LOGFILE "$err in $file", "\n";
  }

  if ($errors_found)
  {
   print "----------------------------------\n";
   print LOGFILE "--------------------------", "\n";
   capture_err("$pname:$host:$sid  - Datafile errors in v\$datafile_header");
  }
  else
  {
   print "No errors in v\$datafile_header\n";
   print LOGFILE "No errors in v\$datafile_header\n";
  }

 $get_datafile_errs->finish;

}# End of routine check_datafile_errors

sub start_recovery()
{
$mrp_process=`ps -ef | grep -i $sid | grep ora_mrp | grep -v grep`;
print "mrp process is :$mrp_process:\n";
if ($mrp_process)
{
 print "The Managed Recovery process (mrp) for $sid is already running!\n";
 print LOGFILE "The Managed Recovery process (mrp) is already running!", "\n";
 #exit(0);
 return 0;
}
print "Starting Managed Recovery Process as it is not started yet.....\n"; 
open(SQLDBA, "$oracle_home/bin/sqlplus \"/ as sysdba \"  << END
recover managed standby database parallel $degree disconnect from session
exit
END |") || capture_err("$pname on $host for $sid : cannot find sqlplus: $!");

@data = <SQLDBA>;

foreach $line (@data)
{
 if ($line =~ /ORA-/)
 {
  capture_err($line);
 }
}


$check_mrp =$dbh->prepare("select count(*) from v\$managed_standby where process like 'MRP%'")
                    or die "Cannot prepare SQLSTMT: $DBI::errstr \n";

$check_mrp->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");

$mrp_process_count=$check_mrp->fetchrow_array;
if ($mrp_process_count=0)
{
 capture_err("$pname:$host:$sid managed recovery process not started");
}

$check_mrp->finish;


print "Managed recovery process for Standby db $sid started\n";
print LOGFILE "Managed recovery process for Standby db $sid started ", "\n";
return 0;
}# End of routine start_recovery


sub start_dr()
{

# Define harmless errors
#
$already_started="ORA-01081";
$already_mounted="ORA-01100";
$database_busy="ORA-01154";

open(SQLDBA, "$oracle_home/bin/sqlplus \"/ as sysdba \"  << END
startup nomount
exit
END |") || capture_err("$pname on $host for $sid : cannot find sqlplus: $!");

@data = <SQLDBA>;

foreach $line (@data)
{
 if ($line =~ /ORA-/)
 {
   if ($line =~ /ORA-32004/)
    {
     print "Obsolete parameter warning during startup...Ignoring it....\n";
    }
   else
    {
     capture_err($line);
    }
 }
}
print "Instance $sid started in nomount state ....\n"; 
print LOGFILE "Instance $sid started in nomount state ....\n";
return 0;

}# End of routine start_dr

sub mount_standby()
{

$mount_db = $dbh->prepare("alter database mount standby database") or
        die "Cannot prepare SQLSTMT: $DBI::errstr \n";

$mount_db->execute or capture_err("$pname:$host:$sid Cannot execute SQLSTMT: $DBI::errstr");
$mount_db->finish;

print LOGFILE "Standby db $sid mounted ", "\n";

}


sub check_alertlog()
{
#
# Every *statement* in alert_<SID>.ora will be seperated by a timestamp
# and this timestamp will be used for finding error messages and
# their corresponding trace files and other information. This timestamp
# also helps us delimit each error and its corresponding info in the
# alert_<SID>.log
#
# for example : "Sun Jul  6 13:13:48 2003"
#
$alert_log_file="$bdump/alert_$sid.log";

print "alert logfile used is $alert_log_file\n\n";
print LOGFILE "alert logfile used is $alert_log_file", "\n";

print "alert log errors in the last 1 hour are below....\n";
print LOGFILE "alert log errors in the last 1 hour are below....", "\n";


while ( ($error_code,$error_desc) = each %error_codes)
 {
  open (ALERT_LOG,$alert_log_file) ||
     print "Cannot open $alert_log_file: $!";

  &move_alert_log_hr_back($alert_log_file);

           while(<ALERT_LOG>)
           {
            #
            # this line will have the error code
            #
            $alert_log_line = <ALERT_LOG>;
            next unless (($alert_log_line =~ /$error_code/) or ($alert_log_line =~ /$error_desc/));

            capture_err("$pname:$host:$sid - Fatal alert log error $error_code $error_desc");
           }
           close ALERT_LOG;
 }

}# End of routine check_alertlog

#
# a subroutine that points the file handle to a timestamp that is 1 hours
# behind the current time in alert_<SID>.log file
#
sub move_alert_log_hr_back()
{
    my ($xx) = @_;
    my %months =
        (
         "Jan" => 1,
         "Feb" => 2,
         "Mar" => 3,
         "Apr" => 4,
         "May" => 5,
         "Jun" => 6,
         "Jul" => 7,
         "Aug" => 8,
         "Sep" => 9,
         "Oct" => 10,
         "Nov" => 11,
         "Dec" => 12
         );

    my $timestamp;

    $current_time =~ s/^(\w+)(.*)/\2/;
    $current_time =~ s/^\s+//;
 
    my ($mon,$day,$time,$year) = split('\s+',$current_time);
    $mon = $months{$mon};
    my ($hrs, $mins, $secs)    = split(':',$time);

    $current_time    = timelocal($secs,$mins,$hrs,$day,($mon-1),$year);

    $time_hr_back = $current_time - (60*60);

    $current_time    = scalar localtime($current_time);

    #
    # Stop the file handle when it reaches a line that contains
    # the $time_hr_back timestamp. We will start looking for
    # errors from this point till the end of the alert_<SID>.log file
    #
    $timestamp = <ALERT_LOG>;
    my $found = 0;

    while($found == 0 and $timestamp = <ALERT_LOG>)
    {
        #
        # Let's ignore alert log lines starting with a *
        # 
        if ($timestamp =~ /\*\**/)
        {
           $timestamp = <ALERT_LOG>;
        }

        $week_day  = $timestamp;
        $week_day  =~ s/(\w+)(.*)/\1/;
        chomp($week_day);

        if (grep(/^$week_day$/,@week_days))
        {
            $timestamp =~ s/^(\w+)(.*)/\2/;
            $timestamp =~ s/^\s+//;

            my ($mon,$day,$time,$year) = split('\s+',$timestamp);
            $mon = $months{$mon};
            my ($hrs, $mins, $secs)    = split(':',$time);

            $timestamp    = timelocal($secs,$mins,$hrs,$day,($mon-1),$year);

            if ($timestamp >= $time_hr_back)
            {
                $found = 1;
            }
        }

    }

}# End of routine move_alert_log_hr_back

sub capture_err()
{
 $err_str=$_[0];
 print "$err_str\n";
 print LOGFILE "$err_str", "\n";

#mgr new
if ($err_str =~ /$already_started/)
 {
  print "Standby db already started !\n";
  print LOGFILE "Oracle instance already started !", "\n";
  #exit(1);
 }
 if ($err_str =~ /$already_mounted/)
 {
  print "Standby db already mounted ! \n";
  print LOGFILE "Oracle instance already mounted !", "\n";
  #exit(1);
 }
 if ($err_str =~ /$database_busy/)
 {
  print "Standby db is already started and in managed recovery mode !\n";
  print LOGFILE "Standby db is already started and in managed recovery mode", "\n";
  #exit(1);
 }
#mgr new end


 if (LOGFILE)
 {
    close(LOGFILE);
    &mailit_1($err_str, $logfile);
 }
 &pageit1($err_str);
 exit(1);
}# End of routine - capture_err

#
#Print program usage
#
sub usage()
{
 $exit = shift(@_) || 0;
 print STDERR "\nusage: $Synopsis";
 exit $exit;
}# End of subroutine usage

sub ora_home()
{
#---------------------------------------------------------------
# Sets  ORACLE_HOME based on /etc/oratab
#---------------------------------------------------------------
 open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
 while (<ORATAB>)
 {
  if (/^${oracle_sid}:/)
   {
    $ENV{'ORACLE_SID'}  = $oracle_sid;
    $oracle_home = (split(':'))[1];
    $ENV{'ORACLE_HOME'} = $oracle_home;
   }
 }
 close(ORATAB);
}# End of routine - ora_home

