#!/oracle/product/perl
#
# Filename: analyze_database.pl
#
# Purpose: To analyze all objects in relavent schemas in the database,
#          to be called regularly from cron to keep statistics up to date.
#  		The algorith/theory behind this program is that analyze done on
#		a table only needs to be grossly estimated , but analyze on
#		an index needs a complete 'compute' analysis.
#		Therefore, a quick analyze table is done for everything, and
#		then a complete analysis for each index is done next.
#
# Author: David Novice, Cisco Systems, Jan 20, 1997
#
# Syntax: $0 [sid]
#
# Comments: This program should be run under the userid of someone with 
#           and OPS$ account as a DBA.
#
# History Modified:
#  swei  Mar-19-2004 Add Which_Lib and msgfmt/mailit function
#
# ........................................................................
#

use Getopt::Std;
use POSIX;
#require "ctime.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackage;


select(STDERR); $| = 1;
select(STDOUT); $| = 1;

    &init_fn();
    $start_time=time;
    print "\nStart Date  ", &get_date("DD-MON-YYYY"), "   Time  ",
        &get_time("HH:MI:SS", $start_time), "\n";
    &log_message("\nStart Date  ", &get_date("DD-MON-YYYY"), "   Time  ",
        &get_time("HH:MI:SS", $start_time), "\n");
    &log_message("\n--------------------------------------------------------------------------------\n");
    sleep(1);

    &analyze_tables();

    $end_time=time;
    $time_taken = &print_time(time - $start_time);
    print "\n--------------------------------------------------------------------------------\n";
    print "All analysis done.                                  Total Time Taken - $time_taken\n\n";
    &log_message("\n--------------------------------------------------------------------------------\n");
    &log_message("All analysis done.                                  Total Time Taken - $time_taken\n\n");

    print "End Date  ", &get_date("DD-MON-YYYY"), "   Time  ",
        &get_time("HH:MI:SS", $start_time), "\n";
    &log_message("End Date  ", &get_date("DD-MON-YYYY"), "   Time  ",
        &get_time("HH:MI:SS", $start_time), "\n");

    $errmsg = &msgfmt("i","`uname -n`","$oracle_sid","$oracle_sid Analyze Report");
    &mailit("$errmsg", $logfile);
    exit(0);

sub init_fn
{

    $usage = <<EOFEOF;

Usage:  
    $0 [-help] -s sid -e analyze_percent -u username[,username...] -m mis-dba -p erp-dba-duty


    -e analyze_percent     : Estimate analyze_percent of table data.
                             Default is 1.
    -h help                : Print this help.
    -m mailto              : Mail list. 
                             Default is mis-dba.
    -p pageto              : Page list. 
                             Default is erp-dba-duty.
    -s sid                 : Oracle SID. 
                             Default is SITRN.
    -u username            : Analyze objects owned by this user.
                             If not specified, analyzes all objects owned
                             by all users except SYS and SYSTEM users.
Description:

    This program analyzes database objects (tables and indexes) of 
    specified users(s). This program uses compute option to 
    get statistics for indexes and estimate option for tables.

Note :
    The Oracle userid must have access to analyze the tables.
    OPS\$ORACLE account should exist. Should be run by Oracle user.

EOFEOF

    #get command line options
    &getopt('defhilmprsu');
    if ($opt_h)
    {
        print $usage;
        exit(0);
    }

    undef($pfile);
    $pfile = $opt_f ;
    $estimate = 30;
    $logfile = "/tmp/analyze_$oracle_sid.log";
    &get_params($pfile) if defined($pfile);

    $oracle_sid     = $opt_s ? $opt_s : "";
    $estimate       = $opt_e ? $opt_e : $estimate;
    $mailto         = $opt_m ? $opt_m : $mailto;
    $pageto         = $opt_p ? $opt_p : $pageto;
    $analyze_users  = $opt_u ? $opt_u : $analyze_users;
    $logfile        = $opt_l ? $opt_l : $logfile;
    $p_degree       = $opt_d ? $opt_d : $p_degree;
    
    print "Analyze_percent   = $estimate\n";
    print "Anlyze_users      = $analyze_users\n";
    print "Degree            = $p_degree\n";
    print "Mailto            = $mailto\n";
    print "Pageto            = $pageto\n";
    print "Logfile           = $logfile\n";

    if (!defined(oracle_sid) || $oracle_sid eq "")
    {
        printf "SID is not given.\n";
        &show_error("SID is not given"); 
    }
    if (!defined($estimate) || $estimate < 0 || $estimate > 100)
    {
        printf "Estimate - $estimate : Value is not given or invalid.\n";
        &show_error("Estimate - $estimate : Value is not given or invalid."); 
    }

    open(LOGFILE, ">$logfile") || die "Cannot open log file. $!";
    print LOGFILE "Analyze_percent = $estimate\n";
    print LOGFILE "Anlyze_users    = $analyze_users\n";
    print LOGFILE "Mailto          = $mailto\n";
    print LOGFILE "Pageto          = $pageto\n";
    print LOGFILE "Logfile         = $logfile\n";
    close(LOGFILE);


    &ora_home($oracle_sid);
    $dbh = DBI->connect("dbi:Oracle:", "", "") ||
        &show_error("Cannot login to $oracle_sid. $DBI::errstr");
    #$dbh->{RowCacheSize} = -1;
    
}

sub analyze_tables
{

    if ((!defined($analyze_users)) || ($analyze_users eq ""))
    {
	$val = $ENV{'ORACLE_HOME'};
	if (-f "$val/lib/libserver10.a"){
        $where_condition = "and owner not in ('WMSYS','MDSYS','CTXSYS','XDB','WKSYS','LBACSYS','OLAPSYS','DMSYS','ODM','ORDSYS','ORDPLUGINS','SI_INFORMTN_SCHEMA','OUTLN','DBSNMP','SYSTEM','SYS','EXFSYS') ";
        }
	else
	{
        $where_condition = "and owner not in ('SYS', 'SYSTEM') ";
        #$where_condition = "and u.name not in ('SYS', 'SYSTEM') ";
	#and owner <= 'O'";
	}
    }
    else 
    {
        $analyze_users =~ s/,/','/g;
        $analyze_users =~ s/^/'/g;
        $analyze_users =~ s/$/'/g;
        $where_condition = " and owner in ($analyze_users) ";
    }

    $stmt = "select owner, segment_name, round(sum(bytes/1024/1024), 0) 
	from dba_segments 
	where 1=1 
	and segment_type in ('TABLE', 'TABLE PARTITION')
	$where_condition
	group by owner, segment_name
	order by owner, segment_name";
    $sth = $dbh->prepare($stmt) || 
        warn("Error while preparing $stmt. $DBI::errstr");
    #$rc = $sth->execute() 
    $sth->execute() 
        || warn("Error while executing $stmt. $DBI::errstr");
    $usertableref = $sth->fetchall_arrayref;
    $sth->finish();

    foreach(@$usertableref)
    {
        ($owner, $table, $tsize) = (@$_);
        push(@{$analyze_tables{$owner}}, $table);
        $indx = "${owner}_${table}";
        $table_size{$indx} = $tsize;
        $analyze_clause{$indx} = &get_analyze_clause($owner, $table, $indx);
        if ($tsize <= 1 )
        {
            $degree{$indx} = 1;
        }
        else
        {
            $degree{$indx} = $p_degree;
        }
    }
    &analyze_fn(@analyze_tables);
    $rc = $dbh->disconnect;
}

sub get_analyze_clause()
{
my $owner;
my $table;
my $stmt;
my $sth;
my $rc;

    ($owner, $table, $indx) = @_;
    #
    # Get table size.
    #
    $tabsize = $table_size{$indx};
    #
    # Get analyze clause.
    #
    $r1 = "-1";
    for($i=0; $i<=$#tsizeinorder; $i++)
    {
        #print "Size $tabsize $tsizeinorder[$i]\n";
        if ($tabsize <= $tsizeinorder[$i]) 
        { 
	    $r1 = $percent_hash{$tsizeinorder[$i]}; 
	    last; 
        }
    }
    if ($r1 eq "-1")              # Sample is not given. Use $estimate.
    {
        $r2 = "$estimate";
    }
    elsif ($r1 =~ /compute/i)
    {
        $r2 = 'NULL';
    }
    else
    {
        $r2 = "$r1";
    }
    return($r2);
}

sub analyze_fn()
{
my $start_time, $stime, $end_time, $etime;
my @analyze_tables;

    
    @analyze_tables = @_;
    printf("%-45s       %s %s %s\n", "Table Name", "StartTime", "EndTime", "Time Taken");
    printf "--------------------------------------------------------------------------------\n";
    foreach $owner (sort keys %analyze_tables)
    {
        foreach $table (@{$analyze_tables{$owner}})
        {
            $start_time=time;
            $stime = &get_time("HH:MI:SS", $start_time);
            $towner = $owner;
            $ttable = $table;
            $indx = "${owner}_${table}";
            $sample_size = $analyze_clause{$indx};
            $degree = $degree{$indx};
	    $analyze_stmt = "begin DBMS_STATS.GATHER_TABLE_STATS (ownname => '$towner', tabname => '\"$ttable\"', estimate_percent => $sample_size, block_sample => TRUE, degree => $degree, method_opt => 'FOR ALL COLUMNS SIZE 1', granularity => 'ALL', cascade => TRUE); end; ";

            $sth = $dbh->prepare("$analyze_stmt") ||
		warn("Prepare failed for $analyze_stmt. $DBI::errstr");
            $sth->execute||
		warn("Execute failed for $analyze_stmt. $DBI::errstr");
	    $sth->finish;
            $end_time=time;
            $etime = &get_time("HH:MI:SS", $end_time);
            $duration = ($end_time - $start_time);
            $str1 = sprintf "%-45s       %s  %s %s\n", 
                ${owner}.".".${table},
                $stime, 
                $etime,
                &print_time($duration);
            print $str1;
            push(@logstr, $str1);
            #&log_message($str1);
        }
    }
}

sub print_time()
{
use integer;

my $hours, $minutes, $seconds, $time_duration;

    $time_duration = $_[0];
    $hours = $time_duration / 3600;
    $seconds = $time_duration % 60;
    $minutes = ($time_duration % 3600) / 60;
    $ret_string = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);;
    return($ret_string);
}

sub get_params()
{
my $pfile;

    $pfile = $_[0];
    if (! -f $pfile)
    {
        print "File $pfile doesn't exist.\n";
        &show_error("File $pfile doesn't exist."); 
    }
    open(PFILE, "$pfile") || &show_error("Cannot open $pfile. $!");
    while(<PFILE>)
    {
        chomp;
        next if /^#/;
        if (/analyze_percent/i)
        {
            $estimate = (split(" ")) [2];
        }
        elsif (/analyze_users/i)
        {
            ($dummy, $dummy, @usernames) = (split(" "));
            $analyze_users = join '', @usernames;
            $analyze_users =~ tr /a-z/A-Z/;
        }
        elsif (/mailto/i)
        {
            ($dummy, $dummy, @mailto) = (split(" "));
            $mailto = join '', @mailto;
        }
        elsif (/pageto/i)
        {
            ($dummy, $dummy, @pageto) = (split(" "));
            $pageto = join '', @pageto;
        }
        elsif (/logfile/i)
        {
            ($dummy, $dummy, $logfile) = (split(" "));
        }
        elsif (/degree/i)
        {
            ($dummy, $dummy, $p_degree) = (split(" "));
        }
        elsif (/table_size/i)
        {
            ($d1, $d2, $table_size, $d3, @sample) = split(" ");
            chomp($table_size);
            $percent_hash{$table_size} = join ' ', @sample;
        }
    }
    @tsizeinorder = sort numerically (keys %percent_hash);
    close(PFILE);
}

sub numerically
{
    $a <=> $b;
}

sub ora_home
{
my $oracle_sid;

    $oracle_sid = $_[0];

    #---------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #---------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || die "Can't Open /etc/oratab";
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_HOME'} = $oracle_home;
        $ENV{'ORACLE_SID'}=$oracle_sid;
        $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
        $ENV{'SHLIB_PATH'} = "$oracle_home/lib";
        $ENV{'TNS_ADMIN'} = "$oracle_home/network/admin";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }
        print "Sid $oracle_sid home $ora_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();

        }
    }
    close(ORATAB);
}
