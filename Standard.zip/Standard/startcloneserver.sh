#!/bin/ksh
# Script to set values for required environment variables 
# and start clone server.
# v1.0
# Following variables to be referenced across the script.
set -x
INSTANCENAME=""
PORTNUMBER=""
HOSTTYPE=""
STD_DIR=""
CLONEDIR=""
CLONETOP=""
#CLONE Indicators.
CLONE_LOCK=CLONESETUP.WIP
CLONESTATUS=.CLONESTATUS
CLONESTATUSTMP=.CLONESTATUSTMP
CLONESTATVAR=""
TMPOLDPATH=""
############################
# The following are methods
# used by the script.
############################ 
# Lock Monitor
checkCloneInstallLock() {
 while [ -f $STD_DIR/$CLONE_LOCK ]
 do
  echo " Clone Setup In Progress.."
  echo " Sleeping for few seconds..."
  sleep 30
 done
}
# Create Lock
createCloneInstallLock(){
if [ ! -f $STD_DIR/$CLONE_LOCK ]
   then
     touch $STD_DIR/$CLONE_LOCK
 fi
}
# Remove Lock
removeCloneInstallLock(){
	rm -f $STD_DIR/$CLONE_LOCK
}
# Function to fetch and set startup args.
setStartUpArgs(){	
	INSTANCENAME=$1
	export INSTANCENAME
	HOSTTYPE=$2
	export HOSTTYPE
	PORTNUMBER=$3
	export PORTNUMBER	
	if [ $HOSTTYPE = "DBNODE" ]
	then
    		TMPOLDPATH=$PATH
	        export TMPOLDPATH
		export PATH=/usr/local/bin:$PATH
		SETDB_ASK=N
		export SETDB_ASK
		. /usr/local/bin/setdb $INSTANCENAME
		PATH=$TMPOLDPATH
		export PATH
		ORAENV_ASK=NO
		export ORAENV_ASK
		ORACLE_SID=$INSTANCENAME
		export ORACLE_SID
		STD_DIR=/usr/tools/oracle/Standard
		export STD_DIR
		CLONEDIR=$STD_DIR/clonepackage
		export CLONEDIR
		CLONETOP=$CLONEDIR/clickClone
		export CLONETOP
		CLONESTATVAR=$INSTANCENAME
		export CLONESTATVAR
		PATH=$STD_DIR/clonepackage/CLONE_JVM/jre/bin/:$PATH
		export PATH
		CLASSPATH=$STD_DIR/clonepackage:$STD_DIR/clonepackage/CLONE_JVM
		export CLASSPATH		
	elif [ $HOSTTYPE = "SOURCENODES" -o $HOSTTYPE = "SOURCE" -o $HOSTTYPE = "DRHOST" -o $HOSTTYPE = "BACKUPHOST" -o $HOSTTYPE = "NONERPDBNODE" ]
	then		
		STD_DIR=/usr/tools/oracle/Standard
		export STD_DIR
		CLONEDIR=$STD_DIR/clonepackage
		export CLONEDIR
		CLONETOP=$CLONEDIR/clickClone
		export CLONETOP
		CLONESTATVAR=$INSTANCENAME
		export CLONESTATVAR
	elif [ $HOSTTYPE = "FENODE" ]
	then
		TMPINSTANCENAME=`echo $INSTANCENAME | tr '[A-Z]' '[a-z]'`
		export TMPINSTANCENAME
		STD_DIR=/apps/$TMPINSTANCENAME/Standard
		export STD_DIR		
		CLONEDIR=$STD_DIR/clonepackage
		export CLONEDIR
		CLONETOP=$CLONEDIR/clickClone
		export CLONETOP	
		CLONESTATVAR=$INSTANCENAME`hostname`
		export CLONESTATVAR
		PATH=$STD_DIR/clonepackage/CLONE_JVM/jre/bin/:$PATH
		export PATH
		CLASSPATH=$STD_DIR/clonepackage:$STD_DIR/clonepackage/CLONE_JVM
		export CLASSPATH
	fi
}
# Function to update .CLONESTATUS file.
updateCloneStatusFile(){
# Checks if .CLONESTATUS file exists.
	if [ ! -f $CLONEDIR/$CLONESTATUS ]
	then
		# If file doesnt exist, create it.
		touch $CLONEDIR/$CLONESTATUS
		# Add Clone information to the status file.
        echo $CLONESTATVAR >> $CLONEDIR/$CLONESTATUS
	else
		# If file exits, check if instance entry exists.
		# If entry doesnt exist, then update entry.
        CHECKVAR=`grep $CLONESTATVAR $CLONEDIR/$CLONESTATUS`
        if [ -z "$CHECKVAR" ]
        then
          echo $CLONESTATVAR >> $CLONEDIR/$CLONESTATUS
        fi
	fi	
}
# Function to setup SOURCE Nodes ( Source/DR/Backup )
installAndRunClonePackageOnSourceNodes(){		
	updateCloneStatusFile
	removeCloneInstallLock		
}

# Function to setup Target Nodes ( Target FE & Target DB Nodes )
installAndRunClonePackageOnTargetNodes(){	
	cd $CLONEDIR
	# Creating directories for jvm and instant clients.
	if [ ! -d $CLONEDIR/CLONE_JVM ]
	then
		mkdir $CLONEDIR/CLONE_JVM
		mv jre.tar $CLONEDIR/CLONE_JVM
		cd $CLONEDIR/CLONE_JVM
		tar -xf jre.tar
		# Removing jre.tar file
		rm -f jre.tar
		cd $CLONEDIR
	fi
	cp $CLONEDIR/cloneserver.jar $CLONEDIR/cloneserver$INSTANCENAME.jar	
	updateCloneStatusFile
	removeCloneInstallLock
	$STD_DIR/clonepackage/CLONE_JVM/jre/bin/java  -server -Xms512m -Xmx512m -jar $CLONEDIR/cloneserver$INSTANCENAME.jar $INSTANCENAME $HOSTTYPE $PORTNUMBER >/dev/null 2>&1 &
        echo " Server Is Running With Status As $? "
}
# Cleanup Source Nodes.
cleanupClonePackage(){
	checkCloneInstallLock
	if [ -d $CLONEDIR ]
	then
        createCloneInstallLock        
        sed "/$CLONESTATVAR/d" $CLONEDIR/$CLONESTATUS > $CLONEDIR/$CLONESTATUSTMP
        mv $CLONEDIR/$CLONESTATUSTMP $CLONEDIR/$CLONESTATUS
        CONTENTCHK=`cat $CLONEDIR/$CLONESTATUS | wc -l`
        if [ $CONTENTCHK -eq 0 ]
        then
            rm -Rf $CLONEDIR
        fi
        removeCloneInstallLock
	else
		echo " Nothing to Cleanup... "
	fi
}
# Script startup point
if [ $1 = "STARTUP" ]
then
	setStartUpArgs $2 $3 $4
	unset PERL5LIB
	if [ $HOSTTYPE = "SOURCENODES" ]
	then
		checkCloneInstallLock
		createCloneInstallLock
		chmod -R 755 $CLONETOP
		installAndRunClonePackageOnSourceNodes				
	elif [ $HOSTTYPE = "NONERPDBNODE" ]
	then
		checkCloneInstallLock
		createCloneInstallLock
		installAndRunClonePackageOnSourceNodes				
	elif [ $HOSTTYPE = "DBNODE"  -o $HOSTTYPE = "FENODE" ]
	then
		checkCloneInstallLock
		createCloneInstallLock
		chmod -R 755 $CLONETOP
		installAndRunClonePackageOnTargetNodes
	fi
elif [ $1 = "CLEANUP" ]
then
	setStartUpArgs $2 $3 $4
	cleanupClonePackage	
fi	

echo " Exiting startcloneserver.sh ...."
exit
