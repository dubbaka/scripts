package StdDBPackage;
sub get_default_value()
{
    my $warn=10;
    my $alert=5;
    my $mailto="mis-dba";
    my $pageto="dba-duty";
    my $parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
    my $sid;

    $sid = $_[0];

   if (-r $parfile )
   {
    open(DEFFILE, $parfile) || die "Can't Open $parfile. $!";
    while (<DEFFILE>)
    {
    next unless (/^$sid:/ );
    #print $_;
    ($sidhome, $mailto, $pageto) = split(/:/);
    }
    close(DEFFILE);
    chomp($mailto);
    chomp($pageto);
   }
   return($mailto,$pageto,$warn,$alert); 
}
sub check_oracle7()
{
   my $oracle7 = "";
   my $parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
   my $exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";
   my $sid;
    $sid = $_[0];
   if (-r $exceptfile )
   {
    open(VERFILE, $exceptfile) || die "Can't Open $exceptfile. $!";
    while (<VERFILE>)
    {
     next unless (/^ORACLE7:/ && /$sid/ );
     print $_;
     $oracle7 = "Y";
    }
    close(VERFILE);
   }
   return($oracle7);
}

sub check_nls()
{
   my $nls = "";
   my $parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
   my $exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";
   if (-r $exceptfile )
   {
    open(NLSFILE, $exceptfile) || die "Can't Open $exceptfile. $!";
    while (<NLSFILE>)
    {
     next unless (/^NLS:/ );
     #print $_;
     $nls = "Y";
    }
    close(NLSFILE);
   }
   return($nls);
}

sub which_lib
{
$val = $ENV{'ORACLE_HOME'};

if (-f "$val/bin/svrmgrl") {
                 $one = clnt8;
        }

if (-f "$val/lib/libserver9.a") {
	if (-d "$val/lib32") {
                 $one = clnt964;
        }
else {
                 $one = clnt9;
        }
}

if ( -f "$val/lib/libserver10.a") {
        eval "use lib '$val/perlmods/lib'";
}
elsif ( $^O eq "linux" and -d "/usr/cisco/packages/oracle/current/Perlmod/lib") {
	eval "use lib '/usr/cisco/packages/oracle/current/Perlmod/lib'";
}
elsif ( -d "/oracle/product/clnt9207/lib" ) {
	eval "use lib '/oracle/product/9.2.0.7/lib'";
}
else{
   if (-d "/oracle/product/perlmods/$one/lib") {
        eval "use lib '/oracle/product/perlmods/$one/lib'";
   }
}
eval "use DBI";
}

1;
