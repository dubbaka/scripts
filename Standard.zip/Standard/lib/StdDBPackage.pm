package StdDBPackage;
sub get_default_value()
{
    my $warn=10;
    my $alert=5;
    my $mailto="mis-dba";
    my $pageto="dba-duty";
    my $parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
    my $sid;

    $sid = $_[0];

   if (-r $parfile )
   {
    open(DEFFILE, $parfile) || die "Can't Open $parfile. $!";
    while (<DEFFILE>)
    {
    next unless (/^$sid:/ );
    #print $_;
    ($sidhome, $mailto, $pageto) = split(/:/);
    }
    close(DEFFILE);
    chomp($mailto);
    chomp($pageto);
   }
   return($mailto,$pageto,$warn,$alert); 
}
sub check_oracle7()
{
   my $oracle7 = "";
   my $parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
   my $exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";
   my $sid;
    $sid = $_[0];
   if (-r $exceptfile )
   {
    open(VERFILE, $exceptfile) || die "Can't Open $exceptfile. $!";
    while (<VERFILE>)
    {
     next unless (/^ORACLE7:/ && /$sid/ );
     print $_;
     $oracle7 = "Y";
    }
    close(VERFILE);
   }
   return($oracle7);
}
sub check_nls()
{
   my $nls = "";
   my $parfile     = "/usr/tools/oracle/Standard/script/oracleDB.par";
   my $exceptfile  = "/usr/tools/oracle/Standard/script/exceptionDB.par";
   if (-r $exceptfile )
   {
    open(NLSFILE, $exceptfile) || die "Can't Open $exceptfile. $!";
    while (<NLSFILE>)
    {
     next unless (/^NLS:/ );
     #print $_;
     $nls = "Y";
    }
    close(NLSFILE);
   }
   return($nls);
}
sub set_oraenv
{
    my $oracle_sid = $_[0];
    if ( -f "/etc/oratab" ){
	$myoratab="/etc/oratab";
    }
    else {
	$myoratab="/var/opt/oracle/oratab";
    }
    open(MYORATAB, "$myoratab") || die "Can't Open $myoratab";
    while (<MYORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home            = (split(':'))[1];
            $ENV{'ORACLE_HOME'}     = $oracle_home;
            $ENV{'ORACLE_SID'}      = $oracle_sid;
            $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
            $ENV{'SHLIB_PATH'}      = "$oracle_home/lib";
            $ENV{'TNS_ADMIN'}       = "$oracle_home/network/admin";
            ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
            ($nls)=&StdDBPackage::check_nls;

            if ($oracle7 eq "Y")
            {
                $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
                $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
            }
            else
            {
              if ($nls eq "Y" )
              {
                  $ENV{'ORA_NLS32'} = "";
                  $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
              }
              else
              {
                  $ENV{'ORA_NLS32'} = "";
                  $ENV{'ORA_NLS33'} = "";
              }
             }
        &StdDBPackage::which_lib();
        }
    }
    close(MYORATAB);
}
sub which_lib
{

my ($perl_version) = `/oracle/product/perl -V:version | cut -f2 -d=  ` ;
$perl_version =~ s/\'//g;
$perl_version =~ s/\;//g;
$perl_version =~ s/\.//g;

$val = $ENV{'ORACLE_HOME'};

if (-f "$val/bin/svrmgrl") {
                 $one = clnt8;
        }

if (-f "$val/lib/libserver9.a") {
        if (-d "$val/lib32") {
                 $one = clnt964;
        }
else {
                 $one = clnt9;
        }
}

if (-f "$val/lib/libserver10.a") {
       $one = 10.2;
}

if (-f "$val/lib/libserver11.a") {
       $one = 11.2;
}

if ( -d "$val/perlmods/lib" ) {
	#print ":$val/perlmods/lib:\n" ;
        eval "use lib '$val/perlmods/lib'";
	eval "use DBI";
}
elsif( -d "/oracle/product/perlmods/$one/lib") {
	#print ":/oracle/product/perlmods/$one/lib:\n" ;
        eval "use lib '/oracle/product/perlmods/$one/lib'";
	eval "use DBI";
}
elsif ( -d "/usr/cisco/packages/oracle/oracle-11.2.0.1/Perlmod/$one/lib" && $perl_version > 588 ) {
	print ":/usr/cisco/packages/oracle/oracle-11.2.0.1/Perlmod/$one/lib\n" ;
        eval "use lib '/usr/cisco/packages/oracle/oracle-11.2.0.1/Perlmod/$one/lib'";
	eval "use DBI";
}
elsif ( -d "/usr/cisco/packages/oracle/current/Perlmod/lib") {
        print ":/usr/cisco/packages/oracle/current/Perlmod/lib:\n" ;
        eval "use lib '/usr/cisco/packages/oracle/current/Perlmod/lib'";
        eval "use DBI";
}

else { 	 die "**********  Perl lib error *************\n Error: Unable to location perl lib dirctory\n Please contact Standard-dba team for further help\n ***************************************\n ";
}
}

1;
