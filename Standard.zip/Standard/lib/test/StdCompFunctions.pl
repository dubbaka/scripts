#!/oracle/product/perl
#
# .....................................................................
# program:   StdCompProc               
#
# Description:
#
# This package is used by Standard Team for checking compliance
# Please do not make any changes without the approval of Standard team.
#
# History
#   Name             Date          Desc
#   -------------------------------------------
#   Rama Arumugam    11/30/2006    Created
#   Rama Arumugam    01/08/2007    Std compliance phase-2
#   Rama Arumugam    9/5/2007      New format to keep seperate check sum info
# .....................................................................
#
require "ctime.pl";
require "stat.pl";
require "getopts.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";

use Getopt::Std;
use Time::Local;

select(STDERR); $| = 1;
select(STDOUT); $| = 1;
$SIG{CHLD} = 'IGNORE';
# Load system variables.
$Slash = rindex($0,'/');
if ($Slash > 0) {$PWD = substr($0, 0, $Slash)}
else {$PWD = "."}

$par1 = "$ARGV[0]";
$par2 = "$ARGV[1]";
$par3 = "$ARGV[2]";
$par4 = "$ARGV[3]";
$par5 = "$ARGV[4]";
$par6 = "$ARGV[5]";

$host = `hostname`; chomp($host);
$ux_date = `which date`; chomp($ux_date);
$myserver_os = `uname`; chomp($myserver_os);
$ux_cksm = `which cksum`; chomp($ux_cksm);
$ux_mkdir = `which mkdir`; chomp($ux_mkdir);

if ( "$par1" eq "" || "$par2" eq "" ||"$par3" eq "" ||"$par4" eq "" ) { 
print <<EOT;
--------------------------------------------
Std Compliance parameters Passed: 
Param 1: $par1
Param 2: $par2
Param 3: $par3
Param 4: $par4
Param 5: $par5
Param 6: $par6
--------------------------------------------
EOT

}

$stdlogdir = "/var/tmp/StdCompliance";

$tmp = substr $par4, 0, (length $par4)-4;
$stdlogfilename = "$stdlogdir/$tmp".".csv";

if (! -d $stdlogdir ) { system("$ux_mkdir $stdlogdir"); }
unless (open (STDCOMPFILE,">> $stdlogfilename")) {
    print "Unable to open log file Std compliance logfile $stdlogfilename ..\n";
    exit;
}

if ( "$par1" =~ "find_cksum" ) { $cksumStat=&find_cksum("$par2","$par3","$par5","$par6"); print "$cksumStat";}
if ( "$par1" =~ "end_job" ) { &end_alljob("$par2","$par3","$par5","$par6"); }

close STDCOMPFILE;
exit;

sub find_cksum()
{
	# Load system variables.
	$Slash = rindex($0,'/');
	if ($Slash > 0) {$PWD = substr($0, 0, $Slash)}
	else {$PWD = "."}
	
	$actscript = "$_[3]/$_[2]"; # "$0"; # perl mod it is diff call
	$write_secs = (stat($actscript))[9];
	$actfiletime =  scalar localtime($write_secs); $actfiletime =~ s/  / /g;
	
	$stdscript = "$_[0]"; # "$_[0]"; perl mod it is diff call
#print "$stdscript = $_[0]\n";
	$stdscriptpath = "/usr/tools/oracle/Standard/script";

	$stdscr_ver = "Ver 2.0 Dt 01-08-2007";
	$mydate = `$ux_date -u +%Y%m%d`; chomp($mydate);
	$mytime = `$ux_date -u "+%d-%b-%Y %T"`; chomp($mytime); 
	$myseq = "$_[1]";

#print "ACT cksum: $ux_cksm $actscript \n";

	if ( ! -f $actscript ) {  $cksum_status = "------------------------------------------------------
This is not a valid file: $actscript
------------------------------------------------------ \n"; 
	return($cksum_status);
	}
		
	if ( ! -f "$stdscriptpath/.cksum.$par5" ) {  $cksum_status = "------------------------------------------------------
Checksum filed for *** \"$par5\" ***
------------------------------------------------------ \n"; 
	return($cksum_status);

	}

	$actcksum = `$ux_cksm $actscript`;chomp($actcksum);
	($actcksum,$x) = split(' ', $actcksum, 2);

	$Stat = "^$stdscript";
	open (FILE,"$stdscriptpath/.cksum.$par5");
#print "$stdscriptpath/.cksum.$par5\n";
  	@LINES = <FILE>; close FILE;
  	@tmp = grep(/$Stat/, @LINES);
	$temp = $tmp[0];	
#print "$temp\n";
	($stdscript,$stdcksum,$stdfiletime) = split(/~/, $temp,3); chomp($stdfiletime);
	
	print STDCOMPFILE "$myseq,00-BEGIN,$mytime,$host,,$actscript,$actfiletime,$actcksum,$stdscript,$stdfiletime,$stdcksum,$stdscr_ver\n";
#	print "$myseq,00-BEGIN,$mytime,$host,,$actscript,$actfiletime,$actcksum,$stdscript,$stdfiletime,$stdcksum,$stdscr_ver\n";
#print "$actscript:$actcksum,$stdscript:$stdcksum\n";

	$cksum_status = "UnKnown Error";

	if ( $stdcksum eq $actcksum ) { $cksum_status = "SUCCESS"; }

	if ( $stdcksum ne $actcksum ) { $cksum_status = "FAILED";
		print STDCOMPFILE "$myseq,99-CKSUM_FAILED,$mytime,$host,,,,,$stdscript,,,\n";	
		$cksum_status = "
-------------------------------------------------------------
Check sum failed as this script: $actscript
is not same as standard script : $stdscript 
-------------------------------------------------------------\n";
	}	

	if ( $actscript =~ "check_extents_all.pl" && $myserver_os =~ "Linux" ) {
		$cksum_status = "NOT_FOR_LINUX";
		print STDCOMPFILE "$myseq,99-NOT_FOR_LINUX,$mytime,$host,,,,,$stdscript,,,\n";	

		return($cksum_status);

	}
	
	return($cksum_status);
}

sub log_job()
{
	$mystage = "$_[0]";
	$myseq = "$_[1]";
	$mysid = "$_[2]";
	$mystdscript = "$_[3]";
	$myCom = "$_[4]";
	$ux_date = `which date`; chomp($ux_date);
	$mytime = `$ux_date -u "+%d-%b-%Y %T"`; chomp($mytime);
	print STDCOMPFILE "$myseq,$mystage,$mytime,$host,$mysid,$myCom,,,$mystdscript,,,\n";
#print "$myCom,$_[4],$_[3]\n";
}

