package Lock;

sub lock {
    my ($lockfile) = @_;
    $args0	= (split('\.',$lockfile))[0];
    $args1	= (split('\.',$lockfile))[1];
    $args2	= (split('\.',$lockfile))[2];
    $args3	= (split('\.',$lockfile))[3];
    my $lock = "/var/tmp/$lockfile.LOCK";
    my $ps;

    if ($^O eq "solaris") {
	$ps = "/usr/ucb/ps -auxww";
    } elsif ($^O eq "linux") {
	$ps = "ps -fwwp";
    } elsif ($^O eq "hpux") {
	$ps = "ps -lxp";
    }

    my $pid;
    # Remove stale lock.
    if (-f $lock) {
	open LOCK, "$lock" or die "Cannot open $lock ($!)\n";
	$pid = <LOCK>;
	close LOCK;
	my $ps_line = qx{$ps $pid};
	unlink $lock if !( $ps_line =~ /$args0/ & 
			   $ps_line =~ /$args1/ & 
			   $ps_line =~ /$args2/ & 
			   $ps_line =~ /$args3/);
    }

    die "Already running with pid=$pid " if -f $lock;

    open LOCK, ">$lock" or die "Cannot open $lock ($!)\n";
    print LOCK $$ or die "Could not write to $lock ($!)\n";
    close LOCK;
}

sub unlock {
    my ($lockfile) = @_;
    my $lock 	   = "/var/tmp/$lockfile.LOCK";
    unlink $lock;
}

1;
