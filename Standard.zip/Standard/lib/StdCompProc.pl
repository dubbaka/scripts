#!/oracle/product/perl
#
# .....................................................................
# program:   StdCompProc               
#
# Description:
#
# This package is used by Standard Team for checking compliance
# Please do not make any changes without the approval of Standard team.
#
# History
#   Name             Date          Desc
#   -------------------------------------------
#   Rama Arumugam    11/30/2006    Created
#   Rama Arumugam    01/08/2007    Std compliance phase-2
#
# .....................................................................
#
require "ctime.pl";
require "stat.pl";
require "getopts.pl";
require "/usr/tools/oracle/Standard/script/perllib.pl";

use Getopt::Std;
use Time::Local;

select(STDERR); $| = 1;
select(STDOUT); $| = 1;
$SIG{CHLD} = 'IGNORE';
# Load system variables.
$Slash = rindex($0,'/');
if ($Slash > 0) {$PWD = substr($0, 0, $Slash)}
else {$PWD = "."}

$par1 = "$ARGV[0]";
$par2 = "$ARGV[1]";
$par3 = "$ARGV[2]";
$par4 = "$ARGV[3]";
$par5 = "$ARGV[4]";

$host = `hostname`; chomp($host);
$ux_date = `which date`; chomp($ux_date);
$myserver_os = `uname`; chomp($myserver_os);
$ux_cksm = `which cksum`; chomp($ux_cksm);
$ux_mkdir = `which mkdir`; chomp($ux_mkdir);

if ( "$par1" eq "" || "$par2" eq "" ||"$par3" eq "" ||"$par4" eq "" ) { 
print <<EOT;
--------------------------------------------
Std Compliance parameters Passed: 
Param 1: $par1
Param 2: $par2
Param 3: $par3
Param 4: $par4
Param 5: $par5
--------------------------------------------
EOT

}

$stdlogdir = "/var/tmp/StdCompliance";

$tmp = substr $par4, 0, (length $par4)-4;
$stdlogfilename = "$stdlogdir/$tmp".".csv";

if (! -d $stdlogdir ) { system("$ux_mkdir $stdlogdir"); }
unless (open (STDCOMPFILE,">> $stdlogfilename")) {
    print "Unable to open log file Std compliance logfile $stdlogfilename ..\n";
    exit;
}

if ( "$par1" =~ "find_cksum" ) { $cksumStat=&find_cksum("$par2","$par3","$par5"); print "$cksumStat";}
if ( "$par1" =~ "begin_eachjob" ) { &begin_eachjob("$par2","$par3","$par5"); }
if ( "$par1" =~ "end_eachjob" ) { &end_eachjob("$par2","$par3","$par5"); }
if ( "$par1" =~ "end_alljob" ) { &end_alljob("$par2","$par3","$par5"); }

close STDCOMPFILE;
exit;

sub find_cksum()
{
	# Load system variables.
	$Slash = rindex($0,'/');
	if ($Slash > 0) {$PWD = substr($0, 0, $Slash)}
	else {$PWD = "."}
	
	$actscript = "$_[2]"; # "$0"; # perl mod it is diff call
	$write_secs = (stat($actscript))[9];
	$actfiletime =  scalar localtime($write_secs); $actfiletime =~ s/  / /g;
	
	$stdscript = "$_[0]"; # "$_[0]"; perl mod it is diff call
	$stdscriptpath = "/usr/tools/oracle/Standard/script";

	$stdscr_ver = "Ver 2.0 Dt 01-08-2007";
	$mydate = `$ux_date -u +%Y%m%d`; chomp($mydate);
	$mytime = `$ux_date -u "+%d-%b-%Y %T"`; chomp($mytime); 
	$myseq = "$_[1]";
		
	$actcksum = `$ux_cksm $actscript`;chomp($actcksum);
	($actcksum,$x) = split(' ', $actcksum, 2);

	$Stat = "^$stdscript";
	open (FILE,"$stdscriptpath/.std_script_cksum");
  	@LINES = <FILE>; close FILE;
  	@tmp = grep(/$Stat/, @LINES);
	$temp = $tmp[0];	
	($stdscript,$stdcksum,$stdfiletime) = split(/~/, $temp,3); chomp($stdfiletime);
	
	print STDCOMPFILE "$myseq,00-BEGIN,$mytime,$host,,$actscript,$actfiletime,$actcksum,$stdscript,$stdfiletime,$stdcksum,$stdscr_ver\n";

	$cksum_status = "SUCCESS";
	if ( $stdcksum ne $actcksum ) { $cksum_status = "FAILED";
		print STDCOMPFILE "$myseq,99-CKSUM_FAILED,$mytime,$host,,,,,$stdscript,,,\n";	
	}	

	if ( $actscript =~ "check_extents_all.pl" && $myserver_os =~ "Linux" ) {
		$cksum_status = "NOT_FOR_LINUX";
		print STDCOMPFILE "$myseq,99-NOT_FOR_LINUX,$mytime,$host,,,,,$stdscript,,,\n";	
	}
	
	return($cksum_status);
}

sub begin_eachjob()
{
	$myseq = "$_[0]";
	$mysid = "$_[1]";
	$mystdscript = "$_[2]";
	$mystage = "11-START";

	$ux_date = `which date`; chomp($ux_date);
	$mytime = `$ux_date -u "+%d-%b-%Y %T"`; chomp($mytime); 
	print STDCOMPFILE "$myseq,$mystage,$mytime,$host,$mysid,,,,$mystdscript,,,\n";
}


sub end_eachjob()
{
	$myseq = "$_[0]";
	$mysid = "$_[1]";
	$mystdscript = "$_[2]";
	$mystage = "22-END";
	$ux_date = `which date`; chomp($ux_date);
	$mytime = `$ux_date -u "+%d-%b-%Y %T"`; chomp($mytime); 
	print STDCOMPFILE "$myseq,$mystage,$mytime,$host,$mysid,,,,$mystdscript,,,\n";
}


sub end_alljob()
{
	$myseq = "$_[0]";
	$mysid = "$_[1]";
	$mystdscript = "$_[2]";
	$mystage = "99-END";
	$ux_date = `which date`; chomp($ux_date);
	$mytime = `$ux_date -u "+%d-%b-%Y %T"`; chomp($mytime);
	print STDCOMPFILE "$myseq,$mystage,$mytime,$host,$mysid,,,,$mystdscript,,,\n";
}

