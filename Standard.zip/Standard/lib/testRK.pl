#!/oracle/product/perl

require "stat.pl";
require "ctime.pl";
use Getopt::Std;
use Time::Local;
require "/usr/tools/oracle/Standard/script/perllib.pl";
use lib "/usr/tools/oracle/Standard/lib/";
use StdDBPackageRK;


$username          = "";
$passwd            = "";

getopt('s');
$sid               = $opt_s if defined($opt_s) || &usage;
$ENV{'ORACLE_SID'} = $sid;

&ora_home($sid);

$dbh =  &ConnectDB(); 
print "\n Connected to $sid \n";

sub usage
{
    print "$_[0]";
    print "Usage:\ndbstats.pl -s <SID>\n";
    exit (1);
}

sub ora_home()
{
my $oracle_sid;

    $oracle_sid = $_[0];

    #-------------------------------------------------------------------------
    # Sets  ORACLE_HOME based on /etc/oratab
    #-------------------------------------------------------------------------
    open(ORATAB, "/etc/oratab") || 
	&dbstats_error("Can't Open /etc/oratab. $!\n");
    
    while (<ORATAB>)
    {
        if (/^${oracle_sid}:/)
        {
            $oracle_home = (split(':'))[1];
            $ENV{'ORACLE_HOME'} = $oracle_home;
        $ENV{'ORACLE_SID'}=$oracle_sid;
        $ENV{'LD_LIBRARY_PATH'} = "$oracle_home/lib";
        $ENV{'SHLIB_PATH'} = "$oracle_home/lib";
        $ENV{'TNS_ADMIN'} = "$oracle_home/network/admin";
        ($oracle7)=&StdDBPackage::check_oracle7($oracle_sid);
        ($nls)=&StdDBPackage::check_nls;

        if ($oracle7 eq "Y")
        {
        $ENV{'ORA_NLS32'} = "$oracle_home/ocommon/nls/admin/data";
        $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
        }
        else
        {
          if ($nls eq "Y" )
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "/oracle/product/clntcurr/ocommon/nls/admin/data";
          }
          else
          {
          $ENV{'ORA_NLS32'} = "";
          $ENV{'ORA_NLS33'} = "";
          }
        }

        print "Sid $oracle_sid home $oracle_home\n" if defined($opt_d);
        print "Sid $oracle_sid Flag $db_flag\n" if defined($opt_d);
        &StdDBPackage::which_lib();
        }

    }
    close(ORATAB);
}

sub ConnectDB
{
my $dbh;

    print "sid is <$ENV{'ORACLE_SID'}>\n";
    $dbh = DBI->connect("dbi:Oracle:", $username, $passwd) ||
        &dbstats_error("Cannot connect to $oracle_sid. $DBI::errstr\n");
    return($dbh);
}

sub DisconnectDB
{
    $dbh->disconnect if ($dbh);
}
