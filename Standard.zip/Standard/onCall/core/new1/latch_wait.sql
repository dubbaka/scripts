col name for a22
col p1text for a8
col p2text for a8
col username for a11
col osuser for a8
col program for a30
col module for a26
col p2 for 999
col p1 for 9.99EEEE
col process for 99999
col sid for 9999
set pagesize 600
set linesize 200

select l.name,
       x.p1,
       x.p1text,
       x.p2,
       x.p2text,
       nvl(w.program, nvl(p.program, '<unknown program>')) program,
       nvl(w.module, nvl(w.module, '<unknown program>')) module,
       w.username,
w.sid,
--       w.serial#,
       w.osuser
--       w.process
from v$session w, v$session_wait x, v$latch l,
     v$process p
where w.sid = x.sid
and w.paddr = p.addr (+)
and l.latch# = x.p2
and x.event  like  ('%latch%') 
order by l.name,module,sid
/

