set heading on
col name heading "Name" format a30
col max_processes heading "Target" format 999
col running_processes heading "Actual" format 999
col run heading "Running" format 999
col pend heading "Pending" format 9999
col stat heading "Status" format a15
set pagesize 99
select a.user_concurrent_queue_name name, a.running_processes, a.max_processes,
nvl(b.running,0) run, nvl(c.pending,0) pend, d.status stat
-- from apps.fnd_concurrent_worker_requests a,
from apps.fnd_concurrent_queues_vl a,
(select concurrent_queue_name = b.concurrent_queue_name (+)
and a.concurrent_queue_name = c.concurrent_queue_name (+)
and a.concurrent_queue_name = d.concurrent_queue_name (+) and a.user_concurrent_queue_name = '&queue_name'
and d.status != 'Deactivated'
group by a.user_concurrent_queue_name,  a.max_processes, a.running_processes,
nvl(b.running,0), nvl(c.pending,0), d.status
order by d.status, 1;
