set pages 100
set lines 132
column comments format a50
column status format a10
select * 
  from dba_rsrc_consumer_groups
 order by consumer_group
;
