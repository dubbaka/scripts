                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."XXDEX_PROCESS_K" AUTHID CURRENT_USER as                                                         
/* $Header: XXDEX_PROCESS_K.sql 2.1.5.0 2010/08/07 12                                                                               
:00:00 dexsys ship $ Copyright (c) 2010 DEX Systems,                                                                                
 Inc.  */                                                                                                                           
                                                                                                                                    
	type PARTS_TBL is table of NUMBER index by BINARY_INTEGER;                                                                         
                                                                                                                                    
	type RMA_TBL is table of VARCHAR2(10) index by BINARY_INT                                                                          
EGER;                                                                                                                               
                                                                                                                                    
   procedure PART_BY_SERIAL ( myRetCode out number                                                                                  
									  ,myRetMesg out varchar2                                                                                                  
									  ,myParts	 out XXDEX_PROCESS_K.PARTS_TBL                                                                                  
									  ,mySerial  in  varchar2                                                                                                  
									  );                                                                                                                       
                                                                                                                                    
	procedure REPAIR_ROUTING ( myRetCode		out 	number                                                                                  
									  ,myRetMesg		out 	varchar2                                                                                                
									  ,myRepPlantID	out	number                                                                                                 
									  ,myOrdType		in  	varchar2                                                                                                
									  ,myRetPlantID	in		number                                                                                                 
									  ,myReasonCd		in		varchar2                                                                                                
									  ,myItemId			in		number                                                                                                   
									  );                                                                                                                       
                                                                                                                                    
	procedure RETURN_ROUTING ( myRetCode		out 	number                                                                                  
									  ,myRetMesg		out 	varchar2                                                                                                
									  ,myRetPlantId	out	number				-- Plant ID of Retur                                                                         
n                                                                                                                                   
									  ,myRepPlantId	out	number				-- Plant ID of Repair                                                                        
									  ,myOrgId			in		number                                                                                                    
									  ,myOrdType		in 	varchar2                                                                                                 
									  ,myCountry		in 	varchar2                                                                                                 
									  ,myState		   in 	varchar2                                                                                                
									  ,myItemId			in 	number                                                                                                   
									  ,myReasonCd		in		varchar2                                                                                                
									  );                                                                                                                       
                                                                                                                                    
	procedure ORDER_HOLD_CHECK ( myRetCode 	out number                                                                                 
										 ,myRetMesg		out varchar2                                                                                                 
										 ,myHoldId		out number                                                                                                    
										 ,myRMA			in	 varchar2                                                                                                    
										 ,myOrder		in	 varchar2 default null                                                                                      
										 ,myUseCC		in	 varchar2 default 'N'                                                                                       
										 );                                                                                                                       
                                                                                                                                    
	procedure COMPLETE_RMA ( myRetCode 		out 	number                                                                                   
 								   ,myRetMesg 		out	varchar2                                                                                               
 								   ,myRMAList		out 	XXDEX_PROCESS_K.RMA_TBL                                                                                
 								   ,myRMA			in		varchar2                                                                                                   
 								   ,myRtnPlantID	in		number                                                                                                
 								   ,myUseCCFlag	in		varchar2	default 'N'                                                                                   
 								   ,myCardAcct		in		varchar2 default null                                                                                  
 								   ,myCardCSC		in		varchar2 default null                                                                                   
 								   ,myRMAAmt		in		number   default null                                                                                    
 								   ,myHoldChecks  in    varchar2 default 'Y'                                                                               
                          );                                                                                                        
                                                                                                                                    
	procedure RMA_RELEASE_PROC	( myRetCode		out	number                                                                                 
										 ,myRetMesg		out	varchar2                                                                                                 
									 	);                                                                                                                       
                                                                                                                                    
end XXDEX_PROCESS_K;                                                                                                                
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."XXDEX_PROCESS_K" as                                                                          
/* $Header: XXDEX_PROCESS_K.sql 2.1.5.0 2010/08/07 12:00:00 dexsys                                                                  
ship $ Copyright (c) 2010 DEX Systems, Inc.  */                                                                                     
                                                                                                                                    
  /****************************************************                                                                             
***************************                                                                                                         
   *********************************   Private   ***************************                                                        
******                                                                                                                              
   ********************************************************************                                                             
***********/                                                                                                                        
                                                                                                                                    
   mySect    varchar2(100) := 'begin';                                                                                              
                                                                                                                                    
  /*************************************************************************                                                        
****                                                                                                                                
   *********************************   Public  **************************                                                           
*******                                                                                                                             
   *******************************************************************                                                              
**********/                                                                                                                         
                                                                                                                                    
   /*************************************************************                                                                   
*************                                                                                                                       
    This procedure will return a collection of Parts that is tie                                                                    
d to the                                                                                                                            
   	Serial Number.  The CustRef is the CCO ID.                                                                                      
    **********************************************************************                                                          
*****/                                                                                                                              
   procedure PART_BY_SERIAL ( myRetCode out number                                                                                  
									  ,myRetMesg out varchar2                                                                                                  
									  ,myParts	 out XXDEX_PROCESS_K.PARTS_TBL                                                                                  
									  ,mySerial  in  varchar2                                                                                                  
									 ) is                                                                                                                      
		cursor c1 is                                                                                                                      
			select distinct lne.INVENTORY_ITEM_ID                                                                                            
			from   LINES lne                                                                                                                 
					,SERIALS ser                                                                                                                   
			where  ser.SERIAL = mySerial                                                                                                     
			and    ser.ORDERNO = lne.ORDERNO                                                                                                 
			and    ser.ITEM    = lne.ITEM;                                                                                                   
                                                                                                                                    
		myIdx 	binary_integer := 0;                                                                                                       
	begin                                                                                                                              
		myRetCode := 0;                                                                                                                   
		mySect := 'Parts Loop';                                                                                                           
                                                                                                                                    
		for r1 in c1 loop                                                                                                                 
			myIdx := myIdx + 1;                                                                                                              
			myParts(myIdx) := r1.INVENTORY_ITEM_ID;                                                                                          
		end loop;                                                                                                                         
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			myRetMesg := mySect || ' ' || SQLERRM;                                                                                           
         myRetCode := 2;                                                                                                            
	end PART_BY_SERIAL;                                                                                                                
                                                                                                                                    
                                                                                                                                    
	/*************************************************************                                                                     
************************                                                                                                            
	 This procedure will return the Routing ORg ID (Plan                                                                               
t Org ID) based on the Routing                                                                                                      
	 Type, Item_ID, Region Code, Entity ID, and Ord Type.                                                                              
	 ********************************************************************                                                              
******************/                                                                                                                 
	procedure GET_ROUTING_ID ( myRetCode		out number                                                                                   
									  ,myRetMesg		out varchar2                                                                                                 
									  ,myPlantID		out number                                                                                                   
									  ,myRouteType		in  varchar2		-- N = Return, R = Repair, S                                                                 
= Shipping                                                                                                                          
									  ,myOrdType		in  varchar2                                                                                                 
									  ,myEntityID		in	 number                                                                                                  
									  ,myRegionCd		in  varchar2                                                                                                
									  ,myItemID			in  number                                                                                                   
									  ) is                                                                                                                     
                                                                                                                                    
		myProdFamily	MTL_ITEM_CATEGORIES_V.SEGMENT1%type;                                                                                 
		mySCnt			number;                                                                                                                  
                                                                                                                                    
		cursor c1 is                                                                                                                      
			select REGION_CODE                                                                                                               
					,PLANT_ID                                                                                                                      
			from   XXDEX_ROUTING_RULES                                                                                                       
			where  ROUTE_TYPE = myRouteType                                                                                                  
			and    ORDTYPE    = myOrdType                                                                                                    
			and    INVENTORY_ITEM_ID = myItemID                                                                                              
			and    ENTITY_ID  = myEntityID                                                                                                   
			and    myScnt = 1                                                                                                                
			union                                                                                                                            
			select REGION_CODE                                                                                                               
					,PLANT_ID                                                                                                                      
			from   XXDEX_ROUTING_RULES                                                                                                       
			where  ROUTE_TYPE = myRouteType                                                                                                  
			and    ORDTYPE    = myOrdType                                                                                                    
			and    INVENTORY_ITEM_ID is null                                                                                                 
			and    PRODUCT_FAMILY = myProdFamily                                                                                             
			and    ENTITY_ID  = myEntityID                                                                                                   
			and    mySCnt = 2                                                                                                                
			union                                                                                                                            
			select REGION_CODE                                                                                                               
					,PLANT_ID                                                                                                                      
			from   XXDEX_ROUTING_RULES                                                                                                       
			where  ROUTE_TYPE = myRouteType                                                                                                  
			and    ORDTYPE    = myOrdType                                                                                                    
			and    INVENTORY_ITEM_ID is null                                                                                                 
			and    PRODUCT_FAMILY is null                                                                                                    
			and    REGION_CODE = myRegionCd                                                                                                  
			and    ENTITY_ID  = myEntityID                                                                                                   
			and    mySCnt = 3                                                                                                                
			union                                                                                                                            
			select REGION_CODE                                                                                                               
					,PLANT_ID                                                                                                                      
			from   XXDEX_ROUTING_RULES                                                                                                       
			where  ROUTE_TYPE = myRouteType                                                                                                  
			and    ORDTYPE    = myOrdType                                                                                                    
			and    INVENTORY_ITEM_ID is null                                                                                                 
			and    PRODUCT_FAMILY is null                                                                                                    
			and    REGION_CODE is null                                                                                                       
			and    ENTITY_ID  = myEntityID                                                                                                   
			and    mySCnt = 4                                                                                                                
			order by 1;                                                                                                                      
                                                                                                                                    
	begin                                                                                                                              
		myRetcode := 0;                                                                                                                   
		myProdFamily := F_DEX_PRODUCT_CATEGORY(myItemID);                                                                                 
		myPlantID := null;                                                                                                                
                                                                                                                                    
		-- walk thru list 4 times or until plant id found                                                                                 
		for x in 1 .. 4 loop                                                                                                              
			mySCnt := x;                                                                                                                     
			for r1 in c1 loop                                                                                                                
				if nvl(r1.REGION_CODE,myRegionCd) = myRegionCD then                                                                             
					myPlantID := r1.PLANT_ID;                                                                                                      
					exit;                                                                                                                          
				end if;                                                                                                                         
			end loop;                                                                                                                        
			if myPlantID is not null then                                                                                                    
				exit;                                                                                                                           
			end if;                                                                                                                          
		end loop;                                                                                                                         
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			myRetCode := 2;                                                                                                                  
			myRetMesg := mySect || ' ' || SQLERRM;                                                                                           
	end GET_ROUTING_ID;                                                                                                                
                                                                                                                                    
                                                                                                                                    
	/********************************************************                                                                          
*********************************                                                                                                   
		Determines Repair Routing based on Return Plant, Order Reason Cd and                                                              
 Part Number                                                                                                                        
	 ***************************************************************                                                                   
**********************/                                                                                                             
	procedure REPAIR_ROUTING ( myRetCode		out 	number                                                                                  
									  ,myRetMesg		out 	varchar2                                                                                                
									  ,myRepPlantID	out	number                                                                                                 
									  ,myOrdType		in  	varchar2                                                                                                
									  ,myRetPlantID	in		number                                                                                                 
									  ,myReasonCd		in  	varchar2                                                                                               
									  ,myItemId			in    number                                                                                                 
									  ) is                                                                                                                     
                                                                                                                                    
		myRouteType		varchar2(1) := 'R';                                                                                                  
		myRegionCd		varchar2(40);                                                                                                         
		myOrgID			number;                                                                                                                 
                                                                                                                                    
	begin                                                                                                                              
                                                                                                                                    
		myRetcode := 0;                                                                                                                   
		myRegionCD := myReasonCd;                                                                                                         
                                                                                                                                    
		mySect := 'Repair Routing';                                                                                                       
		GET_ROUTING_ID ( myRetCode		=> myRetCode                                                                                          
						    ,myRetMesg		=> myRetMesg                                                                                                  
							 ,myPlantID		=> myRepPlantID                                                                                                 
							 ,myRouteType	=> myRouteType                                                                                                 
							 ,myOrdType		=> myOrdType                                                                                                    
							 ,myEntityID	=> myRetPlantID                                                                                                 
							 ,myRegionCd	=> myRegionCd                                                                                                   
							 ,myItemID		=> myItemID                                                                                                      
							 );                                                                                                                          
                                                                                                                                    
		if myRetCode = 0 then                                                                                                             
			myRepPlantID := nvl(myRepPlantId, myRetPlantId);                                                                                 
		end if;                                                                                                                           
	end REPAIR_ROUTING;                                                                                                                
                                                                                                                                    
	/***************************************************************************                                                       
*****************                                                                                                                   
		Determines Return Routing based on Bill Org ID, Country/St                                                                        
ate (Service Rgn) and Part Number                                                                                                   
	 ********************************************************************                                                              
***********************/                                                                                                            
	procedure RETURN_ROUTING ( myRetCode		out 	number                                                                                  
									  ,myRetMesg		out 	varchar2                                                                                                
									  ,myRetPlantId	out	number				-- Plant ID of Return                                                                        
									  ,myRepPlantId	out	number				-- Plant ID of Repair                                                                        
                                                                                                                                    
									  ,myOrgId			in		number                                                                                                    
									  ,myOrdType		in 	varchar2                                                                                                 
									  ,myCountry		in 	varchar2                                                                                                 
									  ,myState		   in 	varchar2                                                                                                
									  ,myItemId			in 	number                                                                                                   
									  ,myReasonCd		in		varchar2                                                                                                
									  ) is                                                                                                                     
                                                                                                                                    
		myRouteType		varchar2(1) := 'N';                                                                                                  
		myRegionCd		varchar2(40);                                                                                                         
                                                                                                                                    
	begin                                                                                                                              
		myRetcode := 0;                                                                                                                   
		myRegionCD := XXDEX_RETURN_REGION_F (myCountry, myState);                                                                         
		mySect := 'Return Route';                                                                                                         
		GET_ROUTING_ID ( myRetCode		=> myRetCode                                                                                          
						    ,myRetMesg		=> myRetMesg                                                                                                  
							 ,myPlantID		=> myRetPlantId                                                                                                 
							 ,myRouteType	=> myRouteType                                                                                                 
							 ,myOrdType		=> myOrdType                                                                                                    
							 ,myEntityID	=> myOrgID                                                                                                      
							 ,myRegionCd	=> myRegionCd                                                                                                   
							 ,myItemID		=> myItemID                                                                                                      
							 );                                                                                                                          
                                                                                                                                    
		if myRetCode = 0 then                                                                                                             
			myRetPlantID := nvl(myRetPlantID, XXDEX_PLANT_ID_F);                                                                             
                                                                                                                                    
			mySect := 'Return Route - Repair';                                                                                               
                                                                                                                                    
			REPAIR_ROUTING ( myRetCode		 => myRetCode                                                                                        
								 ,myRetMesg		 => myRetMesg                                                                                                  
								 ,myRepPlantId	 => myRepPlantId                                                                                             
								 ,myOrdType		 => myOrdType                                                                                                  
								 ,myRetPlantID  => myRetPlantID                                                                                             
								 ,myReasonCd	 => myReasonCd                                                                                                 
							 	 ,myItemId		 => myItemID                                                                                                   
							  	);                                                                                                                        
		end if;                                                                                                                           
                                                                                                                                    
                                                                                                                                    
	end RETURN_ROUTING;                                                                                                                
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    
	/*************************************************************                                                                     
************************                                                                                                            
		This procedure will check if any Holds need to be p                                                                               
lace on the RMA/Order                                                                                                               
	 ******************************************************                                                                            
*******************************/                                                                                                    
	procedure ORDER_HOLD_CHECK ( myRetCode 	out number                                                                                 
										 ,myRetMesg		out varchar2                                                                                                 
										 ,myHoldId		out number                                                                                                    
										 ,myRMA			in	 varchar2                                                                                                    
										 ,myOrder		in	 varchar2 default null                                                                                      
										 ,myUseCC		in	 varchar2 default 'N'                                                                                       
										 ) is                                                                                                                     
                                                                                                                                    
		myHoldName		XXDEX_HOLDS_V.NAME%Type;                                                                                              
		myTermName		XXDEX_CUSTOMERS_V.TERM_NAME%type;                                                                                     
		myCreditHold	XXDEX_CUSTOMERS_V.CREDIT_HOLD%type;                                                                                  
		myCountry		XXDEX_ORDERS_ALL_V.COUNTRY%type;                                                                                       
		myHistID			number;                                                                                                                
                                                                                                                                    
		myPassFail		varchar2(1);                                                                                                          
		myLimit			number;                                                                                                                 
		myBillSiteId	number;                                                                                                              
		myAmount			number;                                                                                                                
                                                                                                                                    
      myCustID       number(15);                                                                                                    
      myOrgID        number(15);                                                                                                    
                                                                                                                                    
      ABORT_PROC     exception;                                                                                                     
                                                                                                                                    
	begin                                                                                                                              
                                                                                                                                    
		myRetCode := 0;                                                                                                                   
                                                                                                                                    
		mySect := 'Credit Hold Check';                                                                                                    
                                                                                                                                    
		if myOrder is not null then                                                                                                       
			mySect := 'Hold Find - Order: ' || myOrder;                                                                                      
                                                                                                                                    
			select ord.BILL_SITE_USE_ID                                                                                                      
			      ,ord.CUSTOMER_ID                                                                                                           
			      ,ord.ORG_ID                                                                                                                
			into   myBillSiteID                                                                                                              
			      ,myCustID                                                                                                                  
			      ,myOrgID                                                                                                                   
			from   XXDEX_RMAHDR_ALL_V rmh                                                                                                    
					,XXDEX_ORDERS_ALL_V ord                                                                                                        
			where  ord.ORDERNO = myOrder                                                                                                     
			and    ord.RMA     = rmh.CALL (+);                                                                                               
                                                                                                                                    
			mySect := 'Hold Amt - Order: ' || myOrder;                                                                                       
                                                                                                                                    
			select sum(PRICE * (QTYORG - QTY_IW))                                                                                            
			into   myAmount                                                                                                                  
			from (                                                                                                                           
					select lne.PART                                                                                                                
							,lne.PRICE                                                                                                                   
							,sum(decode(lne.UOM,'LT',lne.QTYORG,1))	QTYORG                                                                               
							,sum(decode(lne.UOM,'LT',0, decode(ser.WARRANTY,'Valid',                                                                     
1,0))) QTY_IW                                                                                                                       
					from   DEX_SERIALS ser                                                                                                         
							,DEX_LINES lne                                                                                                               
					where  lne.ORDERNO = myOrder                                                                                                   
					and    lne.ORDERNO = ser.ORDERNO                                                                                               
					and    lne.ITEM    = ser.ITEM                                                                                                  
					group by lne.PART                                                                                                              
							  ,lne.PRICE                                                                                                                 
				   );                                                                                                                           
		else                                                                                                                              
			mySect := 'Hold Find - RMA: ' || myRMA;                                                                                          
                                                                                                                                    
         select rmh.BILL_SITE_USE_ID                                                                                                
               ,rmh.CUSTOMER_ID                                                                                                     
               ,rmh.ORG_ID                                                                                                          
         into   myBillSiteID                                                                                                        
			      ,myCustID                                                                                                                  
			      ,myOrgID                                                                                                                   
         from   XXDEX_RMAHDR_ALL_V rmh                                                                                              
         where  rmh.CALL = myRMA;                                                                                                   
                                                                                                                                    
			mySect := 'Hold Amt - RMA: ' || myRMA;                                                                                           
                                                                                                                                    
			select sum(PRICE * (QTYORG - QTY_IW))                                                                                            
			into   myAmount                                                                                                                  
			from (                                                                                                                           
					select rd.PART                                                                                                                 
							,rd.PRICE                                                                                                                    
							,sum(rd.QTYORG)	QTYORG                                                                                                       
							,sum(decode(rs.WARRANTY,'Valid',1,0)) QTY_IW                                                                                 
					from   RMA_SERIALS rs                                                                                                          
							,DEX_RMADET rd                                                                                                               
					where  rd.CALL = myRMA                                                                                                         
					and    rd.CALL = rs.CALL (+)                                                                                                   
					and    rd.ITEM = rs.ITEM (+)                                                                                                   
					group by rd.PART                                                                                                               
							  ,rd.PRICE                                                                                                                  
				   );                                                                                                                           
		end if;                                                                                                                           
                                                                                                                                    
      mySect := 'Hold Term - CustID: ' || to_char(myCustID) ||                                                                      
' OrgID: ' || to_char(myOrgID);                                                                                                     
                                                                                                                                    
      begin                                                                                                                         
         select TERM_NAME                                                                                                           
         into   myTermName                                                                                                          
         from   XXDEX_CUSTOMERS_ALL_V                                                                                               
         where  CUSTOMER_ID = myCustID                                                                                              
         and    ORG_ID      = myOrgID                                                                                               
         and    SITE_USE_ID = myBillSiteId;                                                                                         
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myRetMesg := XXDEX_CUSTOMERS_ERROR_F ( myCustID,myOrgID );                                                           
               raise ABORT_PROC;                                                                                                    
         end;                                                                                                                       
                                                                                                                                    
      mySect := 'Hold Check';                                                                                                       
                                                                                                                                    
		XXDEX_CUST_CREDIT_CHECK_P (                                                                                                       
											 myRetCode		=> myRetCode                                                                                                 
										 	,myRetMesg		=> myRetMesg                                                                                                
										 	,myPassFail		=> myPassFail                                                                                              
										 	,myLimit			=> myLimit                                                                                                   
										 	,myHoldFlag		=> myCreditHold                                                                                            
										 	,myBillSiteId	=> myBillSiteID                                                                                           
										 	,myAmount		=> myAmount                                                                                                  
										 	);                                                                                                                      
                                                                                                                                    
		if myRetCode != 0 and myUseCC = 'N' then                                                                                          
			myHoldName := XXDEX_DEFAULTS_F('CREDIT_CHECK_HOLD_NAME');                                                                        
                                                                                                                                    
		elsif myTermName = 'CIA' and myUseCC = 'N' then                                                                                   
			myHoldName := 'Collect In Advance';                                                                                              
                                                                                                                                    
		else                                                                                                                              
			myHoldName := XXDEX_DENIED_PARTY_F (myOrder, myRMA);                                                                             
		end if;                                                                                                                           
                                                                                                                                    
		if myHoldName is not null then                                                                                                    
			mySect := 'Hold Name (' || myHoldName || ')';                                                                                    
                                                                                                                                    
			select HOLD_ID                                                                                                                   
			into	 myHoldID                                                                                                                   
			from   OE_HOLD_DEFINITIONS                                                                                                       
			where  NAME = myHoldName;                                                                                                        
		end if;                                                                                                                           
                                                                                                                                    
		if myHoldID is not null then                                                                                                      
		   mySect := 'Hold Hist (' || to_char(myHoldID) || ')';                                                                           
                                                                                                                                    
			-- check if Order/RMA already had Release of Hold.                                                                               
If so then don't assign hold.                                                                                                       
			select max(HISTORY_ID)                                                                                                           
			into   myHistID                                                                                                                  
			from   XXDEX_HOLD_HISTORY                                                                                                        
			where  RCD_TYPE  = decode(myOrder,null, 'R','O')                                                                                 
			and    RECORD_ID = nvl(myOrder,myRMA)                                                                                            
			and    HOLD_ID   = myHoldID                                                                                                      
			and    ACTION_CODE = 'R';                                                                                                        
			if myHistID is not null then                                                                                                     
				myHoldID := null;                                                                                                               
				myRetCode := 0;                                                                                                                 
			end if;                                                                                                                          
		end if;                                                                                                                           
                                                                                                                                    
		-- return success but even if Hold ID is set.                                                                                     
		myRetCode := 0;                                                                                                                   
                                                                                                                                    
	exception                                                                                                                          
	   when ABORT_PROC then                                                                                                            
	      myRetCode := 2;                                                                                                              
                                                                                                                                    
		when NO_DATA_FOUND then                                                                                                           
			myRetCode := 2;                                                                                                                  
			myRetMesg := mySect || ' Not Found';                                                                                             
                                                                                                                                    
		when OTHERS then                                                                                                                  
			myRetCode := 2;                                                                                                                  
			myRetMesg := mySect || ' ' || SQLERRM;                                                                                           
	end ORDER_HOLD_CHECK;                                                                                                              
                                                                                                                                    
	/********************************************************                                                                          
***************************                                                                                                         
	 This procedure is called from RMA Form and B2Bs to determine if the RMA ca                                                        
n be                                                                                                                                
	 processed to an Open Status.  if a RtnLocID is passed as override then                                                            
all lines                                                                                                                           
	 can be placed on same RMA.                                                                                                        
	 ***************************************************************                                                                   
********************/                                                                                                               
	procedure COMPLETE_RMA ( myRetCode 		out 	number                                                                                   
 								   ,myRetMesg 		out	varchar2                                                                                               
 								   ,myRMAList		out 	XXDEX_PROCESS_K.RMA_TBL                                                                                
 								   ,myRMA			in		varchar2                                                                                                   
 								   ,myRtnPlantID	in		number                                                                                                
 								   ,myUseCCFlag	in		varchar2	default 'N'                                                                                   
 								   ,myCardAcct		in		varchar2 default null                                                                                  
 								   ,myCardCSC		in		varchar2 default null                                                                                   
 								   ,myRMAAmt		in		number   default null                                                                                    
 								   ,myHoldChecks  in    varchar2 default 'Y'                                                                               
 								   ) is                                                                                                                    
                                                                                                                                    
		myCountry		XXDEX_ADDRESSES_V.COUNTRY%type;                                                                                        
		myState			XXDEX_ADDRESSES_V.PROVINCE%type;                                                                                        
		myFnd				varchar2(1);                                                                                                             
		myPlant			DEX_PLANTS.PLANT%type;                                                                                                  
		myHoldDescr		varchar2(240);                                                                                                       
		myPriceType		RMAHDR.PRICE_TYPE_CODE%type;                                                                                         
                                                                                                                                    
		myHoldID			number;                                                                                                                
		myItemID			number;                                                                                                                
		myIdx				number := 0;                                                                                                             
		myPdx				number := 0;                                                                                                             
		myRdx				number := 0;                                                                                                             
                                                                                                                                    
		myRetPlantID	number;                                                                                                              
		myRepPlantId	number;                                                                                                              
		myRMAPlantID	number;                                                                                                              
                                                                                                                                    
		myOrgID			number;                                                                                                                 
		myItem			number;                                                                                                                  
                                                                                                                                    
		myROrgID			number;                                                                                                                
		myIOrgID			number;                                                                                                                
                                                                                                                                    
		myCall			RMAHDR.CALL%type;                                                                                                        
		myOrdType		RMAHDR.ORDTYPE%type;                                                                                                   
                                                                                                                                    
		myProcFlag		varchar2(1) := 'Y';                                                                                                   
		myCustPO			RMAHDR.CUSTPO%type;                                                                                                    
		myCardType		RMAHDR.CREDIT_CARD_TYPE%type;                                                                                         
		myCardName		RMAHDR.CREDIT_CARD_NAME%type;                                                                                         
		myCardExp		RMAHDR.CREDIT_CARD_EXP%type;                                                                                           
		myCardApproval	RMAHDR.CREDIT_CARD_APPROVAL%type;                                                                                  
		myShipSt1		RMAHDR.SHIP_ST1%type;                                                                                                  
		myShipZip		RMAHDR.SHIP_ZIP%type;                                                                                                  
		myAmount			number;                                                                                                                
		myTranId			number;                                                                                                                
		myReturn			varchar2(500);                                                                                                         
		myOrder			RMAHDR.ORDERNO%type;                                                                                                    
		myAuthRMA		RMAHDR.AUTHORIZATION%type;                                                                                             
		myMastOrg		varchar2(1);                                                                                                           
		myLineCnt		number;                                                                                                                
		myPlantCode		DEX_PLANTS.PLANT_CODE%type;                                                                                          
                                                                                                                                    
		myChkHolds	   varchar2(1) := myHoldChecks;                                                                                        
                                                                                                                                    
		type RETURN_REC is record (                                                                                                       
	  		 INVENTORY_ITEM_ID		NUMBER                                                                                                     
	    	,RETURN_PLANT_ID			NUMBER                                                                                                     
	    	,REPAIR_PLANT_ID			NUMBER                                                                                                     
	   	);                                                                                                                             
                                                                                                                                    
		type RETURN_TBL is table of RETURN_REC index by BINARY_INTEGER;                                                                   
		type PLANT_TBL is table of NUMBER index by BINARY_INTEGER;                                                                        
                                                                                                                                    
		myItemList	RETURN_TBL;                                                                                                            
		myPlantList	PLANT_TBL;                                                                                                            
                                                                                                                                    
		cursor c1 is                                                                                                                      
			select distinct INVENTORY_ITEM_ID                                                                                                
			from   DEX_RMADET                                                                                                                
			where  CALL = myRMA;                                                                                                             
                                                                                                                                    
		cursor c2 (myItemID number) is                                                                                                    
			select ITEM                                                                                                                      
			from   DEX_RMADET                                                                                                                
			where  CALL = myRMA                                                                                                              
			and    INVENTORY_ITEM_ID = myItemID;                                                                                             
	begin                                                                                                                              
		myRetCode := 0;                                                                                                                   
                                                                                                                                    
		myRMAList(1) := myRMA;                                                                                                            
                                                                                                                                    
		select count(*)                                                                                                                   
		into   myLineCnt                                                                                                                  
		from   DEX_RMADET                                                                                                                 
		where  CALL = myRMA;                                                                                                              
		if myLineCnt = 0 then                                                                                                             
			myRetCode := 1;                                                                                                                  
			myRetMesg := 'No RMA Details exist. Cannot complete RMA.';                                                                       
			return;                                                                                                                          
		end if;                                                                                                                           
                                                                                                                                    
		mySect := 'Comp RMA - Select';                                                                                                    
		select rmh.SHIP_STATE                                                                                                             
				,rmh.COUNTRY                                                                                                                    
				,rmh.ORDTYPE                                                                                                                    
				,rmh.ORG_ID                                                                                                                     
				,rmh.PRICE_TYPE_CODE                                                                                                            
				,rmh.CREDIT_CARD_NAME                                                                                                           
				,rmh.CREDIT_CARD_TYPE                                                                                                           
				,rmh.CREDIT_CARD_EXP                                                                                                            
				,rmh.CREDIT_CARD_APPROVAL                                                                                                       
				,rmh.SHIP_ST1                                                                                                                   
				,rmh.SHIP_ZIP                                                                                                                   
				,rmh.CUSTPO                                                                                                                     
				,rmh.ORDERNO                                                                                                                    
				,rmh.AUTHORIZATION                                                                                                              
				,rmh.PLANT_ID                                                                                                                   
				,rmh.HOLD_ID                                                                                                                    
		into   myState                                                                                                                    
				,myCountry                                                                                                                      
				,myOrdType                                                                                                                      
				,myOrgId                                                                                                                        
				,myPriceType                                                                                                                    
				,myCardName                                                                                                                     
				,myCardType                                                                                                                     
				,myCardExp                                                                                                                      
				,myCardApproval                                                                                                                 
				,myShipSt1                                                                                                                      
				,myShipZip                                                                                                                      
				,myCustPO                                                                                                                       
				,myOrder                                                                                                                        
				,myAuthRMA                                                                                                                      
				,myRMAPlantID                                                                                                                   
				,myHoldID                                                                                                                       
		from   DEX_PLANTS dxp                                                                                                             
				,XXDEX_RMAHDR_ALL_V rmh                                                                                                         
		where  rmh.CALL = myRMA                                                                                                           
		and    rmh.PLANT_ID = dxp.PLANT_ID;                                                                                               
                                                                                                                                    
		begin                                                                                                                             
			select nvl(PLANT_CODE,'I')                                                                                                       
			into   myPlantCode                                                                                                               
			from   DEX_PLANTS                                                                                                                
			where  PLANT_ID = nvl(myRtnPlantID, myRMAPlantID);                                                                               
                                                                                                                                    
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRetCode := 2;                                                                                                                 
				myRetMesg := 'Cannot find Plant for PlantID: ' || nvl(myRtnPlantID                                                              
, myRMAPlantID);                                                                                                                    
				return;                                                                                                                         
		end;                                                                                                                              
		if myUseCCFlag = 'R' and WEB_PAYMENTS_K.SETUP(myOrgID) = 'Y' and m                                                                
yAuthRMA is null then                                                                                                               
			mySect := 'Complet RMA - CC Load';                                                                                               
                                                                                                                                    
			myReturn := K_DEX_WEB_PAYMENTS.LOAD (                                                                                            
									                   myTranID     => myTranId                                                                                
									                  ,myOrder      => myRMA                                                                                   
									                  ,myPONum      => myCustPO                                                                                
									                  ,myCardType   => myCardType                                                                              
                                                                                                                                    
									                  ,myCardName   => myCardname                                                                              
									                  ,myCardAcct   => myCardAcct                                                                              
									                  ,myCardCSC    => myCardCSC                                                                               
									                  ,myCardExp    => myCardExp                                                                               
									                  ,myStreet     => myShipSt1                                                                               
									                  ,myZip        => myShipZip                                                                               
									                  ,myAmt        => myRMAAmt                                                                                
									                  ,myOrgID      => myOrgId                                                                                 
									                  ,myProcFlag   => myProcFlag                                                                              
									                  ,myOrdType	  => 'R'					-- RMA                                                                           
									                 );                                                                                                        
			if myReturn != 'VALID' then                                                                                                      
				myRetCode := 2;                                                                                                                 
				myRetMesg := 'Credit Card Auth Failed: ' || myReturn;                                                                           
				return;                                                                                                                         
			end if;                                                                                                                          
		end if;                                                                                                                           
                                                                                                                                    
                                                                                                                                    
		if myPlantCode = 'A' or myAuthRMA is not null then                                                                                
			-- July 2010 - only do hold checks for RMAs that are not t                                                                       
ied to Order or Authorized Plants                                                                                                   
			myChkHolds := 'N';                                                                                                               
		else                                                                                                                              
			myChkHolds := 'Y';                                                                                                               
		end if;                                                                                                                           
                                                                                                                                    
                                                                                                                                    
		if myChkHolds = 'Y' then                                                                                                          
			mySect := 'Comp RMA - Hold';                                                                                                     
			ORDER_HOLD_CHECK ( myRetCode => myRetCode                                                                                        
									,myRetMesg => myRetMesg                                                                                                    
									,myHoldID  => myHoldID                                                                                                     
									,myRMA     => myRMA                                                                                                        
									,myUseCC	  => myUseCCFlag                                                                                                  
								  );                                                                                                                        
			if myRetCode != 0 then                                                                                                           
				return;                                                                                                                         
			end if;                                                                                                                          
                                                                                                                                    
			update DEX_RMAHDR set                                                                                                            
			HOLD_ID = myHoldID                                                                                                               
			where  CALL = myRMA;                                                                                                             
                                                                                                                                    
			if myHoldID is not null then                                                                                                     
				select DESCRIPTION                                                                                                              
				into   myHoldDescr                                                                                                              
				from   OE_HOLD_DEFINITIONS                                                                                                      
				where  HOLD_ID = myHoldId;                                                                                                      
                                                                                                                                    
				myRetCode := 1;                                                                                                                 
				myRetMesg := 'RMA placed on hold: ' || nvl(myRetMesg, myHoldDescr);                                                             
				return ;                                                                                                                        
			end if;                                                                                                                          
                                                                                                                                    
		elsif myHoldID is not null then                                                                                                   
			-- clear existing hold if Hold Checks not needed                                                                                 
			mySect := 'Comp RMA - Hold Clear';                                                                                               
			update DEX_RMAHDR set                                                                                                            
			HOLD_ID = null                                                                                                                   
			where CALL = myRMA;                                                                                                              
                                                                                                                                    
		end if;                                                                                                                           
                                                                                                                                    
		mySect := 'Comp RMA - Return Locs';                                                                                               
                                                                                                                                    
		for r1 in c1 loop                                                                                                                 
			-- If Return Location Override (myRtnPlantID) specifi                                                                            
ed, then find all of the Repair Locations                                                                                           
			-- for the Part/Reason Code.  Else, compute the Return and                                                                       
Repair locations.                                                                                                                   
                                                                                                                                    
			if myRtnPlantID is not null then			-- override specified                                                                         
                                                                                                                                    
				myRetPlantID := myRtnPlantID;                                                                                                   
				REPAIR_ROUTING ( myRetCode		 => myRetCode                                                                                       
									 ,myRetMesg		 => myRetMesg                                                                                                 
									 ,myRepPlantId	 => myRepPlantId                                                                                            
									 ,myOrdType		 => myOrdType                                                                                                 
									 ,myRetPlantID  => myRetPlantID                                                                                            
									 ,myReasonCd	 => myPriceType                                                                                               
							 		 ,myItemId		 => r1.INVENTORY_ITEM_ID                                                                                      
							  		);                                                                                                                       
			else                                                                                                                             
				RETURN_ROUTING ( myRetCode	    => myRetCode                                                                                     
				  				    ,myRetMesg	    => myRetMesg                                                                                           
									 ,myRetPlantId	 => myRetPlantId                                                                                            
									 ,myRepPlantId  => myRepPlantId                                                                                            
									 ,myOrgId	    => myOrgID                                                                                                   
									 ,myOrdType	    => myOrdType                                                                                               
									 ,myCountry	    => myCountry                                                                                               
									 ,myState	    => myState                                                                                                   
									 ,myItemId	    => r1.INVENTORY_ITEM_ID                                                                                     
									 ,myReasonCd    => myPriceType                                                                                             
									);                                                                                                                         
			end if;                                                                                                                          
			if myRetCode != 0 then                                                                                                           
				exit;                                                                                                                           
			end if;                                                                                                                          
                                                                                                                                    
			myIdx := myIdx + 1;                                                                                                              
			myItemList(myIdx).INVENTORY_ITEM_ID := r1.INVENTORY_ITEM_ID;                                                                     
			myItemList(myIdx).RETURN_PLANT_ID := myRetPlantId;                                                                               
			myItemList(myIdx).REPAIR_PLANT_ID := myRepPlantId;                                                                               
                                                                                                                                    
			myFnd := 'N';                                                                                                                    
			for i in 1 .. myPdx loop                                                                                                         
				if myPlantList(i) = myRetPlantID then                                                                                           
					myFnd := 'Y';                                                                                                                  
					exit;                                                                                                                          
				end if;                                                                                                                         
			end loop;                                                                                                                        
                                                                                                                                    
			if myFnd = 'N' then                                                                                                              
				myPdx := myPdx + 1;                                                                                                             
				myPlantList(myPdx) := myRetPlantID;                                                                                             
			end if;                                                                                                                          
		end loop;                                                                                                                         
                                                                                                                                    
		if myRetCode != 0 then                                                                                                            
			return;                                                                                                                          
		end if;                                                                                                                           
                                                                                                                                    
		mySect := 'Comp RMA - Split';                                                                                                     
		myCall := myRMA;			-- first RMA same as original RMA                                                                              
		for i in 1 .. myPdx loop                                                                                                          
			myRetPlantId := myPlantList(i);                                                                                                  
                                                                                                                                    
			select PLANT                                                                                                                     
			into   myPlant                                                                                                                   
			from 	 XXDEX_PLANTS_ALL_V                                                                                                        
			where  PLANT_ID = myRetPlantID;                                                                                                  
                                                                                                                                    
			myMastOrg := XXDEX_DEFAULTS_F ('RMA_MASTER_ORG', myRetPlantId);                                                                  
			if myMastOrg = 'Y' then                                                                                                          
				myIOrgID := DEX_ORGANIZATIONS_K.MASTER_ID;                                                                                      
			else                                                                                                                             
				myIOrgID := DEX_ORGANIZATIONS_K.BUS_TYPE(myRetPlantI                                                                            
D, 'R');                                                                                                                            
			end if;                                                                                                                          
                                                                                                                                    
			if myCall is null then                                                                                                           
				myCall  := F_PREBOOK_CHECK;                                                                                                     
			end if;                                                                                                                          
			for j in 1 .. myIdx loop                                                                                                         
				if myItemList(j).RETURN_PLANT_ID = myRetPlantID then                                                                            
					myItemID := myItemList(j).INVENTORY_ITEM_ID;                                                                                   
					myRepPlantId := myItemList(j).REPAIR_PLANT_ID;                                                                                 
                                                                                                                                    
					mySect := 'Comp - Update RMADET';                                                                                              
                                                                                                                                    
					for r2 in c2 (myItemID) loop                                                                                                   
						update DEX_RMA_SERIALS set                                                                                                    
						CALL   = myCall								-- first time thru Call will                                                                           
 be same as RMA                                                                                                                     
						where  CALL = myRMA                                                                                                           
						and    ITEM = r2.ITEM;                                                                                                        
                                                                                                                                    
						update DEX_RMADET set                                                                                                         
						CALL   = myCAll                                                                                                               
					  ,ORGANIZATION_ID = myIOrgID                                                                                                  
					  ,REPAIR_PLANT_ID = myRepPlantID                                                                                              
						where  CALL = myRMA                                                                                                           
						and    ITEM = r2.ITEM;                                                                                                        
					end loop;                                                                                                                      
				end if;                                                                                                                         
			end loop;                                                                                                                        
                                                                                                                                    
			if myCall != myRMA then                                                                                                          
				mySect := 'Comp RMA - Inser RMAHDR';                                                                                            
				insert into DEX_RMAHDR (                                                                                                        
				CALL,PLANT,PLANT_ID,STATUS,DATEOPN                                                                                              
				,CODE_OPEN,CODE_CLOSE,COUNT,CUSTPO,CONTACT,METHOD,RELEASE,SHIP                                                                  
TO,DROP_SHIP,SHIP_VIA                                                                                                               
				,SHIP_NAME,SHIP_ATTN,SHIP_ST1,SHIP_ST2,SHIP_CITY,SHI                                                                            
P_STATE,SHIP_ZIP,SCAR,NOTIFY,DATEEXP,ORIGIN,INITIATO                                                                                
R                                                                                                                                   
				,EDIDATE,EDITIME,BRANCH_FROM,BRANCH_TO,RA_NUMBER,ORDERNO,CUST,REGION,AGE                                                        
NT,TLM,ORDTYPE,JOB_NUMBER                                                                                                           
				,FROM_NAME,FROM_ST1,FROM_ST2,FROM_CITY,FROM_STAT                                                                                
E,FROM_ZIP,PRIORITY,PROGRAM,FROM_CODE,TO_CODE                                                                                       
				,PICKHDR,TELEPHONE,ENGINEER,MANAGER,DISPATCH,CUST_NUMB                                                                          
ER,CONTRACT,AUTHORIZATION,APPROVAL,ORDER_REV,STOCK_C                                                                                
ODE                                                                                                                                 
				,DATECLS,MSG_STATUS,MESSAGE,EDI,SHIPMENT,SHIPTO_LOC_CODE,SHIPTO_SITE_C                                                          
ODE,INFO_SOURCE,DRIVER,INET_COMMENTS                                                                                                
				,RETURN_RMA,RETURN_TAG,PARTIAL_SHP,HOLD_CODE,FREIGHT_QUOTE,CRED                                                                 
IT_CARD_TYPE,CREDIT_CARD_NAME,CREDIT_CARD_ACCT                                                                                      
				,CREDIT_CARD_EXP,CREDIT_CARD_METHOD,CREDIT_CARD_APPRO                                                                           
VAL,SATURDAY_DELIVERY,LEAD_ID,COUNTRY,CREATION_DATE,                                                                                
ORG_ID,CUSTOMER_ID                                                                                                                  
				,BILL_SITE_USE_ID,SHIP_SITE_USE_ID,CUST_EXCHANGE,LAST_U                                                                         
PDATE_DATE,LAST_UPDATED_BY,CREATED_BY,USER_DATA_ID,O                                                                                
RDER_SOURCE                                                                                                                         
				,NEED_PO_FLAG,PROVINCE,BOX_KIT,REVERSE_AE,FTP,CC_HEADER_ID,RET                                                                  
URN_FLAG,RETURN_ORDER,PAYMENT_OPTION,PRICE_TYPE_CODE                                                                                
                                                                                                                                    
				,RESIDENTIAL_FLAG,SPECIAL_HANDLING,FTP_DATE,NOTIFY_EMAIL,RELABEL_FLAG,CON                                                       
TACT_ID,OSP_FLAG,LAST_UPDATED_USER_DATA_ID                                                                                          
				,PO_HEADER_ID,DATECLS_TRUNC,FRT_THIRD_PARTY_NAME,FRT_THIR                                                                       
D_PARTY_CONTACT,FRT_THIRD_PARTY_ADDRESS1,FRT_THIRD_P                                                                                
ARTY_ADDRESS2                                                                                                                       
				,FRT_THIRD_PARTY_CITY,FRT_THIRD_PARTY_CODE,FRT_THIRD_PARTY_S                                                                    
TATE,FRT_THIRD_PARTY_POSTALCODE,FRT_THIRD_PARTY_PHON                                                                                
E,FRT_THIRD_PARTY_ACCT                                                                                                              
				,FRT_THIRD_PARTY_FLAG,CUST_STATUS,COMMENTS,OUTSIDE_                                                                             
SALESREP_ID,INSIDE_SALESREP_ID,HOLD_ID,ATTRIBUTE_CAT                                                                                
EGORY                                                                                                                               
				,CURRENCY_CODE,EXCHANGE_RATE_TYPE,EXCHANGE_RATE_DATE,EXCHANGE_RATE                                                              
				,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTR                                                                               
IBUTE5,ATTRIBUTE6,ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9,A                                                                                
TTRIBUTE10                                                                                                                          
				,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,ATTRIBUTE15,AT                                                                 
TRIBUTE16,ATTRIBUTE17,ATTRIBUTE18,ATTRIBUTE19,ATTRIB                                                                                
UTE20                                                                                                                               
				,ATTRIBUTE21,ATTRIBUTE22,ATTRIBUTE23,ATTRIBUTE24,ATTRIBUTE25,ATTRIBU                                                            
TE26,ATTRIBUTE27,ATTRIBUTE28,ATTRIBUTE29,ATTRIBUTE30                                                                                
                                                                                                                                    
				,ATTRIBUTE31,ATTRIBUTE32,ATTRIBUTE33,ATTRIBUTE34,ATTRIBUTE35,ATTRIBUTE36,                                                       
ATTRIBUTE37,ATTRIBUTE38,ATTRIBUTE39,ATTRIBUTE40                                                                                     
				)                                                                                                                               
				 select myCall,myPlant,myRetPlantID,'O',trunc(SYSDATE)                                                                          
				,CODE_OPEN,CODE_CLOSE,COUNT,CUSTPO,CONTACT,METHOD,RELEASE || '-'                                                                
|| i,SHIPTO,DROP_SHIP,SHIP_VIA                                                                                                      
				,SHIP_NAME,SHIP_ATTN,SHIP_ST1,SHIP_ST2,SHIP_CITY,SHIP_STATE,SHIP_ZIP,                                                           
SCAR,NOTIFY,DATEEXP,ORIGIN,INITIATOR                                                                                                
				,EDIDATE,EDITIME,BRANCH_FROM,BRANCH_TO,RA_NUMBER,ORDERNO,CUST,R                                                                 
EGION,AGENT,TLM,ORDTYPE,JOB_NUMBER                                                                                                  
				,FROM_NAME,FROM_ST1,FROM_ST2,FROM_CITY,FROM_STATE,FROM_ZIP,PRIORI                                                               
TY,PROGRAM,FROM_CODE,TO_CODE                                                                                                        
				,PICKHDR,TELEPHONE,ENGINEER,MANAGER,DISPATCH,CUST_NUMBER,CONTRACT,AUTHO                                                         
RIZATION,APPROVAL,ORDER_REV,STOCK_CODE                                                                                              
				,DATECLS,MSG_STATUS,MESSAGE,EDI,SHIPMENT,SHIPTO_LOC_CODE,SHIP                                                                   
TO_SITE_CODE,INFO_SOURCE,DRIVER,INET_COMMENTS                                                                                       
				,RETURN_RMA,RETURN_TAG,PARTIAL_SHP,HOLD_CODE,FREIGHT_Q                                                                          
UOTE,CREDIT_CARD_TYPE,CREDIT_CARD_NAME,CREDIT_CARD_A                                                                                
CCT                                                                                                                                 
				,CREDIT_CARD_EXP,CREDIT_CARD_METHOD,CREDIT_CARD_APPROVAL,SATURDAY_DELI                                                          
VERY,LEAD_ID,COUNTRY,CREATION_DATE,ORG_ID,CUSTOMER_I                                                                                
D                                                                                                                                   
				,BILL_SITE_USE_ID,SHIP_SITE_USE_ID,CUST_EXCHANGE,LAST_UPDATE_DATE,LAST_U                                                        
PDATED_BY,CREATED_BY,USER_DATA_ID,ORDER_SOURCE                                                                                      
				,NEED_PO_FLAG,PROVINCE,BOX_KIT,REVERSE_AE,FTP,CC_HEAD                                                                           
ER_ID,RETURN_FLAG,RETURN_ORDER,PAYMENT_OPTION,PRICE_                                                                                
TYPE_CODE                                                                                                                           
				,RESIDENTIAL_FLAG,SPECIAL_HANDLING,FTP_DATE,NOTIFY_EMAIL,RELABEL                                                                
_FLAG,CONTACT_ID,OSP_FLAG,LAST_UPDATED_USER_DATA_ID                                                                                 
				,PO_HEADER_ID,DATECLS_TRUNC,FRT_THIRD_PARTY_NAME                                                                                
,FRT_THIRD_PARTY_CONTACT,FRT_THIRD_PARTY_ADDRESS1,FR                                                                                
T_THIRD_PARTY_ADDRESS2                                                                                                              
				,FRT_THIRD_PARTY_CITY,FRT_THIRD_PARTY_CODE,FRT_THIR                                                                             
D_PARTY_STATE,FRT_THIRD_PARTY_POSTALCODE,FRT_THIRD_P                                                                                
ARTY_PHONE,FRT_THIRD_PARTY_ACCT                                                                                                     
				,FRT_THIRD_PARTY_FLAG,CUST_STATUS,COMMENTS,OUTSIDE_SALESREP_ID,INSID                                                            
E_SALESREP_ID,HOLD_ID,ATTRIBUTE_CATEGORY                                                                                            
				,CURRENCY_CODE,EXCHANGE_RATE_TYPE,EXCHANGE_RATE_DATE,EXCHAN                                                                     
GE_RATE                                                                                                                             
				,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTRIBUTE5,ATTRIBUTE6                                                              
,ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9,ATTRIBUTE10                                                                                       
				,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,ATTRI                                                                          
BUTE15,ATTRIBUTE16,ATTRIBUTE17,ATTRIBUTE18,ATTRIBUTE                                                                                
19,ATTRIBUTE20                                                                                                                      
				,ATTRIBUTE21,ATTRIBUTE22,ATTRIBUTE23,ATTRIBUTE24,ATTRIBUTE2                                                                     
5,ATTRIBUTE26,ATTRIBUTE27,ATTRIBUTE28,ATTRIBUTE29,AT                                                                                
TRIBUTE30                                                                                                                           
				,ATTRIBUTE31,ATTRIBUTE32,ATTRIBUTE33,ATTRIBUTE34,ATTRIBUTE35,ATT                                                                
RIBUTE36,ATTRIBUTE37,ATTRIBUTE38,ATTRIBUTE39,ATTRIBU                                                                                
TE40                                                                                                                                
				from DEX_RMAHDR                                                                                                                 
				where CALL = myRMA;                                                                                                             
                                                                                                                                    
			else                                                                                                                             
				mySect := 'Comp RMA - Updt RMA';                                                                                                
				update DEX_RMAHDR set                                                                                                           
				PLANT = myPlant                                                                                                                 
			  ,PLANT_ID = myRetPlantID                                                                                                       
			  ,STATUS = 'O'                                                                                                                  
			  ,DATEOPN = trunc(SYSDATE)                                                                                                      
				where CALL = myRMA;                                                                                                             
			end if;                                                                                                                          
                                                                                                                                    
			myRMAList(i) := myCall;                                                                                                          
			myCall := null;                                                                                                                  
		end loop;                                                                                                                         
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			myRetCode := 2;                                                                                                                  
			myRetMesg := mySect || ' ' || SQLERRM;                                                                                           
	end COMPLETE_RMA;                                                                                                                  
                                                                                                                                    
	/******************************************************************                                                                
**************************************                                                                                              
	 This process is called from a Concurrent Request to release RMA                                                                   
S that have Pending Hold.                                                                                                           
	 **************************************************                                                                                
****************************************************                                                                                
**/                                                                                                                                 
	procedure RMA_RELEASE_PROC	( myRetCode		out	number                                                                                 
										 ,myRetMesg		out	varchar2                                                                                                 
										 ) is                                                                                                                     
                                                                                                                                    
                                                                                                                                    
		myRCode			number;                                                                                                                 
		myRMesg			varchar2(200);                                                                                                          
		myRMAList		XXDEX_PROCESS_K.RMA_TBL;                                                                                               
		cursor c1 is                                                                                                                      
			select rh.CALL                                                                                                                   
					,rh.PLANT_ID                                                                                                                   
					,rh.RETURN_PLANT_ID                                                                                                            
					,decode(nvl(dxp.PLANT_CODE,'I'),'A','N','Y') HOLD_CHECK                                                                        
			from   DEX_PLANTS dxp                                                                                                            
					,DEX_RMAHDR rh                                                                                                                 
			where  rh.PLANT_ID = dxp.PLANT_ID                                                                                                
			and    rh.HOLD_ID is not null                                                                                                    
			and    rh.STATUS = 'P';                                                                                                          
	begin                                                                                                                              
		for r1 in c1 loop                                                                                                                 
			mySect := 'Release Hold - Complete RMA';                                                                                         
			XXDEX_PROCESS_K.COMPLETE_RMA ( myRetCode 		=> myRC                                                                               
ode                                                                                                                                 
 									   			,myRetMesg 		=> myRMesg                                                                                             
 									   			,myRMAList		=> myRMAList                                                                                            
 									   			,myRMA			=> r1.CALL                                                                                                 
 									   			,myRtnPlantID	=> r1.RETURN_PLANT_ID                                                                                 
 									   			,myHoldChecks  => r1.HOLD_CHECK                                                                                     
													);                                                                                                                     
			if myRCode != 0 then                                                                                                             
				rollback;                                                                                                                       
			else                                                                                                                             
				commit;                                                                                                                         
			end if;                                                                                                                          
		end loop;                                                                                                                         
		myRetCode := 0;                                                                                                                   
		mySect := 'Release - Orders';                                                                                                     
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			myRetCode := 2;                                                                                                                  
			myRetMesg := 'Sect: ' || mySect || ' Other Error: ' || SQLERRM;                                                                  
	end RMA_RELEASE_PROC;                                                                                                              
end XXDEX_PROCESS_K;                                                                                                                
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

