undefine sid

column machine format a10
column sid format 9999
column username format a15
column osuser format a15
set linesize 80 

select v.sid, v.serial#, v.username,  v.osuser, v.process,v.machine
, p.pid, p.spid, p.username, v.status, to_char(logon_time, 'MM/DD/ HH24:MIpm') logon_time, last_call_et/60
from v$session v, v$process p
where v.paddr = p.addr
and v.sid = &&sid
order by logon_time
/
