set lines 200
col machine format a7
col event format a30
select sid,serial#,username,machine,sql_hash_value,event,round((sysdate-logon_time)*24*60*60,0) "Sec" from v$session where username='XXCTS_WWQ_U' and status='ACTIVE' and sql_hash_value=3946046654;
