                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."K_DEX_RECV_EXPRESS" as                                                                          
/* $Header: K_DEX_RECV_EXPRESS.sql 2.1.10.0 2010/08/22 12:00:00 dexsys                                                              
 ship $ Copyright (c) 2008 DEX Systems, Inc. */                                                                                     
                                                                                                                                    
   type TRK_TBL is table of varchar2(30) index by binar                                                                             
y_integer;                                                                                                                          
   TRACK_TABLE    TRK_TBL;                                                                                                          
                                                                                                                                    
   type DESC_FLEX_REC_TYPE is record (                                                                                              
      ATTRIBUTE1        DEX_ORDERS.ATTRIBUTE1%type                                                                                  
     ,ATTRIBUTE2        DEX_ORDERS.ATTRIBUTE2%type                                                                                  
     ,ATTRIBUTE3        DEX_ORDERS.ATTRIBUTE3%type                                                                                  
     ,ATTRIBUTE4        DEX_ORDERS.ATTRIBUTE4%type                                                                                  
     ,ATTRIBUTE5        DEX_ORDERS.ATTRIBUTE5%type                                                                                  
     ,ATTRIBUTE6        DEX_ORDERS.ATTRIBUTE6%type                                                                                  
     ,ATTRIBUTE7        DEX_ORDERS.ATTRIBUTE7%type                                                                                  
     ,ATTRIBUTE8        DEX_ORDERS.ATTRIBUTE8%type                                                                                  
     ,ATTRIBUTE9        DEX_ORDERS.ATTRIBUTE9%type                                                                                  
     ,ATTRIBUTE10       DEX_ORDERS.ATTRIBUTE10%type                                                                                 
     ,ATTRIBUTE11       DEX_ORDERS.ATTRIBUTE11%type                                                                                 
     ,ATTRIBUTE12       DEX_ORDERS.ATTRIBUTE12%type                                                                                 
     ,ATTRIBUTE13       DEX_ORDERS.ATTRIBUTE13%type                                                                                 
     ,ATTRIBUTE14       DEX_ORDERS.ATTRIBUTE14%type                                                                                 
     ,ATTRIBUTE15       DEX_ORDERS.ATTRIBUTE15%type                                                                                 
     ,ATTRIBUTE16       DEX_ORDERS.ATTRIBUTE16%type                                                                                 
     ,ATTRIBUTE17       DEX_ORDERS.ATTRIBUTE17%type                                                                                 
     ,ATTRIBUTE18       DEX_ORDERS.ATTRIBUTE18%type                                                                                 
     ,ATTRIBUTE19       DEX_ORDERS.ATTRIBUTE19%type                                                                                 
     ,ATTRIBUTE20       DEX_ORDERS.ATTRIBUTE20%type                                                                                 
     ,ATTRIBUTE21       DEX_ORDERS.ATTRIBUTE21%type                                                                                 
     ,ATTRIBUTE22       DEX_ORDERS.ATTRIBUTE22%type                                                                                 
     ,ATTRIBUTE23       DEX_ORDERS.ATTRIBUTE23%type                                                                                 
     ,ATTRIBUTE24       DEX_ORDERS.ATTRIBUTE24%type                                                                                 
     ,ATTRIBUTE25       DEX_ORDERS.ATTRIBUTE25%type                                                                                 
     ,ATTRIBUTE26       DEX_ORDERS.ATTRIBUTE26%type                                                                                 
     ,ATTRIBUTE27       DEX_ORDERS.ATTRIBUTE27%type                                                                                 
     ,ATTRIBUTE28       DEX_ORDERS.ATTRIBUTE28%type                                                                                 
     ,ATTRIBUTE29       DEX_ORDERS.ATTRIBUTE29%type                                                                                 
     ,ATTRIBUTE30       DEX_ORDERS.ATTRIBUTE30%type                                                                                 
     ,ATTRIBUTE31       DEX_ORDERS.ATTRIBUTE31%type                                                                                 
     ,ATTRIBUTE32       DEX_ORDERS.ATTRIBUTE32%type                                                                                 
     ,ATTRIBUTE33       DEX_ORDERS.ATTRIBUTE33%type                                                                                 
     ,ATTRIBUTE34       DEX_ORDERS.ATTRIBUTE34%type                                                                                 
     ,ATTRIBUTE35       DEX_ORDERS.ATTRIBUTE35%type                                                                                 
     ,ATTRIBUTE36       DEX_ORDERS.ATTRIBUTE36%type                                                                                 
     ,ATTRIBUTE37       DEX_ORDERS.ATTRIBUTE37%type                                                                                 
     ,ATTRIBUTE38       DEX_ORDERS.ATTRIBUTE38%type                                                                                 
     ,ATTRIBUTE39       DEX_ORDERS.ATTRIBUTE39%type                                                                                 
     ,ATTRIBUTE40       DEX_ORDERS.ATTRIBUTE40%type                                                                                 
   );                                                                                                                               
                                                                                                                                    
   type CREDIT_CARD_REC_TYPE is record (                                                                                            
      CREDIT_CARD_TYPE			DEX_ORDERS.CREDIT_CARD_TYPE%type                                                                           
     ,CREDIT_CARD_NAME			DEX_ORDERS.CREDIT_CARD_TYPE%type                                                                           
     ,CREDIT_CARD_ACCT			DEX_ORDERS.CREDIT_CARD_TYPE%                                                                               
type                                                                                                                                
     ,CREDIT_CARD_EXP			DEX_ORDERS.CREDIT_CARD_TYPE%type                                                                            
     ,CREDIT_CARD_METHOD      DEX_ORDERS.CREDIT_CARD_METHOD%type                                                                    
     ,CREDIT_CARD_APPROVAL    DEX_ORDERS.CREDIT_CARD_AP                                                                             
PROVAL%type                                                                                                                         
   );                                                                                                                               
                                                                                                                                    
   type CURRENCY_REC_TYPE is record (                                                                                               
      CURRENCY_CODE           DEX_ORDERS.CURRENCY_CODE%type                                                                         
     ,EXCHANGE_RATE_TYPE      DEX_ORDERS.EXCHANGE_RATE_TYPE%type                                                                    
     ,EXCHANGE_RATE_DATE		DEX_ORDERS.EXCHANGE_RATE_D                                                                                
ATE%type                                                                                                                            
     ,EXCHANGE_RATE			   DEX_ORDERS.EXCHANGE_RATE%type                                                                              
   );                                                                                                                               
                                                                                                                                    
   procedure TRACK (                                                                                                                
                     myRetMesg        out  varchar2                                                                                 
                    ,myRetCode        out  number                                                                                   
                    ,myOrder       in out  varchar2                                                                                 
                    ,mySerialID    in out  varchar2                                                                                 
                    ,myEmpNo       in      varchar2                                                                                 
                    ,myCust        in      varchar2                                                                                 
                    ,myCustName    in      varchar2                                                                                 
                    ,myCustID      in      number                                                                                   
                    ,myBillID      in      number                                                                                   
                    ,myShipID      in      number                                                                                   
                    ,myParent      in      varchar2                                                                                 
                    ,myWaybill     in      varchar2                                                                                 
                    ,myCustPO      in      varchar2                                                                                 
                    ,myPRelease    in      varchar2                                                                                 
                    ,myPlantID     in      number                                                                                   
                    ,myOrgID       in      number                                                                                   
                    ,myPlant       in      varchar2                                                                                 
                    ,myCPart       in      varchar2                                                                                 
                    ,myCItemID     in      number                                                                                   
                    ,myPart        in      varchar2                                                                                 
                    ,myItemID      in      number                                                                                   
                    ,myIOrgID      in      number                                                                                   
                    ,myRPlantID    in      number                                                                                   
                    ,myTrack       in      varchar2                                                                                 
                    ,myUserID      in      number                                                                                   
                    ,myTypeCode    in      varchar2 default                                                                         
null                                                                                                                                
                    ,myHoldCode    in      varchar2 default null                                                                    
                    ,myTag         in      varchar2 default                                                                         
null                                                                                                                                
                    ,myPBNum       in      varchar2 default null                                                                    
                    ,myPBItem      in      number   default                                                                         
null                                                                                                                                
                    ,myDirect      in      varchar2 default 'N'                                                                     
                    ,myXDockLocn   in      varchar2 default n                                                                       
ull                                                                                                                                 
                    ,myPalletID    in      number   default null                                                                    
                    ,myPayOption   in      varchar2 default n                                                                       
ull                                                                                                                                 
                    ,myBOMTranID   in      number   default null                                                                    
                    ,myRtnStatCd   in      varchar2 default n                                                                       
ull                                                                                                                                 
                    ,myLotQty      in      number   default null                                                                    
                    ,myLotCntInd   in      varchar2 default n                                                                       
ull                                                                                                                                 
                    ,myOChrgLmt    in      number   default null                                                                    
                    ,myRMAPrice    in      number   default n                                                                       
ull                                                                                                                                 
                    ,myOrdAttrCat  in      varchar2 default null                                                                    
                    ,myOrdFlex     in      DESC_FLEX_REC_TYPE                                                                       
 default null                                                                                                                       
                    ,myLneAttrCat  in      varchar2 default null                                                                    
                                                                                                                                    
                    ,myLneFlex     in      DESC_FLEX_REC_TYPE default null                                                          
                    ,mySrlAttrCat  in      varchar2 de                                                                              
fault null                                                                                                                          
                    ,mySrlFlex     in      DESC_FLEX_REC_TYPE defau                                                                 
lt null                                                                                                                             
                   );                                                                                                               
                                                                                                                                    
   procedure BULK_CHCK (                                                                                                            
                         myRetMesg  out varchar2                                                                                    
                        ,myRetCode  out number                                                                                      
                        ,myNum      out number                                                                                      
                        ,myPlantID  in  number                                                                                      
                        ,myLPlateID in  number default null                                                                         
                        ,myShipID   in  number default nul                                                                          
l                                                                                                                                   
                        ,myPalletID in  number default null                                                                         
                       );                                                                                                           
                                                                                                                                    
   procedure BULK_PROC (                                                                                                            
                         myRetMesg  out varchar2                                                                                    
                        ,myRetCode  out number                                                                                      
                        ,myPlantID  in  number                                                                                      
                        ,myUserID   in  number                                                                                      
                        ,myEmpNo    in  varchar2                                                                                    
                        ,myWaybill  in  varchar2                                                                                    
                        ,myLPlateID in  number default null                                                                         
                        ,myShipID   in  number default nul                                                                          
l                                                                                                                                   
                        ,myPalletID in  number default null                                                                         
                       );                                                                                                           
                                                                                                                                    
   procedure LOG_SET;                                                                                                               
   procedure LOG_UNSET;                                                                                                             
                                                                                                                                    
   procedure ERROR_ROLLBACK;                                                                                                        
                                                                                                                                    
   procedure TABLE_INIT;                                                                                                            
   procedure TABLE_LOAD ( myTrack varchar2 );                                                                                       
                                                                                                                                    
   function  TABLE_COUNT return binary_integer;                                                                                     
   function  TABLE_DATA ( myIdx binary_integer ) ret                                                                                
urn varchar2;                                                                                                                       
end K_DEX_RECV_EXPRESS;                                                                                                             
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."K_DEX_RECV_EXPRESS" as                                                                       
/* $Header: K_DEX_RECV_EXPRESS.sql 2.1.10.0 2010/08/22                                                                              
12:00:00 dexsys ship $ Copyright (c) 2008 DEX System                                                                                
s, Inc. */                                                                                                                          
                                                                                                                                    
   mySect   varchar2(100);                                                                                                          
                                                                                                                                    
   myLog    varchar2(1) := 'N';                                                                                                     
                                                                                                                                    
  /******************************************************                                                                           
****************************                                                                                                        
   ************************************  Private **************************                                                         
**********                                                                                                                          
   ****************************************************************                                                                 
******************/                                                                                                                 
                                                                                                                                    
   function TRAN_FEE ( myCustID number,myOrgID number ) r                                                                           
eturn varchar2 is                                                                                                                   
   begin                                                                                                                            
      return ( F_DEX_CUST_CTRL ( myCustID,'TFB',myOrgID ) );                                                                        
   end TRAN_FEE;                                                                                                                    
                                                                                                                                    
   /************************************************************************                                                        
**********/                                                                                                                         
                                                                                                                                    
	procedure UPDT_ORDER_FLEX ( myRMA varchar2, myOrder varchar2 ) i                                                                   
s                                                                                                                                   
      cursor c1 is                                                                                                                  
      	select ATTRIBUTE_CATEGORY                                                                                                    
      	      ,ATTRIBUTE1                                                                                                            
      	      ,ATTRIBUTE2                                                                                                            
      	      ,ATTRIBUTE3                                                                                                            
      	      ,ATTRIBUTE4                                                                                                            
      	      ,ATTRIBUTE5                                                                                                            
      	      ,ATTRIBUTE6                                                                                                            
      	      ,ATTRIBUTE7                                                                                                            
      	      ,ATTRIBUTE8                                                                                                            
      	      ,ATTRIBUTE9                                                                                                            
      	      ,ATTRIBUTE10                                                                                                           
      	      ,ATTRIBUTE11                                                                                                           
      	      ,ATTRIBUTE12                                                                                                           
      	      ,ATTRIBUTE13                                                                                                           
      	      ,ATTRIBUTE14                                                                                                           
      	      ,ATTRIBUTE15                                                                                                           
      	      ,ATTRIBUTE16                                                                                                           
      	      ,ATTRIBUTE17                                                                                                           
      	      ,ATTRIBUTE18                                                                                                           
      	      ,ATTRIBUTE19                                                                                                           
      	      ,ATTRIBUTE20                                                                                                           
      	      ,ATTRIBUTE21                                                                                                           
      	      ,ATTRIBUTE22                                                                                                           
      	      ,ATTRIBUTE23                                                                                                           
      	      ,ATTRIBUTE24                                                                                                           
      	      ,ATTRIBUTE25                                                                                                           
      	      ,ATTRIBUTE26                                                                                                           
      	      ,ATTRIBUTE27                                                                                                           
      	      ,ATTRIBUTE28                                                                                                           
      	      ,ATTRIBUTE29                                                                                                           
      	      ,ATTRIBUTE30                                                                                                           
      	      ,ATTRIBUTE31                                                                                                           
      	      ,ATTRIBUTE32                                                                                                           
      	      ,ATTRIBUTE33                                                                                                           
      	      ,ATTRIBUTE34                                                                                                           
      	      ,ATTRIBUTE35                                                                                                           
      	      ,ATTRIBUTE36                                                                                                           
      	      ,ATTRIBUTE37                                                                                                           
      	      ,ATTRIBUTE38                                                                                                           
      	      ,ATTRIBUTE39                                                                                                           
      	      ,ATTRIBUTE40                                                                                                           
      	from   DEX_RMAHDR                                                                                                            
      	where  CALL = myRMA;                                                                                                         
	begin                                                                                                                              
		for r1 in c1 loop                                                                                                                 
			update DEX_ORDERS set                                                                                                            
			ATTRIBUTE_CATEGORY = r1.ATTRIBUTE_CATEGORY                                                                                       
		  ,ATTRIBUTE1  = r1.ATTRIBUTE1                                                                                                    
		  ,ATTRIBUTE2  = r1.ATTRIBUTE2                                                                                                    
		  ,ATTRIBUTE3  = r1.ATTRIBUTE3                                                                                                    
		  ,ATTRIBUTE4  = r1.ATTRIBUTE4                                                                                                    
		  ,ATTRIBUTE5  = r1.ATTRIBUTE5                                                                                                    
		  ,ATTRIBUTE6  = r1.ATTRIBUTE6                                                                                                    
		  ,ATTRIBUTE7  = r1.ATTRIBUTE7                                                                                                    
		  ,ATTRIBUTE8  = r1.ATTRIBUTE8                                                                                                    
		  ,ATTRIBUTE9  = r1.ATTRIBUTE9                                                                                                    
		  ,ATTRIBUTE10 = r1.ATTRIBUTE10                                                                                                   
		  ,ATTRIBUTE11 = r1.ATTRIBUTE11                                                                                                   
		  ,ATTRIBUTE12 = r1.ATTRIBUTE12                                                                                                   
		  ,ATTRIBUTE13 = r1.ATTRIBUTE13                                                                                                   
		  ,ATTRIBUTE14 = r1.ATTRIBUTE14                                                                                                   
		  ,ATTRIBUTE15 = r1.ATTRIBUTE15                                                                                                   
		  ,ATTRIBUTE16 = r1.ATTRIBUTE16                                                                                                   
		  ,ATTRIBUTE17 = r1.ATTRIBUTE17                                                                                                   
		  ,ATTRIBUTE18 = r1.ATTRIBUTE18                                                                                                   
		  ,ATTRIBUTE19 = r1.ATTRIBUTE19                                                                                                   
		  ,ATTRIBUTE20 = r1.ATTRIBUTE20                                                                                                   
		  ,ATTRIBUTE21 = r1.ATTRIBUTE21                                                                                                   
		  ,ATTRIBUTE22 = r1.ATTRIBUTE22                                                                                                   
		  ,ATTRIBUTE23 = r1.ATTRIBUTE23                                                                                                   
		  ,ATTRIBUTE24 = r1.ATTRIBUTE24                                                                                                   
		  ,ATTRIBUTE25 = r1.ATTRIBUTE25                                                                                                   
		  ,ATTRIBUTE26 = r1.ATTRIBUTE26                                                                                                   
		  ,ATTRIBUTE27 = r1.ATTRIBUTE27                                                                                                   
		  ,ATTRIBUTE28 = r1.ATTRIBUTE28                                                                                                   
		  ,ATTRIBUTE29 = r1.ATTRIBUTE29                                                                                                   
		  ,ATTRIBUTE30 = r1.ATTRIBUTE30                                                                                                   
		  ,ATTRIBUTE31 = r1.ATTRIBUTE31                                                                                                   
		  ,ATTRIBUTE32 = r1.ATTRIBUTE32                                                                                                   
		  ,ATTRIBUTE33 = r1.ATTRIBUTE33                                                                                                   
		  ,ATTRIBUTE34 = r1.ATTRIBUTE34                                                                                                   
		  ,ATTRIBUTE35 = r1.ATTRIBUTE35                                                                                                   
		  ,ATTRIBUTE36 = r1.ATTRIBUTE36                                                                                                   
		  ,ATTRIBUTE37 = r1.ATTRIBUTE37                                                                                                   
		  ,ATTRIBUTE38 = r1.ATTRIBUTE38                                                                                                   
		  ,ATTRIBUTE39 = r1.ATTRIBUTE39                                                                                                   
		  ,ATTRIBUTE40 = r1.ATTRIBUTE40                                                                                                   
		   where ORDERNO = myOrder;                                                                                                       
		end loop;                                                                                                                         
	end UPDT_ORDER_FLEX;                                                                                                               
                                                                                                                                    
   /************************************************                                                                                
**********************************/                                                                                                 
                                                                                                                                    
   procedure BOOKING_POST_PROCESS ( myOrder varchar2,myCustID numbe                                                                 
r,myOrgID number ) is                                                                                                               
      myProgName    FND_CONCURRENT_PROGRAMS.CONCURRENT_P                                                                            
ROGRAM_NAME%type;                                                                                                                   
      myPrinter     FND_CONCURRENT_PROGRAMS.PRINTER_NAME%typ                                                                        
e;                                                                                                                                  
                                                                                                                                    
      myAppName     varchar2(20);                                                                                                   
                                                                                                                                    
      myCopies      number;                                                                                                         
                                                                                                                                    
      myParentCode  varchar2(20);                                                                                                   
      myRetMesg     varchar2(2000);                                                                                                 
                                                                                                                                    
      myRequestID   pls_integer;                                                                                                    
                                                                                                                                    
   begin                                                                                                                            
      select fna.APPLICATION_SHORT_NAME                                                                                             
            ,fcp.CONCURRENT_PROGRAM_NAME                                                                                            
            ,dcx.PRINTER_NAME                                                                                                       
            ,dcx.COPIES                                                                                                             
      into   myAppName                                                                                                              
            ,myProgName                                                                                                             
            ,myPrinter                                                                                                              
            ,myCopies                                                                                                               
      from   DEX_CUSTOMER_DATA dcd                                                                                                  
            ,DEX_CUSTOMER_DOCUMENTS dcx                                                                                             
            ,FND_CONCURRENT_PROGRAMS_VL fcp                                                                                         
            ,FND_APPLICATION fna                                                                                                    
      where  dcd.CUSTOMER_ID     = myCustID                                                                                         
      and    dcd.ORG_ID          = myOrgID                                                                                          
      and    dcd.CUSTOMER_ID     = dcx.CUSTOMER_ID                                                                                  
      and    dcx.DATA_TYPE       = 'BOK'                                                                                            
      and    dcx.LABEL_REPORT_ID = fcp.CONCURRENT_PROGRAM_ID                                                                        
      and    fcp.APPLICATION_ID  = fna.APPLICATION_ID                                                                               
      and    rownum              < 2;                                                                                               
                                                                                                                                    
      myRetMesg := K_DEX_CONC_REQUEST.SUBMIT (                                                                                      
                                               myRequestID                                                                          
                                              ,myAppName                                                                            
                                              ,myProgName                                                                           
                                              ,null                                                                                 
                                              ,myPrinte                                                                             
r                                                                                                                                   
                                              ,myCopies                 -- C                                                        
opies                                                                                                                               
                                              ,myOrder                                                                              
-- Parameter 1   (OrderNo)                                                                                                          
                                              ,chr(0)                                                                               
                                             );                                                                                     
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         null;                                                                                                                      
   end BOOKING_POST_PROCESS;                                                                                                        
                                                                                                                                    
   /************************************************************************                                                        
**********/                                                                                                                         
                                                                                                                                    
   procedure LOG ( myData varchar2 default null ) is                                                                                
   begin                                                                                                                            
      if myLog = 'Y' then                                                                                                           
         K_DEX_LOG.LOG ( mySect,myData,'K_DEX_RECV_EXPR                                                                             
ESS' );                                                                                                                             
      end if;                                                                                                                       
   end LOG;                                                                                                                         
                                                                                                                                    
  /******************************************************************                                                               
****************                                                                                                                    
   ************************************  Public  ************                                                                       
************************                                                                                                            
   **************************************************                                                                               
********************************/                                                                                                   
                                                                                                                                    
   procedure TRACK (                                                                                                                
                     myRetMesg        out  varchar2                                                                                 
                    ,myRetCode        out  number                                                                                   
                    ,myOrder       in out  varchar2                                                                                 
                    ,mySerialID    in out  varchar2                                                                                 
                    ,myEmpNo       in      varchar2                                                                                 
                    ,myCust        in      varchar2                                                                                 
                    ,myCustName    in      varchar2                                                                                 
                    ,myCustID      in      number                                                                                   
                    ,myBillID      in      number                                                                                   
                    ,myShipID      in      number                                                                                   
                    ,myParent      in      varchar2                                                                                 
                    ,myWaybill     in      varchar2                                                                                 
                    ,myCustPO      in      varchar2                                                                                 
                    ,myPRelease    in      varchar2                                                                                 
                    ,myPlantID     in      number                                                                                   
                    ,myOrgID       in      number                                                                                   
                    ,myPlant       in      varchar2                                                                                 
                    ,myCPart       in      varchar2                                                                                 
                    ,myCItemID     in      number                                                                                   
                    ,myPart        in      varchar2                                                                                 
                    ,myItemID      in      number                                                                                   
                    ,myIOrgID      in      number                                                                                   
                    ,myRPlantID    in      number                                                                                   
                    ,myTrack       in      varchar2                                                                                 
                    ,myUserID      in      number                                                                                   
                    ,myTypeCode    in      varchar2 default null                                                                    
                    ,myHoldCode    in      varchar2 defau                                                                           
lt null                                                                                                                             
                    ,myTag         in      varchar2 default null                                                                    
                    ,myPBNum       in      varchar2 defau                                                                           
lt null                                                                                                                             
                    ,myPBItem      in      number   default null                                                                    
                    ,myDirect      in      varchar2 defau                                                                           
lt 'N'                                                                                                                              
                    ,myXDockLocn   in      varchar2 default null                                                                    
                    ,myPalletID    in      number   defaul                                                                          
t null                                                                                                                              
                    ,myPayOption   in      varchar2 default null                                                                    
                    ,myBOMTranID   in      number   defaul                                                                          
t null                                                                                                                              
                    ,myRtnStatCd   in      varchar2 default null                                                                    
                    ,myLotQty      in      number   defaul                                                                          
t null                                                                                                                              
                    ,myLotCntInd   in      varchar2 default null                                                                    
                    ,myOChrgLmt    in      number   defaul                                                                          
t null                                                                                                                              
                    ,myRMAPrice    in      number   default null                                                                    
                    ,myOrdAttrCat  in      varchar2 defaul                                                                          
t null                                                                                                                              
                    ,myOrdFlex     in      DESC_FLEX_REC_TYPE default n                                                             
ull                                                                                                                                 
                    ,myLneAttrCat  in      varchar2 default null                                                                    
                    ,myLneFlex     in      DESC_FLEX_REC_TYPE                                                                       
 default null                                                                                                                       
                    ,mySrlAttrCat  in      varchar2 default null                                                                    
                                                                                                                                    
                    ,mySrlFlex     in      DESC_FLEX_REC_TYPE default null                                                          
                   ) is                                                                                                             
      myNewOrd       varchar2(1) := 'N';                                                                                            
      myNewLne       varchar2(1) := 'N';                                                                                            
      myStatCode     varchar2(1) := 'N';                                                                                            
      myLineType     varchar2(1) := 'S';                                                                                            
      myWarrTrack    varchar2(1);                                                                                                   
      myPutaway      varchar2(1);                                                                                                   
      myWarrAudit    varchar2(1);                                                                                                   
      myTranFee      varchar2(1);                                                                                                   
      myB2B          varchar2(1);                                                                                                   
      myFinalClose   varchar2(1);                                                                                                   
      myLocn         varchar2(3);                                                                                                   
      myDmgCode      varchar2(3);                                                                                                   
      myDmgScrap     varchar2(1);                                                                                                   
      myDmgFin       varchar2(1);                                                                                                   
      myRouteFin     varchar2(1);                                                                                                   
      myClass        varchar2(1);                                                                                                   
      myRecvXprs     varchar2(1)  := F_DEX_CUST_CTRL ( m                                                                            
yCustID,'REX',myOrgID,'T' );                                                                                                        
      myTTypeCode    varchar2(2)  := myTypeCode;                                                                                    
      myStsNum       varchar2(10);                                                                                                  
      myTOrder       varchar2(10);                                                                                                  
      myStorage      varchar2(10);                                                                                                  
      myWarr         varchar2(20);                                                                                                  
      myTTag         varchar2(30) := myTag;                                                                                         
      myRelease      varchar2(60);                                                                                                  
                                                                                                                                    
      myItem         pls_integer := 1;                                                                                              
      myUnique       pls_integer := 1;                                                                                              
      myPBUnique     pls_integer;                                                                                                   
      myWarrDays     pls_integer;                                                                                                   
      myLead         pls_integer;                                                                                                   
                                                                                                                                    
      myWarrID       number(15);                                                                                                    
      myGrpID        number(15);                                                                                                    
      myTranID       number(15);                                                                                                    
      myNItemID      number(15) := myItemID;                                                                                        
      myNCItemID     number(15);                                                                                                    
      myWarrDetID    number(15);                                                                                                    
                                                                                                                                    
      myCPrice       number(10,2);                                                                                                  
                                                                                                                                    
      mySchd         date;                                                                                                          
                                                                                                                                    
      myNbrTimes     number;                                                                                                        
                                                                                                                                    
      myChrgLimit    number;                                                                                                        
      myFeeOverride  number := null;                                                                                                
      myShipFee      number;                                                                                                        
                                                                                                                                    
      myUser         varchar2(30);                                                                                                  
      myProgName     varchar2(40);                                                                                                  
      myUserName     varchar2(100);                                                                                                 
                                                                                                                                    
      myStatus       varchar2(1);                                                                                                   
                                                                                                                                    
      myBERFlag      varchar2(1);                                                                                                   
      myHonoredBy    varchar2(10);                                                                                                  
                                                                                                                                    
      myPriceCode    varchar2(30);                                                                                                  
                                                                                                                                    
		myOrdType		DEX_ORDERS.ORDTYPE%type := 'R';                                                                                        
                                                                                                                                    
      myWarranty     DEX_SERIALS.WARRANTY%type := null;                                                                             
      myRouteCode    DEX_SERIALS.ROUTE_CODE%type := null;                                                                           
      myRtnRouteCode DEX_SERIALS.ROUTE_CODE%type := null;                                                                           
      mySerial       DEX_SERIALS.SERIAL%type := myTrack;                                                                            
                                                                                                                                    
      myShipName     DEX_RMAHDR.SHIP_NAME%type;                                                                                     
      myShipAttn     DEX_RMAHDR.SHIP_ATTN%type;                                                                                     
      myShipSt1      DEX_RMAHDR.SHIP_ST1%type;                                                                                      
      myShipSt2      DEX_RMAHDR.SHIP_ST2%type;                                                                                      
      myShipCity     DEX_RMAHDR.SHIP_CITY%type;                                                                                     
      myShipState    DEX_RMAHDR.SHIP_STATE%type;                                                                                    
      myShipZip      DEX_RMAHDR.SHIP_ZIP%type;                                                                                      
      myCountry      DEX_RMAHDR.COUNTRY%type;                                                                                       
      myCmt          DEX_RMAHDR.COMMENTS%type;                                                                                      
      myNotify       DEX_RMAHDR.NOTIFY%type;                                                                                        
      myEMail        DEX_RMAHDR.NOTIFY_EMAIL%type;                                                                                  
      myRMAPartial 	DEX_RMAHDR.PARTIAL_SHP%type;                                                                                    
		myCustExch		DEX_RMAHDR.CUST_EXCHANGE%type;                                                                                        
                                                                                                                                    
      myRMA          DEX_ORDERS.RMA%type;                                                                                           
      myOrdSrc       DEX_ORDERS.ORDER_SOURCE%type;                                                                                  
      myRShipVia     DEX_ORDERS.SHIP_VIA%type;                                                                                      
      mySShipVia     DEX_ORDERS.SHIP_VIA%type;                                                                                      
                                                                                                                                    
      myNPart        DEX_LINES.PART%type;                                                                                           
      myNCPart       DEX_LINES.CUSTPART%type;                                                                                       
      myDesc         DEX_LINES.DESCRIPTION%type;                                                                                    
      myOEM          DEX_LINES.MFG%type;                                                                                            
      myPrice        DEX_LINES.PRICE%type;                                                                                          
      myGrp          DEX_LINES.GRP%type;                                                                                            
      myQtyOrg       DEX_LINES.QTYORG%type := 1;                                                                                    
      myUOM          DEX_LINES.UOM%type := XXDEX_UOM_                                                                               
DEFAULT_F;                                                                                                                          
      myTGrp         DEX_LINES.GRP%type;                                                                                            
      myTGrpID       DEX_LINES.GROUP_ID%type;                                                                                       
                                                                                                                                    
      myTranCode     DEX_PLANTS.TRANSFER_CODE%type;                                                                                 
      myPCountry     DEX_PLANTS.COUNTRY%type;                                                                                       
                                                                                                                                    
      mySchdFlag     DEX_CUSTOMER_DATA.SCHEDULE_FLAG%type;                                                                          
      myInvMgmt      DEX_CUSTOMER_DATA.ADVREP_FLAG%type                                                                             
;                                                                                                                                   
      myProgCode     DEX_CUSTOMER_DATA.PROGRAM_CODE%type;                                                                           
      myRelabel      DEX_CUSTOMER_DATA.RELABEL_FLAG%type;                                                                           
      myZeroPrice    DEX_CUSTOMER_DATA.ZERO_PRICE_ALLOWED_FLAG%t                                                                    
ype;                                                                                                                                
                                                                                                                                    
      mySPartial     XXDEX_CUSTOMERS_ALL_V.SHIP_PARTIAL%type;                                                                       
      myOSalesRep    XXDEX_CUSTOMERS_ALL_V.OUTSIDE_SALESREP_NU                                                                      
MBER%type;                                                                                                                          
      myISalesRep    XXDEX_CUSTOMERS_ALL_V.INSIDE_SALESREP_NUMBER%t                                                                 
ype;                                                                                                                                
      myRegion       XXDEX_CUSTOMERS_ALL_V.REGION%type;                                                                             
                                                                                                                                    
      myRepair       DEX_FAIL_CODES.FAIL_CODE%type;                                                                                 
      myWarrInd      DEX_WARRANTY_DETAIL.WARR_ACCT_IND%type;                                                                        
                                                                                                                                    
      myMPRPrice     varchar2(1) := nvl(XXDEX_DEFAULTS_F (                                                                          
 'MULTI_PLANT_PRICE_REPAIR' ),'N');                                                                                                 
      myIBUpdate	   varchar2(1) := XXDEX_DEFAULTS_F('INSTALLBASE_UPD                                                                
ATE');                                                                                                                              
                                                                                                                                    
      myCurrInfo     CURRENCY_REC_TYPE;                                                                                             
      myCardInfo     CREDIT_CARD_REC_TYPE;                                                                                          
                                                                                                                                    
      mySubj         varchar2(100);                                                                                                 
      myMesg         varchar2(4000);                                                                                                
                                                                                                                                    
      ABORT_PROC     exception;                                                                                                     
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
		--	savepoint TRACK_SAVEPOINT;   rollbacks handled by                                                                              
calling program                                                                                                                     
                                                                                                                                    
      mySect := 'Plant - Start';                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Plant';                                                                                                    
                                                                                                                                    
      select TRANSFER_CODE                                                                                                          
            ,COUNTRY                                                                                                                
      into   myTranCode                                                                                                             
            ,myPCountry                                                                                                             
      from   DEX_PLANTS                                                                                                             
      where  PLANT_ID = myPlantID;                                                                                                  
                                                                                                                                    
     log;                                                                                                                           
      mySect := 'Track - Cust Data';                                                                                                
                                                                                                                                    
		begin                                                                                                                             
      	select nvl(SCHEDULE_FLAG,'N')                                                                                                
      	      ,nvl(ADVREP_FLAG,'N')                                                                                                  
      	      ,nvl(PROGRAM_CODE,'RP')                                                                                                
      	      ,nvl(RELABEL_FLAG,'N')                                                                                                 
      	      ,nvl(ZERO_PRICE_ALLOWED_FLAG,'N')                                                                                      
      	      ,nvl(TRACK_WARR_FLAG,'N')                                                                                              
            	,WARRANTY_REPAIR                                                                                                       
      	into   mySchdFlag                                                                                                            
      	      ,myInvMgmt                                                                                                             
      	      ,myProgCode                                                                                                            
      	      ,myRelabel                                                                                                             
      	      ,myZeroPrice                                                                                                           
      	      ,myWarrTrack                                                                                                           
            	,myWarrDays                                                                                                            
      	from   DEX_CUSTOMER_DATA                                                                                                     
      	where  CUSTOMER_ID = myCustID                                                                                                
      	and    ORG_ID      = myOrgID;                                                                                                
                                                                                                                                    
      exception                                                                                                                     
      	when NO_DATA_FOUND then                                                                                                      
	      	mySect := 'Track - Cust Data (Template)';                                                                                   
      		select nvl(SCHEDULE_FLAG,'N')                                                                                               
      		      ,nvl(ADVREP_FLAG,'N')                                                                                                 
      		      ,nvl(PROGRAM_CODE,'RP')                                                                                               
      		      ,nvl(RELABEL_FLAG,'N')                                                                                                
      		      ,nvl(ZERO_PRICE_ALLOWED_FLAG,'N')                                                                                     
      		      ,nvl(TRACK_WARR_FLAG,'N')                                                                                             
            		,WARRANTY_REPAIR                                                                                                      
      		into   mySchdFlag                                                                                                           
      		      ,myInvMgmt                                                                                                            
      		      ,myProgCode                                                                                                           
      		      ,myRelabel                                                                                                            
      		      ,myZeroPrice                                                                                                          
      		      ,myWarrTrack                                                                                                          
            		,myWarrDays                                                                                                           
      		from   DEX_CUSTOMER_DATA                                                                                                    
      		where  CUSTOMER_ID = 0                                                                                                      
      		and    ORG_ID      = myOrgID                                                                                                
      		and    XXDEX_DEFAULTS_F ( 'CUST_DYNAMIC_LOAD' ) = 'Y';                                                                      
                                                                                                                                    
      end;                                                                                                                          
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Cust Bill';                                                                                                
                                                                                                                                    
      XXDEX_CUSTOMERS_K.BILL (                                                                                                      
                               myRetMesg   => myRetMesg                                                                             
                              ,myRetCode   => myRetCode                                                                             
                              ,mySPartial  => mySPartia                                                                             
l                                                                                                                                   
                              ,myOSalesRep => myOSalesRep                                                                           
                              ,myISalesRep => myISalesRep                                                                           
                              ,myRegion    => myRegion                                                                              
                              ,myBillID    => myBillID                                                                              
                              ,myCustID    => myCustID                                                                              
                              ,myOrgID     => myOrgID                                                                               
                              ,myPlantID   => myPlant                                                                               
ID                                                                                                                                  
                             );                                                                                                     
                                                                                                                                    
      if myRetCode > 0 then                                                                                                         
         raise ABORT_PROC;                                                                                                          
                                                                                                                                    
      elsif length(myOSalesRep) > 30 then                                                                                           
         myRetMesg := 'Outside Salesrep: ' || myOSalesRep || ' More than 3                                                          
0 Characters';                                                                                                                      
         raise ABORT_PROC;                                                                                                          
                                                                                                                                    
      elsif length(myISalesRep) > 30 then                                                                                           
         myRetMesg := 'Inside Salesrep: ' || myISalesRep || ' More than                                                             
 30 Characters';                                                                                                                    
         raise ABORT_PROC;                                                                                                          
                                                                                                                                    
      elsif length(myRegion) > 6 then                                                                                               
         myRetMesg := 'Region: ' || myRegion || ' More than 6 Characters'                                                           
;                                                                                                                                   
         raise ABORT_PROC;                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Cust Ship';                                                                                                
                                                                                                                                    
      XXDEX_CUSTOMERS_K.SHIP (                                                                                                      
                               myRetMesg   => myRetMesg                                                                             
                              ,myRetCode   => myRetCod                                                                              
e                                                                                                                                   
                              ,myShipVia   => mySShipVia                                                                            
                              ,myShipName  => myShipName                                                                            
                              ,myShipAddr1 => myShipSt1                                                                             
                              ,myShipAddr2 => myShipSt2                                                                             
                              ,myShipAddr3 => myShipAttn                                                                            
                              ,myShipCity  => myShipC                                                                               
ity                                                                                                                                 
                              ,myShipState => myShipState                                                                           
                              ,myShipZip   => myShipZip                                                                             
                              ,myCountry   => myCountry                                                                             
                              ,myBillID    => myBillID                                                                              
                              ,myShipID    => myShipID                                                                              
                              ,myCustID    => myCustID                                                                              
                                                                                                                                    
                              ,myOrgID     => myOrgID                                                                               
                              ,myPlantID   => myPlantID                                                                             
                             );                                                                                                     
                                                                                                                                    
      if myRetCode > 0 then                                                                                                         
         raise ABORT_PROC;                                                                                                          
                                                                                                                                    
      elsif length(mySShipVia) > 30 then                                                                                            
         myRetMesg := 'Ship Via: ' || mySShipVia || ' More than 30 Char                                                             
acters';                                                                                                                            
         raise ABORT_PROC;                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      if myPBNum is not null then                                                                                                   
         log;                                                                                                                       
         mySect := 'Track - Prebook';                                                                                               
                                                                                                                                    
         begin                                                                                                                      
            select ORDER_SOURCE                                                                                                     
                  ,PRICE_TYPE_CODE                                                                                                  
                  ,nvl(RELABEL_FLAG,'N')                                                                                            
                  ,SHIP_NAME                                                                                                        
                  ,SHIP_ATTN                                                                                                        
                  ,SHIP_ST1                                                                                                         
                  ,SHIP_ST2                                                                                                         
                  ,SHIP_CITY                                                                                                        
                  ,SHIP_STATE                                                                                                       
                  ,SHIP_ZIP                                                                                                         
                  ,COUNTRY                                                                                                          
                  ,SHIP_VIA                                                                                                         
                  ,CURRENCY_CODE                                                                                                    
                  ,EXCHANGE_RATE_TYPE                                                                                               
                  ,EXCHANGE_RATE_DATE                                                                                               
                  ,EXCHANGE_RATE                                                                                                    
                  ,CREDIT_CARD_TYPE                                                                                                 
                  ,CREDIT_CARD_NAME                                                                                                 
                  ,CREDIT_CARD_ACCT                                                                                                 
                  ,CREDIT_CARD_EXP                                                                                                  
                  ,CREDIT_CARD_METHOD                                                                                               
                  ,CREDIT_CARD_APPROVAL                                                                                             
                  ,COMMENTS                                                                                                         
                  ,NOTIFY                                                                                                           
                  ,NOTIFY_EMAIL                                                                                                     
                  ,PARTIAL_SHP                                                                                                      
                  ,ORDTYPE                                                                                                          
                  ,CUST_EXCHANGE                                                                                                    
            into   myOrdSrc                                                                                                         
                  ,myPriceCode                                                                                                      
                  ,myRelabel                                                                                                        
                  ,myShipName                                                                                                       
                  ,myShipAttn                                                                                                       
                  ,myShipSt1                                                                                                        
                  ,myShipSt2                                                                                                        
                  ,myShipCity                                                                                                       
                  ,myShipState                                                                                                      
                  ,myShipZip                                                                                                        
                  ,myCountry                                                                                                        
                  ,myRShipVia                                                                                                       
                  ,myCurrInfo.CURRENCY_CODE                                                                                         
                  ,myCurrInfo.EXCHANGE_RATE_TYPE                                                                                    
                  ,myCurrInfo.EXCHANGE_RATE_DATE                                                                                    
                  ,myCurrInfo.EXCHANGE_RATE                                                                                         
                  ,myCardInfo.CREDIT_CARD_TYPE                                                                                      
                  ,myCardInfo.CREDIT_CARD_NAME                                                                                      
                  ,myCardInfo.CREDIT_CARD_ACCT                                                                                      
                  ,myCardInfo.CREDIT_CARD_EXP                                                                                       
                  ,myCardInfo.CREDIT_CARD_METHOD                                                                                    
                  ,myCardInfo.CREDIT_CARD_APPROVAL                                                                                  
                  ,myCmt                                                                                                            
                  ,myNotify                                                                                                         
                  ,myEMail                                                                                                          
                  ,myRMAPartial                                                                                                     
                  ,myOrdType                                                                                                        
                  ,myCustExch                                                                                                       
            from   DEX_RMAHDR                                                                                                       
            where  CALL = myPBNum;                                                                                                  
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               null;                                                                                                                
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
		log;                                                                                                                              
		mySect := 'Track - Partial Shp';                                                                                                  
  		-- override with RMA, Customer Control                                                                                          
  		mySPartial := nvl(myRMAPartial, nvl(XXDEX_PARTIAL_                                                                              
SHIP_F(null,null,myCustID,myOrgID,0,myOrdType), mySP                                                                                
artial));                                                                                                                           
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Tran Fee Flag';                                                                                            
                                                                                                                                    
      myTranFee := TRAN_FEE ( myCustID,myOrgID );                                                                                   
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - DPA';                                                                                                      
                                                                                                                                    
      myPutaway := F_DEX_CUST_CTRL ( myCustID,'DPA',myOrgID,'T' );                                                                  
                                                                                                                                    
      if myProgCode = 'RC' and myTTypeCode is null then                                                                             
         log;                                                                                                                       
         mySect := 'Track - Unopen';                                                                                                
                                                                                                                                    
         begin                                                                                                                      
            select TYPE_CODE                                                                                                        
            into   myTTypeCode                                                                                                      
            from   DEX_CUST_ITEMS_DATA_V                                                                                            
            where  CUSTOMER_ITEM_ID = myCItemID                                                                                     
            and    TYPE_CODE        = 'UN';                                                                                         
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myTTypeCode := myTypeCode;                                                                                           
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      if myTranFee = 'Y' then                                                                                                       
         log;                                                                                                                       
         mySect := 'Track - Tran Fee Price';                                                                                        
                                                                                                                                    
         myPrice := K_DEX_TRANSACTION_FEES.PRICE ( myCustID,myOrgID,myIte                                                           
mID );                                                                                                                              
      end if;                                                                                                                       
                                                                                                                                    
      if nvl(myPrice,0) = 0 then                                                                                                    
         if myPriceCode is null then                                                                                                
            if myProgCode = 'TD' then                                                                                               
               myPriceCode := 'TD';                                                                                                 
            else                                                                                                                    
               myPriceCode := 'RP';                                                                                                 
            end if;                                                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Price';                                                                                                 
                                                                                                                                    
         myPrice := F_DEX_PRICE ( nvl(myNItemID,myItemID                                                                            
),myCustID,myPriceCode,myCurrInfo.CURRENCY_CODE,myRe                                                                                
pair,myWarrInd );                                                                                                                   
                                                                                                                                    
         if nvl(myPrice,0) = 0 then                                                                                                 
            myPrice := myRMAPrice;                                                                                                  
         end if;                                                                                                                    
                                                                                                                                    
         myLineType := null;                                                                                                        
      end if;                                                                                                                       
                                                                                                                                    
      if myMPRPrice = 'Y' and myPlantID != myRPlantID th                                                                            
en                                                                                                                                  
         myPrice := 0;                                                                                                              
                                                                                                                                    
      elsif nvl(myPrice,0) = 0 and myTranFee != 'Y' and myZeroPrice = 'N' the                                                       
n                                                                                                                                   
         myRetMesg := 'Price Must Not be Zero';                                                                                     
                                                                                                                                    
         raise ABORT_PROC;                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      if myPrice is null then                                                                                                       
         myPrice := 0;                                                                                                              
      end if;                                                                                                                       
                                                                                                                                    
      mySTSNum := F_DEX_PRICE_STS ( nvl(myNItemID,myItemID),myCustID,myTy                                                           
peCode );                                                                                                                           
                                                                                                                                    
      if myOrder is not null then                                                                                                   
         log;                                                                                                                       
         mySect := 'Track - Check Order';                                                                                           
                                                                                                                                    
         begin                                                                                                                      
            select 'N'                                                                                                              
            into   myNewOrd                                                                                                         
            from   DEX_ORDERS                                                                                                       
            where  ORDERNO = myOrder;                                                                                               
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myOrder := null;                                                                                                     
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      if myOrder is null or myPBNum is not null then                                                                                
         log;                                                                                                                       
         mySect := 'Track - Find Order';                                                                                            
                                                                                                                                    
         begin                                                                                                                      
            select ORDERNO                                                                                                          
                  ,RMA                                                                                                              
            into   myOrder                                                                                                          
                  ,myRMA                                                                                                            
            from   DEX_ORDERS                                                                                                       
            where  CUST         = myCust                                                                                            
            and    CUSTPO       = myCustPO                                                                                          
            and    PLANT_ID     = myPlantID                                                                                         
            and    nvl(RMA,'x') = nvl(myPBNum,nvl(RMA,'x'))                                                                         
            and    CLOSED_FLAG  = 'O'                                                                                               
            and    ORDTYPE      = myOrdType                                                                                         
            and    rownum       < 2;                                                                                                
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myNewOrd := 'Y';                                                                                                     
         end;                                                                                                                       
                                                                                                                                    
         -- Jan 2007 - always force new Order if different Prebooking                                                               
         if nvl(myPBNum,'x') != nvl(myRMA,nvl(myPBNum,'                                                                             
x')) then                                                                                                                           
            myNewOrd := 'Y';                                                                                                        
         end if;                                                                                                                    
                                                                                                                                    
         if myNewOrd = 'Y' then                                                                                                     
            myNewLne  := 'Y';                                                                                                       
            myRelease := nvl(myPRelease,to_char(SYSDATE,'DD-MON                                                                     
 HH24:MI:SS'));                                                                                                                     
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Track - Order';                                                                                              
                                                                                                                                    
            myOrder := F_ORDER_CHECK;                                                                                               
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Track - Insert Order (' || my                                                                                
Order || ')';                                                                                                                       
                                                                                                                                    
            insert into DEX_ORDERS                                                                                                  
           (ORDERNO,CUSTNAME,CUSTPO,RELEASE,CUST,SHIPT                                                                              
O                                                                                                                                   
           ,DATERCV,ORDTYPE,ORDER_SOURCE,RELABEL_FLAG                                                                               
           ,REGION,AGENT,CLASS,TLM,SHIP_VIA,DROP_SHIP                                                                               
           ,SHIP_NAME,SHIP_ATTN,SHIP_ST1,SHIP_ST2                                                                                   
           ,SHIP_CITY,SHIP_STATE,SHIP_ZIP,COUNTRY                                                                                   
           ,PARTIAL_SHP,COD,TYPE,TRANSFER,DRIVER,RMA,PRICE_TYPE_CODE                                                                
           ,CUSTOMER_ID,BILL_SITE_USE_ID,SHIP_SITE_USE_ID,P                                                                         
AYMENT_OPTION                                                                                                                       
           ,PLANT_ID,ORG_ID,PLANT,CLOSED_FLAG,EMAIL,CUST_EXCHANG                                                                    
E                                                                                                                                   
           ,CURRENCY_CODE,EXCHANGE_RATE_TYPE,EXCHANGE_RATE_DATE,EXCHANGE_RAT                                                        
E                                                                                                                                   
           ,CREDIT_CARD_TYPE,CREDIT_CARD_NAME,CREDIT_CARD_ACCT                                                                      
           ,CREDIT_CARD_EXP,CREDIT_CARD_METHOD,CREDIT_CARD_APPROV                                                                   
AL                                                                                                                                  
           ,ATTRIBUTE_CATEGORY                                                                                                      
           ,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTRIBUTE5                                                                  
           ,ATTRIBUTE6,ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9                                                                             
,ATTRIBUTE10                                                                                                                        
           ,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,ATTRI                                                                   
BUTE15                                                                                                                              
           ,ATTRIBUTE16,ATTRIBUTE17,ATTRIBUTE18,ATTRIBUTE19,ATTRIBUTE20                                                             
                                                                                                                                    
           ,ATTRIBUTE21,ATTRIBUTE22,ATTRIBUTE23,ATTRIBUTE24,ATTRIBUTE25                                                             
           ,ATTRIBUTE26,ATTRIBUTE27,ATTRIBUTE28,ATTRIBUTE                                                                           
29,ATTRIBUTE30                                                                                                                      
           ,ATTRIBUTE31,ATTRIBUTE32,ATTRIBUTE33,ATTRIBUTE34,ATT                                                                     
RIBUTE35                                                                                                                            
           ,ATTRIBUTE36,ATTRIBUTE37,ATTRIBUTE38,ATTRIBUTE39,ATTRIBUTE                                                               
40                                                                                                                                  
           ) values (                                                                                                               
            myOrder,myCustName,myCustPO,myRelease,myC                                                                               
ust,0                                                                                                                               
           ,trunc(SYSDATE),myOrdType,myOrdSrc,myRelabel                                                                             
           ,myRegion,myOSalesRep,myClass,myISalesRep,nvl(myRShipVia,                                                                
mySShipVia),'N'                                                                                                                     
           ,myShipName,myShipAttn,myShipSt1,myShipSt2                                                                               
           ,myShipCity,myShipState,myShipZip,myCountry                                                                              
           ,mySPartial,'N','N','V',myWaybill,myPBNum,myPr                                                                           
iceCode                                                                                                                             
           ,myCustID,myBillID,myShipID,myPayOption                                                                                  
           ,myPlantID,myOrgID,myPlant,'O',myEMail,myCustExch                                                                        
           ,myCurrInfo.CURRENCY_CODE,myCurrInfo.EXCHANGE_RATE_                                                                      
TYPE,myCurrInfo.EXCHANGE_RATE_DATE,myCurrInfo.EXCHAN                                                                                
GE_RATE                                                                                                                             
           ,myCardInfo.CREDIT_CARD_TYPE,myCardInfo.CREDIT_CARD_NAME,my                                                              
CardInfo.CREDIT_CARD_ACCT                                                                                                           
           ,myCardInfo.CREDIT_CARD_EXP,myCardInfo.CR                                                                                
EDIT_CARD_METHOD,myCardInfo.CREDIT_CARD_APPROVAL                                                                                    
           ,myOrdAttrCat                                                                                                            
           ,myOrdFlex.ATTRIBUTE1,myOrdFlex.ATTRIBUTE2,my                                                                            
OrdFlex.ATTRIBUTE3,myOrdFlex.ATTRIBUTE4,myOrdFlex.AT                                                                                
TRIBUTE5                                                                                                                            
           ,myOrdFlex.ATTRIBUTE6,myOrdFlex.ATTRIBUTE7,myOrdFlex.ATTRI                                                               
BUTE8,myOrdFlex.ATTRIBUTE9,myOrdFlex.ATTRIBUTE10                                                                                    
           ,myOrdFlex.ATTRIBUTE11,myOrdFlex.ATTRIBUTE12                                                                             
,myOrdFlex.ATTRIBUTE13,myOrdFlex.ATTRIBUTE14,myOrdFl                                                                                
ex.ATTRIBUTE15                                                                                                                      
           ,myOrdFlex.ATTRIBUTE16,myOrdFlex.ATTRIBUTE17,myOrdFl                                                                     
ex.ATTRIBUTE18,myOrdFlex.ATTRIBUTE19,myOrdFlex.ATTRI                                                                                
BUTE20                                                                                                                              
           ,myOrdFlex.ATTRIBUTE21,myOrdFlex.ATTRIBUTE22,myOrdFlex.ATTRI                                                             
BUTE23,myOrdFlex.ATTRIBUTE24,myOrdFlex.ATTRIBUTE25                                                                                  
           ,myOrdFlex.ATTRIBUTE26,myOrdFlex.ATTRIBUTE                                                                               
27,myOrdFlex.ATTRIBUTE28,myOrdFlex.ATTRIBUTE29,myOrd                                                                                
Flex.ATTRIBUTE30                                                                                                                    
           ,myOrdFlex.ATTRIBUTE31,myOrdFlex.ATTRIBUTE32,myOrd                                                                       
Flex.ATTRIBUTE33,myOrdFlex.ATTRIBUTE34,myOrdFlex.ATT                                                                                
RIBUTE35                                                                                                                            
           ,myOrdFlex.ATTRIBUTE36,myOrdFlex.ATTRIBUTE37,myOrdFlex.ATT                                                               
RIBUTE38,myOrdFlex.ATTRIBUTE39,myOrdFlex.ATTRIBUTE40                                                                                
                                                                                                                                    
           );                                                                                                                       
                                                                                                                                    
            -- Aug 2007: Need to pull in flex fields from DEX_                                                                      
RMAHDR when doing Cross Dock option                                                                                                 
            if myPalletID is not null then                                                                                          
               log;                                                                                                                 
               mySect := 'Track - Order Flex';                                                                                      
                                                                                                                                    
               UPDT_ORDER_FLEX ( myPBNum,myOrder );                                                                                 
            end if;                                                                                                                 
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      if myNewOrd = 'N' then                                                                                                        
         log;                                                                                                                       
         mySect := 'Track - Find Item';                                                                                             
                                                                                                                                    
         begin                                                                                                                      
            select ITEM                                                                                                             
            into   myItem                                                                                                           
            from   DEX_LINES lne                                                                                                    
            where  ORDERNO           = myOrder                                                                                      
            and    INVENTORY_ITEM_ID = nvl(myNItemID,myItemID)                                                                      
            and    nvl(CUSTPART,'x') = nvl(myNCPart,nvl                                                                             
(myCPart,'x'))                                                                                                                      
            and    PRICE             = myPrice                                                                                      
            and    nvl(UOM,'EA')    != 'LT'                                                                                         
            and    rownum            < 2                                                                                            
            and    exists                                                                                                           
                  (select '*'                                                                                                       
                   from   DEX_SERIALS ser                                                                                           
                   where  lne.ORDERNO            = ser.ORDERNO                                                                      
                   and    lne.ITEM               = ser.I                                                                            
TEM                                                                                                                                 
                   and    nvl(ser.TYPE_CODE,'X') = nvl(myTypeCode,'X'));                                                            
                                                                                                                                    
            myNewLne := 'N';                                                                                                        
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Track - Unique';                                                                                             
                                                                                                                                    
            select max(UNIQUENO)                                                                                                    
            into   myUnique                                                                                                         
            from   DEX_SERIALS                                                                                                      
            where  ORDERNO = myOrder                                                                                                
            and    ITEM    = myItem;                                                                                                
                                                                                                                                    
            myUnique := nvl(myUnique,0) + 1;                                                                                        
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myNewLne := 'Y';                                                                                                     
               myUnique := 1;                                                                                                       
                                                                                                                                    
               select nvl(max(ITEM),0) + 1                                                                                          
               into   myItem                                                                                                        
               from   DEX_LINES                                                                                                     
               where  ORDERNO = myOrder;                                                                                            
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Serial Control';                                                                                           
                                                                                                                                    
      if XXDEX_CUST_SERIAL_CTRL_F ( myCustID,myOrgID,my                                                                             
ItemID ) = 'N' then                                                                                                                 
         myUOM := 'LT';                                                                                                             
      else                                                                                                                          
         myUOM := 'EA';                                                                                                             
      end if;                                                                                                                       
                                                                                                                                    
      if myLotCntInd = 'F' then           -- Force Lot                                                                              
         myUOM := 'LT';                                                                                                             
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Override Fees';                                                                                            
                                                                                                                                    
      if myUOM = 'LT' and myLotCntInd = 'Y' then                                                                                    
         myFeeOverride := K_DEX_TRANSACTION_FEES.FEE (                                                                              
                                                       myCustID       =                                                             
> myCustID                                                                                                                          
                                                      ,myOrgID                                                                      
   => myOrgID                                                                                                                       
                                                      ,myItemID                                                                     
      => myItemID                                                                                                                   
                                                      ,myLoc                                                                        
n         => 'REC'                                                                                                                  
                                                      ,myTy                                                                         
peCode     => myTypeCode                                                                                                            
                                                                                                                                    
 ,myForceRqrd    => 'Y'                                                                                                             
                                                                                                                                    
,myPalletID     => myPalletID                                                                                                       
                                                      ,myConsiderFees => '                                                          
N'                                                                                                                                  
                                                     );                                                                             
                                                                                                                                    
         myFeeOverride := myFeeOverride * nvl(myLotQty,myQtyOrg);                                                                   
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Track Check';                                                                                              
                                                                                                                                    
      begin                                                                                                                         
         select ORDERNO                                                                                                             
         into   myTOrder                                                                                                            
         from   DEX_SERIALS                                                                                                         
         where  TRACK     = myTrack                                                                                                 
         and    LOCATION != 'SHP';                                                                                                  
                                                                                                                                    
         myRetMesg := 'Track: ' || myTrack || ' is Already on O                                                                     
rder: ' || myTOrder;                                                                                                                
         raise ABORT_PROC;                                                                                                          
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            null;                                                                                                                   
      end;                                                                                                                          
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Charge Limit';                                                                                             
                                                                                                                                    
      myChrgLimit := XXDEX_CHARGE_LIMIT_F ( myCustID,m                                                                              
yItemID );                                                                                                                          
                                                                                                                                    
      if myParent = 'EDSCOE' then                                                                                                   
         log;                                                                                                                       
         mySect := 'Track - EDS COE Charge Limit';                                                                                  
                                                                                                                                    
         myChrgLimit := nvl(myChrgLimit,mySrlFlex.ATTRIBUTE5);                                                                      
                                                                                                                                    
      elsif myParent = 'TTERCT' then                                                                                                
         mySerial := substr(mySerial,6);          -- will ignore first 5                                                            
chars.                                                                                                                              
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Part Route Code';                                                                                          
                                                                                                                                    
      if myPalletID is not null then                                                                                                
         -- dont do routing on Cross Dock option                                                                                    
         myRouteCode := null;                                                                                                       
                                                                                                                                    
      else                                                                                                                          
         begin                                                                                                                      
            select PART_ROUTING_CODE                                                                                                
            into   myRouteCode                                                                                                      
            from   DEX_CUST_ITEM_XREFS_DATA_V                                                                                       
            where  CUSTOMER_ITEM_ID  = nvl(myNCItemID,my                                                                            
CItemID)                                                                                                                            
            and    INVENTORY_ITEM_ID = nvl(myNItemID,myItemID);                                                                     
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myRouteCode := null;                                                                                                 
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      if mySerialID is null then                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Serial ID';                                                                                             
                                                                                                                                    
         select SERIALS_S.nextval                                                                                                   
         into   mySerialID                                                                                                          
         from   DUAL;                                                                                                               
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Insert Serials (' || myOrder || '-' || to_char(myIte                                                       
m) || '-' || to_char(myUnique) || ') ' || myNewLne;                                                                                 
                                                                                                                                    
      insert into DEX_SERIALS                                                                                                       
     (SERIAL_ID,ORDERNO,ITEM,LOCATION,DATELOC,SCRAP,UNIQUENO                                                                        
     ,TRACK,SERIAL,TYPE_CODE,ORIG_SERIAL,TAB_NUMBER,TAG_NUMBER                                                                      
     ,CHARGE_LIMIT,FEE_OVERRIDE,ROUTE_CODE,RTN_STATUS                                                                               
_CODE                                                                                                                               
     ,ATTRIBUTE_CATEGORY                                                                                                            
     ,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTRIBUTE5                                                                        
     ,ATTRIBUTE6,ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9,ATTRIBUTE10                                                                       
     ,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,                                                                              
ATTRIBUTE15                                                                                                                         
     ,ATTRIBUTE16,ATTRIBUTE17,ATTRIBUTE18,ATTRIBUTE19,ATTRIBUTE20                                                                   
     ,ATTRIBUTE21,ATTRIBUTE22,ATTRIBUTE23,ATTRIBUTE2                                                                                
4,ATTRIBUTE25                                                                                                                       
     ) values (                                                                                                                     
      mySerialID,myOrder,myItem,'REC',SYSDATE,'N',myUnique                                                                          
     ,myTrack,mySerial,myTypeCode,mySerial,decode(myTypeCode,'UN',n                                                                 
ull,myHoldCode),myTTag                                                                                                              
     ,myChrgLimit,myFeeOverride,myRouteCode,myRtnStatCd                                                                             
                                                                                                                                    
     ,mySrlAttrCat                                                                                                                  
     ,mySrlFlex.ATTRIBUTE1,mySrlFlex.ATTRIBUTE2,mySrlFlex.                                                                          
ATTRIBUTE3,mySrlFlex.ATTRIBUTE4,mySrlFlex.ATTRIBUTE5                                                                                
                                                                                                                                    
     ,mySrlFlex.ATTRIBUTE6,mySrlFlex.ATTRIBUTE7,mySrlFlex.ATTRIBUTE8,mySrlFle                                                       
x.ATTRIBUTE9,mySrlFlex.ATTRIBUTE10                                                                                                  
     ,mySrlFlex.ATTRIBUTE11,mySrlFlex.ATTRIBUTE12,mySrlFlex.ATTRIBUTE                                                               
13,mySrlFlex.ATTRIBUTE14,mySrlFlex.ATTRIBUTE15                                                                                      
     ,mySrlFlex.ATTRIBUTE16,mySrlFlex.ATTRIBUTE17,mySrlFl                                                                           
ex.ATTRIBUTE18,mySrlFlex.ATTRIBUTE19,mySrlFlex.ATTRI                                                                                
BUTE20                                                                                                                              
     ,mySrlFlex.ATTRIBUTE21,mySrlFlex.ATTRIBUTE22,mySrlFlex.ATTRIBUTE23                                                             
,mySrlFlex.ATTRIBUTE24,mySrlFlex.ATTRIBUTE25                                                                                        
     );                                                                                                                             
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - BOM';                                                                                                      
                                                                                                                                    
      if myBOMTranID is not null then                                                                                               
         update DEX_SERIAL_OPTIONS set                                                                                              
         SERIAL_ID = mySerialID                                                                                                     
         where TRAN_ID = myBOMTranID;                                                                                               
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - B2B';                                                                                                      
                                                                                                                                    
      begin                                                                                                                         
         select 'Y'                                                                                                                 
         into   myB2B                                                                                                               
         from   DEX_CUSTOMER_CONTROL                                                                                                
         where  CUSTOMER_ID = myCustID                                                                                              
         and    ORG_ID      = myOrgID                                                                                               
         and    TYPE        = 'B2B'                                                                                                 
         and   (DATA        = 'RECV' or instr(SEGMENT1,'RECV') > 0                                                                  
);                                                                                                                                  
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myB2B := 'N';                                                                                                           
      end;                                                                                                                          
                                                                                                                                    
      if myB2B = 'Y' then                                                                                                           
         log;                                                                                                                       
         mySect := 'Track - DEX Interface';                                                                                         
                                                                                                                                    
         K_DEX_INTERFACE.LOAD (                                                                                                     
                                myRetMesg => myRetMe                                                                                
sg                                                                                                                                  
                               ,myRetCode => myRetCode                                                                              
                               ,myTypeID  => 501                                                                                    
                               ,mySrcID   => mySerialID                                                                             
                               ,mySubmit  => 'N'                                                                                    
                              );                                                                                                    
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            raise ABORT_PROC;                                                                                                       
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
		log;                                                                                                                              
		mySect := 'Track - Installbase';                                                                                                  
		if myIBUpdate = 'Y' and myRPlantId = myPlantID then			-- Re                                                                       
pair Plant                                                                                                                          
			K_DEX_INTERFACE. LOAD (                                                                                                          
                              myRetMesg => myRetMesg                                                                                
                             ,myRetCode => myRetCode                                                                                
                             ,myTypeID  => 503                                                                                      
                             ,mySrcID   => mySerialID                                                                               
                             ,mySubmit  => 'N'                                                                                      
                            );                                                                                                      
			if myRetCode > 0 then                                                                                                            
            raise ABORT_PROC;                                                                                                       
         end if;                                                                                                                    
		end if;                                                                                                                           
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Item';                                                                                                     
                                                                                                                                    
		dbms_output.put_line('NItemID: ' || myNItemID || ' ItemID: ' || myIt                                                              
emID || ' IOrgID || ' || myIOrgID);                                                                                                 
		begin                                                                                                                             
	      select DESCRIPTION                                                                                                           
   	         ,nvl(CUMULATIVE_TOTAL_LEAD_TIME,14)                                                                                    
      	      ,OEM                                                                                                                   
         	   ,GRP                                                                                                                   
            	,GROUP_ID                                                                                                              
	      into   myDesc                                                                                                                
   	         ,myLead                                                                                                                
      	      ,myOEM                                                                                                                 
         	   ,myGrp                                                                                                                 
            	,myGrpID                                                                                                               
	      from   V_DEX_PART_DATA                                                                                                       
   	   where  INVENTORY_ITEM_ID = nvl(myNItemID,myIt                                                                                
emID)                                                                                                                               
      	and    ORGANIZATION_ID   = myIOrgID;                                                                                         
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRetMesg := 'Part: ' || F_DEX_ITEM_NUMBER(myItemID) || ' is no                                                                 
t enabled in Organization: ' || myIOrgID;                                                                                           
				raise ABORT_PROC;                                                                                                               
		end;                                                                                                                              
                                                                                                                                    
                                                                                                                                    
      if myProgCode in ('RC','TD') then                                                                                             
         myTGrp   := myGrp;                                                                                                         
         myTGrpID := myGrpID;                                                                                                       
                                                                                                                                    
         if myProgCode = 'TD' then                                                                                                  
            myGrp := 'DNS';                                                                                                         
         else                                                                                                                       
            myGrp := 'RCT';                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Grp';                                                                                                   
                                                                                                                                    
         begin                                                                                                                      
            select dxg.GRP                                                                                                          
                  ,dxg.GROUP_ID                                                                                                     
            into   myGrp                                                                                                            
                  ,myGrpID                                                                                                          
            from   DEX_GROUP_PLANTS dgo                                                                                             
                  ,DEX_GROUPS dxg                                                                                                   
            where  dxg.GROUP_ID = dgo.GROUP_ID                                                                                      
            and    dgo.PLANT_ID = myPlantID                                                                                         
            and    dxg.GRP      = myGrp;                                                                                            
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myGrp   := myTGrp;                                                                                                   
               myGrpID := myTGrpID;                                                                                                 
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      if myNewLne = 'Y' then                                                                                                        
         log;                                                                                                                       
         mySect := 'Track - Schd';                                                                                                  
                                                                                                                                    
         mySchd := F_DEX_SCHD_DATE ( myCustID,myOrgI                                                                                
D,'N',myLead,'R',myPlantID );                                                                                                       
                                                                                                                                    
         if mySchd is null then                                                                                                     
            myRetMesg := 'Schd Date Not Loaded (' || to_char(myCust                                                                 
ID) || '-' || to_char(myOrgID) || ')';                                                                                              
            raise ABORT_PROC;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Insert Lines';                                                                                          
                                                                                                                                    
         insert into DEX_LINES                                                                                                      
        (ORDERNO,ITEM,CUSTITEM,PART,CUSTPART,ORIG_CUST_PAR                                                                          
T,DATESCH,GRP,STATCODE                                                                                                              
        ,SERIALCTL,QTYORG,PRICE,INV_MGMT,MFG,DESCRIPTIO                                                                             
N,SHIP_EARLY,LINE_TYPE                                                                                                              
        ,STATUS,STORE,INVENTORY_ITEM_ID,CUSTOMER_ITEM_I                                                                             
D,GROUP_ID                                                                                                                          
        ,ORGANIZATION_ID,REPAIR_PLANT_ID,UOM,STS_NUMBER,ATTRIBUTE_C                                                                 
ATEGORY                                                                                                                             
        ,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTRIBUTE5                                                                     
        ,ATTRIBUTE6,ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9,ATTRI                                                                          
BUTE10                                                                                                                              
        ,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,ATTRIBUTE15                                                                
        ) values (                                                                                                                  
         myOrder,myItem,nvl(myPBItem,myItem),nvl(myNPart,myPa                                                                       
rt),nvl(myNCPart,myCPart),nvl(myNCPart,myCPart),trun                                                                                
c(mySchd),myGrp,myStatCode                                                                                                          
        ,'N',decode(myUOM,'LT',nvl(myLotQty,myQtyOrg),myQtyOrg),myPrice,myInv                                                       
Mgmt,myOEM,myDesc,'Y',myLineType                                                                                                    
        ,'O','R',nvl(myNItemID,myItemID),nvl(myNCItemID,myCItemID),myGr                                                             
pID                                                                                                                                 
        ,myIOrgID,myRPlantID,myUOM,myStsNum,myLneAttrCat                                                                            
        ,myLneFlex.ATTRIBUTE1,myLneFlex.ATTRIBUTE2,myLneFlex.ATTRIBUT                                                               
E3,myLneFlex.ATTRIBUTE4,myLneFlex.ATTRIBUTE5                                                                                        
        ,myLneFlex.ATTRIBUTE6,myLneFlex.ATTRIBUTE7,myLneFle                                                                         
x.ATTRIBUTE8,myLneFlex.ATTRIBUTE9,myLneFlex.ATTRIBUT                                                                                
E10                                                                                                                                 
        ,myLneFlex.ATTRIBUTE11,myLneFlex.ATTRIBUTE12,myLneFlex.ATTRIBUTE13                                                          
,myLneFlex.ATTRIBUTE14,myLneFlex.ATTRIBUTE15                                                                                        
        );                                                                                                                          
                                                                                                                                    
         if myNewOrd = 'N' then                             -- K_DEX_QCRE                                                           
CV_AOL Calls K_WIP_JOB                                                                                                              
            log;                                                                                                                    
            mySect := 'Track - Job';                                                                                                
                                                                                                                                    
            K_WIP_JOB.JOB_OPEN ( myOrder,myItem );                                                                                  
         end if;                                                                                                                    
                                                                                                                                    
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'Track - Update Lines';                                                                                          
                                                                                                                                    
         update DEX_LINES set                                                                                                       
         QTYORG = (select nvl(count('*'),0)                                                                                         
                   from   DEX_SERIALS                                                                                               
                   where  ORDERNO = myOrder                                                                                         
                   and    ITEM    = myItem)                                                                                         
        ,STATUS = 'O'                                                                                                               
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = myItem;                                                                                                    
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'Line Item Not Found - Order: ' ||                                                                         
 myOrder || ' Item: ' || to_char(myItem);                                                                                           
            raise ABORT_PROC;                                                                                                       
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Receipts History';                                                                                         
                                                                                                                                    
      K_DEX_RECEIPTS.HISTORY ( myRetMesg,myRetCode,myWaybill,'OR',myOrder,                                                          
null,null );                                                                                                                        
                                                                                                                                    
      if myRetCode > 0 then                                                                                                         
         raise ABORT_PROC;                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      if myPBNum is not null then                                                                                                   
         log;                                                                                                                       
         mySect := 'Track - PB Serial Update';                                                                                      
                                                                                                                                    
         update DEX_RMA_SERIALS set                                                                                                 
         STATUS    = 'C'                                                                                                            
        ,ORDERNO   = myOrder                                                                                                        
        ,DATEENT   = SYSDATE                                                                                                        
        ,SERIAL_ID = mySerialID                                                                                                     
         where CALL   = myPBNum                                                                                                     
         and   SERIAL = myTrack;                                                                                                    
                                                                                                                                    
         if SQL%rowcount = 0 and myPBItem is not null then                                                                          
            log;                                                                                                                    
            mySect := 'Track - PB Serial Insert';                                                                                   
                                                                                                                                    
            select nvl(max(UNIQUENO),0)                                                                                             
            into   myPBUnique                                                                                                       
            from   DEX_RMA_SERIALS                                                                                                  
            where  CALL = myPBNum                                                                                                   
            and    ITEM = myPBItem;                                                                                                 
                                                                                                                                    
            myPBUnique := myPBUnique + 1;                                                                                           
                                                                                                                                    
            insert into DEX_RMA_SERIALS                                                                                             
           (CALL                                                                                                                    
           ,ORDERNO                                                                                                                 
           ,ITEM                                                                                                                    
           ,SERIAL                                                                                                                  
           ,UNIQUENO                                                                                                                
           ,STATUS                                                                                                                  
           ,DATEENT                                                                                                                 
           ,SERIAL_ID                                                                                                               
           ,RMA_SERIAL_ID                                                                                                           
           ) values (                                                                                                               
            myPBNum                                                                                                                 
           ,myOrder                                                                                                                 
           ,myPBItem                                                                                                                
           ,myTrack                                                                                                                 
           ,myPBUnique                                                                                                              
           ,'C'                                                                                                                     
           ,SYSDATE                                                                                                                 
           ,mySerialID                                                                                                              
           ,RMA_SERIALS_S.nextval                                                                                                   
           );                                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - PB Detail Update';                                                                                      
                                                                                                                                    
         update DEX_RMADET set                                                                                                      
         QTYRCV     = nvl(QTYRCV,0) + decode(UOM,'LT',nvl(myLotQty,myQ                                                              
tyOrg),1)                                                                                                                           
        ,RECV_PRICE = myPrice                                                                                                       
        ,STATUS     = decode(sign(QTYORG - (nvl(QTYRCV,0) + deco                                                                    
de(UOM,'LT',nvl(myLotQty,myQtyOrg),1))),1,'O','C')                                                                                  
         where CALL = myPBNum                                                                                                       
         and   ITEM = myPBItem;                                                                                                     
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - FCR';                                                                                                   
                                                                                                                                    
         begin                                                                                                                      
            select 'Y'                                                                                                              
            into   myFinalClose                                                                                                     
            from   DEX_CUSTOMER_CONTROL                                                                                             
            where  CUSTOMER_ID = myCustID                                                                                           
            and    ORG_ID      = myOrgID                                                                                            
            and    TYPE        = 'FCR';          -- Final Cl                                                                        
ose RMA Required (RMA must be marked as Final Close)                                                                                
                                                                                                                                    
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myFinalClose := 'N';                                                                                                 
         end;                                                                                                                       
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - PB Header Update';                                                                                      
                                                                                                                                    
         update DEX_RMAHDR set                                                                                                      
         ORDERNO  = myOrder                                                                                                         
        ,STATUS   = 'C'                                                                                                             
        ,DATECLS  = SYSDATE                                                                                                         
         where CALL = myPBNum                                                                                                       
         and   not (myFinalClose = 'Y' and nvl(CUST_S                                                                               
TATUS,'A') = 'F')                                                                                                                   
         and   not exists                                                                                                           
              (select '*'                                                                                                           
               from   DEX_RMADET                                                                                                    
               where  CALL = myPBNum                                                                                                
               and    QTYORG - nvl(QTYRCV,0) > 0);                                                                                  
      end if;                                                                                                                       
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    
      if myWarrTrack = 'Y' and myWarrDays > 0 then                                                                                  
         log;                                                                                                                       
         mySect := 'Track - Warr Check';                                                                                            
                                                                                                                                    
         K_DEX_WARRANTY_AOL.CHECK_TRACK (                                                                                           
                                          myTrack     => my                                                                         
Track                                                                                                                               
                                         ,myReport    => null                                                                       
                                         ,myWarrID    => myWar                                                                      
rID                                                                                                                                 
                                         ,myResult    => myWarr                                                                     
                                         ,myWarrAudit => myWar                                                                      
rAudit                                                                                                                              
                                         ,myBERFlag   => myBERFlag                                                                  
                                         ,myHonoredBy =>                                                                            
 myHonoredBy                                                                                                                        
                                         ,myErrMesg 	=> myRetMesg                                                                   
                                                                                                                                    
                                        );                                                                                          
			if myRetMesg is not null then                                                                                                    
				raise ABORT_PROC;                                                                                                               
			end if;                                                                                                                          
                                                                                                                                    
         if myWarr = 'WARRANTY' then                                                                                                
            log;                                                                                                                    
            mySect := 'Track - Warr Proc';                                                                                          
                                                                                                                                    
            K_DEX_WARRANTY_AOL.PROCESS (                                                                                            
                                         myTrack     => myTrac                                                                      
k                                                                                                                                   
                                        ,myWarrID    => myWarrID                                                                    
                                        ,myUserID    => myUserI                                                                     
D                                                                                                                                   
                                        ,myReported  => 'Not Reported'                                                              
                                        ,myWarranty  => '                                                                           
Valid'                                                                                                                              
                                        ,myHonoredBy => myHonoredBy                                                                 
                                        ,mySerial    =>                                                                             
 myTrack                                                                                                                            
                                        ,myCmt       => null                                                                        
                                        ,myWarrDetID => myWa                                                                        
rrDetID                                                                                                                             
                                       );                                                                                           
                                                                                                                                    
            myPrice := 0;                                                                                                           
                                                                                                                                    
            if myNewLne = 'Y' then                                                                                                  
               log;                                                                                                                 
               mySect := 'Track - Warr Lines';                                                                                      
                                                                                                                                    
               update DEX_LINES set                                                                                                 
               PRICE    = 0                                                                                                         
              ,STATCODE = 'W'                                                                                                       
               where ORDERNO = myOrder                                                                                              
               and   ITEM    = myItem;                                                                                              
                                                                                                                                    
            else                                                                                                                    
               log;                                                                                                                 
               mySect := 'Track - Warr Move';                                                                                       
                                                                                                                                    
               K_MOVE_ORDER.SERIAL (                                                                                                
                                     myRetMesg   => myRetMesg                                                                       
                                    ,myRetCode   => myRetCode                                                                       
                                                                                                                                    
                                    ,myOrder     => myOrder                                                                         
                                    ,myItem      => myItem                                                                          
                                    ,mySerialID  => mySerialID                                                                      
                                                                                                                                    
                                    ,myNPrice    => myPrice                                                                         
                                    ,myNStatCode => 'W'                                                                             
                                    ,myNSchdDate => null                                                                            
                                    ,myNItemID   => myItemID                                                                        
                                                                                                                                    
--                                  ,myNCPart    => nvl(myNItemID,myItemID)                                                         
                                    ,myNCPart    => n                                                                               
vl(myNCPart,myCPart)                                                                                                                
                                    ,myNGrp      => myGrp                                                                           
                                                                                                                                    
                                   );                                                                                               
                                                                                                                                    
               if myRetCode > 0 then                                                                                                
                  raise ABORT_PROC;                                                                                                 
               end if;                                                                                                              
            end if;                                                                                                                 
                                                                                                                                    
         elsif myWarr = 'INVALID' then                                                                                              
            log;                                                                                                                    
            mySect := 'Track - Warr Invalid';                                                                                       
                                                                                                                                    
            -- Jan 2008 : store warranty detail for                                                                                 
Returns/Invalid for Recert Custs                                                                                                    
            K_DEX_WARRANTY_AOL.PROCESS (                                                                                            
                                         myTrack     =>                                                                             
myTrack                                                                                                                             
                                        ,myWarrID    => myWarrID                                                                    
                                        ,myUserID    => m                                                                           
yUserID                                                                                                                             
                                        ,myReported  => 'Not Reported'                                                              
                                                                                                                                    
                                        ,myWarranty  => 'Invalid'                                                                   
                                        ,myHonoredBy => myHonor                                                                     
edBy                                                                                                                                
                                        ,mySerial    => myTrack                                                                     
                                        ,myCmt       => null                                                                        
                                        ,myWarrDetID                                                                                
 => myWarrDetID                                                                                                                     
                                       );                                                                                           
                                                                                                                                    
         elsif myWarr = 'RETURN' then                                                                                               
            log;                                                                                                                    
            mySect := 'Track - Warr Return';                                                                                        
                                                                                                                                    
            K_DEX_WARRANTY_AOL.PROCESS_RETURN (                                                                                     
                                                myWa                                                                                
rrID   => myWarrID                                                                                                                  
                                               ,mySerialID                                                                          
=> mySerialID                                                                                                                       
                                               ,myUserID   => my                                                                    
UserID                                                                                                                              
                                               );                                                                                   
            update DEX_SERIALS set                                                                                                  
            WARRANTY_ID = myWarrID                                                                                                  
           ,WARRANTY    = 'Return'                                                                                                  
            where  SERIAL_ID = mySerialID;                                                                                          
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Transfer Counter';                                                                                         
                                                                                                                                    
      P_DEX_CNT_HOUR ( 'QRX',myEmpNo,null,myPlant,1,myPrice,0,SYSDATE,-                                                             
1,'Y',mySerialID );                                                                                                                 
                                                                                                                                    
      if myNewOrd = 'Y' then                                                                                                        
         log;                                                                                                                       
         mySect := 'Track - Update Order';                                                                                          
                                                                                                                                    
         update DEX_ORDERS set                                                                                                      
         DATEENT  = trunc(SYSDATE)                                                                                                  
        ,TRANSFER = 'Q'                                                                                                             
        ,UNPACKER = myEmpNo                                                                                                         
        ,RECEIVER = myEmpNo                                                                                                         
         where ORDERNO = myOrder;                                                                                                   
                                                                                                                                    
         if myRecvXprs = 'Y' then                                                                                                   
            myStatus := 'A';                                                                                                        
         else                                                                                                                       
            myStatus := null;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
                                                                                                                                    
			/*                                                                                                                               
         log;                                                                                                                       
         mySect := 'Track - Update Serials (QCR)';                                                                                  
                                                                                                                                    
         update DEX_SERIALS set                                                                                                     
         LOCATION = 'QCR'                                                                                                           
        ,DATELOC  = SYSDATE                                                                                                         
        ,STATUS   = myStatus                                                                                                        
         where ORDERNO = myOrder;                                                                                                   
			*/                                                                                                                               
                                                                                                                                    
         if myProgCode = 'RC' or myRecvXprs = 'Y' or myRela                                                                         
bel = 'Y' then                                                                                                                      
            log;                                                                                                                    
            mySect := 'Track - QCRecv';                                                                                             
                                                                                                                                    
            myRetMesg := K_DEX_QCRECV_AOL.ACCEPT ( myOrde                                                                           
r,myEmpNo,'N' , myXDockLocn);                                                                                                       
                                                                                                                                    
                                                                                                                                    
            if myRetMesg != 'VALID' then                                                                                            
               raise ABORT_PROC;                                                                                                    
            end if;                                                                                                                 
                                                                                                                                    
            mySect := 'Track - Clear Schedule';                                                                                     
            delete DEX_SCHEDULE                                                                                                     
            where  SERIAL_ID = mySerialID;                                                                                          
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Booking Post Process';                                                                                  
                                                                                                                                    
         BOOKING_POST_PROCESS ( myOrder,myCustID,myOrgID                                                                            
 );                                                                                                                                 
                                                                                                                                    
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'Track - Counters Grp';                                                                                          
                                                                                                                                    
         P_DEX_CNT_HOUR ( 'QCR',myGrp,myEmpNo,myPlant,1,                                                                            
myPrice,null,SYSDATE,-1,'N',null );                                                                                                 
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Counters Emp';                                                                                          
                                                                                                                                    
         P_DEX_CNT_HOUR ( 'QCR',myEmpNo,null,myPlant,1,myPric                                                                       
e,null,SYSDATE,null,'Y',mySerialID );                                                                                               
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Cnt Emp';                                                                                               
                                                                                                                                    
         P_DEX_CNT_HOUR ( 'REU',myEmpNo,null,myPlant,1 / 2,myPri                                                                    
ce / 2,null,SYSDATE,null,'N',null );                                                                                                
         P_DEX_CNT_HOUR ( 'RER',myEmpNo,null,myPlant,1 / 2,myPrice                                                                  
/ 2,null,SYSDATE,null,'N',null );                                                                                                   
      end if;                                                                                                                       
                                                                                                                                    
      -- Sep 2006. Only call Fees logic if a new order                                                                              
wasn't created because it didn't go thru the                                                                                        
      -- K_DEX_QCRECV_AOL process (above).                                                                                          
      if myTranFee = 'Y' and myPrice > 0 and myNewOrd != 'Y' then                                                                   
         log;                                                                                                                       
         mySect := 'Track - Service Fees';                                                                                          
                                                                                                                                    
         K_DEX_TRANSACTION_FEES.CHARGE (                                                                                            
                                         myRetMesg  => myRe                                                                         
tMesg                                                                                                                               
                                        ,myRetCode  => myRetCode                                                                    
                                        ,mySerialID => mySe                                                                         
rialID                                                                                                                              
                                        ,myLocn     => 'REC'                                                                        
                                        ,myTypeCode => myTypeC                                                                      
ode                                                                                                                                 
                                        ,myCredit   => 'N'                                                                          
                                       );                                                                                           
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            raise ABORT_PROC;                                                                                                       
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      if myTypeCode = 'DM' then                                                                                                     
         log;                                                                                                                       
         mySect := 'Track - Damage';                                                                                                
                                                                                                                                    
         begin                                                                                                                      
            select DATA                                                                                                             
                  ,nvl(SEGMENT3,'N')                                                                                                
                  ,nvl(SEGMENT4,'N')                                                                                                
            into   myDmgCode                                                                                                        
                  ,myDmgScrap                                                                                                       
                  ,myDmgFin                                                                                                         
            from   DEX_CUSTOMER_CONTROL                                                                                             
            where  CUSTOMER_ID = myCustID                                                                                           
            and    ORG_ID      = myOrgID                                                                                            
            and    TYPE        = 'DMG';                                                                                             
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myDmgCode := null;                                                                                                   
               myDmgScrap := 'Y';                                                                                                   
               myDmgFin   := 'N';                                                                                                   
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      myStorage := null;                                                                                                            
                                                                                                                                    
      if myProgCode = 'RC' then                                                                                                     
         log;                                                                                                                       
         mySect := 'Track - Route FIN';                                                                                             
                                                                                                                                    
         begin                                                                                                                      
            select 'Y'                                                                                                              
            into   myRouteFIN                                                                                                       
            from   DEX_CUSTOMER_CONTROL                                                                                             
            where  CUSTOMER_ID = myCustID                                                                                           
            and    ORG_ID      = myOrgID                                                                                            
            and    DATA        = myTypeCode                                                                                         
            and    TYPE        = 'DQR';               -- Route to F                                                                 
inished Goods based on Type Code                                                                                                    
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myRouteFIN := 'N';                                                                                                   
         end;                                                                                                                       
                                                                                                                                    
         if myTypeCode in ('UN','OB','DQ','SU') then                                                                                
            if myXDockLocn is null then                                                                                             
               myLocn := 'RCP';                                                                                                     
            else                                                                                                                    
               myLocn := myXDockLocn;              -- Set                                                                           
By Bulk Cross Dock Receiving Form to route units dir                                                                                
ectly to PCK or RLB                                                                                                                 
            end if;                                                                                                                 
                                                                                                                                    
         elsif myTypeCode = 'DM' and myDmgCode = 'RET' then                                                                         
            myLocn := 'RCP';                                                                                                        
                                                                                                                                    
         elsif mySchdFlag = 'D' then                                                                                                
            myLocn := 'RCT';                                                                                                        
                                                                                                                                    
         elsif myDirect = 'Y' then                                                                                                  
            myLocn := 'RCT';                                                                                                        
                                                                                                                                    
         else                                                                                                                       
            myLocn := 'RCH';                                                                                                        
         end if;                                                                                                                    
                                                                                                                                    
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'Track - Locn';                                                                                                  
                                                                                                                                    
         if myRelabel = 'Y' then                                                                                                    
            myLocn := 'RLB';                                                                                                        
                                                                                                                                    
         elsif myXDockLocn is not null then              -- Set by OCD C                                                            
ust Ctrl and Different Line Org versus Plant Repair                                                                                 
Org                                                                                                                                 
            myLocn := myXDockLocn;                                                                                                  
                                                                                                                                    
         elsif myRecvXprs = 'N' then                     -- QCRe                                                                    
cv Required if REX Cust Ctrl Not Set                                                                                                
            myLocn := 'QCR';                                                                                                        
                                                                                                                                    
         elsif myGrp = 'LOG' then                                                                                                   
            myLocn := 'LGI';                                                                                                        
                                                                                                                                    
         elsif (myTranCode = 'MS' and mySchdFlag != 'D') or mySchdFlag = 'W'                                                        
then                                                                                                                                
            myLocn := 'WPO';                                                                                                        
                                                                                                                                    
         elsif myProgCode = 'TD' then                                                                                               
            myLocn    := 'DNI';                                                                                                     
            myStorage := 'RCV-XPRS';                                                                                                
                                                                                                                                    
         else                                                                                                                       
            log;                                                                                                                    
            mySect := 'Proc - Find Locn';                                                                                           
                                                                                                                                    
            myLocn := F_DEX_PROD_LOCN ( myIOrgID,myItemID,myCItemID,m                                                               
yGrp,'N' );                                                                                                                         
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Putaway';                                                                                                  
                                                                                                                                    
      if myPutaway = 'Y' then                                                                                                       
         K_DEX_PUTAWAY.DEFECTIVE (                                                                                                  
                                   myStorage  => myS                                                                                
torage                                                                                                                              
                                  ,myCustID   => myCustID                                                                           
                                  ,myItemID   => myItemID                                                                           
                                  ,myPlantID  => myPlantID                                                                          
                                  ,myType     => 'R'                                                                                
                                                                                                                                    
                                  ,myLocn     => myLocn                                                                             
                                  ,myTypeCode => myTypeCode                                                                         
                                 );                                                                                                 
      end if;                                                                                                                       
                                                                                                                                    
      if myProgCode = 'RC' and myStorage is null then                                                                               
         myStorage := 'STAGE';                                                                                                      
      end if;                                                                                                                       
                                                                                                                                    
      if myUOM = 'LT' and myLotCntInd = 'Y' and myParent = 'TTEECT' th                                                              
en                                                                                                                                  
         myFeeOverride := null;        --reset because want to use normal l                                                         
ogic at ship.                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Update Serials (Stage)';                                                                                   
                                                                                                                                    
      update DEX_SERIALS set                                                                                                        
      LOCATION     = nvl(myLocn,LOCATION)                                                                                           
     ,STORAGE      = myStorage                                                                                                      
     ,ROUTE_CODE   = myRouteCode                                                                                                    
     ,DATELOC      = SYSDATE                                                                                                        
     ,SCRAP        = decode(myTypeCode,'DM',myDmgScrap,'N                                                                           
')                                                                                                                                  
     ,TYPE_CODE    = myTypeCode                 -- this is needed because f                                                         
irst call to QCRECV AOL may overwrite type code to O                                                                                
B.                                                                                                                                  
     ,PALLET_ID    = myPalletID                                                                                                     
     ,FEE_OVERRIDE = myFeeOverride                                                                                                  
     ,LABEL_DATA1  = null                                                                                                           
     ,LABEL_DATA2  = null                                                                                                           
     ,ORIG_SERIAL  = SERIAL                                                                                                         
     ,SCHEDULE_ID  = null                                                                                                           
     ,REASON       = decode(REASON,null,'NOT SORTED',REASO                                                                          
N)                                                                                                                                  
--     ,PUTAWAY_FLAG = myPutaway                                                                                                    
      where SERIAL_ID = mySerialID;                                                                                                 
                                                                                                                                    
      -- Out of Warranty Logic (OOW) Control                                                                                        
      log;                                                                                                                          
      mySect := 'Track - OOW Control';                                                                                              
                                                                                                                                    
      P_DEX_SERIAL_OOW ( mySerialID );                                                                                              
                                                                                                                                    
      if myProgCode = 'RC' then                                                                                                     
         log;                                                                                                                       
         mySect := 'Track - Custom Callout';                                                                                        
                                                                                                                                    
         myRtnRouteCode := XXDEX_CUSTOMER_CALLOUT_K.RECV_ROUTE_                                                                     
CODE ( myParent,mySerialID );                                                                                                       
                                                                                                                                    
         if (myTypeCode = 'OB' or myRtnRouteCode is not null or myDmgFin                                                            
= 'Y' or myRouteFin = 'Y') and myXDockLocn is null t                                                                                
hen                                                                                                                                 
            log;                                                                                                                    
            mySect := 'Track - Tran ID';                                                                                            
                                                                                                                                    
            select TRANSACTION_S.nextval                                                                                            
            into   myTranID                                                                                                         
            from   DUAL;                                                                                                            
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Track - Serial Tran';                                                                                        
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            TRAN_ID = myTranID                                                                                                      
            where SERIAL_ID = mySerialID;                                                                                           
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Track - Pack';                                                                                               
                                                                                                                                    
            K_DEX_RECERT.PACK (                                                                                                     
                                myRetMesg  => myRetMesg                                                                             
                               ,myRetCode  => myRetCode                                                                             
                               ,myUserID   => myUserID                                                                              
                               ,mySerialID => mySerialID                                                                            
                               ,myPalletID => null                                                                                  
                               ,myBoxDIM   => null                                                                                  
                               ,myTranID   => myTranID                                                                              
                               ,myEmpNo    => myEmpNo                                                                               
                               ,myCPrice   => myPrice                                                                               
                               ,myAction   => 'Accept'                                                                              
                              );                                                                                                    
                                                                                                                                    
            if myRetCode > 0 then                                                                                                   
               raise ABORT_PROC;                                                                                                    
            end if;                                                                                                                 
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      if mySTSNum is not null then                                                                                                  
         P_DEX_SUBMIT_SYNC_STS ( mySTSNum );                                                                                        
      end if;                                                                                                                       
                                                                                                                                    
      if myNotify = 'Y' and myEMail is not null then                                                                                
         log;                                                                                                                       
         mySect := 'Track - Notify';                                                                                                
                                                                                                                                    
         mySubj := 'RMA ' || myPBNum || ' has been received ('                                                                      
|| myCust || ')';                                                                                                                   
                                                                                                                                    
         myMesg := null;                                                                                                            
                                                                                                                                    
         myMesg := myMesg || 'We have received your unit(s)                                                                         
 sent on RMA ' || myPBNum || '.' || chr(10);                                                                                        
         myMesg := myMesg || 'Please reference Order Number                                                                         
 ' || myOrder || ' if further status is needed.' ||                                                                                 
chr(10);                                                                                                                            
                                                                                                                                    
         if myCmt is not null then                                                                                                  
            myMesg := myMesg || chr(10);                                                                                            
            myMesg := myMesg || 'Order Comments' || chr(10);                                                                        
            myMesg := myMesg || replace(myCmt,':') || chr(10)                                                                       
;                                                                                                                                   
         end if;                                                                                                                    
                                                                                                                                    
         myMesg := myMesg || chr(10);                                                                                               
         myMesg := myMesg || 'Thank you for your business.' || chr(10);                                                             
                                                                                                                                    
         K_DEX_MAIL.SEND ( DEX_ORG_EMAILS_F ( 'CUST_SERVICE' ),myEMail,null,n                                                       
ull,mySubj,myMesg );                                                                                                                
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Complete';                                                                                                 
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when ABORT_PROC then                                                                                                          
         myRetCode := 1;                                                                                                            
                                                                                                                                    
         -- rollback to TRACK_SAVEPOINT;   rollbacks handled in calling p                                                           
rogram                                                                                                                              
                                                                                                                                    
                                                                                                                                    
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
         myRetCode := 2;                                                                                                            
                                                                                                                                    
         -- rollback to TRACK_SAVEPOINT;   rollbacks handled in calling prog                                                        
ram                                                                                                                                 
   end TRACK;                                                                                                                       
                                                                                                                                    
  /********************************************************                                                                         
**************************/                                                                                                         
                                                                                                                                    
   procedure BULK_CHCK (                                                                                                            
                         myRetMesg  out varchar2                                                                                    
                        ,myRetCode  out number                                                                                      
                        ,myNum      out number                                                                                      
                        ,myPlantID  in  number                                                                                      
                        ,myLPlateID in  number default null                                                                         
                        ,myShipID   in  number default null                                                                         
                        ,myPalletID in  number defau                                                                                
lt null                                                                                                                             
                       ) is                                                                                                         
      myXPlantID  number(15);                                                                                                       
                                                                                                                                    
      ABORT_PROC  exception;                                                                                                        
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select rmh.PLANT_ID                                                                                                        
               ,count('*')    NUM                                                                                                   
         from   DEX_RMAHDR rmh                                                                                                      
               ,DEX_SERIALS ser                                                                                                     
         where  ser.RMA_NUMBER       = rmh.CALL                                                                                     
         and    rmh.STATUS           = 'O'                                                                                          
         and    ser.LICENSE_PLATE_ID = myLPlateID                                                                                   
         and    ser.LOCATION         = 'SHP'                                                                                        
         group by rmh.PLANT_ID;                                                                                                     
                                                                                                                                    
      cursor c2 is                                                                                                                  
         select rmh.PLANT_ID                                                                                                        
               ,count('*')    NUM                                                                                                   
         from   DEX_RMAHDR rmh                                                                                                      
               ,DEX_SERIALS ser                                                                                                     
         where  ser.RMA_NUMBER = rmh.CALL                                                                                           
         and    rmh.STATUS     = 'O'                                                                                                
         and    ser.SHIP_ID    = myShipID                                                                                           
         and    ser.LOCATION   = 'SHP'                                                                                              
         group by rmh.PLANT_ID;                                                                                                     
                                                                                                                                    
      cursor c3 is                                                                                                                  
         select rmh.PLANT_ID                                                                                                        
               ,count('*')    NUM                                                                                                   
         from   DEX_RMAHDR rmh                                                                                                      
               ,DEX_SERIALS ser                                                                                                     
         where  ser.RMA_NUMBER = rmh.CALL                                                                                           
         and    rmh.STATUS     = 'O'                                                                                                
         and    ser.PALLET_ID  = myPalletID                                                                                         
         and    ser.LOCATION   = 'SHP'                                                                                              
         group by rmh.PLANT_ID;                                                                                                     
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
      myNum := 0;                                                                                                                   
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'BulkChck - Init';                                                                                                  
                                                                                                                                    
      if myLPlateID > 0 then                                                                                                        
         mySect := 'BulkChck - LPlate';                                                                                             
                                                                                                                                    
         for c1r in c1 loop                                                                                                         
            if myXPlantID is not null then                                                                                          
               FND_MESSAGE.SET_NAME ( DEX_APP_F,'PLA                                                                                
NT_MULTIPLE' );                                                                                                                     
               myRetMesg := FND_MESSAGE.GET;                                                                                        
               raise ABORT_PROC;                                                                                                    
                                                                                                                                    
            elsif c1r.PLANT_ID != myPlantID then                                                                                    
               FND_MESSAGE.SET_NAME ( DEX_APP_F,'PLANT_INCORRECT                                                                    
' );                                                                                                                                
               myRetMesg := FND_MESSAGE.GET;                                                                                        
               raise ABORT_PROC;                                                                                                    
            end if;                                                                                                                 
                                                                                                                                    
            myXPlantID := c1r.PLANT_ID;                                                                                             
            myNum      := c1r.NUM;                                                                                                  
         end loop;                                                                                                                  
                                                                                                                                    
      elsif myShipID > 0 then                                                                                                       
         mySect := 'BulkChck - Ship ID';                                                                                            
                                                                                                                                    
         for c2r in c2 loop                                                                                                         
            if myXPlantID is not null then                                                                                          
               FND_MESSAGE.SET_NAME ( DEX_APP_F,'PLANT_MULTIPLE' );                                                                 
               myRetMesg := FND_MESSAGE.GET;                                                                                        
               raise ABORT_PROC;                                                                                                    
                                                                                                                                    
            elsif c2r.PLANT_ID != myPlantID then                                                                                    
               FND_MESSAGE.SET_NAME ( DEX_APP_F,'PLANT_INCOR                                                                        
RECT' );                                                                                                                            
               myRetMesg := FND_MESSAGE.GET;                                                                                        
               raise ABORT_PROC;                                                                                                    
            end if;                                                                                                                 
                                                                                                                                    
            myXPlantID := c2r.PLANT_ID;                                                                                             
            myNum      := c2r.NUM;                                                                                                  
         end loop;                                                                                                                  
                                                                                                                                    
      elsif myPalletID > 0 then                                                                                                     
         mySect := 'BulkChck - Pallet ID';                                                                                          
                                                                                                                                    
         for c3r in c3 loop                                                                                                         
            if myXPlantID is not null then                                                                                          
               FND_MESSAGE.SET_NAME ( DEX_APP_F,'PLANT_MULTIPLE' )                                                                  
;                                                                                                                                   
               myRetMesg := FND_MESSAGE.GET;                                                                                        
               raise ABORT_PROC;                                                                                                    
                                                                                                                                    
            elsif c3r.PLANT_ID != myPlantID then                                                                                    
               FND_MESSAGE.SET_NAME ( DEX_APP_F,'PLA                                                                                
NT_INCORRECT' );                                                                                                                    
               myRetMesg := FND_MESSAGE.GET;                                                                                        
               raise ABORT_PROC;                                                                                                    
            end if;                                                                                                                 
                                                                                                                                    
            myXPlantID := c3r.PLANT_ID;                                                                                             
            myNum      := c3r.NUM;                                                                                                  
         end loop;                                                                                                                  
                                                                                                                                    
      else                                                                                                                          
         FND_MESSAGE.SET_NAME ( DEX_APP_F,'RECV_XPRS_BULK_CHCK'                                                                     
);                                                                                                                                  
         myRetMesg := FND_MESSAGE.GET;                                                                                              
         raise ABORT_PROC;                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'BulkChck - Complete';                                                                                              
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when ABORT_PROC then                                                                                                          
         myRetCode := 1;                                                                                                            
                                                                                                                                    
         rollback;                                                                                                                  
                                                                                                                                    
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
         myRetCode := 2;                                                                                                            
                                                                                                                                    
         rollback;                                                                                                                  
   end BULK_CHCK;                                                                                                                   
                                                                                                                                    
  /************************************************************************                                                         
**********/                                                                                                                         
                                                                                                                                    
   procedure BULK_PROC (                                                                                                            
                         myRetMesg  out varchar2                                                                                    
                        ,myRetCode  out number                                                                                      
                        ,myPlantID  in  number                                                                                      
                        ,myUserID   in  number                                                                                      
                        ,myEmpNo    in  varchar2                                                                                    
                        ,myWaybill  in  varchar2                                                                                    
                        ,myLPlateID in  number default null                                                                         
                        ,myShipID   in  number default n                                                                            
ull                                                                                                                                 
                        ,myPalletID in  number default null                                                                         
                       ) is                                                                                                         
      myDirect       varchar2(1);                                                                                                   
      myXDockLocn    varchar2(3);                                                                                                   
      myCrossDock    varchar2(3) := XXDEX_DEFAULTS_F ( 'REPAIR_PLANT_CROSS                                                          
_DOCK' );                                                                                                                           
                                                                                                                                    
      mySerialID     number(15);                                                                                                    
      myRPlantID     number(15);                                                                                                    
                                                                                                                                    
      myOrder        DEX_ORDERS.ORDERNO%type;                                                                                       
                                                                                                                                    
      myItem         DEX_SERIALS.ITEM%type;                                                                                         
                                                                                                                                    
      myOrdFlex      DESC_FLEX_REC_TYPE;                                                                                            
      myLneFlex      DESC_FLEX_REC_TYPE;                                                                                            
      mySrlFlex      DESC_FLEX_REC_TYPE;                                                                                            
                                                                                                                                    
      ABORT_PROC     exception;                                                                                                     
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select rmh.CALL                                                                                                            
               ,rmh.CUSTPO                                                                                                          
               ,rmh.RELEASE                                                                                                         
               ,rmh.PRICE_TYPE_CODE                                                                                                 
               ,rmh.PAYMENT_OPTION                                                                                                  
               ,rmh.ORDTYPE                                                                                                         
               ,rmh.PLANT                                                                                                           
               ,rmh.PLANT_ID                                                                                                        
               ,rmh.ORG_ID                                                                                                          
               ,rmh.BILL_SITE_USE_ID                                                                                                
               ,rmh.SHIP_SITE_USE_ID                                                                                                
               ,rmh.CUSTOMER_ID                                                                                                     
               ,cus.CUSTOMER_NUMBER                                                                                                 
               ,cus.CUSTOMER_NAME                                                                                                   
               ,cus.PARENT_CODE                                                                                                     
               ,lne.PART                                                                                                            
               ,lne.CUSTPART                                                                                                        
               ,lne.PRICE                                                                                                           
               ,lne.HOLD_CODE                                                                                                       
               ,lne.CUSTOMER_ITEM_ID                                                                                                
               ,lne.INVENTORY_ITEM_ID                                                                                               
               ,lne.ORGANIZATION_ID                                                                                                 
               ,lne.REPAIR_PLANT_ID                                                                                                 
               ,ser.ITEM                                                                                                            
               ,ser.TRACK                                                                                                           
               ,ser.TAG_NUMBER                                                                                                      
               ,ser.TYPE_CODE                                                                                                       
               ,rmh.ATTRIBUTE_CATEGORY    ORDER_ATTRIBUTE_CATEGO                                                                    
RY                                                                                                                                  
               ,rmh.ATTRIBUTE1            ORDER_ATTRIBUTE1                                                                          
               ,rmh.ATTRIBUTE2            ORDER_ATTRIBUTE2                                                                          
               ,rmh.ATTRIBUTE3            ORDER_ATTRIBUTE3                                                                          
               ,rmh.ATTRIBUTE4            ORDER_ATTRIB                                                                              
UTE4                                                                                                                                
               ,rmh.ATTRIBUTE5            ORDER_ATTRIBUTE5                                                                          
               ,rmh.ATTRIBUTE6            ORDER_ATTRIBUTE6                                                                          
               ,rmh.ATTRIBUTE7            ORDER_ATTRIBUTE7                                                                          
               ,rmh.ATTRIBUTE8            ORDER_ATTR                                                                                
IBUTE8                                                                                                                              
               ,rmh.ATTRIBUTE9            ORDER_ATTRIBUTE9                                                                          
               ,rmh.ATTRIBUTE10           ORDER_ATTRIBUTE10                                                                         
               ,rmh.ATTRIBUTE11           ORDER_ATTRIBUT                                                                            
E11                                                                                                                                 
               ,rmh.ATTRIBUTE12           ORDER_ATTRIBUTE12                                                                         
               ,rmh.ATTRIBUTE13           ORDER_ATTRIBUTE13                                                                         
               ,rmh.ATTRIBUTE14           ORDER_ATTRIBUTE1                                                                          
4                                                                                                                                   
               ,rmh.ATTRIBUTE15           ORDER_ATTRIBUTE15                                                                         
               ,rmh.ATTRIBUTE16           ORDER_ATTRIBUTE16                                                                         
               ,rmh.ATTRIBUTE17           ORDER_ATTRIBUTE17                                                                         
               ,rmh.ATTRIBUTE18           ORDER_ATTR                                                                                
IBUTE18                                                                                                                             
               ,rmh.ATTRIBUTE19           ORDER_ATTRIBUTE19                                                                         
               ,rmh.ATTRIBUTE20           ORDER_ATTRIBUTE20                                                                         
               ,rmh.ATTRIBUTE21           ORDER_ATTRIB                                                                              
UTE21                                                                                                                               
               ,rmh.ATTRIBUTE22           ORDER_ATTRIBUTE22                                                                         
               ,rmh.ATTRIBUTE23           ORDER_ATTRIBUTE23                                                                         
               ,rmh.ATTRIBUTE24           ORDER_ATTRIBUT                                                                            
E24                                                                                                                                 
               ,rmh.ATTRIBUTE25           ORDER_ATTRIBUTE25                                                                         
               ,rmh.ATTRIBUTE26           ORDER_ATTRIBUTE26                                                                         
               ,rmh.ATTRIBUTE27           ORDER_ATTRIBUTE2                                                                          
7                                                                                                                                   
               ,rmh.ATTRIBUTE28           ORDER_ATTRIBUTE28                                                                         
               ,rmh.ATTRIBUTE29           ORDER_ATTRIBUTE29                                                                         
               ,rmh.ATTRIBUTE30           ORDER_ATTRIBUTE30                                                                         
               ,rmh.ATTRIBUTE31           ORDER_ATTR                                                                                
IBUTE31                                                                                                                             
               ,rmh.ATTRIBUTE32           ORDER_ATTRIBUTE32                                                                         
               ,rmh.ATTRIBUTE33           ORDER_ATTRIBUTE33                                                                         
               ,rmh.ATTRIBUTE34           ORDER_ATTRIB                                                                              
UTE34                                                                                                                               
               ,rmh.ATTRIBUTE35           ORDER_ATTRIBUTE35                                                                         
               ,rmh.ATTRIBUTE36           ORDER_ATTRIBUTE36                                                                         
               ,rmh.ATTRIBUTE37           ORDER_ATTRIBUT                                                                            
E37                                                                                                                                 
               ,rmh.ATTRIBUTE38           ORDER_ATTRIBUTE38                                                                         
               ,rmh.ATTRIBUTE39           ORDER_ATTRIBUTE39                                                                         
               ,rmh.ATTRIBUTE40           ORDER_ATTRIBUTE4                                                                          
0                                                                                                                                   
               ,lne.ATTRIBUTE_CATEGORY    LINE_ATTRIBUTE_CATEGORY                                                                   
               ,lne.ATTRIBUTE1            LINE_ATTRIBUTE1                                                                           
               ,lne.ATTRIBUTE2            LINE_ATTRIBUTE                                                                            
2                                                                                                                                   
               ,lne.ATTRIBUTE3            LINE_ATTRIBUTE3                                                                           
               ,lne.ATTRIBUTE4            LINE_ATTRIBUTE4                                                                           
               ,lne.ATTRIBUTE5            LINE_ATTRIBUTE5                                                                           
               ,lne.ATTRIBUTE6            LINE_ATTRIBUTE6                                                                           
               ,lne.ATTRIBUTE7            LINE_ATTRI                                                                                
BUTE7                                                                                                                               
               ,lne.ATTRIBUTE8            LINE_ATTRIBUTE8                                                                           
               ,lne.ATTRIBUTE9            LINE_ATTRIBUTE9                                                                           
               ,lne.ATTRIBUTE10           LINE_ATTRIBUTE10                                                                          
               ,lne.ATTRIBUTE11           LINE_ATTRIB                                                                               
UTE11                                                                                                                               
               ,lne.ATTRIBUTE12           LINE_ATTRIBUTE12                                                                          
               ,lne.ATTRIBUTE13           LINE_ATTRIBUTE13                                                                          
               ,lne.ATTRIBUTE14           LINE_ATTRIBUTE14                                                                          
                                                                                                                                    
               ,lne.ATTRIBUTE15           LINE_ATTRIBUTE15                                                                          
               ,ser.ATTRIBUTE_CATEGORY    SERIAL_ATTRIBUTE_CATEGORY                                                                 
               ,ser.ATTRIBUTE1            SERIAL_ATTRI                                                                              
BUTE1                                                                                                                               
               ,ser.ATTRIBUTE2            SERIAL_ATTRIBUTE2                                                                         
               ,ser.ATTRIBUTE3            SERIAL_ATTRIBUTE3                                                                         
               ,ser.ATTRIBUTE4            SERIAL_ATTRIBU                                                                            
TE4                                                                                                                                 
               ,ser.ATTRIBUTE5            SERIAL_ATTRIBUTE5                                                                         
               ,ser.ATTRIBUTE6            SERIAL_ATTRIBUTE6                                                                         
               ,ser.ATTRIBUTE7            SERIAL_ATTRIBUTE                                                                          
7                                                                                                                                   
               ,ser.ATTRIBUTE8            SERIAL_ATTRIBUTE8                                                                         
               ,ser.ATTRIBUTE9            SERIAL_ATTRIBUTE9                                                                         
               ,ser.ATTRIBUTE10           SERIAL_ATTRIBUTE10                                                                        
                                                                                                                                    
               ,ser.ATTRIBUTE11           SERIAL_ATTRIBUTE11                                                                        
               ,ser.ATTRIBUTE12           SERIAL_ATTRIBUTE12                                                                        
               ,ser.ATTRIBUTE13           SERIAL_ATTRIBUTE1                                                                         
3                                                                                                                                   
               ,ser.ATTRIBUTE14           SERIAL_ATTRIBUTE14                                                                        
               ,ser.ATTRIBUTE15           SERIAL_ATTRIBUTE15                                                                        
               ,ser.ATTRIBUTE16           SERIAL_ATTRIBUTE                                                                          
16                                                                                                                                  
               ,ser.ATTRIBUTE17           SERIAL_ATTRIBUTE17                                                                        
               ,ser.ATTRIBUTE18           SERIAL_ATTRIBUTE18                                                                        
               ,ser.ATTRIBUTE19           SERIAL_ATTRIBUT                                                                           
E19                                                                                                                                 
               ,ser.ATTRIBUTE20           SERIAL_ATTRIBUTE20                                                                        
               ,ser.ATTRIBUTE21           SERIAL_ATTRIBUTE21                                                                        
               ,ser.ATTRIBUTE22           SERIAL_ATTRIBU                                                                            
TE22                                                                                                                                
               ,ser.ATTRIBUTE23           SERIAL_ATTRIBUTE23                                                                        
               ,ser.ATTRIBUTE24           SERIAL_ATTRIBUTE24                                                                        
               ,ser.ATTRIBUTE25           SERIAL_ATTRIB                                                                             
UTE25                                                                                                                               
         from   XXDEX_CUSTOMERS_DATA_V cus                                                                                          
               ,DEX_RMAHDR rmh                                                                                                      
               ,DEX_LINES lne                                                                                                       
               ,DEX_SERIALS ser                                                                                                     
         where  ser.ORDERNO          = lne.ORDERNO                                                                                  
         and    ser.ITEM             = lne.ITEM                                                                                     
         and    ser.RMA_NUMBER       = rmh.CALL                                                                                     
         and    rmh.CUSTOMER_ID      = cus.CUSTOMER_ID                                                                              
         and    rmh.ORG_ID           = cus.ORG_ID                                                                                   
         and    rmh.STATUS           = 'O'                                                                                          
         and    nvl(ser.LICENSE_PLATE_ID,0) = nvl(myLPlat                                                                           
eID,nvl(ser.LICENSE_PLATE_ID,0))                                                                                                    
         and    ser.SHIP_ID          = nvl(myShipID, ser.SHIP_ID)                                                                   
         and    nvl(ser.PALLET_ID,0) = nvl(myPalletID, nv                                                                           
l(ser.PALLET_ID,0))                                                                                                                 
         and    ser.LOCATION         = 'SHP';                                                                                       
                                                                                                                                    
      cursor c2 ( myCItemID number,myItemID number ) is                                                                             
         select nvl(DIRECT_TO_RCT_FLAG,'N')  DIRECT_FLAG                                                                            
         from   DEX_CUST_ITEM_XREFS_DATA_V                                                                                          
         where  CUSTOMER_ITEM_ID  = myCItemID                                                                                       
         and    INVENTORY_ITEM_ID = myItemID                                                                                        
         order by PREFERENCE_NUMBER;                                                                                                
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
      mySect := 'BulkProc - Start';                                                                                                 
      log;                                                                                                                          
      mySect := 'BulkProc - Check';                                                                                                 
                                                                                                                                    
      if myLPlateID is null and myShipID is null and                                                                                
 myPalletID is null then                                                                                                            
         FND_MESSAGE.SET_NAME ( DEX_APP_F,'RECV_XPRS_                                                                               
BULK_CHCK' );                                                                                                                       
         myRetMesg := FND_MESSAGE.GET;                                                                                              
                                                                                                                                    
         raise ABORT_PROC;                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         mySect := 'BulkProc - Repair Plant ID';                                                                                    
                                                                                                                                    
         myRPlantID := c1r.REPAIR_PLANT_ID;                                                                                         
                                                                                                                                    
         XXDEX_PROCESS_K.REPAIR_ROUTING (                                                                                           
                                          myRetCode                                                                                 
 => myRetCode                                                                                                                       
                                         ,myRetMesg    => myRetM                                                                    
esg                                                                                                                                 
                                         ,myRepPlantID => myRPlantID                                                                
                                         ,myOrdType    =>                                                                           
 c1r.ORDTYPE                                                                                                                        
                                         ,myRetPlantID => myPlant                                                                   
ID                                                                                                                                  
                                         ,myReasonCd   => c1r.PRICE_TYPE_CO                                                         
DE                                                                                                                                  
                                         ,myItemID     => c1r.INVENTORY_ITE                                                         
M_ID                                                                                                                                
                                        );                                                                                          
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            raise ABORT_PROC;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         mySect := 'BulkProc - Direct';                                                                                             
                                                                                                                                    
         myDirect := 'N';                                                                                                           
                                                                                                                                    
         for c2r in c2 ( c1r.CUSTOMER_ITEM_ID,c1r.INVENTORY_ITEM                                                                    
_ID ) loop                                                                                                                          
            myDirect := c2r.DIRECT_FLAG;                                                                                            
                                                                                                                                    
            exit;                                                                                                                   
         end loop;                                                                                                                  
                                                                                                                                    
         mySect := 'BulkProc - Cross Dock';                                                                                         
                                                                                                                                    
         myXDockLocn := null;                                                                                                       
                                                                                                                                    
         if myCrossDock is not null and myRPlantID != myPlantID the                                                                 
n                                                                                                                                   
            myXDockLocn := myCrossDock;                                                                                             
         end if;                                                                                                                    
                                                                                                                                    
         mySect := 'BulkProc - Order Flex';                                                                                         
                                                                                                                                    
         myOrdFlex.ATTRIBUTE1  := c1r.ORDER_ATTRIBUTE1;                                                                             
         myOrdFlex.ATTRIBUTE2  := c1r.ORDER_ATTRIBUTE2;                                                                             
         myOrdFlex.ATTRIBUTE3  := c1r.ORDER_ATTRIBUTE3;                                                                             
         myOrdFlex.ATTRIBUTE4  := c1r.ORDER_ATTRIBUTE4;                                                                             
         myOrdFlex.ATTRIBUTE5  := c1r.ORDER_ATTRIBUTE5;                                                                             
         myOrdFlex.ATTRIBUTE6  := c1r.ORDER_ATTRIBUTE6;                                                                             
         myOrdFlex.ATTRIBUTE7  := c1r.ORDER_ATTRIBUTE                                                                               
7;                                                                                                                                  
         myOrdFlex.ATTRIBUTE8  := c1r.ORDER_ATTRIBUTE8;                                                                             
         myOrdFlex.ATTRIBUTE9  := c1r.ORDER_ATTRIBUTE9;                                                                             
         myOrdFlex.ATTRIBUTE10 := c1r.ORDER_ATTRIBUTE10;                                                                            
         myOrdFlex.ATTRIBUTE11 := c1r.ORDER_ATTRIBUTE11;                                                                            
         myOrdFlex.ATTRIBUTE12 := c1r.ORDER_ATTRIBUTE12;                                                                            
         myOrdFlex.ATTRIBUTE13 := c1r.ORDER_ATTRIBUT                                                                                
E13;                                                                                                                                
         myOrdFlex.ATTRIBUTE14 := c1r.ORDER_ATTRIBUTE14;                                                                            
         myOrdFlex.ATTRIBUTE15 := c1r.ORDER_ATTRIBUTE15;                                                                            
         myOrdFlex.ATTRIBUTE16 := c1r.ORDER_ATTRIBUTE16;                                                                            
         myOrdFlex.ATTRIBUTE17 := c1r.ORDER_ATTRIBUTE17;                                                                            
         myOrdFlex.ATTRIBUTE18 := c1r.ORDER_ATTRIBUTE                                                                               
18;                                                                                                                                 
         myOrdFlex.ATTRIBUTE19 := c1r.ORDER_ATTRIBUTE19;                                                                            
         myOrdFlex.ATTRIBUTE20 := c1r.ORDER_ATTRIBUTE20;                                                                            
         myOrdFlex.ATTRIBUTE21 := c1r.ORDER_ATTRIBUTE21;                                                                            
         myOrdFlex.ATTRIBUTE22 := c1r.ORDER_ATTRIBUTE22;                                                                            
         myOrdFlex.ATTRIBUTE23 := c1r.ORDER_ATTRIBUTE2                                                                              
3;                                                                                                                                  
         myOrdFlex.ATTRIBUTE24 := c1r.ORDER_ATTRIBUTE24;                                                                            
         myOrdFlex.ATTRIBUTE25 := c1r.ORDER_ATTRIBUTE25;                                                                            
         myOrdFlex.ATTRIBUTE26 := c1r.ORDER_ATTRIBUTE26;                                                                            
         myOrdFlex.ATTRIBUTE27 := c1r.ORDER_ATTRIBUTE27;                                                                            
         myOrdFlex.ATTRIBUTE28 := c1r.ORDER_ATTRIBUTE28                                                                             
;                                                                                                                                   
         myOrdFlex.ATTRIBUTE29 := c1r.ORDER_ATTRIBUTE29;                                                                            
         myOrdFlex.ATTRIBUTE30 := c1r.ORDER_ATTRIBUTE30;                                                                            
         myOrdFlex.ATTRIBUTE31 := c1r.ORDER_ATTRIBUTE31;                                                                            
         myOrdFlex.ATTRIBUTE32 := c1r.ORDER_ATTRIBUTE32;                                                                            
         myOrdFlex.ATTRIBUTE33 := c1r.ORDER_ATTRIBUTE33;                                                                            
                                                                                                                                    
         myOrdFlex.ATTRIBUTE34 := c1r.ORDER_ATTRIBUTE34;                                                                            
         myOrdFlex.ATTRIBUTE35 := c1r.ORDER_ATTRIBUTE35;                                                                            
         myOrdFlex.ATTRIBUTE36 := c1r.ORDER_ATTRIBUTE36;                                                                            
         myOrdFlex.ATTRIBUTE37 := c1r.ORDER_ATTRIBUTE37;                                                                            
         myOrdFlex.ATTRIBUTE38 := c1r.ORDER_ATTRIBUTE38;                                                                            
         myOrdFlex.ATTRIBUTE39 := c1r.ORDER_ATTRIBUT                                                                                
E39;                                                                                                                                
         myOrdFlex.ATTRIBUTE40 := c1r.ORDER_ATTRIBUTE40;                                                                            
                                                                                                                                    
         mySect := 'BulkProc - Line Flex';                                                                                          
                                                                                                                                    
         myLneFlex.ATTRIBUTE1  := c1r.LINE_ATTRIBUTE1;                                                                              
         myLneFlex.ATTRIBUTE2  := c1r.LINE_ATTRIBUTE2;                                                                              
         myLneFlex.ATTRIBUTE3  := c1r.LINE_ATTRIBUTE3;                                                                              
         myLneFlex.ATTRIBUTE4  := c1r.LINE_ATTRIBUTE4;                                                                              
         myLneFlex.ATTRIBUTE5  := c1r.LINE_ATTRIBUTE5;                                                                              
         myLneFlex.ATTRIBUTE6  := c1r.LINE_ATTRIBUTE6;                                                                              
         myLneFlex.ATTRIBUTE7  := c1r.LINE_ATTRIBUTE7;                                                                              
         myLneFlex.ATTRIBUTE8  := c1r.LINE_ATTRIBUTE8;                                                                              
                                                                                                                                    
         myLneFlex.ATTRIBUTE9  := c1r.LINE_ATTRIBUTE9;                                                                              
         myLneFlex.ATTRIBUTE10 := c1r.LINE_ATTRIBUTE10;                                                                             
         myLneFlex.ATTRIBUTE11 := c1r.LINE_ATTRIBUTE11;                                                                             
         myLneFlex.ATTRIBUTE12 := c1r.LINE_ATTRIBUTE12;                                                                             
         myLneFlex.ATTRIBUTE13 := c1r.LINE_ATTRIBUTE13;                                                                             
         myLneFlex.ATTRIBUTE14 := c1r.LINE_ATTRIBUTE14;                                                                             
         myLneFlex.ATTRIBUTE15 := c1r.LINE_ATTRIBUTE15                                                                              
;                                                                                                                                   
                                                                                                                                    
         mySect := 'BulkProc - Serial Flex';                                                                                        
                                                                                                                                    
         mySrlFlex.ATTRIBUTE1  := c1r.SERIAL_ATTRIBUTE1                                                                             
;                                                                                                                                   
         mySrlFlex.ATTRIBUTE2  := c1r.SERIAL_ATTRIBUTE2;                                                                            
         mySrlFlex.ATTRIBUTE3  := c1r.SERIAL_ATTRIBUTE3;                                                                            
         mySrlFlex.ATTRIBUTE4  := c1r.SERIAL_ATTRIBUTE4;                                                                            
         mySrlFlex.ATTRIBUTE5  := c1r.SERIAL_ATTRIBUTE5;                                                                            
         mySrlFlex.ATTRIBUTE6  := c1r.SERIAL_ATTRIBUTE6;                                                                            
                                                                                                                                    
         mySrlFlex.ATTRIBUTE7  := c1r.SERIAL_ATTRIBUTE7;                                                                            
         mySrlFlex.ATTRIBUTE8  := c1r.SERIAL_ATTRIBUTE8;                                                                            
         mySrlFlex.ATTRIBUTE9  := c1r.SERIAL_ATTRIBUTE9;                                                                            
         mySrlFlex.ATTRIBUTE10 := c1r.SERIAL_ATTRIBUTE10;                                                                           
         mySrlFlex.ATTRIBUTE11 := c1r.SERIAL_ATTRIBUTE11                                                                            
;                                                                                                                                   
         mySrlFlex.ATTRIBUTE12 := c1r.SERIAL_ATTRIBUTE12;                                                                           
         mySrlFlex.ATTRIBUTE13 := c1r.SERIAL_ATTRIBUTE13;                                                                           
         mySrlFlex.ATTRIBUTE14 := c1r.SERIAL_ATTRIBUTE14;                                                                           
         mySrlFlex.ATTRIBUTE15 := c1r.SERIAL_ATTRIBUTE15;                                                                           
         mySrlFlex.ATTRIBUTE16 := c1r.SERIAL_ATTRIBU                                                                                
TE16;                                                                                                                               
         mySrlFlex.ATTRIBUTE17 := c1r.SERIAL_ATTRIBUTE17;                                                                           
         mySrlFlex.ATTRIBUTE18 := c1r.SERIAL_ATTRIBUTE18;                                                                           
         mySrlFlex.ATTRIBUTE19 := c1r.SERIAL_ATTRIBUTE19;                                                                           
         mySrlFlex.ATTRIBUTE20 := c1r.SERIAL_ATTRIBUTE                                                                              
20;                                                                                                                                 
         mySrlFlex.ATTRIBUTE21 := c1r.SERIAL_ATTRIBUTE21;                                                                           
         mySrlFlex.ATTRIBUTE22 := c1r.SERIAL_ATTRIBUTE22;                                                                           
         mySrlFlex.ATTRIBUTE23 := c1r.SERIAL_ATTRIBUTE23;                                                                           
         mySrlFlex.ATTRIBUTE24 := c1r.SERIAL_ATTRIBUTE24                                                                            
;                                                                                                                                   
         mySrlFlex.ATTRIBUTE25 := c1r.SERIAL_ATTRIBUTE25;                                                                           
                                                                                                                                    
         mySect := 'BulkProc - PB Item';                                                                                            
                                                                                                                                    
         if c1r.CALL is not null then                                                                                               
            begin                                                                                                                   
               select ITEM                                                                                                          
               into   myItem                                                                                                        
               from   DEX_RMA_SERIALS                                                                                               
               where  CALL   = c1r.CALL                                                                                             
               and    SERIAL = c1r.TRACK;                                                                                           
                                                                                                                                    
            exception                                                                                                               
               when NO_DATA_FOUND then                                                                                              
                  myItem := null;                                                                                                   
            end;                                                                                                                    
                                                                                                                                    
         else                                                                                                                       
            myItem := null;                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         mySect := 'BulkProc - Track';                                                                                              
                                                                                                                                    
			mySerialID := null;                                                                                                              
                                                                                                                                    
         TRACK (                                                                                                                    
                  myRetMesg    => myRetMesg                                                                                         
                 ,myRetCode    => myRetCode                                                                                         
                 ,myOrder      => myOrder                                                                                           
                 ,mySerialID   => mySerialID                                                                                        
                 ,myEmpNo      => myEmpNo                                                                                           
                 ,myCust       => c1r.CUSTOMER_NUMBER                                                                               
                 ,myCustName   => c1r.CUSTOMER_NAME                                                                                 
                 ,myCustID     => c1r.CUSTOMER_ID                                                                                   
                 ,myBillID     => c1r.BILL_SITE_USE_ID                                                                              
                 ,myShipID     => c1r.SHIP_SITE_USE_ID                                                                              
                 ,myParent     => c1r.PARENT_CODE                                                                                   
                 ,myWaybill    => myWaybill                                                                                         
                 ,myCustPO     => c1r.CUSTPO                                                                                        
                 ,myPRelease   => c1r.RELEASE                                                                                       
                 ,myPlantID    => c1r.PLANT_ID                                                                                      
                 ,myOrgID      => c1r.ORG_ID                                                                                        
                 ,myPlant      => c1r.PLANT                                                                                         
                 ,myCPart      => c1r.CUSTPART                                                                                      
                 ,myCItemID    => c1r.CUSTOMER_ITEM_ID                                                                              
                 ,myPart       => c1r.PART                                                                                          
                 ,myItemID     => c1r.INVENTORY_ITEM_ID                                                                             
                 ,myIOrgID     => c1r.ORGANIZATION_ID                                                                               
                 ,myRPlantID   => myRPlantID                                                                                        
                 ,myTrack      => c1r.TRACK                                                                                         
                 ,myUserID     => myUserID                                                                                          
                 ,myTypeCode   => c1r.TYPE_CODE                                                                                     
                 ,myHoldCode   => c1r.HOLD_CODE                                                                                     
                 ,myTag        => c1r.TAG_NUMBER                                                                                    
                 ,myPBNum      => c1r.CALL                                                                                          
                 ,myPBItem     => myItem                                                                                            
                 ,myDirect     => myDirect                                                                                          
                 ,myXDockLocn  => myXDockLocn                                                                                       
                 ,myPalletID   => null                                                                                              
                 ,myPayOption  => c1r.PAYMENT_OPTION                                                                                
                 ,myBOMTranID  => null                                                                                              
                 ,myRtnStatCd  => null                                                                                              
                 ,myLotQty     => null                                                                                              
                 ,myLotCntInd  => null                                                                                              
                 ,myOChrgLmt   => null                                                                                              
                 ,myRMAPrice   => c1r.PRICE                                                                                         
                 ,myOrdAttrCat => c1r.ORDER_ATTRIBUTE_CATEGORY                                                                      
                 ,myOrdFlex    => myOrdFlex                                                                                         
                 ,myLneAttrCat => c1r.LINE_ATTRIBUTE_CATEGORY                                                                       
                 ,myLneFlex    => myLneFlex                                                                                         
                 ,mySrlAttrCat => c1r.SERIAL_ATTRIBUTE_CATEGO                                                                       
RY                                                                                                                                  
                 ,mySrlFlex    => mySrlFlex                                                                                         
                );                                                                                                                  
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            raise ABORT_PROC;                                                                                                       
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'BulkProc - Complete';                                                                                              
      log;                                                                                                                          
                                                                                                                                    
      commit;                                                                                                                       
                                                                                                                                    
   exception                                                                                                                        
      when ABORT_PROC then                                                                                                          
         myRetCode := 1;                                                                                                            
                                                                                                                                    
         rollback;                                                                                                                  
                                                                                                                                    
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
         myRetCode := 2;                                                                                                            
                                                                                                                                    
         rollback;                                                                                                                  
   end BULK_PROC;                                                                                                                   
                                                                                                                                    
  /*********************************************************                                                                        
*************************/                                                                                                          
                                                                                                                                    
   procedure LOG_SET is                                                                                                             
   begin                                                                                                                            
      myLog := 'Y';                                                                                                                 
      K_DEX_LOG.LOG_SET;                                                                                                            
   end LOG_SET;                                                                                                                     
                                                                                                                                    
  /********************************************************                                                                         
**************************/                                                                                                         
                                                                                                                                    
   procedure LOG_UNSET is                                                                                                           
   begin                                                                                                                            
      myLog := 'N';                                                                                                                 
      K_DEX_LOG.LOG_UNSET;                                                                                                          
   end LOG_UNSET;                                                                                                                   
                                                                                                                                    
  /*************************************************                                                                                
*********************************/                                                                                                  
                                                                                                                                    
   procedure ERROR_ROLLBACK is                                                                                                      
   begin                                                                                                                            
      rollback;                                                                                                                     
   end ERROR_ROLLBACK;                                                                                                              
                                                                                                                                    
  /***************************************************************                                                                  
*******************/                                                                                                                
                                                                                                                                    
   procedure TABLE_INIT is                                                                                                          
   begin                                                                                                                            
      if TRACK_TABLE.count > 0 then                                                                                                 
         TRACK_TABLE.delete;                                                                                                        
      end if;                                                                                                                       
   end TABLE_INIT;                                                                                                                  
                                                                                                                                    
  /**************************************************************************                                                       
********/                                                                                                                           
                                                                                                                                    
   procedure TABLE_LOAD ( myTrack varchar2 ) is                                                                                     
      myIdx    number(5);                                                                                                           
   begin                                                                                                                            
      myIdx := TRACK_TABLE.count;                                                                                                   
                                                                                                                                    
      myIdx := nvl(myIdx,0) + 1;                                                                                                    
                                                                                                                                    
      TRACK_TABLE ( myIdx ) := myTrack;                                                                                             
   end TABLE_LOAD;                                                                                                                  
                                                                                                                                    
  /************************************************************                                                                     
**********************/                                                                                                             
                                                                                                                                    
   function TABLE_COUNT return binary_integer is                                                                                    
   begin                                                                                                                            
      return ( TRACK_TABLE.count );                                                                                                 
   end TABLE_COUNT;                                                                                                                 
                                                                                                                                    
  /*****************************************************************                                                                
*****************/                                                                                                                  
   function TABLE_DATA ( myIdx binary_integer ) return varc                                                                         
har2 is                                                                                                                             
   begin                                                                                                                            
      return ( TRACK_TABLE ( myIdx ) );                                                                                             
   end TABLE_DATA;                                                                                                                  
end K_DEX_RECV_EXPRESS;                                                                                                             
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

