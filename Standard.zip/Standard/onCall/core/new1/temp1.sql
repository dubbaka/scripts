set pagesize 24
set termout on
set verify off
set feedback off
set heading on

column used_MBytes     format 999,999
column total_MBytes    format 999,999
column collect_time    format A15

select
   to_char(sysdate,'DD-MON-RR:HH24:MI') collect_time
     ,round(used_blocks*8192/1024/1024,0)  used_Mbytes
       ,round(total_blocks*8192/1024/1024,0) total_Mbytes
       from
          V$sort_segment
          where
             tablespace_name = 'TEMP'
/

