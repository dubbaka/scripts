select * from v$pq_sysstat
/
