clear breaks
clear columns
set lines 500
set pages 300
break on report
compute sum of count on report
select count(*) kount, program from v$session where type<>'BACKGROUND' group by program order by program;

set pages 500
set lines 500
column sid format 999999
column serial# format 999999
column process format 999999
column program format a50
--column sql_text format a300
--** taking longtime -> select ses.sid sid, ses.serial# serial#, ses.process process, '['||ses.us
--ername||']'||ses.program program, sql.sql_text sql_text
--** taking longtime ->   from v$session ses, v$sqltext sql
--** taking longtime ->  where ses.sql_address = sql.address
--** taking longtime ->    and ses.sql_hash_value = sql.hash_value
--** taking longtime ->  order by ses.username, ses.sid, sql.piece
--** taking longtime -> /
select sql_text
  from v$sqltext sqlt
 where (sqlt.address, sqlt.hash_value) in
       (select sesn.sql_address, sesn.sql_hash_value
          from v$session sesn
         where (sesn.sid, sesn.serial#) in
               (select ses.sid, ses.serial#
                  from v$session ses, v$process pro
                 where pro.spid=&unix_pid
                   and ses.paddr=pro.addr))
  order by sqlt.piece;

