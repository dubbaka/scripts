--------------------------------------------------------------------------------
-- SCCS INFO : archived.sql [1.6] 11/25/01 23:47:49
-- FILE INFO : archived8.sql
-- CREATED   : ckarthik
-- DATE      : 07/02/2000
-- DESC      : Displays Sess info with SQL-TEXT.
--------------------------------------------------------------------------------

CLEAR COL BREAK COMPUTE
SET PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
BREAK ON when SKIP 1
COMPUTE SUM OF count ON when

SELECT TO_CHAR(COMPLETION_TIME, 'DD-MON-YYYY') when,
       TO_CHAR(COMPLETION_TIME, 'HH24'),
       count(*) count
FROM   v$archived_log
GROUP  BY TO_CHAR(COMPLETION_TIME, 'DD-MON-YYYY'),
       TO_CHAR(COMPLETION_TIME, 'HH24')
order by 1,2
/

SET PAGES 32 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF

PROMPT
