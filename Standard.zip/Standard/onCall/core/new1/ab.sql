set pages 40
set lines 250
col machine for a18
col osuser for a12
col username for a15
col program for a31
col module for a31
select a.sid sid_sid,a.serial#,b.spid,a.username,a.module,a.sql_hash_value,to_char(a.logon_time,'DD-MON-YYYY HH24:MI:SS'),a.event from v$session a,v$process b where
a.paddr=b.addr and b.spid in
('6792',
'23005',
'24016',
'314')
order by 5;
