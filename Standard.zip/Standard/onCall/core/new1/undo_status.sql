select round(sum(bytes)/1024/1024/1024,2),status from dba_undo_extents where tablespace_name='APPS_UNDOTS1' group by status;

select sum(bytes)/1024/1024/1024 "Free Space in GB" from dba_free_space where tablespace_name='APPS_UNDOTS1';

