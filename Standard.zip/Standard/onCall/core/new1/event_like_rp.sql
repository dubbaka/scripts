set linesize 150
set pagesize 1000
col username for a12
col osuser for a12
col p1text format a10
col p2text format a10
col program format a20
set head on
select 
       w.sid, 
       p.spid, 
       x.p1,
       x.p1text, 
       x.p2, 
       x.p2text,
       nvl(w.program, nvl(p.program, '<unknown program>')) program, 
       w.username,
       w.serial#, 
       w.osuser, 
       w.process ,
 	w.sql_hash_value
from v$session w, v$session_wait x,
     v$process p
where w.sid = x.sid
and p.background is null
and w.paddr = p.addr (+)
and x.event like '&pl_enter_the_event_name'
order by sid;
