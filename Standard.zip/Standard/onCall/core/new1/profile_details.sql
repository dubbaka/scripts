set lines 132
set pages 65
ttitle center 'Profile Resource Limits' skip 2

col prof	format a25 heading 'Profile'             justify c
col res		format a25 heading 'Resource'            justify c
col lim		format a25 heading 'Limit'               justify c
accept profile_name char prompt 'Enter Profile Name :'
select profile	prof, resource_name res, limit lim
from dba_profiles
where profile=decode('&&profile_name',null,profile,'&&profile_name')
order by 1,2;

