alter system kill session '&a' immediate;
