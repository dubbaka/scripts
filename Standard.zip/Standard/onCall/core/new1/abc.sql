spool temp.log
col owner for a10
col tablespace_name for a40
col segment_name for a30
col segment_type for a30
select owner,tablespace_name,segment_name,segment_type,extents,max_extents from dba_segments where max_extents!=2147483645 and segment_type not in ('TYPE2 UNDO') order by extents
/
