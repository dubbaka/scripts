set lines 132
accept username char prompt 'Enter Username : '
column username form a30
select username, to_char(created,'MM/DD/YYYY HH24:MI:SS') creation_date, account_status, lock_date, profile
  from dba_users
 where username = '&username'
;
