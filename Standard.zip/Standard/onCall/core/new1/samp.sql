col Execution_time(Min) for a20
col user_name for a14
select p.REQUEST_ID,p.PHASE_CODE,p.STATUS_CODE,to_char(p.actual_start_date,'DD-MON-RR HH24:MI:SS') Start_time,to_char(p.actual_completion_date,'DD-MON-RR HH24:MI:SS') End_time,to_char(round(trunc(((actual_completion_date-actual_start_date)*24*60*60)/60)+(((actual_completion_date-actual_start_date)*24*60*60)-(trunc(((actual_completion_date-actual_start_date)*24*60*60)/60)*60))/100,2)) "Execution_time(Min)",fu.user_name "Submitted by" from apps.fnd_concurr
