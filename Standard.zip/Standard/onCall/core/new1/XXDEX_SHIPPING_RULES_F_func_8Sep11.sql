                                                                                                                                    
  CREATE OR REPLACE FUNCTION "APPS"."XXDEX_SHIPPING_RULES_F" ( myShipID	numbe                                                       
r                                                                                                                                   
																	,myData		varchar2 		-- E=Event, F=FlexCode, T = Ship Tpee,                                                         
I - International Flag                                                                                                              
                                                  ) ret                                                                             
urn varchar2 AUTHID CURRENT_USER is                                                                                                 
                                                                                                                                    
/* $Header: XXDEX_SHIPPING_RULES_F.sql 2.1.0.0 2010/08/05 12:00:00                                                                  
dexsys ship $ Copyright (c) 2010 DEX Systems, Inc. *                                                                                
/                                                                                                                                   
                                                                                                                                    
	myFlexCode		XXDEX_SHIPPING_RULES.SHIP_CUST_FLEX_CODE%type;                                                                         
	myEvent			XXDEX_SHIPPING_RULES.SHIP_CUST_EVENT%type;                                                                               
	myShipType		XXDEX_SHIPPING_RULES.SHIP_TYPE%type;                                                                                   
	myIntNatFlag  	XXDEX_SHIPPING_RULES.INTERNATIONAL_FLAG%type;                                                                       
                                                                                                                                    
begin                                                                                                                               
	begin                                                                                                                              
		select rul.SHIP_CUST_FLEX_CODE                                                                                                    
				,rul.SHIP_CUST_EVENT                                                                                                            
				,rul.SHIP_TYPE                                                                                                                  
				,nvl(INTERNATIONAL_FLAG,'N')                                                                                                    
		into   myFlexCode                                                                                                                 
				,myEvent                                                                                                                        
				,myShipType                                                                                                                     
				,myIntNatFlag                                                                                                                   
		from   XXDEX_SHIPPING_RULES_V rul                                                                                                 
			   ,DEX_ORDERS ord                                                                                                               
			   ,DEX_LINES lne                                                                                                                
		 		,DEX_SERIALS ser                                                                                                               
		where  ser.SHIP_ID = myShipID                                                                                                     
		and    ser.ORDERNO = lne.ORDERNO                                                                                                  
		and    ser.ITEM    = lne.ITEM                                                                                                     
		and    lne.ORDERNO = ord.ORDERNO                                                                                                  
		and    nvl(lne.REPAIR_PLANT_ID, ord.PLANT_ID) = rul.DESTINATION_PLANT_I                                                           
D                                                                                                                                   
		and    ord.PLANT_ID = rul.SOURCE_PLANT_ID                                                                                         
		and    rownum < 2;                                                                                                                
   exception                                                                                                                        
   	when NO_DATA_FOUND then                                                                                                         
   		null;                                                                                                                          
  	end;                                                                                                                             
                                                                                                                                    
	if myData = 'E' then                                                                                                               
		return ( myEvent );                                                                                                               
	elsif myData = 'F' then                                                                                                            
		return ( myFlexCode );                                                                                                            
	elsif myData = 'T' then                                                                                                            
		return ( myShipType );                                                                                                            
	elsif myData = 'I' then                                                                                                            
		return (myIntNatFlag);                                                                                                            
	else                                                                                                                               
		return ( null);                                                                                                                   
	end if;                                                                                                                            
end;                                                                                                                                
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

