set time on
set timing on
set lines 150
set verify off
set pages 200
column owner format a15
column table_name format a30
column tablespace_name format a20
column segment_name format a30
column segment_type format a15
column index_type format a15
column size_in_mb format 999999999.99
accept tablespace_name char prompt 'Enter Tablespace Name : '
accept segment_name char prompt 'Enter Segment Name : '
accept seg_size char prompt 'Enter Size in MB  : '
spool segment_size
ttitle center 'List of Objects under &&tablespace_name having size more than &&seg_size MB'  skip 1 center '**************************************************************' skip 2
select a.owner, a.segment_name, a.segment_type , a.tablespace_name, round(sum(a.bytes)/(1024*1024),2) size_in_MB,
       (select b.index_type
          from dba_indexes b
         where a.segment_type like 'INDEX%'
           and a.owner = b.owner
           and a.segment_name = b.index_name) index_type
  from dba_segments a
 where a.tablespace_name = decode('&tablespace_name', null , a.tablespace_name, '&tablespace_name')
   and a.segment_name = decode('&segment_name', null , a.segment_name, '&segment_name')
 group by a.owner, a.segment_name, a.segment_type, a.tablespace_name
 having round(sum(a.bytes)/(1024*1024),2) > decode('&seg_size', null , 0, '&seg_size')
;
spool off
