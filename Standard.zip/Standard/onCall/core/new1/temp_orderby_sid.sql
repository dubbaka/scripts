SELECT ss.sid, sum(st.blocks)/1024*8 FROM v$sort_usage st, v$session ss
where ss.saddr=st.session_addr group by ss.sid order by 2
/
