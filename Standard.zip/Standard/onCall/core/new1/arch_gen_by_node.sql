--------------------------------------------------------------------------------
-- SCCS INFO : archived.sql [1.6] 11/25/01 23:47:49
-- FILE INFO : archived8.sql
-- CREATED   : biddas
-- DATE      : 07/02/2006
-- DESC      : Displays Sess info with SQL-TEXT.
--------------------------------------------------------------------------------

CLEAR COL BREAK COMPUTE
SET PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
col log_hour format 99999999
BREAK ON log_date SKIP 1
COMPUTE SUM OF count ON log_date

SELECT thread# Node#, TO_CHAR(COMPLETION_TIME, 'DD-MON-YYYY') Log_Date,
       TO_CHAR(COMPLETION_TIME, 'HH24') Hr,
       count(*) count
FROM   v$archived_log
GROUP  BY thread#, TO_CHAR(COMPLETION_TIME, 'DD-MON-YYYY'),
       TO_CHAR(COMPLETION_TIME, 'HH24')
order by 2,1
/

SET PAGES 32 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF

PROMPT
