set pagesize 24 linesize 80 echo off feedback 1 wrap on
column reqid format 9999999999 heading "Request Id"
column sesid format a10 heading "Session"
column ospid format a10 heading "OS Pid"
col module for a25
select
   a.request_id reqid,
   d.sid||','||d.serial# sesid,
   c.spid ospid,
   d.module,
   d.seconds_in_wait/60,
   d.event,
   d.last_call_et/60
from
   applsys.fnd_concurrent_requests a,
   applsys.fnd_concurrent_processes b,
   v$process c, v$session d
where
   a.controlling_manager=b.concurrent_process_id
   and c.spid=a.oracle_process_id
   and c.addr=d.paddr
   and d.sql_hash_value='&hash'
   and a.phase_code='R';
