col username for a13
col event for a15
col log_time for a25
select a.sid,a.serial#,a.username,a.osuser,a.status,a.sql_hash_value,a.last_call_et,c.event,to_char(a.logon_time,'DD-MON-YYYY Hh24:MI:SS') "log_time",a.last_call_et/60
from v$session a,v$process b,v$session_wait c
where a.paddr=b.addr
and a.sid=c.sid
and c.event='gc buffer busy'
order by 5
/
