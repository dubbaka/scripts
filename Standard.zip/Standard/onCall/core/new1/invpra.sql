alter package XXCTS_DM_PA_REV_ACTUAL_PUB1 compile body ;
alter package XXCTS_DM_PA_COST_ACTUAL_PUB1 compile body ;
alter package XXCTS_DM_PA_REV_BUDGET_PUB1  compile body ;
alter package XXCTS_DM_PA_COST_BUDGET_PUB  compile body ;
alter package XXCTS_DM_PA_AGREEMENT_PUB1   compile body ;
alter package XXCTS_DM_PA_PROJECT_PUB1	 compile body ;
alter package XXCTS_DM_PA_PROJECT_PUB	compile body ;
alter package XXCTS_DM_PA_COST_ACTUAL_PUB compile body ;
alter package XXCTS_DM_PA_PROJ_COPY	 compile body ;
alter package XXCTS_DM_PA_COST_BUDGET_PUB1  compile body ;
alter package XXCTS_DM_PA_PROJECT_PUB2	  compile body ;
alter package XXCTS_DM_PA_AGREEMENT_PUB	 compile body ;
alter package XXCTS_DM_PA_REV_BUDGET_PUB compile body ;
alter package XXCTS_DM_PA_REV_ACTUAL_PUB compile body ;
alter package  XXCTS_DM_PA_PROJ_UTIL   compile body ;


