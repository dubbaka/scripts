col username for a15
col event for a30
select a.sid,a.serial#,a.username,a.status,a.sql_hash_value,c.event,to_char(a.logon_time,'DD-MON-YYYY Hh24:MI:SS'),a.last_call_et/60
from v$session a,v$process b,v$session_wait c
where a.paddr=b.addr
and a.sid=c.sid
and a.sql_hash_value='&HashValue' and a.program like 'java%' and a.status='ACTIVE' and a.last_call_et/60>10
order by 5
/
