                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."XXDEX_CISCO_INVOICE_K" AUTHID CURRENT_USE                                                       
R as                                                                                                                                
/* $Header: XXDEX_CISCO_INVOICE_K.sql 2.1.6.0 2010/09/10 12:00:00 dexsys                                                            
ship $ Copyright (c) 2010 DEX Systems, Inc. */                                                                                      
                                                                                                                                    
                                                                                                                                    
   procedure PROCESS (                                                                                                              
                       myOrder    varchar2                                                                                          
                      ,myShipNo   number                                                                                            
                      ,myMultiInv varchar2 default n                                                                                
ull                                                                                                                                 
                      ,myTrxDate  date default null                                                                                 
                     );                                                                                                             
                                                                                                                                    
   function  PROCESS (                                                                                                              
                       myOrder    varchar2                                                                                          
                      ,myShipNo   number                                                                                            
                      ,myMultiInv varchar2 default null                                                                             
                      ,myTrxDate  date default null                                                                                 
                     ) return     varchar2;                                                                                         
                                                                                                                                    
   procedure CREDIT  (                                                                                                              
                       myReturnOrder  varchar2                                                                                      
                     );                                                                                                             
                                                                                                                                    
   procedure CORE    (                                                                                                              
                       myRetMesg   out   varchar2                                                                                   
                      ,myRetCode   out   number                                                                                     
                      ,myOrder     in    varchar2                                                                                   
                      ,myShipNo    in    number                                                                                     
                      ,myPCust     in    varchar2 default null                                                                      
                      ,myProcType  in    varchar2 default 'N'                                                                       
   -- N-Normal   A-Accept   R-Reject   C-Cust Credit                                                                                
   D-Cust Debit                                                                                                                     
                      ,myPWaybill       in    varchar2 default                                                                      
 null                                                                                                                               
                     );                                                                                                             
                                                                                                                                    
   procedure SALES_RTN (                                                                                                            
                       myRetMesg   out   varchar2                                                                                   
                      ,myRetCode   out   number                                                                                     
                      ,myOrder     in    varchar2                                                                                   
                      ,myRMA        in    varchar2                                                                                  
                      ,myPCust     in    varchar2 default                                                                           
 null                                                                                                                               
                      ,myProcType  in    varchar2 default 'N'    -- N-No                                                            
rmal   A-Accept   R-Reject   C-Cust Credit   D-Cust                                                                                 
Debit                                                                                                                               
                     );                                                                                                             
                                                                                                                                    
  procedure ADV_CORE (                                                                                                              
                    myRetMesg   out   varchar2                                                                                      
                   ,myRetCode   out   number                                                                                        
                   ,myCOrder    in    varchar2                                                                                      
                   ,myProcType  in    varchar2                                                                                      
                   ,myPCust     in    varchar2   default null                                                                       
                   ,mySerialID  in    number     default null                                                                       
                      );                                                                                                            
                                                                                                                                    
  procedure QTC_INVOICE_UPDTS;                                                                                                      
end XXDEX_CISCO_INVOICE_K;                                                                                                          
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."XXDEX_CISCO_INVOICE_K" as                                                                    
/* $Header: XXDEX_CISCO_INVOICE_K.sql 2.1.5.0 2010/08/20 1                                                                          
2:00:00 dexsys ship $ Copyright (c) 2010 DEX Systems                                                                                
, Inc. */                                                                                                                           
   mySect         varchar2(200)  := null;                                                                                           
   myRetMesg	 	varchar2(200);                                                                                                       
   myRetCode		number;                                                                                                               
                                                                                                                                    
   /*************************************************************************                                                       
*************************                                                                                                           
    ********************************************  Lo                                                                                
cal *******************************************                                                                                     
    ****************************************************                                                                            
**********************************************/                                                                                     
                                                                                                                                    
                                                                                                                                    
   /**************************************************                                                                              
************************************************                                                                                    
    ********************************************   Publ                                                                             
ic  *******************************************                                                                                     
    ****************************************************                                                                            
**********************************************/                                                                                     
                                                                                                                                    
                                                                                                                                    
   /**************************************************                                                                              
************************************************/                                                                                   
                                                                                                                                    
   procedure PROCESS (                                                                                                              
                       myOrder    varchar2                                                                                          
                      ,myShipNo   number                                                                                            
                      ,myMultiInv varchar2 default null                                                                             
                      ,myTrxDate  date default null                                                                                 
                     ) is                                                                                                           
                                                                                                                                    
                                                                                                                                    
      myPeriod     	number(2);                                                                                                      
      myYear       	number(4);                                                                                                      
		myDate			date;                                                                                                                    
                                                                                                                                    
		myInvMgmt		varchar2(1);                                                                                                           
		myBillType		varchar2(1);                                                                                                          
		myOrdType		varchar2(1);                                                                                                           
		myDuplicate		varchar2(1);                                                                                                         
                                                                                                                                    
		myCustName		XXDEX_PARTIES_V.CUSTOMER_NAME%type;                                                                                   
		myRMANbr		   DEX_ORDERS.RMA%type;                                                                                                 
                                                                                                                                    
		myShipId			number;                                                                                                                
		myOrgId			number;                                                                                                                 
      myShpHdrID   	number := null;                                                                                                 
      myCustID			number;                                                                                                            
		myTotal			number;                                                                                                                 
		myLineNbr		number := 0;                                                                                                           
                                                                                                                                    
                                                                                                                                    
		myUserId			number := 2793;			-- Constant set by cisco                                                                             
                                                                                                                                    
      --CISCO C3 API                                                                                                                
      myECHdrId     	number := null;                                                                                                
      myECLineId    	number;                                                                                                        
                                                                                                                                    
      myECBVHdrId   	number := null;                                                                                                
      myECBVLineId  	number;                                                                                                        
		myBusEntCd		varchar2(50);                                                                                                         
		myBusEntName	varchar2(50);                                                                                                        
		myInvOrdType	varchar2(50);                                                                                                        
                                                                                                                                    
		myDeliveryID	DEX_SHIP_INTERFACE.REF_1%type;                                                                                       
		myCarrier		DEX_SHIP_INTERFACE.SERVICE_NAME%type;                                                                                  
		myShipInstruct DEX_SHIP_INTERFACE.CARRIER_INSTRUCTIONS                                                                            
%type;                                                                                                                              
		myFreight		DEX_SHIP_INTERFACE.FREIGHT_CHARGE%type;                                                                                
                                                                                                                                    
      myBCity     	XXDEX_ADDRESSES_V.CITY%type;                                                                                     
      myBCounty      XXDEX_ADDRESSES_V.COUNTY%type;                                                                                 
      myBCountry     XXDEX_ADDRESSES_V.COUNTRY%type;                                                                                
      myBState       XXDEX_ADDRESSES_V.STATE%type;                                                                                  
      myBZip     	   XXDEX_ADDRESSES_V.POSTAL_CODE%type;                                                                            
      myBAddress1    XXDEX_ADDRESSES_V.ADDRESS1%type;                                                                               
      myBAddress2    XXDEX_ADDRESSES_V.ADDRESS2%type;                                                                               
      myBAddress3    XXDEX_ADDRESSES_V.ADDRESS3%type;                                                                               
      myBAddress4    XXDEX_ADDRESSES_V.ADDRESS4%type;                                                                               
      myBAddressId   XXDEX_ADDRESSES_V.ADDRESS_ID%type;                                                                             
		myBCustName		XXDEX_PARTIES_V.CUSTOMER_NAME%type;                                                                                  
		myBCustID		XXDEX_PARTIES_V.CUSTOMER_ID%type;                                                                                      
		myBCust			XXDEX_PARTIES_V.CUSTOMER_NUMBER%type;                                                                                   
                                                                                                                                    
      mySCity        XXDEX_ADDRESSES_V.CITY%type;                                                                                   
      mySCounty      XXDEX_ADDRESSES_V.COUNTY%type;                                                                                 
      mySCountry     XXDEX_ADDRESSES_V.COUNTRY%type;                                                                                
      mySState       XXDEX_ADDRESSES_V.STATE%type;                                                                                  
      mySZip         XXDEX_ADDRESSES_V.POSTAL_CODE%type;                                                                            
      mySAddress1    XXDEX_ADDRESSES_V.ADDRESS1%type;                                                                               
      mySAddress2    XXDEX_ADDRESSES_V.ADDRESS2%type;                                                                               
      mySAddress3    XXDEX_ADDRESSES_V.ADDRESS3%type;                                                                               
      mySAddress4    XXDEX_ADDRESSES_V.ADDRESS4%type;                                                                               
      mySAddressId   XXDEX_ADDRESSES_V.ADDRESS_ID%ty                                                                                
pe;                                                                                                                                 
      mySCustName		XXDEX_PARTIES_V.CUSTOMER_NAME%type;                                                                              
		mySCustID		XXDEX_PARTIES_V.CUSTOMER_ID%type;                                                                                      
      mySCust			XXDEX_PARTIES_V.CUSTOMER_NUMBER%type;                                                                               
                                                                                                                                    
		myECOrder		XXCTS_OMAR_CEC_HEADERS.EC_ORDER_NUMBER%type;                                                                           
		myECOrdSrc		XXCTS_OMAR_CEC_HEADERS.EC_ORDER_SOURCE%type := 'EC IO                                                                 
SA';                                                                                                                                
		myECItemNbr		XXCTS_OMAR_CEC_LINES.INVENTORY_ITEM%type := 'REP-SPVIP';                                                             
		myECItemID		number := 14748958;                                                                                                   
		myPriceList		varchar2(30);                                                                                                        
		myAttr1			varchar2(150) := to_char(SYSDATE,'DD-MON-YYYY HH24:MI');                                                                
                                                                                                                                    
		myNotes			XXCTS_OMAR_CEC_NOTES.NOTES%type;                                                                                        
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select shd.ITEM                                                                                                            
               ,shd.INVENTORY_ITEM_ID                                                                                               
               ,shd.ITEM_NUMBER                                                                                                     
               ,shd.ITEM_DESCRIPTION                                                                                                
               ,shd.UOM                                                                                                             
               ,decode(UOM,'LT',QUANTITY,1)		QUANTITY                                                                               
               ,shd.PRICE                                                                                                           
               ,shh.SHIP_SITE_USE_ID                                                                                                
               ,shh.BILL_SITE_USE_ID                                                                                                
               ,ser.SERIAL_NUMBER                                                                                                   
               ,ser.SERIAL_ID                                                                                                       
               ,shh.SHIP_SERVICE                                                                                                    
               ,shh.SHIP_TO_NAME                                                                                                    
					,shh.SHIP_TO_ADDRESS_LINE_1                                                                                                    
					,shh.SHIP_TO_ADDRESS_LINE_2                                                                                                    
					,shh.SHIP_TO_CITY                                                                                                              
					,shh.SHIP_TO_STATE                                                                                                             
					,shh.SHIP_TO_PROVINCE                                                                                                          
					,shh.SHIP_TO_COUNTRY_CODE                                                                                                      
					,shh.SHIP_TO_POSTAL_CODE                                                                                                       
					,shh.CONTACT_NAME                                                                                                              
					,shh.CONTACT_PHONE_NBR                                                                                                         
					,shh.CONTACT_EMAIL                                                                                                             
					,shh.CURRENCY_CODE                                                                                                             
					,shh.DATERCV                                                                                                                   
					,shh.CUSTOMER_NUMBER                                                                                                           
					,shh.CUSTOMER_ID                                                                                                               
					,shh.ORG_ID                                                                                                                    
					,shh.SHPHDR_ID                                                                                                                 
					,shh.SHIP_ID                                                                                                                   
					,shh.DATEPRO                                                                                                                   
					,shh.DROP_SHIP                                                                                                                 
					,shh.RMA_NBR                                                                                                                   
					,ser.REPAIR_ACTION_DESC                                                                                                        
					,decode(ser.WARR_TYPE,'S','Standard - ', 'Repair                                                                               
-','') ||                                                                                                                           
								decode(ser.WARR_ACCT_IND,'I','In Warranty', 'O','Out of Warr                                                                
anty','V',' Voided Warranty','G','Good Will','') WAR                                                                                
RANTY                                                                                                                               
               ,shh.PARTIAL_SHP                                                                                                     
               ,shh.ORDER_REASON_CODE                                                                                               
               ,shh.CUSTPO                                                                                                          
         from   XXDEX_CISCO_SHPSERS_V ser                                                                                           
               ,XXDEX_CISCO_SHPDETS_V shd                                                                                           
         		,XXDEX_CISCO_SHPHDRS_V shh                                                                                               
         where  shh.ORDERNO   = myOrder                                                                                             
         and    shh.SHIPMENT  = myShipNo                                                                                            
         and    shh.ORDERNO   = shd.ORDERNO                                                                                         
         and    shh.SHIPMENT  = shd.SHIPMENT                                                                                        
         and    shd.ORDERNO   = ser.ORDERNO                                                                                         
         and    shd.ITEM      = ser.ITEM                                                                                            
         and    shd.SHIPMENT  = ser.SHIPMENT                                                                                        
         and    ser.REPAIR_PLANT_ID = ser.PLANT_ID						-- Shipment isn't                                                           
 tied interplant shipment                                                                                                           
         and    ser.INT_RMA_NUMBER is null                                                                                          
         and    nvl(ser.PLANT_CODE,'I') != 'A'						-- Not Au                                                                       
thorized Provide                                                                                                                    
         order by ITEM;                                                                                                             
                                                                                                                                    
                                                                                                                                    
      myRetCode      number(1);                                                                                                     
      myRetMesg      varchar2(2000);                                                                                                
      ABORT_PROC     exception;                                                                                                     
                                                                                                                                    
   begin                                                                                                                            
		SAVEPOINT INVPROC_SAVEPOINT;                                                                                                      
                                                                                                                                    
		-- dbms_output.put_line('in xxdex_cisco_k.process');                                                                              
      mySect := 'Pro - Begin';                                                                                                      
      begin                                                                                                                         
			select sh.SHIP_ID                                                                                                                
					,sh.ORG_ID                                                                                                                     
					,sh.ORDTYPE                                                                                                                    
					,nvl(dcd.ADVREP_FLAG,'N')                                                                                                      
               ,nvl(dcd.ADVREP_BILL_TYPE,'R')                                                                                       
               ,sh.DATEPRO                                                                                                          
               ,sh.CUSTOMER_ID                                                                                                      
               ,nvl(dxi.REF_1,dxi.SHIP_ID)                                                                                          
               ,nvl(dxi.FREIGHT_CHARGE,0)                                                                                           
               ,nvl(sh.SHIP_VIA_CARRIER ,dxi.SERVICE_NAME)                                                                          
               ,sh.RMA_NBR                                                                                                          
               ,dxi.CARRIER_INSTRUCTIONS                                                                                            
			into   myShipID                                                                                                                  
					,myOrgID                                                                                                                       
					,myOrdType                                                                                                                     
					,myInvMgmt                                                                                                                     
					,myBillType                                                                                                                    
					,myDate                                                                                                                        
					,myCustID                                                                                                                      
					,myDeliveryID                                                                                                                  
					,myFreight                                                                                                                     
					,myCarrier                                                                                                                     
					,myRMANbr                                                                                                                      
					,myShipInstruct                                                                                                                
			from   DEX_CUSTOMER_DATA dcd                                                                                                     
					,DEX_SHIP_INTERFACE dxi                                                                                                        
					,XXDEX_CISCO_SHPHDRS_V sh                                                                                                      
			where  sh.ORDERNO  = myOrder                                                                                                     
			and    sh.SHIPMENT = myShipNo                                                                                                    
			and    sh.CUSTOMER_ID = dcd.CUSTOMER_ID                                                                                          
			and    sh.ORG_ID      = dcd.ORG_ID                                                                                               
			and    sh.SHIP_ID     = dxi.SHIP_ID (+)                                                                                          
			and    rownum < 2;                                                                                                               
                                                                                                                                    
			myCustName := XXDEX_CUST_F(myCustID,'NAME');                                                                                     
			-- dbms_output.put_line('shipid: ' || myShipid || ' name: ' ||                                                                   
myCustName || ' delvid: ' || myDeliveryID);                                                                                         
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
			 	myRetMesg := 'Invalid Shipment: ' || myOrder || ' ' || myShipNo;                                                               
            raise ABORT_PROC;                                                                                                       
		end;                                                                                                                              
                                                                                                                                    
		if myShipId is null then                                                                                                          
			myECOrder := myECOrdSrc || ' ' || myOrder || '-' || myShipNo;                                                                    
		else                                                                                                                              
			myECOrder := myECOrdSrc || ' ' || myDeliveryID;                                                                                  
		end if;                                                                                                                           
                                                                                                                                    
		mySect := 'Pro - Org Cd';                                                                                                         
		begin                                                                                                                             
			if myOrgID not in (2363, 112) then                                                                                               
				select SHORT_CODE                                                                                                               
						,SHORT_NAME                                                                                                                   
				into   myBusEntCd                                                                                                               
						,myBusEntName                                                                                                                 
				from   XXSTC_OMAR_HR_OPRTG_UNITS_V                                                                                              
				where  ORGANIZATION_iD = myOrgID;                                                                                               
			else                                                                                                                             
				select SHORT_CODE                                                                                                               
						,SHORT_NAME                                                                                                                   
				into   myBusEntCd                                                                                                               
						,myBusEntName                                                                                                                 
				from   XXSTC_OMAR_BV_HR_OPRTG_UNITS_V                                                                                           
				where  ORGANIZATION_iD = myOrgID;                                                                                               
			end if;                                                                                                                          
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRetMesg := 'Cannot find Bus Entity Name for OU:                                                                               
 ' || myOrgID;                                                                                                                      
				raise ABORT_PROC;                                                                                                               
		end;                                                                                                                              
		if myBusEntCd = 'NL' then                                                                                                         
			myInvOrdType := 'Invoice Only-' || myBusEntCd;                                                                                   
		else                                                                                                                              
			myInvOrdType := 'Invoice Only - ' || myBusEntCd;                                                                                 
		end if;                                                                                                                           
                                                                                                                                    
		if myInvOrdType = 'Invoice Only - US' then                                                                                        
			myAttr1 := null;                                                                                                                 
		end if;                                                                                                                           
                                                                                                                                    
      /*                                                                                                                            
      mySect := 'Pro - Total';                                                                                                      
                                                                                                                                    
      select round(sum(nvl(QTYSHP,0) * nvl(PRICE,0)),2)                                                                             
                                                                                                                                    
      into   myTotal                                                                                                                
      from   XXDEX_SHPDETS                                                                                                          
      where  ORDERNO  = myOrder                                                                                                     
      and    SHIPMENT = myShipNo;                                                                                                   
		*/                                                                                                                                
                                                                                                                                    
                                                                                                                                    
      begin                                                                                                                         
      	select 'Y'                                                                                                                   
      	into   myDuplicate                                                                                                           
      	from   XXDEX_CISCO_QTC_INVOICE                                                                                               
      	where  DEX_SHIP_ID = myShipID                                                                                                
      	and    DEX_RMA_NBR = myRMANbr                                                                                                
      	and    rownum < 2;                                                                                                           
     	exception                                                                                                                     
       	when NO_DATA_FOUND then                                                                                                     
         	myDuplicate := 'N';                                                                                                       
      end;                                                                                                                          
                                                                                                                                    
		-- dbms_output.put_line('Total: ' || myTotal || ' Dup: ' ||                                                                       
myDuplicate);                                                                                                                       
		if myDuplicate = 'Y' then                                                                                                         
			return;                                                                                                                          
		end if;                                                                                                                           
                                                                                                                                    
      /*                                                                                                                            
                                                                                                                                    
      if myTotal = 0 or (myInvMgmt = 'Y' and ((myOrdType                                                                            
 = 'R' and myBillType != 'R') or (myOrdType != 'R' a                                                                                
nd myBillType = 'R'))) then                                                                                                         
                                                                                                                                    
         mySect := 'Pro - Update XXDEX_SHPHDRS_ALL_V';                                                                              
                                                                                                                                    
         update XXDEX_SHPHDRS_ALL_V set                                                                                             
         INVOICE        = '000000'                                                                                                  
        ,INVOICE_AMOUNT = 0                                                                                                         
        ,DATEINV        = myDate                                                                                                    
         where ORDERNO  = myOrder                                                                                                   
         and   SHIPMENT = myShipNo;                                                                                                 
                                                                                                                                    
         return;                                                                                                                    
      end if;                                                                                                                       
		*/                                                                                                                                
                                                                                                                                    
      mySect := 'Pro - Opn c1';                                                                                                     
		-- dbms_output.put_line('before c1 loop');                                                                                        
      for c1r in c1 loop                                                                                                            
                                                                                                                                    
        begin                                                                                                                       
        --myPriceList  := 'Global Price List - ' || myBusEntCd;                                                                     
        select fv.description price_list                                                                                            
          INTO myPriceList                                                                                                          
          from FND_FLEX_VALUES_VL fv, fnd_flex_value_sets ffv                                                                       
         where  ffv.flex_value_set_name = 'XXCTS_QTC_CUR_PRICE                                                                      
_LIST'                                                                                                                              
           AND fv.flex_value  = c1r.CURRENCY_CODE                                                                                   
           and  fv.flex_value_set_id = ffv.flex_value_set_id;                                                                       
                                                                                                                                    
        exception                                                                                                                   
            when NO_DATA_FOUND then                                                                                                 
                myRetMesg := 'Cannot find Price List for Cur                                                                        
rency: ' || c1r.CURRENCY_CODE;                                                                                                      
                raise ABORT_PROC;                                                                                                   
            when TOO_MANY_ROWS then                                                                                                 
                myRetMesg := 'Too many rows for Price L                                                                             
ist for Currency: ' || c1r.CURRENCY_CODE;                                                                                           
                raise ABORT_PROC;                                                                                                   
            WHEN OTHERS then                                                                                                        
                myRetMesg := SQLERRM||' on Select Price List' ;                                                                     
                raise ABORT_PROC;                                                                                                   
        end;                                                                                                                        
                                                                                                                                    
      	-- dbms_output.put_line('c1 ship_id: ' || c1r.SHIP_ID);                                                                      
      	if myShpHdrId is null then                                                                                                   
                                                                                                                                    
                                                                                                                                    
         	mySect := 'Address Fields';                                                                                               
                                                                                                                                    
         	--Fetch the Billing Address fields based on BILL_SI                                                                       
TE_USE_ID                                                                                                                           
         	-- dbms_output.put_line('bill tp addr');                                                                                  
         	select   adr.CITY                                                                                                         
         	        ,adr.COUNTY                                                                                                       
         	        ,adr.COUNTRY                                                                                                      
         	        ,adr.STATE STATE_PROVINCE                                                                                         
         	        ,adr.POSTAL_CODE                                                                                                  
         	        ,adr.ADDRESS1                                                                                                     
         	        ,adr.ADDRESS2                                                                                                     
         	        ,adr.ADDRESS3                                                                                                     
         	        ,adr.ADDRESS4                                                                                                     
         	        ,adr.ADDRESS_ID                                                                                                   
         	        ,cus.CUSTOMER_NAME                                                                                                
         	        ,cus.CUSTOMER_ID                                                                                                  
         	        ,cus.CUSTOMER_NUMBER                                                                                              
         	into                                                                                                                      
         	         myBCity                                                                                                          
         	        ,myBCounty                                                                                                        
         	        ,myBCountry                                                                                                       
         	        ,myBState                                                                                                         
         	        ,myBZip                                                                                                           
         	        ,myBAddress1                                                                                                      
         	        ,myBAddress2                                                                                                      
         	        ,myBAddress3                                                                                                      
         	        ,myBAddress4                                                                                                      
         	        ,myBAddressId                                                                                                     
         	        ,myBCustName                                                                                                      
         	        ,myBCustID                                                                                                        
         	        ,myBCust                                                                                                          
         	from     XXDEX_PARTIES_V cus,                                                                                             
         	         XXDEX_ADDRESSES_V adr,                                                                                           
         	         XXDEX_SITE_USES_V ste                                                                                            
         	where   	ste.SITE_USE_ID = c1r.BILL_SITE_USE_ID                                                                           
         	and     	adr.ADDRESS_ID  = ste.ADDRESS_ID                                                                                 
         	and     	cus.CUSTOMER_ID = adr.CUSTOMER_ID;                                                                               
                                                                                                                                    
                                                                                                                                    
         	if c1r.DROP_SHIP = 'Y' then                                                                                               
         		-- use address on shipment                                                                                               
         		-- dbms_output.put_line('drop ship ship addr');                                                                          
         		mySCustName := c1r.SHIP_TO_NAME;                                                                                         
					mySAddress1 := c1r.SHIP_TO_ADDRESS_LINE_1;                                                                                     
					mySAddress2 := c1r.SHIP_TO_ADDRESS_LINE_2;                                                                                     
					mySCity 		:= c1r.SHIP_TO_CITY;                                                                                                 
					mySState 	:= c1r.SHIP_TO_STATE;                                                                                                
					mySCountry 	:= c1r.SHIP_TO_COUNTRY_CODE;                                                                                       
					mySZip      := c1r.SHIP_TO_POSTAL_CODE;                                                                                        
					mySCustId	:= c1r.CUSTOMER_ID;                                                                                                  
					mySCust     := c1r.CUSTOMER_NUMBER;                                                                                            
				else                                                                                                                            
	         	--Fetch the Shipping Address fields based on                                                                             
 SHIP_SITE_USE_ID                                                                                                                   
	         	-- dbms_output.put_line('ship addr id');                                                                                 
	         	select   adr.CITY                                                                                                        
	         	        ,adr.COUNTY                                                                                                      
	         	        ,adr.COUNTRY                                                                                                     
	         	        ,adr.STATE STATE_PROVINCE                                                                                        
	         	        ,adr.POSTAL_CODE                                                                                                 
	         	        ,adr.ADDRESS1                                                                                                    
	         	        ,adr.ADDRESS2                                                                                                    
	         	        ,adr.ADDRESS3                                                                                                    
	         	        ,adr.ADDRESS4                                                                                                    
	         	        ,adr.ADDRESS_ID                                                                                                  
	         	        ,cus.CUSTOMER_NAME                                                                                               
	         	        ,cus.CUSTOMER_ID                                                                                                 
	         	into                                                                                                                     
	         	         mySCity                                                                                                         
	         	        ,mySCounty                                                                                                       
	         	        ,mySCountry                                                                                                      
	         	        ,mySState                                                                                                        
	         	        ,mySZip                                                                                                          
	         	        ,mySAddress1                                                                                                     
	         	        ,mySAddress2                                                                                                     
	         	        ,mySAddress3                                                                                                     
	         	        ,mySAddress4                                                                                                     
	         	        ,mySAddressId                                                                                                    
	         	        ,mySCustName                                                                                                     
	         	        ,mySCustID                                                                                                       
	         	from     XXDEX_PARTIES_V cus,                                                                                            
	         	         XXDEX_ADDRESSES_V adr,                                                                                          
	         	         XXDEX_SITE_USES_V ste                                                                                           
	         	where   	ste.SITE_USE_ID = c1r.SHIP_SITE_USE_ID                                                                          
	         	and     	adr.ADDRESS_ID  = ste.ADDRESS_ID                                                                                
	         	and     	cus.CUSTOMER_ID = adr.CUSTOMER_ID;                                                                              
				end if;                                                                                                                         
                                                                                                                                    
                                                                                                                                    
         	mySect := 'Pro - Insert';                                                                                                 
                                                                                                                                    
         	if c1r.ORG_ID not in (2363, 112) then                                                                                     
                                                                                                                                    
         	    mySect := 'Pro - US Headers';                                                                                         
         	    SELECT  XXCTS_OMAR_CEC_HEADERS_S.NEXTVAL                                                                              
         	    INTO    myECHdrId                                                                                                     
         	    FROM    dual;                                                                                                         
                                                                                                                                    
         	    -- dbms_output.put_line('insert cec_headers');                                                                        
                insert into XXCTS_OMAR_CEC_HEADERS (                                                                                
                                                                                                                                    
                BILL_TO_ADDRESS_CITY                                                                                                
               ,BILL_TO_ADDRESS_COUNTRY                                                                                             
               ,BILL_TO_ADDRESS_COUNTY                                                                                              
               ,BILL_TO_ADDRESS_ID                                                                                                  
               ,BILL_TO_ADDRESS_LINE_1                                                                                              
               ,BILL_TO_ADDRESS_LINE_2                                                                                              
               ,BILL_TO_ADDRESS_LINE_3                                                                                              
               ,BILL_TO_ADDRESS_LINE_4                                                                                              
               ,BILL_TO_ADDRESS_NEW_FLAG                                                                                            
               ,BILL_TO_ADDRESS_STATE                                                                                               
               ,BILL_TO_ADDRESS_ZIP                                                                                                 
               ,BILL_TO_CONTACT_EMAIL                                                                                               
               ,BILL_TO_CONTACT_FAX                                                                                                 
               ,BILL_TO_CONTACT_FIRST_NAME                                                                                          
               ,BILL_TO_CUSTOMER                                                                                                    
               ,BILL_TO_CUSTOMER_ID                                                                                                 
               ,BILL_TO_SITE_USE_ID                                                                                                 
					,SHIP_TO_ADDRESS_CITY                                                                                                          
					,SHIP_TO_ADDRESS_COUNTRY                                                                                                       
					,SHIP_TO_ADDRESS_COUNTY                                                                                                        
					,SHIP_TO_ADDRESS_ID                                                                                                            
					,SHIP_TO_ADDRESS_LINE_1                                                                                                        
					,SHIP_TO_ADDRESS_LINE_2                                                                                                        
					,SHIP_TO_ADDRESS_LINE_3                                                                                                        
					,SHIP_TO_ADDRESS_LINE_4                                                                                                        
					,SHIP_TO_ADDRESS_NEW_FLAG                                                                                                      
					,SHIP_TO_ADDRESS_STATE                                                                                                         
					,SHIP_TO_ADDRESS_ZIP                                                                                                           
					,SHIP_TO_CONTACT_EMAIL                                                                                                         
					,SHIP_TO_CONTACT_FIRST_NAME                                                                                                    
					,SHIP_TO_CONTACT_PHONE                                                                                                         
					,SHIP_TO_CUSTOMER                                                                                                              
					,SHIP_TO_CUSTOMER_ID                                                                                                           
					,SHIP_TO_SITE_USE_ID                                                                                                           
               ,SHIPPING_INSTRUCTIONS                                                                                               
               ,PARTIAL_SHIPMENT_ALLOWED_FLAG                                                                                       
               ,CUSTOMER_PO_NUMBER                                                                                                  
               ,BUSINESS_ENTITY_CODE                                                                                                
               ,CREATED_BY                                                                                                          
               ,CREATION_DATE                                                                                                       
               ,CURRENCY_CODE                                                                                                       
               ,CONVERSION_TYPE_CODE                                                                                                
               ,CUSTOMER_ID                                                                                                         
               ,CUSTOMER_NAME                                                                                                       
               ,DATE_ORDERED                                                                                                        
               ,EC_HEADER_ID                                                                                                        
               ,EC_ORDER_NUMBER                                                                                                     
               ,EC_ORDER_SOURCE                                                                                                     
               ,LOAD_BATCH                                                                                                          
               ,LOAD_CODE                                                                                                           
               ,OPERATION_CODE                                                                                                      
               ,ORDER_QUEUE_STATUS_ID                                                                                               
               ,ORDER_TYPE                                                                                                          
               ,ORG_ID                                                                                                              
               ,PRICE_LIST                                                                                                          
               ,PRODUCT_FOR_RESALE_FLAG                                                                                             
               ,SERVICE_LEVEL_CODE                                                                                                  
               ,SHIPPING_PREFERENCE                                                                                                 
               ,DATE_SHIPPED                                                                                                        
               ,UPGRADED_FLAG                                                                                                       
               ,ATTRIBUTE10                                                                                                         
               ,ATTRIBUTE2                                                                                                          
               ,ATTRIBUTE4                                                                                                          
               ,ATTRIBUTE6                                                                                                          
               ,ATTRIBUTE8                                                                                                          
               ,ATTRIBUTE9                                                                                                          
               ,ATTRIBUTE1                                                                                                          
                ) values (                                                                                                          
                myBcity               								-- BILL_TO_ADDRESS_CITY                                                               
                                                                                                                                    
               ,myBCountry                                  -- BILL_TO_ADDRES                                                       
S_COUNTRY                                                                                                                           
               ,myBCounty                                   -- BILL_                                                                
TO_ADDRESS_COUNTY                                                                                                                   
               ,myBAddressId                                                                                                        
-- BILL_TO_ADDRESS_ID                                                                                                               
               ,myBAddress1                                                                                                         
    -- BILL_TO_ADDRESS_LINE_1                                                                                                       
               ,myBAddress2                                 -- BILL_TO_ADD                                                          
RESS_LINE_2                                                                                                                         
               ,myBAddress3                                 -- BIL                                                                  
L_TO_ADDRESS_LINE_3                                                                                                                 
               ,myBAddress4                                                                                                         
  -- BILL_TO_ADDRESS_LINE_4                                                                                                         
               ,'N'                                         -- BILL_TO_ADDRE                                                        
SS_NEW_FLAG                                                                                                                         
               ,myBState                                    -- BIL                                                                  
L_TO_ADDRESS_STATE                                                                                                                  
               ,myBZip                                                                                                              
 -- BILL_TO_ADDRESS_ZIP                                                                                                             
               ,''                                                                                                                  
      -- BILL_TO_CONTACT_EMAIL                                                                                                      
               ,''                                          -- BILL_TO_CO                                                           
NTACT_FAX                                                                                                                           
               ,''			                                 -- BILL_TO_CON                                                                
TACT_FIRST_NAME                                                                                                                     
               ,myBCust                                     --                                                                      
 BILL_TO_CUSTOMER                                                                                                                   
               ,myBCustId                                                                                                           
-- BILL_TO_CUSTOMER_ID                                                                                                              
               ,c1r.BILL_SITE_USE_ID                                                                                                
     -- BILL_TO_SITE_USE_ID                                                                                                         
					,mySCity            									-- SHIP_TO_ADDRESS_CITY                                                                           
					,mySCountry         									-- SHIP_TO_ADDRESS_COUNTRY                                                                        
					,mySCounty          									-- SHIP_TO_ADDRESS_COUNTY                                                                         
					,mySAddressId       									-- SHIP_TO_ADDRESS_                                                                               
ID                                                                                                                                  
					,mySAddress1        									-- SHIP_TO_ADDRESS_LINE_1                                                                         
					,mySAddress2        									-- SHIP_TO_ADDRESS_LINE_2                                                                         
					,mySAddress3        									-- SHIP_TO_ADDRESS_LINE_3                                                                         
                                                                                                                                    
					,mySAddress4        									-- SHIP_TO_ADDRESS_LINE_4                                                                         
					,nvl(c1r.DROP_SHIP,'N')        					-- SHIP_TO_ADDRESS_NEW_FLAG                                                                
					,mySState	         								-- SHIP_TO_ADDRESS_S                                                                                
TATE                                                                                                                                
					,mySZip     		   								-- SHIP_TO_ADDRESS_ZIP                                                                                
					,c1r.CONTACT_EMAIL									-- SHIP_TO_CONTACT_EMAIL                                                                            
					,c1r.CONTACT_NAME										-- SHIP_TO_CONTACT_FIRST_NAME                                                                       
					,c1r.CONTACT_PHONE_NBR								-- SHIP_TO_CONTACT_PHO                                                                           
NE                                                                                                                                  
					,mySCustName											-- SHIP_TO_CUSTOMER                                                                                     
					,mySCustId												-- SHIP_TO_CUSTOMER_ID                                                                                   
					,c1r.SHIP_SITE_USE_ID   							-- SHIP_TO_SITE_USE                                                                             
_ID                                                                                                                                 
               ,myShipInstruct										-- SHIPPING_INSTRUCTIONS                                                                    
               ,c1r.PARTIAL_SHP										-- PARTIAL_SHIPMENT_                                                                       
ALLOWED_FLAG                                                                                                                        
               ,c1r.CUSTPO												-- CUSTOMER_PO_NUMBER                                                                         
               ,myBusEntName				                     -- B                                                                           
USINESS_ENTITY_CODE                                                                                                                 
               ,myUserID                                                                                                            
  -- CREATED_BY                                                                                                                     
               ,SYSDATE                                     --                                                                      
 CREATION_DATE                                                                                                                      
               ,c1r.CURRENCY_CODE                           --                                                                      
CURRENCY_CODE                                                                                                                       
               ,'Corporate'											-- CONVERSION_TYPE_CODE                                                                       
               ,c1r.CUSTOMER_ID                                                                                                     
      -- CUSTOMER_ID                                                                                                                
               ,myCustName                                                                                                          
   -- CUSTOMER_NAME                                                                                                                 
               ,c1r.DATERCV                                                                                                         
  -- DATE_ORDERED                                                                                                                   
               ,myECHdrId                                                                                                           
-- EC_HEADER_ID                                                                                                                     
               ,myECOrder                                   --                                                                      
 EC_ORDER_NUMBER                                                                                                                    
               ,myECOrdSrc                                                                                                          
-- EC_ORDER_SOURCE                                                                                                                  
               ,-1                                                                                                                  
 -- LOAD_BATCH                                                                                                                      
               ,'ELECTRONIC_COMMERCE'                       --                                                                      
LOAD_CODE                                                                                                                           
               ,'INSERT'                                    -- OPERA                                                                
TION_CODE                                                                                                                           
               ,0                                           -- ORDER                                                                
_QUEUE_STATUS_ID                                                                                                                    
               ,myInvOrdType		                          	-- O                                                                       
RDER_TYPE                                                                                                                           
               ,c1r.ORG_ID                                  -- ORG_I                                                                
D                                                                                                                                   
               ,myPriceList											-- PRICE_LIST                                                                                 
               ,'N'                                         -- PRODUCT_FOR_R                                                        
ESALE_FLAG                                                                                                                          
               ,'Standard'                                  -- SERV                                                                 
ICE_LEVEL_CODE                                                                                                                      
               ,'C'    		                                 -- SH                                                                     
IPPING_PREFERENCE                                                                                                                   
               ,c1r.DATEPRO  											-- DATE_SHIPPED                                                                             
               ,'N'                                                                                                                 
    -- UPGRADED_FLAG                                                                                                                
               ,'Resale'                                                                                                            
   -- ATTRIBUTE10                                                                                                                   
               ,SYSDATE                                                                                                             
-- ATTRIBUTE2                                                                                                                       
               ,'Y'                                         -- A                                                                    
TTRIBUTE4                                                                                                                           
               ,c1r.RMA_NBR                                 -- ATTRI                                                                
BUTE6                                                                                                                               
               ,myBusEntCd				                        -- ATTRIBUTE8                                                                 
               ,'YES'                                                                                                               
    -- ATTRIBUTE9                                                                                                                   
               ,myAttr1													-- ATTRIBUTE1                                                                                   
               );                                                                                                                   
                                                                                                                                    
            else                                                                                                                    
                                                                                                                                    
         	    mySect := 'Pro - BV Headers';                                                                                         
         	    SELECT  XXCTS_OMAR_BV_CEC_HEADERS_S.NEXTVAL                                                                           
         	    INTO    myECHdrId                                                                                                     
         	    FROM    dual;                                                                                                         
                                                                                                                                    
         	    -- dbms_output.put_line('insert cec bv headers');                                                                     
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    
                insert into XXCTS_OMAR_BV_CEC_HEADERS (                                                                             
                                                                                                                                    
                BILL_TO_ADDRESS_CITY                                                                                                
               ,BILL_TO_ADDRESS_COUNTRY                                                                                             
               ,BILL_TO_ADDRESS_COUNTY                                                                                              
               ,BILL_TO_ADDRESS_ID                                                                                                  
               ,BILL_TO_ADDRESS_LINE_1                                                                                              
               ,BILL_TO_ADDRESS_LINE_2                                                                                              
               ,BILL_TO_ADDRESS_LINE_3                                                                                              
               ,BILL_TO_ADDRESS_LINE_4                                                                                              
               ,BILL_TO_ADDRESS_NEW_FLAG                                                                                            
               ,BILL_TO_ADDRESS_STATE                                                                                               
               ,BILL_TO_ADDRESS_ZIP                                                                                                 
               ,BILL_TO_CONTACT_EMAIL                                                                                               
               ,BILL_TO_CONTACT_FAX                                                                                                 
               ,BILL_TO_CONTACT_FIRST_NAME                                                                                          
               ,BILL_TO_CUSTOMER                                                                                                    
               ,BILL_TO_CUSTOMER_ID                                                                                                 
               ,BILL_TO_SITE_USE_ID                                                                                                 
					,SHIP_TO_ADDRESS_CITY                                                                                                          
					,SHIP_TO_ADDRESS_COUNTRY                                                                                                       
					,SHIP_TO_ADDRESS_COUNTY                                                                                                        
					,SHIP_TO_ADDRESS_ID                                                                                                            
					,SHIP_TO_ADDRESS_LINE_1                                                                                                        
					,SHIP_TO_ADDRESS_LINE_2                                                                                                        
					,SHIP_TO_ADDRESS_LINE_3                                                                                                        
					,SHIP_TO_ADDRESS_LINE_4                                                                                                        
					,SHIP_TO_ADDRESS_NEW_FLAG                                                                                                      
					,SHIP_TO_ADDRESS_STATE                                                                                                         
					,SHIP_TO_ADDRESS_ZIP                                                                                                           
					,SHIP_TO_CONTACT_EMAIL                                                                                                         
					,SHIP_TO_CONTACT_FIRST_NAME                                                                                                    
					,SHIP_TO_CONTACT_PHONE                                                                                                         
					,SHIP_TO_CUSTOMER                                                                                                              
					,SHIP_TO_CUSTOMER_ID                                                                                                           
					,SHIP_TO_SITE_USE_ID                                                                                                           
               ,SHIPPING_INSTRUCTIONS                                                                                               
               ,PARTIAL_SHIPMENT_ALLOWED_FLAG                                                                                       
               ,CUSTOMER_PO_NUMBER                                                                                                  
               ,BUSINESS_ENTITY_CODE                                                                                                
               ,CREATED_BY                                                                                                          
               ,CREATION_DATE                                                                                                       
               ,CURRENCY_CODE                                                                                                       
               ,CONVERSION_TYPE_CODE                                                                                                
               ,CUSTOMER_ID                                                                                                         
               ,CUSTOMER_NAME                                                                                                       
               ,DATE_ORDERED                                                                                                        
               ,EC_HEADER_ID                                                                                                        
               ,EC_ORDER_NUMBER                                                                                                     
               ,EC_ORDER_SOURCE                                                                                                     
               ,LOAD_BATCH                                                                                                          
               ,LOAD_CODE                                                                                                           
               ,OPERATION_CODE                                                                                                      
               ,ORDER_QUEUE_STATUS_ID                                                                                               
               ,ORDER_TYPE                                                                                                          
               ,ORG_ID                                                                                                              
               ,PRICE_LIST                                                                                                          
               ,PRODUCT_FOR_RESALE_FLAG                                                                                             
               ,SERVICE_LEVEL_CODE                                                                                                  
               ,SHIPPING_PREFERENCE                                                                                                 
               ,DATE_SHIPPED                                                                                                        
               ,UPGRADED_FLAG                                                                                                       
               ,ATTRIBUTE10                                                                                                         
               ,ATTRIBUTE2                                                                                                          
               ,ATTRIBUTE4                                                                                                          
               ,ATTRIBUTE6                                                                                                          
               ,ATTRIBUTE8                                                                                                          
               ,ATTRIBUTE9                                                                                                          
               ,ATTRIBUTE1                                                                                                          
                ) values (                                                                                                          
                myBcity               								-- BILL_TO_ADDRESS_CITY                                                               
                                                                                                                                    
               ,myBCountry                                  -- BILL_TO_ADDRES                                                       
S_COUNTRY                                                                                                                           
               ,myBCounty                                   -- BILL_                                                                
TO_ADDRESS_COUNTY                                                                                                                   
               ,myBAddressId                                                                                                        
-- BILL_TO_ADDRESS_ID                                                                                                               
               ,myBAddress1                                                                                                         
    -- BILL_TO_ADDRESS_LINE_1                                                                                                       
               ,myBAddress2                                 -- BILL_TO_ADD                                                          
RESS_LINE_2                                                                                                                         
               ,myBAddress3                                 -- BIL                                                                  
L_TO_ADDRESS_LINE_3                                                                                                                 
               ,myBAddress4                                                                                                         
  -- BILL_TO_ADDRESS_LINE_4                                                                                                         
               ,'N'                                         -- BILL_TO_ADDRE                                                        
SS_NEW_FLAG                                                                                                                         
               ,myBState                                    -- BIL                                                                  
L_TO_ADDRESS_STATE                                                                                                                  
               ,myBZip                                                                                                              
 -- BILL_TO_ADDRESS_ZIP                                                                                                             
               ,''                                                                                                                  
      -- BILL_TO_CONTACT_EMAIL                                                                                                      
               ,''                                          -- BILL_TO_CO                                                           
NTACT_FAX                                                                                                                           
               ,''			                                 -- BILL_TO_CON                                                                
TACT_FIRST_NAME                                                                                                                     
               ,myBCust                                     --                                                                      
 BILL_TO_CUSTOMER                                                                                                                   
               ,myBCustId                                                                                                           
-- BILL_TO_CUSTOMER_ID                                                                                                              
               ,c1r.BILL_SITE_USE_ID                                                                                                
     -- BILL_TO_SITE_USE_ID                                                                                                         
					,mySCity            									-- SHIP_TO_ADDRESS_CITY                                                                           
					,mySCountry         									-- SHIP_TO_ADDRESS_COUNTRY                                                                        
					,mySCounty          									-- SHIP_TO_ADDRESS_COUNTY                                                                         
					,mySAddressId       									-- SHIP_TO_ADDRESS_                                                                               
ID                                                                                                                                  
					,mySAddress1        									-- SHIP_TO_ADDRESS_LINE_1                                                                         
					,mySAddress2        									-- SHIP_TO_ADDRESS_LINE_2                                                                         
					,mySAddress3        									-- SHIP_TO_ADDRESS_LINE_3                                                                         
                                                                                                                                    
					,mySAddress4        									-- SHIP_TO_ADDRESS_LINE_4                                                                         
					,nvl(c1r.DROP_SHIP,'N')        					-- SHIP_TO_ADDRESS_NEW_FLAG                                                                
					,mySState	         								-- SHIP_TO_ADDRESS_S                                                                                
TATE                                                                                                                                
					,mySZip     		   								-- SHIP_TO_ADDRESS_ZIP                                                                                
					,c1r.CONTACT_EMAIL									-- SHIP_TO_CONTACT_EMAIL                                                                            
					,c1r.CONTACT_NAME										-- SHIP_TO_CONTACT_FIRST_NAME                                                                       
					,c1r.CONTACT_PHONE_NBR								-- SHIP_TO_CONTACT_PHO                                                                           
NE                                                                                                                                  
					,mySCustName											-- SHIP_TO_CUSTOMER                                                                                     
					,mySCustId												-- SHIP_TO_CUSTOMER_ID                                                                                   
					,c1r.SHIP_SITE_USE_ID   							-- SHIP_TO_SITE_USE                                                                             
_ID                                                                                                                                 
               ,myShipInstruct										-- SHIPPING_INSTRUCTIONS                                                                    
               ,c1r.PARTIAL_SHP										-- PARTIAL_SHIPMENT_                                                                       
ALLOWED_FLAG                                                                                                                        
               ,c1r.CUSTPO												-- CUSTOMER_PO_NUMBER                                                                         
               ,myBusEntName                   					-- BU                                                                           
SINESS_ENTITY_CODE                                                                                                                  
               ,myUserID                                                                                                            
 -- CREATED_BY                                                                                                                      
               ,SYSDATE                                     --                                                                      
CREATION_DATE                                                                                                                       
               ,c1r.CURRENCY_CODE                           -- C                                                                    
URRENCY_CODE                                                                                                                        
               ,'Corporate'											-- CONVERSION_TYPE_CODE                                                                       
               ,c1r.CUSTOMER_ID                                                                                                     
     -- CUSTOMER_ID                                                                                                                 
               ,myCustName                                                                                                          
  -- CUSTOMER_NAME                                                                                                                  
               ,c1r.DATERCV                                                                                                         
 -- DATE_ORDERED                                                                                                                    
               ,myECHdrId                                   -                                                                       
- EC_HEADER_ID                                                                                                                      
               ,myECOrder                                   --                                                                      
EC_ORDER_NUMBER                                                                                                                     
               ,myECOrdSrc                                  --                                                                      
 EC_ORDER_SOURCE                                                                                                                    
               ,-1                                          -                                                                       
- LOAD_BATCH                                                                                                                        
               ,'ELECTRONIC_COMMERCE'                       -- LO                                                                   
AD_CODE                                                                                                                             
               ,'INSERT'                                    -- OPERATI                                                              
ON_CODE                                                                                                                             
               ,0                                           -- ORDER_Q                                                              
UEUE_STATUS_ID                                                                                                                      
               ,myInvOrdType		                           -- ORD                                                                     
ER_TYPE                                                                                                                             
               ,c1r.ORG_ID                                  -- ORG_ID                                                               
               ,myPriceList											-- PRICE_LIST                                                                                 
               ,'N'                                                                                                                 
        -- PRODUCT_FOR_RESALE_FLAG                                                                                                  
               ,'Standard'                                  -- SERVIC                                                               
E_LEVEL_CODE                                                                                                                        
               ,'C'                                         -- SH                                                                   
IPPING_PREFERENCE                                                                                                                   
                ,c1r.DATEPRO																	-- DATE_SHIPPED                                                                        
                                                                                                                                    
               ,'N'                                         -- UPGRADED_FLAG                                                        
               ,'Resale'                                                                                                            
        -- ATTRIBUTE10                                                                                                              
               ,SYSDATE                                                                                                             
     -- ATTRIBUTE2                                                                                                                  
               ,'Y'                                                                                                                 
 -- ATTRIBUTE4                                                                                                                      
               ,c1r.RMA_NBR                                 --                                                                      
ATTRIBUTE6                                                                                                                          
               ,myBusEntCd				                        -- ATTRIBUTE8                                                                 
                                                                                                                                    
               ,'YES'                                       -- ATTRIBUTE9                                                           
               ,myAttr1													-- ATTRIBUTE1                                                                                   
               );                                                                                                                   
				end if;                                                                                                                         
			end if;                                                                                                                          
			myShpHdrID := c1r.SHPHDR_ID;                                                                                                     
                                                                                                                                    
			myNotes := 'RMA: ' || c1r.RMA_NBR || ', Delivery#: ' || my                                                                       
DeliveryID || ' Line#: ' || c1r.ITEM || ', Carrier N                                                                                
ame: ' || myCarrier  || chr(13) ||                                                                                                  
						  ' Serial: ' || c1r.SERIAL_NUMBER || ', Part: ' || c1r.ITEM_NU                                                               
MBER || ', Descr: ' || c1r.ITEM_DESCRIPTION || chr(1                                                                                
3) ||                                                                                                                               
						  ' Warranty: ' || c1r.WARRANTY || ', Repair Action: ' || c1r.REPA                                                            
IR_ACTION_DESC;                                                                                                                     
                                                                                                                                    
			myLineNbr := myLineNbr + 1;                                                                                                      
                                                                                                                                    
                                                                                                                                    
			if c1r.ORG_ID  not in (2363, 112) then                                                                                           
				mySect := 'Pro - US Lines';                                                                                                     
            select XXCTS_OMAR_CEC_LINES_S.NEXTVAL                                                                                   
         	into   myECLineId                                                                                                         
         	from   dual;                                                                                                              
                                                                                                                                    
         	-- dbms_output.put_line('insert cec lines');                                                                              
            insert into XXCTS_OMAR_CEC_LINES                                                                                        
           (DELIVERY_REQUIRED_FLAG                                                                                                  
           ,DUTY_ATTRIBUTE                                                                                                          
           ,DUTY_ATTRIBUTE_OVERRIDE_FLAG                                                                                            
           ,EC_LINE_ID                                                                                                              
           ,EC_LINE_NUMBER                                                                                                          
           ,FOB_POINT_CODE                                                                                                          
           ,SHIP_TO_ADDRESS_CITY                                                                                                    
           ,SHIP_TO_ADDRESS_COUNTRY                                                                                                 
           ,SHIP_TO_ADDRESS_COUNTY                                                                                                  
           ,SHIP_TO_ADDRESS_ID                                                                                                      
           ,SHIP_TO_ADDRESS_LINE_1                                                                                                  
           ,SHIP_TO_ADDRESS_LINE_2                                                                                                  
           ,SHIP_TO_ADDRESS_LINE_3                                                                                                  
           ,SHIP_TO_ADDRESS_LINE_4                                                                                                  
           ,SHIP_TO_ADDRESS_STATE                                                                                                   
           ,SHIP_TO_ADDRESS_ZIP                                                                                                     
           ,SHIP_TO_CONTACT_EMAIL                                                                                                   
           ,SHIP_TO_CONTACT_PHONE                                                                                                   
           ,SHIP_TO_CUSTOMER                                                                                                        
           ,SHIP_TO_CUSTOMER_ID                                                                                                     
           ,TRANSACTION_TYPE_NAME                                                                                                   
           ,UNIT_OF_MEASURE_CODE                                                                                                    
           ,CREATED_BY                                                                                                              
           ,CREATION_DATE                                                                                                           
           ,WAREHOUSE                                                                                                               
           ,WAREHOUSE_ID                                                                                                            
           ,EC_HEADER_ID                                                                                                            
           ,OPERATION_CODE                                                                                                          
           ,ORG_ID                                                                                                                  
           ,SERVICE_LEVEL_CODE                                                                                                      
           ,FREIGHT_PAYMENT_METHOD_CODE                                                                                             
           ,FREIGHT_TERMS_CODE                                                                                                      
           ,FRT_CARRIER_OVERRIDE_FLAG                                                                                               
           ,INVENTORY_ITEM                                                                                                          
           ,INVENTORY_ITEM_ID                                                                                                       
           ,ITEM_TYPE_CODE                                                                                                          
           ,LAST_UPDATE_DATE                                                                                                        
           ,LIST_PRICE                                                                                                              
           ,OPTION_FLAG                                                                                                             
           ,ORDERED_QUANTITY                                                                                                        
           ,SELLING_PRICE                                                                                                           
           ) values (                                                                                                               
            'N' 										-- DELIVERY_REQUIRED_FLAG                                                                                 
           ,'N'                              -- DUTY_ATTRIBUTE                                                                      
           ,'N'                              -- DUTY_ATTRIBUTE_OVE                                                                  
RRIDE_FLAG                                                                                                                          
           ,myECLineId                       -- EC_LINE_ID                                                                          
           ,myLineNbr		                  -- EC_LINE_NUMBER                                                                          
           ,'Customer Premises'              -- FOB_P                                                                               
OINT_CODE                                                                                                                           
           ,mySCity                          -- SHIP_TO_ADDRESS_CITY                                                                
                                                                                                                                    
           ,mySCountry                       -- SHIP_TO_ADDRESS_COUNTRY                                                             
           ,mySCounty                        -- SHIP_TO_A                                                                           
DDRESS_COUNTY                                                                                                                       
           ,mySAddressId                     -- SHIP_TO_ADDRESS_                                                                    
ID                                                                                                                                  
           ,mySAddress1                      -- SHIP_TO_ADDRESS_LINE_1                                                              
           ,mySAddress2                      -- SHIP_TO_                                                                            
ADDRESS_LINE_2                                                                                                                      
           ,mySAddress3                      -- SHIP_TO_ADDRESS                                                                     
_LINE_3                                                                                                                             
           ,mySAddress4                      -- SHIP_TO_ADDRESS_LINE_4                                                              
                                                                                                                                    
           ,mySState                         -- SHIP_TO_ADDRESS_STATE                                                               
           ,mySZip                           -- SHIP_TO_ADD                                                                         
RESS_ZIP                                                                                                                            
           ,c1r.CONTACT_EMAIL                -- SHIP_TO_CONTACT_EMAIL                                                               
                                                                                                                                    
           ,c1r.CONTACT_PHONE_NBR            -- SHIP_TO_CONTACT_PHONE                                                               
           ,c1r.CUSTOMER_NUMBER              -- SHIP_TO_CUS                                                                         
TOMER                                                                                                                               
           ,c1r.CUSTOMER_ID                  -- SHIP_TO_CUSTOMER_ID                                                                 
           ,myInvOrdType			             -- TRANSACTION_T                                                                            
YPE_NAME                                                                                                                            
           ,c1r.UOM                          -- UNIT_OF_MEASURE_CODE                                                                
           ,myUserId                         -- CREA                                                                                
TED_BY                                                                                                                              
           ,SYSDATE                          -- CREATION_DATE                                                                       
           ,'MANUFACTURING - SAN JOSE'       -- WAREHOUSE                                                                           
           ,2                                -- WAREHOU                                                                             
SE_ID                                                                                                                               
           ,myECHdrId                        -- EC_HEADER_ID                                                                        
           ,'INSERT'                         -- OPERATION_CODE                                                                      
           ,c1r.ORG_ID --ORG_ID              -- ORG_                                                                                
ID                                                                                                                                  
           ,'Standard'                       -- SERVICE_LEVEL_CODE                                                                  
           ,'Absorb'                         -- FREIGHT_PAYM                                                                        
ENT_METHOD_CODE                                                                                                                     
           ,'CIP'                            -- FREIGHT_TERMS_                                                                      
CODE                                                                                                                                
           ,'N'                              -- FRT_CARRIER_OVERRIDE_FLAG                                                           
                                                                                                                                    
           ,myECItemNbr		        			   -- INVENTORY_ITEM                                                                            
           ,myECItemID				            -- INVENTORY_ITEM_ID                                                                          
           ,'STANDARD'                       -- ITEM_TYPE_CODE                                                                      
           ,SYSDATE                          -- LAST_U                                                                              
PDATE_DATE                                                                                                                          
           ,c1r.PRICE                        -- LIST_PRICE                                                                          
           ,'N'                              -- OPTION_FLAG                                                                         
           ,c1r.QUANTITY                     -- ORDE                                                                                
RED_QUANTITY                                                                                                                        
           ,c1r.PRICE                        -- SELLING_PRICE                                                                       
           );                                                                                                                       
                                                                                                                                    
          	if myFreight > 0 then                                                                                                    
          		mySect := 'Pro - US Freight';                                                                                           
          		-- dbms_output.put_line('insert cec prices adju');                                                                      
          		insert into XXCTS_OMAR_CEC_PRICE_ADJMTS (                                                                               
	            OPERATION_CODE                                                                                                         
	           ,EC_HEADER_ID                                                                                                           
	           ,CREATION_DATE                                                                                                          
	           ,CREATED_BY                                                                                                             
	           ,LAST_UPDATE_DATE                                                                                                       
	           ,AUTOMATIC_FLAG                                                                                                         
	           ,PERCENT                                                                                                                
	           ,INVENTORY_ITEM                                                                                                         
	           ,INVENTORY_ITEM_ID                                                                                                      
	           ,ADJUSTED_AMOUNT                                                                                                        
	           ) values (                                                                                                              
	           'INSERT'                                                                                                                
	           ,myECHdrId                                                                                                              
	           ,SYSDATE                                                                                                                
	           ,myUserID                                                                                                               
	           ,SYSDATE                                                                                                                
	           ,'N'                                                                                                                    
	           ,0                                                                                                                      
	           ,'FREIGHT'                                                                                                              
	           ,547797                                                                                                                 
	           ,myFreight                                                                                                              
	           );                                                                                                                      
	       	end if;                                                                                                                    
                                                                                                                                    
         	if c1r.UOM != 'LT' then                                                                                                   
         		mySect := 'Pro - US Notes';                                                                                              
         		-- dbms_output.put_line('insert cec notes');                                                                             
               insert into XXCTS_OMAR_CEC_NOTES (                                                                                   
               CREATED_BY                                                                                                           
              ,CREATED_BY_USER_NAME                                                                                                 
              ,CREATION_DATE                                                                                                        
              ,EC_HEADER_ID                                                                                                         
              ,EC_LINE_ID                                                                                                           
              ,LAST_UPDATE_DATE                                                                                                     
              ,LAST_UPDATE_USER_NAME                                                                                                
              ,LAST_UPDATED_BY                                                                                                      
              ,NOTE_TYPE_CODE                                                                                                       
              ,NOTES                                                                                                                
              ,OPERATION_CODE                                                                                                       
              ,OVERRIDE_FLAG                                                                                                        
              ,USAGE                                                                                                                
              ,USAGE_ID                                                                                                             
              ) values (                                                                                                            
               myUserID                                                                                                             
              ,'CA_ADMIN'                                                                                                           
              ,SYSDATE                                                                                                              
              ,myECHdrId                                                                                                            
              ,myECLineId                                                                                                           
              ,SYSDATE                                                                                                              
              ,'CA_ADMIN'                                                                                                           
              ,myUserID                                                                                                             
              ,'SN'                                                                                                                 
              ,myNotes                                                                                                              
              ,'INSERT'                                                                                                             
              ,'N'                                                                                                                  
              ,null                                                                                                                 
              ,null                                                                                                                 
              );                                                                                                                    
				end if;                                                                                                                         
			else                                                                                                                             
				mySect := 'Pro - BV Lines';                                                                                                     
            select XXCTS_OMAR_BV_CEC_LINES_S.NEXTVAL                                                                                
         	into   myECLineId                                                                                                         
         	from   dual;                                                                                                              
                                                                                                                                    
				-- dbms_output.put_line('insert cec bv lines');                                                                                 
            insert into XXCTS_OMAR_BV_CEC_LINES                                                                                     
           (DELIVERY_REQUIRED_FLAG                                                                                                  
           ,DUTY_ATTRIBUTE                                                                                                          
           ,DUTY_ATTRIBUTE_OVERRIDE_FLAG                                                                                            
           ,EC_LINE_ID                                                                                                              
           ,EC_LINE_NUMBER                                                                                                          
           ,FOB_POINT_CODE                                                                                                          
           ,SHIP_TO_ADDRESS_CITY                                                                                                    
           ,SHIP_TO_ADDRESS_COUNTRY                                                                                                 
           ,SHIP_TO_ADDRESS_COUNTY                                                                                                  
           ,SHIP_TO_ADDRESS_ID                                                                                                      
           ,SHIP_TO_ADDRESS_LINE_1                                                                                                  
           ,SHIP_TO_ADDRESS_LINE_2                                                                                                  
           ,SHIP_TO_ADDRESS_LINE_3                                                                                                  
           ,SHIP_TO_ADDRESS_LINE_4                                                                                                  
           ,SHIP_TO_ADDRESS_STATE                                                                                                   
           ,SHIP_TO_ADDRESS_ZIP                                                                                                     
           ,SHIP_TO_CONTACT_EMAIL                                                                                                   
           ,SHIP_TO_CONTACT_PHONE                                                                                                   
           ,SHIP_TO_CUSTOMER                                                                                                        
           ,SHIP_TO_CUSTOMER_ID                                                                                                     
           ,TRANSACTION_TYPE_NAME                                                                                                   
           ,UNIT_OF_MEASURE_CODE                                                                                                    
           ,CREATED_BY                                                                                                              
           ,CREATION_DATE                                                                                                           
           ,WAREHOUSE                                                                                                               
           ,WAREHOUSE_ID                                                                                                            
           ,EC_HEADER_ID                                                                                                            
           ,OPERATION_CODE                                                                                                          
           ,ORG_ID                                                                                                                  
           ,SERVICE_LEVEL_CODE                                                                                                      
           ,FREIGHT_PAYMENT_METHOD_CODE                                                                                             
           ,FREIGHT_TERMS_CODE                                                                                                      
           ,FRT_CARRIER_OVERRIDE_FLAG                                                                                               
           ,INVENTORY_ITEM                                                                                                          
           ,INVENTORY_ITEM_ID                                                                                                       
           ,ITEM_TYPE_CODE                                                                                                          
           ,LAST_UPDATE_DATE                                                                                                        
           ,LIST_PRICE                                                                                                              
           ,OPTION_FLAG                                                                                                             
           ,ORDERED_QUANTITY                                                                                                        
           ,SELLING_PRICE                                                                                                           
           ) values (                                                                                                               
            'N' 										-- DELIVERY_REQUIRED_FLAG                                                                                 
           ,'N'                              -- DUTY_ATTRIBUTE                                                                      
           ,'N'                              -- DUTY_ATTRIBUTE_OV                                                                   
ERRIDE_FLAG                                                                                                                         
           ,myECLineId                       -- EC_LINE_ID                                                                          
           ,myLineNbr		                  -- EC_LINE_NUMBER                                                                          
           ,'Customer Premises'              -- FOB_                                                                                
POINT_CODE                                                                                                                          
           ,mySCity                          -- SHIP_TO_ADDRESS_CIT                                                                 
Y                                                                                                                                   
           ,mySCountry                       -- SHIP_TO_ADDRESS_COUNTRY                                                             
           ,mySCounty                        -- SHIP_TO_                                                                            
ADDRESS_COUNTY                                                                                                                      
           ,mySAddressId                     -- SHIP_TO_ADDRESS                                                                     
_ID                                                                                                                                 
           ,mySAddress1                      -- SHIP_TO_ADDRESS_LINE_1                                                              
           ,mySAddress2                      -- SHIP_TO                                                                             
_ADDRESS_LINE_2                                                                                                                     
           ,mySAddress3                      -- SHIP_TO_ADDRES                                                                      
S_LINE_3                                                                                                                            
           ,mySAddress4                      -- SHIP_TO_ADDRESS_LINE_                                                               
4                                                                                                                                   
           ,mySState                         -- SHIP_TO_ADDRESS_STATE                                                               
           ,mySZip                           -- SHIP_TO_AD                                                                          
DRESS_ZIP                                                                                                                           
           ,c1r.CONTACT_EMAIL                -- SHIP_TO_CONTACT_EMAI                                                                
L                                                                                                                                   
           ,c1r.CONTACT_PHONE_NBR            -- SHIP_TO_CONTACT_PHONE                                                               
           ,c1r.CUSTOMER_NUMBER              -- SHIP_TO_CU                                                                          
STOMER                                                                                                                              
           ,c1r.CUSTOMER_ID                  -- SHIP_TO_CUSTOMER_ID                                                                 
           ,myInvOrdType		               -- TRANSACTION                                                                             
_TYPE_NAME                                                                                                                          
           ,c1r.UOM                          -- UNIT_OF_MEASURE_COD                                                                 
E                                                                                                                                   
           ,myUserId                         -- CREATED_BY                                                                          
           ,SYSDATE                          -- CREATION_DATE                                                                       
           ,'MANUFACTURING - SAN JOSE'       -- WAREHOUSE                                                                           
           ,2                                -- WAREH                                                                               
OUSE_ID                                                                                                                             
           ,myEcHdrId                        -- EC_HEADER_ID                                                                        
           ,'INSERT'                         -- OPERATION_COD                                                                       
E                                                                                                                                   
           ,c1r.ORG_ID --ORG_ID              -- ORG_ID                                                                              
           ,'Standard'                       -- SERVICE_LEVEL_CODE                                                                  
           ,'Absorb'                         -- FREIGHT_PA                                                                          
YMENT_METHOD_CODE                                                                                                                   
           ,'CIP'                            -- FREIGHT_TERM                                                                        
S_CODE                                                                                                                              
           ,'N'                              -- FRT_CARRIER_OVERRIDE_FL                                                             
AG                                                                                                                                  
           ,myECItemNbr		        			   -- INVENTORY_ITEM                                                                            
           ,myECItemID				            -- INVENTORY_ITEM_ID                                                                          
           ,'STANDARD'                       -- ITEM_TYPE_CODE                                                                      
           ,SYSDATE                          -- LAST                                                                                
_UPDATE_DATE                                                                                                                        
           ,c1r.PRICE                        -- LIST_PRICE                                                                          
           ,'N'                              -- OPTION_FLA                                                                          
G                                                                                                                                   
           ,c1r.QUANTITY                     -- ORDERED_QUANTITY                                                                    
           ,c1r.PRICE                        -- SELLING_PRICE                                                                       
           );                                                                                                                       
                                                                                                                                    
          	if myFreight > 0 then                                                                                                    
          		mySect := 'Pro - BV Freight';                                                                                           
          		-- dbms_output.put_line('insert cec bv pric adj');                                                                      
          		insert into XXCTS_OMAR_BV_CEC_PRICE_ADJMTS (                                                                            
                                                                                                                                    
	            OPERATION_CODE                                                                                                         
	           ,EC_HEADER_ID                                                                                                           
	           ,CREATION_DATE                                                                                                          
	           ,CREATED_BY                                                                                                             
	           ,LAST_UPDATE_DATE                                                                                                       
	           ,AUTOMATIC_FLAG                                                                                                         
	           ,PERCENT                                                                                                                
	           ,INVENTORY_ITEM                                                                                                         
	           ,INVENTORY_ITEM_ID                                                                                                      
	           ,ADJUSTED_AMOUNT                                                                                                        
	           ) values (                                                                                                              
	           'INSERT'                                                                                                                
	           ,myECHdrId                                                                                                              
	           ,SYSDATE                                                                                                                
	           ,myUserID                                                                                                               
	           ,SYSDATE                                                                                                                
	           ,'N'                                                                                                                    
	           ,0                                                                                                                      
	           ,'FREIGHT'                                                                                                              
	           ,547797                                                                                                                 
	           ,myFreight                                                                                                              
	           );                                                                                                                      
	       	end if;                                                                                                                    
                                                                                                                                    
         	if c1r.UOM != 'LT' then                                                                                                   
         		mySect := 'Pro - BV Notes';                                                                                              
         		-- dbms_output.put_line('insert cec bv notes');                                                                          
               insert into XXCTS_OMAR_BV_CEC_NOTES (                                                                                
               CREATED_BY                                                                                                           
              ,CREATED_BY_USER_NAME                                                                                                 
              ,CREATION_DATE                                                                                                        
              ,EC_HEADER_ID                                                                                                         
              ,EC_LINE_ID                                                                                                           
              ,LAST_UPDATE_DATE                                                                                                     
              ,LAST_UPDATE_USER_NAME                                                                                                
              ,LAST_UPDATED_BY                                                                                                      
              ,NOTE_TYPE_CODE                                                                                                       
              ,NOTES                                                                                                                
              ,OPERATION_CODE                                                                                                       
              ,OVERRIDE_FLAG                                                                                                        
              ,USAGE                                                                                                                
              ,USAGE_ID                                                                                                             
              ) values (                                                                                                            
               myUserID                                                                                                             
              ,'CA_ADMIN'                                                                                                           
              ,SYSDATE                                                                                                              
              ,myECHdrId                                                                                                            
              ,myECLineId                                                                                                           
              ,SYSDATE                                                                                                              
              ,'CA_ADMIN'                                                                                                           
              ,myUserID                                                                                                             
              ,'SN'                                                                                                                 
              ,myNotes                                                                                                              
              ,'INSERT'                                                                                                             
              ,'N'                                                                                                                  
              ,null                                                                                                                 
              ,null                                                                                                                 
              );                                                                                                                    
				end if;                                                                                                                         
                                                                                                                                    
			end if;                                                                                                                          
                                                                                                                                    
         mySect := 'Pro - QTC Invoice';                                                                                             
         -- dbms_output.put_line('insert cec qtc invoice');                                                                         
         insert into XXDEX_CISCO_QTC_INVOICE (                                                                                      
         EC_HEADER_ID                                                                                                               
        ,EC_LINE_ID                                                                                                                 
        ,DEX_RMA_NBR                                                                                                                
        ,DEX_SHIP_ID                                                                                                                
        ,SERIAL_NUMBER                                                                                                              
        ,SERIAL_ID                                                                                                                  
        ) values (                                                                                                                  
         myECHdrId                                                                                                                  
        ,myECLineId                                                                                                                 
        ,c1r.RMA_NBR                                                                                                                
        ,c1r.SHIP_ID                                                                                                                
        ,decode(c1r.UOM,'LT',null,c1r.SERIAL_NUMBER)                                                                                
        ,decode(c1r.UOM,'LT',null,c1r.SERIAL_ID)                                                                                    
        );                                                                                                                          
                                                                                                                                    
      end loop;                                                                                                                     
      -- dbms_output.put_line('end c1 loop');                                                                                       
                                                                                                                                    
      -- dbms_output.put_line('call inv updates');                                                                                  
      QTC_INVOICE_UPDTS;                                                                                                            
                                                                                                                                    
                                                                                                                                    
      mySect := 'Pro - Complete';                                                                                                   
                                                                                                                                    
                                                                                                                                    
   exception                                                                                                                        
      when ABORT_PROC then                                                                                                          
         rollback to INVPROC_SAVEPOINT;                                                                                             
         RAISE_APPLICATION_ERROR ( -20001,myRetMesg );                                                                              
                                                                                                                                    
      when OTHERS then                                                                                                              
         rollback to INVPROC_SAVEPOINT;                                                                                             
         RAISE_APPLICATION_ERROR ( -20001,mySect || ' ' || SQLERRM );                                                               
   end PROCESS;                                                                                                                     
                                                                                                                                    
                                                                                                                                    
   /*********************************************************                                                                       
*****************************************/                                                                                          
                                                                                                                                    
   function PROCESS (                                                                                                               
                       myOrder    varchar2                                                                                          
                      ,myShipNo   number                                                                                            
                      ,myMultiInv varchar2 default null                                                                             
                      ,myTrxDate  date default null                                                                                 
                    )  return varchar2 is                                                                                           
   begin                                                                                                                            
      PROCESS( myOrder,myShipNo,myMultiInv,myTrxDate );                                                                             
                                                                                                                                    
                                                                                                                                    
      return ( null );                                                                                                              
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
           return ( SQLERRM || ' (' || mySect || ')' );                                                                             
   end PROCESS;                                                                                                                     
                                                                                                                                    
   /*********************************************************************                                                           
*****************************/                                                                                                      
                                                                                                                                    
   procedure CREDIT (                                                                                                               
                      myReturnOrder  varchar2                                                                                       
                    ) is                                                                                                            
                                                                                                                                    
   begin                                                                                                                            
   	return;                                                                                                                         
   end CREDIT;                                                                                                                      
                                                                                                                                    
   /*******************************************************************                                                             
*******************************/                                                                                                    
                                                                                                                                    
   procedure CORE (                                                                                                                 
                    myRetMesg   out   varchar2                                                                                      
                   ,myRetCode   out   number                                                                                        
                   ,myOrder     in    varchar2                                                                                      
                   ,myShipNo    in    number                                                                                        
                   ,myPCust     in    varchar2   default null                                                                       
                   ,myProcType  in    varchar2   default 'N'                                                                        
                   ,myPWaybill        in    varchar2 de                                                                             
fault null                                                                                                                          
                  ) is                                                                                                              
      ABORT_PROC      exception;                                                                                                    
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
   exception                                                                                                                        
      when ABORT_PROC then                                                                                                          
         myRetCode := 1;                                                                                                            
                                                                                                                                    
      when OTHERS then                                                                                                              
         myRetCode := 2;                                                                                                            
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end CORE;                                                                                                                        
                                                                                                                                    
   /***********************************************************                                                                     
***************************************/                                                                                            
    -- This will be called when a Sales Return RMA is created.                                                                      
 It will issue a Credit Shipment against                                                                                            
    -- the DEXCR Cust for this Order. This is to reduce the Rev                                                                     
enue against the Sales Order when there                                                                                             
    -- is a pending Sales Return.  Sales Return RMA may be again                                                                    
st multiple shipments.                                                                                                              
    -- The procedure will also be called when Return Or                                                                             
der is processed thru QCR or when a Return RMA is                                                                                   
    -- Cancelled in order to reverse out the DEXCR Cre                                                                              
dit.                                                                                                                                
   procedure SALES_RTN (                                                                                                            
                         myRetMesg   out   varchar2                                                                                 
                        ,myRetCode   out   number                                                                                   
                        ,myOrder     in    varchar2                                                                                 
                        ,myRMA       in    varchar2                                                                                 
                        ,myPCust     in    varchar2 default null                                                                    
                        ,myProcType  in    varchar2 default 'N'                                                                     
    -- N-Normal   A-Accept   R-Reject(Cancel Return)                                                                                
   C-Cust Credit   D-Cust Debit                                                                                                     
                       ) is                                                                                                         
      ABORT_PROC      exception;                                                                                                    
                                                                                                                                    
   begin                                                                                                                            
                                                                                                                                    
      myRetCode := 0;                                                                                                               
      myRetMesg := NULL;                                                                                                            
                                                                                                                                    
      RETURN;                                                                                                                       
   exception                                                                                                                        
      when ABORT_PROC then                                                                                                          
         myRetCode := 1;                                                                                                            
                                                                                                                                    
      when OTHERS then                                                                                                              
         myRetCode := 2;                                                                                                            
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end SALES_RTN;                                                                                                                   
                                                                                                                                    
   /*****************************************************************                                                               
*********************************/                                                                                                  
    -- This is called when an Advance Core is received in. It will ne                                                               
ed to Debit back the DEXCR for                                                                                                      
    -- the Qty Returned and then issue a Credit Memo to the Real Customer                                                           
 for the Qty Rtnd * Core Price                                                                                                      
    -- This logic was previously in the CORE section but it wasn't taking                                                           
 into account for multiple                                                                                                          
    -- shipments and nbr of quantity being received at a time.  The Core Cred                                                       
it is also changed to be one                                                                                                        
    -- transaction for the credit amount instead of 2 transation (1st - cre                                                         
dit old amt, 2nd - debit new amt).                                                                                                  
   --                                                                                                                               
    -- DR# 56684 (AC) - Added a SerialID parameter because the                                                                      
Core needs to be Reversed by individual                                                                                             
    --                  Track at QCP for DELL GSD                                                                                   
   procedure ADV_CORE (                                                                                                             
                    myRetMesg   out   varchar2                                                                                      
                   ,myRetCode   out   number                                                                                        
                   ,myCOrder    in    varchar2                                                                                      
                   ,myProcType  in    varchar2                                                                                      
                   ,myPCust     in    varchar2   default null                                                                       
                   ,mySerialID  in    number     defau                                                                              
lt null                                                                                                                             
                      ) is                                                                                                          
                                                                                                                                    
      ABORT_PROC      exception;                                                                                                    
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
   exception                                                                                                                        
      when ABORT_PROC then                                                                                                          
         myRetCode := 1;                                                                                                            
                                                                                                                                    
      when OTHERS then                                                                                                              
         myRetCode := 2;                                                                                                            
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end ADV_CORE;                                                                                                                    
                                                                                                                                    
                                                                                                                                    
	/*****************************************************                                                                             
***********************************************                                                                                     
	 This procedure will first try to update the Invoice Nu                                                                            
mber on the XXDEX_CISCO_QTC_INVOICE table                                                                                           
	 by querying ODS Boundry Sysetm for the EC Header/Line ID whe                                                                      
n first creating invoice.                                                                                                           
	 **************************************************                                                                                
**************************************************/                                                                                 
	procedure QTC_INVOICE_UPDTS is                                                                                                     
                                                                                                                                    
		pragma autonomous_transaction;                                                                                                    
                                                                                                                                    
		myInvNbr     	XXCTS_ODS_OM_RA_CUSTOMER_TRX.TRX_NUMBER%type;                                                                       
		myTrxDate		XXCTS_ODS_OM_RA_CUSTOMER_TRX.TRX_DATE%ty                                                                               
pe;                                                                                                                                 
		myInvAmt       XXCTS_ODS_OM_RA_CUST_TRX_LINES.EXTENDED_AMOUNT%type;                                                               
		myTaxAmt       XXCTS_ODS_OM_RA_CUST_TRX_LINES.EXTENDED                                                                            
_AMOUNT%type;                                                                                                                       
		myCurrCd       XXCTS_ODS_OM_RA_CUSTOMER_TRX.INVOICE_CURRENCY_C                                                                    
ODE%type;                                                                                                                           
		myCurrRate     XXCTS_ODS_OM_GL_DAILY_RATES.CONVERSION_RATE%type;                                                                  
		mySalesOrder	XXCTS_ODS_OM_OE_ORDER_HDRS_ALL.ORDER_N                                                                               
UMBER%type;                                                                                                                         
                                                                                                                                    
                                                                                                                                    
		cursor c0 is                                                                                                                      
			select EC_HEADER_ID                                                                                                              
					,EC_LINE_ID                                                                                                                    
			from   XXDEX_CISCO_QTC_INVOICE                                                                                                   
			where  nvl(STATUS,'O') != 'P'                                                                                                    
			and    QTC_INVOICE_NBR is null;                                                                                                  
                                                                                                                                    
		cursor c1 is                                                                                                                      
			select DEX_SHIP_ID                                                                                                               
					,QTC_INVOICE_NBR                                                                                                               
					,trunc(QTC_INVOICE_DATE) QTC_INVOICE_DATE                                                                                      
					,sum(INVOICE_AMT) INVOICE_AMT                                                                                                  
					,sum(TAX_AMT) TAX_AMT                                                                                                          
					,sum(DISC_AMT) DISC_AMT                                                                                                        
			from   XXDEX_CISCO_QTC_INVOICE                                                                                                   
			where  nvl(STATUS,'O') != 'P'                                                                                                    
			and    QTC_INVOICE_NBR is not null                                                                                               
			group by DEX_SHIP_ID                                                                                                             
					  ,QTC_INVOICE_NBR                                                                                                             
					  ,trunc(QTC_INVOICE_DATE);                                                                                                    
                                                                                                                                    
                                                                                                                                    
		cursor c2 (myShipID number) is                                                                                                    
			select *                                                                                                                         
			from   XXDEX_CISCO_QTC_INVOICE                                                                                                   
			where  DEX_SHIP_ID = myShipID                                                                                                    
			and    SERIAL_ID is not null                                                                                                     
			and    QTC_INVOICE_NBR is not null;                                                                                              
                                                                                                                                    
	begin                                                                                                                              
		SAVEPOINT QCTUPDT_SAVEPOINT;                                                                                                      
		mySect := 'QTC-Updt ODS Inv';                                                                                                     
		for r0 in c0 loop                                                                                                                 
			-- Query provided by QTC Team                                                                                                    
			begin                                                                                                                            
				SELECT OOHA.ORDER_NUMBER "SALES_ORDER_NBR",                                                                                     
				    	 ORCT.TRX_NUMBER "QTC_INVOICE_NBR",                                                                                        
				    	 ORCTLL.EXTENDED_AMOUNT INVOICE_LINE_AMT ,                                                                                 
				    	 ORCTLT.EXTENDED_AMOUNT TAX_AMOUNT,                                                                                        
				    	 ORCT.INVOICE_CURRENCY_CODE "CURRENCY_CODE",                                                                               
				    	 NVL(APS.EXCHANGE_RATE,1) "CURRENCY_RATE",                                                                                 
				    	 ORCT.TRX_DATE                                                                                                             
				into   mySalesOrder,                                                                                                            
						 myInvNbr,                                                                                                                    
						 myInvAmt,                                                                                                                    
						 myTaxAmt,                                                                                                                    
						 myCurrCd,                                                                                                                    
						 myCurrRate,                                                                                                                  
						 myTrxDate                                                                                                                    
				FROM                                                                                                                            
				    	 XXCTS_ODS_OM_CEC_HEADERS OCH,                                                                                             
				    	 XXCTS_ODS_OM_CEC_LINES OCL,                                                                                               
				    	 XXCTS_ODS_OM_OE_ORDER_HDRS_ALL OOHA,                                                                                      
				    	 XXCTS_ODS_OM_OE_ORDER_LNES_ALL OOLA,                                                                                      
				    	 XXCTS_ODS_OM_RA_CUSTOMER_TRX ORCT,                                                                                        
				    	 XXCTS_ODS_OM_RA_CUST_TRX_LINES ORCTLL, -- LINE                                                                            
				    	 XXCTS_ODS_OM_RA_CUST_TRX_LINES ORCTLT, -- TAX                                                                             
				    	 XXCTS_ODS_OM_AR_PAYMNT_SCHDLES APS                                                                                        
				WHERE 1=1                                                                                                                       
				AND    OCH.EC_HEADER_ID=OCL.EC_HEADER_ID                                                                                        
				AND    OCH.EC_ORDER_NUMBER=OOHA.ORIG_SYS_DOCUMENT_R                                                                             
EF                                                                                                                                  
				AND    OOHA.HEADER_ID=OOLA.HEADER_ID                                                                                            
				AND    OCL.EC_LINE_ID=OOLA.ORIG_SYS_LINE_REF                                                                                    
				AND    ORCT.CUSTOMER_TRX_ID=ORCTLL.CUSTOMER_TRX_ID                                                                              
				AND    ORCT.CUSTOMER_TRX_ID=ORCTLT.CUSTOMER_TRX_ID                                                                              
				AND    ORCT.CUSTOMER_TRX_ID=APS.CUSTOMER_TRX_ID                                                                                 
				AND    TO_CHAR(OOHA.ORDER_NUMBER)=(ORCT.INTERFACE_HEA                                                                           
DER_ATTRIBUTE1)                                                                                                                     
				AND    TO_CHAR(OOLA.LINE_ID)=(ORCTLL.INTERFACE_LINE_ATTRIB                                                                      
UTE6)                                                                                                                               
				AND    ORCTLL.CUSTOMER_TRX_LINE_ID=ORCTLT.LINK_TO_CUST_TRX_LINE_ID                                                              
				AND    ORCTLL.LINE_TYPE='LINE'                                                                                                  
				AND    ORCTLT.LINE_TYPE='TAX'                                                                                                   
				AND    OCH.EC_HEADER_ID = r0.EC_HEADER_ID                                                                                       
				AND    OCL.EC_LINE_ID   = r0.EC_LINE_ID                                                                                         
				AND    rownum < 2;                                                                                                              
                                                                                                                                    
				--dbms_output.put_line('lineId: ' || r0.EC_LINE_                                                                                
ID || ' Nbr: ' || myInvNbr || ' Amt: ' ||  myInvAmt                                                                                 
|| ' Tax: ' || myTaxAmt);                                                                                                           
				update XXDEX_CISCO_QTC_INVOICE set                                                                                              
			   QTC_INVOICE_NBR = myInvNbr                                                                                                    
			  ,INVOICE_AMT     = myInvAmt                                                                                                    
			  ,TAX_AMT         = myTaxAmt                                                                                                    
			  ,CURRENCY_CODE   = myCurrCd                                                                                                    
			  ,CURRENCY_RATE   = myCurrRate                                                                                                  
			  ,QTC_SALES_ORDER = mySalesOrder                                                                                                
			  ,QTC_INVOICE_DATE = myTrxDate                                                                                                  
			   where EC_HEADER_ID = r0.EC_HEADER_ID                                                                                          
			   and   EC_LINE_ID   = r0.EC_LINE_ID;                                                                                           
			exception                                                                                                                        
				when NO_DATA_FOUND then                                                                                                         
					--dbms_output.put_line('lineId: ' || r0.EC_LINE_ID || ' no                                                                     
data found');                                                                                                                       
					null;                                                                                                                          
			end;                                                                                                                             
		end loop;                                                                                                                         
                                                                                                                                    
		mySect := 'QTC-Updt Shphdrs';                                                                                                     
		--dbms_output.put_line('before c1 loop');                                                                                         
		for r1 in c1 loop                                                                                                                 
			--dbms_output.put_line('shipid: ' || r1.DEX_SHIP_ID || ' inv: '                                                                  
 || r1.QTC_INVOICE_NBR || ' amt: ' || r1.INVOICE_AMT                                                                                
);                                                                                                                                  
			update DEX_SHPHDRS set                                                                                                           
			INVOICE = r1.QTC_INVOICE_NBR                                                                                                     
		  ,INVOICE_AMOUNT = r1.INVOICE_AMT                                                                                                
		  ,TAX_AMOUNT = r1.TAX_AMT                                                                                                        
		  ,DISCOUNT_AMOUNT = r1.DISC_AMT                                                                                                  
		  ,DATEINV = r1.QTC_INVOICE_DATE                                                                                                  
		   where SHIP_ID = r1.DEX_SHIP_ID;                                                                                                
                                                                                                                                    
		   -- update individual serials                                                                                                   
		   mySect := 'QTC-Updt Serial';                                                                                                   
		   for r2 in c2 (r1.DEX_SHIP_ID) loop                                                                                             
		   	--dbms_output.put_line('SerialID: ' || r2.SERIAL_ID || ' ser amt: '                                                           
 || r2.INVOICE_AMT);                                                                                                                
		   	update DEX_SERIALS set                                                                                                        
		   	ATTRIBUTE6 = r2.INVOICE_AMT                                                                                                   
		     ,ATTRIBUTE7 = r2.TAX_AMT                                                                                                     
		     ,ATTRIBUTE8 = r2.DISC_AMT                                                                                                    
		      where SERIAL_ID = r2.SERIAL_ID;                                                                                             
			end loop;                                                                                                                        
                                                                                                                                    
			update XXDEX_CISCO_QTC_INVOICE set                                                                                               
			STATUS = 'P'                                                                                                                     
			where  DEX_SHIP_ID = r1.DEX_SHIP_ID;                                                                                             
		end loop;                                                                                                                         
		--dbms_output.put_line('after c1 loop');                                                                                          
		-- purge any processed ones older than 60 days                                                                                    
		/*                                                                                                                                
		delete XXDEX_CISCO_QTC_INVOICE                                                                                                    
		where  STATUS = 'P'                                                                                                               
		and    QTC_INVOICE_DATE < trunc(SYSDATE) - 60;                                                                                    
		*/                                                                                                                                
                                                                                                                                    
		commit;                                                                                                                           
                                                                                                                                    
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			rollback to QCTUPDT_SAVEPOINT;                                                                                                   
	end QTC_INVOICE_UPDTS;                                                                                                             
                                                                                                                                    
end XXDEX_CISCO_INVOICE_K;                                                                                                          
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

