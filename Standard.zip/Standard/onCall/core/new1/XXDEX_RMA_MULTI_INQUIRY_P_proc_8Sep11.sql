                                                                                                                                    
  CREATE OR REPLACE PROCEDURE "APPS"."XXDEX_RMA_MULTI_INQUIRY_P"                                                                    
(                                                                                                                                   
 myRetMesg   out      varchar2                                                                                                      
,myRetCode   out      number                                                                                                        
,myReportID  in  out  number                                                                                                        
,myCall      in       varchar2                                                                                                      
) is                                                                                                                                
/* $Header: XXDEX_RMA_MULTI_INQUIRY_P.sql 2.1.2.0 2010/06/08 12:00                                                                  
:00 dexsys ship $ Copyright (c) 2008 DEX Systems, In                                                                                
c. */                                                                                                                               
                                                                                                                                    
   myStatus    DEX_RMAHDR.STATUS%type;                                                                                              
   myOrder     DEX_RMAHDR.ORDERNO%type;                                                                                             
   myAuth      DEX_RMAHDR.AUTHORIZATION%type;                                                                                       
   myRMA       DEX_RMAHDR.CALL%type;                                                                                                
                                                                                                                                    
   myQty       RMADET.QTYORG%type;                                                                                                  
                                                                                                                                    
   myName      DEX_PLANTS.NAME%type;                                                                                                
                                                                                                                                    
   myPlantID   number(15);                                                                                                          
                                                                                                                                    
   mySect      varchar2(100);                                                                                                       
                                                                                                                                    
   ABORT_PROC  exception;                                                                                                           
                                                                                                                                    
   cursor c1 is                                                                                                                     
      select CALL                                                                                                                   
            ,ORDERNO                                                                                                                
            ,STATUS                                                                                                                 
            ,PLANT_ID                                                                                                               
      from   DEX_RMAHDR rmh                                                                                                         
      where  AUTHORIZATION = myAuth;                                                                                                
                                                                                                                                    
   cursor c2 is                                                                                                                     
      select rmd.PART                                                                                                               
            ,rmd.DESCR                                                                                                              
            ,sum(rmd.QTYORG - nvl(rmd.QTYRCV,0))  QTY                                                                               
      from   DEX_RMADET rmd                                                                                                         
      where  rmd.CALL = myRMA                                                                                                       
      group by rmd.PART,rmd.DESCR;                                                                                                  
                                                                                                                                    
   cursor c3 ( myPart varchar2 ) is                                                                                                 
      select rms.RMA_SERIAL_ID                                                                                                      
            ,rms.SERIAL                                                                                                             
      from   DEX_RMA_SERIALS rms                                                                                                    
            ,DEX_RMADET rmd                                                                                                         
      where  rmd.CALL = rms.CALL                                                                                                    
      and    rmd.ITEM = rms.ITEM                                                                                                    
      and    nvl(rms.STATUS,'O') != 'C'                                                                                             
      and    rmd.CALL = myRMA                                                                                                       
      and    rmd.PART = myPart;                                                                                                     
                                                                                                                                    
   cursor c4 is                                                                                                                     
      select ORDERNO                                                                                                                
            ,PLANT_ID                                                                                                               
      from   DEX_ORDERS                                                                                                             
      where  RMA = myCall;                                                                                                          
                                                                                                                                    
   cursor c5 is                                                                                                                     
      select lne.PART                                                                                                               
            ,lne.DESCRIPTION                                                                                                        
            ,ser.SERIAL_ID                                                                                                          
            ,nvl(ser.SERIAL,ser.TRACK) SERIAL                                                                                       
            ,ser.LOCATION                                                                                                           
            ,ser.DATELOC                                                                                                            
            ,ser.STORAGE                                                                                                            
            ,1                         QTY                                                                                          
      from   DEX_SERIALS ser                                                                                                        
            ,DEX_LINES lne                                                                                                          
      where  lne.ORDERNO = ser.ORDERNO                                                                                              
      and    lne.ITEM    = ser.ITEM                                                                                                 
      and    lne.ORDERNO = myOrder;                                                                                                 
                                                                                                                                    
   cursor c6 is                                                                                                                     
      select DATA01                          ITEM_NUMBER                                                                            
            ,DATA02                          DESCRIPTION                                                                            
                                                                                                                                    
            ,sum(QTY06)                      QTYORG                                                                                 
            ,sum(QTY07)                      QTYORD                                                                                 
            ,sum(decode(DATA05,'SHP',1,0))   QTYSHP                                                                                 
      from   DEX_REPORT_LINES                                                                                                       
      where  REPORT_ID = myReportID                                                                                                 
      and    TYPE      = 'D'                                                                                                        
      group by DATA01,DATA02;                                                                                                       
                                                                                                                                    
   cursor c7 is                                                                                                                     
      select ORDERNO                                                                                                                
            ,PLANT_ID                                                                                                               
      from   DEX_ORDERS                                                                                                             
      where  RMA = myRMA;                                                                                                           
                                                                                                                                    
   procedure PLANT_NAME is                                                                                                          
   begin                                                                                                                            
      select NAME                                                                                                                   
      into   myName                                                                                                                 
      from   DEX_PLANTS                                                                                                             
      where  PLANT_ID = myPlantID;                                                                                                  
   end PLANT_NAME;                                                                                                                  
                                                                                                                                    
begin                                                                                                                               
	myRetCode := 0;                                                                                                                    
                                                                                                                                    
   mySect := 'Init';                                                                                                                
                                                                                                                                    
   if myCall is null then                                                                                                           
      myRetMesg := 'RMA Number Required';                                                                                           
      raise ABORT_PROC;                                                                                                             
   end if;                                                                                                                          
                                                                                                                                    
   if myReportID > 0 then                                                                                                           
      mySect := 'Report Lines Purge';                                                                                               
                                                                                                                                    
      delete DEX_REPORT_LINES                                                                                                       
      where  REPORT_ID = myReportID;                                                                                                
                                                                                                                                    
      commit;                                                                                                                       
                                                                                                                                    
   else                                                                                                                             
      mySect := 'Report ID';                                                                                                        
                                                                                                                                    
      select DEX_REPORT_S.nextval                                                                                                   
      into   myReportID                                                                                                             
      from   DUAL;                                                                                                                  
   end if;                                                                                                                          
                                                                                                                                    
   mySect := 'Orig RMA';                                                                                                            
                                                                                                                                    
   begin                                                                                                                            
      select STATUS                                                                                                                 
            ,ORDERNO                                                                                                                
            ,PLANT_ID                                                                                                               
      into   myStatus                                                                                                               
            ,myOrder                                                                                                                
            ,myPlantID                                                                                                              
      from   DEX_RMAHDR                                                                                                             
      where  CALL = myCall;                                                                                                         
                                                                                                                                    
   exception                                                                                                                        
      when NO_DATA_FOUND then                                                                                                       
         myRetMesg := 'Invalid RMA #';                                                                                              
         raise ABORT_PROC;                                                                                                          
   end;                                                                                                                             
                                                                                                                                    
   dbms_output.put_line ( 'Call: ' || myCall || ' Status: ' || myStatus                                                             
|| ' Order: ' || myOrder );                                                                                                         
                                                                                                                                    
   mySect := 'Plant';                                                                                                               
                                                                                                                                    
   PLANT_NAME;                                                                                                                      
                                                                                                                                    
   if myStatus != 'C' then                                                                                                          
      myRMA := myCall;                                                                                                              
                                                                                                                                    
      mySect := 'c2 loop';                                                                                                          
                                                                                                                                    
      for c2r in c2 loop                                                                                                            
         myQty := c2r.QTY;                                                                                                          
                                                                                                                                    
         mySect := 'c3 loop';                                                                                                       
                                                                                                                                    
         for c3r in c3 ( c2r.PART ) loop                                                                                            
            mySect := 'Insert Detail (c3)';                                                                                         
                                                                                                                                    
            insert into DEX_REPORT_LINES                                                                                            
           (REPORT_LINE_ID,REPORT_ID,TYPE                                                                                           
           ,DATA01,DATA02,DATA03,DATA04,DATA05,DATA06,DATA07,DATA08                                                                 
           ,DATE01                                                                                                                  
           ,QTY04,QTY05,QTY06,QTY07                                                                                                 
           ) values (                                                                                                               
            DEX_REPORT_LINES_S.nextval,myReportID,'D'                                                                               
                                                                                                                                    
           ,c2r.PART,c2r.DESCR,c3r.SERIAL,myName,'RMA',null,myRMA,null                                                              
           ,to_date(null)                                                                                                           
           ,c3r.RMA_SERIAL_ID,null,1,0                                                                                              
           );                                                                                                                       
                                                                                                                                    
            myQty := myQty - 1;                                                                                                     
         end loop;                                                                                                                  
                                                                                                                                    
         if myQty > 0 then                                                                                                          
            mySect := 'Insert Detail (c2)';                                                                                         
                                                                                                                                    
            insert into DEX_REPORT_LINES                                                                                            
           (REPORT_LINE_ID,REPORT_ID,TYPE                                                                                           
           ,DATA01,DATA02,DATA03,DATA04,DATA05,DATA06,DAT                                                                           
A07,DATA08                                                                                                                          
           ,DATE01                                                                                                                  
           ,QTY04,QTY05,QTY06,QTY07                                                                                                 
           ) values (                                                                                                               
            DEX_REPORT_LINES_S.nextval,myReportID,'D'                                                                               
           ,c2r.PART,c2r.DESCR,'RMA (' || to_char(myQty) || ')',my                                                                  
Name,'RMA',null,myRMA,null                                                                                                          
           ,to_date(null)                                                                                                           
           ,null,null,myQty,0                                                                                                       
           );                                                                                                                       
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      commit;                                                                                                                       
   end if;                                                                                                                          
                                                                                                                                    
   mySect := 'c4 loop';                                                                                                             
                                                                                                                                    
   for c4r in c4 loop                                                                                                               
      myOrder   := c4r.ORDERNO;                                                                                                     
      myPlantID := c4r.PLANT_ID;                                                                                                    
                                                                                                                                    
      PLANT_NAME;                                                                                                                   
                                                                                                                                    
      dbms_output.put_line ( 'Order: ' || myOrder   );                                                                              
                                                                                                                                    
      mySect := 'c5 loop';                                                                                                          
                                                                                                                                    
      for c5r in c5 loop                                                                                                            
         mySect := 'Insert Detail (c5)';                                                                                            
                                                                                                                                    
         insert into DEX_REPORT_LINES                                                                                               
        (REPORT_LINE_ID,REPORT_ID,TYPE                                                                                              
        ,DATA01,DATA02,DATA03,DATA04,DATA05,DATA06,DATA                                                                             
07,DATA08                                                                                                                           
        ,DATE01                                                                                                                     
        ,QTY04,QTY05,QTY06,QTY07                                                                                                    
        ) values (                                                                                                                  
         DEX_REPORT_LINES_S.nextval,myReportID,'D'                                                                                  
        ,c5r.PART,c5r.DESCRIPTION,c5r.SERIAL,myName,c                                                                               
5r.LOCATION,c5r.STORAGE,null,myOrder                                                                                                
        ,c5r.DATELOC                                                                                                                
        ,null,c5r.SERIAL_ID,c5r.QTY,c5r.QTY                                                                                         
        );                                                                                                                          
      end loop;                                                                                                                     
                                                                                                                                    
      commit;                                                                                                                       
                                                                                                                                    
      myAuth := myOrder;                                                                                                            
                                                                                                                                    
      dbms_output.put_line ( 'Auth: ' || myAuth  );                                                                                 
                                                                                                                                    
      mySect := 'c1 loop';                                                                                                          
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         myRMA     := c1r.CALL;                                                                                                     
         myStatus  := c1r.STATUS;                                                                                                   
         myPlantID := c1r.PLANT_ID;                                                                                                 
                                                                                                                                    
         mySect := 'Plant (c1)';                                                                                                    
                                                                                                                                    
         PLANT_NAME;                                                                                                                
                                                                                                                                    
         if myStatus != 'C' then                                                                                                    
            mySect := 'c2 loop (c1)';                                                                                               
                                                                                                                                    
            for c2r in c2 loop                                                                                                      
               myQty := c2r.QTY;                                                                                                    
                                                                                                                                    
               mySect := 'c3 loop (c2)';                                                                                            
                                                                                                                                    
               for c3r in c3 ( c2r.PART ) loop                                                                                      
                  mySect := 'Insert Detail (c3)';                                                                                   
                                                                                                                                    
                  insert into DEX_REPORT_LINES                                                                                      
                 (REPORT_LINE_ID,REPORT_ID,TYPE                                                                                     
                 ,DATA01,DATA02,DATA03,DATA04,DATA05,DATA06,DATA07,DATA08                                                           
                 ,DATE01                                                                                                            
                 ,QTY04,QTY05,QTY06,QTY07                                                                                           
                 ) values (                                                                                                         
                  DEX_REPORT_LINES_S.nextval,myReportID,'D'                                                                         
                 ,c2r.PART,c2r.DESCR,c3r.SERIAL,myName,                                                                             
'RMA',null,myRMA,null                                                                                                               
                 ,to_date(null)                                                                                                     
                 ,c3r.RMA_SERIAL_ID,null,1,0                                                                                        
                 );                                                                                                                 
                                                                                                                                    
                  myQty := myQty - 1;                                                                                               
               end loop;                                                                                                            
                                                                                                                                    
               if myQty > 0 then                                                                                                    
                  mySect := 'Insert Detail (c2)';                                                                                   
                                                                                                                                    
                  insert into DEX_REPORT_LINES                                                                                      
                 (REPORT_LINE_ID,REPORT_ID,TYPE                                                                                     
                 ,DATA01,DATA02,DATA03,DATA04,DATA05,                                                                               
DATA06,DATA07,DATA08                                                                                                                
                 ,DATE01                                                                                                            
                 ,QTY04,QTY05,QTY06,QTY07                                                                                           
                 ) values (                                                                                                         
                  DEX_REPORT_LINES_S.nextval,myReportID,'D'                                                                         
                 ,c2r.PART,c2r.DESCR,'RMA (' || to_char(my                                                                          
Qty) || ')',myName,'RMA',null,myRMA,null                                                                                            
                 ,to_date(null)                                                                                                     
                 ,null,null,myQty,0                                                                                                 
                 );                                                                                                                 
               end if;                                                                                                              
            end loop;                                                                                                               
                                                                                                                                    
            commit;                                                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         mySect := 'c7 loop (c1)';                                                                                                  
                                                                                                                                    
         for c7r in c7 loop                                                                                                         
            myOrder   := c7r.ORDERNO;                                                                                               
            myPlantID := c7r.PLANT_ID;                                                                                              
                                                                                                                                    
            PLANT_NAME;                                                                                                             
                                                                                                                                    
            dbms_output.put_line ( 'Order: ' || myOrder   );                                                                        
                                                                                                                                    
            mySect := 'c5 loop (c7)';                                                                                               
                                                                                                                                    
            for c5r in c5 loop                                                                                                      
               mySect := 'Insert Detail (c5)';                                                                                      
                                                                                                                                    
               insert into DEX_REPORT_LINES                                                                                         
              (REPORT_LINE_ID,REPORT_ID,TYPE                                                                                        
              ,DATA01,DATA02,DATA03,DATA04,DATA05,DAT                                                                               
A06,DATA07,DATA08                                                                                                                   
              ,DATE01                                                                                                               
              ,QTY04,QTY05,QTY06,QTY07                                                                                              
              ) values (                                                                                                            
               DEX_REPORT_LINES_S.nextval,myReportID                                                                                
,'D'                                                                                                                                
              ,c5r.PART,c5r.DESCRIPTION,c5r.SERIAL,myName,c5r.LOCATION,c5                                                           
r.STORAGE,null,myOrder                                                                                                              
              ,c5r.DATELOC                                                                                                          
              ,null,c5r.SERIAL_ID,c5r.QTY,c5r.QTY                                                                                   
              );                                                                                                                    
            end loop;                                                                                                               
                                                                                                                                    
            commit;                                                                                                                 
         end loop;                                                                                                                  
      end loop;                                                                                                                     
   end loop;                                                                                                                        
                                                                                                                                    
   mySect := 'c6 loop';                                                                                                             
                                                                                                                                    
   for c6r in c6 loop                                                                                                               
      mySect := 'Insert Summary';                                                                                                   
                                                                                                                                    
      insert into DEX_REPORT_LINES                                                                                                  
     (REPORT_LINE_ID,REPORT_ID,TYPE                                                                                                 
     ,DATA01,DATA02,QTY01,QTY02,QTY03                                                                                               
     ) values (                                                                                                                     
      DEX_REPORT_LINES_S.nextval,myReportID,'S'                                                                                     
     ,c6r.ITEM_NUMBER,c6r.DESCRIPTION,c6r.QTYORG,c6r.QTY                                                                            
ORD - c6r.QTYSHP,c6r.QTYSHP                                                                                                         
     );                                                                                                                             
   end loop;                                                                                                                        
                                                                                                                                    
   commit;                                                                                                                          
                                                                                                                                    
exception                                                                                                                           
   when ABORT_PROC then                                                                                                             
      myRetCode := 1;                                                                                                               
                                                                                                                                    
   when OTHERS then                                                                                                                 
      myRetCode := 2;                                                                                                               
      myRetMesg := mySect || ' ' || SQLERRM;                                                                                        
end;                                                                                                                                
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

