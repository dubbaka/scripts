rem -------------------------------------------------------------
rem     Rollback Information
rem -------------------------------------------------------------

set pagesize 66
set line 132

TTitle left "*** Database:  "dbname", Rollback Information ( As of:  " xdate " ) ***" skip 2

select  substr(sys.dba_rollback_segs.SEGMENT_ID,1,5) "ID#",
        substr(sys.dba_segments.OWNER,1,8) "Owner",
        substr(sys.dba_segments.TABLESPACE_NAME,1,17) "Tablespace Name",
        substr(sys.dba_segments.SEGMENT_NAME,1,17) "Rollback Name",
        substr(sys.dba_rollback_segs.INITIAL_EXTENT,1,10) "INI_Extent",
        substr(sys.dba_rollback_segs.NEXT_EXTENT,1,10) "Next Exts",
        substr(sys.dba_segments.MIN_EXTENTS,1,5) "MinEx",
      substr(sys.dba_segments.MAX_EXTENTS,1,5) "MaxEx",
        substr(sys.dba_segments.PCT_INCREASE,1,5) "%Incr",
        substr(sys.dba_segments.BYTES,1,15) "Size (Bytes)",
        substr(sys.dba_segments.EXTENTS,1,6) "Extent#",
        substr(sys.dba_rollback_segs.STATUS,1,10) "Status"
from sys.dba_segments, sys.dba_rollback_segs
where sys.dba_segments.segment_name = sys.dba_rollback_segs.segment_name and
      sys.dba_segments.segment_type = 'ROLLBACK'
order by sys.dba_rollback_segs.segment_id;
