set linesize 120
SELECT  substr(sql_text,1,74)  sqltext, (sum(sharable_mem)/1024/1024) total_mem , count(*) cnt  
        FROM   v$sqlarea
        GROUP  BY  substr(sql_text,1,74) 
        HAVING COUNT(*) > &number_of_sqls
order by total_mem
/ 
