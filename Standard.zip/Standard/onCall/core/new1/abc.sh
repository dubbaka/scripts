cat /tmp/abc1.txt | while read line
do
name=`echo $line | awk ' { print $2 } '`
sqlplus / <<EOF
insert into objects_2_drop select * from dba_objects where object_name='$name' and owner='SYS';
commit;
exit;
EOF
done
