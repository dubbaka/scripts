set lines 200
set feed on
col machine format a20
col event format a30
col username format a20
col sql_text format a40
select a.sid,a.username,a.osuser,machine,b.event,c.sql_text 
 from v$session a, 
      v$session_wait b ,
      v$sql c
where a.sid=b.sid 
  and a.sql_hash_value=&sql_hash_value
  and a.sql_hash_value=c.sql_hash
order by 5
/

