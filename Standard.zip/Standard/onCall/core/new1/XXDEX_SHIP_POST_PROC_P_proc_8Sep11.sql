                                                                                                                                    
  CREATE OR REPLACE PROCEDURE "APPS"."XXDEX_SHIP_POST_PROC_P" (                                                                     
																		 myRetCode		out	number                                                                                            
										 								,myRetMesg		out	varchar2                                                                                         
										 								,myShipId		in  	number                                                                                           
										 								) is                                                                                                             
                                                                                                                                    
                                                                                                                                    
/* $Header: XXDEX_SHIP_POST_PROC_P.sql 2.1.0.0 2010/05/11 12:00:00 d                                                                
exsys ship $ Copyright (c) 2010 DEX Systems, Inc. */                                                                                
                                                                                                                                    
                                                                                                                                    
 	myIBUpdate	varchar2(1) := XXDEX_DEFAULTS_F('INSTALLBASE_UPDATE');                                                                 
 	myRepPlant	varchar2(1);                                                                                                           
                                                                                                                                    
 	myUserId		number := F_DEX_USER_ID;                                                                                                
	mySect		varchar2(2000);                                                                                                            
                                                                                                                                    
                                                                                                                                    
begin                                                                                                                               
	myRetCode := 0;                                                                                                                    
                                                                                                                                    
	if myIBUpdate = 'Y' then                                                                                                           
		begin                                                                                                                             
			select decode(PLANT_ID,REPAIR_PLANT_ID,'Y','N')                                                                                  
			into   myRepPlant                                                                                                                
			from   XXDEX_CISCO_SERIALS_V                                                                                                     
			where  SHIP_ID = myShipID                                                                                                        
			and    rownum < 2;                                                                                                               
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRepPlant := 'N';                                                                                                              
		end;                                                                                                                              
		if myRepPlant = 'Y' then                                                                                                          
			K_DEX_INTERFACE.LOAD (                                                                                                           
   	                           myRetMesg => myRetMesg                                                                               
      	                       ,myRetCode => myRetCode                                                                               
         	                    ,myTypeID  => 504                                                                                     
            	                 ,mySrcID   => myShipID                                                                                
               	              ,mySubmit  => 'N'                                                                                     
                  	          );                                                                                                     
		end if;                                                                                                                           
	end if;                                                                                                                            
                                                                                                                                    
	XXDEX_CISCO_K.ENABLEMENT_API ( myRetCode 	=> myRetCo                                                                               
de                                                                                                                                  
		  								   ,myRetMesg  => myRetMesg                                                                                             
		  								   ,myEMMType	=> 'SHP'                                                                                                  
		  								   ,myRecordId	=> myShipID                                                                                              
											);                                                                                                                       
                                                                                                                                    
exception                                                                                                                           
	when OTHERS then                                                                                                                   
		myRetCode := 2;                                                                                                                   
		myRetMesg := mySect || ' - ' || SQLERRM;                                                                                          
end;                                                                                                                                
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

