SELECT a.sid, a.serial#,  b.event
FROM   v$session a, v$session_wait b
WHERE  username IS NOT NULL
AND    status = 'ACTIVE'
AND    a.sid  = b.sid
and  b.event like 'Streams AQ:%'
/
