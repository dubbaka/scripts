set linesize 132
set pagsize 100
column table_name format a40
select a.owner, table_name,  CHAIN_CNT , bytes/1024/1024 "Size MB"
from dba_tables a, dba_segments b
where CHAIN_CNT >1
and a.table_name = b.segment_name
and b.segment_type ='TABLE'
/
