set pages 100
set lines 132
col osuser for a15
col username for a25
col machine for a20
col program for a20
col sid format 999999
col logon_time for a20
col space_in_mb for 9999999
col memory_utilized for 999999
accept size char prompt 'Enter Usage in MB per session : '
spool sessions_using_temp_space
select s.username, trim(s.osuser) osuser,s.machine,s.program,s.sid, to_char(s.logon_time,'MM/DD/YYYY HH24:MI:SS') logon_time, 
       u.blocks*8/1024 space_in_MB
  from v$session s, v$process p, v$sqlarea a, v$sort_usage u, v$sess_io si
 where s.type!='BACKGROUND'
   and s.username is not null
   and s.paddr=p.addr (+)
   and s.sql_hash_value=a.hash_value (+)
   and s.saddr    = u.session_addr (+)
   and s.sid = si.sid (+)
   and s.username not in ('SYS','SYSTEM')
   and (u.blocks*8)/1024 > decode('&size',null,0,'&&size')
 order by space_in_mb
;
spool off
