accept sesncnt char prompt 'Enter Max Session count limit :'
accept parlsesncnt char prompt 'Enter Parallel Max Session count limit :'
set lines 132
set verify off
set feedback off
column osuser format a20
column username format a20
column machine format a30
column program format a30
spool get_active_session_count
select sn.osuser, sn.username, sn.machine, count(*) session_count --,sn.program
--sn.sid,  p.spid, pxs.qcsid
                    from v$process p , v$session sn, v$px_session pxs
                   where 
--sn.status = 'ACTIVE' and
                     sn.type != 'BACKGROUND'
                     and sn.paddr = p.addr (+)
                     and sn.sid = pxs.sid (+)
                     and (sn.osuser, sn.username, nvl(pxs.qcsid,0)) in
                        (
                        select s.osuser, s.username, nvl(ps.qcsid,0)
                          from v$session s , v$px_session ps, v$process p
                         where s.status = 'ACTIVE'
                           and s.type != 'BACKGROUND'
                           and s.sid = ps.sid(+)
                           and s.paddr = p.addr(+)
                         group by s.osuser, s.username, ps.qcsid
                        having decode(qcsid,null,count(*),count(*) - &&parlsesncnt + &&SesnCnt ) > &&SesnCnt
                        )
 group by sn.osuser, sn.username, sn.machine--, sn.program
                        order by 1,2;
spool off
set verify on
set feedback on
