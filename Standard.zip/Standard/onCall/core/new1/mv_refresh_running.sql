set lines 132
prompt 
prompt 
prompt 'This script is only valid in 9i onwards.............'
prompt
prompt
connect / as sysdba
ttitle center 'MV Refresh Status Running Now' skip 1 center '********************************' skip 2
column "VIEW BEING REFRESHED" format a30    
column INSERTS format 9999999    
column UPDATES format 9999999    
column DELETES format 9999999    
select sid_knst sid, CURRMVOWNER_KNSTMVR || '.' || CURRMVNAME_KNSTMVR   "MVIEW BEING REFRESHED",  
       decode( REFTYPE_KNSTMVR, 1, 'FAST', 2, 'COMPLETE', 'UNKNOWN' ) REFTYPE, 
       decode(GROUPSTATE_KNSTMVR, 1, 'SETUP', 2, 'INSTANTIATE', 3, 'WRAPUP', 'UNKNOWN' ) STATE, 
       TOTAL_INSERTS_KNSTMVR INSERTS, TOTAL_UPDATES_KNSTMVR UPDATES, TOTAL_DELETES_KNSTMVR DELETES    
  from X$KNSTMVR X    
 WHERE type_knst=6 
   and exists (select 1 
                 from v$session s   
                where s.sid=x.sid_knst 
                  and s.serial#=x.serial_knst); 

