set lines 132
set pages 1000
COLUMN owner            format a15 heading 'Owner'
COLUMN table_owner            format a15 heading 'Table_Owner'
COLUMN table_name       format a30 heading 'Table'
COLUMN tablespace_name  format a12 heading 'Tablespace'
COLUMN table_type_owner format a15 heading 'Type|Owner'
COLUMN table_type       format a15 heading 'Type'
COLUMN iot_name         format a10 heading 'IOT|Overflow'
COLUMN iot_type         format a12 heading 'IOT or|Overflow'
COLUMN nested           format a6  heading 'Nested'
SET lines 130 verify off feedback off pages 58
ttitle center 'Table Details Info'
accept owner char prompt 'Enter Owner :'
accept table_name char prompt 'Enter Table Name :'

spool table_details
SELECT owner, table_name, tablespace_name, ini_trans, degree, cache, iot_type,logging, partitioned, temporary, nested, chain_cnt
  FROM dba_tables
 WHERE owner =  UPPER(decode('&&owner',null, owner, '&&owner'))
   AND table_name = upper(decode('&&table_name', null, table_name,'&&table_name'))
;
select owner, table_name, partitioned, last_analyzed, sample_size, num_rows, avg_row_len, round((sample_size/num_rows)*100,2) analye_percent
  from dba_tables
 WHERE owner =  UPPER(decode('&&owner',null, owner, '&&owner'))
 and table_name = upper(decode('&&table_name', null, table_name,'&&table_name'));

ttitle center 'Synonym Info'
select owner, synonym_name, table_owner, table_name
  from dba_synonyms 
 where table_name='&&table_name';

set pages 1000
set lines 140
col tablespace_name for a15
col subpartition_count heading subpart|count for 99999999
ttitle center 'Table Partition Info'
select table_owner, table_name, composite, partition_name, tablespace_name, subpartition_count, ini_trans, logging, chain_cnt
--       , last_analyzed, num_rows, sample_size, round((sample_size/num_rows)*100,2) analye_percent
  from dba_tab_partitions
 WHERE table_owner =  UPPER(decode('&&owner',null, table_owner, '&&owner'))
 and table_name = '&&table_name';

select owner, table_name, partitioning_type , subpartitioning_type, partition_count
  from dba_part_tables
 WHERE owner =  UPPER(decode('&&owner',null, owner, '&&owner'))
 and table_name='&&table_name';

ttitle center 'Table Partition Column Info'
column column_name format a30
select * 
  from dba_part_key_columns
 where name = '&&table_name';

ttitle center 'Table Sub-partition Column Info'
select * 
  from dba_subpart_key_columns
 where name = '&&table_name';

select table_owner, table_name, partition_name, subpartition_name, logging
  from dba_tab_subpartitions
 WHERE table_owner =  UPPER(decode('&&owner',null, table_owner, '&&owner'))
 and table_name='&&table_name';
spool off
