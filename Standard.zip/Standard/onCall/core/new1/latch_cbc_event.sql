col event for a27
col osuser for a10
col username for a15
select inst_id,sid,username,module,sql_hash_value,event from gv$session where event like '%library cache%';
