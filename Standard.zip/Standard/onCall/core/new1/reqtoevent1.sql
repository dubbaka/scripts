set pagesize 54 linesize 180 echo off feedback 1 wrap on
column reqid format 9999999999 heading "Request Id"
column sesid format a10 heading "Session"
column ospid format a10 heading "OS Pid"
col username for a5
col event for a30
col module for a30
select
   a.request_id reqid,
   d.sid||','||d.serial# sesid,
   c.spid ospid,
   d.event,
   d.module,
   d.username,
   d.last_call_et/60,
--   to_char(d.logon_time,'DD-MON-YYYY HH24:MI:SS'),
    r.name
from
   applsys.fnd_concurrent_requests a,
   applsys.fnd_concurrent_processes b,
   v$process c, v$session d,v$transaction t,v$rollname r
where
   a.controlling_manager=b.concurrent_process_id
   and c.spid=a.oracle_process_id
   and c.addr=d.paddr
   and d.username = 'APPS'
   and t.addr = d.taddr
   and r.usn = t.xidusn
   and d.event like 'latch: undo global data%'
   and a.phase_code='R' order by 5;
