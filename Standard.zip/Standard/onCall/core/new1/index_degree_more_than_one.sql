set pages 100
set lines 132
column owner format a20
column index_name format a30
column partitioned format a12
column degree format a10
column instances format a10
ttitle center 'List of Indexes with degree > 1 or DEFAULT' skip 1 center '*****************************************' skip 2
break on owner on table_name skip 1 on owner
spool  index_degree_more_than_one
accept owner char prompt 'Enter Schema Owner : '
select owner, table_name, index_name, partitioned, degree, instances
  from dba_indexes
 where trim(degree) not in ('0', '1')
   and owner not in ('SYS','SYSTEM','OUTLN','DBSNMP')
   and owner = decode('&&owner',null, owner, '&&owner')
   and table_name not in (select mview_name from dba_mviews)
 order by owner, table_name
;
spool off
