select
  p.pid,
  s.sid,
  s.serial#,
  p.spid
  from
  sys.v_$session  s,
  sys.v_$process  p
  where
  s.sid = (select sid from sys.v_$mystat where rownum = 1) and
  p.addr = s.paddr
/
