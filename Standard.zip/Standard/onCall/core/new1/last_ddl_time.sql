set pagesize 100
col object_name format a30
column owner format a10
select owner, object_name, object_type, to_char(last_ddl_time, 'DD-MON-RR HH24:MI:SS')
from dba_objects
where    trunc(last_ddl_time) = trunc(sysdate-1)
