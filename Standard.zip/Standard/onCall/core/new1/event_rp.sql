select a.sid,a.serial#,b.spid,a.username,a.status,a.sql_hash_value,a.last_call_et/60
from v$session a,v$process b,v$session_wait c
where a.paddr=b.addr
and a.sid=c.sid
and c.event like '&event' 
order by 6;
