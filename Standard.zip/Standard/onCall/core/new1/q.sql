prompt to get session details
ttitle off
set linesize 132
col pid format 9999 heading 'PID'
col spid format a6 heading 'SERVER|PID'
col sid format 9999 heading 'SID'
col serial# format 99999 heading 'SERIAL'
col process format a6 heading 'CLIENT|PID'
col osuser format a8 heading 'OS|USERNAME'
col username format a12 heading 'ORACLE|USERNAME'
col logical format b99999999999 heading 'LOGICAL|READS'
col physical_reads format b99999999 heading 'PHYSICAL|READS'
col audsid format b99999999 heading 'AUDIT|SESSION'
col program format a15 heading 'PROGRAM NAME'
col logon_time format a8 heading 'LOGON|TIME'
col module format a15 heading 'MODULE'
col client_info format a6 heading 'CLIENT|INFO'
rem
select s.inst_id, s.process,
       p.spid,
       p.pid,
       s.sid,
       s.serial#,
       s.osuser,
       s.username,
       i.block_gets + i.consistent_gets logical,
       i.physical_reads,
       s.audsid, s.status, s.action,
       to_char( s.logon_time, 'hh24:mi:ss' ) logon_time,
       substr(s.program,1,15),
       substr(s.module,1,15),substr(s.client_info,1,6) client_info,sql_hash_value,last_call_et/60 last_call_min
  from gv$process p, gv$session s, gv$sess_io i
 where i.sid = s.sid
   and s.paddr = p.addr
   and s.sid = '&&sid'
and p.inst_id = s.inst_id and s.inst_id = i.inst_id
 order by block_gets + consistent_gets desc;
rem

