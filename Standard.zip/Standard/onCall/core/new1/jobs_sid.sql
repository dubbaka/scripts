SELECT sid, type, id1, id2
   FROM v$lock
   WHERE type = 'JQ';

