                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."K_DEX_PRODUCT_STATUS" AUTHID CURRENT_USER                                                       
 as                                                                                                                                 
/* $Header: K_DEX_PRODUCT_STATUS.sql 2.0.0.0 2009/05/01 12:00:00 dexsys sh                                                          
ip $ Copyright (c) 2008 DEX Systems, Inc. */                                                                                        
                                                                                                                                    
   procedure  LOG_SET;                                                                                                              
   procedure  LOG_UNSET;                                                                                                            
                                                                                                                                    
   procedure  RUN_UNSET;                                                                                                            
                                                                                                                                    
   procedure  REPORT ( myRetMesg out varchar2,myPReportID  nu                                                                       
mber );                                                                                                                             
end K_DEX_PRODUCT_STATUS;                                                                                                           
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."K_DEX_PRODUCT_STATUS" as                                                                     
/* $Header: K_DEX_PRODUCT_STATUS.sql 2.0.0.0 2009/05/01 1                                                                           
2:00:00 dexsys ship $ Copyright (c) 2008 DEX Systems                                                                                
, Inc. */                                                                                                                           
                                                                                                                                    
   mySect       varchar2(100);                                                                                                      
                                                                                                                                    
   myLog        varchar2(1)    := 'N';                                                                                              
   myLogNum     binary_integer := 0;                                                                                                
   myRunSQL     boolean        := true;                                                                                             
   myROAR_Chk    varchar2(1);                                                                                                       
   myReportID   pls_integer;                                                                                                        
                                                                                                                                    
   mySQL        varchar2(9000);                                                                                                     
                                                                                                                                    
   /********************************************************                                                                        
******************************/                                                                                                     
                                                                                                                                    
   procedure LOG is                                                                                                                 
   begin                                                                                                                            
      if myLog = 'Y' then                                                                                                           
         myLogNum := myLogNum + 1;                                                                                                  
                                                                                                                                    
         insert into DEX_LOG                                                                                                        
        (PROGRAM,LOG_DATE,SECTION,LOG_NUM)                                                                                          
         values                                                                                                                     
        ('PRODSTAT',SYSDATE,mySect,myLogNum);                                                                                       
                                                                                                                                    
        commit;                                                                                                                     
      end if;                                                                                                                       
   end LOG;                                                                                                                         
                                                                                                                                    
   /**********************************************************                                                                      
****************************/                                                                                                       
                                                                                                                                    
   procedure LOG_SET is                                                                                                             
   begin                                                                                                                            
      myLog := 'Y';                                                                                                                 
   end LOG_SET;                                                                                                                     
                                                                                                                                    
   /***************************************************                                                                             
***********************************/                                                                                                
                                                                                                                                    
   procedure LOG_UNSET is                                                                                                           
   begin                                                                                                                            
      myLog := 'N';                                                                                                                 
   end LOG_UNSET;                                                                                                                   
                                                                                                                                    
   /******************************************************************                                                              
********************/                                                                                                               
                                                                                                                                    
   procedure RUN_UNSET is                                                                                                           
   begin                                                                                                                            
      myRunSQL := FALSE;                                                                                                            
   end RUN_UNSET;                                                                                                                   
                                                                                                                                    
   /**************************************************                                                                              
************************************/                                                                                               
                                                                                                                                    
   function GET_LIST (myType     varchar2                                                                                           
                     ,myUserid  number                                                                                              
                     ,myData    varchar2                                                                                            
                     ) return varchar2 is                                                                                           
      cursor list_cur is                                                                                                            
         select VALUE                                                                                                               
           from DEX_SELECTIONS                                                                                                      
          where USER_ID = myUserid                                                                                                  
            and DATA = myData;                                                                                                      
                                                                                                                                    
      cursor date_cur (test_date varchar2) is                                                                                       
         select to_date(test_date,'MM/DD/RR') new_date                                                                              
           from dual;                                                                                                               
                                                                                                                                    
      is_good     boolean;                                                                                                          
      conv_date   date;                                                                                                             
      rtn_list    varchar2(1000) := null;                                                                                           
      rtn_cnt     number := 0;                                                                                                      
      sep         varchar2(1) := null;                                                                                              
                                                                                                                                    
   begin                                                                                                                            
      for r1 in list_cur loop                                                                                                       
         is_good := true;                                                                                                           
                                                                                                                                    
         if myType = 'D' then                                                                                                       
            begin                                                                                                                   
               open date_cur (r1.VALUE);                                                                                            
               fetch date_cur into conv_date;                                                                                       
               close date_cur;                                                                                                      
            exception                                                                                                               
               when OTHERS then                                                                                                     
                  is_good := false;                                                                                                 
            end;                                                                                                                    
                                                                                                                                    
            if is_good then                                                                                                         
               rtn_list := rtn_list || sep || 'TO_DATE(''' ||                                                                       
r1.VALUE || ''',''mm/dd/RR'')';                                                                                                     
            end if;                                                                                                                 
         else                                                                                                                       
            rtn_list := rtn_list || sep || '''' || r1.VALUE || '                                                                    
''';                                                                                                                                
         end if;                                                                                                                    
                                                                                                                                    
         if is_good then                                                                                                            
            rtn_cnt := rtn_cnt + 1;                                                                                                 
            sep := ',';                                                                                                             
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      if rtn_cnt = 0 then                                                                                                           
         rtn_list := 'null';    -- return null for list so wont ab                                                                  
ort on empty list                                                                                                                   
      end if;                                                                                                                       
      return ('(' || rtn_list || ')');                                                                                              
   end GET_LIST;                                                                                                                    
                                                                                                                                    
   /***************************************************************                                                                 
***********************/                                                                                                            
                                                                                                                                    
   procedure SET_SORT (fld_sort  IN varchar2                                                                                        
                      ,sort_ord  IN varchar2                                                                                        
                      ,sql_order IN OUT varchar2                                                                                    
                     ) is                                                                                                           
      crnt_sql_ord varchar2(300) := null;                                                                                           
      sql_fld varchar2(50) := null;                                                                                                 
      delim  varchar2(2);                                                                                                           
   begin                                                                                                                            
      crnt_sql_ord := sql_order;                                                                                                    
                                                                                                                                    
      if fld_sort = 'Code' then                                                                                                     
         sql_fld :=  'S.CODE';                                                                                                      
      elsif fld_sort = 'Comment' then                                                                                               
         sql_fld := 'S.REASON';                                                                                                     
        elsif fld_sort = 'Comment_ORD' then                                                                                         
         sql_fld := 'H.COMMENTS';                                                                                                   
      elsif fld_sort = 'Comment_LNE' then                                                                                           
         sql_fld := 'D.COMMENTS';                                                                                                   
      elsif fld_sort = 'Cust' then                                                                                                  
         sql_fld := 'H.CUST';                                                                                                       
      elsif fld_sort = 'Cust Exchange' then                                                                                         
         sql_fld := 'H.CUST_EXCHANGE';                                                                                              
      elsif fld_sort = 'Cust PO' then                                                                                               
         sql_fld := 'H.CUSTPO';                                                                                                     
      elsif fld_sort = 'Cust Part' then                                                                                             
         sql_fld := 'D.CUSTPART';                                                                                                   
      elsif fld_sort = 'DateLoc' then                                                                                               
         sql_fld := 'S.DATELOC';                                                                                                    
      elsif fld_sort = 'DateRcv' then                                                                                               
         sql_fld := 'H.DATERCV';                                                                                                    
      elsif fld_sort = 'DateSch' then                                                                                               
         sql_fld := 'D.DATESCH';                                                                                                    
      elsif fld_sort = 'DateTrn' then                                                                                               
         sql_fld := 'H.DATETRN';                                                                                                    
      elsif fld_sort = 'Group' then                                                                                                 
         sql_fld := 'D.GRP';                                                                                                        
      elsif fld_sort = 'Location' then                                                                                              
         sql_fld := 'S.LOCATION';                                                                                                   
      elsif fld_sort = 'OEM' then                                                                                                   
         sql_fld := 'D.MFG';                                                                                                        
      elsif fld_sort = 'Order' then                                                                                                 
         sql_fld := 'S.ORDERNO';                                                                                                    
      elsif fld_sort = 'OrdType' then                                                                                               
         sql_fld := 'H.ORDTYPE';                                                                                                    
      elsif fld_sort = 'Part' then                                                                                                  
         sql_fld := 'F_DEX_ITEM_NUMBER ( D.INVENTORY_ITEM_ID                                                                        
)';                                                                                                                                 
      elsif fld_sort = 'PONum' then                                                                                                 
         sql_fld := 'S.PO_NO';                                                                                                      
      elsif fld_sort = 'Shortage' then                                                                                              
         sql_fld := 'S.SHORTAGE';                                                                                                   
      elsif fld_sort = 'Sort' then                                                                                                  
         sql_fld := 'S.SORT';                                                                                                       
      elsif fld_sort = 'Stat Code' then                                                                                             
         sql_fld := 'D.STATCODE';                                                                                                   
      elsif fld_sort = 'Status' then                                                                                                
         sql_fld := 'S.STATUS';                                                                                                     
      elsif fld_sort = 'Step' then                                                                                                  
         sql_fld := 'F_STEP ( S.LOCATION )';                                                                                        
      elsif fld_sort = 'Storage' then                                                                                               
         sql_fld := 'S.STORAGE';                                                                                                    
      elsif fld_sort = 'Scrap' then                                                                                                 
         sql_fld := 'S.SCRAP';                                                                                                      
      elsif fld_sort = 'Release' then                                                                                               
         sql_fld := 'H.RELEASE';                                                                                                    
      elsif fld_sort = 'Expedite' then                                                                                              
         sql_fld := 'S.SWAP';                                                                                                       
      elsif fld_sort = 'Serial' then                                                                                                
         sql_fld := 'S.SERIAL';                                                                                                     
      elsif fld_sort = 'Store' then                                                                                                 
         sql_fld := 'D.STORE';                                                                                                      
      elsif fld_sort = 'Tag Number' then                                                                                            
         sql_fld := 'S.TAG_NUMBER';                                                                                                 
      elsif fld_sort = 'Warranty Claim Number' then                                                                                 
         sql_fld := 'F_DEX_WARRANTY_CLAIM_NUM ( S.SERIAL_ID )';                                                                     
      elsif fld_sort = 'Return Waybill' then                                                                                        
         sql_fld := 'S.RETURN_WAYBILL';                                                                                             
      elsif fld_sort = 'MPS Date' then                                                                                              
         sql_fld := 'M.SCHEDULE_DATE';                                                                                              
      elsif fld_sort = 'Track' then                                                                                                 
         sql_fld := 'S.TRACK';                                                                                                      
      elsif fld_sort = 'Warranty Flag' then                                                                                         
         sql_fld := 'S.WARRANTY';                                                                                                   
      elsif fld_sort = 'Invoice' then                                                                                               
         sql_fld := 'R.INVOICE';                                                                                                    
      elsif fld_sort = 'RECEIVE_TRACK' then                                                                                         
         sql_fld := 'S.RECEIVE_DATE';                                                                                               
      else                                                                                                                          
         sql_fld := null;                                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      if sql_fld is not null then                                                                                                   
         if crnt_sql_ord is null then                                                                                               
            crnt_sql_ord := sql_fld || ' ' || sort_ord;                                                                             
         else                                                                                                                       
            crnt_sql_ord := crnt_sql_ord || ', ' || sql_fld || ' ' || sort                                                          
_ord;                                                                                                                               
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      sql_order := crnt_sql_ord;                                                                                                    
   end SET_SORT;                                                                                                                    
                                                                                                                                    
   /***************************************************************                                                                 
***********************/                                                                                                            
                                                                                                                                    
   function BUILD_SQL ( myOSPFlag out varchar2 ) ret                                                                                
urn varchar2 is                                                                                                                     
      mySQL         varchar2(9000) := null;                                                                                         
                                                                                                                                    
      bCust     boolean := false;                                                                                                   
      bDate     boolean := false;                                                                                                   
      bLocn     boolean := false;                                                                                                   
      bLocnSet  boolean := false;                                                                                                   
      bShip     boolean := false;                                                                                                   
      bPart     boolean := false;                                                                                                   
      bCPart    boolean := false;                                                                                                   
      bTran     boolean := false;                                                                                                   
      bCFlag    boolean := false;                                                                                                   
      bStatus   boolean := false;                                                                                                   
      bDEXM     boolean := false;                                                                                                   
                                                                                                                                    
      tCust     varchar2(30) := null;                                                                                               
      tCustLst  varchar2(30) := null;                                                                                               
      tDate     varchar2(30) := null;                                                                                               
      tDateHold varchar2(30) := null;                                                                                               
      tDateLst  varchar2(30) := null;                                                                                               
      tPart     varchar2(100) := null;                                                                                              
      tPartLst  varchar2(30) := null;                                                                                               
      tCPart    varchar2(30) := null;                                                                                               
      tCPartLst varchar2(30) := null;                                                                                               
                                                                                                                                    
      pbTmp     varchar2(1);                                                                                                        
      ppTmp     varchar2(30);                                                                                                       
      pcTmp     varchar2(30);                                                                                                       
      pgTmp     varchar2(100);                                                                                                      
      bSelect   varchar2(1);                                                                                                        
      pSelect   varchar2(30);                                                                                                       
      pComp     varchar2(30);                                                                                                       
      gSelect   varchar2(100);                                                                                                      
      sData     varchar2(100) := null;                                                                                              
      gField    varchar2(160) := null;                                                                                              
      myGeneralizedDate varchar2(11);                                                                                               
                                                                                                                                    
      sort_cnt  number := 0;                                                                                                        
                                                                                                                                    
      bSort     boolean := false;                                                                                                   
      tSort     varchar2(1);                                                                                                        
      pSort     varchar2(30) := null;                                                                                               
      pSortType varchar2(5) := null;                                                                                                
                                                                                                                                    
     --- DEX Report Select into Vars                                                                                                
      myCheck1  varchar2(1);                                                                                                        
      myCheck2  varchar2(1);                                                                                                        
      myCheck3  varchar2(1);                                                                                                        
      myCheck4  varchar2(1);                                                                                                        
      myCheck5  varchar2(1);                                                                                                        
      myCheck6  varchar2(1);                                                                                                        
                                                                                                                                    
      myField1  varchar2(20);                                                                                                       
      myField2  varchar2(20);                                                                                                       
      myField3  varchar2(20);                                                                                                       
      myField4  varchar2(20);                                                                                                       
      myField5  varchar2(20);                                                                                                       
      myField6  varchar2(20);                                                                                                       
                                                                                                                                    
      myComp1   varchar2(12);                                                                                                       
      myComp2   varchar2(12);                                                                                                       
      myComp3   varchar2(12);                                                                                                       
      myComp4   varchar2(12);                                                                                                       
      myComp5   varchar2(12);                                                                                                       
      myComp6   varchar2(12);                                                                                                       
                                                                                                                                    
      myValue1  varchar2(100);                                                                                                      
      myValue2  varchar2(100);                                                                                                      
      myValue3  varchar2(100);                                                                                                      
      myValue4  varchar2(100);                                                                                                      
      myValue5  varchar2(100);                                                                                                      
      myValue6  varchar2(100);                                                                                                      
                                                                                                                                    
      mySort1     varchar2(20);                                                                                                     
      mySort2     varchar2(20);                                                                                                     
      mySort3     varchar2(20);                                                                                                     
      myOrder1    varchar2(20);                                                                                                     
      myOrder2    varchar2(20);                                                                                                     
      myOrder3    varchar2(20);                                                                                                     
      myOpType    varchar2(20);                                                                                                     
      myFail_Chk  varchar2(20);                                                                                                     
      myComp_Chk  varchar2(20);                                                                                                     
      myDisp_Chk  varchar2(20);                                                                                                     
      myShtgCode  varchar2(10);                                                                                                     
      myPlant		DEX_PLANTS.PLANT%type;                                                                                               
                                                                                                                                    
      mySQLOrder  varchar2(300) := NULL;                                                                                            
                                                                                                                                    
      myUserID    number := F_DEX_USER_ID;                                                                                          
                                                                                                                                    
      myItemID    pls_integer;                                                                                                      
                                                                                                                                    
   begin                                                                                                                            
      mySect := 'Build - Init';                                                                                                     
                                                                                                                                    
      select decode(ATTRIBUTE1,null,'N','Y') CHECK1                                                                                 
            ,decode(ATTRIBUTE2,null,'N','Y') CHECK2                                                                                 
            ,decode(ATTRIBUTE3,null,'N','Y') CHECK3                                                                                 
            ,decode(ATTRIBUTE4,null,'N','Y') CHECK4                                                                                 
            ,decode(ATTRIBUTE5,null,'N','Y') CHECK5                                                                                 
            ,decode(ATTRIBUTE6,null,'N','Y') CHECK6                                                                                 
            ,ATTRIBUTE1                                                                                                             
            ,ATTRIBUTE2                                                                                                             
            ,ATTRIBUTE3                                                                                                             
            ,ATTRIBUTE4                                                                                                             
            ,ATTRIBUTE5                                                                                                             
            ,ATTRIBUTE6                                                                                                             
            ,COMP1                                                                                                                  
            ,COMP2                                                                                                                  
            ,COMP3                                                                                                                  
            ,COMP4                                                                                                                  
            ,COMP5                                                                                                                  
            ,COMP6                                                                                                                  
            ,DATA1                                                                                                                  
            ,DATA2                                                                                                                  
            ,DATA3                                                                                                                  
            ,DATA4                                                                                                                  
            ,DATA5                                                                                                                  
            ,DATA6                                                                                                                  
            ,ATTRIBUTE9                                                                                                             
            ,ATTRIBUTE10                                                                                                            
            ,ATTRIBUTE11                                                                                                            
            ,ATTRIBUTE12                                                                                                            
            ,TYPE                                                                                                                   
            ,ATTRIBUTE14                                                                                                            
            ,ATTRIBUTE13                                                                                                            
            ,ATTRIBUTE8                                                                                                             
            ,ATTRIBUTE15                                                                                                            
            ,CREATED_BY                                                                                                             
            ,ATTRIBUTE16                                                                                                            
            ,decode(NUMBER1, 1, 'Y','N')                                                                                            
            ,decode(NUMBER2, 1, 'Y','N')                                                                                            
            ,PLANT                                                                                                                  
      into   myCheck1                                                                                                               
            ,myCheck2                                                                                                               
            ,myCheck3                                                                                                               
            ,myCheck4                                                                                                               
            ,myCheck5                                                                                                               
            ,myCheck6                                                                                                               
            ,myField1                                                                                                               
            ,myField2                                                                                                               
            ,myField3                                                                                                               
            ,myField4                                                                                                               
            ,myField5                                                                                                               
            ,myField6                                                                                                               
            ,myComp1                                                                                                                
            ,myComp2                                                                                                                
            ,myComp3                                                                                                                
            ,myComp4                                                                                                                
            ,myComp5                                                                                                                
            ,myComp6                                                                                                                
            ,myValue1                                                                                                               
            ,myValue2                                                                                                               
            ,myValue3                                                                                                               
            ,myValue4                                                                                                               
            ,myValue5                                                                                                               
            ,myValue6                                                                                                               
            ,mySort1                                                                                                                
            ,mySort2                                                                                                                
            ,mySort3                                                                                                                
            ,myOpType                                                                                                               
            ,myFail_Chk                                                                                                             
            ,myComp_Chk                                                                                                             
            ,myOrder1                                                                                                               
            ,myOrder2                                                                                                               
            ,myOrder3                                                                                                               
            ,myUserID                                                                                                               
            ,myShtgCode                                                                                                             
            ,myROAR_Chk                                                                                                             
            ,myOSPFlag                                                                                                              
            ,myPlant                                                                                                                
      from   DEX_REPORT                                                                                                             
      where  REPORT_ID = myReportID;                                                                                                
                                                                                                                                    
      mySect := 'Build - loop';                                                                                                     
                                                                                                                                    
      ---  Set flags for selection criteria entered by u                                                                            
ser  (liBuild)                                                                                                                      
      ---  Moved code up here so appropriate flags are set when                                                                     
 needed                                                                                                                             
                                                                                                                                    
      for x in 1 .. 6 loop                                                                                                          
         if x = 1 then                                                                                                              
            pbTmp := myCHECK1;                                                                                                      
            ppTmp := myFIELD1;                                                                                                      
            pcTmp := myCOMP1;                                                                                                       
            pgTmp := myVALUE1;                                                                                                      
         elsif x = 2 then                                                                                                           
            pbTmp := myCHECK2;                                                                                                      
            ppTmp := myFIELD2;                                                                                                      
            pcTmp := myCOMP2;                                                                                                       
            pgTmp := myVALUE2;                                                                                                      
         elsif x = 3 then                                                                                                           
            pbTmp := myCHECK3;                                                                                                      
            ppTmp := myFIELD3;                                                                                                      
            pcTmp := myCOMP3;                                                                                                       
            pgTmp := myVALUE3;                                                                                                      
         elsif x = 4 then                                                                                                           
            pbTmp := myCHECK4;                                                                                                      
            ppTmp := myFIELD4;                                                                                                      
            pcTmp := myCOMP4;                                                                                                       
            pgTmp := myVALUE4;                                                                                                      
         elsif x = 5 then                                                                                                           
            pbTmp := myCHECK5;                                                                                                      
            ppTmp := myFIELD5;                                                                                                      
            pcTmp := myCOMP5;                                                                                                       
            pgTmp := myVALUE5;                                                                                                      
         else                                                                                                                       
            pbTmp := myCHECK6;                                                                                                      
            ppTmp := myFIELD6;                                                                                                      
            pcTmp := myCOMP6;                                                                                                       
            pgTmp := myVALUE6;                                                                                                      
         end if;                                                                                                                    
                                                                                                                                    
         dbms_output.put_line ( x || ' ' || pbTmp || '                                                                              
' || ppTmp || ' ' || pgTmp );                                                                                                       
                                                                                                                                    
         If (pbTmp = 'Y') AND (ppTmp = 'Cust') AND (pgTmp IS NOT NULL) th                                                           
en                                                                                                                                  
            if pgTmp = 'DEXM' then                                                                                                  
               dbms_output.put_line ( 'DEXM' );                                                                                     
                                                                                                                                    
               bDEXM := TRUE;                                                                                                       
            else                                                                                                                    
               tCust    := pgTmp;                                                                                                   
               tCustLst := pcTmp;                                                                                                   
               bCust    := True;                                                                                                    
            end if;                                                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         If (pbTmp = 'Y') AND (ppTmp = 'OrdClosedFlag') AND (pgTm                                                                   
p = 'O') then                                                                                                                       
            bCFlag   := True;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         If (pbTmp = 'Y') AND (ppTmp = 'DateLoc') AND (pgTmp IS NOT                                                                 
NULL) then                                                                                                                          
            tDateHold := TO_CHAR(f_dex_general_date(pgTmp),'DD-MON-                                                                 
RRRR');                                                                                                                             
            if tDateHold is not null then                                                                                           
               tDate    := tDateHold;                                                                                               
            else                                                                                                                    
               tDate    := pgTmp;                                                                                                   
            end if;                                                                                                                 
            tDateLst := pcTmp;                                                                                                      
            bDate    := True;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         If (pbTmp = 'Y') AND (ppTmp = 'DateRcv') AND (pgTmp IS NOT NULL)                                                           
then                                                                                                                                
            tDateHold := TO_CHAR(f_dex_general_date(pgTmp),'DD-MON-RRRR')                                                           
;                                                                                                                                   
            if tDateHold is not null then                                                                                           
               tDate    := tDateHold;                                                                                               
            else                                                                                                                    
               tDate    := pgTmp;                                                                                                   
            end if;                                                                                                                 
            tDateLst := pcTmp;                                                                                                      
            bDate    := True;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         If (pbTmp = 'Y') AND (ppTmp = 'RECEIVE_TRACK'                                                                              
) AND (pgTmp IS NOT NULL) then                                                                                                      
            tDateHold := TO_CHAR(f_dex_general_date(pgTmp),'DD-MON-RRRR')                                                           
;                                                                                                                                   
            if tDateHold is not null then                                                                                           
               tDate := tDateHold;                                                                                                  
            else                                                                                                                    
               tDate := pgTmp;                                                                                                      
            end if;                                                                                                                 
                                                                                                                                    
            tDateLst := pcTmp;                                                                                                      
            bDate    := True;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         If (pbTmp = 'Y') AND (ppTmp = 'Location') and (pgT                                                                         
mp = 'SHP') AND (pcTmp = '=') then                                                                                                  
            bLocn := True;                                                                                                          
         end if;                                                                                                                    
                                                                                                                                    
         if (pbTmp = 'Y') AND (ppTmp = 'Location') and (pgTmp = 'SHP') AND (                                                        
pcTmp = '!=') then                                                                                                                  
            bTran := True;                                                                                                          
         end if;                                                                                                                    
                                                                                                                                    
         if (pbTmp = 'Y') AND (ppTmp = 'Location') then                                                                             
            bLocnSet := True;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         if (pbTmp = 'Y') AND (ppTmp = 'Status') then                                                                               
            bStatus := True;                                                                                                        
         end if;                                                                                                                    
                                                                                                                                    
         If (pbTmp = 'Y') AND (ppTmp = 'Part') AND (pgTmp IS NOT NULL                                                               
) then                                                                                                                              
            tPart    := pgTmp;                                                                                                      
            tPartLst := pcTmp;                                                                                                      
            bPart    := True;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         If (pbTmp = 'Y') AND (ppTmp = 'Cust Part') AND (pgTmp IS                                                                   
 NOT NULL) then                                                                                                                     
            tCPart    := pgTmp;                                                                                                     
            tCPartLst := pcTmp;                                                                                                     
            bCPart    := True;                                                                                                      
         end if;                                                                                                                    
      end Loop;                                                                                                                     
                                                                                                                                    
      mySect := 'Build - select';                                                                                                   
                                                                                                                                    
      dbms_output.put_line ( 'Type (Before): ' || myOp                                                                              
Type );                                                                                                                             
                                                                                                                                    
      -- Override OPTYPE flag if specific Location criteria was used.                                                               
                                                                                                                                    
      if bLocnSet then                                                                                                              
         if bTran or bDEXM then                                                                                                     
            myOPTYPE := 'Open';                                                                                                     
                                                                                                                                    
         elsif bLocn then                                                                                                           
            myOPTYPE := 'Ship';                                                                                                     
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      dbms_output.put_line ( 'Type (After): ' || myOpTy                                                                             
pe );                                                                                                                               
                                                                                                                                    
      mySQL := mySQL || ' select replace(S.ORDERNO || ''-'' || to_char(                                                             
S.ITEM,''000''),'' '','''')' || chr(10);  -- 1                                                                                      
      mySQL := mySQL || ',S.TRACK' || chr(10);                                                                                      
-- 2                                                                                                                                
      mySQL := mySQL || ',S.STORAGE' || chr(10);           -- 3                                                                     
      mySQL := mySQL || ',D.CUSTPART' || chr(10);           -                                                                       
- 4                                                                                                                                 
      mySQL := mySQL || ',H.RELEASE' || chr(10);           -- 5                                                                     
      mySQL := mySQL || ',to_char(S.DATELOC,''MM/DD/RR HH24:MI                                                                      
:SS'')' || chr(10);           -- 6                                                                                                  
      mySQL := mySQL || ',S.LOCATION' || chr(10);           -- 7                                                                    
      mySQL := mySQL || ',H.CUSTPO' || chr(10);                                                                                     
  -- 8                                                                                                                              
      mySQL := mySQL || ',D.DATESCH' || chr(10);           -- 9                                                                     
      mySQL := mySQL || ',F_DEX_ITEM_NUMBER ( D.INVENTORY_I                                                                         
TEM_ID )' || chr(10);           -- 10                                                                                               
      mySQL := mySQL || ',D.GRP' || chr(10);           -- 11                                                                        
      mySQL := mySQL || ',D.MFG' || chr(10);           --                                                                           
 12                                                                                                                                 
                                                                                                                                    
--      if myOPTYPE != 'Open' then                                                                                                  
--           mySQL := mySQL || ',F_PRICE_SHIP ( S.ORDERNO,S.ITEM                                                                    
,S.SHIPMENT,D.PRICE)   PRICE' || chr(10);                                                                                           
-- 13                                                                                                                               
--      else                                                                                                                        
--         mySQL := mySQL || ',D.PRICE' || chr(10);                                                                                 
   -- 13                                                                                                                            
--      end if;                                                                                                                     
                                                                                                                                    
     -- mySQL := mySQL || ',decode(S.LOCATION,''FIN'                                                                                
',decode(H.ORDTYPE,''R'',decode(S.SCRAP,''Y'',0,deco                                                                                
de(FEE_TOTAL,null,PRICE,0)),F_PRICE_SHIP ( S.ORDERNO                                                                                
,S.ITEM,S.SHIPMENT,D.PRICE)),F_PRICE_SHIP ( S.ORDERN                                                                                
O,S.ITEM,S.SHIPMENT,D.PRICE))   PRICE' || chr(10);                                                                                  
         -- 13                                                                                                                      
     -- DR# 56576 Use same functio that counters uses for price                                                                     
 on a Serial                                                                                                                        
      mySQL := mySQL || ',F_DEX_OPEN_AMT_SERIALS(S.SERIAL_ID,S.LO                                                                   
CATION,S.SCRAP,D.PRICE,D.FEE_TOTAL) PRICE' || chr(10                                                                                
);                                                                                                                                  
                                                                                                                                    
      mySQL := mySQL || ',H.CUST' || chr(10);           -- 14                                                                       
      mySQL := mySQL || ',H.CUST_EXCHANGE' || chr(10);                                                                              
 -- 15                                                                                                                              
      mySQL := mySQL || ',S.SHORTAGE' || chr(10);           -- 16                                                                   
      mySQL := mySQL || ',S.REASON' || chr(10);                                                                                     
 -- 17                                                                                                                              
      mySQL := mySQL || ',S.DATECMT STORAGE_DATE' || chr(10);                                                                       
 -- 18                                                                                                                              
      mySQL := mySQL || ',S.SCRAP' || chr(10);           -- 19                                                                      
      mySQL := mySQL || ',H.DATERCV' || chr(10);           -                                                                        
- 20                                                                                                                                
      mySQL := mySQL || ',H.DATETRN' || chr(10);           -- 21                                                                    
      mySQL := mySQL || ',S.TAG_NUMBER' || chr(10);                                                                                 
  -- 22                                                                                                                             
      mySQL := mySQL || ',S.SHIP_ID' || chr(10);           -- 23                                                                    
      mySQL := mySQL || ',S.PO_NO' || chr(10);                                                                                      
-- 24                                                                                                                               
      mySQL := mySQL || ',trunc(SYSDATE - S.DATELOC)' || chr(10);                                                                   
    -- 25                                                                                                                           
      mySQL := mySQL || ',S.LABEL_DATA1' || chr(10);           -- 26                                                                
                                                                                                                                    
      mySQL := mySQL || ',S.TAB_NUMBER' || chr(10);           -- 27                                                                 
      mySQL := mySQL || ',H.ATTRIBUTE3' || chr(10);                                                                                 
 -- 28                                                                                                                              
      mySQL := mySQL || ',S.SCHEDULE_ID' || chr(10);           -- 29                                                                
      mySQL := mySQL || ',M.SCHEDULE_DATE' || chr(10);                                                                              
           -- 30                                                                                                                    
      mySQL := mySQL || ',S.SERIAL' || chr(10);           --                                                                        
31                                                                                                                                  
      mySQL := mySQL || ',H.ORDTYPE' || chr(10);           -- 32                                                                    
      mySQL := mySQL || ',H.ATTRIBUTE1' || chr(10);                                                                                 
-- 33                                                                                                                               
      mySQL := mySQL || ',H.ATTRIBUTE2' || chr(10);           -- 34                                                                 
                                                                                                                                    
      if myFAIL_CHK = 'Y' then                                                                                                      
         mySQL := mySQL || ',DC.DESCRIPTION DESCR' || chr(10);           --                                                         
35                                                                                                                                  
      else                                                                                                                          
         mySQL := mySQL || ',DF.FAILURE_SYMPTOM_CODE_ID FAILURE'                                                                    
 || chr(10);           -- 35                                                                                                        
      end if;                                                                                                                       
                                                                                                                                    
      if myCOMP_CHK = 'Y' then                                                                                                      
         mySQL := mySQL || ',F_DEX_FAILURE_COMPONENT(DF                                                                             
.FAILURE_ID) COMPONENT' || chr(10);           -- 36                                                                                 
      else                                                                                                                          
         mySQL := mySQL || ',H.RMA' || chr(10);              -- 36                                                                  
      end if;                                                                                                                       
                                                                                                                                    
      if myOPTYPE = 'Open' then                                                                                                     
         mySQL := mySQL || ','' ''' || chr(10);                                                                                     
    -- 37                                                                                                                           
      else                                                                                                                          
         mySQL := mySQL || ',R.WAYBILL' || chr(10);                                                                                 
    -- 37                                                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      mySQL := mySQL || ',S.SCRAP_CTL' || chr(10);                                                                                  
        -- 38                                                                                                                       
      mySQL := mySQL || ',D.COMMENTS' || chr(10);            --                                                                     
39                                                                                                                                  
      mySQL := mySQL || ',F_DEX_ITEM_NUMBER ( D.INVENTORY_ITEM_ID,''D'' )'                                                          
|| chr(10);         -- 40 (Description)                                                                                             
      mySQL := mySQL || ',H.COMMENTS' || chr(10);            --                                                                     
41                                                                                                                                  
      mySQL := mySQL || ',H.ORG_ID' || chr(10);              -- 42                                                                  
      mySQL := mySQL || ',D.INVENTORY_ITEM_ID' || chr(10);                                                                          
 -- 43                                                                                                                              
      mySQL := mySQL || ',S.RETURN_WAYBILL' || chr(10);           -- 44                                                             
                                                                                                                                    
      mySQL := mySQL || ',S.BOX_DIM' || chr(10);           -- 45                                                                    
      mySQL := mySQL || ',DF.DOA' || chr(10);           -- 46                                                                       
      mySQL := mySQL || ',F_DEX_GET_MODEL ( D.INVENTOR                                                                              
Y_ITEM_ID ) MODEL' || chr(10);        -- 47                                                                                         
      mySQL := mySQL || ',S.SORT' || chr(10);        -- 48                                                                          
      mySQL := mySQL || ',H.PLANT' || chr(10);                                                                                      
 -- 49                                                                                                                              
      mySQL := mySQL || ',S.WARRANTY_ID' || chr(10);        -- 50                                                                   
      mySQL := mySQL || ',S.ORDERNO' || chr(10);        -                                                                           
- 51                                                                                                                                
      mySQL := mySQL || ',S.ITEM' || chr(10);        -- 52                                                                          
      mySQL := mySQL || ',DF.NTF' || chr(10);        -- 53                                                                          
      mySQL := mySQL || ',S.PALLET_ID' || chr(10);        -                                                                         
- 54                                                                                                                                
      mySQL := mySQL || ',S.TYPE_CODE' || chr(10);        -- 55                                                                     
      mySQL := mySQL || ',S.ORIG_SERIAL' || chr(10);        -                                                                       
- 56                                                                                                                                
      mySQL := mySQL || ',S.ATTRIBUTE1' || chr(10);        -- 57                                                                    
      mySQL := mySQL || ',S.ATTRIBUTE2' || chr(10);        -                                                                        
- 58                                                                                                                                
      mySQL := mySQL || ',S.ATTRIBUTE3' || chr(10);        -- 59                                                                    
      mySQL := mySQL || ',S.ATTRIBUTE4' || chr(10);        -                                                                        
- 60                                                                                                                                
      mySQL := mySQL || ',S.ATTRIBUTE5' || chr(10);        -- 61                                                                    
      mySQL := mySQL || ',F_DEX_ITEM_DATA(D.INVENTORY_ITEM_I                                                                        
D,D.ORGANIZATION_ID,''PART_CODE'')' || chr(10);                                                                                     
   -- 62                                                                                                                            
      mySQL := mySQL || ',F_DEX_WARRANTY_CLAIM_NUM(S.SERIAL_ID)' || c                                                               
hr(10);        -- 63                                                                                                                
      mySQL := mySQL || ',S.WARRANTY' || chr(10);                                                                                   
-- 64                                                                                                                               
                                                                                                                                    
      if myOPTYPE = 'Open' then                                                                                                     
         mySQL := mySQL || ','' ''' || chr(10);              -- 6                                                                   
5                                                                                                                                   
      else                                                                                                                          
         mySQL := mySQL || ',R.INVOICE' || chr(10);          -- 6                                                                   
5                                                                                                                                   
      end if;                                                                                                                       
                                                                                                                                    
      mySQL := mySQL || ', (select X.TRACK from SERIALS X whe                                                                       
re X.SERIAL_ID = S.REF_SERIAL_ID) TRACK_REF' || chr(                                                                                
10);        -- 66                                                                                                                   
      mySQL := mySQL || ',S.RTN_STATUS_CODE' || chr(10);                                                                            
 -- 67                                                                                                                              
      mySQL := mySQL || ',S.RECEIVE_DATE' || chr(10);        -- 68                                                                  
      mySQL := mySQL || ',S.ROUTE_CODE' || chr(10);                                                                                 
   -- 69                                                                                                                            
                                                                                                                                    
      mySect := 'Build - from';                                                                                                     
                                                                                                                                    
      mySQL := mySQL || ' from DEX_FAILURE DF,DEX_SCHEDULE M,                                                                       
ORDERS H,LINES D,SERIALS S' || chr(10);                                                                                             
                                                                                                                                    
      if myFAIL_CHK = 'Y' then                                                                                                      
         mySQL := replace(mySQL,' from ',' from DEX_CODES                                                                           
DC,');                                                                                                                              
      end if;                                                                                                                       
                                                                                                                                    
      If myOPTYPE != 'Open' then                                                                                                    
         mySQL := replace(mySQL,' from ',' from SHPHDRS R,');                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      mySQL := replace(mySQL,' from SHPHDRS R,SERIALS X where X.SERIAL_ID =                                                         
S.REF_SERIAL_ID',' from SERIALS X where X.SERIAL_ID                                                                                 
= S.REF_SERIAL_ID');                                                                                                                
                                                                                                                                    
      mySect := 'Build - where';                                                                                                    
                                                                                                                                    
      mySQL := mySQL || ' where S.ORDERNO     = H.ORDERNO' || chr(10);                                                              
      mySQL := mySQL || ' and   S.ORDERNO     = D.ORDER                                                                             
NO' || chr(10);                                                                                                                     
      mySQL := mySQL || ' and   S.ITEM        = D.ITEM' || chr                                                                      
(10);                                                                                                                               
      mySQL := mySQL || ' and   S.SCHEDULE_ID = M.SCHEDULE_ID (+)' || ch                                                            
r(10);                                                                                                                              
      mySQL := mySQL || ' and   S.FAILURE_ID  = DF.FAILURE_ID (+)' || c                                                             
hr(10);                                                                                                                             
                                                                                                                                    
      if myFAIL_CHK = 'Y' then                                                                                                      
         mySQL := mySQL || ' and DF.FAILURE_SYMPTOM_CODE_ID = DC                                                                    
.CODE_ID(+)' || chr(10);                                                                                                            
      end if;                                                                                                                       
                                                                                                                                    
      if myShtgCode in ('Y','N') then                                                                                               
         if myShtgCode = 'Y' then                                                                                                   
            mySQL := mySQL || ' and exists' || chr(10);                                                                             
                                                                                                                                    
         elsif myShtgCode = 'N' then                                                                                                
            mySQL := mySQL || ' and not exists' || chr                                                                              
(10);                                                                                                                               
         end if;                                                                                                                    
                                                                                                                                    
         mySQL := mySQL || '    (select ''*''' || chr(                                                                              
10);                                                                                                                                
         mySQL := mySQL || '     from   DEX_BACKORDERS dbo' || chr(10);                                                             
         mySQL := mySQL || '     where  S.SERIAL_ID =                                                                               
 dbo.SERIAL_ID)' || chr(10);                                                                                                        
      end if;                                                                                                                       
                                                                                                                                    
      if myOPTYPE = 'Ship' then                                                                                                     
         mySQL := mySQL || ' and S.ORDERNO = R.ORDERNO                                                                              
' || chr(10);                                                                                                                       
         mySQL := mySQL || ' and S.SHIPMENT = R.SHIPMENT' || chr                                                                    
(10);                                                                                                                               
                                                                                                                                    
      elsif myOPTYPE != 'Open' then                                                                                                 
         mySQL := mySQL || ' and S.ORDERNO = R.ORDERNO (+)' |                                                                       
| chr(10);                                                                                                                          
         mySQL := mySQL || ' and S.SHIPMENT = R.SHIPMENT (+)' || ch                                                                 
r(10);                                                                                                                              
      end if;                                                                                                                       
                                                                                                                                    
      if myPlant is not null then                                                                                                   
         mySQL := mySQL || ' and H.PLANT = ''' || myPlant || '''' || chr(1                                                          
0);                                                                                                                                 
      end if;                                                                                                                       
                                                                                                                                    
      If (bCust) AND (bLocn) AND (bDate) then                                                                                       
         bShip:=True;                                                                                                               
      end if;                                                                                                                       
                                                                                                                                    
      If (bShip) then                                                                                                               
                                                                                                                                    
         mySQL := mySQL || ' and R.CUST ' || tCustLst;                                                                              
                                                                                                                                    
         if tCustLst in ('IN','NOT IN') then                                                                                        
            mySQL := mySQL || GET_LIST ('C',myUserID,'Cust')                                                                        
;                                                                                                                                   
         elsif (substr(tCustLst,1,3) <> 'IS ') then                                                                                 
            mySQL := mySQL || '''' || tCust || '''';                                                                                
         end if;                                                                                                                    
                                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      If (bTran) then                                                                                                               
         mySQL:= mySQL || ' and H.TRANSFER != ''S''' || chr(10);                                                                    
         mySQL:= mySQL || ' and D.STATUS != ''S''' || chr(1                                                                         
0);                                                                                                                                 
      end if;                                                                                                                       
                                                                                                                                    
      mySect := 'Build - where loop';                                                                                               
                                                                                                                                    
      for x in 1 .. 6 loop                                                                                                          
         myGeneralizedDate := null;                                                                                                 
                                                                                                                                    
         if x = 1 then                                                                                                              
            bSelect := myCHECK1;                                                                                                    
            pSelect := myFIELD1;                                                                                                    
            pComp   := myCOMP1;                                                                                                     
            gSelect := myVALUE1;                                                                                                    
         elsif x = 2 then                                                                                                           
            bSelect := myCHECK2;                                                                                                    
            pSelect := myFIELD2;                                                                                                    
            pComp   := myCOMP2;                                                                                                     
            gSelect := myVALUE2;                                                                                                    
         elsif x = 3 then                                                                                                           
            bSelect := myCHECK3;                                                                                                    
            pSelect := myFIELD3;                                                                                                    
            pComp   := myCOMP3;                                                                                                     
            gSelect := myVALUE3;                                                                                                    
         elsif x = 4 then                                                                                                           
            bSelect := myCHECK4;                                                                                                    
            pSelect := myFIELD4;                                                                                                    
            pComp   := myCOMP4;                                                                                                     
            gSelect := myVALUE4;                                                                                                    
         elsif x = 5 then                                                                                                           
            bSelect := myCHECK5;                                                                                                    
            pSelect := myFIELD5;                                                                                                    
            pComp   := myCOMP5;                                                                                                     
            gSelect := myVALUE5;                                                                                                    
         else                                                                                                                       
            bSelect := myCHECK6;                                                                                                    
            pSelect := myFIELD6;                                                                                                    
            pComp   := myCOMP6;                                                                                                     
            gSelect := myVALUE6;                                                                                                    
         end if;                                                                                                                    
                                                                                                                                    
			-- Oct 2007:  Don't specify where clause LOCATION = SHP, when myOPTYPE = '                                                       
Ship'                                                                                                                               
			--            This causes the query to run very slow when LOCATION=SH                                                            
P is specified.  It                                                                                                                 
			--				  isn't needed because joining SERIALS with SHPHD                                                                          
RS                                                                                                                                  
			if pSelect = 'Location' and myOPTYPE = 'Ship' and bLocn then                                                                     
				bSelect := 'N';                                                                                                                 
			end if;                                                                                                                          
                                                                                                                                    
                                                                                                                                    
         if bSelect = 'Y' then                                                                                                      
            sData := pSelect;                                                                                                       
                                                                                                                                    
            if pSelect = 'Part' and pComp = '=' then                                                                                
               myItemID := F_DEX_ITEM_ID ( gSelect );                                                                               
                                                                                                                                    
               if myItemID is null then                                                                                             
                  RAISE_APPLICATION_ERROR ( -20001,'In                                                                              
valid Item Number: ' || gSelect );                                                                                                  
               end if;                                                                                                              
            end if;                                                                                                                 
                                                                                                                                    
            if (pSelect = 'Code') then                                                                                              
               gField:=' and S.CODE ';                                                                                              
            elsif (pSelect = 'Comment') then                                                                                        
               gField:=' and S.REASON ';                                                                                            
            elsif (pSelect = 'Comment_ORD') then                                                                                    
               gField:=' and upper(f_dex_convert_comments(H.ORDERNO, 0,                                                             
''O'')) ';                                                                                                                          
            elsif (pSelect = 'Comment_LNE') then                                                                                    
               gField:=' and upper(f_dex_convert_comments(D.ORDERNO, D                                                              
.ITEM,''O'')) ';                                                                                                                    
            elsif (pSelect = 'Cust') then                                                                                           
               gField:=' and H.CUST ';                                                                                              
            elsif (pSelect = 'Cust Exchange') then                                                                                  
               gField:=' and H.CUST_EXCHANGE ';                                                                                     
            elsif (pSelect = 'Cust PO') then                                                                                        
               gField:=' and H.CUSTPO ';                                                                                            
            elsif (pSelect = 'Cust Part') then                                                                                      
               gField:=' and D.CUSTPART ';                                                                                          
            elsif (pSelect = 'DateLoc') then                                                                                        
            	if myOPTYPE = 'Ship' then                                                                                              
            		-- if running ship only report use this for fast                                                                      
query                                                                                                                               
               	gField:=' and R.DATEPRO ';                                                                                          
               else                                                                                                                 
               	gField:=' and TRUNC(S.DATELOC) ';                                                                                   
               end if;                                                                                                              
            elsif (pSelect = 'DateRcv') then                                                                                        
               gField:=' and TRUNC(H.DATERCV) ';                                                                                    
            elsif (pSelect = 'DateSch') then                                                                                        
               gField:=' and TRUNC(D.DATESCH) ';                                                                                    
            elsif (pSelect = 'DateTrn') then                                                                                        
               gField:=' and TRUNC(H.DATETRN) ';                                                                                    
            elsif (pSelect = 'Expedite') then                                                                                       
               gField:=' and S.SWAP ';                                                                                              
            elsif (pSelect = 'Group') then                                                                                          
               gField:=' and D.GRP ';                                                                                               
            elsif (pSelect = 'Location') then                                                                                       
               gField:=' and S.LOCATION ';                                                                                          
            elsif (pSelect = 'NTF') then                                                                                            
               gField:=' and DF.NTF ';                                                                                              
            elsif (pSelect = 'OEM') then                                                                                            
               gField:=' and D.MFG ';                                                                                               
            elsif (pSelect = 'Order') then                                                                                          
               gField:=' and S.ORDERNO ';                                                                                           
            elsif (pSelect = 'OrdType') then                                                                                        
               gField:=' and H.ORDTYPE ';                                                                                           
            elsif (pSelect = 'Orig Serial') then                                                                                    
               gField:=' and S.ORIG_SERIAL ';                                                                                       
            elsif (pSelect = 'Return Flag') then                                                                                    
               gField:=' and H.RETURN_FLAG ';                                                                                       
            elsif (pSelect = 'PalletID') then                                                                                       
               gField:=' and S.PALLET_ID ';                                                                                         
            elsif pSelect = 'Part' and myItemID > 0 then                                                                            
               gField:=' and D.INVENTORY_ITEM_ID ';                                                                                 
            elsif (pSelect = 'Part') then                                                                                           
               gField:=' and F_DEX_ITEM_NUMBER ( D.INVENTORY_ITEM_I                                                                 
D ) ';                                                                                                                              
            elsif (pSelect = 'Part Code') then                                                                                      
               gField:=' and F_DEX_ITEM_DATA ( D.INVENTORY_ITEM_ID,D.ORGANIZ                                                        
ATION_ID,''PART_CODE'' ) ';                                                                                                         
            elsif (pSelect = 'PICKLIST_ID') then                                                                                    
               gField:=' and S.PICKLIST_ID ';                                                                                       
            elsif (pSelect = 'Plant') then                                                                                          
               gField:=' and H.PLANT ';                                                                                             
            elsif (pSelect = 'PONum') then                                                                                          
               gField:=' and S.PO_NO ';                                                                                             
            elsif (pSelect = 'Price') then                                                                                          
               if myOPTYPE != 'Open' then                                                                                           
                  gField:=' and F_PRICE_SHIP ( S.ORDERNO,S.ITEM,S.SH                                                                
IPMENT,D.PRICE) ';                                                                                                                  
               else                                                                                                                 
                  gField:=' and D.PRICE ';                                                                                          
               end if;                                                                                                              
            elsif (pSelect = 'Rownum') then                                                                                         
               gField:=' and ROWNUM ';                                                                                              
            elsif (pSelect = 'Serial') then                                                                                         
               gField:=' and S.SERIAL ';                                                                                            
            elsif (pSelect = 'Shortage') then                                                                                       
               gField:=' and S.SHORTAGE ';                                                                                          
            elsif (pSelect = 'Stat Code') then                                                                                      
               gField:=' and D.STATCODE ';                                                                                          
            elsif (pSelect = 'Status') then                                                                                         
               gField:=' and D.STATUS ';                                                                                            
            elsif (pSelect = 'Step') then                                                                                           
               gField:=' and S.LOCATION in (select LOCATION from DEX_LO                                                             
CATIONS where STEP ';                                                                                                               
            elsif (pSelect = 'Storage') then                                                                                        
               gField:=' and S.STORAGE ';                                                                                           
            elsif (pSelect = 'StorageDate') then                                                                                    
               gField:=' and TRUNC(S.DATECMT) ';                                                                                    
            elsif (pSelect = 'Store') then                                                                                          
               gField:=' and D.STORE ';                                                                                             
            elsif (pSelect = 'Scrap') then                                                                                          
               gField:=' and S.SCRAP ';                                                                                             
            elsif (pSelect = 'Sort') then                                                                                           
               gField:=' and S.SORT ';                                                                                              
            elsif (pSelect = 'Tag Number') then                                                                                     
               gField:=' and S.TAG_NUMBER ';                                                                                        
            elsif (pSelect = 'Warranty Claim Number') then                                                                          
               gField:=' and F_DEX_WARRANTY_CLAIM_NUM(S.SERIAL_ID) ';                                                               
            elsif (pSelect = 'Return Waybill') then                                                                                 
               gField:=' and S.RETURN_WAYBILL ';                                                                                    
            elsif (pSelect = 'RecertType') then                                                                                     
               gField:=' and S.TYPE_CODE ';                                                                                         
            elsif (pSelect = 'Release') then                                                                                        
               if pComp = '!=' then                                                                                                 
                  gField := ' and nvl(H.RELEASE,decode(H.CUST,''                                                                    
DEXS'',H.CUST_EXCHANGE,H.RELEASE)) ';                                                                                               
               else                                                                                                                 
                  gField:=' and H.RELEASE ';                                                                                        
               end if;                                                                                                              
            elsif (pSelect = 'OrdClosedFlag') then                                                                                  
               gField:=' and H.CLOSED_FLAG ';                                                                                       
            elsif (pSelect = 'SerClosedFlag') then                                                                                  
               gField:=' and S.CLOSED_FLAG ';                                                                                       
            elsif (pSelect = 'TranID') then                                                                                         
               gField:=' and S.TRAN_ID ';                                                                                           
            elsif (pSelect = 'ShipID') then                                                                                         
               gField:=' and S.SHIP_ID ';                                                                                           
            elsif (pSelect = 'SchdID') then                                                                                         
               gField:=' and S.SCHEDULE_ID ';                                                                                       
            elsif (pSelect = 'MPS Date') then                                                                                       
               gField:=' and M.SCHEDULE_DATE ';                                                                                     
            elsif (pSelect = 'Attribute 1') then                                                                                    
               gField:=' and H.ATTRIBUTE1 ';                                                                                        
            elsif (pSelect = 'Attribute 2') then                                                                                    
               gField:=' and H.ATTRIBUTE2 ';                                                                                        
            elsif (pSelect = 'Attribute 3') then                                                                                    
               gField:=' and H.ATTRIBUTE3 ';                                                                                        
            elsif (pSelect = 'DoaFlag') then                                                                                        
               gField:=' and nvl(DF.DOA,''N'') ';                                                                                   
            elsif (pSelect = 'Warranty Flag') then                                                                                  
               gField:=' and S.WARRANTY ';                                                                                          
            elsif (pSelect = 'Invoice') then                                                                                        
               gField:=' and R.INVOICE ';                                                                                           
            elsif (pSelect = 'Track Reference') then                                                                                
               gField:=' and S.REF_SERIAL_ID in ( select X.SERIAL                                                                   
_ID from SERIALS X where X.TRACK ';                                                                                                 
            elsif (pSelect = 'RECEIVE_TRACK') then                                                                                  
               gField:=' and S.RECEIVE_DATE ';                                                                                      
            else                                                                                                                    
               gField:=' and '  ||  pSelect || ' ';                                                                                 
            end if;                                                                                                                 
                                                                                                                                    
            if (pSelect = 'DateLoc') OR (pSelect = 'DateRcv')                                                                       
OR (pSelect = 'DateSch') OR                                                                                                         
                         (pSelect='DateTrn') OR (pSelect = 'MPS Date') OR (p                                                        
Select = 'StorageDate') or (pSelect = 'RECEIVE_TRACK                                                                                
') then                                                                                                                             
               mySQL := mySQL || gField || pComp;                                                                                   
                                                                                                                                    
               If (pComp = 'IN') OR (pComp = 'NOT IN') then                                                                         
                  mySQL := mySQL || GET_LIST('D', myUserID, sDa                                                                     
ta) || chr(10);                                                                                                                     
                  --mySQL := mySQL || ' (select TO_DATE(VALUE,                                                                      
''MM/DD/RR'') from DEX_SELECTIONS';                                                                                                 
                  --mySQL := mySQL || ' where USER_ID = ' || to_char                                                                
(myUserID) || ' and DATA = ''' || sData || ''')';                                                                                   
               else myGeneralizedDate := TO_CHAR(f_dex                                                                              
_general_date(gSelect),'DD-MON-RRRR');                                                                                              
                  if myGeneralizedDate is not null then                                                                             
                     mySQL := mySQL || ' TO_DATE(''' || myGen                                                                       
eralizedDate || ''', ''DD-MON-RRRR'')' || chr(10);                                                                                  
                  elsif (substr(pComp,1,3) <> 'IS ')                                                                                
then                                                                                                                                
                     mySQL := mySQL || ' TO_DATE(''' || gSelect || ''', '                                                           
'DD-MON-RRRR'')' || chr(10);                                                                                                        
                  end if;                                                                                                           
               end if;                                                                                                              
/*                                                                                                                                  
               elsif gSelect = 'BEGINNING OF CURRENT MONTH' then                                                                    
                  mySQL := mySQL || ' trunc(sysdate,''MM'') '|                                                                      
| chr(10);                                                                                                                          
               elsif gSelect = 'BEGINNING OF CURRENT WEEK' then                                                                     
                  mySQL := mySQL || ' trunc(sysdate,''D                                                                             
'') '|| chr(10);                                                                                                                    
               elsif gSelect = 'BEGINNING OF NEXT MONTH' then                                                                       
                                                                                                                                    
                  mySQL := mySQL || ' last_day(trunc(sysdate)) + 1 '|| chr(10                                                       
);                                                                                                                                  
               elsif gSelect = 'BEGINNING OF NEXT WEEK' then                                                                        
                  mySQL := mySQL || ' trunc(sysdate + 7,''D'') '||                                                                  
 chr(10);                                                                                                                           
               elsif gSelect = 'BEGINNING OF PRIOR MONTH' then                                                                      
                  mySQL := mySQL || ' add_months(trunc(sy                                                                           
sdate,''MM''),-1) '|| chr(10);                                                                                                      
               elsif gSelect = 'BEGINNING OF PRIOR WEEK' then                                                                       
                  mySQL := mySQL || ' trunc(sysdate - 7,''D'')                                                                      
'|| chr(10);                                                                                                                        
               elsif gSelect = 'END OF CURRENT MONTH' then                                                                          
                  mySQL := mySQL || ' last_day(trunc(sysda                                                                          
te)) '|| chr(10);                                                                                                                   
               elsif gSelect = 'END OF CURRENT WEEK' then                                                                           
                  mySQL := mySQL || ' trunc(sysdate,''                                                                              
D'') + 6 '|| chr(10);                                                                                                               
               elsif gSelect = 'END OF NEXT MONTH' then                                                                             
                  mySQL := mySQL || ' add_months(las                                                                                
t_day(trunc(sysdate)),1) '|| chr(10);                                                                                               
               elsif gSelect = 'END OF NEXT WEEK' then                                                                              
                  mySQL := mySQL || ' trunc(sysdate + 7,''D'')                                                                      
+ 6 '|| chr(10);                                                                                                                    
               elsif gSelect = 'END OF PRIOR MONTH' then                                                                            
                  mySQL := mySQL || ' trunc(sysdate,''MM                                                                            
'') - 1 '|| chr(10);                                                                                                                
               elsif gSelect = 'END OF PRIOR WEEK' then                                                                             
                  mySQL := mySQL || ' trunc(sysdate -                                                                               
 7,''D'') + 6  '|| chr(10);                                                                                                         
               elsif gSelect = 'TODAY' then                                                                                         
                  mySQL := mySQL || 'TRUNC(SYSDATE)' || ch                                                                          
r(10);                                                                                                                              
               elsif gSelect = 'TOMORROW' then                                                                                      
                  mySQL := mySQL || 'TRUNC(SYSDATE) + 1' || chr(10);                                                                
               elsif gSelect = 'YESTERDAY' then                                                                                     
                  mySQL := mySQL || 'TRUNC(SYSDATE) - 1' || chr                                                                     
(10);                                                                                                                               
                                                                                                                                    
               if pComp not in ('IN','NOT IN','IS NULL','IS NOT NULL')                                                              
and myGeneralizedDate is null then                                                                                                  
                  mySQL := mySQL || ' TO_DATE(''' || gSelect || ''',                                                                
''DD-MON-RRRR'')' || chr(10);                                                                                                       
               end if;                                                                                                              
*/                                                                                                                                  
            elsif (pSelect in ('Step','Track Reference')) then                                                                      
               mySQL := mySQL || gField || pComp;                                                                                   
                                                                                                                                    
               If substr(pComp,1,3) <> 'IS ' then                                                                                   
                  mySQL := mySQL || '''' || gSelect || '''';                                                                        
               end if;                                                                                                              
                                                                                                                                    
               mySQL := mySQL || ')' || chr(10);                                                                                    
                                                                                                                                    
            elsif (pSelect = 'Location') and ((bShip) or (bDE                                                                       
XM)) then                                                                                                                           
                                                                                                                                    
               mySQL := mySQL || ' and S.LOCATION ' || pComp;                                                                       
                                                                                                                                    
               If (substr(pComp,1,3) <> 'IS ') then                                                                                 
                  mySQL := mySQL || '''' || gSelect || '                                                                            
''';                                                                                                                                
               end if;                                                                                                              
                                                                                                                                    
            elsif (pSelect = 'Rownum') then                                                                                         
               mySQL := mySQL || gField || pComp;                                                                                   
               mySQL := mySQL || gSelect || chr(10);                                                                                
                                                                                                                                    
            elsif (pSelect = 'Cust') AND (bShip) then                                                                               
               null;                                                                                                                
                                                                                                                                    
            else                                                                                                                    
               mySQL := mySQL || gField || pComp || ' ';                                                                            
                                                                                                                                    
               If pComp = 'IN' or pComp = 'NOT IN' then                                                                             
                  mySQL := mySQL || GET_LIST ( 'C',myUserI                                                                          
D,sData ) || chr(10);                                                                                                               
                                                                                                                                    
               elsif substr(pComp,1,3) <> 'IS ' and pSe                                                                             
lect = 'Part' and myItemID > 0 then                                                                                                 
                   mySQL := mySQL || to_char(myItemID) || chr(10);                                                                  
                                                                                                                                    
               elsif substr(pComp,1,3) <> 'IS ' then                                                                                
                                                                                                                                    
                   mySQL := mySQL || '''' || gSelect || '''' || chr(10);                                                            
               end if;                                                                                                              
            end if;                                                                                                                 
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      If (bCust) AND (Not(bLocn)) AND (Not(bCFlag)) AND (                                                                           
myOPTYPE = 'Open') then                                                                                                             
         mySQL := mySQL || ' and H.CLOSED_FLAG = ''O''                                                                              
';                                                                                                                                  
                                                                                                                                    
         if (not bStatus) then                                                                                                      
             mySQL:= mySQL || ' and D.STATUS != ''S''';                                                                             
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      mySect := 'Build - sort';                                                                                                     
                                                                                                                                    
      -- Add sort statements to command                                                                                             
      SET_SORT (mySort1, myOrder1, mySQLOrder);                                                                                     
      SET_SORT (mySort2, myOrder2, mySQLOrder);                                                                                     
      SET_SORT (mySort2, myOrder2, mySQLOrder);                                                                                     
                                                                                                                                    
      if mySQLOrder is not null then                                                                                                
         mySQL := mySQL || ' order by ' || mySQLOrder || chr(10)                                                                    
;                                                                                                                                   
      end if;                                                                                                                       
                                                                                                                                    
                                                                                                                                    
      return (mySQL);                                                                                                               
   end BUILD_SQL;                                                                                                                   
                                                                                                                                    
   /*******************************************************************                                                             
*******************/                                                                                                                
                                                                                                                                    
   procedure  REPORT ( myRetMesg out varchar2,myPReportI                                                                            
D  number ) is                                                                                                                      
      myReturn   boolean;                                                                                                           
                                                                                                                                    
      myNumRows  number   := 0;                                                                                                     
                                                                                                                                    
      myInfo         varchar2(20);                                                                                                  
                                                                                                                                    
      myCur          binary_integer;        -- Source Cursor                                                                        
      myCnt          binary_integer;        -- Rows REPORTed                                                                        
                                                                                                                                    
      myData01       DEX_REPORT_LINES.DATA01%type;                                                                                  
      myData02       DEX_REPORT_LINES.DATA02%type;                                                                                  
      myData03       DEX_REPORT_LINES.DATA03%type;                                                                                  
      myData04       DEX_REPORT_LINES.DATA04%type;                                                                                  
      myData05       DEX_REPORT_LINES.DATA05%type;                                                                                  
      myData06       DEX_REPORT_LINES.DATA06%type;                                                                                  
      myData07       DEX_REPORT_LINES.DATA07%type;                                                                                  
      myData08       DEX_REPORT_LINES.DATA08%type;                                                                                  
      myData09       DEX_REPORT_LINES.DATA09%type;                                                                                  
      myData10       DEX_REPORT_LINES.DATA10%type;                                                                                  
      myData11       DEX_REPORT_LINES.DATA11%type;                                                                                  
      myData12       DEX_REPORT_LINES.DATA12%type;                                                                                  
      myData13       DEX_REPORT_LINES.DATA13%type;                                                                                  
      myData14       DEX_REPORT_LINES.DATA14%type;                                                                                  
      myData15       DEX_REPORT_LINES.DATA15%type;                                                                                  
      myData16       DEX_REPORT_LINES.DATA16%type;                                                                                  
      myData17       DEX_REPORT_LINES.DATA17%type;                                                                                  
      myData18       DEX_REPORT_LINES.DATA18%type;                                                                                  
      myData19       DEX_REPORT_LINES.DATA19%type;                                                                                  
      myData20       DEX_REPORT_LINES.DATA20%type;                                                                                  
      myData21       DEX_REPORT_LINES.DATA21%type;                                                                                  
      myData22       DEX_REPORT_LINES.DATA22%type;                                                                                  
      myData23       DEX_REPORT_LINES.DATA23%type;                                                                                  
      myData24       DEX_REPORT_LINES.DATA24%type;                                                                                  
      myData25       DEX_REPORT_LINES.DATA25%type;                                                                                  
      myData26       DEX_REPORT_LINES.DATA26%type;                                                                                  
      myData27       DEX_REPORT_LINES.DATA27%type;                                                                                  
      myData28       DEX_REPORT_LINES.DATA28%type;                                                                                  
      myData29       DEX_REPORT_LINES.DATA29%type;                                                                                  
      myData30       DEX_REPORT_LINES.DATA30%type;                                                                                  
      myData31       DEX_REPORT_LINES.DATA31%type;                                                                                  
      myData32       DEX_REPORT_LINES.DATA32%type;                                                                                  
      myData33       DEX_REPORT_LINES.DATA33%type;                                                                                  
      myData34       DEX_REPORT_LINES.DATA34%type;                                                                                  
      myData35       DEX_REPORT_LINES.DATA35%type;                                                                                  
      myData36       DEX_REPORT_LINES.DATA36%type;                                                                                  
      myData37       DEX_REPORT_LINES.DATA37%type;                                                                                  
      myData38       DEX_REPORT_LINES.DATA38%type;                                                                                  
      myData39       DEX_REPORT_LINES.DATA39%type;                                                                                  
      myData40       DEX_REPORT_LINES.DATA40%type;                                                                                  
      myData41       DEX_REPORT_LINES.DATA41%type;                                                                                  
      myData42       DEX_REPORT_LINES.DATA42%type;                                                                                  
      myData43       DEX_REPORT_LINES.DATA43%type;                                                                                  
      myData44       DEX_REPORT_LINES.DATA44%type;                                                                                  
      myData45       DEX_REPORT_LINES.DATA45%type;                                                                                  
      myData46       DEX_REPORT_LINES.DATA46%type;                                                                                  
      myData47       DEX_REPORT_LINES.DATA47%type;                                                                                  
      myData48       DEX_REPORT_LINES.DATA48%type;                                                                                  
      myData49       DEX_REPORT_LINES.DATA49%type;                                                                                  
      myData50       DEX_REPORT_LINES.DATA50%type;                                                                                  
      myData51       DEX_REPORT_LINES.DATA51%type;                                                                                  
      myData52       DEX_REPORT_LINES.DATA52%type;                                                                                  
                                                                                                                                    
      myOrdNum       ORDERS.ORDERNO%type;                                                                                           
      myOrdItm       number;                                                                                                        
                                                                                                                                    
      myType         DEX_REPORT_LINES.TYPE%type;                                                                                    
                                                                                                                                    
      myDate01       DATE;                                                                                                          
      myDate02       DATE;                                                                                                          
      myDate03       DATE;                                                                                                          
      myDate04       DATE;                                                                                                          
      myDate05       DATE;                                                                                                          
      myDate06       date;                                                                                                          
                                                                                                                                    
      myOrgID        pls_integer;                                                                                                   
      myItemID       pls_integer;                                                                                                   
      myPOHeadID     pls_integer;                                                                                                   
                                                                                                                                    
      myQty01        number;                                                                                                        
      myQty02        number;                                                                                                        
      myQty03        number;                                                                                                        
      myQty04        number;                                                                                                        
      myQty05        number;                                                                                                        
      myQty06        number;                                                                                                        
      myQty07        number;                                                                                                        
      myQty08        number;                                                                                                        
                                                                                                                                    
      myAmt01        number;                                                                                                        
      myAmt02        number := 0;                                                                                                   
                                                                                                                                    
      myOSPFlag      varchar2(1);                                                                                                   
                                                                                                                                    
      myWarrantyID    number;                                                                                                       
                                                                                                                                    
   begin                                                                                                                            
      mySQL := null;                                                                                                                
                                                                                                                                    
      mySect := 'Rep - Begin';                                                                                                      
      log;                                                                                                                          
                                                                                                                                    
      myReportID := myPReportID;                                                                                                    
                                                                                                                                    
      delete DEX_REPORT_LINES                                                                                                       
      where  REPORT_ID = myReportID;                                                                                                
                                                                                                                                    
      commit;                                                                                                                       
                                                                                                                                    
      mySect := 'Rep - Build';                                                                                                      
      log;                                                                                                                          
                                                                                                                                    
      mySQL := BUILD_SQL ( myOSPFlag );                                                                                             
                                                                                                                                    
      if myLog = 'Y' then                                                                                                           
         myLogNum := myLogNum + 1;                                                                                                  
                                                                                                                                    
         insert into DEX_LOG                                                                                                        
        (PROGRAM,LOG_DATE,SECTION,LOG_NUM,SEGMENT1)                                                                                 
         values                                                                                                                     
        ('PRODSTAT',SYSDATE,'SQL',myLogNum,mySQL);                                                                                  
                                                                                                                                    
         commit;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      if myRunSQL then                                                                                                              
         mySect := 'Rep - After-Build';                                                                                             
         log;                                                                                                                       
                                                                                                                                    
         myCur := DBMS_SQL.OPEN_CURSOR;                                                                                             
                                                                                                                                    
         -- write to DEX_REPORT_LINES                                                                                               
         DBMS_SQL.PARSE( myCur,mySQL, dbms_sql.v7 );                                                                                
                                                                                                                                    
         mySect := 'Rep - Define Column';                                                                                           
                                                                                                                                    
         DBMS_SQL.DEFINE_COLUMN( myCur,1,myData01,80 );                                                                             
         DBMS_SQL.DEFINE_COLUMN( myCur,2,myData02,80 );                                                                             
         DBMS_SQL.DEFINE_COLUMN( myCur,3,myData03,80 )                                                                              
;                                                                                                                                   
         DBMS_SQL.DEFINE_COLUMN( myCur,4,myData04,100 );                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,5,myData28,150 );                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,6,myData05,80 );                                                                             
         DBMS_SQL.DEFINE_COLUMN( myCur,7,myData12,20 );                                                                             
         DBMS_SQL.DEFINE_COLUMN( myCur,8,myData07,20 );                                                                             
         DBMS_SQL.DEFINE_COLUMN( myCur,9,myDate01 );                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,10,myData08,10                                                                               
0 );                                                                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,11,myData09,20 );                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,12,myData10,20 );                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,13,myAmt01 );                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,14,myData11,20 );                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,15,myData25,150 );                                                                           
                                                                                                                                    
         DBMS_SQL.DEFINE_COLUMN( myCur,16,myData16,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,17,myData06,80 );                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,18,myDate02 );                                                                               
         DBMS_SQL.DEFINE_COLUMN( myCur,19,myData13,20 );                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,20,myDate03 );                                                                               
         DBMS_SQL.DEFINE_COLUMN( myCur,21,myDate04 );                                                                               
         DBMS_SQL.DEFINE_COLUMN( myCur,22,myData14,20 )                                                                             
;                                                                                                                                   
         DBMS_SQL.DEFINE_COLUMN( myCur,23,myQty01 );                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,24,myData15,20 );                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,25,myQty03 );                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,26,myData18,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,27,myData19,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,28,myData20,150 );                                                                           
                                                                                                                                    
         DBMS_SQL.DEFINE_COLUMN( myCur,29,myQty02 );                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,30,myDate05 );                                                                               
         DBMS_SQL.DEFINE_COLUMN( myCur,31,myData21,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,32,myType,1 );                                                                               
         DBMS_SQL.DEFINE_COLUMN( myCur,33,myData22,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,34,myData23,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,35,myData24,150                                                                              
 );                                                                                                                                 
         DBMS_SQL.DEFINE_COLUMN( myCur,36,myData27,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,37,myData29,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,38,myData30,150 );                                                                           
         DBMS_SQL.DEFINE_COLUMN( myCur,39,myData40,150);                                                                            
                                                                                                                                    
         DBMS_SQL.DEFINE_COLUMN( myCur,40,myData31,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,41,myData41,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,42,myOrgID);                                                                                 
         DBMS_SQL.DEFINE_COLUMN( myCur,43,myItemID);                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,44,myData42,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,45,myData43,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,46,myData46,150);                                                                            
                                                                                                                                    
         DBMS_SQL.DEFINE_COLUMN( myCur,47,myData47,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,48,myData48,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,49,myData49,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,50,myWarrantyID);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,51,myOrdNum,20);                                                                             
         DBMS_SQL.DEFINE_COLUMN( myCur,52,myOrdItm);                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,53,myData32,1                                                                                
);                                                                                                                                  
         DBMS_SQL.DEFINE_COLUMN( myCur,54,myQty07);                                                                                 
         DBMS_SQL.DEFINE_COLUMN( myCur,55,myData33,2);                                                                              
         DBMS_SQL.DEFINE_COLUMN( myCur,56,myData34,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,57,myData35,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,58,myData36,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,59,myData37,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,60,myData38,1                                                                                
50);                                                                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,61,myData39,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,62,myData17,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,63,myData26,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,64,myData44,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,65,myData45,15                                                                               
0);                                                                                                                                 
         DBMS_SQL.DEFINE_COLUMN( myCur,66,myData50,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,67,myData51,150);                                                                            
         DBMS_SQL.DEFINE_COLUMN( myCur,68,myDate06);                                                                                
         DBMS_SQL.DEFINE_COLUMN( myCur,69,myData52,150);                                                                            
                                                                                                                                    
         mySect := 'Rep - Execute';                                                                                                 
                                                                                                                                    
         myCnt := DBMS_SQL.EXECUTE( myCur );                                                                                        
                                                                                                                                    
         commit;                                                                                                                    
                                                                                                                                    
         mySect := 'Rep - Column Value';                                                                                            
                                                                                                                                    
         loop                                                                                                                       
            if DBMS_SQL.FETCH_ROWS( myCur ) > 0 then                                                                                
               DBMS_SQL.COLUMN_VALUE( myCur,1,myData01                                                                              
);                                                                                                                                  
               DBMS_SQL.COLUMN_VALUE( myCur,2,myData02 );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,3,myData03 );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,4,myData04 );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,5,myData28  )                                                                           
;                                                                                                                                   
               DBMS_SQL.COLUMN_VALUE( myCur,6,myData05 );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,7,myData12 );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,8,myData07  );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,9,myDate01 );                                                                           
                                                                                                                                    
               DBMS_SQL.COLUMN_VALUE( myCur,10,myData08 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,11,myData09 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,12,myData10 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,13,myAmt01 )                                                                            
;                                                                                                                                   
               DBMS_SQL.COLUMN_VALUE( myCur,14,myData11 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,15,myData25 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,16,myData16 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,17,myData06                                                                             
 );                                                                                                                                 
               DBMS_SQL.COLUMN_VALUE( myCur,18,myDate02 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,19,myData13 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,20,myDate03 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,21,myDate                                                                               
04 );                                                                                                                               
               DBMS_SQL.COLUMN_VALUE( myCur,22,myData14 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,23,myQty01 );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,24,myData15 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,25,myQty                                                                                
03 );                                                                                                                               
               DBMS_SQL.COLUMN_VALUE( myCur,26,myData18 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,27,myData19 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,28,myData20 );                                                                          
                                                                                                                                    
               DBMS_SQL.COLUMN_VALUE( myCur,29,myQty02 );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,30,myDate05 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,31,myData21 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,32,myType );                                                                            
               DBMS_SQL.COLUMN_VALUE( myCur,33,myDat                                                                                
a22 );                                                                                                                              
               DBMS_SQL.COLUMN_VALUE( myCur,34,myData23 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,35,myData24 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,36,myData27 )                                                                           
;                                                                                                                                   
               DBMS_SQL.COLUMN_VALUE( myCur,37,myData29 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,38,myData30 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,39,myData40 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,40,myData31                                                                             
 );                                                                                                                                 
               DBMS_SQL.COLUMN_VALUE( myCur,41,myData41 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,42,myOrgID );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,43,myItemID );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,44,myData4                                                                              
2 );                                                                                                                                
               DBMS_SQL.COLUMN_VALUE( myCur,45,myData43 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,46,myData46 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,47,myData47 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,48,myDat                                                                                
a48 );                                                                                                                              
               DBMS_SQL.COLUMN_VALUE( myCur,49,myData49 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,50,myWarrantyID );                                                                      
               DBMS_SQL.COLUMN_VALUE( myCur,51,myOrdN                                                                               
um );                                                                                                                               
               DBMS_SQL.COLUMN_VALUE( myCur,52,myOrdItm );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,53,myData32 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,54,myQty07 );                                                                           
               DBMS_SQL.COLUMN_VALUE( myCur,55,myDat                                                                                
a33 );                                                                                                                              
               DBMS_SQL.COLUMN_VALUE( myCur,56,myData34 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,57,myData35 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,58,myData36 )                                                                           
;                                                                                                                                   
               DBMS_SQL.COLUMN_VALUE( myCur,59,myData37 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,60,myData38 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,61,myData39 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,62,myData17                                                                             
 );                                                                                                                                 
               DBMS_SQL.COLUMN_VALUE( myCur,63,myData26 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,64,myData44 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,65,myData45 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,66,myData                                                                               
50 );                                                                                                                               
               DBMS_SQL.COLUMN_VALUE( myCur,67,myData51 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,68,myDate06 );                                                                          
               DBMS_SQL.COLUMN_VALUE( myCur,69,myData52 );                                                                          
                                                                                                                                    
                                                                                                                                    
               if nvl(myROAR_Chk,'N') = 'Y' then                                                                                    
                  mySect := 'Rep - ROAR Info';                                                                                      
                                                                                                                                    
                  select nvl(sum(decode(STATUS,'O',1,'P',                                                                           
1,'R',1,0)),0)                                                                                                                      
                        ,nvl(sum(decode(STATUS,'O',0,'P',0,'R',                                                                     
0,1)),0)                                                                                                                            
                        ,nvl(sum(decode(DATECLS,null,SYSDATE - DATEOP                                                               
N,DATECLS - DATEOPN)),0)                                                                                                            
                  into   myQty05                                                                                                    
                        ,myQty06                                                                                                    
                        ,myQty08                                                                                                    
                  from   ROARCON                                                                                                    
                  where  ORDERNO = myOrdNum                                                                                         
                  and    STATUS != 'X'                                                                                              
                  and  ((TYPE = 'OS' and ITEM is null) or (TYPE != 'OS'                                                             
and ITEM = myOrdItm));                                                                                                              
                                                                                                                                    
                  myQty08 := round(myQty08,2);                                                                                      
               end if;                                                                                                              
                                                                                                                                    
               if myData51 is not null then                                                                                         
                  myData51 := F_DEX_FLEX_VALUE ('DEX Return Status Co                                                               
de', myData51);                                                                                                                     
               end if;                                                                                                              
                                                                                                                                    
               if myOSPFlag = 'Y' and myData15 is not null then                                                                     
                  mySect := 'Rep - OSP';                                                                                            
                                                                                                                                    
                  begin                                                                                                             
                     select pov.VENDOR_NAME                                                                                         
                           ,poh.ATTRIBUTE2                                                                                          
                           ,poh.PO_HEADER_ID                                                                                        
                     into   myData29                                                                                                
                           ,myData27                                                                                                
                           ,myPOHeadID                                                                                              
                     from   PO_VENDORS pov                                                                                          
                           ,PO_HEADERS_ALL Poh                                                                                      
                     where  poh.VENDOR_ID = pov.VENDOR_ID                                                                           
                     and    poh.SEGMENT1  = myData15                                                                                
                     and    poh.ORG_ID    = myOrgID                                                                                 
                     and    poh.TYPE_LOOKUP_CODE in ('STANDA                                                                        
RD','BLANKET','PLANNED','CONTRACT');                                                                                                
                                                                                                                                    
                  exception                                                                                                         
                     when NO_DATA_FOUND then                                                                                        
                        myData29 := null;                                                                                           
                  end;                                                                                                              
                                                                                                                                    
                  mySect := 'Rep - PO Price';                                                                                       
                                                                                                                                    
                  begin                                                                                                             
                     select nvl(UNIT_PRICE,0)                                                                                       
                     into   myAmt02                                                                                                 
                     from   PO_LINES_ALL                                                                                            
                     where  PO_HEADER_ID = myPOHeadID                                                                               
                     and    ITEM_ID      = myItemID                                                                                 
                     and    rownum       < 2;                                                                                       
                                                                                                                                    
                  exception                                                                                                         
                     when NO_DATA_FOUND then                                                                                        
                        myAmt02 := 0;                                                                                               
                  end;                                                                                                              
               else                                                                                                                 
                  myAmt02 := 0;                                                                                                     
               end if;                                                                                                              
                                                                                                                                    
               -- if Location = PKD and ShipID is not null and Waybill i                                                            
s null :  get Waybill for DEX_SHIP_INTERFACE                                                                                        
               if myData12 = 'PKD'  and myQty01 is not null                                                                         
 and rtrim(myData29) is null then                                                                                                   
                  mySect := 'Rep - Waybill';                                                                                        
                                                                                                                                    
                  begin                                                                                                             
                     select WAYBILL_NUM                                                                                             
                     into   myData29                                                                                                
                     from   DEX_SHIP_INTERFACE                                                                                      
                     where  SHIP_ID = myQty01                                                                                       
                     and    STATUS = 'D';                                                                                           
                  exception                                                                                                         
                     when OTHERS then                                                                                               
                        null;                                                                                                       
                  end;                                                                                                              
               end if;                                                                                                              
                                                                                                                                    
               myQty04 := 0;                                                                                                        
                                                                                                                                    
               if nvl(myWarrantyID,0) != 0 then                                                                                     
                  mySect := 'Rep - Warr Detl';                                                                                      
                                                                                                                                    
                  -- get count of # times in plant                                                                                  
                  select count(*)                                                                                                   
                  into   myQty04                                                                                                    
                  from   DEX_WARRANTY_DETAIL                                                                                        
                  where  WARRANTY_ID = myWarrantyID;                                                                                
                  -- and    WARRANTY = 'Valid';                                                                                     
               end if;                                                                                                              
                                                                                                                                    
               mySect := 'Rep - Insert in Lines';                                                                                   
                                                                                                                                    
               insert into DEX_REPORT_LINES                                                                                         
              (REPORT_LINE_ID,REPORT_ID                                                                                             
              ,DATA01,DATA02,DATA03,DATA04,DATA05,DATA06,D                                                                          
ATA07,DATA08,DATA09,DATA10                                                                                                          
              ,DATA11,DATA12,DATA13,DATA14,DATA15,DATA16,DATA17,DATA18,DATA19                                                       
,DATA20                                                                                                                             
              ,DATA21,DATA22,DATA23,DATA24,DATA25,DATA26,DATA27,DATA28                                                              
,DATA29,DATA30                                                                                                                      
              ,DATA31,DATA32,DATA33,DATA34,DATA35,DATA36,DATA37                                                                     
,DATA38,DATA39,DATA40                                                                                                               
              ,DATA41,DATA42,DATA43,DATA44,DATA45,DATA46                                                                            
,DATA47,DATA48,DATA49,DATA50                                                                                                        
              ,DATA51,DATA52                                                                                                        
              ,TYPE,QTY01,QTY02,QTY03,QTY04,QTY05,QTY06,QTY07,QTY08                                                                 
              ,AMT01,AMT02                                                                                                          
              ,DATE01,DATE02,DATE03,DATE04,DATE05,DATE0                                                                             
6                                                                                                                                   
              ) values (                                                                                                            
               DEX_REPORT_LINES_S.nextval,myReportID                                                                                
              ,myData01,myData02,myData03,myData04,myData05,myData06,myData0                                                        
7,myData08,myData09,myData10                                                                                                        
              ,myData11,myData12,myData13,myData14,myData15,myData16,myData                                                         
17,myData18,myData19,myData20                                                                                                       
              ,myData21,myData22,myData23,myData24,myData25,myData26,myDat                                                          
a27,myData28,myData29,myData30                                                                                                      
              ,myData31,myData32,myData33,myData34,myData35,myData36,myDa                                                           
ta37,myData38,myData39,myData40                                                                                                     
              ,myData41,myData42,myData43,myData44,myData45,myData46,myD                                                            
ata47,myData48,myData49,myData50                                                                                                    
              ,myData51,myData52                                                                                                    
              ,myType,myQty01,myQty02,myQty03,myQty04,myQty05,my                                                                    
Qty06,myQty07,myQty08                                                                                                               
              ,myAmt01,myAmt02                                                                                                      
              ,myDate01,myDate02,myDate03,myDate04,myDate05,myDate06                                                                
              );                                                                                                                    
                                                                                                                                    
               mySect := 'Rep - Insert in Lines';                                                                                   
                                                                                                                                    
            else                                                                                                                    
               exit;                                                                                                                
            end if;                                                                                                                 
         end loop;                                                                                                                  
                                                                                                                                    
         mySect := 'Rep - Finished';                                                                                                
         log;                                                                                                                       
                                                                                                                                    
         DBMS_SQL.CLOSE_CURSOR( myCur );                                                                                            
                                                                                                                                    
         commit;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end REPORT;                                                                                                                      
end K_DEX_PRODUCT_STATUS;                                                                                                           
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

