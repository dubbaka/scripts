alter session set nls_date_format='YYYY/MM/DD HH24:MI';
set lines 120 pages 500
col wait_class format a35
col event format a45
SELECT to_char(a.sample_time,'YYYY/MM/DD HH24:mi') Sample_Time,a.event,a.machine,count(1)
FROM
dba_hist_active_sess_history a
WHERE
a.sample_time > TO_DATE('&2') and a.sample_time < TO_DATE('&3')
and instance_number=&4
and a.wait_class in (initcap('&1'))
group by to_char(a.sample_time,'YYYY/MM/DD HH24:mi'), a.wait_class,a.event
ORDER BY 2,4 desc;
