set lines 180 
alter session set nls_date_format='YYYY-DD-MM HH24:MI:SS'; 
 SELECT to_char(a.sample_time,'DD-MON-YYYY HH24'),a.machine,a.sql_id,count(1)
  FROM
  dba_hist_active_sess_history a
  WHERE
 a.sample_time > TO_DATE('&1') and a.sample_time < TO_DATE('&2')
and a.machine in ('prn-adfprd01.thefacebook.com','prn-adfprd02.thefacebook.com')
--and a.sql_id='9bcamcmxrjktr'
  group by a.machine,to_char(a.sample_time,'DD-MON-YYYY HH24'),a.sql_id
  ORDER BY  4 ;
