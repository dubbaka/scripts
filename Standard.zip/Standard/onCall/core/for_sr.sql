select  to_date( to_char(last_connect,'DD-MON-YYYY')) , count(distinct user_id) "users"
from icx_sessions
where  last_connect > sysdate - &days and user_id != '-1' and counter < limit_connects and disabled_flag != 'Y' and PSEUDO_FLAG = 'N'
group by to_date( to_char(last_connect,'DD-MON-YYYY'))
order by 1 desc;


-- 2) All sessions
selAect  to_date( to_char(last_connect,'DD-MON-YYYY')) , count(user_id) "users"
from icx_sessions
where  last_connect > sysdate - &days and user_id != '-1' and counter < limit_connects and disabled_flag != 'Y' and PSEUDO_FLAG = 'N'
group by to_date( to_char(last_connect,'DD-MON-YYYY')) order by 1 desc;


-- B)  Using query as note 295206.1

-- 1)  Distinct Users
select  to_date( to_char(last_connect,'DD-MON-YYYY')) , count(distinct user_id) "users"
from icx_sessions
where  last_connect > sysdate - &days and user_id != '-1' and counter < limit_connects
group by to_date( to_char(last_connect,'DD-MON-YYYY'))
order by 1 desc;


-- 2) All sessions
select  to_date( to_char(last_connect,'DD-MON-YYYY')) , count(user_id) "users"
from icx_sessions
where  last_connect > sysdate - &days and user_id != '-1' and counter < limit_connects
group by to_date( to_char(last_connect,'DD-MON-YYYY')) order by 1 desc;


