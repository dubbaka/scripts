column event format a40
set pagesize 80

select a.event,count(*),avg(b.wait_time)
from v$session a,v$session_wait b
where a.sid = b.sid
and a.type != 'BACKGROUND'
group by a.event 
order by 2
/
