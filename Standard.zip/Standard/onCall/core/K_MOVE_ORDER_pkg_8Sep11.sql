                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."K_MOVE_ORDER" AUTHID CURRENT_USER as                                                            
/* $Header: K_MOVE_ORDER.sql 2.1.2.0 2010/06/10 12:00:00                                                                            
 dexsys ship $ Copyright (c) 2008 DEX Systems, Inc.                                                                                 
*/                                                                                                                                  
                                                                                                                                    
   procedure LOG_SET;                                                                                                               
   procedure LOG_UNSET;                                                                                                             
                                                                                                                                    
   procedure CHANGE_CUST (                                                                                                          
                           myRetMesg   out  varchar2                                                                                
                                                                                                                                    
                          ,myRetCode   out  number                                                                                  
                          ,myOrder     in   varchar2                                                                                
                                                                                                                                    
                          ,myCust      in   varchar2                                                                                
                          ,myLineFlag  in   varchar2                                                                                
                          ,myECust     in   varchar2 default null                                                                   
                         );                                                                                                         
                                                                                                                                    
   procedure CHANGE_CUST (                                                                                                          
                           myOrder     varchar2                                                                                     
                          ,myCust      varchar2                                                                                     
                          ,myLineFlag  varchar2                                                                                     
                          ,myECust     varchar2 default null                                                                        
                         );                                                                                                         
                                                                                                                                    
   procedure SERIAL      (                                                                                                          
                           myOrder        varchar2                                                                                  
                          ,myItem         number                                                                                    
                          ,mySerialID     number                                                                                    
                          ,myNPrice       number                                                                                    
                          ,myNStatCode    varchar2  default null                                                                    
                          ,myNSchdDate    date      d                                                                               
efault null                                                                                                                         
                          ,myNItemID      number    default null                                                                    
                          ,myNCPart       varchar2  d                                                                               
efault null                                                                                                                         
                          ,myNGrp         varchar2  default null                                                                    
                         );                                                                                                         
                                                                                                                                    
   procedure SERIAL      (                                                                                                          
                           myRetMesg   out  varchar2                                                                                
                          ,myRetCode   out  number                                                                                  
                          ,myOrder     in   varchar2                                                                                
                          ,myItem      in   number                                                                                  
                          ,mySerialID  in   number                                                                                  
                          ,myNPrice    in   number                                                                                  
                          ,myNStatCode in   varchar2  default null                                                                  
                          ,myNSchdDate in   date      default                                                                       
null                                                                                                                                
                          ,myNItemID   in   number    default null                                                                  
                          ,myNCPart    in   varchar2  defa                                                                          
ult null                                                                                                                            
                          ,myNGrp      in   varchar2  default null                                                                  
                         );                                                                                                         
                                                                                                                                    
   procedure SERIAL      (                                                                                                          
                           myRetMesg   out  varchar2                                                                                
                          ,myRetCode   out  number                                                                                  
                          ,myTranID    in   number                                                                                  
                          ,myOrder     in   varchar2                                                                                
                          ,myNOrder    in   varchar2                                                                                
                          ,myCustPO    in   varchar2                                                                                
                          ,myRelease   in   varchar2                                                                                
                          ,myNCust     in   varchar2 default null                                                                   
                         );                                                                                                         
                                                                                                                                    
   procedure PROCESS     (                                                                                                          
                           myOrder     varchar2                                                                                     
                          ,myNOrder    varchar2                                                                                     
                          ,myTranID    number                                                                                       
                          ,myBuyFlag   varchar2 default 'N'                                                                         
                         );                                                                                                         
                                                                                                                                    
   procedure CONSOLIDATE (                                                                                                          
                           myRetMesg      out  varchar2                                                                             
                          ,myRetCode      out  number                                                                               
                                                                                                                                    
                          ,myNOrder    in out  varchar2                                                                             
                          ,myOrder     in      varchar2                                                                             
                         );                                                                                                         
                                                                                                                                    
   procedure CHANGE_PO   (                                                                                                          
                           myRetMesg      out  varchar2                                                                             
                          ,myRetCode      out  number                                                                               
                          ,myNOrder    in out  varchar2                                                                             
                          ,myOrder     in      varchar2                                                                             
                                                                                                                                    
                          ,myCustPO    in      varchar2                                                                             
                          ,myCPart     in      varchar2                                                                             
                          ,myCQty      in      number                                                                               
                          ,myAllowFIN	in		  varchar2 default 'N'                                                                    
                         );                                                                                                         
                                                                                                                                    
   procedure SERL_CUST   (                                                                                                          
                           myRetMesg      out  varchar2                                                                             
                          ,myRetCode      out  number                                                                               
                          ,myNOrder    in out  varchar2                                                                             
                          ,myNCust     in      varchar2                                                                             
                          ,myTranID    in      number                                                                               
                         );                                                                                                         
end K_MOVE_ORDER;                                                                                                                   
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."K_MOVE_ORDER" as                                                                             
/* $Header: K_MOVE_ORDER.sql 2.1.2.0 2010/06/10 12:00:00 dexs                                                                       
ys ship $ Copyright (c) 2008 DEX Systems, Inc. */                                                                                   
                                                                                                                                    
   mySect      varchar2(100);                                                                                                       
                                                                                                                                    
   myLog       varchar2(1)    := 'N';                                                                                               
                                                                                                                                    
   myHCust     varchar2(30) := XXDEX_DEFAULTS_F ( 'INTERNAL_C                                                                       
UST_HOUSE' );                                                                                                                       
   mySCust     varchar2(30) := XXDEX_DEFAULTS_F ( 'INTERNAL_CUST                                                                    
_SHARE' );                                                                                                                          
   myTCust     varchar2(30) := XXDEX_DEFAULTS_F ( 'INTERNAL_CUST_TE                                                                 
ST' );                                                                                                                              
   myRCust     varchar2(30) := XXDEX_DEFAULTS_F ( 'INTERNAL_CUST_REPAIR                                                             
' );                                                                                                                                
                                                                                                                                    
   /********************************************************************                                                            
*********************************/                                                                                                  
                                                                                                                                    
   procedure LOG ( mySegment varchar2 default null ) is                                                                             
   begin                                                                                                                            
      if myLog = 'Y' then                                                                                                           
         K_DEX_LOG.LOG ( mySect,mySegment,'K_MOVE_ORDER                                                                             
' );                                                                                                                                
      end if;                                                                                                                       
   end LOG;                                                                                                                         
                                                                                                                                    
   /********************************************************************                                                            
*********************************/                                                                                                  
                                                                                                                                    
   procedure LOG_SET is                                                                                                             
   begin                                                                                                                            
      myLog := 'Y';                                                                                                                 
      K_DEX_LOG.LOG_SET;                                                                                                            
   end LOG_SET;                                                                                                                     
                                                                                                                                    
   /*************************************************************************                                                       
****************************/                                                                                                       
                                                                                                                                    
   procedure LOG_UNSET is                                                                                                           
   begin                                                                                                                            
      myLog := 'N';                                                                                                                 
      K_DEX_LOG.LOG_UNSET;                                                                                                          
   end LOG_UNSET;                                                                                                                   
                                                                                                                                    
   /************************************************************************                                                        
*****************************/                                                                                                      
                                                                                                                                    
   procedure CHANGE_CUST (                                                                                                          
                           myRetMesg   out  varchar2                                                                                
                          ,myRetCode   out  number                                                                                  
                          ,myOrder     in   varchar2                                                                                
                          ,myCust      in   varchar2                                                                                
                          ,myLineFlag  in   varchar2                                                                                
                          ,myECust     in   varchar2 default null                                                                   
                         ) is                                                                                                       
      myOrdType      varchar2(1);                                                                                                   
      myCODFlag      varchar2(1);                                                                                                   
      myEDIFlag      varchar2(1) := 'N';                                                                                            
      myDropShip     varchar2(1);                                                                                                   
      myBusType      varchar2(1);                                                                                                   
      myPriceType    varchar2(2);                                                                                                   
      myPlant        DEX_PLANTS.PLANT%type;                                                                                         
                                                                                                                                    
      myShipto       number(3) := 0;                                                                                                
                                                                                                                                    
      myCustID       number(15);                                                                                                    
      myTCustID      number(15);                                                                                                    
      myBillSiteID   number(15);                                                                                                    
      myShipSiteID   number(15);                                                                                                    
      myOrgID        number(15);                                                                                                    
      myInvOrgID     number(15);                                                                                                    
                                                                                                                                    
      myPrice        number;                                                                                                        
                                                                                                                                    
      myOCust        DEX_ORDERS.CUST%type;                                                                                          
                                                                                                                                    
      myCustName     XXDEX_PARTIES_V.CUSTOMER_NAME%type                                                                             
;                                                                                                                                   
      myShipPartial  XXDEX_PARTIES_V.SHIP_PARTIAL%type;                                                                             
      myCustType     XXDEX_PARTIES_V.CUSTOMER_TYPE%type;                                                                            
                                                                                                                                    
      myAdvRep       DEX_CUSTOMER_DATA.ADVREP_FLAG%type;                                                                            
      myRecvRma      DEX_CUSTOMER_DATA.RECV_RMA_FLAG%type;                                                                          
      myValCustPart  DEX_CUSTOMER_DATA.VALIDATE_CUSTPA                                                                              
RT_FLAG%type;                                                                                                                       
                                                                                                                                    
      myRelabel      DEX_ORDERS.RELABEL_FLAG%type;                                                                                  
      myShipName     DEX_ORDERS.SHIP_NAME%type;                                                                                     
      myShipAttn     DEX_ORDERS.SHIP_ATTN%type;                                                                                     
      myShipSt1      DEX_ORDERS.SHIP_ST1%type;                                                                                      
      myShipSt2      DEX_ORDERS.SHIP_ST2%type;                                                                                      
      myShipCity     DEX_ORDERS.SHIP_CITY%type;                                                                                     
      myShipState    DEX_ORDERS.SHIP_STATE%type;                                                                                    
      myShipZip      DEX_ORDERS.SHIP_ZIP%type;                                                                                      
      myCountry      DEX_ORDERS.COUNTRY%type;                                                                                       
      myRegion       DEX_ORDERS.REGION%type;                                                                                        
      myAgent        DEX_ORDERS.AGENT%type;                                                                                         
      myTLM          DEX_ORDERS.TLM%type;                                                                                           
      myShipVia      DEX_ORDERS.SHIP_VIA%type;                                                                                      
      myOrdSrc       DEX_ORDERS.ORDER_SOURCE%type;                                                                                  
                                                                                                                                    
      myActive       V_DEX_PART_DATA.ACTIVE_FLAG%typ                                                                                
e;                                                                                                                                  
                                                                                                                                    
      ABORT_PROC     exception;                                                                                                     
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select ITEM                                                                                                                
               ,INVENTORY_ITEM_ID                                                                                                   
               ,ORGANIZATION_ID                                                                                                     
               ,PRICE                                                                                                               
               ,PART                                                                                                                
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    QTYORG > nvl(QTYSHP,0);                                                                                             
                                                                                                                                    
      cursor c2 ( myItemID number ) is                                                                                              
         select mci.CUSTOMER_ITEM_NUMBER                                                                                            
               ,mci.CUSTOMER_ITEM_ID                                                                                                
         from   MTL_CUSTOMER_ITEMS mci                                                                                              
               ,MTL_CUSTOMER_ITEM_XREFS mcx                                                                                         
         where  mci.CUSTOMER_ITEM_ID  = mcx.CUSTOMER_ITEM_I                                                                         
D                                                                                                                                   
         and    mcx.INVENTORY_ITEM_ID = myItemID                                                                                    
         and    mci.CUSTOMER_ID       = myTCustID                                                                                   
              -- myTCustID not myCustID                                                                                             
         order by PREFERENCE_NUMBER,CUSTOMER_ITEM_NUMBER;                                                                           
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
      mySect := 'Cust - Start';                                                                                                     
      log;                                                                                                                          
      mySect := 'Cust - Load Data';                                                                                                 
                                                                                                                                    
      select ORDTYPE                                                                                                                
            ,CUST                                                                                                                   
            ,PLANT                                                                                                                  
            ,ORG_ID                                                                                                                 
            ,nvl(RELABEL_FLAG,'N')                                                                                                  
            ,ORDER_SOURCE                                                                                                           
            ,BILL_SITE_USE_ID                                                                                                       
            ,SHIP_SITE_USE_ID                                                                                                       
      into   myOrdType                                                                                                              
            ,myOCust                                                                                                                
            ,myPlant                                                                                                                
            ,myOrgID                                                                                                                
            ,myRelabel                                                                                                              
            ,myOrdSrc                                                                                                               
            ,myBillSiteID                                                                                                           
            ,myShipSiteID                                                                                                           
      from   DEX_ORDERS                                                                                                             
      where  ORDERNO = myOrder;                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cust - Load Cust';                                                                                                 
                                                                                                                                    
      select rac.CUSTOMER_ID                                                                                                        
            ,rac.CUSTOMER_NAME                                                                                                      
            ,rac.SHIP_PARTIAL                                                                                                       
            ,dcd.ADVREP_FLAG                                                                                                        
            ,dcd.RECV_RMA_FLAG                                                                                                      
            ,nvl(dcd.VALIDATE_CUSTPART_FLAG,'N')                                                                                    
            ,rac.CUSTOMER_TYPE                                                                                                      
      into   myCustID                                                                                                               
            ,myCustName                                                                                                             
            ,myShipPartial                                                                                                          
            ,myAdvRep                                                                                                               
            ,myRecvRma                                                                                                              
            ,myValCustPart                                                                                                          
            ,myCustType                                                                                                             
      from   DEX_CUSTOMER_DATA dcd                                                                                                  
            ,XXDEX_PARTIES_V rac                                                                                                    
      where  dcd.CUSTOMER_ID     = rac.CUSTOMER_ID                                                                                  
      and    dcd.ORG_ID          = myOrgID                                                                                          
      and    rac.CUSTOMER_NUMBER = myCust;                                                                                          
                                                                                                                                    
      if myECust is null then                                                                                                       
         myTCustID := myCustID;                                                                                                     
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'Cust - Load Cust Exchange';                                                                                     
                                                                                                                                    
         select rac.CUSTOMER_ID                                                                                                     
               ,dcd.RECV_RMA_FLAG                                                                                                   
               ,nvl(dcd.VALIDATE_CUSTPART_FLAG,'N')                                                                                 
         into   myTCustID                                                                                                           
               ,myRecvRma                                                                                                           
               ,myValCustPart                                                                                                       
         from   DEX_CUSTOMER_DATA dcd                                                                                               
               ,XXDEX_PARTIES_V rac                                                                                                 
         where  dcd.CUSTOMER_ID     = rac.CUSTOMER_ID                                                                               
         and    dcd.ORG_ID          = myOrgID                                                                                       
         and    rac.CUSTOMER_NUMBER = myECust;                                                                                      
      end if;                                                                                                                       
                                                                                                                                    
      if myAdvRep = 'Y' and myCust != myHCust then                                                                                  
         myValCustPart := 'Y';                                                                                                      
      end if;                                                                                                                       
                                                                                                                                    
      if myCust != myOCust and myRecvRma = 'Y' and myOrd                                                                            
Type = 'R' then                                                                                                                     
         myRetMesg := 'Cannot Change Customer - RMA Control En                                                                      
abled';                                                                                                                             
         raise ABORT_PROC;                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cust - Bill Site';                                                                                                 
                                                                                                                                    
      select decode(DUE_DAYS,0,'Y','N')                                                                                             
      into   myCODFlag                                                                                                              
      from   XXDEX_CUSTOMERS_ALL_V                                                                                                  
      where  CUSTOMER_ID    = myCustID                                                                                              
      and    ORG_ID         = myOrgID                                                                                               
      and    SITE_USE_ID    = myBillSiteID;                                                                                         
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cust - Load Ship';                                                                                                 
                                                                                                                                    
      if myDropShip = 'Y' then                                                                                                      
         select REG                                                                                                                 
               ,SAP                                                                                                                 
               ,TLM                                                                                                                 
               ,CARRIER                                                                                                             
         into   myRegion                                                                                                            
               ,myAgent                                                                                                             
               ,myTLM                                                                                                               
               ,myShipVia                                                                                                           
         from   V_DEX_CUST_SHIP                                                                                                     
         where  CUSTOMER_ID = myCustID                                                                                              
         and    SHIPTO      = myShipto                                                                                              
         and    ORG_ID      = myOrgID;                                                                                              
                                                                                                                                    
      else                                                                                                                          
         select NAME                                                                                                                
               ,ATTN                                                                                                                
               ,STREET1                                                                                                             
               ,STREET2                                                                                                             
               ,CITY                                                                                                                
               ,STATE                                                                                                               
               ,ZIP                                                                                                                 
               ,COUNTRY                                                                                                             
               ,REG                                                                                                                 
               ,SAP                                                                                                                 
               ,TLM                                                                                                                 
               ,CARRIER                                                                                                             
         into   myShipName                                                                                                          
               ,myShipAttn                                                                                                          
               ,myShipSt1                                                                                                           
               ,myShipSt2                                                                                                           
               ,myShipCity                                                                                                          
               ,myShipState                                                                                                         
               ,myShipZip                                                                                                           
               ,myCountry                                                                                                           
               ,myRegion                                                                                                            
               ,myAgent                                                                                                             
               ,myTLM                                                                                                               
               ,myShipVia                                                                                                           
         from   V_DEX_CUST_SHIP                                                                                                     
         where  CUSTOMER_ID = myCustID                                                                                              
         and    SHIPTO      = myShipto                                                                                              
         and    ORG_ID      = myOrgID;                                                                                              
      end if;                                                                                                                       
                                                                                                                                    
      if myOrdType in ('R','H') then                                                                                                
         if myCust in (myHCust,mySCust,myTCust,myRCust) then                                                                        
            myOrdType := 'H';                                                                                                       
         else                                                                                                                       
            myOrdType := 'R';                                                                                                       
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cust - Update';                                                                                                    
                                                                                                                                    
      update DEX_ORDERS set                                                                                                         
      CUST             = myCust                                                                                                     
     ,CUST_EXCHANGE    = nvl(myECust,CUST_EXCHANGE)                                                                                 
     ,CUSTNAME         = myCustName                                                                                                 
     ,SHIPTO           = myShipto                                                                                                   
     ,ORDTYPE          = myOrdType                                                                                                  
     ,COD              = myCODFlag                                                                                                  
     ,CUSTOMER_ID      = myCustID                                                                                                   
     ,BILL_SITE_USE_ID = myBillSiteID                                                                                               
     ,SHIP_SITE_USE_ID = myShipSiteID                                                                                               
     ,PARTIAL_SHP      = myShipPartial                                                                                              
     ,SHIP_NAME        = myShipName                                                                                                 
     ,SHIP_ATTN        = myShipAttn                                                                                                 
     ,SHIP_ST1         = myShipSt1                                                                                                  
     ,SHIP_ST2         = myShipSt2                                                                                                  
     ,SHIP_CITY        = myShipCity                                                                                                 
     ,SHIP_STATE       = myShipState                                                                                                
     ,SHIP_ZIP         = myShipZip                                                                                                  
     ,COUNTRY          = myCountry                                                                                                  
     ,REGION           = myRegion                                                                                                   
     ,AGENT            = myAgent                                                                                                    
     ,TLM              = myTLM                                                                                                      
     ,SHIP_VIA         = myShipVia                                                                                                  
      where ORDERNO = myOrder;                                                                                                      
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cust - Bus Type';                                                                                                  
                                                                                                                                    
      myBusType := F_DEX_BUS_TYPE ( myOrdType,myAdvRep,my                                                                           
OrdSrc );                                                                                                                           
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cust - Inv Org';                                                                                                   
                                                                                                                                    
      myInvOrgID := DEX_ORGANIZATIONS_K.BUS_TYPE ( myOrgID,myBusType );                                                             
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cust - Loop';                                                                                                      
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         log;                                                                                                                       
         mySect := 'Cust - Org/Item ID Check';                                                                                      
                                                                                                                                    
         begin                                                                                                                      
            select ACTIVE_FLAG                                                                                                      
            into   myActive                                                                                                         
            from   V_DEX_PART_DATA                                                                                                  
            where  INVENTORY_ITEM_ID = c1r.INVENTORY_ITEM_ID                                                                        
            and    ORGANIZATION_ID   = myInvOrgID;                                                                                  
                                                                                                                                    
            if myActive != 'Y' then                                                                                                 
               myRetMesg := 'Part Status Not Active' |                                                                              
| chr(10) || 'Line Item: ' || to_char(c1r.ITEM);                                                                                    
               raise ABORT_PROC;                                                                                                    
            end if;                                                                                                                 
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myRetMesg := 'Part Not Enabled in Organization' || chr(10) ||                                                        
 'Line Item: ' || to_char(c1r.ITEM);                                                                                                
               raise ABORT_PROC;                                                                                                    
         end;                                                                                                                       
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Cust - Price';                                                                                                  
                                                                                                                                    
         if myLineFlag = 'Y' then                                                                                                   
            if myOrdType = 'R' then                                                                                                 
               myPriceType := 'RP';                                                                                                 
                                                                                                                                    
            elsif myOrdType = 'S' then                                                                                              
               myPriceType := 'SL';                                                                                                 
                                                                                                                                    
            elsif myOrdType = 'H' then                                                                                              
               if myCust = myHCust then                                                                                             
                  myPriceType := 'XX';                                                                                              
               else                                                                                                                 
                  if myRelabel = 'Y' then                                                                                           
                     myPriceType := 'RL';                                                                                           
                  else                                                                                                              
                     myPriceType := 'RP';                                                                                           
                  end if;                                                                                                           
               end if;                                                                                                              
                                                                                                                                    
            end if;                                                                                                                 
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Cust - Price';                                                                                               
                                                                                                                                    
            myPrice := F_DEX_PRICE ( c1r.INVENTORY_ITEM_ID,myCustID,myPric                                                          
eType );                                                                                                                            
                                                                                                                                    
         else                                                                                                                       
            myPrice := c1r.PRICE;                                                                                                   
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Cust - Update DEX_LINES';                                                                                       
                                                                                                                                    
         update DEX_LINES set                                                                                                       
         PRICE           = myPrice                                                                                                  
        ,INV_MGMT        = myAdvRep                                                                                                 
        ,ORGANIZATION_ID = myInvOrgID                                                                                               
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = c1r.ITEM;                                                                                                  
      end loop;                                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cust - Complete';                                                                                                  
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when ABORT_PROC then                                                                                                          
         myRetCode := 1;                                                                                                            
                                                                                                                                    
         rollback;                                                                                                                  
                                                                                                                                    
      when OTHERS then                                                                                                              
         myRetMesg := SQLERRM || ' (' || mySect || ')';                                                                             
         myRetCode := 2;                                                                                                            
                                                                                                                                    
         rollback;                                                                                                                  
   end CHANGE_CUST;                                                                                                                 
                                                                                                                                    
   /************************************************                                                                                
****************************************************                                                                                
*/                                                                                                                                  
                                                                                                                                    
   procedure CHANGE_CUST (                                                                                                          
                           myOrder     varchar2                                                                                     
                          ,myCust      varchar2                                                                                     
                          ,myLineFlag  varchar2                                                                                     
                          ,myECust     varchar2 default nul                                                                         
l                                                                                                                                   
                         ) is                                                                                                       
      myRetMesg   varchar2(2000);                                                                                                   
      myRetCode   number(1);                                                                                                        
   begin                                                                                                                            
      CHANGE_CUST (                                                                                                                 
                    myRetMesg  => myRetMesg                                                                                         
                   ,myRetCode  => myRetCode                                                                                         
                   ,myOrder    => myOrder                                                                                           
                   ,myCust     => myCust                                                                                            
                   ,myLineFlag => myLineFlag                                                                                        
                   ,myECust    => myECust                                                                                           
                  );                                                                                                                
                                                                                                                                    
      if myRetCode > 0 then                                                                                                         
         RAISE_APPLICATION_ERROR ( -20001,myRetMesg );                                                                              
      end if;                                                                                                                       
   end CHANGE_CUST;                                                                                                                 
                                                                                                                                    
   /************************************************************************                                                        
*****************************/                                                                                                      
                                                                                                                                    
   procedure SERIAL (                                                                                                               
                      myOrder        varchar2                                                                                       
                     ,myItem         number                                                                                         
                     ,mySerialID     number                                                                                         
                     ,myNPrice       number                                                                                         
                     ,myNStatCode    varchar2  default                                                                              
 null                                                                                                                               
                     ,myNSchdDate    date      default null                                                                         
                     ,myNItemID      number    default null                                                                         
                     ,myNCPart       varchar2  default n                                                                            
ull                                                                                                                                 
                     ,myNGrp         varchar2  default null                                                                         
                    ) is                                                                                                            
      myNItem     pls_integer;                                                                                                      
      myUnique    pls_integer;                                                                                                      
      myGrpID     pls_integer;                                                                                                      
      myOrgID     pls_integer;                                                                                                      
      myCustID    pls_integer;                                                                                                      
      myItemID    pls_integer;                                                                                                      
      myCItemID   pls_integer;                                                                                                      
      myQty       pls_integer;                                                                                                      
                                                                                                                                    
      myPickCnt   number;                                                                                                           
      myStatCode  varchar2(1);                                                                                                      
      myOrdType   varchar2(1);                                                                                                      
      myLineType  varchar2(1);                                                                                                      
      myGrp       varchar2(3);                                                                                                      
      myOEM       varchar2(4);                                                                                                      
      myTrack     DEX_SERIALS.TRACK%type;                                                                                           
                                                                                                                                    
      myDesc      DEX_LINES.DESCRIPTION%type;                                                                                       
      myPart      DEX_LINES.PART%type;                                                                                              
      myCPart     DEX_LINES.CUSTPART%type;                                                                                          
      myUOM			LINES.UOM%type;                                                                                                       
                                                                                                                                    
      myPrice     number;                                                                                                           
      myFeeTotal  number;                                                                                                           
                                                                                                                                    
      mySchdDate  date;                                                                                                             
                                                                                                                                    
      myCmt       long;                                                                                                             
                                                                                                                                    
   begin                                                                                                                            
      mySect := 'Serial - Start';                                                                                                   
      log;                                                                                                                          
      mySect := 'Serial - Load Data';                                                                                               
                                                                                                                                    
      select lne.INVENTORY_ITEM_ID                                                                                                  
            ,lne.ORGANIZATION_ID                                                                                                    
            ,lne.CUSTOMER_ITEM_ID                                                                                                   
            ,lne.GROUP_ID                                                                                                           
            ,lne.PART                                                                                                               
            ,lne.CUSTPART                                                                                                           
            ,lne.GRP                                                                                                                
            ,lne.MFG                                                                                                                
            ,lne.DESCRIPTION                                                                                                        
            ,lne.STATCODE                                                                                                           
            ,lne.DATESCH                                                                                                            
            ,lne.COMMENTS                                                                                                           
            ,lne.QTYORG - nvl(lne.QTYSHP,0)                                                                                         
            ,lne.PRICE                                                                                                              
            ,lne.LINE_TYPE                                                                                                          
            ,lne.FEE_TOTAL                                                                                                          
            ,nvl(lne.UOM,XXDEX_UOM_PRIMARY_F ( INVENTORY_ITEM_ID,ORG                                                                
ANIZATION_ID ))                                                                                                                     
            ,ord.ORDTYPE                                                                                                            
            ,ord.CUSTOMER_ID                                                                                                        
      into   myItemID                                                                                                               
            ,myOrgID                                                                                                                
            ,myCItemID                                                                                                              
            ,myGrpID                                                                                                                
            ,myPart                                                                                                                 
            ,myCPart                                                                                                                
            ,myGrp                                                                                                                  
            ,myOEM                                                                                                                  
            ,myDesc                                                                                                                 
            ,myStatCode                                                                                                             
            ,mySchdDate                                                                                                             
            ,myCmt                                                                                                                  
            ,myQty                                                                                                                  
            ,myPrice                                                                                                                
            ,myLineType                                                                                                             
            ,myFeeTotal                                                                                                             
            ,myUOM                                                                                                                  
            ,myOrdType                                                                                                              
            ,myCustID                                                                                                               
      from   DEX_LINES lne                                                                                                          
            ,DEX_ORDERS ord                                                                                                         
      where  lne.ORDERNO = ord.ORDERNO                                                                                              
      and    lne.ORDERNO = myOrder                                                                                                  
      and    lne.ITEM    = myItem;                                                                                                  
                                                                                                                                    
		-- Lot Unit of Measures are to be treated as one Serial.                                                                          
		if myUOM = 'LT' and myQty > 1 then                                                                                                
			myQty := 1;                                                                                                                      
		end if;                                                                                                                           
                                                                                                                                    
      if myNItemID is not null then                                                                                                 
         log;                                                                                                                       
         mySect := 'Serial - Load Item';                                                                                            
                                                                                                                                    
         myItemID := myNItemID;                                                                                                     
                                                                                                                                    
         select ITEM_NUMBER                                                                                                         
               ,GROUP_ID                                                                                                            
               ,GRP                                                                                                                 
               ,OEM                                                                                                                 
               ,substr(DESCRIPTION,1,30)                                                                                            
         into   myPart                                                                                                              
               ,myGrpID                                                                                                             
               ,myGrp                                                                                                               
               ,myOEM                                                                                                               
               ,myDesc                                                                                                              
         from   V_DEX_PART_DATA                                                                                                     
         where  INVENTORY_ITEM_ID = myItemID                                                                                        
         and    ORGANIZATION_ID   = myOrgID;                                                                                        
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serial - Check (StatCode)';                                                                                        
                                                                                                                                    
      if myNStatCode is not null then                                                                                               
         myStatCode := myNStatCode;                                                                                                 
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serial - Check (Schd)';                                                                                            
                                                                                                                                    
      if myNSchdDate is not null then                                                                                               
         mySchdDate := myNSchdDate;                                                                                                 
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serial - Check (Cust Part)';                                                                                       
                                                                                                                                    
      if myNCPart is not null then                                                                                                  
         myCPart := myNCPart;                                                                                                       
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Serial - Cust Part';                                                                                            
                                                                                                                                    
         begin                                                                                                                      
            select CUSTOMER_ITEM_ID                                                                                                 
            into   myCItemID                                                                                                        
            from   MTL_CUSTOMER_ITEMS                                                                                               
            where  CUSTOMER_ID          = myCustID                                                                                  
            and    CUSTOMER_ITEM_NUMBER = myCPart;                                                                                  
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myCItemID := null;                                                                                                   
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      select TRACK                                                                                                                  
      into   myTrack                                                                                                                
      from   DEX_SERIALS                                                                                                            
      where  SERIAL_ID = mySerialID;                                                                                                
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serial - Open Picklist';                                                                                           
                                                                                                                                    
      if nvl(myNgrp,myGrp) != myGrp then                                                                                            
         -- check for open picklists before changing groups                                                                         
         select count(*)                                                                                                            
         into   myPickCnt                                                                                                           
         from   PICKLIST                                                                                                            
         where  PICK_TYPE in ('M','G')                                                                                              
         and    STATUS in ('P','O', 'D', 'R')                                                                                       
         and    SERIAL_ID = mySerialID;                                                                                             
                                                                                                                                    
         if nvl(myPickCnt,0) > 0 then                                                                                               
            -- don't allow                                                                                                          
            RAISE_APPLICATION_ERROR ( -20001,'Open Picklists Exists for Tr                                                          
ack: ' || myTrack || '.  Grp change is not allowed.'                                                                                
 );                                                                                                                                 
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serial - Check (Grp)';                                                                                             
                                                                                                                                    
      if myNGrp is not null then                                                                                                    
         myGrp := myNGrp;                                                                                                           
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Serial - Load Grp';                                                                                             
                                                                                                                                    
         select GROUP_ID                                                                                                            
         into   myGrpID                                                                                                             
         from   DEX_GROUPS                                                                                                          
         where  GRP = myGrp;                                                                                                        
      end if;                                                                                                                       
                                                                                                                                    
      if myNPrice is not null then                                                                                                  
         myPrice := myNPrice;                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      if myLog = 'Y' then                                                                                                           
         K_DEX_LOG.LOG ( mySect,'Order: ' || myOrder || ' Qty: '                                                                    
|| to_char(myQty) || ' SerialID: ' || to_char(mySeri                                                                                
alID),'K_MOVE_ORDER' );                                                                                                             
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serial - Check (Qty)';                                                                                             
                                                                                                                                    
      if myQty = 1 then                                                                                                             
         myNItem := myItem;                                                                                                         
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Serial - Update Line';                                                                                          
                                                                                                                                    
         update DEX_LINES set                                                                                                       
         PRICE             = myPrice                                                                                                
        ,STATCODE          = myStatCode                                                                                             
        ,DATESCH           = mySchdDate                                                                                             
        ,GRP               = myGrp                                                                                                  
        ,GROUP_ID          = myGrpID                                                                                                
        ,CUSTPART          = myCPart                                                                                                
        ,CUSTOMER_ITEM_ID  = myCItemID                                                                                              
        ,INVENTORY_ITEM_ID = myItemID                                                                                               
        ,PART              = myPart                                                                                                 
        ,MFG               = myOEM                                                                                                  
        ,DESCRIPTION       = myDesc                                                                                                 
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = myItem;                                                                                                    
                                                                                                                                    
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'Serial - Find Line';                                                                                            
                                                                                                                                    
         begin                                                                                                                      
            select ITEM                                                                                                             
            into   myNItem                                                                                                          
            from   DEX_LINES                                                                                                        
            where  ORDERNO            = myOrder                                                                                     
            and    INVENTORY_ITEM_ID  = myItemID                                                                                    
            and    PRICE              = myPrice                                                                                     
            and    STATCODE           = myStatCode                                                                                  
            and    DATESCH            = mySchdDate                                                                                  
            and    GRP                = myGrp                                                                                       
            and    nvl(UOM,'x')      != 'LT'                                                                                        
            and    nvl(CUSTPART,'X')  = nvl(myCPart,'X')                                                                            
            and    nvl(LINE_TYPE,'G') = nvl(myLineType,'G')                                                                         
            and    rownum             < 2;                                                                                          
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myNItem := 0;                                                                                                        
         end;                                                                                                                       
                                                                                                                                    
         dbms_output.put_line ( 'NItem: ' || myNItem || ' Order:                                                                    
' || myOrder || ' ItemID: ' || myItemID || ' Price:                                                                                 
' || myPrice || ' StatCode: ' || myStatCode || ' Sch                                                                                
dDate: ' || mySchdDate || ' Grp: ' || myGrp || ' CPa                                                                                
rt: ' || myCPart );                                                                                                                 
                                                                                                                                    
         if myNItem = 0 then                                                                                                        
            log;                                                                                                                    
            mySect := 'Serial - Last Line';                                                                                         
                                                                                                                                    
            select nvl(max(ITEM),0) + 1                                                                                             
            into   myNItem                                                                                                          
            from   DEX_LINES                                                                                                        
            where  ORDERNO = myOrder;                                                                                               
                                                                                                                                    
            if myNItem > 999 then                                                                                                   
               RAISE_APPLICATION_ERROR ( -20001,'Order: '                                                                           
 || myOrder || ' has 999 Line Items' );                                                                                             
            end if;                                                                                                                 
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Serial - Insert DEX_LINES';                                                                                  
                                                                                                                                    
            insert into DEX_LINES                                                                                                   
           (ORDERNO                                                                                                                 
           ,ITEM                                                                                                                    
           ,CUSTITEM                                                                                                                
           ,PART                                                                                                                    
           ,CUSTPART                                                                                                                
           ,DESCRIPTION                                                                                                             
           ,DATESCH                                                                                                                 
           ,STATCODE                                                                                                                
           ,COMMENTS                                                                                                                
           ,SERIALCTL                                                                                                               
           ,PRICE                                                                                                                   
           ,QTYORG                                                                                                                  
           ,GRP                                                                                                                     
           ,HOLD_CODE                                                                                                               
           ,MFG                                                                                                                     
           ,SHIP_EARLY                                                                                                              
           ,INFO                                                                                                                    
           ,INFO2                                                                                                                   
           ,INFO3                                                                                                                   
           ,INFO4                                                                                                                   
           ,INV_MGMT                                                                                                                
           ,DOA                                                                                                                     
           ,FAILANAL                                                                                                                
           ,SWAP                                                                                                                    
           ,RMA_FLAG                                                                                                                
           ,REQUISITION_NUMBER                                                                                                      
           ,LINE_LOCATION_ID                                                                                                        
           ,NOTE_TO_BUYER_ID                                                                                                        
           ,STATUS                                                                                                                  
           ,STORE                                                                                                                   
           ,ORIG_CUST_PART                                                                                                          
           ,INVENTORY_ITEM_ID                                                                                                       
           ,ORGANIZATION_ID                                                                                                         
           ,GROUP_ID                                                                                                                
           ,CUSTOMER_ITEM_ID                                                                                                        
           ,SUBINVENTORY_CODE                                                                                                       
           ,HOLD_ID                                                                                                                 
           ,MAX_PRICE                                                                                                               
           ,COST                                                                                                                    
           ,REFERENCE_ORDER                                                                                                         
           ,REFERENCE_ITEM                                                                                                          
           ,REFERENCE_CUSTITEM                                                                                                      
           ,USE_MAX_PRICE_FLAG                                                                                                      
           ,CALC_FEE_PCT                                                                                                            
           ,BOX_KIT_ITEM_ID                                                                                                         
           ,REPOST_CODE                                                                                                             
           ,REPOST_TIMES                                                                                                            
           ,REPOST_DATE                                                                                                             
           ,UOM                                                                                                                     
           ,LAST_UPDATE_DATE                                                                                                        
           ,LAST_UPDATED_BY                                                                                                         
           ,PARTIAL_SHP                                                                                                             
           ,LINE_TYPE                                                                                                               
           ,FEE_TYPE                                                                                                                
           ,FEE_PRICE                                                                                                               
           ,FEE_BILL                                                                                                                
           ,FEE_BILL_TOTAL                                                                                                          
           ,FEE_TOTAL                                                                                                               
           ,STS_NUMBER                                                                                                              
           ,CORE_FLAG                                                                                                               
           ,CORE_PRICE                                                                                                              
           ,CORE_BUY                                                                                                                
           ,SERIAL_FLAG                                                                                                             
           ,DIVISION                                                                                                                
           ,BUSINESS                                                                                                                
           ,REPAIR_PLANT_ID                                                                                                         
           ,ATTRIBUTE_CATEGORY                                                                                                      
           ,ATTRIBUTE1                                                                                                              
           ,ATTRIBUTE2                                                                                                              
           ,ATTRIBUTE3                                                                                                              
           ,ATTRIBUTE4                                                                                                              
           ,ATTRIBUTE5                                                                                                              
           ,ATTRIBUTE6                                                                                                              
           ,ATTRIBUTE7                                                                                                              
           ,ATTRIBUTE8                                                                                                              
           ,ATTRIBUTE9                                                                                                              
           ,ATTRIBUTE10                                                                                                             
           ,ATTRIBUTE11                                                                                                             
           ,ATTRIBUTE12                                                                                                             
           ,ATTRIBUTE13                                                                                                             
           ,ATTRIBUTE14                                                                                                             
           ,ATTRIBUTE15)                                                                                                            
            select ORDERNO                                                                                                          
                  ,myNItem                                                                                                          
                  ,CUSTITEM                                                                                                         
                  ,myPart                                                                                                           
                  ,myCPart                                                                                                          
                  ,myDesc                                                                                                           
                  ,mySchdDate                                                                                                       
                  ,myStatCode                                                                                                       
                  ,myCmt                                                                                                            
                  ,SERIALCTL                                                                                                        
                  ,myPrice                                                                                                          
                  ,0                                                                                                                
                  ,myGrp                                                                                                            
                  ,HOLD_CODE                                                                                                        
                  ,myOEM                                                                                                            
                  ,SHIP_EARLY                                                                                                       
                  ,INFO                                                                                                             
                  ,INFO2                                                                                                            
                  ,INFO3                                                                                                            
                  ,INFO4                                                                                                            
                  ,INV_MGMT                                                                                                         
                  ,DOA                                                                                                              
                  ,FAILANAL                                                                                                         
                  ,SWAP                                                                                                             
                  ,RMA_FLAG                                                                                                         
                  ,REQUISITION_NUMBER                                                                                               
                  ,LINE_LOCATION_ID                                                                                                 
                  ,NOTE_TO_BUYER_ID                                                                                                 
                  ,STATUS                                                                                                           
                  ,STORE                                                                                                            
                  ,ORIG_CUST_PART                                                                                                   
                  ,myItemID                                                                                                         
                  ,ORGANIZATION_ID                                                                                                  
                  ,myGrpID                                                                                                          
                  ,myCItemID                                                                                                        
                  ,SUBINVENTORY_CODE                                                                                                
                  ,HOLD_ID                                                                                                          
                  ,MAX_PRICE                                                                                                        
                  ,COST                                                                                                             
                  ,REFERENCE_ORDER                                                                                                  
                  ,REFERENCE_ITEM                                                                                                   
                  ,REFERENCE_CUSTITEM                                                                                               
                  ,USE_MAX_PRICE_FLAG                                                                                               
                  ,CALC_FEE_PCT                                                                                                     
                  ,BOX_KIT_ITEM_ID                                                                                                  
                  ,REPOST_CODE                                                                                                      
                  ,REPOST_TIMES                                                                                                     
                  ,REPOST_DATE                                                                                                      
                  ,UOM                                                                                                              
                  ,SYSDATE              -- LAST_UPDATE_DATE                                                                         
                  ,LAST_UPDATED_BY                                                                                                  
                  ,PARTIAL_SHP                                                                                                      
                  ,LINE_TYPE                                                                                                        
                  ,FEE_TYPE                                                                                                         
                  ,FEE_PRICE                                                                                                        
                  ,FEE_BILL                                                                                                         
                  ,FEE_BILL_TOTAL                                                                                                   
                  ,FEE_TOTAL                                                                                                        
                  ,STS_NUMBER                                                                                                       
                  ,CORE_FLAG                                                                                                        
                  ,CORE_PRICE                                                                                                       
                  ,CORE_BUY                                                                                                         
                  ,SERIAL_FLAG                                                                                                      
                  ,DIVISION                                                                                                         
                  ,BUSINESS                                                                                                         
                  ,REPAIR_PLANT_ID                                                                                                  
                  ,ATTRIBUTE_CATEGORY                                                                                               
                  ,ATTRIBUTE1                                                                                                       
                  ,ATTRIBUTE2                                                                                                       
                  ,ATTRIBUTE3                                                                                                       
                  ,ATTRIBUTE4                                                                                                       
                  ,ATTRIBUTE5                                                                                                       
                  ,ATTRIBUTE6                                                                                                       
                  ,ATTRIBUTE7                                                                                                       
                  ,ATTRIBUTE8                                                                                                       
                  ,ATTRIBUTE9                                                                                                       
                  ,ATTRIBUTE10                                                                                                      
                  ,ATTRIBUTE11                                                                                                      
                  ,ATTRIBUTE12                                                                                                      
                  ,ATTRIBUTE13                                                                                                      
                  ,ATTRIBUTE14                                                                                                      
                  ,ATTRIBUTE15                                                                                                      
            from   DEX_LINES                                                                                                        
            where  ORDERNO = myOrder                                                                                                
            and    ITEM    = myItem;                                                                                                
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Serial - Unique';                                                                                               
                                                                                                                                    
         select nvl(max(UNIQUENO),0) + 1                                                                                            
         into   myUnique                                                                                                            
         from   DEX_SERIALS                                                                                                         
         where  ORDERNO = myOrder                                                                                                   
         and    ITEM    = myNItem;                                                                                                  
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Serial - Update Serial';                                                                                        
                                                                                                                                    
         update DEX_SERIALS set                                                                                                     
         ITEM     = myNItem                                                                                                         
        ,UNIQUENO = myUnique                                                                                                        
         where SERIAL_ID = mySerialID;                                                                                              
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Serial - Reset Serial';                                                                                         
/*                                                                                                                                  
         update DEX_SERIALS set                                                                                                     
         UNIQUENO = rownum                                                                                                          
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = myItem;                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
*/                                                                                                                                  
         mySect := 'Serial - Update Qty New';                                                                                       
                                                                                                                                    
         update DEX_LINES set                                                                                                       
         QTYORG =                                                                                                                   
            (select count('*')                                                                                                      
             from   DEX_SERIALS                                                                                                     
             where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                         
             and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM)                                                                           
		  ,QTYSCR =                                                                                                                       
            (select count('*')                                                                                                      
             from   DEX_SERIALS                                                                                                     
             where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                         
             and    DEX_SERIALS.ITEM    = DEX_LINES.                                                                                
ITEM                                                                                                                                
             and    DEX_SERIALS.SCRAP   = 'Y')                                                                                      
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = myNItem;                                                                                                   
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Serial - Update Qty Old';                                                                                       
                                                                                                                                    
         update DEX_LINES set                                                                                                       
         QTYORG =                                                                                                                   
            (select count('*')                                                                                                      
             from   DEX_SERIALS                                                                                                     
             where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                         
             and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM)                                                                           
		  ,QTYSCR =                                                                                                                       
            (select count('*')                                                                                                      
             from   DEX_SERIALS                                                                                                     
             where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                         
                                                                                                                                    
             and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM                                                                            
             and    DEX_SERIALS.SCRAP   = 'Y')                                                                                      
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = myItem;                                                                                                    
                                                                                                                                    
         if myNItem != myItem and myOrdType in ('R','H') then                                                                       
            log;                                                                                                                    
            mySect := 'Serial - Job Open';                                                                                          
                                                                                                                                    
            K_WIP_JOB.JOB_OPEN ( myOrder,myNItem );                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         if myFeeTotal is not null then                                                                                             
            mySect := 'Serial - Fee Total (Old)';                                                                                   
                                                                                                                                    
            update DEX_LINES lne set                                                                                                
            FEE_TOTAL =                                                                                                             
              (select nvl(sum(FEE),0)                                                                                               
               from   DEX_SERIAL_FEES dsf                                                                                           
                     ,SERIALS ser                                                                                                   
               where  ser.SERIAL_ID = dsf.SERIAL_ID                                                                                 
               and    ser.ORDERNO   = lne.ORDERNO                                                                                   
               and    ser.ITEM      = lne.ITEM                                                                                      
               and    dsf.BILL_FLAG is null)                                                                                        
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = myItem;                                                                                                 
                                                                                                                                    
            mySect := 'Serial - Fee Total (New)';                                                                                   
                                                                                                                                    
            update DEX_LINES lne set                                                                                                
            FEE_TOTAL =                                                                                                             
              (select nvl(sum(FEE),0)                                                                                               
               from   DEX_SERIAL_FEES dsf                                                                                           
                     ,SERIALS ser                                                                                                   
               where  ser.SERIAL_ID = dsf.SERIAL_ID                                                                                 
               and    ser.ORDERNO   = lne.ORDERNO                                                                                   
               and    ser.ITEM      = lne.ITEM                                                                                      
               and    dsf.BILL_FLAG is null)                                                                                        
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = myNItem;                                                                                                
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serial - Complete';                                                                                                
      log;                                                                                                                          
   end SERIAL;                                                                                                                      
                                                                                                                                    
   /**********************************************************                                                                      
*******************************************/                                                                                        
                                                                                                                                    
   procedure SERIAL      (                                                                                                          
                           myRetMesg   out  varchar2                                                                                
                          ,myRetCode   out  number                                                                                  
                          ,myOrder     in   varchar2                                                                                
                          ,myItem      in   number                                                                                  
                          ,mySerialID  in   number                                                                                  
                          ,myNPrice    in   number                                                                                  
                          ,myNStatCode in   varchar2  defau                                                                         
lt null                                                                                                                             
                          ,myNSchdDate in   date      default null                                                                  
                          ,myNItemID   in   number    d                                                                             
efault null                                                                                                                         
                          ,myNCPart    in   varchar2  default null                                                                  
                                                                                                                                    
                          ,myNGrp      in   varchar2  default null                                                                  
                         ) is                                                                                                       
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
      SERIAL ( myOrder,myItem,mySerialID,myNPrice,my                                                                                
NStatCode,myNSchdDate,myNItemID,myNCPart,myNGrp );                                                                                  
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
         myRetCode := 2;                                                                                                            
   end SERIAL;                                                                                                                      
                                                                                                                                    
   /*****************************************************                                                                           
************************************************/                                                                                   
                                                                                                                                    
   procedure SERIAL (                                                                                                               
                      myRetMesg   out  varchar2                                                                                     
                     ,myRetCode   out  number                                                                                       
                     ,myTranID    in   number                                                                                       
                     ,myOrder     in   varchar2                                                                                     
                     ,myNOrder    in   varchar2                                                                                     
                     ,myCustPO    in   varchar2                                                                                     
                     ,myRelease   in   varchar2                                                                                     
                     ,myNCust     in   varchar2 default null                                                                        
                    ) is                                                                                                            
      myQty       pls_integer;                                                                                                      
      myCnt       pls_integer := 0;                                                                                                 
      myNItem     pls_integer := 0;                                                                                                 
                                                                                                                                    
      myUserID    number(15) := F_DEX_USER_ID;                                                                                      
                                                                                                                                    
      myOrdType   varchar2(1);                                                                                                      
                                                                                                                                    
      myCmt       long;                                                                                                             
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select *                                                                                                                   
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    ITEM in                                                                                                             
               (select ITEM                                                                                                         
                from   DEX_SERIALS                                                                                                  
                where  ORDERNO = myOrder                                                                                            
                and    TRAN_ID = myTranID)                                                                                          
         order by ITEM;                                                                                                             
                                                                                                                                    
      cursor c2 ( myItem number ) is                                                                                                
         select *                                                                                                                   
         from   DEX_SERIALS                                                                                                         
         where  ORDERNO = myOrder                                                                                                   
         and    ITEM    = myItem                                                                                                    
         and    TRAN_ID = myTranID                                                                                                  
         order by UNIQUENO;                                                                                                         
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
      mySect := 'Serl - Start';                                                                                                     
      log;                                                                                                                          
      mySect := 'Serl - Load Comment';                                                                                              
                                                                                                                                    
      select ORDTYPE                                                                                                                
            ,COMMENTS                                                                                                               
      into   myOrdType                                                                                                              
            ,myCmt                                                                                                                  
      from   DEX_ORDERS                                                                                                             
      where  ORDERNO = myOrder;                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serl - Insert Order';                                                                                              
                                                                                                                                    
      insert into DEX_ORDERS                                                                                                        
     (ORDERNO                                                                                                                       
     ,CUST                                                                                                                          
     ,CUSTNAME                                                                                                                      
     ,CUSTPO                                                                                                                        
     ,RELEASE                                                                                                                       
     ,DATERCV                                                                                                                       
     ,DATEENT                                                                                                                       
     ,DATEINS                                                                                                                       
     ,DATETRN                                                                                                                       
     ,ROAR                                                                                                                          
     ,CUSTBOX                                                                                                                       
     ,UNPACKER                                                                                                                      
     ,RECEIVER                                                                                                                      
     ,INSPECTOR                                                                                                                     
     ,CUSTREP                                                                                                                       
     ,DROP_SHIP                                                                                                                     
     ,SHIP_VIA                                                                                                                      
     ,SHIP_NAME                                                                                                                     
     ,SHIP_ATTN                                                                                                                     
     ,SHIP_ST1                                                                                                                      
     ,SHIP_ST2                                                                                                                      
     ,SHIP_CITY                                                                                                                     
     ,SHIP_STATE                                                                                                                    
     ,SHIP_ZIP                                                                                                                      
     ,COD                                                                                                                           
     ,HOLD_CODE                                                                                                                     
     ,SHIPTO                                                                                                                        
     ,ORDTYPE                                                                                                                       
     ,DISC_FLAG                                                                                                                     
     ,TRANSFER                                                                                                                      
     ,REJECTS                                                                                                                       
     ,REASON                                                                                                                        
     ,PARTIAL_SHP                                                                                                                   
     ,REGION                                                                                                                        
     ,AGENT                                                                                                                         
     ,CLASS                                                                                                                         
     ,TLM                                                                                                                           
     ,COMMENTS                                                                                                                      
     ,RMA                                                                                                                           
     ,PLANT                                                                                                                         
     ,TYPE                                                                                                                          
     ,EXCHANGE                                                                                                                      
     ,DRIVER                                                                                                                        
     ,SHIPTO_LOC_CODE                                                                                                               
     ,SHIPTO_SITE_CODE                                                                                                              
     ,CLOSED_FLAG                                                                                                                   
     ,FREIGHT_QUOTE                                                                                                                 
     ,CREDIT_CARD_TYPE                                                                                                              
     ,CREDIT_CARD_NAME                                                                                                              
     ,CREDIT_CARD_ACCT                                                                                                              
     ,CREDIT_CARD_EXP                                                                                                               
     ,SATURDAY_DELIVERY                                                                                                             
     ,LEAD_ID                                                                                                                       
     ,CUST_EXCHANGE                                                                                                                 
     ,COUNTRY                                                                                                                       
     ,ORDER_SOURCE                                                                                                                  
     ,CREDIT_CARD_APPROVAL                                                                                                          
     ,ATTRIBUTE_CATEGORY                                                                                                            
     ,ATTRIBUTE1                                                                                                                    
     ,ATTRIBUTE2                                                                                                                    
     ,ATTRIBUTE3                                                                                                                    
     ,ATTRIBUTE4                                                                                                                    
     ,ATTRIBUTE5                                                                                                                    
     ,ATTRIBUTE6                                                                                                                    
     ,ATTRIBUTE7                                                                                                                    
     ,ATTRIBUTE8                                                                                                                    
     ,ATTRIBUTE9                                                                                                                    
     ,ATTRIBUTE10                                                                                                                   
     ,ATTRIBUTE11                                                                                                                   
     ,ATTRIBUTE12                                                                                                                   
     ,ATTRIBUTE13                                                                                                                   
     ,ATTRIBUTE14                                                                                                                   
     ,ATTRIBUTE15                                                                                                                   
     ,ATTRIBUTE16                                                                                                                   
     ,ATTRIBUTE17                                                                                                                   
     ,ATTRIBUTE18                                                                                                                   
     ,ATTRIBUTE19                                                                                                                   
     ,ATTRIBUTE20                                                                                                                   
     ,ATTRIBUTE21                                                                                                                   
     ,ATTRIBUTE22                                                                                                                   
     ,ATTRIBUTE23                                                                                                                   
     ,ATTRIBUTE24                                                                                                                   
     ,ATTRIBUTE25                                                                                                                   
     ,ATTRIBUTE26                                                                                                                   
     ,ATTRIBUTE27                                                                                                                   
     ,ATTRIBUTE28                                                                                                                   
     ,ATTRIBUTE29                                                                                                                   
     ,ATTRIBUTE30                                                                                                                   
     ,ATTRIBUTE31                                                                                                                   
     ,ATTRIBUTE32                                                                                                                   
     ,ATTRIBUTE33                                                                                                                   
     ,ATTRIBUTE34                                                                                                                   
     ,ATTRIBUTE35                                                                                                                   
     ,ATTRIBUTE36                                                                                                                   
     ,ATTRIBUTE37                                                                                                                   
     ,ATTRIBUTE38                                                                                                                   
     ,ATTRIBUTE39                                                                                                                   
     ,ATTRIBUTE40                                                                                                                   
     ,ORG_ID                                                                                                                        
     ,PLANT_ID                                                                                                                      
     ,CUSTOMER_ID                                                                                                                   
     ,BILL_SITE_USE_ID                                                                                                              
     ,SHIP_SITE_USE_ID                                                                                                              
     ,OUTSIDE_SALESREP_ID                                                                                                           
     ,INSIDE_SALESREP_ID                                                                                                            
     ,CREDIT_CARD_METHOD                                                                                                            
     ,EXCHANGE_RATE_TYPE                                                                                                            
     ,EXCHANGE_RATE_DATE                                                                                                            
     ,EXCHANGE_RATE                                                                                                                 
     ,FRT_THIRD_PARTY_NAME                                                                                                          
     ,FRT_THIRD_PARTY_CONTACT                                                                                                       
     ,FRT_THIRD_PARTY_ADDRESS1                                                                                                      
     ,FRT_THIRD_PARTY_ADDRESS2                                                                                                      
     ,FRT_THIRD_PARTY_CITY                                                                                                          
     ,FRT_THIRD_PARTY_CODE                                                                                                          
     ,FRT_THIRD_PARTY_STATE                                                                                                         
     ,FRT_THIRD_PARTY_POSTALCODE                                                                                                    
     ,FRT_THIRD_PARTY_PHONE                                                                                                         
     ,FRT_THIRD_PARTY_ACCT                                                                                                          
     ,FRT_THIRD_PARTY_FLAG                                                                                                          
     ,EMAIL                                                                                                                         
     ,PGM_MGR_ID                                                                                                                    
     ,PAYMENT_COMMENTS                                                                                                              
     )                                                                                                                              
      select myNOrder                                                                                                               
            ,nvl(myNCust,CUST)            -- Use New Cust to Avoid                                                                  
 Key Violation - Other fields will be updated later                                                                                 
            ,CUSTNAME                                                                                                               
            ,myCustPO                                                                                                               
            ,myRelease                                                                                                              
            ,DATERCV                                                                                                                
            ,DATEENT                                                                                                                
            ,DATEINS                                                                                                                
            ,DATETRN                                                                                                                
            ,ROAR                                                                                                                   
            ,CUSTBOX                                                                                                                
            ,UNPACKER                                                                                                               
            ,RECEIVER                                                                                                               
            ,INSPECTOR                                                                                                              
            ,CUSTREP                                                                                                                
            ,DROP_SHIP                                                                                                              
            ,SHIP_VIA                                                                                                               
            ,SHIP_NAME                                                                                                              
            ,SHIP_ATTN                                                                                                              
            ,SHIP_ST1                                                                                                               
            ,SHIP_ST2                                                                                                               
            ,SHIP_CITY                                                                                                              
            ,SHIP_STATE                                                                                                             
            ,SHIP_ZIP                                                                                                               
            ,COD                                                                                                                    
            ,HOLD_CODE                                                                                                              
            ,SHIPTO                                                                                                                 
            ,ORDTYPE                                                                                                                
            ,DISC_FLAG                                                                                                              
            ,TRANSFER                                                                                                               
            ,REJECTS                                                                                                                
            ,REASON                                                                                                                 
            ,PARTIAL_SHP                                                                                                            
            ,REGION                                                                                                                 
            ,AGENT                                                                                                                  
            ,CLASS                                                                                                                  
            ,TLM                                                                                                                    
            ,myCmt                                                                                                                  
            ,RMA                                                                                                                    
            ,PLANT                                                                                                                  
            ,TYPE                                                                                                                   
            ,EXCHANGE                                                                                                               
            ,DRIVER                                                                                                                 
            ,SHIPTO_LOC_CODE                                                                                                        
            ,SHIPTO_SITE_CODE                                                                                                       
            ,CLOSED_FLAG                                                                                                            
            ,FREIGHT_QUOTE                                                                                                          
            ,CREDIT_CARD_TYPE                                                                                                       
            ,CREDIT_CARD_NAME                                                                                                       
            ,CREDIT_CARD_ACCT                                                                                                       
            ,CREDIT_CARD_EXP                                                                                                        
            ,SATURDAY_DELIVERY                                                                                                      
            ,LEAD_ID                                                                                                                
            ,CUST_EXCHANGE                                                                                                          
            ,COUNTRY                                                                                                                
            ,ORDER_SOURCE                                                                                                           
            ,CREDIT_CARD_APPROVAL                                                                                                   
            ,ATTRIBUTE_CATEGORY                                                                                                     
            ,ATTRIBUTE1                                                                                                             
            ,ATTRIBUTE2                                                                                                             
            ,ATTRIBUTE3                                                                                                             
            ,ATTRIBUTE4                                                                                                             
            ,ATTRIBUTE5                                                                                                             
            ,ATTRIBUTE6                                                                                                             
            ,ATTRIBUTE7                                                                                                             
            ,ATTRIBUTE8                                                                                                             
            ,ATTRIBUTE9                                                                                                             
            ,ATTRIBUTE10                                                                                                            
            ,ATTRIBUTE11                                                                                                            
            ,ATTRIBUTE12                                                                                                            
            ,ATTRIBUTE13                                                                                                            
            ,ATTRIBUTE14                                                                                                            
            ,ATTRIBUTE15                                                                                                            
            ,ATTRIBUTE16                                                                                                            
            ,ATTRIBUTE17                                                                                                            
            ,ATTRIBUTE18                                                                                                            
            ,ATTRIBUTE19                                                                                                            
            ,ATTRIBUTE20                                                                                                            
            ,ATTRIBUTE21                                                                                                            
            ,ATTRIBUTE22                                                                                                            
            ,ATTRIBUTE23                                                                                                            
            ,ATTRIBUTE24                                                                                                            
            ,ATTRIBUTE25                                                                                                            
            ,ATTRIBUTE26                                                                                                            
            ,ATTRIBUTE27                                                                                                            
            ,ATTRIBUTE28                                                                                                            
            ,ATTRIBUTE29                                                                                                            
            ,ATTRIBUTE30                                                                                                            
            ,ATTRIBUTE31                                                                                                            
            ,ATTRIBUTE32                                                                                                            
            ,ATTRIBUTE33                                                                                                            
            ,ATTRIBUTE34                                                                                                            
            ,ATTRIBUTE35                                                                                                            
            ,ATTRIBUTE36                                                                                                            
            ,ATTRIBUTE37                                                                                                            
            ,ATTRIBUTE38                                                                                                            
            ,ATTRIBUTE39                                                                                                            
            ,ATTRIBUTE40                                                                                                            
            ,ORG_ID                                                                                                                 
            ,PLANT_ID                                                                                                               
            ,CUSTOMER_ID                                                                                                            
            ,BILL_SITE_USE_ID                                                                                                       
            ,SHIP_SITE_USE_ID                                                                                                       
            ,OUTSIDE_SALESREP_ID                                                                                                    
            ,INSIDE_SALESREP_ID                                                                                                     
            ,CREDIT_CARD_METHOD                                                                                                     
            ,EXCHANGE_RATE_TYPE                                                                                                     
            ,EXCHANGE_RATE_DATE                                                                                                     
            ,EXCHANGE_RATE                                                                                                          
            ,FRT_THIRD_PARTY_NAME                                                                                                   
            ,FRT_THIRD_PARTY_CONTACT                                                                                                
            ,FRT_THIRD_PARTY_ADDRESS1                                                                                               
            ,FRT_THIRD_PARTY_ADDRESS2                                                                                               
            ,FRT_THIRD_PARTY_CITY                                                                                                   
            ,FRT_THIRD_PARTY_CODE                                                                                                   
            ,FRT_THIRD_PARTY_STATE                                                                                                  
            ,FRT_THIRD_PARTY_POSTALCODE                                                                                             
            ,FRT_THIRD_PARTY_PHONE                                                                                                  
            ,FRT_THIRD_PARTY_ACCT                                                                                                   
            ,FRT_THIRD_PARTY_FLAG                                                                                                   
            ,EMAIL                                                                                                                  
            ,PGM_MGR_ID                                                                                                             
            ,PAYMENT_COMMENTS                                                                                                       
      from   DEX_ORDERS                                                                                                             
      where  ORDERNO = myOrder;                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serl - Loop';                                                                                                      
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         myNItem := myNItem + 1;                                                                                                    
                                                                                                                                    
         if c1r.QTYCUT is not null then                                                                                             
            myQty := c1r.QTYCUT;                                                                                                    
                                                                                                                                    
         else                                                                                                                       
            log;                                                                                                                    
            mySect := 'Serl - Qty';                                                                                                 
                                                                                                                                    
            select nvl(count('*'),0)                                                                                                
            into   myQty                                                                                                            
            from   DEX_SERIALS                                                                                                      
            where  ORDERNO = myOrder                                                                                                
            and    ITEM    = c1r.ITEM                                                                                               
            and    TRAN_ID = myTranID;                                                                                              
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Serl - Insert DEX_LINES';                                                                                       
                                                                                                                                    
         insert into DEX_LINES                                                                                                      
        (ORDERNO                                                                                                                    
        ,ITEM                                                                                                                       
        ,CUSTITEM                                                                                                                   
        ,PART                                                                                                                       
        ,CUSTPART                                                                                                                   
        ,DESCRIPTION                                                                                                                
        ,DATESCH                                                                                                                    
        ,STATCODE                                                                                                                   
        ,COMMENTS                                                                                                                   
        ,SERIALCTL                                                                                                                  
        ,PRICE                                                                                                                      
        ,QTYORG                                                                                                                     
        ,GRP                                                                                                                        
        ,HOLD_CODE                                                                                                                  
        ,MFG                                                                                                                        
        ,SHIP_EARLY                                                                                                                 
        ,INFO                                                                                                                       
        ,INFO2                                                                                                                      
        ,INFO3                                                                                                                      
        ,INFO4                                                                                                                      
        ,INV_MGMT                                                                                                                   
        ,DOA                                                                                                                        
        ,FAILANAL                                                                                                                   
        ,SWAP                                                                                                                       
        ,RMA_FLAG                                                                                                                   
        ,REQUISITION_NUMBER                                                                                                         
        ,LINE_LOCATION_ID                                                                                                           
        ,NOTE_TO_BUYER_ID                                                                                                           
        ,STATUS                                                                                                                     
        ,STORE                                                                                                                      
        ,ORIG_CUST_PART                                                                                                             
        ,INVENTORY_ITEM_ID                                                                                                          
        ,ORGANIZATION_ID                                                                                                            
        ,GROUP_ID                                                                                                                   
        ,CUSTOMER_ITEM_ID                                                                                                           
        ,SUBINVENTORY_CODE                                                                                                          
        ,ATTRIBUTE_CATEGORY                                                                                                         
        ,ATTRIBUTE1                                                                                                                 
        ,ATTRIBUTE2                                                                                                                 
        ,ATTRIBUTE3                                                                                                                 
        ,ATTRIBUTE4                                                                                                                 
        ,ATTRIBUTE5                                                                                                                 
        ,ATTRIBUTE6                                                                                                                 
        ,ATTRIBUTE7                                                                                                                 
        ,ATTRIBUTE8                                                                                                                 
        ,ATTRIBUTE9                                                                                                                 
        ,ATTRIBUTE10                                                                                                                
        ,ATTRIBUTE11                                                                                                                
        ,ATTRIBUTE12                                                                                                                
        ,ATTRIBUTE13                                                                                                                
        ,ATTRIBUTE14                                                                                                                
        ,ATTRIBUTE15                                                                                                                
        ,HOLD_ID                                                                                                                    
        ,REFERENCE_ORDER                                                                                                            
        ,REFERENCE_ITEM                                                                                                             
        ,REFERENCE_CUSTITEM                                                                                                         
        ,LAST_UPDATE_DATE                                                                                                           
        ,LAST_UPDATED_BY                                                                                                            
        ,CALC_FEE_PCT                                                                                                               
        ,BOX_KIT_ITEM_ID                                                                                                            
        ,UOM                                                                                                                        
        ,COMMENTS_LSM                                                                                                               
        ,RETURN_RMA_FLAG                                                                                                            
        ,ZERO_PRICE_ALLOWED_FLAG                                                                                                    
        ,LINE_TYPE                                                                                                                  
        ,PARTIAL_SHP                                                                                                                
        ,FEE_TOTAL                                                                                                                  
        ,QTYBAD                                                                                                                     
        ,FTP                                                                                                                        
        ,FTP_DATE                                                                                                                   
        ,CORE_FLAG                                                                                                                  
        ,CORE_PRICE                                                                                                                 
        ,CORE_BUY                                                                                                                   
        ,COST                                                                                                                       
        ,FEE_TYPE                                                                                                                   
        ,STS_NUMBER                                                                                                                 
        ,SERIAL_FLAG                                                                                                                
        ,DIVISION                                                                                                                   
        ,BUSINESS                                                                                                                   
        ,REPAIR_PLANT_ID                                                                                                            
        ) values (                                                                                                                  
         myNOrder                                -- ORDERNO                                                                         
        ,myNItem                                 -- ITEM                                                                            
        ,c1r.CUSTITEM                                                                                                               
        ,c1r.PART                                                                                                                   
        ,c1r.CUSTPART                                                                                                               
        ,c1r.DESCRIPTION                                                                                                            
        ,c1r.DATESCH                                                                                                                
        ,c1r.STATCODE                                                                                                               
        ,c1r.COMMENTS                                                                                                               
        ,c1r.SERIALCTL                                                                                                              
        ,c1r.PRICE                                                                                                                  
        ,myQty                                                                                                                      
        ,c1r.GRP                                                                                                                    
        ,c1r.HOLD_CODE                                                                                                              
        ,c1r.MFG                                                                                                                    
        ,c1r.SHIP_EARLY                                                                                                             
        ,c1r.INFO                                                                                                                   
        ,c1r.INFO2                                                                                                                  
        ,c1r.INFO3                                                                                                                  
        ,c1r.INFO4                                                                                                                  
        ,c1r.INV_MGMT                                                                                                               
        ,c1r.DOA                                                                                                                    
        ,c1r.FAILANAL                                                                                                               
        ,c1r.SWAP                                                                                                                   
        ,c1r.RMA_FLAG                                                                                                               
        ,c1r.REQUISITION_NUMBER                                                                                                     
        ,c1r.LINE_LOCATION_ID                                                                                                       
        ,c1r.NOTE_TO_BUYER_ID                                                                                                       
        ,c1r.STATUS                                                                                                                 
        ,c1r.STORE                                                                                                                  
        ,c1r.ORIG_CUST_PART                                                                                                         
        ,c1r.INVENTORY_ITEM_ID                                                                                                      
        ,c1r.ORGANIZATION_ID                                                                                                        
        ,c1r.GROUP_ID                                                                                                               
        ,c1r.CUSTOMER_ITEM_ID                                                                                                       
        ,c1r.SUBINVENTORY_CODE                                                                                                      
        ,c1r.ATTRIBUTE_CATEGORY                                                                                                     
        ,c1r.ATTRIBUTE1                                                                                                             
        ,c1r.ATTRIBUTE2                                                                                                             
        ,c1r.ATTRIBUTE3                                                                                                             
        ,c1r.ATTRIBUTE4                                                                                                             
        ,c1r.ATTRIBUTE5                                                                                                             
        ,c1r.ATTRIBUTE6                                                                                                             
        ,c1r.ATTRIBUTE7                                                                                                             
        ,c1r.ATTRIBUTE8                                                                                                             
        ,c1r.ATTRIBUTE9                                                                                                             
        ,c1r.ATTRIBUTE10                                                                                                            
        ,c1r.ATTRIBUTE11                                                                                                            
        ,c1r.ATTRIBUTE12                                                                                                            
        ,c1r.ATTRIBUTE13                                                                                                            
        ,c1r.ATTRIBUTE14                                                                                                            
        ,c1r.ATTRIBUTE15                                                                                                            
        ,c1r.HOLD_ID                                                                                                                
        ,c1r.REFERENCE_ORDER                                                                                                        
        ,c1r.REFERENCE_ITEM                                                                                                         
        ,c1r.REFERENCE_CUSTITEM                                                                                                     
        ,SYSDATE                              -- LAST_UPDATE_D                                                                      
ATE                                                                                                                                 
        ,myUserID                             -- LAST_UPDATED_BY                                                                    
        ,c1r.CALC_FEE_PCT                                                                                                           
        ,c1r.BOX_KIT_ITEM_ID                                                                                                        
        ,c1r.UOM                                                                                                                    
        ,c1r.COMMENTS_LSM                                                                                                           
        ,c1r.RETURN_RMA_FLAG                                                                                                        
        ,c1r.ZERO_PRICE_ALLOWED_FLAG                                                                                                
        ,c1r.LINE_TYPE                                                                                                              
        ,c1r.PARTIAL_SHP                                                                                                            
        ,c1r.FEE_TOTAL                                                                                                              
        ,c1r.QTYBAD                                                                                                                 
        ,c1r.FTP                                                                                                                    
        ,c1r.FTP_DATE                                                                                                               
        ,c1r.CORE_FLAG                                                                                                              
        ,c1r.CORE_PRICE                                                                                                             
        ,c1r.CORE_BUY                                                                                                               
        ,c1r.COST                                                                                                                   
        ,c1r.FEE_TYPE                                                                                                               
        ,c1r.STS_NUMBER                                                                                                             
        ,c1r.SERIAL_FLAG                                                                                                            
        ,c1r.DIVISION                                                                                                               
        ,c1r.BUSINESS                                                                                                               
        ,c1r.REPAIR_PLANT_ID                                                                                                        
        );                                                                                                                          
                                                                                                                                    
         myCnt := 0;                                                                                                                
                                                                                                                                    
         for c2r in c2 ( c1r.ITEM ) loop                                                                                            
            myCnt := myCnt + 1;                                                                                                     
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Serl - Move DEX_SERIALS (' || myNOrder                                                                       
 || '-' || to_char(myNItem) || '-' || to_char(myCnt)                                                                                
 || ')';                                                                                                                            
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            ORDERNO       = myNOrder                                                                                                
           ,ITEM          = myNItem                                                                                                 
           ,UNIQUENO      = myCnt                                                                                                   
            where SERIAL_ID = c2r.SERIAL_ID;                                                                                        
                                                                                                                                    
            log;                                                                                                                    
/*                                                                                                                                  
            mySect := 'Serl - Reset DEX_SERIALS';                                                                                   
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            UNIQUENO      = rownum                                                                                                  
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = c1r.ITEM;                                                                                               
                                                                                                                                    
            log;                                                                                                                    
*/                                                                                                                                  
            mySect := 'Serl - Update Qty New';                                                                                      
                                                                                                                                    
            update DEX_LINES set                                                                                                    
            QTYORG =                                                                                                                
               (select count('*')                                                                                                   
                from   DEX_SERIALS                                                                                                  
                where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                      
                and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM)                                                                        
                                                                                                                                    
		  	  ,QTYSCR =                                                                                                                    
            	(select count('*')                                                                                                     
             	 from   DEX_SERIALS                                                                                                   
             	 where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                       
             	 and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM                                                                          
             	 and    DEX_SERIALS.SCRAP   = 'Y')                                                                                    
            where ORDERNO = myNOrder                                                                                                
            and   ITEM    = myNItem;                                                                                                
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Serl - Update Qty Old';                                                                                      
                                                                                                                                    
            update DEX_LINES set                                                                                                    
            QTYORG =                                                                                                                
               (select count('*')                                                                                                   
                from   DEX_SERIALS                                                                                                  
                where  DEX_SERIALS.ORDERNO = DEX_LINES.                                                                             
ORDERNO                                                                                                                             
                and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM)                                                                        
		  	  ,QTYSCR =                                                                                                                    
            	(select count('*')                                                                                                     
             	 from   DEX_SERIALS                                                                                                   
             	 where  DEX_SERIALS.ORDERNO = DEX_LINES.OR                                                                            
DERNO                                                                                                                               
             	 and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM                                                                          
             	 and    DEX_SERIALS.SCRAP   = 'Y')                                                                                    
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = c1r.ITEM;                                                                                               
         end loop;                                                                                                                  
                                                                                                                                    
         if myCnt = 0 then                                                                                                          
            myRetCode := 1;                                                                                                         
            myRetMesg := 'No Serial Records Updated';                                                                               
                                                                                                                                    
            exit;                                                                                                                   
         end if;                                                                                                                    
                                                                                                                                    
         if c1r.FEE_TOTAL is not null then                                                                                          
            mySect := 'Serial - Fee Total (Old)';                                                                                   
                                                                                                                                    
            update DEX_LINES lne set                                                                                                
            FEE_TOTAL =                                                                                                             
              (select nvl(sum(FEE),0)                                                                                               
               from   DEX_SERIAL_FEES dsf                                                                                           
                     ,SERIALS ser                                                                                                   
               where  ser.SERIAL_ID = dsf.SERIAL_ID                                                                                 
               and    ser.ORDERNO   = lne.ORDERNO                                                                                   
               and    ser.ITEM      = lne.ITEM                                                                                      
               and    dsf.BILL_FLAG is null)                                                                                        
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = c1r.ITEM;                                                                                               
                                                                                                                                    
            mySect := 'Serial - Fee Total (New)';                                                                                   
                                                                                                                                    
            update DEX_LINES lne set                                                                                                
            FEE_TOTAL =                                                                                                             
              (select nvl(sum(FEE),0)                                                                                               
               from   DEX_SERIAL_FEES dsf                                                                                           
                     ,SERIALS ser                                                                                                   
               where  ser.SERIAL_ID = dsf.SERIAL_ID                                                                                 
               and    ser.ORDERNO   = lne.ORDERNO                                                                                   
               and    ser.ITEM      = lne.ITEM                                                                                      
               and    dsf.BILL_FLAG is null)                                                                                        
            where ORDERNO = myNOrder                                                                                                
            and   ITEM    = myNItem;                                                                                                
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      if myCnt = 0 then                                                                                                             
         rollback;                                                                                                                  
         return;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      if myNCust is not null then                                                                                                   
         CHANGE_CUST (                                                                                                              
                       myNOrder                                                                                                     
                      ,myNCust                                                                                                      
                      ,'Y'                                                                                                          
                     );                                                                                                             
      end if;                                                                                                                       
                                                                                                                                    
      if myOrdType in ('R','H','M') then                                                                                            
         log;                                                                                                                       
         mySect := 'Serl - Job Open';                                                                                               
                                                                                                                                    
         K_WIP_JOB.JOB_OPEN ( myNOrder );                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Serl - Complete';                                                                                                  
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         rollback;                                                                                                                  
         myRetCode := 2;                                                                                                            
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end SERIAL;                                                                                                                      
                                                                                                                                    
   /********************************************************************                                                            
*********************************/                                                                                                  
                                                                                                                                    
   procedure PROCESS (                                                                                                              
                       myOrder     varchar2                                                                                         
                      ,myNOrder    varchar2                                                                                         
                      ,myTranID    number                                                                                           
                      ,myBuyFlag   varchar2 default 'N'                                                                             
                     ) is                                                                                                           
      myNItem     number(5) := 0;                                                                                                   
                                                                                                                                    
      myUserID    number(15) := F_DEX_USER_ID;                                                                                      
                                                                                                                                    
      myOrdType   varchar2(1);                                                                                                      
                                                                                                                                    
      myRelease   DEX_ORDERS.RELEASE%type;                                                                                          
                                                                                                                                    
      myCmt       long;                                                                                                             
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select *                                                                                                                   
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    QTYCUT  > 0;                                                                                                        
                                                                                                                                    
   begin                                                                                                                            
      mySect := 'Proc - Start';                                                                                                     
      log;                                                                                                                          
      mySect := 'Proc - Load Comment';                                                                                              
                                                                                                                                    
      select ORDTYPE                                                                                                                
            ,RELEASE                                                                                                                
            ,COMMENTS                                                                                                               
      into   myOrdType                                                                                                              
            ,myRelease                                                                                                              
            ,myCmt                                                                                                                  
      from   DEX_ORDERS                                                                                                             
      where  ORDERNO = myOrder;                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Proc - Loop';                                                                                                      
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         myNItem := myNItem + 1;                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Proc - Insert DEX_LINES';                                                                                       
                                                                                                                                    
         insert into DEX_LINES                                                                                                      
        (ORDERNO                                                                                                                    
        ,ITEM                                                                                                                       
        ,CUSTITEM                                                                                                                   
        ,PART                                                                                                                       
        ,CUSTPART                                                                                                                   
        ,DESCRIPTION                                                                                                                
        ,DATESCH                                                                                                                    
        ,STATCODE                                                                                                                   
        ,COMMENTS                                                                                                                   
        ,SERIALCTL                                                                                                                  
        ,PRICE                                                                                                                      
        ,QTYORG                                                                                                                     
        ,GRP                                                                                                                        
        ,HOLD_CODE                                                                                                                  
        ,MFG                                                                                                                        
        ,SHIP_EARLY                                                                                                                 
        ,INFO                                                                                                                       
        ,INFO2                                                                                                                      
        ,INFO3                                                                                                                      
        ,INFO4                                                                                                                      
        ,INV_MGMT                                                                                                                   
        ,DOA                                                                                                                        
        ,FAILANAL                                                                                                                   
        ,SWAP                                                                                                                       
        ,RMA_FLAG                                                                                                                   
        ,REQUISITION_NUMBER                                                                                                         
        ,LINE_LOCATION_ID                                                                                                           
        ,NOTE_TO_BUYER_ID                                                                                                           
        ,STATUS                                                                                                                     
        ,STORE                                                                                                                      
        ,ORIG_CUST_PART                                                                                                             
        ,INVENTORY_ITEM_ID                                                                                                          
        ,ORGANIZATION_ID                                                                                                            
        ,GROUP_ID                                                                                                                   
        ,CUSTOMER_ITEM_ID                                                                                                           
        ,SUBINVENTORY_CODE                                                                                                          
        ,ATTRIBUTE_CATEGORY                                                                                                         
        ,ATTRIBUTE1                                                                                                                 
        ,ATTRIBUTE2                                                                                                                 
        ,ATTRIBUTE3                                                                                                                 
        ,ATTRIBUTE4                                                                                                                 
        ,ATTRIBUTE5                                                                                                                 
        ,ATTRIBUTE6                                                                                                                 
        ,ATTRIBUTE7                                                                                                                 
        ,ATTRIBUTE8                                                                                                                 
        ,ATTRIBUTE9                                                                                                                 
        ,ATTRIBUTE10                                                                                                                
        ,ATTRIBUTE11                                                                                                                
        ,ATTRIBUTE12                                                                                                                
        ,ATTRIBUTE13                                                                                                                
        ,ATTRIBUTE14                                                                                                                
        ,ATTRIBUTE15                                                                                                                
        ,HOLD_ID                                                                                                                    
        ,REFERENCE_ORDER                                                                                                            
        ,REFERENCE_ITEM                                                                                                             
        ,REFERENCE_CUSTITEM                                                                                                         
        ,LAST_UPDATE_DATE                                                                                                           
        ,LAST_UPDATED_BY                                                                                                            
        ,CALC_FEE_PCT                                                                                                               
        ,BOX_KIT_ITEM_ID                                                                                                            
        ,UOM                                                                                                                        
        ,COMMENTS_LSM                                                                                                               
        ,RETURN_RMA_FLAG                                                                                                            
        ,ZERO_PRICE_ALLOWED_FLAG                                                                                                    
        ,LINE_TYPE                                                                                                                  
        ,PARTIAL_SHP                                                                                                                
        ,FEE_TOTAL                                                                                                                  
        ,QTYBAD                                                                                                                     
        ,FTP                                                                                                                        
        ,FTP_DATE                                                                                                                   
        ,CORE_FLAG                                                                                                                  
        ,CORE_PRICE                                                                                                                 
        ,CORE_BUY                                                                                                                   
        ,COST                                                                                                                       
        ,FEE_TYPE                                                                                                                   
        ,STS_NUMBER                                                                                                                 
        ,SERIAL_FLAG                                                                                                                
        ,DIVISION                                                                                                                   
        ,BUSINESS                                                                                                                   
        ,REPAIR_PLANT_ID                                                                                                            
        ) values (                                                                                                                  
         myNOrder                                -- ORDERNO                                                                         
        ,myNItem                                 -- ITEM                                                                            
        ,c1r.CUSTITEM                                                                                                               
        ,c1r.PART                                                                                                                   
        ,c1r.CUSTPART                                                                                                               
        ,c1r.DESCRIPTION                                                                                                            
        ,c1r.DATESCH                                                                                                                
        ,c1r.STATCODE                                                                                                               
        ,c1r.COMMENTS                                                                                                               
        ,c1r.SERIALCTL                                                                                                              
        ,c1r.PRICE                                                                                                                  
        ,c1r.QTYCUT                                                                                                                 
        ,c1r.GRP                                                                                                                    
        ,c1r.HOLD_CODE                                                                                                              
        ,c1r.MFG                                                                                                                    
        ,c1r.SHIP_EARLY                                                                                                             
        ,c1r.INFO                                                                                                                   
        ,c1r.INFO2                                                                                                                  
        ,c1r.INFO3                                                                                                                  
        ,c1r.INFO4                                                                                                                  
        ,c1r.INV_MGMT                                                                                                               
        ,c1r.DOA                                                                                                                    
        ,c1r.FAILANAL                                                                                                               
        ,c1r.SWAP                                                                                                                   
        ,c1r.RMA_FLAG                                                                                                               
        ,c1r.REQUISITION_NUMBER                                                                                                     
        ,c1r.LINE_LOCATION_ID                                                                                                       
        ,c1r.NOTE_TO_BUYER_ID                                                                                                       
        ,c1r.STATUS                                                                                                                 
        ,c1r.STORE                                                                                                                  
        ,c1r.ORIG_CUST_PART                                                                                                         
        ,c1r.INVENTORY_ITEM_ID                                                                                                      
        ,c1r.ORGANIZATION_ID                                                                                                        
        ,c1r.GROUP_ID                                                                                                               
        ,c1r.CUSTOMER_ITEM_ID                                                                                                       
        ,c1r.SUBINVENTORY_CODE                                                                                                      
        ,c1r.ATTRIBUTE_CATEGORY                                                                                                     
        ,c1r.ATTRIBUTE1                                                                                                             
        ,c1r.ATTRIBUTE2                                                                                                             
        ,c1r.ATTRIBUTE3                                                                                                             
        ,c1r.ATTRIBUTE4                                                                                                             
        ,c1r.ATTRIBUTE5                                                                                                             
        ,c1r.ATTRIBUTE6                                                                                                             
        ,c1r.ATTRIBUTE7                                                                                                             
        ,c1r.ATTRIBUTE8                                                                                                             
        ,c1r.ATTRIBUTE9                                                                                                             
        ,c1r.ATTRIBUTE10                                                                                                            
        ,c1r.ATTRIBUTE11                                                                                                            
        ,c1r.ATTRIBUTE12                                                                                                            
        ,c1r.ATTRIBUTE13                                                                                                            
        ,c1r.ATTRIBUTE14                                                                                                            
        ,c1r.ATTRIBUTE15                                                                                                            
        ,c1r.HOLD_ID                                                                                                                
        ,c1r.REFERENCE_ORDER                                                                                                        
        ,c1r.REFERENCE_ITEM                                                                                                         
        ,c1r.REFERENCE_CUSTITEM                                                                                                     
        ,SYSDATE                              -- LAST                                                                               
_UPDATE_DATE                                                                                                                        
        ,myUserID                             -- LAST_UPDATED_BY                                                                    
        ,c1r.CALC_FEE_PCT                                                                                                           
        ,c1r.BOX_KIT_ITEM_ID                                                                                                        
        ,c1r.UOM                                                                                                                    
        ,c1r.COMMENTS_LSM                                                                                                           
        ,c1r.RETURN_RMA_FLAG                                                                                                        
        ,c1r.ZERO_PRICE_ALLOWED_FLAG                                                                                                
        ,c1r.LINE_TYPE                                                                                                              
        ,c1r.PARTIAL_SHP                                                                                                            
        ,c1r.FEE_TOTAL                                                                                                              
        ,c1r.QTYBAD                                                                                                                 
        ,c1r.FTP                                                                                                                    
        ,c1r.FTP_DATE                                                                                                               
        ,c1r.CORE_FLAG                                                                                                              
        ,c1r.CORE_PRICE                                                                                                             
        ,c1r.CORE_BUY                                                                                                               
        ,c1r.COST                                                                                                                   
        ,c1r.FEE_TYPE                                                                                                               
        ,c1r.STS_NUMBER                                                                                                             
        ,c1r.SERIAL_FLAG                                                                                                            
        ,c1r.DIVISION                                                                                                               
        ,c1r.BUSINESS                                                                                                               
        ,c1r.REPAIR_PLANT_ID                                                                                                        
        );                                                                                                                          
                                                                                                                                    
         if nvl(c1r.SERIAL_FLAG,'Y') = 'Y' then                                                                                     
            log;                                                                                                                    
            mySect := 'Proc - Move DEX_SERIALS';                                                                                    
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            ORDERNO       = myNOrder                                                                                                
           ,ITEM          = myNItem                                                                                                 
           ,UNIQUENO      = rownum                                                                                                  
           ,LOCATION      = decode(myBuyFlag,'Y','BUY',LOCATION                                                                     
)                                                                                                                                   
           ,DATELOC       = decode(myBuyFlag,'Y',SYSDATE,DATELOC)                                                                   
           ,TAB_NUMBER    = decode(myBuyFlag,'Y','BCK',TAB_NUM                                                                      
BER)                                                                                                                                
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = c1r.ITEM                                                                                                
            and   TRAN_ID = myTranID;                                                                                               
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Proc - Update Qty New';                                                                                      
                                                                                                                                    
            update DEX_LINES set                                                                                                    
            QTYORG =                                                                                                                
               (select count('*')                                                                                                   
                from   DEX_SERIALS                                                                                                  
                where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDE                                                                         
RNO                                                                                                                                 
                and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM)                                                                        
           ,QTYSCR =                                                                                                                
               (select count('*')                                                                                                   
                from   DEX_SERIALS                                                                                                  
                where  DEX_SERIALS.ORDERNO = DEX_LINE                                                                               
S.ORDERNO                                                                                                                           
                and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM                                                                         
                and    DEX_SERIALS.SCRAP   = 'Y')                                                                                   
            where ORDERNO = myNOrder                                                                                                
            and   ITEM    = myNItem;                                                                                                
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Proc - Update Qty Old';                                                                                      
                                                                                                                                    
            update DEX_LINES set                                                                                                    
            QTYORG =                                                                                                                
               (select count('*')                                                                                                   
                from   DEX_SERIALS                                                                                                  
                where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDE                                                                         
RNO                                                                                                                                 
                and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM)                                                                        
			  ,QTYSCR =                                                                                                                      
               (select count('*')                                                                                                   
                from   DEX_SERIALS                                                                                                  
                where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDE                                                                         
RNO                                                                                                                                 
                and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM                                                                         
                and    DEX_SERIALS.SCRAP   = 'Y')                                                                                   
           ,QTYCUT = null                                                                                                           
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = c1r.ITEM;                                                                                               
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      if myRelease is null or length(myRelease) > 18 then                                                                           
         myRelease := 'BUY OPP ' || to_char(SYSDATE,'MMDDH                                                                          
H24MI');                                                                                                                            
                                                                                                                                    
      else                                                                                                                          
         myRelease := myRelease || '-B';                                                                                            
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Proc - Insert Order';                                                                                              
                                                                                                                                    
      insert into DEX_ORDERS                                                                                                        
     (ORDERNO                                                                                                                       
     ,CUST                                                                                                                          
     ,CUSTNAME                                                                                                                      
     ,CUSTPO                                                                                                                        
     ,RELEASE                                                                                                                       
     ,DATERCV                                                                                                                       
     ,DATEENT                                                                                                                       
     ,DATEINS                                                                                                                       
     ,DATETRN                                                                                                                       
     ,ROAR                                                                                                                          
     ,CUSTBOX                                                                                                                       
     ,UNPACKER                                                                                                                      
     ,RECEIVER                                                                                                                      
     ,INSPECTOR                                                                                                                     
     ,CUSTREP                                                                                                                       
     ,DROP_SHIP                                                                                                                     
     ,SHIP_VIA                                                                                                                      
     ,SHIP_NAME                                                                                                                     
     ,SHIP_ATTN                                                                                                                     
     ,SHIP_ST1                                                                                                                      
     ,SHIP_ST2                                                                                                                      
     ,SHIP_CITY                                                                                                                     
     ,SHIP_STATE                                                                                                                    
     ,SHIP_ZIP                                                                                                                      
     ,COD                                                                                                                           
     ,HOLD_CODE                                                                                                                     
     ,SHIPTO                                                                                                                        
     ,ORDTYPE                                                                                                                       
     ,DISC_FLAG                                                                                                                     
     ,TRANSFER                                                                                                                      
     ,REJECTS                                                                                                                       
     ,REASON                                                                                                                        
     ,PARTIAL_SHP                                                                                                                   
     ,REGION                                                                                                                        
     ,AGENT                                                                                                                         
     ,CLASS                                                                                                                         
     ,TLM                                                                                                                           
     ,COMMENTS                                                                                                                      
     ,RMA                                                                                                                           
     ,PLANT                                                                                                                         
     ,TYPE                                                                                                                          
     ,EXCHANGE                                                                                                                      
     ,DRIVER                                                                                                                        
     ,SHIPTO_LOC_CODE                                                                                                               
     ,SHIPTO_SITE_CODE                                                                                                              
     ,ATTRIBUTE_CATEGORY                                                                                                            
     ,ATTRIBUTE1                                                                                                                    
     ,ATTRIBUTE2                                                                                                                    
     ,ATTRIBUTE3                                                                                                                    
     ,ATTRIBUTE4                                                                                                                    
     ,ATTRIBUTE5                                                                                                                    
     ,CLOSED_FLAG                                                                                                                   
     ,FREIGHT_QUOTE                                                                                                                 
     ,CREDIT_CARD_TYPE                                                                                                              
     ,CREDIT_CARD_NAME                                                                                                              
     ,CREDIT_CARD_ACCT                                                                                                              
     ,CREDIT_CARD_EXP                                                                                                               
     ,SATURDAY_DELIVERY                                                                                                             
     ,LEAD_ID                                                                                                                       
     ,CUST_EXCHANGE                                                                                                                 
     ,COUNTRY                                                                                                                       
     ,ORDER_SOURCE                                                                                                                  
     ,CREDIT_CARD_APPROVAL                                                                                                          
     ,ATTRIBUTE6                                                                                                                    
     ,ATTRIBUTE7                                                                                                                    
     ,ATTRIBUTE8                                                                                                                    
     ,ATTRIBUTE9                                                                                                                    
     ,ATTRIBUTE10                                                                                                                   
     ,ORG_ID                                                                                                                        
     ,CUSTOMER_ID                                                                                                                   
     ,BILL_SITE_USE_ID                                                                                                              
     ,SHIP_SITE_USE_ID)                                                                                                             
      select myNOrder                                                                                                               
 -- ORDERNO                                                                                                                         
            ,CUST                                      -- CUST                                                                      
            ,CUSTNAME                                                                                                               
-- CUSTNAME                                                                                                                         
            ,CUSTPO                                    -- CUSTPO                                                                    
            ,myRelease                                                                                                              
  -- RELEASE                                                                                                                        
            ,DATERCV                                   -- DATERCV                                                                   
                                                                                                                                    
            ,DATEENT                                   -- DATEENT                                                                   
            ,DATEINS                                   -- DATEI                                                                     
NS                                                                                                                                  
            ,DATETRN                                   -- DATETRN                                                                   
            ,ROAR                                      -- ROA                                                                       
R                                                                                                                                   
            ,CUSTBOX                                   -- CUSTBOX                                                                   
            ,UNPACKER                                  -- UNPA                                                                      
CKER                                                                                                                                
            ,RECEIVER                                  -- RECEIVER                                                                  
            ,INSPECTOR                                 --                                                                           
INSPECTOR                                                                                                                           
            ,CUSTREP                                   -- CUSTREP                                                                   
            ,DROP_SHIP                                                                                                              
 -- DROP_SHIP                                                                                                                       
            ,SHIP_VIA                                  -- SHIP_V                                                                    
IA                                                                                                                                  
            ,SHIP_NAME                                 -- SHIP_NAME                                                                 
            ,SHIP_ATTN                                 -- S                                                                         
HIP_ATTN                                                                                                                            
            ,SHIP_ST1                                  -- SHIP_ST1                                                                  
            ,SHIP_ST2                                                                                                               
 -- SHIP_ST2                                                                                                                        
            ,SHIP_CITY                                 -- SHIP_CI                                                                   
TY                                                                                                                                  
            ,SHIP_STATE                                -- SHIP_STATE                                                                
            ,SHIP_ZIP                                  --                                                                           
SHIP_ZIP                                                                                                                            
            ,COD                                       -- COD                                                                       
            ,HOLD_CODE                                 -- H                                                                         
OLD_CODE                                                                                                                            
            ,SHIPTO                                    -- SHIPTO                                                                    
            ,ORDTYPE                                   -                                                                            
- ORDTYPE                                                                                                                           
            ,DISC_FLAG                                 -- DISC_FLAG                                                                 
            ,TRANSFER                                                                                                               
   -- TRANSFER                                                                                                                      
            ,REJECTS                                   -- REJEC                                                                     
TS                                                                                                                                  
            ,REASON                                    -- REASON                                                                    
            ,PARTIAL_SHP                               -- PART                                                                      
IAL_SHP                                                                                                                             
            ,REGION                                    -- REGION                                                                    
            ,AGENT                                     --                                                                           
 AGENT                                                                                                                              
            ,CLASS                                     -- CLASS                                                                     
            ,TLM                                       -- T                                                                         
LM                                                                                                                                  
            ,myCmt                                     -- COMMENTS                                                                  
            ,RMA                                       -- RM                                                                        
A                                                                                                                                   
            ,PLANT                                     -- PLANT                                                                     
            ,decode(myBuyFlag,'Y','B',TYPE)            -- TYPE                                                                      
            ,EXCHANGE                                                                                                               
  -- EXCHANGE                                                                                                                       
            ,DRIVER                                    -- DRIVER                                                                    
                                                                                                                                    
            ,SHIPTO_LOC_CODE                           -- SHIPTO_LOC_CODE                                                           
            ,SHIPTO_SITE_CODE                                                                                                       
-- SHIPTO_SITE_CODE                                                                                                                 
            ,ATTRIBUTE_CATEGORY                        --                                                                           
ATTRIBUTE_CATEGORY                                                                                                                  
            ,ATTRIBUTE1                                -- A                                                                         
TTRIBUTE1                                                                                                                           
            ,ATTRIBUTE2                                -- ATTRIBUTE2                                                                
                                                                                                                                    
            ,ATTRIBUTE3                                -- ATTRIBUTE3                                                                
            ,ATTRIBUTE4                                -- AT                                                                        
TRIBUTE4                                                                                                                            
            ,ATTRIBUTE5                                -- ATTRIBUTE5                                                                
            ,CLOSED_FLAG                                                                                                            
   -- CLOSED_FLAG                                                                                                                   
            ,FREIGHT_QUOTE                             -- FR                                                                        
EIGHT_QUOTE                                                                                                                         
            ,CREDIT_CARD_TYPE                          -- CREDIT_C                                                                  
ARD_TYPE                                                                                                                            
            ,CREDIT_CARD_NAME                          -- CREDIT_CARD                                                               
_NAME                                                                                                                               
            ,CREDIT_CARD_ACCT                          -- CREDIT_CARD_AC                                                            
CT                                                                                                                                  
            ,CREDIT_CARD_EXP                           -- CREDIT_CARD_EXP                                                           
            ,SATURDAY_DELIVERY                                                                                                      
  -- SATURDAY_DELIVERY                                                                                                              
            ,LEAD_ID                                                                                                                
-- LEAD_ID                                                                                                                          
            ,CUST_EXCHANGE                             -- CUST_EXCH                                                                 
ANGE                                                                                                                                
            ,COUNTRY                                   -- COUNTRY                                                                   
            ,ORDER_SOURCE                                                                                                           
            ,CREDIT_CARD_APPROVAL                      -- C                                                                         
REDIT_CARD_APPROVAL                                                                                                                 
            ,ATTRIBUTE6                                --                                                                           
ATTRIBUTE6                                                                                                                          
            ,ATTRIBUTE7                                -- ATTRIBUTE                                                                 
7                                                                                                                                   
            ,ATTRIBUTE8                                -- ATTRIBUTE8                                                                
            ,ATTRIBUTE9                                -- A                                                                         
TTRIBUTE9                                                                                                                           
            ,ATTRIBUTE10                               -- ATTRIBUTE1                                                                
0                                                                                                                                   
            ,ORG_ID                                    -- ORG_ID                                                                    
            ,CUSTOMER_ID                               -- CUSTO                                                                     
MER_ID                                                                                                                              
            ,BILL_SITE_USE_ID                          -- BILL_SITE_USE                                                             
_ID                                                                                                                                 
            ,SHIP_SITE_USE_ID                          -- SHIP_SITE_USE_ID                                                          
                                                                                                                                    
      from   DEX_ORDERS                                                                                                             
      where  ORDERNO = myOrder;                                                                                                     
                                                                                                                                    
      if myOrdType in ('R','H','M') then                                                                                            
         log;                                                                                                                       
         mySect := 'Proc - Job Open';                                                                                               
                                                                                                                                    
         K_WIP_JOB.JOB_OPEN ( myNOrder );                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Proc - Complete';                                                                                                  
      log;                                                                                                                          
   end PROCESS;                                                                                                                     
                                                                                                                                    
   /***************************************************                                                                             
**************************************************/                                                                                 
                                                                                                                                    
   procedure CONSOLIDATE (                                                                                                          
                           myRetMesg      out  varchar2                                                                             
                          ,myRetCode      out  number                                                                               
                          ,myNOrder    in out  varchar2                                                                             
                          ,myOrder     in      varchar2                                                                             
                         ) is                                                                                                       
      myNItem    number(4) := 0;                                                                                                    
                                                                                                                                    
      myUserID   number(15) := F_DEX_USER_ID;                                                                                       
                                                                                                                                    
      myOrdType  DEX_ORDERS.ORDTYPE%type;                                                                                           
      myRelease  DEX_ORDERS.RELEASE%type;                                                                                           
                                                                                                                                    
      myCmt      long;                                                                                                              
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select *                                                                                                                   
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    QTYCUT  > 0;                                                                                                        
                                                                                                                                    
   begin                                                                                                                            
      mySect := 'Cons - Start';                                                                                                     
      log;                                                                                                                          
      mySect := 'Cons - Load Comment';                                                                                              
                                                                                                                                    
      select ORDTYPE                                                                                                                
            ,RELEASE                                                                                                                
            ,COMMENTS                                                                                                               
      into   myOrdType                                                                                                              
            ,myRelease                                                                                                              
            ,myCmt                                                                                                                  
      from   DEX_ORDERS                                                                                                             
      where  ORDERNO = myOrder;                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cons - QtyCut';                                                                                                    
                                                                                                                                    
      update DEX_LINES lne set                                                                                                      
      QTYCUT =                                                                                                                      
         (select count('*')                                                                                                         
          from   DEX_SERIALS ser                                                                                                    
          where  ser.ORDERNO = lne.ORDERNO                                                                                          
          and    ser.ITEM    = lne.ITEM                                                                                             
          and    ser.LOCATION not in ('PKD','SHP'))                                                                                 
      where ORDERNO = myOrder;                                                                                                      
                                                                                                                                    
      if SQL%rowcount = 0 then                                                                                                      
         myRetMesg := 'No Tracks Found to Move';                                                                                    
         myRetCode := 1;                                                                                                            
                                                                                                                                    
         return;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cons - Order';                                                                                                     
                                                                                                                                    
      myNOrder := F_ORDER_CHECK;                                                                                                    
                                                                                                                                    
      dbms_output.put_line ( 'New Order: ' || myNOrder );                                                                           
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cons - Loop';                                                                                                      
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         log;                                                                                                                       
         mySect := 'Cons - Item';                                                                                                   
                                                                                                                                    
         select min(ITEM)                                                                                                           
         into   myNItem                                                                                                             
         from   DEX_LINES                                                                                                           
         where  ORDERNO           = myNOrder                                                                                        
         and    INVENTORY_ITEM_ID = c1r.INVENTORY_ITEM_ID                                                                           
         and    PRICE             = c1r.PRICE                                                                                       
         and    CUSTPART          = c1r.CUSTPART                                                                                    
         and    GRP               = c1r.GRP                                                                                         
         and    STATCODE          = c1r.STATCODE;                                                                                   
                                                                                                                                    
         dbms_output.put_line ( 'NItem: ' || myNItem || ' Item: ' || c1r.                                                           
ITEM || ' Qty: ' || c1r.QTYCUT );                                                                                                   
                                                                                                                                    
         if nvl(myNItem,0) = 0 then                                                                                                 
            log;                                                                                                                    
            mySect := 'Cons - Last Item';                                                                                           
                                                                                                                                    
            select max(ITEM)                                                                                                        
            into   myNItem                                                                                                          
            from   DEX_LINES                                                                                                        
            where  ORDERNO = myNOrder;                                                                                              
                                                                                                                                    
            myNItem := nvl(myNItem,0) + 1;                                                                                          
                                                                                                                                    
            if myNItem > 999 then                                                                                                   
               myRetMesg := 'Line Item Over 999';                                                                                   
               myRetCode := 1;                                                                                                      
                                                                                                                                    
               rollback;                                                                                                            
                                                                                                                                    
               return;                                                                                                              
            end if;                                                                                                                 
                                                                                                                                    
            if myNItem is null then                                                                                                 
               myRetMesg := 'New Line Item Null';                                                                                   
               myRetCode := 1;                                                                                                      
                                                                                                                                    
               rollback;                                                                                                            
                                                                                                                                    
               return;                                                                                                              
            end if;                                                                                                                 
                                                                                                                                    
            dbms_output.put_line ( 'New Item: ' || myN                                                                              
Item || ' Item: ' || c1r.ITEM || ' Qty: ' || c1r.QTY                                                                                
CUT );                                                                                                                              
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Cons - Insert DEX_LINES';                                                                                    
                                                                                                                                    
            insert into DEX_LINES                                                                                                   
           (ORDERNO                                                                                                                 
           ,ITEM                                                                                                                    
           ,CUSTITEM                                                                                                                
           ,PART                                                                                                                    
           ,CUSTPART                                                                                                                
           ,DESCRIPTION                                                                                                             
           ,DATESCH                                                                                                                 
           ,STATCODE                                                                                                                
           ,COMMENTS                                                                                                                
           ,SERIALCTL                                                                                                               
           ,PRICE                                                                                                                   
           ,QTYORG                                                                                                                  
           ,GRP                                                                                                                     
           ,HOLD_CODE                                                                                                               
           ,MFG                                                                                                                     
           ,SHIP_EARLY                                                                                                              
           ,INFO                                                                                                                    
           ,INFO2                                                                                                                   
           ,INFO3                                                                                                                   
           ,INFO4                                                                                                                   
           ,INV_MGMT                                                                                                                
           ,DOA                                                                                                                     
           ,FAILANAL                                                                                                                
           ,SWAP                                                                                                                    
           ,RMA_FLAG                                                                                                                
           ,REQUISITION_NUMBER                                                                                                      
           ,LINE_LOCATION_ID                                                                                                        
           ,NOTE_TO_BUYER_ID                                                                                                        
           ,STATUS                                                                                                                  
           ,STORE                                                                                                                   
           ,ORIG_CUST_PART                                                                                                          
           ,INVENTORY_ITEM_ID                                                                                                       
           ,ORGANIZATION_ID                                                                                                         
           ,GROUP_ID                                                                                                                
           ,CUSTOMER_ITEM_ID                                                                                                        
           ,SUBINVENTORY_CODE                                                                                                       
           ,ATTRIBUTE_CATEGORY                                                                                                      
           ,ATTRIBUTE1                                                                                                              
           ,ATTRIBUTE2                                                                                                              
           ,ATTRIBUTE3                                                                                                              
           ,ATTRIBUTE4                                                                                                              
           ,ATTRIBUTE5                                                                                                              
           ,ATTRIBUTE6                                                                                                              
           ,ATTRIBUTE7                                                                                                              
           ,ATTRIBUTE8                                                                                                              
           ,ATTRIBUTE9                                                                                                              
           ,ATTRIBUTE10                                                                                                             
           ,ATTRIBUTE11                                                                                                             
           ,ATTRIBUTE12                                                                                                             
           ,ATTRIBUTE13                                                                                                             
           ,ATTRIBUTE14                                                                                                             
           ,ATTRIBUTE15                                                                                                             
           ,HOLD_ID                                                                                                                 
           ,REFERENCE_ORDER                                                                                                         
           ,REFERENCE_ITEM                                                                                                          
           ,REFERENCE_CUSTITEM                                                                                                      
           ,LAST_UPDATE_DATE                                                                                                        
           ,LAST_UPDATED_BY                                                                                                         
           ,CALC_FEE_PCT                                                                                                            
           ,BOX_KIT_ITEM_ID                                                                                                         
           ,UOM                                                                                                                     
           ,COMMENTS_LSM                                                                                                            
           ,RETURN_RMA_FLAG                                                                                                         
           ,ZERO_PRICE_ALLOWED_FLAG                                                                                                 
           ,LINE_TYPE                                                                                                               
           ,PARTIAL_SHP                                                                                                             
           ,FEE_TOTAL                                                                                                               
           ,QTYBAD                                                                                                                  
           ,FTP                                                                                                                     
           ,FTP_DATE                                                                                                                
           ,CORE_FLAG                                                                                                               
           ,CORE_PRICE                                                                                                              
           ,CORE_BUY                                                                                                                
           ,COST                                                                                                                    
           ,FEE_TYPE                                                                                                                
           ,STS_NUMBER                                                                                                              
           ,SERIAL_FLAG                                                                                                             
           ,DIVISION                                                                                                                
           ,BUSINESS                                                                                                                
           ,REPAIR_PLANT_ID                                                                                                         
           ) values (                                                                                                               
            myNOrder                                -- ORDERNO                                                                      
           ,myNItem                                 -- ITEM                                                                         
           ,c1r.CUSTITEM                                                                                                            
           ,c1r.PART                                                                                                                
           ,c1r.CUSTPART                                                                                                            
           ,c1r.DESCRIPTION                                                                                                         
           ,c1r.DATESCH                                                                                                             
           ,c1r.STATCODE                                                                                                            
           ,c1r.COMMENTS                                                                                                            
           ,c1r.SERIALCTL                                                                                                           
           ,c1r.PRICE                                                                                                               
           ,c1r.QTYCUT                                                                                                              
           ,c1r.GRP                                                                                                                 
           ,c1r.HOLD_CODE                                                                                                           
           ,c1r.MFG                                                                                                                 
           ,c1r.SHIP_EARLY                                                                                                          
           ,c1r.INFO                                                                                                                
           ,c1r.INFO2                                                                                                               
           ,c1r.INFO3                                                                                                               
           ,c1r.INFO4                                                                                                               
           ,c1r.INV_MGMT                                                                                                            
           ,c1r.DOA                                                                                                                 
           ,c1r.FAILANAL                                                                                                            
           ,c1r.SWAP                                                                                                                
           ,c1r.RMA_FLAG                                                                                                            
           ,c1r.REQUISITION_NUMBER                                                                                                  
           ,c1r.LINE_LOCATION_ID                                                                                                    
           ,c1r.NOTE_TO_BUYER_ID                                                                                                    
           ,c1r.STATUS                                                                                                              
           ,c1r.STORE                                                                                                               
           ,c1r.ORIG_CUST_PART                                                                                                      
           ,c1r.INVENTORY_ITEM_ID                                                                                                   
           ,c1r.ORGANIZATION_ID                                                                                                     
           ,c1r.GROUP_ID                                                                                                            
           ,c1r.CUSTOMER_ITEM_ID                                                                                                    
           ,c1r.SUBINVENTORY_CODE                                                                                                   
           ,c1r.ATTRIBUTE_CATEGORY                                                                                                  
           ,c1r.ATTRIBUTE1                                                                                                          
           ,c1r.ATTRIBUTE2                                                                                                          
           ,c1r.ATTRIBUTE3                                                                                                          
           ,c1r.ATTRIBUTE4                                                                                                          
           ,c1r.ATTRIBUTE5                                                                                                          
           ,c1r.ATTRIBUTE6                                                                                                          
           ,c1r.ATTRIBUTE7                                                                                                          
           ,c1r.ATTRIBUTE8                                                                                                          
           ,c1r.ATTRIBUTE9                                                                                                          
           ,c1r.ATTRIBUTE10                                                                                                         
           ,c1r.ATTRIBUTE11                                                                                                         
           ,c1r.ATTRIBUTE12                                                                                                         
           ,c1r.ATTRIBUTE13                                                                                                         
           ,c1r.ATTRIBUTE14                                                                                                         
           ,c1r.ATTRIBUTE15                                                                                                         
           ,c1r.HOLD_ID                                                                                                             
           ,c1r.REFERENCE_ORDER                                                                                                     
           ,c1r.REFERENCE_ITEM                                                                                                      
           ,c1r.REFERENCE_CUSTITEM                                                                                                  
           ,SYSDATE                              -- LAST_UPDATE_DAT                                                                 
E                                                                                                                                   
           ,myUserID                             -- LAST_UPDATED_BY                                                                 
           ,c1r.CALC_FEE_PCT                                                                                                        
           ,c1r.BOX_KIT_ITEM_ID                                                                                                     
           ,c1r.UOM                                                                                                                 
           ,c1r.COMMENTS_LSM                                                                                                        
           ,c1r.RETURN_RMA_FLAG                                                                                                     
           ,c1r.ZERO_PRICE_ALLOWED_FLAG                                                                                             
           ,c1r.LINE_TYPE                                                                                                           
           ,c1r.PARTIAL_SHP                                                                                                         
           ,c1r.FEE_TOTAL                                                                                                           
           ,c1r.QTYBAD                                                                                                              
           ,c1r.FTP                                                                                                                 
           ,c1r.FTP_DATE                                                                                                            
           ,c1r.CORE_FLAG                                                                                                           
           ,c1r.CORE_PRICE                                                                                                          
           ,c1r.CORE_BUY                                                                                                            
           ,c1r.COST                                                                                                                
           ,c1r.FEE_TYPE                                                                                                            
           ,c1r.STS_NUMBER                                                                                                          
           ,c1r.SERIAL_FLAG                                                                                                         
           ,c1r.DIVISION                                                                                                            
           ,c1r.BUSINESS                                                                                                            
           ,c1r.REPAIR_PLANT_ID                                                                                                     
           );                                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         if nvl(c1r.STORE,'R') not in ('P','X') then                                                                                
            log;                                                                                                                    
            mySect := 'Cons - Move DEX_SERIALS - Item: ' || to_char(m                                                               
yNItem);                                                                                                                            
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            ORDERNO       = myNOrder                                                                                                
           ,ITEM          = myNItem                                                                                                 
           ,UNIQUENO      = UNIQUENO * -1                                                                                           
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = c1r.ITEM                                                                                                
            and   LOCATION not in ('PKD','SHP');                                                                                    
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Cons - Update Qty New';                                                                                      
                                                                                                                                    
            update DEX_LINES lne set                                                                                                
            QTYORG =                                                                                                                
               (select count('*')                                                                                                   
                from   DEX_SERIALS ser                                                                                              
                where  ser.ORDERNO = lne.ORDERNO                                                                                    
                and    ser.ITEM    = lne.ITEM)                                                                                      
		  	  ,QTYSCR =                                                                                                                    
            	(select count('*')                                                                                                     
                from   DEX_SERIALS ser                                                                                              
                where  ser.ORDERNO = lne.ORDERNO                                                                                    
                and    ser.ITEM    = lne.ITEM                                                                                       
                and    ser.SCRAP   = 'Y')                                                                                           
           ,(FEE_TOTAL,FEE_BILL) =                                                                                                  
               (select sum(dsf.FEE)                                                                                                 
                      ,sum(decode(dsf.BILL_FLAG,null,dsf.FEE,0))                                                                    
                from   DEX_SERIAL_FEES dsf                                                                                          
                      ,SERIALS ser                                                                                                  
                where  ser.SERIAL_ID = dsf.SERIAL_ID                                                                                
                                                                                                                                    
                and    ser.ORDERNO   = lne.ORDERNO                                                                                  
                and    ser.ITEM      = lne.ITEM)                                                                                    
            where ORDERNO = myNOrder                                                                                                
            and   ITEM    = myNItem;                                                                                                
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Cons - Update Qty Old';                                                                                      
                                                                                                                                    
            update DEX_LINES lne set                                                                                                
            QTYORG =                                                                                                                
               (select count('*')                                                                                                   
                from   DEX_SERIALS ser                                                                                              
                where  ser.ORDERNO = lne.ORDERNO                                                                                    
                and    ser.ITEM    = lne.ITEM)                                                                                      
		  	  ,QTYSCR =                                                                                                                    
            	(select count('*')                                                                                                     
                from   DEX_SERIALS ser                                                                                              
                where  ser.ORDERNO = lne.ORDERNO                                                                                    
                and    ser.ITEM    = lne.ITEM                                                                                       
                and    ser.SCRAP   = 'Y')                                                                                           
           ,(FEE_TOTAL,FEE_BILL) =                                                                                                  
               (select sum(dsf.FEE)                                                                                                 
                      ,sum(decode(dsf.BILL_FLAG,null,dsf.FEE,0))                                                                    
                from   DEX_SERIAL_FEES dsf                                                                                          
                      ,SERIALS ser                                                                                                  
                where  ser.SERIAL_ID = dsf.SERIAL_ID                                                                                
                and    ser.ORDERNO   = lne.ORDERNO                                                                                  
                and    ser.ITEM      = lne.ITEM)                                                                                    
           ,QTYCUT = null                                                                                                           
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = c1r.ITEM;                                                                                               
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      if myRelease is null or length(myRelease) > 38 t                                                                              
hen                                                                                                                                 
         myRelease := 'Move Order ' || to_char(SYSDATE,'MMDDHH24MI');                                                               
                                                                                                                                    
      else                                                                                                                          
         myRelease := myRelease || '-MO';                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cons - Insert Order';                                                                                              
                                                                                                                                    
      insert into DEX_ORDERS                                                                                                        
     (ORDERNO                                                                                                                       
     ,CUST                                                                                                                          
     ,CUSTNAME                                                                                                                      
     ,CUSTPO                                                                                                                        
     ,RELEASE                                                                                                                       
     ,DATERCV                                                                                                                       
     ,DATEENT                                                                                                                       
     ,DATEINS                                                                                                                       
     ,DATETRN                                                                                                                       
     ,ROAR                                                                                                                          
     ,CUSTBOX                                                                                                                       
     ,UNPACKER                                                                                                                      
     ,RECEIVER                                                                                                                      
     ,INSPECTOR                                                                                                                     
     ,CUSTREP                                                                                                                       
     ,DROP_SHIP                                                                                                                     
     ,SHIP_VIA                                                                                                                      
     ,SHIP_NAME                                                                                                                     
     ,SHIP_ATTN                                                                                                                     
     ,SHIP_ST1                                                                                                                      
     ,SHIP_ST2                                                                                                                      
     ,SHIP_CITY                                                                                                                     
     ,SHIP_STATE                                                                                                                    
     ,SHIP_ZIP                                                                                                                      
     ,COD                                                                                                                           
     ,HOLD_CODE                                                                                                                     
     ,SHIPTO                                                                                                                        
     ,ORDTYPE                                                                                                                       
     ,DISC_FLAG                                                                                                                     
     ,TRANSFER                                                                                                                      
     ,REJECTS                                                                                                                       
     ,REASON                                                                                                                        
     ,PARTIAL_SHP                                                                                                                   
     ,REGION                                                                                                                        
     ,AGENT                                                                                                                         
     ,CLASS                                                                                                                         
     ,TLM                                                                                                                           
     ,COMMENTS                                                                                                                      
     ,RMA                                                                                                                           
     ,PLANT                                                                                                                         
     ,TYPE                                                                                                                          
     ,EXCHANGE                                                                                                                      
     ,DRIVER                                                                                                                        
     ,SHIPTO_LOC_CODE                                                                                                               
     ,SHIPTO_SITE_CODE                                                                                                              
     ,ATTRIBUTE_CATEGORY                                                                                                            
     ,ATTRIBUTE1                                                                                                                    
     ,ATTRIBUTE2                                                                                                                    
     ,ATTRIBUTE3                                                                                                                    
     ,ATTRIBUTE4                                                                                                                    
     ,ATTRIBUTE5                                                                                                                    
     ,CLOSED_FLAG                                                                                                                   
     ,FREIGHT_QUOTE                                                                                                                 
     ,CREDIT_CARD_TYPE                                                                                                              
     ,CREDIT_CARD_NAME                                                                                                              
     ,CREDIT_CARD_ACCT                                                                                                              
     ,CREDIT_CARD_EXP                                                                                                               
     ,SATURDAY_DELIVERY                                                                                                             
     ,LEAD_ID                                                                                                                       
     ,CUST_EXCHANGE                                                                                                                 
     ,COUNTRY                                                                                                                       
     ,ORDER_SOURCE                                                                                                                  
     ,CREDIT_CARD_APPROVAL                                                                                                          
     ,ATTRIBUTE6                                                                                                                    
     ,ATTRIBUTE7                                                                                                                    
     ,ATTRIBUTE8                                                                                                                    
     ,ATTRIBUTE9                                                                                                                    
     ,ATTRIBUTE10                                                                                                                   
     ,ORG_ID                                                                                                                        
     ,CUSTOMER_ID                                                                                                                   
     ,BILL_SITE_USE_ID                                                                                                              
     ,SHIP_SITE_USE_ID)                                                                                                             
      select myNOrder                                  -- ORDERNO                                                                   
            ,CUST                                                                                                                   
   -- CUST                                                                                                                          
            ,CUSTNAME                                  -- CUSTNAME                                                                  
            ,CUSTPO                                                                                                                 
   -- CUSTPO                                                                                                                        
            ,myRelease                                 -- RELEASE                                                                   
                                                                                                                                    
            ,DATERCV                                   -- DATERCV                                                                   
            ,DATEENT                                   -- DATEE                                                                     
NT                                                                                                                                  
            ,DATEINS                                   -- DATEINS                                                                   
            ,DATETRN                                   -- DAT                                                                       
ETRN                                                                                                                                
            ,ROAR                                      -- ROAR                                                                      
            ,CUSTBOX                                   -- CUST                                                                      
BOX                                                                                                                                 
            ,UNPACKER                                  -- UNPACKER                                                                  
            ,RECEIVER                                  -- R                                                                         
ECEIVER                                                                                                                             
            ,INSPECTOR                                 -- INSPECTOR                                                                 
            ,CUSTREP                                                                                                                
 -- CUSTREP                                                                                                                         
            ,DROP_SHIP                                 -- DROP_SHI                                                                  
P                                                                                                                                   
            ,SHIP_VIA                                  -- SHIP_VIA                                                                  
            ,SHIP_NAME                                 -- SHI                                                                       
P_NAME                                                                                                                              
            ,SHIP_ATTN                                 -- SHIP_ATTN                                                                 
            ,SHIP_ST1                                                                                                               
-- SHIP_ST1                                                                                                                         
            ,SHIP_ST2                                  -- SHIP_ST2                                                                  
                                                                                                                                    
            ,SHIP_CITY                                 -- SHIP_CITY                                                                 
            ,SHIP_STATE                                -- SHI                                                                       
P_STATE                                                                                                                             
            ,SHIP_ZIP                                  -- SHIP_ZIP                                                                  
            ,COD                                                                                                                    
-- COD                                                                                                                              
            ,HOLD_CODE                                 -- HOLD_CODE                                                                 
            ,SHIPTO                                                                                                                 
-- SHIPTO                                                                                                                           
            ,ORDTYPE                                   -- ORDTYPE                                                                   
            ,DISC_FLAG                                                                                                              
 -- DISC_FLAG                                                                                                                       
            ,TRANSFER                                  -- TRANSF                                                                    
ER                                                                                                                                  
            ,REJECTS                                   -- REJECTS                                                                   
            ,REASON                                    -- REA                                                                       
SON                                                                                                                                 
            ,PARTIAL_SHP                               -- PARTIAL_SHP                                                               
            ,REGION                                    -                                                                            
- REGION                                                                                                                            
            ,AGENT                                     -- AGENT                                                                     
            ,CLASS                                     --                                                                           
 CLASS                                                                                                                              
            ,TLM                                       -- TLM                                                                       
            ,myCmt                                     -- COM                                                                       
MENTS                                                                                                                               
            ,RMA                                       -- RMA                                                                       
            ,PLANT                                     -- PLAN                                                                      
T                                                                                                                                   
            ,TYPE                                      -- TYPE                                                                      
            ,EXCHANGE                                  -- EXCHANG                                                                   
E                                                                                                                                   
            ,DRIVER                                    -- DRIVER                                                                    
            ,SHIPTO_LOC_CODE                           -- SHIPT                                                                     
O_LOC_CODE                                                                                                                          
            ,SHIPTO_SITE_CODE                          -- SHIPTO_SI                                                                 
TE_CODE                                                                                                                             
            ,ATTRIBUTE_CATEGORY                        -- ATTRIBUTE_CA                                                              
TEGORY                                                                                                                              
            ,ATTRIBUTE1                                -- ATTRIBUTE1                                                                
            ,ATTRIBUTE2                                                                                                             
 -- ATTRIBUTE2                                                                                                                      
            ,ATTRIBUTE3                                -- ATTRI                                                                     
BUTE3                                                                                                                               
            ,ATTRIBUTE4                                -- ATTRIBUTE4                                                                
            ,ATTRIBUTE5                                                                                                             
-- ATTRIBUTE5                                                                                                                       
            ,CLOSED_FLAG                               -- CLOSED                                                                    
_FLAG                                                                                                                               
            ,FREIGHT_QUOTE                             -- FREIGHT_QUOTE                                                             
            ,CREDIT_CARD_TYPE                                                                                                       
   -- CREDIT_CARD_TYPE                                                                                                              
            ,CREDIT_CARD_NAME                                                                                                       
-- CREDIT_CARD_NAME                                                                                                                 
            ,CREDIT_CARD_ACCT                          --                                                                           
CREDIT_CARD_ACCT                                                                                                                    
            ,CREDIT_CARD_EXP                           -- CRE                                                                       
DIT_CARD_EXP                                                                                                                        
            ,SATURDAY_DELIVERY                         -- SATURDA                                                                   
Y_DELIVERY                                                                                                                          
            ,LEAD_ID                                   -- LEAD_ID                                                                   
            ,CUST_EXCHANGE                                                                                                          
  -- CUST_EXCHANGE                                                                                                                  
            ,COUNTRY                                   -- C                                                                         
OUNTRY                                                                                                                              
            ,ORDER_SOURCE                                                                                                           
            ,CREDIT_CARD_APPROVAL                      -- CREDIT_CARD_A                                                             
PPROVAL                                                                                                                             
            ,ATTRIBUTE6                                -- ATTRIBUTE6                                                                
            ,ATTRIBUTE7                                                                                                             
  -- ATTRIBUTE7                                                                                                                     
            ,ATTRIBUTE8                                -- ATTR                                                                      
IBUTE8                                                                                                                              
            ,ATTRIBUTE9                                -- ATTRIBUTE9                                                                
            ,ATTRIBUTE10                                                                                                            
 -- ATTRIBUTE10                                                                                                                     
            ,ORG_ID                                    -- ORG_                                                                      
ID                                                                                                                                  
            ,CUSTOMER_ID                               -- CUSTOMER_ID                                                               
            ,BILL_SITE_USE_ID                          --                                                                           
 BILL_SITE_USE_ID                                                                                                                   
            ,SHIP_SITE_USE_ID                          -- SH                                                                        
IP_SITE_USE_ID                                                                                                                      
      from   DEX_ORDERS                                                                                                             
      where  ORDERNO = myOrder;                                                                                                     
                                                                                                                                    
      if myOrdType in ('R','H','M') then                                                                                            
         log;                                                                                                                       
         mySect := 'Cons - Job Open';                                                                                               
                                                                                                                                    
         K_WIP_JOB.JOB_OPEN ( myNOrder );                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Cons - Complete';                                                                                                  
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
         myRetCode := 2;                                                                                                            
                                                                                                                                    
--         rollback;                                                                                                                
   end CONSOLIDATE;                                                                                                                 
                                                                                                                                    
   /*********************************************************                                                                       
********************************************/                                                                                       
                                                                                                                                    
   procedure CHANGE_PO (                                                                                                            
                         myRetMesg      out  varchar2                                                                               
                        ,myRetCode      out  number                                                                                 
                        ,myNOrder    in out  varchar2                                                                               
                        ,myOrder     in      varchar2                                                                               
                        ,myCustPO    in      varchar                                                                                
2                                                                                                                                   
                        ,myCPart     in      varchar2                                                                               
                        ,myCQty      in      number                                                                                 
                        ,myAllowFIN	in		  varchar2 default 'N'                                                                      
                       ) is                                                                                                         
      myTQty      number(5) := myCQty;                                                                                              
                                                                                                                                    
        myQty         number(5);                                                                                                    
                                                                                                                                    
      myCust      DEX_ORDERS.CUST%type;                                                                                             
      myRelease   DEX_ORDERS.RELEASE%type;                                                                                          
      myCmt       DEX_ORDERS.COMMENTS%type;                                                                                         
      myNItem      number;                                                                                                          
      myOrdType   varchar2(1);                                                                                                      
        myUnique    pls_integer;                                                                                                    
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select ITEM                                                                                                                
               ,INVENTORY_ITEM_ID                                                                                                   
               ,COMMENTS                                                                                                            
               ,FEE_TOTAL                                                                                                           
         from   DEX_LINES                                                                                                           
         where  ORDERNO  = myOrder                                                                                                  
         and    CUSTPART = myCPart                                                                                                  
         and    (QTYORG  - nvl(QTYSHP,0)) > 0;                                                                                      
                                                                                                                                    
      cursor c2 ( myItem number ) is                                                                                                
         select SERIAL_ID                                                                                                           
         from   DEX_SERIALS                                                                                                         
         where  ORDERNO = myOrder                                                                                                   
         and    ITEM    = myItem                                                                                                    
         and    LOCATION != 'SHP'                                                                                                   
         and not (LOCATION = 'FIN' and myAllowFin = 'N')                                                                            
         order by UNIQUENO;                                                                                                         
                                                                                                                                    
                                                                                                                                    
   begin                                                                                                                            
      mySect := 'ChgPO - Start';                                                                                                    
      log;                                                                                                                          
      mySect := 'ChgPO - Load Data';                                                                                                
                                                                                                                                    
      select CUST                                                                                                                   
            ,RELEASE                                                                                                                
            ,ORDTYPE                                                                                                                
      into   myCust                                                                                                                 
            ,myRelease                                                                                                              
            ,myOrdType                                                                                                              
      from   DEX_ORDERS                                                                                                             
      where  ORDERNO = myOrder;                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'ChgPO - Find';                                                                                                     
                                                                                                                                    
      begin                                                                                                                         
         select ORDERNO                                                                                                             
         into   myNOrder                                                                                                            
         from   DEX_ORDERS                                                                                                          
         where  CUST    = myCust                                                                                                    
         and    CUSTPO  = myCustPO                                                                                                  
         and    RELEASE = myRelease;                                                                                                
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myNOrder := null;                                                                                                       
      end;                                                                                                                          
                                                                                                                                    
      if myNOrder is null then                                                                                                      
         log;                                                                                                                       
         mySect := 'ChgPO - Order';                                                                                                 
                                                                                                                                    
         myNOrder := F_ORDER_CHECK;                                                                                                 
                                                                                                                                    
         insert into DEX_ORDERS                                                                                                     
        (ORDERNO                                                                                                                    
        ,CUST                                                                                                                       
        ,CUSTNAME                                                                                                                   
        ,CUSTPO                                                                                                                     
        ,RELEASE                                                                                                                    
        ,DATERCV                                                                                                                    
        ,DATEENT                                                                                                                    
        ,DATEINS                                                                                                                    
        ,DATETRN                                                                                                                    
        ,ROAR                                                                                                                       
        ,CUSTBOX                                                                                                                    
        ,UNPACKER                                                                                                                   
        ,RECEIVER                                                                                                                   
        ,INSPECTOR                                                                                                                  
        ,CUSTREP                                                                                                                    
        ,DROP_SHIP                                                                                                                  
        ,SHIP_VIA                                                                                                                   
        ,SHIP_NAME                                                                                                                  
        ,SHIP_ATTN                                                                                                                  
        ,SHIP_ST1                                                                                                                   
        ,SHIP_ST2                                                                                                                   
        ,SHIP_CITY                                                                                                                  
        ,SHIP_STATE                                                                                                                 
        ,SHIP_ZIP                                                                                                                   
        ,COD                                                                                                                        
        ,HOLD_CODE                                                                                                                  
        ,SHIPTO                                                                                                                     
        ,ORDTYPE                                                                                                                    
        ,DISC_FLAG                                                                                                                  
        ,TRANSFER                                                                                                                   
        ,REJECTS                                                                                                                    
        ,REASON                                                                                                                     
        ,PARTIAL_SHP                                                                                                                
        ,REGION                                                                                                                     
        ,AGENT                                                                                                                      
        ,CLASS                                                                                                                      
        ,TLM                                                                                                                        
        ,COMMENTS                                                                                                                   
        ,RMA                                                                                                                        
        ,PLANT                                                                                                                      
        ,TYPE                                                                                                                       
        ,EXCHANGE                                                                                                                   
        ,DRIVER                                                                                                                     
        ,SHIPTO_LOC_CODE                                                                                                            
        ,SHIPTO_SITE_CODE                                                                                                           
        ,CLOSED_FLAG                                                                                                                
        ,FREIGHT_QUOTE                                                                                                              
        ,CREDIT_CARD_TYPE                                                                                                           
        ,CREDIT_CARD_NAME                                                                                                           
        ,CREDIT_CARD_ACCT                                                                                                           
        ,CREDIT_CARD_EXP                                                                                                            
        ,SATURDAY_DELIVERY                                                                                                          
        ,LEAD_ID                                                                                                                    
        ,CUST_EXCHANGE                                                                                                              
        ,COUNTRY                                                                                                                    
        ,ORDER_SOURCE                                                                                                               
        ,CREDIT_CARD_APPROVAL                                                                                                       
        ,ATTRIBUTE_CATEGORY                                                                                                         
        ,ATTRIBUTE1                                                                                                                 
        ,ATTRIBUTE2                                                                                                                 
        ,ATTRIBUTE3                                                                                                                 
        ,ATTRIBUTE4                                                                                                                 
        ,ATTRIBUTE5                                                                                                                 
        ,ATTRIBUTE6                                                                                                                 
        ,ATTRIBUTE7                                                                                                                 
        ,ATTRIBUTE8                                                                                                                 
        ,ATTRIBUTE9                                                                                                                 
        ,ATTRIBUTE10                                                                                                                
        ,ATTRIBUTE11                                                                                                                
        ,ATTRIBUTE12                                                                                                                
        ,ATTRIBUTE13                                                                                                                
        ,ATTRIBUTE14                                                                                                                
        ,ATTRIBUTE15                                                                                                                
        ,ATTRIBUTE16                                                                                                                
        ,ATTRIBUTE17                                                                                                                
        ,ATTRIBUTE18                                                                                                                
        ,ATTRIBUTE19                                                                                                                
        ,ATTRIBUTE20                                                                                                                
        ,ATTRIBUTE21                                                                                                                
        ,ATTRIBUTE22                                                                                                                
        ,ATTRIBUTE23                                                                                                                
        ,ATTRIBUTE24                                                                                                                
        ,ATTRIBUTE25                                                                                                                
        ,ORG_ID                                                                                                                     
        ,CUSTOMER_ID                                                                                                                
        ,BILL_SITE_USE_ID                                                                                                           
        ,SHIP_SITE_USE_ID)                                                                                                          
         select myNOrder                                  -- ORDERNO                                                                
               ,CUST                                                                                                                
     -- CUST                                                                                                                        
               ,CUSTNAME                                  -- CUST                                                                   
NAME                                                                                                                                
               ,myCustPO                                  -- CUSTPO                                                                 
               ,RELEASE                                                                                                             
 -- RELEASE                                                                                                                         
               ,DATERCV                                   -- DATER                                                                  
CV                                                                                                                                  
               ,DATEENT                                   -- DATEENT                                                                
               ,DATEINS                                                                                                             
-- DATEINS                                                                                                                          
               ,DATETRN                                   -- DATETR                                                                 
N                                                                                                                                   
               ,ROAR                                      -- ROAR                                                                   
               ,CUSTBOX                                   -- C                                                                      
USTBOX                                                                                                                              
               ,UNPACKER                                  -- UNPACKER                                                               
               ,RECEIVER                                                                                                            
     -- RECEIVER                                                                                                                    
               ,INSPECTOR                                 --                                                                        
INSPECTOR                                                                                                                           
               ,CUSTREP                                   -- CUSTREP                                                                
                                                                                                                                    
               ,DROP_SHIP                                 -- DROP_SHIP                                                              
               ,SHIP_VIA                                                                                                            
-- SHIP_VIA                                                                                                                         
               ,SHIP_NAME                                 -- SHIP_                                                                  
NAME                                                                                                                                
               ,SHIP_ATTN                                 -- SHIP_ATTN                                                              
               ,SHIP_ST1                                                                                                            
    -- SHIP_ST1                                                                                                                     
               ,SHIP_ST2                                  -- S                                                                      
HIP_ST2                                                                                                                             
               ,SHIP_CITY                                 -- SHIP_CITY                                                              
                                                                                                                                    
               ,SHIP_STATE                                -- SHIP_STATE                                                             
               ,SHIP_ZIP                                                                                                            
 -- SHIP_ZIP                                                                                                                        
               ,COD                                       -- COD                                                                    
               ,HOLD_CODE                                                                                                           
      -- HOLD_CODE                                                                                                                  
               ,SHIPTO                                    -                                                                         
- SHIPTO                                                                                                                            
               ,ORDTYPE                                   -- ORDTYPE                                                                
               ,DISC_FLAG                                                                                                           
      -- DISC_FLAG                                                                                                                  
               ,TRANSFER                                  -                                                                         
- TRANSFER                                                                                                                          
               ,REJECTS                                   -- REJECT                                                                 
S                                                                                                                                   
               ,REASON                                    -- REASON                                                                 
               ,PARTIAL_SHP                               --                                                                        
 PARTIAL_SHP                                                                                                                        
               ,REGION                                    -- REGI                                                                   
ON                                                                                                                                  
               ,AGENT                                     -- AGENT                                                                  
               ,CLASS                                     --                                                                        
 CLASS                                                                                                                              
               ,TLM                                       -- TLM                                                                    
               ,myCmt                                                                                                               
-- COMMENTS                                                                                                                         
               ,RMA                                       -- RMA                                                                    
               ,PLANT                                                                                                               
     -- PLANT                                                                                                                       
               ,TYPE                                      -- TYP                                                                    
E                                                                                                                                   
               ,EXCHANGE                                  -- EXCHANGE                                                               
               ,DRIVER                                                                                                              
-- DRIVER                                                                                                                           
               ,SHIPTO_LOC_CODE                           -- SHIPTO_                                                                
LOC_CODE                                                                                                                            
               ,SHIPTO_SITE_CODE                          -- SHIPTO_S                                                               
ITE_CODE                                                                                                                            
               ,CLOSED_FLAG                               -- CLOSED_F                                                               
LAG                                                                                                                                 
               ,FREIGHT_QUOTE                             -- FREIGHT_QUOTE                                                          
                                                                                                                                    
               ,CREDIT_CARD_TYPE                          -- CREDIT_CARD_TYPE                                                       
                                                                                                                                    
               ,CREDIT_CARD_NAME                          -- CREDIT_CARD_NAME                                                       
                                                                                                                                    
               ,CREDIT_CARD_ACCT                          -- CREDIT_CARD_ACCT                                                       
                                                                                                                                    
               ,CREDIT_CARD_EXP                           -- CREDIT_CARD_EXP                                                        
               ,SATURDAY_DELIVERY                                                                                                   
      -- SATURDAY_DELIVERY                                                                                                          
               ,LEAD_ID                                   -- LEAD_ID                                                                
               ,CUST_EXCHANGE                             --                                                                        
 CUST_EXCHANGE                                                                                                                      
               ,COUNTRY                                   -- CO                                                                     
UNTRY                                                                                                                               
               ,ORDER_SOURCE                                                                                                        
               ,CREDIT_CARD_APPROVAL                      -- CREDIT_C                                                               
ARD_APPROVAL                                                                                                                        
               ,ATTRIBUTE_CATEGORY                        -- ATTR                                                                   
IBUTE_CATEGORY                                                                                                                      
               ,ATTRIBUTE1                                -- AT                                                                     
TRIBUTE1                                                                                                                            
               ,ATTRIBUTE2                                -- ATTRIBUT                                                               
E2                                                                                                                                  
               ,ATTRIBUTE3                                -- ATTRIBUTE3                                                             
               ,ATTRIBUTE4                                                                                                          
   -- ATTRIBUTE4                                                                                                                    
               ,ATTRIBUTE5                                --                                                                        
ATTRIBUTE5                                                                                                                          
               ,ATTRIBUTE6                                -- ATTRIB                                                                 
UTE6                                                                                                                                
               ,ATTRIBUTE7                                -- ATTRIBUTE7                                                             
               ,ATTRIBUTE8                                                                                                          
     -- ATTRIBUTE8                                                                                                                  
               ,ATTRIBUTE9                                -                                                                         
- ATTRIBUTE9                                                                                                                        
               ,ATTRIBUTE10                               -- ATTR                                                                   
IBUTE10                                                                                                                             
               ,ATTRIBUTE11                                                                                                         
               ,ATTRIBUTE12                                                                                                         
               ,ATTRIBUTE13                                                                                                         
               ,ATTRIBUTE14                                                                                                         
               ,ATTRIBUTE15                                                                                                         
               ,ATTRIBUTE16                                                                                                         
               ,ATTRIBUTE17                                                                                                         
               ,ATTRIBUTE18                                                                                                         
               ,ATTRIBUTE19                                                                                                         
               ,ATTRIBUTE20                                                                                                         
               ,ATTRIBUTE21                                                                                                         
               ,ATTRIBUTE22                                                                                                         
               ,ATTRIBUTE23                                                                                                         
               ,ATTRIBUTE24                                                                                                         
               ,ATTRIBUTE25                                                                                                         
               ,ORG_ID                                    -- ORG_I                                                                  
D                                                                                                                                   
               ,CUSTOMER_ID                               -- CUSTOMER_ID                                                            
               ,BILL_SITE_USE_ID                                                                                                    
   -- BILL_SITE_USE_ID                                                                                                              
               ,SHIP_SITE_USE_ID                                                                                                    
   -- SHIP_SITE_USE_ID                                                                                                              
         from   DEX_ORDERS                                                                                                          
         where  ORDERNO = myOrder;                                                                                                  
                                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'ChgPO - c1 Loop';                                                                                                  
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         if myTQty < 1 then                                                                                                         
            exit;                                                                                                                   
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'ChgPO - Find Line';                                                                                             
                                                                                                                                    
         begin                                                                                                                      
            select ITEM                                                                                                             
            into   myNItem                                                                                                          
            from   DEX_LINES                                                                                                        
            where  ORDERNO            = myNOrder                                                                                    
            and    CUSTPART           = myCPart                                                                                     
            and    INVENTORY_ITEM_ID  = c1r.INVENTORY_ITEM_ID                                                                       
            and    STATUS in ('O','F')                                                                                              
            and    rownum < 2;                                                                                                      
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myNItem := 0;                                                                                                        
         end;                                                                                                                       
                                                                                                                                    
         dbms_output.put_line ( 'NItem: ' || myNItem || ' Order:                                                                    
 ' || myNOrder );                                                                                                                   
                                                                                                                                    
         if myNItem = 0 then                                                                                                        
            log;                                                                                                                    
            mySect := 'ChgPO - Last Line';                                                                                          
                                                                                                                                    
            myCmt := c1r.COMMENTS;                                                                                                  
                                                                                                                                    
            select nvl(max(ITEM),0) + 1                                                                                             
            into   myNItem                                                                                                          
            from   DEX_LINES                                                                                                        
            where  ORDERNO = myNOrder;                                                                                              
                                                                                                                                    
            if myNItem > 999 then                                                                                                   
               RAISE_APPLICATION_ERROR ( -20001,'Order: ' || myOrder || ' h                                                         
as 999 Line Items' );                                                                                                               
            end if;                                                                                                                 
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'ChgPO - Insert DEX_LINES';                                                                                   
                                                                                                                                    
            insert into DEX_LINES                                                                                                   
           (ORDERNO                                                                                                                 
           ,ITEM                                                                                                                    
           ,CUSTITEM                                                                                                                
           ,PART                                                                                                                    
           ,CUSTPART                                                                                                                
           ,DESCRIPTION                                                                                                             
           ,DATESCH                                                                                                                 
           ,STATCODE                                                                                                                
           ,COMMENTS                                                                                                                
           ,SERIALCTL                                                                                                               
           ,PRICE                                                                                                                   
           ,QTYORG                                                                                                                  
           ,GRP                                                                                                                     
           ,HOLD_CODE                                                                                                               
           ,MFG                                                                                                                     
           ,SHIP_EARLY                                                                                                              
           ,INFO                                                                                                                    
           ,INFO2                                                                                                                   
           ,INFO3                                                                                                                   
           ,INFO4                                                                                                                   
           ,INV_MGMT                                                                                                                
           ,DOA                                                                                                                     
           ,FAILANAL                                                                                                                
           ,SWAP                                                                                                                    
           ,RMA_FLAG                                                                                                                
           ,REQUISITION_NUMBER                                                                                                      
           ,LINE_LOCATION_ID                                                                                                        
           ,NOTE_TO_BUYER_ID                                                                                                        
           ,STATUS                                                                                                                  
           ,STORE                                                                                                                   
           ,ORIG_CUST_PART                                                                                                          
           ,INVENTORY_ITEM_ID                                                                                                       
           ,ORGANIZATION_ID                                                                                                         
           ,GROUP_ID                                                                                                                
           ,CUSTOMER_ITEM_ID                                                                                                        
           ,SUBINVENTORY_CODE                                                                                                       
           ,HOLD_ID                                                                                                                 
           ,MAX_PRICE                                                                                                               
           ,COST                                                                                                                    
           ,REFERENCE_ORDER                                                                                                         
           ,REFERENCE_ITEM                                                                                                          
           ,REFERENCE_CUSTITEM                                                                                                      
           ,USE_MAX_PRICE_FLAG                                                                                                      
           ,CALC_FEE_PCT                                                                                                            
           ,BOX_KIT_ITEM_ID                                                                                                         
           ,REPOST_CODE                                                                                                             
           ,REPOST_TIMES                                                                                                            
           ,REPOST_DATE                                                                                                             
           ,UOM                                                                                                                     
           ,LAST_UPDATE_DATE                                                                                                        
           ,LAST_UPDATED_BY                                                                                                         
           ,PARTIAL_SHP                                                                                                             
           ,LINE_TYPE                                                                                                               
           ,FEE_TOTAL                                                                                                               
           ,CORE_FLAG                                                                                                               
           ,CORE_PRICE                                                                                                              
           ,CORE_BUY                                                                                                                
           ,FEE_TYPE                                                                                                                
           ,STS_NUMBER                                                                                                              
           ,SERIAL_FLAG                                                                                                             
           ,DIVISION                                                                                                                
           ,BUSINESS                                                                                                                
           ,REPAIR_PLANT_ID                                                                                                         
           ,ATTRIBUTE_CATEGORY                                                                                                      
           ,ATTRIBUTE1                                                                                                              
           ,ATTRIBUTE2                                                                                                              
           ,ATTRIBUTE3                                                                                                              
           ,ATTRIBUTE4                                                                                                              
           ,ATTRIBUTE5                                                                                                              
           ,ATTRIBUTE6                                                                                                              
           ,ATTRIBUTE7                                                                                                              
           ,ATTRIBUTE8                                                                                                              
           ,ATTRIBUTE9                                                                                                              
           ,ATTRIBUTE10                                                                                                             
           ,ATTRIBUTE11                                                                                                             
           ,ATTRIBUTE12                                                                                                             
           ,ATTRIBUTE13                                                                                                             
           ,ATTRIBUTE14                                                                                                             
           ,ATTRIBUTE15)                                                                                                            
            select myNOrder                                                                                                         
                  ,myNItem                                                                                                          
                  ,CUSTITEM                                                                                                         
                  ,PART                                                                                                             
                  ,CUSTPART                                                                                                         
                  ,DESCRIPTION                                                                                                      
                  ,DATESCH                                                                                                          
                    ,STATCODE                                                                                                       
                  ,myCmt                                                                                                            
                  ,SERIALCTL                                                                                                        
                  ,PRICE                                                                                                            
                  ,0                                                                                                                
                  ,GRP                                                                                                              
                  ,HOLD_CODE                                                                                                        
                  ,MFG                                                                                                              
                  ,SHIP_EARLY                                                                                                       
                  ,INFO                                                                                                             
                  ,INFO2                                                                                                            
                  ,INFO3                                                                                                            
                  ,INFO4                                                                                                            
                  ,INV_MGMT                                                                                                         
                  ,DOA                                                                                                              
                  ,FAILANAL                                                                                                         
                  ,SWAP                                                                                                             
                  ,RMA_FLAG                                                                                                         
                  ,REQUISITION_NUMBER                                                                                               
                  ,LINE_LOCATION_ID                                                                                                 
                  ,NOTE_TO_BUYER_ID                                                                                                 
                  ,STATUS                                                                                                           
                  ,STORE                                                                                                            
                  ,ORIG_CUST_PART                                                                                                   
                  ,INVENTORY_ITEM_ID                                                                                                
                  ,ORGANIZATION_ID                                                                                                  
                  ,GROUP_ID                                                                                                         
                  ,CUSTOMER_ITEM_ID                                                                                                 
                  ,SUBINVENTORY_CODE                                                                                                
                  ,HOLD_ID                                                                                                          
                  ,MAX_PRICE                                                                                                        
                  ,COST                                                                                                             
                  ,REFERENCE_ORDER                                                                                                  
                  ,REFERENCE_ITEM                                                                                                   
                  ,REFERENCE_CUSTITEM                                                                                               
                  ,USE_MAX_PRICE_FLAG                                                                                               
                  ,CALC_FEE_PCT                                                                                                     
                  ,BOX_KIT_ITEM_ID                                                                                                  
                  ,REPOST_CODE                                                                                                      
                  ,REPOST_TIMES                                                                                                     
                  ,REPOST_DATE                                                                                                      
                  ,UOM                                                                                                              
                  ,SYSDATE              -- LAST_UPDATE_DATE                                                                         
                  ,LAST_UPDATED_BY                                                                                                  
                  ,PARTIAL_SHP                                                                                                      
                  ,LINE_TYPE                                                                                                        
                  ,FEE_TOTAL                                                                                                        
                  ,CORE_FLAG                                                                                                        
                  ,CORE_PRICE                                                                                                       
                  ,CORE_BUY                                                                                                         
                  ,FEE_TYPE                                                                                                         
                  ,STS_NUMBER                                                                                                       
                  ,SERIAL_FLAG                                                                                                      
                  ,DIVISION                                                                                                         
                  ,BUSINESS                                                                                                         
                  ,REPAIR_PLANT_ID                                                                                                  
                  ,ATTRIBUTE_CATEGORY                                                                                               
                  ,ATTRIBUTE1                                                                                                       
                  ,ATTRIBUTE2                                                                                                       
                  ,ATTRIBUTE3                                                                                                       
                  ,ATTRIBUTE4                                                                                                       
                  ,ATTRIBUTE5                                                                                                       
                  ,ATTRIBUTE6                                                                                                       
                  ,ATTRIBUTE7                                                                                                       
                  ,ATTRIBUTE8                                                                                                       
                  ,ATTRIBUTE9                                                                                                       
                  ,ATTRIBUTE10                                                                                                      
                  ,ATTRIBUTE11                                                                                                      
                  ,ATTRIBUTE12                                                                                                      
                  ,ATTRIBUTE13                                                                                                      
                  ,ATTRIBUTE14                                                                                                      
                  ,ATTRIBUTE15                                                                                                      
            from   DEX_LINES                                                                                                        
            where  ORDERNO = myOrder                                                                                                
            and    ITEM    = c1r.ITEM;                                                                                              
                                                                                                                                    
            if myOrdType in ('R','H') then                                                                                          
               log;                                                                                                                 
               mySect := 'ChgPO - Job Open';                                                                                        
                                                                                                                                    
               K_WIP_JOB.JOB_OPEN ( myNOrder,myNItem );                                                                             
            end if;                                                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         select nvl(max(UNIQUENO),0) + 1                                                                                            
         into   myUnique                                                                                                            
         from   DEX_SERIALS                                                                                                         
         where  ORDERNO = myNOrder                                                                                                  
         and    ITEM    = myNItem;                                                                                                  
                                                                                                                                    
         for c2r in c2 ( c1r.ITEM ) loop                                                                                            
            log;                                                                                                                    
            mySect := 'ChgPO - Update Serial';                                                                                      
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            ORDERNO = myNOrder                                                                                                      
           ,ITEM    = myNItem                                                                                                       
           ,UNIQUENO = myUnique                                                                                                     
            where SERIAL_ID = c2r.SERIAL_ID;                                                                                        
                                                                                                                                    
            myUnique := myUnique + 1;                                                                                               
                                                                                                                                    
            myTQty := myTQty - 1;                                                                                                   
            if myTQty < 1 then                                                                                                      
               exit;                                                                                                                
            end if;                                                                                                                 
         end loop;                                                                                                                  
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'ChgPO - Update Qty New';                                                                                        
                                                                                                                                    
         update DEX_LINES set                                                                                                       
         QTYORG =                                                                                                                   
            (select count('*')                                                                                                      
             from   DEX_SERIALS                                                                                                     
             where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                         
             and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM)                                                                           
                                                                                                                                    
        ,QTYSCR =                                                                                                                   
            (select count('*')                                                                                                      
             from   DEX_SERIALS                                                                                                     
             where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                         
             and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM                                                                            
             and    DEX_SERIALS.SCRAP   = 'Y')                                                                                      
         where ORDERNO = myNOrder                                                                                                   
         and   ITEM    = myNItem;                                                                                                   
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'ChgPO - Update Qty Old';                                                                                        
                                                                                                                                    
         update DEX_LINES set                                                                                                       
         QTYORG =                                                                                                                   
            (select count('*')                                                                                                      
             from   DEX_SERIALS                                                                                                     
             where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                         
             and    DEX_SERIALS.ITEM    = DEX_LINES.                                                                                
ITEM)                                                                                                                               
        ,QTYSCR =                                                                                                                   
            (select count('*')                                                                                                      
             from   DEX_SERIALS                                                                                                     
             where  DEX_SERIALS.ORDERNO = DEX_LINES.ORDERNO                                                                         
             and    DEX_SERIALS.ITEM    = DEX_LINES.ITEM                                                                            
             and    DEX_SERIALS.SCRAP   = 'Y')                                                                                      
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = c1r.ITEM;                                                                                                  
                                                                                                                                    
         if c1r.FEE_TOTAL is not null then                                                                                          
            mySect := 'ChgPO - Fee Total (Old)';                                                                                    
                                                                                                                                    
            update DEX_LINES lne set                                                                                                
            FEE_TOTAL =                                                                                                             
              (select nvl(sum(FEE),0)                                                                                               
               from   DEX_SERIAL_FEES dsf                                                                                           
                     ,SERIALS ser                                                                                                   
               where  ser.SERIAL_ID = dsf.SERIAL_ID                                                                                 
               and    ser.ORDERNO   = lne.ORDERNO                                                                                   
               and    ser.ITEM      = lne.ITEM                                                                                      
               and    dsf.BILL_FLAG is null)                                                                                        
            where ORDERNO = myOrder                                                                                                 
            and   ITEM    = c1r.ITEM;                                                                                               
                                                                                                                                    
            mySect := 'ChgPO - Fee Total (New)';                                                                                    
                                                                                                                                    
            update DEX_LINES lne set                                                                                                
            FEE_TOTAL =                                                                                                             
              (select nvl(sum(FEE),0)                                                                                               
               from   DEX_SERIAL_FEES dsf                                                                                           
                     ,SERIALS ser                                                                                                   
               where  ser.SERIAL_ID = dsf.SERIAL_ID                                                                                 
               and    ser.ORDERNO   = lne.ORDERNO                                                                                   
               and    ser.ITEM      = lne.ITEM                                                                                      
               and    dsf.BILL_FLAG is null)                                                                                        
            where ORDERNO = myNOrder                                                                                                
            and   ITEM    = myNItem;                                                                                                
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      if myTQty > 0 then                                                                                                            
         myRetMesg := 'All Qty Not Moved - Qty Remn: ' || to_char(myTQty)                                                           
;                                                                                                                                   
         myRetCode := 1;                                                                                                            
                                                                                                                                    
         rollback;                                                                                                                  
                                                                                                                                    
         return;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'ChgPO - Complete';                                                                                                 
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         rollback;                                                                                                                  
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
         myRetCode := 2;                                                                                                            
                                                                                                                                    
   end CHANGE_PO;                                                                                                                   
                                                                                                                                    
   /*************************************************************************                                                       
****************************/                                                                                                       
                                                                                                                                    
   procedure SERL_CUST (                                                                                                            
                         myRetMesg      out  varchar2                                                                               
                        ,myRetCode      out  number                                                                                 
                        ,myNOrder    in out  varchar2                                                                               
                        ,myNCust     in      varchar2                                                                               
                        ,myTranID    in      number                                                                                 
                       ) is                                                                                                         
      myCmt       DEX_ORDERS.COMMENTS%type;                                                                                         
                                                                                                                                    
      myNItem     pls_integer;                                                                                                      
      myUnique    pls_integer;                                                                                                      
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select ord.CUST                                                                                                            
               ,ord.CUSTPO                                                                                                          
               ,ord.RELEASE                                                                                                         
               ,ord.CUSTOMER_ID                                                                                                     
               ,ord.ORG_ID                                                                                                          
               ,lne.ORDERNO                                                                                                         
               ,lne.ITEM                                                                                                            
               ,lne.CUSTPART                                                                                                        
               ,lne.DATESCH                                                                                                         
               ,lne.STATCODE                                                                                                        
               ,lne.PRICE                                                                                                           
               ,lne.INVENTORY_ITEM_ID                                                                                               
               ,lne.COMMENTS                                                                                                        
               ,lne.FEE_TOTAL                                                                                                       
               ,ser.SERIAL_ID                                                                                                       
         from   DEX_ORDERS ord                                                                                                      
               ,LINES lne                                                                                                           
               ,SERIALS ser                                                                                                         
         where  ser.ORDERNO = lne.ORDERNO                                                                                           
         and    ser.ITEM    = lne.ITEM                                                                                              
         and    ser.ORDERNO = ord.ORDERNO                                                                                           
         and    ser.TRAN_ID = myTranID                                                                                              
         order by 2,3,5;                                                                                                            
                                                                                                                                    
   begin                                                                                                                            
      mySect := 'SerlCust - Start';                                                                                                 
      log;                                                                                                                          
      mySect := 'SerlCust - c1 loop';                                                                                               
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         log;                                                                                                                       
         mySect := 'SerlCust - Find';                                                                                               
                                                                                                                                    
         begin                                                                                                                      
            select ORDERNO                                                                                                          
            into   myNOrder                                                                                                         
            from   DEX_ORDERS                                                                                                       
            where  CUST    = myNCust                                                                                                
            and    CUSTPO  = c1r.CUSTPO                                                                                             
            and    RELEASE = c1r.RELEASE;                                                                                           
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myNOrder := null;                                                                                                    
         end;                                                                                                                       
                                                                                                                                    
         if myNOrder is null then                                                                                                   
            log;                                                                                                                    
            mySect := 'SerlCust - Order';                                                                                           
                                                                                                                                    
            myNOrder := F_ORDER_CHECK;                                                                                              
                                                                                                                                    
            insert into DEX_ORDERS                                                                                                  
           (ORDERNO                                                                                                                 
           ,CUST                                                                                                                    
           ,CUSTNAME                                                                                                                
           ,CUSTPO                                                                                                                  
           ,RELEASE                                                                                                                 
           ,DATERCV                                                                                                                 
           ,DATEENT                                                                                                                 
           ,DATEINS                                                                                                                 
           ,DATETRN                                                                                                                 
           ,ROAR                                                                                                                    
           ,CUSTBOX                                                                                                                 
           ,UNPACKER                                                                                                                
           ,RECEIVER                                                                                                                
           ,INSPECTOR                                                                                                               
           ,CUSTREP                                                                                                                 
           ,DROP_SHIP                                                                                                               
           ,SHIP_VIA                                                                                                                
           ,SHIP_NAME                                                                                                               
           ,SHIP_ATTN                                                                                                               
           ,SHIP_ST1                                                                                                                
           ,SHIP_ST2                                                                                                                
           ,SHIP_CITY                                                                                                               
           ,SHIP_STATE                                                                                                              
           ,SHIP_ZIP                                                                                                                
           ,COD                                                                                                                     
           ,HOLD_CODE                                                                                                               
           ,SHIPTO                                                                                                                  
           ,ORDTYPE                                                                                                                 
           ,DISC_FLAG                                                                                                               
           ,TRANSFER                                                                                                                
           ,REJECTS                                                                                                                 
           ,REASON                                                                                                                  
           ,PARTIAL_SHP                                                                                                             
           ,REGION                                                                                                                  
           ,AGENT                                                                                                                   
           ,CLASS                                                                                                                   
           ,TLM                                                                                                                     
           ,COMMENTS                                                                                                                
           ,RMA                                                                                                                     
           ,PLANT                                                                                                                   
           ,TYPE                                                                                                                    
           ,EXCHANGE                                                                                                                
           ,DRIVER                                                                                                                  
           ,SHIPTO_LOC_CODE                                                                                                         
           ,SHIPTO_SITE_CODE                                                                                                        
           ,CLOSED_FLAG                                                                                                             
           ,FREIGHT_QUOTE                                                                                                           
           ,CREDIT_CARD_TYPE                                                                                                        
           ,CREDIT_CARD_NAME                                                                                                        
           ,CREDIT_CARD_ACCT                                                                                                        
           ,CREDIT_CARD_EXP                                                                                                         
           ,SATURDAY_DELIVERY                                                                                                       
           ,LEAD_ID                                                                                                                 
           ,CUST_EXCHANGE                                                                                                           
           ,COUNTRY                                                                                                                 
           ,ORDER_SOURCE                                                                                                            
           ,CREDIT_CARD_APPROVAL                                                                                                    
           ,ATTRIBUTE_CATEGORY                                                                                                      
           ,ATTRIBUTE1                                                                                                              
           ,ATTRIBUTE2                                                                                                              
           ,ATTRIBUTE3                                                                                                              
           ,ATTRIBUTE4                                                                                                              
           ,ATTRIBUTE5                                                                                                              
           ,ATTRIBUTE6                                                                                                              
           ,ATTRIBUTE7                                                                                                              
           ,ATTRIBUTE8                                                                                                              
           ,ATTRIBUTE9                                                                                                              
           ,ATTRIBUTE10                                                                                                             
           ,ATTRIBUTE11                                                                                                             
           ,ATTRIBUTE12                                                                                                             
           ,ATTRIBUTE13                                                                                                             
           ,ATTRIBUTE14                                                                                                             
           ,ATTRIBUTE15                                                                                                             
           ,ATTRIBUTE16                                                                                                             
           ,ATTRIBUTE17                                                                                                             
           ,ATTRIBUTE18                                                                                                             
           ,ATTRIBUTE19                                                                                                             
           ,ATTRIBUTE20                                                                                                             
           ,ATTRIBUTE21                                                                                                             
           ,ATTRIBUTE22                                                                                                             
           ,ATTRIBUTE23                                                                                                             
           ,ATTRIBUTE24                                                                                                             
           ,ATTRIBUTE25                                                                                                             
           ,ORG_ID                                                                                                                  
           ,CUSTOMER_ID                                                                                                             
           ,BILL_SITE_USE_ID                                                                                                        
           ,SHIP_SITE_USE_ID)                                                                                                       
            select myNOrder                                      -- O                                                               
RDERNO                                                                                                                              
                  ,shp.CUST                                      -- CUS                                                             
T                                                                                                                                   
                  ,rac.CUSTOMER_NAME                             -- CUSTNAME                                                        
                                                                                                                                    
                  ,ord.CUSTPO                                    -- CUSTPO                                                          
                  ,ord.RELEASE                                                                                                      
           -- RELEASE                                                                                                               
                  ,ord.DATERCV                                                                                                      
         -- DATERCV                                                                                                                 
                  ,ord.DATEENT                                                                                                      
       -- DATEENT                                                                                                                   
                  ,ord.DATEINS                                                                                                      
     -- DATEINS                                                                                                                     
                  ,ord.DATETRN                                                                                                      
   -- DATETRN                                                                                                                       
                  ,ord.ROAR                                                                                                         
 -- ROAR                                                                                                                            
                  ,ord.CUSTBOX                                   -- C                                                               
USTBOX                                                                                                                              
                  ,ord.UNPACKER                                  -- UNP                                                             
ACKE                                                                                                                                
                                                                                                                                    

