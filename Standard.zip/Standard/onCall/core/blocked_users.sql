set verify off
set feedback off
set heading on
COLUMN object_name  FORMAT A30
COLUMN holder       FORMAT A25
COLUMN Waiter       FORMAT A25
Accept lock_type char prompt 'Enter Lock_type [TX/TM/ST] :'
ttitle 'Blocking User and Waiting Users'
select /*+ RULE */  distinct o.object_name, sh.username||'('||sh.sid||','||sh.SERIAL#||')' "Holder",
        sw.username||'('||sw.sid||','||sw.SERIAL#||')' "Waiter",
        decode(lh.lmode, 1, 'null', 2,
              'row share', 3, 'row exclusive', 4,  'share',
              5, 'share row exclusive' , 6, 'exclusive')  "Lock Type"
  from v$session sw, v$lock lw,all_objects o,  v$session sh, v$lock lh
 where lh.id1  = o.object_id
  and  lh.id1  = lw.id1
  and  sh.sid  = lh.sid
  and  sw.sid  = lw.sid
  and  sh.lockwait is null
  and  sw.lockwait is not null
--  and  lh.type = '&lock_type'
--  and  lw.type = '&lock_type';
ttitle off
