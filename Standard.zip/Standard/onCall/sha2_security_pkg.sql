select s.username,s.sql_hash_value, t.sql_text, s.last_call_et
from v$session s , v$sqltext t
where s.username = 'APPLSYSPUB'
and s.sql_hash_value= t.hash_value
and t.sql_text like  '%fnd_security_pkg.fnd_encrypted_pwd%'
/
