select fpo.PROFILE_OPTION_ID,fpo.PROFILE_OPTION_name,user_profile_option_name,PROFILE_OPTION_VALUE
    from apps.fnd_profile_options fpo, apps.fnd_profile_option_values fpv, apps.fnd_profile_options_tl fpt
    where fpo.PROFILE_OPTION_ID= fpv.PROFILE_OPTION_ID
   and upper(PROFILE_OPTION_VALUE) like upper('%&prof_value%') and
   fpt.profile_option_name=fpo.profile_option_name
/
