set linesize 120
set pagesize 120

col node_name format a15
col node_name2 format a15

select node_name, node_name2, sum(RUNNING_PROCESSES)
from apps.fnd_concurrent_queues
where CONTROL_CODE is null
and enabled_flag = 'Y'
group by node_name, node_name2
/


select node_name, db_instance, count(*)
from apps.FND_CONCURRENT_PROCESSES a
where 1=1
and process_status_code = 'A'
group by node_name, db_instance
/
