#!/bin/ksh

sqlplus -s '/ as sysdba' <<EOF

set pagesize 1000 lines 180
set space 1
column user_concurrent_program_name format a45 trunc
column request format 9999999999
column total_time format 99,999.99
column start_time format a14
column node_name format a8 noprint
column queue_name  format a29 trunc
column event  format a29 trunc
spool cr.lst
select c.inst_id,r.request_id request,p.user_concurrent_program_name,
       round(((sysdate-actual_start_date)*24*60*60/60),2) Total_Time,
--       (actual_start_date-request_date)*24*60*60 Lag,
       to_char(actual_start_date, 'MM/DD/YY HH24:MI') start_time,
       q.user_concurrent_queue_name queue_name,d.event
from applsys.fnd_concurrent_queues_tl q,applsys.fnd_concurrent_processes cp, applsys.fnd_concurrent_programs_tl p, applsys.fnd_concurrent_requests r, gv\$process c, gv\$session d
where status_code = 'R'
and p.application_id = r.program_application_id
and r.concurrent_program_id = p.concurrent_program_id
and cp.CONCURRENT_PROCESS_ID = r.controlling_manager
and cp.QUEUE_APPLICATION_ID = q.application_id
and cp.CONCURRENT_QUEUE_ID = q.CONCURRENT_QUEUE_ID
and c.spid=r.oracle_process_id
and d.inst_id=c.inst_id
and c.addr=d.paddr
group by r.request_id,
         p.user_concurrent_program_name,
	 actual_start_date,request_date,
         q.user_concurrent_queue_name,c.inst_id,d.event
order by 4 desc;
spool off
EOF
