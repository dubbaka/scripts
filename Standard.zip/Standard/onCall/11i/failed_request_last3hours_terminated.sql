SELECT fcr.request_id,
           fu.user_name,
           fcp.user_concurrent_program_name,
           TO_CHAR (fcr.actual_start_date, 'DD-MON-YYYY HH24:MI:SS') actual_start_date,
           TO_CHAR (fcr.actual_completion_date, 'DD-MON-YYYY HH24:MI:SS') actual_completion_date
      FROM apps.fnd_concurrent_requests fcr,
           apps.fnd_concurrent_programs_tl fcp,
           apps.fnd_user fu
     WHERE     fcr.program_application_id = fcp.application_id
           AND fcr.concurrent_program_id = fcp.concurrent_program_id
           AND fcr.requested_by = fu.user_id
           AND fcr.phase_code = 'X'
           AND fcr.status_code = 'E'
           AND fcr.actual_start_date >= sysdate - 180/(24*60)
ORDER BY 1;
