select distinct request_id,
fu.user_name,
fcpt.USER_CONCURRENT_PROGRAM_NAME  Name, 
decode(status_code,'Q','STANDBY', status_code) Standby, 
decode(phase_code,'P','PENDING', phase_code) pending, REQUEST_DATE,
REQUESTED_START_DATE,
ACTUAL_START_DATE,
ACTUAL_COMPLETION_DATE,
CONTROLLING_MANAGER  
from apps.fnd_concurrent_requests fcr, 
apps.fnd_user fu, 
apps.fnd_concurrent_programs_tl fcpt
where status_code='Q' 
and phase_code='P' 
--and fu.user_name = 'FREDERICKG'
and fcpt.CONCURRENT_PROGRAM_ID = fcr.CONCURRENT_PROGRAM_ID
and fcpt.application_id = fcr.PROGRAM_APPLICATION_ID
and fu.user_id=fcr.requested_by
and trunc(REQUEST_DATE)  = trunc(sysdate);
