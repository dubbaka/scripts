declare
ravi boolean ;
begin
 ravi := fnd_user_pkg.changepassword('&user_name', 'WELCOME123');
end ;
/
