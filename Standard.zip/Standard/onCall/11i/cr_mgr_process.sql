set linesize 120
set pagesize 120


col os_process_id format a10
col user_concurrent_queue_name format a30

select b.user_concurrent_queue_name user_concurrent_queue_name
       , a.oracle_process_id sid
       , a.OS_PROCESS_ID
       , a.NODE_NAME
       , a.DB_NAME
       , a.db_instance
from   apps.FND_CONCURRENT_PROCESSES a , apps.fnd_concurrent_queues_tl b
where  a.process_status_code = 'A'
and    a.concurrent_queue_id = b.concurrent_queue_id
and    a.os_process_id like '%&front_end_os_process%'
order by user_concurrent_queue_name
/

