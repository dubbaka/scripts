REM use this select to get the count only
REM Inputs are concurrent program name, phase_code and status_code

select count(*)
from    apps.fnd_concurrent_requests
where concurrent_program_id in (select concurrent_program_id
				from apps.fnd_concurrent_programs
          			where user_concurrent_program_name  like '%&concurrent_prgm_name%')
and phase_code ='&Enter_phase_code'  
and status_code ='&Enter_staus_code'

REM use this update statement only when the apps.fnd_concurrent_program table 
REM has the program name you are looking for
REM Inputs are concurrent program name, phase_code and status_code

update apps.fnd_concurrent_requests
set phase_code ='C', status_code ='D'
where concurrent_program_id in (select concurrent_program_id
				from apps.fnd_concurrent_programs
          			where user_concurrent_program_name  like '%&concurrent_prgm_name%')
and phase_code ='&Enter_phase_code'  
and status_code ='&Enter_staus_code'

REM this is for 11i
update apps.fnd_concurrent_requests
set phase_code ='C', status_code ='D'
where concurrent_program_id in (select concurrent_program_id
				from apps.fnd_concurrent_programs_tl
          			where user_concurrent_program_name  like '%&concurrent_prgm_name%')
and phase_code ='&Enter_phase_code'  
and status_code ='&Enter_staus_code'




REM Use this update statment when program name is not defined as concurrent
REM program in fnd_concurrent_program table but concurrent_program_id is known
REM This concurrent_program_id can be found from apps.fnd_concurrent_requests 
REM for a given request_id

update apps.fnd_concurrent_requests
set phase_code ='C', status_code ='D'
where concurrent_program_id = &enter_concurrent_program_id
and phase_code ='&Enter_phase_code'  
and status_code ='&Enter_staus_code'

                               
