set pagesize 100

col user_name format a10
col user_concurrent_queue_name format a24
col user_concurrent_program_name format a50
select distinct
--u.user_name,
     q.user_concurrent_queue_name
     ,p.user_concurrent_program_name
       --to_char(actual_start_date, 'MM/DD/YY HH24:MI') start_time,
       --q.node_name,concurrent_queue_name queue_name
from apps.fnd_concurrent_queues_tl q,
     apps.fnd_concurrent_processes cp,
     apps.fnd_concurrent_programs_vl p,
     apps.fnd_concurrent_requests r
--     apps.fnd_user u
where q.user_concurrent_queue_name like  '%&Mgr_Name'
--where 1=1
and p.application_id = r.program_application_id
and r.concurrent_program_id = p.concurrent_program_id
and cp.CONCURRENT_PROCESS_ID = r.controlling_manager
and cp.QUEUE_APPLICATION_ID = q.application_id
and cp.CONCURRENT_QUEUE_ID = q.CONCURRENT_QUEUE_ID
--and q.application_id = 704
--and u.user_id = r.requested_by
--and u.user_name != 'MRP_ADMIN'
/

