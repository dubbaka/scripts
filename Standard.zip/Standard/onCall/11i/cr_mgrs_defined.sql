set pagesize 129
set linesize 129
col user_concurrent_queue_name format a50 
 
select a.user_concurrent_queue_name user_concurrent_queue_name,
       b.concurrent_queue_name, 
       b.enabled_flag , 
       b.creation_date
from apps.fnd_concurrent_queues_tl a, apps.fnd_concurrent_queues b
where 1=1
and a.concurrent_queue_id = b.concurrent_queue_id
--and CREATION_DATE > sysdate -3
order by enabled_flag,concurrent_queue_name
/
