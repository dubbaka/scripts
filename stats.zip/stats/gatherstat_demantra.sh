#!/bin/ksh
sys_date=`date +%d_%m_%Y_%H:%M:%S`
export sys_date
PWD=`dirname $0`
export PWD
cd $PWD
if [ $# -lt 1 ]
then
   echo "USAGE : SCRIPT_NAME ORACLE_SID"
   exit 1;
fi
export ORACLE_SID=$1
check_on_os=$(ps -ef | grep pmon | grep -v grep | grep $ORACLE_SID |wc -l)
if [ $check_on_os -ne 1 ]
then
    echo "Attention:CRITICAL:$ORACLE_SID is down" | mailx -s "$ORACLE_SID is down" "sudhirm@fb.com"
    exit 1;
fi
. /usr/local/bin/dbenv $ORACLE_SID
sqlplus "/as sysdba" << EOF
@$PWD/create_gathertablestats_dp_schema100.sql
EOF

if [ -f $PWD/gathertablestats_dp_schema.sql ]
then
                sqlplus "/as sysdba" << EOF
@$PWD/gathertablestats_dp_schema.sql
EOF
        else
        echo "Create Gather Stats script did not executed please check "
        exit 1;
fi

mv $PWD/gathertablestats_dp_schema.sql $PWD/gathertablestats_dp_schema_$sys_date.sql
mv $PWD/gathertablestats_dp_schema.log $PWD/gathertablestats_dp_schema_$sys_date.log

echo "Gather table status for Demantra is completed at $sys_date" | mailx -s "Gather table status for Demantra is completed "sudhirm@fb.com"
~

