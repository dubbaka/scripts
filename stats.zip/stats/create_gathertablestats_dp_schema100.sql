set pages 0
set lines 200
set feed off
spool gathertablestats_dp_schema.sql
prompt spool gathertablestats_dp_schema.log
prompt select to_char(sysdate,'DD-MON-YYYY Dy HH24:MI:SS') from dual;;
prompt set timing on
prompt set echo on
select 'exec DBMS_STATS.GATHER_TABLE_STATS(ownname=>'''||owner||''',tabname=>'''||table_name||''',estimate_percent=>100,block_sample=>TRUE,no_invalidate=>TRUE,degree=>2,cascade=> TRUE );' from dba_tables where owner='DP';
prompt select to_char(sysdate,'DD-MON-YYYY Dy HH24:MI:SS') from dual;;
prompt spool off
spool off
