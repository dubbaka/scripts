!/bin/ksh

#==================================================
# Help Function
#==================================================

script_help()
{
echo "
NAME                : adhoc_schema_analyze.sh
Functionality       : This script will help to analyze schema(s)  in the database.

SYNTAX

    adhoc_schema_analyze.sh                             Options and Arguments:
           -s                                           # Sid Name (Mandatory argument)
           -u                                           # Schema (Mandatory argument, if "-f" is not passed)
           -p                                           # Analyze Percentage. If not passed, will analyze with the existing percentage.
           -d                                           # Degree (If not passed, will analyze with default degree 8)
           -f                                           # If more than one schema to be analyzed, put the details of the tables in a file
                                                          and pass it. Pattern is the file should be as below.(Mandatory argument, if "-o and -t" are not passed)
                                                          <Schema>|<Percentage>|<Degree>

Note:   If the table name or owner consists of '$', please replace the '$' with '\\$' and pass to script.
        For eg., OPS\$ORALCE should be passed as OPS\\\$ORALCE

EXAMPLES:
        ./adhoc_schema_analyze.sh -s OMSPRD1 -u XXFBDBA -p 10 -d 8
        ./adhoc_schema_analyze.sh -s OMSPRD1 -f /net/dba/fbmon/conf/schema2analyze.txt
"
}

Set_Env()
{
WORK_DIR=/net/dba/fbmon
MLOG=$WORK_DIR/log/Custom_Schema_Analyze.log
rm -f $MLOG
touch $MLOG
cat /dev/null > $MLOG

if [ `ps -ef | grep "ora_smon_${ORA_SID}$" | grep -v grep  | wc -l` -eq 0 ]
then
       echo "===========@ Database $ORA_SID seems to be not running or exists on this host. Please check @==========="
        exit
fi

if [ -f /usr/local/bin/dbenv ]
then
        . /usr/local/bin/dbenv $ORA_SID > /dev/null 2>/dev/null
else
        export PATH=$PATH:/usr/local/bin
        export ORACLE_SID=$ORA_SID
        export ORAENV_ASK=NO
        . oraenv
fi

DBSTATUS=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select 'I_AM_OK' from dual;
EOF
)`
if [ "$DBSTATUS " != "I_AM_OK " ]; then
     echo $DBSTATUS
fi

DBVER=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select banner from v\\$version;
EOF
)`

db_ver=`echo $DBVER | grep "Enterprise Edition Release" | awk -F"Release" '{print $2}' | awk -F"." '{print $1}'`
}

Check_Parameters()
{
SCHEMA=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select count(1) from dba_users where upper(username)=upper('${user}') ;
EOF
)`
if [ "$SCHEMA" -ne "1" ]; then
        echo "Schema" $user "does not exists in database" $ORA_SID
fi
export SCHEMA

if [ -z ${percentage} ]; then
percentage=30
fi

if [ -z ${degree} ]; then
degree=8
fi

}

Chk4Errors()
{
##### Checking for errors from analyze spool file #####
if [ `cat $spool_log | grep "ORA-" | wc -l` -gt 0 ]; then
        echo "Analyze of ${towner}"."${tname} errored out. Please check the file $spool_log for more details."
else
        Time=`cat $spool_log | grep "Elapsed" | awk '{print $2}'`
        echo "Analyze of ${towner}"."${tname} completed. Time taken : $Time"
fi
}

Schema_Analyse()
{
spool_log=/tmp/${user}_${ORA_SID}.log
export spool_log
rm -f $spool_log
sqlplus -s "/ as sysdba"<<EOF > /dev/null
set time on timing on feed on echo on
spool $spool_log
set echo on
EXECUTE DBMS_STATS.GATHER_SCHEMA_STATS('${user}', ESTIMATE_PERCENT=>${percentage}, CASCADE=>TRUE, DEGREE=>${degree});
EOF
Chk4Errors;
}

#===============
# MAIN
#===============

########## Reading Parameters ###########

while getopts s:u:p:d:f: OPTNAME
do
[ "$OPTNAME" = "?" ] && exit 1
  case $OPTNAME in
    s)  # Sid
        ORA_SID=${OPTARG};
        ;;
    u)  # Schema
        user=${OPTARG};
        ;;
    p)  # Analyse percentage
        percentage=${OPTARG};
        ;;
    d)  # Degree of Analyze
        degree=${OPTARG};
        ;;
    f) # File containg the schema details
          Schema_details=${OPTARG};
        ;;
   esac
done

if [ -z ${ORA_SID} ]; then
        script_help
        exit
elif [ -z ${Schema_details} ]; then
        if [ -z ${user} ]; then
                script_help
                exit
        fi
fi

Set_Env;

if [ ! -z ${Schema_details} ]; then
   for i in `cat $Schema_details | grep -v ^#`
        do
                user=`echo $i | awk -F"|" '{print $1}'`
                percentage=`echo $i | awk -F"|" '{print $2}'`
                degree=`echo $i | awk -F"|" '{print $3}'`
                Check_Parameters;
                if [ $SCHEMA -eq 1 ] && [ $percentage -ne 0 ]; then
                        Schema_Analyse;
                fi
                echo "Gathter Schema Statistics Started for $user at `date +%x-%X`" >> $MLOG
                cat $spool_log >> $MLOG
                echo "Gathter Schema Statistics Completed for $user at `date +%x-%X`" >> $MLOG
        done
fi
exit

