SELECT USERNAME,
EXPIRY_DATE ,
PROFILE
FROM
(SELECT u.username ,
U.account_status ,
U.profile ,
P.limit AS passwd_exp_limit,
SYU.ptime ,
SYU.ptime + P.limit AS expiry_date
FROM dba_users U,
sys.user$ SYU ,
dba_profiles P
WHERE u.username NOT IN ('SYS', 'SYSTEM', 'OUTLN', 'DIP', 'TSMSYS',
'DBSNMP', 'ORACLE_OCM', 'OPS$ORACLE')
AND SYU.user# = U.user_id
AND u.username NOT LIKE 'OPS$%'
AND p.profile = u.profile
AND p.resource_name = 'PASSWORD_LIFE_TIME'
)
WHERE TRUNC (EXPIRY_DATE) - 30 <= TRUNC(SYSDATE)
AND PROFILE <> 'END_USER';
