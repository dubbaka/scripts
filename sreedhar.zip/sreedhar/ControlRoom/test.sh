#!/bin/sh
#####################################################################################
#
# File name:    conc_req_error_report.sh
# Purpose:      Verify if there are any concurrent requests failed in last hour
#              
#
# Author:      Rajesh Gunda
# Usage:       $ conc_req_error_report.sh
#
# History:
#
# Date                  Who                     Vesion          Details
# ----------            --------                --------        -------------
# 2015/06/24            rajeshgunda             1.0             Initial draft
#
#####################################################################################
#set -x
Set_Env()
{
  GREP="/bin/grep"
  EGREP="/bin/egrep"
  AWK="/bin/awk"
  SED="/bin/sed"
  XARGS="/usr/bin/xargs"
  ECHO="/bin/echo"
  TR="/usr/bin/tr"
  HEAD="/usr/bin/head"
  CAT="/bin/cat"
  WC="/usr/bin/wc"
  TOUCH="/bin/touch"
  TSTMP=`date +%Y%m%d_%H%M%S`
  TAIL="/usr/bin/tail"
  SORT="/bin/sort"
  UNIQ="/usr/bin/uniq"
  PS="/bin/ps"
  HOSTNAME=`/bin/hostname | cut -d. -f1`
  BZIP2="/usr/bin/bzip2"
  BUNZIP2="/usr/bin/bunzip2"
  GZIP="/bin/gzip"
  GUNZIP="/bin/gunzip"
  HOME="/root/dba"
  SUDO="/usr/bin/sudo"
  FILE="/usr/bin/file"
  TEE="/usr/bin/tee"
  LS="/bin/ls"
  WORKDIR="/oraclesw/admin/scripts/Monitoring/FBCop"
  LOGDIR="$WORKDIR/log"
  statefile="$WORKDIR/config/${HOSTNAME}_conc_req_error_report.state"
  LOGFILE="$LOGDIR/${HOSTNAME}_conc_req_error_report_${TSTMP}.log"
  LOCKFILE="$LOGDIR/${HOSTNAME}_conc_req_error_report.lck"
  ERROR_LOG="$LOGDIR/${HOSTNAME}_conc_req_error_report_${TSTMP}.err"
  html_log="$LOGDIR/${HOSTNAME}_conc_req_error_report.html"
  SQLOUT="$LOGDIR/${HOSTNAME}_conc_req_error_report_sql.out"
  TSTMP="`date +%Y%m%d_%H%M`"
  NOTIFY2="rajeshgunda@uber.com"

$ECHO "`date`:$HOSTNAME:conc_req_error_report:[INFO]:Script started" | $TEE -a $LOGFILE
# Below condition is to make sure parallel run of same script is not executed
if [  -f $LOCKFILE ]
  then
    $ECHO "`date`:[conc_req_error_report]:[ERROR]:Lockfile $LOCKFILE found..., Hence exiting..." | $TEE -a $LOGFILE
    exit 1
  else
    $ECHO "`date`:[conc_req_error_report]:[INFO]:Lockfile is placed" | $TEE -a $LOGFILE
    $TOUCH $LOCKFILE
fi

. /usr/local/bin/dbenv OMSPRD1 1>/tmp/1.err 2>&1
if [ "${ORACLE_SID} " == " " ]
then
    $ECHO "`date`:[conc_req_error_report]:[ERROR]: Failed to source environment" | $TEE -a $LOGFILE
    exit 1
fi

export NLS_DATE_FORMAT="DD-MON-YY HH24:MI"
export DBNAME=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select trim(name) from v\\$database;
EOF
)`
}

concurrent_job_details()
{

NOTIFY="rajeshgunda@uber.com"
cat /dev/null > $html_log
sqlplus -s "/ as sysdba"<<EOF
@$WORKDIR/ControlRoom/set_markup.sql
set pages 5000 linesize 1000 feed off
TTITLE CENTER '<h1>AP Job Failures in last 24 hours</h1>' -

spool $html_log
select  distinct program "Concurrent Program Name" , request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  "Run Time(Mins)", actual_completion_date, status_code "Status"
from apps.FND_CONC_REQUESTS_FORM_V
where actual_start_date > sysdate - 1
and status_code = 'K'
and program IN ('Bank Statement Import' || chr(38) || 'AutoReconciliation',
'Bank Statement Loader',
'Batches Available for Reconciliation',
'BPA Child Print Program - Non Emailed Invoices',
'Bursting FB Argentine Payables Withholding Certificate (XML Publisher Report Bursting Program)',
'Run SQL*Loader- BAI2',
'Apply Payments and Create Payment Events (Request Set Stage)',
'Build Payments',
'Create Accounting',
'EN-US: (FB AR Invoice Print Program (BPA))',
'FB AP Holds Mgmt. Create Case',
'FB AP Serengeti AP Invoice Import Request Set (Report Set)',
'FB AP Update TCC on Invoice Lines (15) (Request Set Stage)',
'FB AP Update TCC on Invoice lines',
'FB AU Payments (Payment Process Request Program)',
'FB Attach BPA PDF to Invoice',
'FB BE Payments (Payment Process Request Program)',
'FB CA EFT Payment (Payment Process Request Program)',
'FB DE Payments (Payment Process Request Program)',
'FB ES Payments (Payment Process Request Program)',
'FB FR Payments (Payment Process Request Program)',
'FB Generic AP Bank Acknowledgement Reader',
'FB IT PaymentsÂ  (Payment Process Request Program)',
'FB NZ Payments (Payment Process Request Program)',
'FB PL PaymentsÂ  (Payment Process Request Program)',
'FB Payments ACH Payments (Payment Process Request Program)',
'FB Send Separate Remittance Advices',
'FB Sup ACH Pay-And (Payment Process Request Program)',
'FB Sup ACH Pay-Ops (Payment Process Request Program)',
'FB Sup ACH Pay-Vit (Payment Process Request Program)',
'FB Supplier ACH Payment (Payment Process Request Program)',
'FB: Update Payment Logging Status',
'FBAPINVREJ (Check Periodic Alert)',
'FB AR Invoice Print Program (BPA) (Multiple Languages)',
'Facebook Invoice Validation request set (Request Set Facebook Invoice Validation request set)',
'Facebook Online Invoice Apply and Publish Payments (Report Set)',
'Format Payment Instructions with Text Output',
'Import Transcepta invoices - Facebook Eurozone (Payables Open Interface Import)',
'Import Transcepta invoices - Facebook Japan Operating Unit (Payables Open Interface Import)',
'Import Transcepta invoices - Facebook US (Payables Open Interface Import)',
'Invoice Approval Workflow',
'Invoice Validation',
'Invoice Validation (20) (Request Set Stage)',
'Payment Process Request Program',
'Period Close Exceptions Report (XML)',
'Unaccounted Transactions Report (XML)',
'XXFB AP BofA Payment XML Upload by Payment Instruction',
'XXFB: AP Serengeti Invoices Validation Program',
'Serengeti Invoice Validation (Request Set Stage)',
'FB Global Transcepta Invoice Import Program',
'Receiving Approval',
'Accounting Program')
order by program;
spool off
EOF
	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -eq 0 ]
	then
		sendmail $NOTIFY;
	fi

}


sendmail()
{
NOTIFY=$1
(echo "Subject:`date`:OMEGA:Concurrent requests failed in last 24 hours "
echo "To: $NOTIFY"
echo "Cc: rajeshgunda@uber.com"
echo "MIME-Version: 1.0"
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
cat $html_log
) | /usr/lib/sendmail -t -v > /dev/null

}


############# MAIN ################

Set_Env;
concurrent_job_details;
$ECHO "`date`:[conc_req_error_report]:[INFO]:Removing Lockfile" | $TEE -a $LOGFILE
rm -f $LOCKFILE
