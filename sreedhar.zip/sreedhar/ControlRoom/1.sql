SET MARKUP HTML ON SPOOL ON PREFORMAT OFF ENTMAP ON -
HEAD "<TITLE>Concurrent Requests Submission Report</TITLE> -
<STYLE type='text/css'> -
<!-- BODY {background: #FFFFC6} --> -
</STYLE>" -
BODY "TEXT='#FF00Ff'" -
TABLE "WIDTH='90%' BORDER='5'"
SPOOL report.html
select /*+parallel(fcra,16) */ to_char(actual_start_date,'MM-DD') "Day ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'00',1,0)),'99999') "00 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'01',1,0)),'99999') "01 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'02',1,0)),'99999') "02 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'03',1,0)),'99999') "03 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'04',1,0)),'99999') "04 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'05',1,0)),'99999') "05 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'06',1,0)),'99999') "06 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'07',1,0)),'99999') "07 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'08',1,0)),'99999') "08 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'09',1,0)),'99999') "09 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'10',1,0)),'99999') "10 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'11',1,0)),'99999') "11 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'12',1,0)),'99999') "12 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'13',1,0)),'99999') "13 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'14',1,0)),'99999') "14 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'15',1,0)),'99999') "15 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'16',1,0)),'99999') "16 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'17',1,0)),'99999') "17 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'18',1,0)),'99999') "18 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'19',1,0)),'99999') "19 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'20',1,0)),'99999') "20 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'21',1,0)),'99999') "21 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'22',1,0)),'99999') "22 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'23',1,0)),'99999') "23 ",
count(*) "Total"
from xxuberdba.FND_CONC_REQUESTS_ARCHIVE fcra
where fcra.actual_start_date between (sysdate -14) and (select /*+parallel(a,16) */ max(a.actual_start_date) from xxuberdba.FND_CONC_REQUESTS_ARCHIVE a)
group by to_char(fcra.actual_start_date,'MM-DD')
union
select /*+parallel(fcr,16) */ to_char(actual_start_date,'MM-DD') "day",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'00',1,0)),'99999') "00 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'01',1,0)),'99999') "01 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'02',1,0)),'99999') "02 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'03',1,0)),'99999') "03 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'04',1,0)),'99999') "04 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'05',1,0)),'99999') "05 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'06',1,0)),'99999') "06 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'07',1,0)),'99999') "07 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'08',1,0)),'99999') "08 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'09',1,0)),'99999') "09 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'10',1,0)),'99999') "10 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'11',1,0)),'99999') "11 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'12',1,0)),'99999') "12 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'13',1,0)),'99999') "13 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'14',1,0)),'99999') "14 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'15',1,0)),'99999') "15 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'16',1,0)),'99999') "16 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'17',1,0)),'99999') "17 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'18',1,0)),'99999') "18 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'19',1,0)),'99999') "19 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'20',1,0)),'99999') "20 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'21',1,0)),'99999') "21 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'22',1,0)),'99999') "22 ",
to_char(sum(decode(to_char(actual_start_date,'hh24'),'23',1,0)),'99999') "23 ",
count(*) "Total"
from apps.fnd_concurrent_requests fcr
where fcr.actual_start_date between (select /*+parallel(a,16) */ max(a.actual_start_date+0.004) from xxuberdba.FND_CONC_REQUESTS_ARCHIVE a) and sysdate
group by to_char(actual_start_date,'MM-DD');
spool off
set markup html off spool off
