. $HOME/.PRDSC1

LOGDIR=/home/oracle/rdasari/scripts/uber
DB_Name=PRD
SPOOL_FILE=$LOGDIR/resp_SL.html
FINAL_FILE=$LOGDIR/resp.html
NOW=$(date +"%m-%d-%Y")
MAIL_LIST=rdasari@uber.com

CNT=`ps -ef| grep smon | grep -v grep | grep PRD  | wc -l`
if [ $CNT -ne 1 ]
then
        exit 0;
else

echo "Content-Type: text/html" >> $FINAL_FILE

$ORACLE_HOME/bin/sqlplus "/as sysdba" << EOF_STAT>/dev/null

set termout off
set markup html on spool on 

set echo off
set pages 199
spool $SPOOL_FILE
select fu.user_name,fu.description,frtl.responsibility_name,furgd.start_date user_resp_start_date,furgd.end_date user_resp_end_date,fu.start_date USER_start_date,fu.end_date USER_end_date
from
apps.fnd_user fu,
apps.fnd_responsibility_tl frtl,
apps.fnd_user_resp_groups_direct furgd
where
fu.user_id=furgd.user_id and
frtl.responsibility_id=furgd.responsibility_id and
frtl.responsibility_name='Uber User Administration' and
fu.end_date is null and
furgd.end_date < sysdate
order by 1;
spool off
set markup html off spool off 
set termout on
exit;

EOF_STAT

CNT=`cat $SPOOL_FILE | grep 'no rows selected'`
if [ $? -eq 0 ]
then
        rm $SPOOL_FILE
        rm $FINAL_FILE
        exit 0;

else

cat $SPOOL_FILE | grep -v 'no rows selected' >> $FINAL_FILE

fi

(echo "Subject: $DB_Name: Following users have Uber User Administration Responsibility as of $NOW ";echo "To: $MAIL_LIST"; cat ${FINAL_FILE})  | /usr/sbin/sendmail $MAIL_LIST

rm $SPOOL_FILE
rm $FINAL_FILE

fi
