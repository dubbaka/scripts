. $HOME/.PRDSC1

LOGDIR=/home/oracle/rdasari/scripts/uber
DB_Name=PRD
SPOOL_FILE=$LOGDIR/resp_SL.html
FINAL_FILE=$LOGDIR/resp.html
NOW=$(date +"%m-%d-%Y")
MAIL_LIST=rdasari@uber.com

CNT=`ps -ef| grep smon | grep -v grep | grep PRD  | wc -l`
if [ $CNT -ne 1 ]
then
        exit 0;
else

echo "Content-Type: text/html" >> $FINAL_FILE

$ORACLE_HOME/bin/sqlplus "/as sysdba" << EOF_STAT

set termout off
set markup html on spool on

TTITLE BOLD CENTER 'Users with Uber User Administration Responsibilty'


set lines 300
set pages 300
set verify off
set echo off
set term off
set feed off
set feedback off
spool $SPOOL_FILE

select 
fu.user_name "Name",
fu.description "Full Name",frtl.responsibility_name "Resp Name",
furgd.start_date "Resp Start Date",
furgd.end_date "Resp End Date",
fu.start_date "Start Date",
fu.end_date "Last Date" from 
apps.fnd_user fu, 
apps.fnd_responsibility_tl frtl, 
apps.fnd_user_resp_groups_direct furgd 
where 
fu.user_id=furgd.user_id and 
frtl.responsibility_id=furgd.responsibility_id and 
frtl.responsibility_name='Uber User Administration' and
nvl(furgd.end_date,sysdate+1) > sysdate
order by 1;


spool off
exit;

EOF_STAT

CNT=`cat $SPOOL_FILE | grep 'no rows selected'`
if [ $? -eq 0 ]
then
        rm $SPOOL_FILE
        rm $FINAL_FILE
        exit 0;

else

cat $SPOOL_FILE | grep -v 'no rows selected' >> $FINAL_FILE

fi

(echo "Subject: $DB_Name: Following users have Uber User Administration Responsibility as of $NOW ";echo "To: $MAIL_LIST"; cat ${FINAL_FILE})  | /usr/sbin/sendmail $MAIL_LIST

rm $SPOOL_FILE
rm $FINAL_FILE

fi
