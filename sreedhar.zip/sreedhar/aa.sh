. $HOME/.PRDSC1

LOGDIR=/home/oracle/rdasari/scripts/uber
DB_Name=PRD
SPOOL_FILE=$LOGDIR/resp_SL.html
FINAL_FILE=$LOGDIR/resp.html
NOW=$(date +"%m-%d-%Y")
MAIL_LIST=rdasari@uber.com

CNT=`ps -ef| grep smon | grep -v grep | grep PRD  | wc -l`
if [ $CNT -ne 1 ]
then
        exit 0;
else

echo "Content-Type: text/html" >> $FINAL_FILE

$ORACLE_HOME/bin/sqlplus "/as sysdba" << EOF_STAT

set markup html on spool on

TTITLE BOLD CENTER 'Users with Uber User Administration Responsibilty'
@test.sql> $SPOOL_FILE
spool off;
set markup html off spool off
exit;

EOF_STAT

CNT=`cat $SPOOL_FILE | grep 'no rows selected'`
if [ $? -eq 0 ]
then
        rm $SPOOL_FILE
        rm $FINAL_FILE
        exit 0;

else

cat $SPOOL_FILE | grep -v 'no rows selected' >> $FINAL_FILE

fi

(echo "Subject: $DB_Name: Following users have Uber User Administration Responsibility as of $NOW ";echo "To: $MAIL_LIST"; cat ${FINAL_FILE})  | /usr/sbin/sendmail $MAIL_LIST

rm $SPOOL_FILE
rm $FINAL_FILE

fi
