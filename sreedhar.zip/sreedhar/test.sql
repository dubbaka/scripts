column Time format 99.99
column user_name format A10
column description format A35
column responsibility_name format A20
column Status format A10
Column user_resp_start_date format A10
Column USER_end_date format A10
Column USER_start_date format A10
set lines 300
set pages 300
set verify off

select fu.user_name,fu.description,frtl.responsibility_name,furgd.start_date user_resp_start_date,furgd.end_date user_resp_end_date,fu.start_date USER_start_date,fu.end_date USER_end_date
from
apps.fnd_user fu,
apps.fnd_responsibility_tl frtl,
apps.fnd_user_resp_groups_direct furgd
where
fu.user_id=furgd.user_id and
frtl.responsibility_id=furgd.responsibility_id and
frtl.responsibility_name='Uber User Administration'
order by 1;
