REM cmhist.sql
REM Use this report to tell which concurrent managers are actually being
REM used in an environment and compare to the concurrent managers that 
REM are allocated processes at startup.  This report only reviews completed
REM normal or completed warning concurrent requests.
REM 
REM Deactivate any managers that are not used.
REM 
REM It makes no sense to run this request with a date range greater than
REM what is contained in the fnd_concurrent_requests table.  Therefore,
REM base dates on the purge frequency.
REM
set verify off
set feedback off
set pagesize 59
set linesize 180
set newpage 02
set recsep off
break on report
compute sum of cnt on report
compute sum of elapsed on report
compute sum of waited on report
rem  column today new_value _date noprint;
rem  select to_char(SYSDATE,'DD-MON-YY') today from dual;
rem  ttitle "Concurrent Manager Request Summary  by Manager from: &&begin_date to &&end_date" skip 2;
column waited format 99999999.99 heading 'WAITED|HOURS';
column wstddev format 99999999.99 heading 'WAITED|STDDEV';
column avewait format 9999.99 heading 'AVG.|WAIT';
column concurrent_queue_name format a30 wrap;
column cnt format 999,999 heading 'COUNT';
column elapsed format 99999.99 heading 'TOTAL|HOURS';
column average format 9999.99 heading 'AVG.|HOURS';
set feedback off
select  q.concurrent_queue_name,
        count(*) cnt,
        sum(r.actual_completion_date - r.actual_start_date) * 24 elapsed,
        avg(r.actual_completion_date - r.actual_start_date) * 24 average,
        stddev(actual_start_date - greatest(r.requested_start_date,r.request_date)) * 24 wstddev,
        sum(actual_start_date - greatest(r.requested_start_date,r.request_date)) * 24 waited,
        avg(actual_start_date - greatest(r.requested_start_date,r.request_date)) * 24 avewait
from    apps.fnd_concurrent_programs p, 
        apps.fnd_concurrent_requests r,
        apps.fnd_concurrent_queues q,
        apps.fnd_concurrent_processes p
where   r.program_application_id = p.application_id  
        and r.concurrent_program_id = p.concurrent_program_id  
        and r.phase_code='C' -- completed
        and r.status_code in ('C','G')  -- completed normal or with warning
        and r.controlling_manager=p.concurrent_process_id 
        and q.concurrent_queue_id=p.concurrent_queue_id 
        and r.concurrent_program_id=p.concurrent_program_id 
        and actual_start_date between to_date('&&begin_date') and to_date('&&end_date')
group by  q.concurrent_queue_name
order by 4;
set feedback on;
clear breaks

