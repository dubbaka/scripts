. $HOME/.PRDSC1

LOGDIR=/home/oracle/rdasari/scripts/uber
DB_Name=PRD
SPOOL_FILE=$LOGDIR/Long_Running_Conc_Reqs_SQL.html
FINAL_FILE=$LOGDIR/Long_Running_Conc_Reqs.html
MAIL_LIST=rdasari@uber.com

CNT=`ps -ef| grep smon | grep -v grep | grep PRD  | wc -l`
if [ $CNT -ne 1 ]
then
        exit 0;
else

echo "Content-Type: text/html" >> $FINAL_FILE

$ORACLE_HOME/bin/sqlplus "/as sysdba" << EOF_STAT

set markup html on spool on

TTITLE BOLD CENTER 'Concurrent requests running more than 8 hours'

column Time format 99.99
column Req_Id format A10
column Minutes format 9999999999
column Program format A35
column User_name format A12
column Status format A10
Column Start_Time format A10
set lines 300
set pages 50
set verify off
spool $SPOOL_FILE

select
        distinct substr(to_char(request_id),1,10) Req_Id
        ,to_char(actual_start_date,'HH24:MI:SS') Start_Time
        ,substr(nvl(r.description,v.user_concurrent_program_name),1,35) Program
        ,decode(phase_code,'P','Pending','C','Completed','R','Running',phase_code) Phase
        ,substr(l.meaning,1,10) Status
        ,substr(u.user_name,1,12) User_Name
        ,(sysdate - actual_start_date)*24 Hours
from    apps.fnd_concurrent_requests r,
        apps.fnd_concurrent_programs p,
        apps.fnd_concurrent_programs_vl v,
        apps.fnd_lookup_values l,
        apps.fnd_user u
where   r.program_application_id = p.application_id
        and r.concurrent_program_id = p.concurrent_program_id
        and p.concurrent_program_name = v.concurrent_program_name
        and lookup_type = 'CP_STATUS_CODE'
        and language = 'US'
        AND view_application_id = 0
        and l.lookup_code = status_code
        and (phase_code = 'R' and status_code != 'T')
        and (sysdate - actual_start_date )*24 > 1
        and u.user_id = r.requested_by
order by 1
/

spool off;
set markup html off spool off
exit;

EOF_STAT

CNT=`cat $SPOOL_FILE | grep 'no rows selected'`
if [ $? -eq 0 ]
then
        rm $SPOOL_FILE
        rm $FINAL_FILE
        exit 0;

else

cat $SPOOL_FILE | grep -v 'no rows selected' >> $FINAL_FILE

fi

(echo "Subject: $DB_Name: Concurrent requests running more than 8 hours ";echo "To: $MAIL_LIST"; cat ${FINAL_FILE})  | /usr/sbin/sendmail $MAIL_LIST

rm $SPOOL_FILE
rm $FINAL_FILE

fi
