spool /net/dba/fbmon/bin/TBS_MON/4_tbs_mon_temp_undo_cri.log
set heading off
set feedback off
select tablespace_name from dba_tablespace_usage_metrics where tablespace_name in (select tablespace_name from dba_tablespace_usage_metrics where tablespace_name like 'UNDO%' or tablespace_name like 'TEMP%') and  USED_PERCENT > 90;
spool off
exit

