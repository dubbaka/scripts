spool /net/dba/fbmon/bin/TBS_MON/3_tbs_mon_no_temp_undo_cri.log
set heading off
set feedback off
select tablespace_name from dba_tablespace_usage_metrics where tablespace_name not in (select tablespace_name from dba_tablespace_usage_metrics where tablespace_name like 'UNDO%' or tablespace_name like 'TEMP%') and  USED_PERCENT >90;
spool off
exit
[oracle@xd05dbadm01 TBS_MON]$ cat 3_tbs_mon_no_temp_undo_cri.sql
spool /net/dba/fbmon/bin/TBS_MON/3_tbs_mon_no_temp_undo_cri.log
set heading off
set feedback off
select tablespace_name from dba_tablespace_usage_metrics where tablespace_name not in (select tablespace_name from dba_tablespace_usage_metrics where tablespace_name like 'UNDO%' or tablespace_name like 'TEMP%') and  USED_PERCENT >90;
spool off
exit

