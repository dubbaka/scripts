#!/bin/ksh
# Syn
#
# Modification History:
# Name                  Date            Notes
# ---------------      ----------      -----------------------
# Vijay S              1.04.2016        Created script.
# Shakeel M            05.18.2016       Modified to seperate undo/temp
# Razi Mohammad        08.10.2016       Added code for Warning Alert at 80 percent
#############################################################

           ######## Defining Varibles #############

db_name=$1

date=`date "+%m-%d-%Y %H:%M"`
hn=$(hostname -a)
ts=`date "+%m%d%Y_%H%M"`
TS2=`date "+%m-%d-%Y"`
LOG_FILE=/net/dba/fbmon/log/tablespace_usage_${db_name}_${ts}.log



           ############ Setting the Enviroinment #########



export ORACLE_SID=$(grep ^${db_name} /etc/oratab |grep -iv Agent |awk -F":" '{print $1}')
export ORACLE_HOME=$(grep ^${db_name} /etc/oratab |grep -iv Agent |awk -F":" '{print $2}')
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"

if [ -f /usr/local/bin/dbenv ]
then
        . /usr/local/bin/dbenv ${ORACLE_SID} >/dev/null
else
        export PATH=$PATH:/usr/local/bin
        export ORACLE_SID=${ORACLE_SID}
        export ORAENV_ASK=NO
        . oraenv >/dev/null
fi


           ########### Checking the tablespace which exceeds 80% usage ##########

sqlplus -s "/ as sysdba" @/net/dba/fbmon/bin/TBS_MON_OMSPRD/1_tbs_mon_no_temp_undo_war.sql

cat /net/dba/fbmon/bin/TBS_MON_OMSPRD/1_tbs_mon_no_temp_undo_war.log | sed '/^$/d;s/[[:blank:]]//g' > /net/dba/fbmon/bin/TBS_MON_OMSPRD/1_tbs_mon_no_temp_undo_war_n.log

count=`cat /net/dba/fbmon/bin/TBS_MON_OMSPRD/1_tbs_mon_no_temp_undo_war_n.log | wc -l`
if [ count -gt 0 ];
then
mail -s "[INFO]:[$hn]:[$date]TABLESPACE of Database $db_name has exceeded 80% of space utilization " rmohammad@fb.com ramkumars@fb.com  tvishal@fb.com < /net/dba/fbmon/bin/TBS_MON_OMSPRD/1_tbs_mon_no_temp_undo_war_n.log
#mail -s "[INFO]:[$hn]:[$date]TABLESPACE of Database $db_name has exceeded 80% of space utilization " ramkumars@fb.com < /net/dba/fbmon/bin/TBS_MON_OMSPRD/1_tbs_mon_no_temp_undo_war_n.log
fi

rm /net/dba/fbmon/bin/TBS_MON_OMSPRD/*log

sqlplus -s "/ as sysdba" @/net/dba/fbmon/bin/TBS_MON_OMSPRD/2_tbs_mon_temp_undo_war.sql

cat /net/dba/fbmon/bin/TBS_MON_OMSPRD/2_tbs_mon_temp_undo_war.log | sed '/^$/d;s/[[:blank:]]//g' > /net/dba/fbmon/bin/TBS_MON_OMSPRD/2_tbs_mon_temp_undo_war_n.log

count=`cat /net/dba/fbmon/bin/TBS_MON_OMSPRD/2_tbs_mon_temp_undo_war_n.log | wc -l`
if [ count -gt 0 ];
then
mail -s "[INFO]:[$hn]:[$date]UNDO OR TEMP (TB LISTED IN EMAIL)TABLESPACE of Database $db_name has high usage(>80%), please investigate" rmohammad@fb.com ramkumars@fb.com tvishal@fb.com < /net/dba/fbmon/bin/TBS_MON_OMSPRD/2_tbs_mon_temp_undo_war_n.log
#mail -s "[INFO]:[$hn]:[$date]UNDO OR TEMP (TB LISTED IN EMAIL)TABLESPACE of Database $db_name has high usage(>80%), please investigate" ramkumars@fb.com < /net/dba/fbmon/bin/TBS_MON_OMSPRD/2_tbs_mon_temp_undo_war_n.log
fi

rm /net/dba/fbmon/bin/TBS_MON_OMSPRD/*log

           ########### Checking the tablespace which exceeds 90% usage ##########

sqlplus -s "/ as sysdba" @/net/dba/fbmon/bin/TBS_MON_OMSPRD/3_tbs_mon_no_temp_undo_cri.sql

cat /net/dba/fbmon/bin/TBS_MON_OMSPRD/3_tbs_mon_no_temp_undo_cri.log | sed '/^$/d;s/[[:blank:]]//g' > /net/dba/fbmon/bin/TBS_MON_OMSPRD/3_tbs_mon_no_temp_undo_cri_n.log

count=`cat /net/dba/fbmon/bin/TBS_MON_OMSPRD/3_tbs_mon_no_temp_undo_cri_n.log | wc -l`
if [ count -gt 0 ];
then
mail -s "[Critical]:[$hn]:[$date]TABLESPACE of Database $db_name has exceeded 90% of space utilization Add space Immediatly" it-omg-dba-pager@fb.com it-omg-dba@fb.com   < /net/dba/fbmon/bin/TBS_MON_OMSPRD/3_tbs_mon_no_temp_undo_cri_n.log
#mail -s "[Critical]:[$hn]:[$date]TABLESPACE of Database $db_name has exceeded 90% of space utilization Add space Immediatly" ramkumars@fb.com < /net/dba/fbmon/bin/TBS_MON_OMSPRD/3_tbs_mon_no_temp_undo_cri_n.log

fi

rm /net/dba/fbmon/bin/TBS_MON_OMSPRD/*log

sqlplus -s "/ as sysdba" @/net/dba/fbmon/bin/TBS_MON_OMSPRD/4_tbs_mon_temp_undo_cri.sql

cat /net/dba/fbmon/bin/TBS_MON_OMSPRD/4_tbs_mon_temp_undo_cri.log | sed '/^$/d;s/[[:blank:]]//g' > /net/dba/fbmon/bin/TBS_MON_OMSPRD/4_tbs_mon_temp_undo_cri_n.log

count=`cat /net/dba/fbmon/bin/TBS_MON_OMSPRD/4_tbs_mon_temp_undo_cri_n.log | wc -l`
if [ count -gt 0 ];
then
mail -s "[Critical]:[$hn]:[$date]UNDO OR TEMP (TB LISTED IN EMAIL)TABLESPACE of Database $db_name has high usage, please investigate" it-omg-dba-pager@fb.com it-omg-dba@fb.com   < /net/dba/fbmon/bin/TBS_MON_OMSPRD/4_tbs_mon_temp_undo_cri_n.log
#mail -s "[Critical]:[$hn]:[$date]UNDO OR TEMP (TB LISTED IN EMAIL)TABLESPACE of Database $db_name has high usage, please investigate" ramkumars@fb.com   < /net/dba/fbmon/bin/TBS_MON_OMSPRD/4_tbs_mon_temp_undo_cri_n.log
fi

rm /net/dba/fbmon/bin/TBS_MON_OMSPRD/*log

