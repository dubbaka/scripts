spool /net/dba/fbmon/bin/TBS_MON/1_tbs_mon_no_temp_undo_war.log
set heading off
set feedback off
select tablespace_name from dba_tablespace_usage_metrics where tablespace_name not in (select tablespace_name from dba_tablespace_usage_metrics where tablespace_name like 'UNDO%' or tablespace_name like 'TEMP%') and  USED_PERCENT > 80;
spool off
exit

