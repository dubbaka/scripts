select
       l.inst_id,
       l.sid,
       s.serial#,
       s.blocking_session-1,
       s.osuser,
       s.status,
       to_char(s.logon_time,'DD-MON-YYYY HH24:MI:SS') logon_time,
       s.audsid,
       s.action,
       s.machine,
       s.module,
       s.program,
       l.type,s.type stype,
       l.id1,
       l.request,l.ctime,
       s.event,
       s.state,
       s.blocking_instance
FROM   gv$session s,
       gv$lock l
WHERE  l.id1 IN (SELECT il.id1
                 FROM   gv$lock il
                 WHERE  il.request <> 0) 
                 --and il.ctime > 180)
  AND  l.sid = s.sid
  AND  l.inst_id = s.inst_id
-- AND  l.ctime >= 180
ORDER BY l.id1,
         l.request asc,
         l.sid
/
         
