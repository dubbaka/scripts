set pagesize 24 linesize 80 echo off feedback 1 wrap on
column reqid format 9999999999 heading "Request Id"
column sesid format a10 heading "Session"
column ospid format a10 heading "OS Pid"
select
   a.request_id reqid,
   d.sid||','||d.serial# sesid,
   c.spid ospid
from
   applsys.fnd_concurrent_requests a,
   applsys.fnd_concurrent_processes b,
   gv$process c, gv$session d
where
   a.controlling_manager=b.concurrent_process_id
   and c.spid=a.oracle_process_id
   and c.addr=d.paddr
   and d.sid=&Sid
   and a.phase_code='R';
