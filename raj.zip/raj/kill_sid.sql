alter system kill session '&sid,&serial' immediate;
