alter session set events = '10046 trace name context forever, level 12' ;
