set pages 999
set verify off
set head on
clear breaks
clear col

accept usr char prompt "Enter value for User Name [Enter For All]: "

select user_name, count(*) "COUNT"
from v$open_cursor
where user_name = nvl(upper('&usr'),user_name)
group by user_name
;

prompt

column text format a40 heading "Summary Of Open Cursors"

select '
   Cursors (Sum): '||to_char(sum(count(*)),'9990.99')||'
   Cursors (Min): '||to_char(min(count(*)),'9990.99')||'
   Cursors (Max): '||to_char(max(count(*)),'9990.99')||'
   Cursors (Avg): '||to_char(avg(count(*)),'9990.99')||'
   Users        : '||to_char(count(count(*)),'9990.99') text
from v$open_cursor
where user_name = nvl(upper('&usr'),user_name)
group by user_name
;

column text format a40 heading "info from sysstatts "    
column name for a35
set linesize 122
select * from v$sysstat where statistic#=3;


select s.sid, sum(value) from v$sesstat s, v$session v
where s.statistic#=3 and value > 0 and s.sid=v.sid and status='ACTIVE' group by s.sid;

select s.sid, sum(value) from v$sesstat s, v$session v
where s.statistic#=3 and value > 0 and s.sid=v.sid  group by s.sid;
undef cr

