col username for a15
col event for a30
select 'kill -9 '||b.spid
from v$session a,v$process b,v$session_wait c
where a.paddr=b.addr
and a.sid=c.sid
and a.machine in ('oa1-iprd-22','oa1-iprd-23','oa1-iprd-24')
/
