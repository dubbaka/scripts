#!/bin/sh

if [ $# != 1 ]
then
   echo "Usage : $0 <instance in uppercase>"
   exit 1
fi


ORACLE_SID=$1
ORAENV_ASK=NO
export PATH=$PATH:/usr/local/bin
. /usr/local/bin/oraenv

sqlplus / << !
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'JTF', tabname => 'JTF_RS_GROUP_MEMBERS', percent => 40 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'APPLSYS', tabname => 'FND_LOOKUP_VALUES', percent => 40 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'APPLSYS', tabname => 'FND_FLEX_VALUE_SETS', percent => 30 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'APPLSYS', tabname => 'FND_FLEX_VALUES', percent => 30 , degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
!
