col metric_name for a50
col min_value for 9999999999999.99
col max_value for 9999999999999.99
col avg_value for 9999999999999.99
alter session set nls_date_format='dd-mon-rr:hh24';
select end_time,snap_id,sum(maxval) as MAXVAL,sum(average) as AVGVAL
from DBA_HIST_SYSMETRIC_SUMMARY where metric_name like '%&t%'
group by snap_id,end_time
order by 2,3;
