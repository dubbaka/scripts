set lines 120 pages 200
COLUMN month FORMAT a15
COLUMN growth FORMAT 999,999,999,999,999
COLUMN growth FORMAT 999,999,999,999,999
SELECT
TO_CHAR(creation_time, 'RRRR-MM') "Month",
SUM(bytes/1024/1024) "growth in MB   ",
SUM(SUM(bytes/1024/1024)/1024) over
(order by TO_CHAR(creation_time, 'RRRR-MM')
range unbounded preceding) "Cumulative"
FROM sys.v_$datafile
GROUP BY TO_CHAR(creation_time, 'RRRR-MM')
ORDER BY TO_CHAR(creation_time, 'RRRR-MM')
/
