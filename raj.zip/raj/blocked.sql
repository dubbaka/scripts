ttitle 'Lock keepers (blockers) and waiters' 
select substr(s1.username,1,8) "Waiter", 
substr(s1.osuser,1,8) "OS user", 
substr(to_char(w.session_id),1,5) "SID", 
P1.spid "PID", 
substr(s2.username,1,8) "Holder", 
substr(s2.osuser,1,8) "OS user", 
substr(to_char(h.session_id),1,5) "SID", 
P2.spid "PID" 
from sys.v_$process P1, sys.v_$process P2, 
sys.v_$session S1, sys.v_$session S2, 
sys.dba_lock w, sys.dba_lock h 
where h.mode_held='Exclusive' 
and w.mode_requested!='None' 
and w.lock_type (+) =h.lock_type 
and w.lock_id1 (+) = h.lock_id1 
and w.lock_id2 (+) = h.lock_id2 
and w.session_id = S1.sid (+) 
and h.session_id = S2.sid (+) 
and S1.paddr = P1.addr (+) 
and S2.paddr = P2.addr (+); 

