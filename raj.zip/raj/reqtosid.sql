set lines 200
col module for a25
col event for a30 trunc
  
SELECT d.inst_id,a.request_id, d.sid, d.serial#,d.sql_id,c.spid,d.module,d.event,d.last_call_et/60
  FROM   apps.fnd_concurrent_requests a,
         apps.fnd_concurrent_processes b,
         gv$process c,
         gv$session d
  WHERE  a.controlling_manager = b.concurrent_process_id
  AND    c.spid = a.oracle_process_id
  AND	 d.inst_id=c.inst_id 
  AND    c.addr = d.paddr
  AND    a.request_id ='&reqid'
  AND    a.status_code='R';
