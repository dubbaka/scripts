col owner for a10
col object_name for a40
col object_type for a40
set lines 150 pages 150
select owner,object_name,object_type, last_ddl_time from dba_objects where status='INVALID';
