sqlplus internal << !
exec utl_recomp.recomp_parallel(50)
!
