select l.name,
       x.p1,
       x.p1text,
       x.p2,
       x.p2text,
       nvl(w.program, nvl(p.program, '<unknown program>')) program,
       w.username,
w.sid,
       w.serial#,
       w.osuser,
       w.process
from v$session w, v$session_wait x, v$latch l,
     v$process p
where w.sid = x.sid
and w.paddr = p.addr (+)
and l.latch# = x.p2
and x.event ='latch free' 
order by sid
/
