col queue for a14
col msg_id for a35
col corr_id for a45
col msg_state for a10
col to_char(enq_time,'DD-MON-YYYY HH24:MI') for a25
col to_char(deq_time,'DD-MON-YYYY HH24:MI') for a35
select queue,msg_id,corr_id,msg_state,to_char(enq_time,'DD-MON-YYYY HH24:MI'),to_char(deq_time,'DD-MON-YYYY HH24:MI') from applsys.aq$wf_deferred a where a.user_data.getEventKey()='&nid' 
/
