column logon_time format a30
column osuser format a10
column machine format a10
column sid format 9999
column username format a15
column osuser format a15

set linesize 120
set pagesize 100


select sid, spid, to_char(logon_time, 'DD-MON-YYYY HH24:MI:SS'), v$session.username, osuser, machine,last_call_et/60
from v$session, v$process
where status = 'ACTIVE'
and  paddr = addr
and sid > 7
order by last_call_et 
-- and username like '%KSGR2%'
--order by logon_time desc;
/

rem select sid, to_char(logon_time, 'DD-MON-YYYY HH24:MI:SS'), username, osuser, machine
rem from v$session
rem where status = 'ACTIVE'
rem and username like '%KSGR2%'
rem and machine = 'mimas'
rem order by logon_time desc;
