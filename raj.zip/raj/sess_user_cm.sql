col username for a15
col event for a30
set pages 0 lines 200
select a.inst_id,a.sid,a.serial#,b.spid,a.username,a.status,a.sql_hash_value,a.machine
from gv$session a,gv$process b
where a.paddr=b.addr and a.inst_id=b.inst_id
and a.osuser='oacg1prd' and a.machine in (select host_name from ops$oracle.apps_servers where nodefor='ConcurrentManager')
and b.spid=3020
order by 8
/
