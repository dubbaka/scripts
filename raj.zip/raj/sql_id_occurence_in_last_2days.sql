select sql_id,count(*) from dba_hist_active_sess_history where sql_id is not null and sample_time > sysdate -2 and pga_allocated > 1024*1024*1024 group by sql_id;
