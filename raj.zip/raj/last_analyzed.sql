column owner format a15
set linesize 100
undefine table_name 

select owner, table_name, ' TABLE' index_name, to_char(last_analyzed, 'DD-MON-YYYY HH24:MI:SS'), num_rows, sample_size
from dba_tables 
where 1 = 1
--owner not in ('SYS', 'SYSTEM')
AND    UPPER(table_name)         LIKE UPPER(NVL('%&&table_name%', table_name))
union all
select owner, table_name, index_name, to_char(last_analyzed, 'DD-MON-YYYY HH24:MI:SS'), num_rows, sample_size
from dba_indexes
where 1 = 1
--owner not in ('SYS', 'SYSTEM')
AND    UPPER(table_name)         LIKE UPPER(NVL('%&&table_name%', table_name))
order by 4 desc
/
