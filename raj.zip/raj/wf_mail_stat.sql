col recipient_role for a5
SELECT
n.notification_id,
n.begin_date,   
n.status, 
n.mail_status, 
n.recipient_role, 
de.def_enq_time,  
de.def_deq_time, 
de.def_state, 
ou.out_enq_time, 
ou.out_deq_time, 
ou.out_state 
FROM   applsys.wf_notifications n, 
       (SELECT d.enq_time def_enq_time, 
               d.deq_time def_deq_time, 
               TO_NUMBER((SELECT VALUE 
                           FROM TABLE(d.user_data.parameter_list) 
                         WHERE NAME = 'NOTIFICATION_ID')) d_notification_id, 
              msg_state def_state 
          FROM applsys.aq$wf_deferred d 
         WHERE d.corr_id = 'APPS:oracle.apps.wf.notification.send') de, 
       (SELECT o.deq_time out_deq_time, 
               o.enq_time out_enq_time, 
               TO_NUMBER((SELECT str_value 
                          FROM TABLE(o.user_data.header.properties) 
                          WHERE NAME = 'NOTIFICATION_ID')) o_notification_id, 
               msg_state out_state 
         FROM applsys.aq$wf_notification_out o) ou 
 WHERE  n.notification_id = &NOTIFICATION_ID 
   AND  n.notification_id = de.d_notification_id(+) 
   AND  n.notification_id = ou.o_notification_id(+) 
   AND n.status='OPEN'
-- and n.mail_status='MAIL'
;
