set pages 100
accept username char prompt 'Enter Oracle Username : '
spool get_session_count
select username, status, count(*)
  from v$session
 where username = decode ('&username',null,username,'&username')
 group by username, status;
spool off
