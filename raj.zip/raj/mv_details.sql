spool mv_details
set lines 150
set pages 100
col master for a30
--select master, to_char(oldest,'mm/dd/yyyy hh24:mi:ss') OLDEST, to_char(oldest_pk,'mm/dd/yyyy hh24:mi:ss') OLDEST_PK,  
--       to_char(youngest,'mm/dd/yyyy hh24:mi:ss') YOUNGEST 
--  from sys.mlog$
--;
COLUMN snapshot_id HEADING 'SnapshotID' FORMAT b9999999
COLUMN owner HEADING 'MVIEW OWNER' FORMAT A15
COLUMN log_owner HEADING 'MLOG OWNER' FORMAT A15
COLUMN name HEADING 'MVIEW NAME' FORMAT A30
COLUMN snapshot_site HEADING 'MVIEW SITE'  format a30
COLUMN current_snapshots HEADING  'Last Time Refresh' format a21
accept name char prompt 'Enter Mview Name : '
select l.snapshot_id, owner , name , log_table MVIEW_LOG_NAME, 
       substr(snapshot_site,1,30) snapshot_site, to_char(current_snapshots, 'mm/dd/yyyy hh24:mi:ss') current_snapshots
--       ,l.master table_name, log_owner mlog_owner
  from dba_registered_snapshots r, dba_snapshot_logs l
 where name = decode(upper('&&name'),null, name,upper('&&name'))
   and r.snapshot_id = l.snapshot_id (+)
;
spool off
