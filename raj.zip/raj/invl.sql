col owner for a10
col object_name for a30
col object_type for a30
select owner,object_name,object_type from dba_objects where status='INVALID';
