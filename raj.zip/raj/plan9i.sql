set lines 120
select
  lpad(' ', 2*(depth))||operation||' '||options
  ||' '||decode(object_owner,null,null,
                object_owner||'.'||object_name)
  ||' '||decode(cost,null,null,'Cost = '||cost)
  ||' '||decode(partition_start,null,null,
                'Partition='||partition_start||'..'||partition_stop)
  ||' '||decode(bytes,null,null,'Bytes= '||bytes)
--  ||' '||decode(access_predicates,null,null,'Access= '||access_predicates)
--  ||' '||decode(filter_predicates,null,null,'Filter= '||filter_predicates)
--, other,other_tag, temp_space
  "Execution Plan"
from v$sql_plan
where  (address, hash_value) =
(select sql_address, sql_hash_value
from v$session
where sid = &sid)
order by id
/
undefine 1
