                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."XXDEX_CISCO_GLOBAL_K" AUTHID CURRENT_USER                                                       
 as                                                                                                                                 
/* $Header: XXDEX_CISCO_GLOBAL_K.sql 21.5.0.0 2010/08/06 12:00:00 dexsys s                                                          
hip $ Copyright (c) 2010 DEX Systems, Inc. */                                                                                       
	ACTION_NEW			VARCHAR2(1) := 'N';                                                                                                   
	ACTION_UPDATE		VARCHAR2(1) := 'U';                                                                                                 
	ACTION_CANCEL		VARCHAR2(1) := 'C';                                                                                                 
                                                                                                                                    
	B2B_USER_NAME		VARCHAR2(100) := 'XXCTS_B2B_APP_U';                                                                                 
	EMM_SITE_ID			VARCHAR2(2) := 'TS';				-- Test.                                                                                     
                                                                                                                                    
	SYSTEM_EXCEPTION					exception;                                                                                                    
	BUSINESS_EXCEPTION				exception;                                                                                                   
	UNHAND_BUSINESS_EXCEPTION		exception;                                                                                              
	LOCK_EXCEPTION						exception;                                                                                                     
                                                                                                                                    
 	CTS_DEX_RMA_RESPONSE_FAILED	CONSTANT VARCHAR (50) := 'CTS_DEX_RMA_RESPONS                                                         
E_FAILED';                                                                                                                          
 	CTS_DEX_RMA_RECEIPT_FAILED		CONSTANT VARCHAR (50) := 'CTS_DEX_RMA                                                                 
_RECEIPT_FAILED';                                                                                                                   
 	CTS_DEX_STATUS_UPDATE_FAILED	CONSTANT VARCHAR (50) := 'CTS                                                                        
_DEX_STATUS_UPDATE_FAILED';                                                                                                         
 	CTS_DEX_QUALITY_UPDATE_FAILED	CONSTANT VARCHAR (50) := 'CTS_DEX_QUALITY_UP                                                        
DATE_FAILED';                                                                                                                       
 	CTS_DEX_SHIP_CONFIRM_FAILED	CONSTANT VARCHAR (50) := 'CTS_DEX_                                                                    
SHIP_CONFIRM_FAILED';                                                                                                               
 	CTS_DEX_INT_REQ_FAILED			CONSTANT VARCHAR (50) := 'CTS                                                                            
_DEX_INT_REQ_FAILED';                                                                                                               
 	CTS_DEX_INT_RECEIPT_FAILED		CONSTANT VARCHAR (50) := '                                                                            
CTS_DEX_INT_RECEIPT_FAILED';                                                                                                        
 	CTS_DEX_SHIP_CUST_FAILED		CONSTANT VARCHAR (50) := 'CTS_DEX_SHIP_CUST_FAI                                                         
LED';                                                                                                                               
 	CTS_DEX_FLAT_FILE_FAILED		CONSTANT VARCHAR (50) := 'CTS_DEX_FLAT_FILE_                                                            
FAILED';                                                                                                                            
 	CTS_DEX_RMA_CREATE_FAILED		CONSTANT VARCHAR (50) := 'CTS_DEX_RMA_CR                                                               
EATE_FAILED';                                                                                                                       
	CTS_DEX_DELIVERY_SEND_FAILED	CONSTANT VARCHAR (50) := 'CTS_DEX_                                                                    
DELIVERY_SEND_FAILED';                                                                                                              
	CTS_DEX_SHIP_CANCEL_FAILED		CONSTANT VARCHAR (50) := '                                                                             
CTS_DEX_SHIP_CANCEL_FAILED';                                                                                                        
	CTS_DEX_RMA_SHIP_FAILED			CONSTANT VARCHAR (50) := 'CTS_DEX_RMA_SHIP_FAILE                                                         
D';                                                                                                                                 
                                                                                                                                    
   /******************** GENERIC RECORD TYPES  ***********************/                                                             
   type ADDRESS_REC is record (                                                                                                     
      CONTACT_NAME	RMAHDR.SHIP_ATTN%type                                                                                            
     ,STREET1			RMAHDR.SHIP_ST1%type                                                                                                
     ,STREET2			RMAHDR.SHIP_ST2%type                                                                                                
     ,CITY				RMAHDR.SHIP_CITY%type                                                                                                 
     ,STATE				RMAHDR.SHIP_STATE%type                                                                                               
     ,PROVINCE			RMAHDR.PROVINCE%type                                                                                               
     ,POSTAL_CODE		RMAHDR.SHIP_ZIP%type                                                                                             
     ,COUNTRY			RMAHDR.COUNTRY%type                                                                                                 
     ,EMAIL_ADDR		RMAHDR.NOTIFY_EMAIL%type                                                                                          
     ,PHONE_NBR		RMAHDR.TELEPHONE%type                                                                                              
     ,SITE_USE_ID		NUMBER                                                                                                           
     );                                                                                                                             
                                                                                                                                    
	type ATTRIBUTES_REC is table of VARCHAR2(150) index by BINARY_INTEGE                                                               
R;                                                                                                                                  
                                                                                                                                    
                                                                                                                                    
	/********************* RMA RECORD TYPES  *******************************                                                           
                                                                                                                                    
	 ************************************************************************/                                                         
   type RMA_HEADER_REC is record (                                                                                                  
      PARTNER_RMA_NBR	VARCHAR2(20)			-- RMA # from Partner                                                                          
     ,ACTION_DATE       DATE						-- Action Date                                                                                    
     ,ACTION_CODE			VARCHAR2(1)				-- N = New, U = Update, C = Can                                                                  
cel                                                                                                                                 
     ,CUSTOMER_NUMBER	VARCHAR2(20)			-- Customer Number                                                                             
     ,CONTRACT_NBR		VARCHAR2(50)			-- Contract # (Optional)                                                                         
     ,CCO_ID				VARCHAR2(30)			-- CCO ID (Optional)                                                                                 
     ,SHIP_METHOD			RMAHDR.SHIP_VIA%type	-- Shipping Method (O                                                                      
ptional) Default will be from Customer Master                                                                                       
     ,SHIP_TO_ADDRESS	XXDEX_CISCO_GLOBAL_K.ADDRESS_REC 		-                                                                          
- Ship to Address record (Optional if SHIP_TO_ID is                                                                                 
provided)                                                                                                                           
     ,BILL_TO_ADDRESS	XXDEX_CISCO_GLOBAL_K.ADDRESS_REC			-- Bill to                                                                 
Address record (Optional if SHIP_TO_ID is provided)                                                                                 
     ,ORDER_TYPE			VARCHAR2(1)				-- Order Type: R =                                                                                
 Repair, S = Sales                                                                                                                  
     ,RTSU_FLAG			VARCHAR2(1)				-- Repair the Same Unit Fl                                                                         
ag (Y = Yes, N = No) (Optional - Default Y)                                                                                         
     ,COMMENTS				RMAHDR.COMMENTS%type -- optional                                                                                  
     ,ORDER_REASON_CD	VARCHAR2(10)			-- Order Reason Code                                                                           
     ,AUTHORIZATION		VARCHAR2(10)			-- Related RMA                                                                                  
     ,INTERNAL_RMA_IND	VARCHAR2(1)				-- Optional ( set                                                                             
to Y for Internal RMA)                                                                                                              
     ,FLEX_VALUES			XXDEX_CISCO_GLOBAL_K.ATTRIBUTES_REC                                                                             
		-- Future use for filling in Flex Field Data  (Opt                                                                                
ional)                                                                                                                              
     );                                                                                                                             
                                                                                                                                    
	type RMA_DETAIL_REC is record (                                                                                                    
		LINE_ID				NUMBER							-- Unique Line Rcd ID Set by                                                                              
calling program                                                                                                                     
	  ,PARTNER_LINE_NBR	RMADET.ITEM%type				-- Partner RMA Line #                                                                      
 (Optional)                                                                                                                         
	  ,PART_NUMBER			RMADET.PART%type				-- Part Number                                                                                
     ,ACTION_DATE       DATE								-- Action Date                                                                                  
     ,ACTION_CODE			VARCHAR2(1)						-- Action Code: N = New, U =                                                                   
Update, C = Cancel                                                                                                                  
	  ,QUANTITY				NUMBER							-- Quantity                                                                                            
	  ,UNIT_PRICE			NUMBER							-- Unit Price (Optional)                                                                              
	  ,STAT_CODE			varchar2(1)						-- Stat Code: P = Priority, E = Ex                                                                 
pedite, N = Normal                                                                                                                  
	  ,SCHEDULE_DATE		DATE								-- Date Scheduled (Optional)                                                                         
                                                                                                                                    
	  ,COMMENTS				RMADET.COMMENTS%type			-- Line comments (Optinoal)                                                                  
	  ,ORDER_REASON_CD	VARCHAR2(10)					-- Order Reason Code                                                                           
	  ,FLEX_VALUES			XXDEX_CISCO_GLOBAL_K.ATTRIBUTES_REC 	-                                                                            
- Future use for filling in Flex Field Data (optiona                                                                                
l)                                                                                                                                  
	  );                                                                                                                               
                                                                                                                                    
	type RMA_DETAILS_TBL is table of RMA_DETAIL_REC index by BINARY_INT                                                                
EGER;                                                                                                                               
                                                                                                                                    
	type RMA_SERIAL_REC is record (                                                                                                    
		LINE_ID				NUMBER										-- Unique Line Rcd ID Set by callin                                                                    
g program                                                                                                                           
	  ,SERIAL_NUMBER		RMA_SERIALS.SERIAL%type					-- Serial Number                                                                     
	  ,FAILURE_DESCR		RMA_SERIALS.REPORTED_FAILURE%type	--                                                                             
Failure Description ( Optional )                                                                                                    
	  ,FLEX_VALUES			XXDEX_CISCO_GLOBAL_K.ATTRIBUTES_REC	-- Future use for                                                             
 filling in Flex Field Data                                                                                                         
	   );                                                                                                                              
                                                                                                                                    
	type RMA_SERIALS_TBL is table of RMA_SERIAL_REC index by BINARY_INT                                                                
EGER;                                                                                                                               
                                                                                                                                    
	type RMA_ERROR_REC is record (                                                                                                     
		PARTNER_RMA_NBR	VARCHAR2(20)							-- RMA # from Partner                                                                          
	  ,LINE_ID				NUMBER									-- Unique Line Rcd ID Set by                                                                          
 calling program                                                                                                                    
	  ,PARTNER_LINE_NBR	RMADET.ITEM%type						-- RMA Line # from                                                                       
 Partner (Optional). Leave blank for Header level er                                                                                
ror                                                                                                                                 
	  ,ERROR_MESSAGE		VARCHAR2(2000)							-- Error Messaeg if couldn't proce                                                          
ss                                                                                                                                  
	   );                                                                                                                              
                                                                                                                                    
	type RMA_ERRORS_TBL is table of RMA_ERROR_REC index by BINARY_INTE                                                                 
GER;                                                                                                                                
                                                                                                                                    
	type ENT_SERIALS_REC is record (                                                                                                   
		INVENTORY_ITEM_ID		NUMBER                                                                                                         
	  ,SERIAL_NUMBER			RMA_SERIALS.SERIAL%type                                                                                         
	  ,ENT_RESULT_CODE		NUMBER                                                                                                         
	  ,PRI_REASON_MEANING	FND_LOOKUP_VALUES.MEANING%type                                                                               
	  ,ENT_AUDIT_ID			NUMBER                                                                                                           
	  ,WARR_TYPE				VARCHAR2(1)                                                                                                        
	  ,WARR_STATUS				VARCHAR2(10)                                                                                                     
	  );                                                                                                                               
                                                                                                                                    
	type ENT_SERIALS_TBL is table of ENT_SERIALS_REC index by BINARY_INTEGER;                                                          
                                                                                                                                    
                                                                                                                                    
  	INIT_RMA_HEADER		RMA_HEADER_REC;                                                                                                 
  	INIT_RMA_DETAILS_TBL RMA_DETAILS_TBL;                                                                                            
  	INIT_RMA_SERIALS_TBL	RMA_SERIALS_TBL;                                                                                            
                                                                                                                                    
	type RCPT_SERIAL_REC is record (                                                                                                   
		SERIAL_NUMBER		RMA_SERIALS.SERIAL%type					-- Serial                                                                              
 Number Receivedd                                                                                                                   
	  ,ORIG_SERIAL_NBR	RMA_SERIALS.SERIAL%type					-- Original                                                                         
Serial #, if different then Serial Nbr ( Optional)                                                                                  
	  ,RECEIPT_DATE		DATE											-- Date of Receipt                                                                                 
	  ,MFG_DATE				DATE											-- Mfg Date (optional)                                                                               
                                                                                                                                    
	  ,REF_SERIAL_ID		NUMBER										-- Ref Serial ID (optional)                                                                      
		);                                                                                                                                
                                                                                                                                    
	type RCPT_SERIALS_TBL is table of RCPT_SERIAL_REC index by                                                                         
BINARY_INTEGER;                                                                                                                     
                                                                                                                                    
	type RCPT_DETAIL_REC is record (                                                                                                   
		RMA_NBR				RMAHDR.CALL%type							-- DEX RMA Nbr                                                                                  
	  ,PARTNER_RMA_NBR	RMAHDR.CUSTPO%type						-- Optiona                                                                              
l if DEX RMA is not provided                                                                                                        
	  ,PARTNER_LINE_NBR	RMADET.CUSTITEM%type						-- Optional                                                                          
	  ,PART_NUMBER			VARCHAR2(80)								-- Part Number                                                                                
	  ,RECEIPT_DATE		DATE											-- Date Recieved (Optional -- don'                                                                 
t set if serials are provided)                                                                                                      
	  ,QUANTITY				NUMBER										-- Qty Received                                                                                     
	  ,SERIALS_TBL			XXDEX_CISCO_GLOBAL_K.RCPT_SERIALS_TBL	-- Optional if none-s                                                       
erialize product                                                                                                                    
	   );                                                                                                                              
                                                                                                                                    
	type RECEIPTS_TBL is table of RCPT_DETAIL_REC index                                                                                
by BINARY_INTEGER;                                                                                                                  
                                                                                                                                    
	/********************* Internal Requisition Receipt Recor                                                                          
d ******************                                                                                                                
	 *******************************************************                                                                           
*********************/                                                                                                              
	type REQ_RECEIPT_REC is record (                                                                                                   
		RMA_NBR				RMAHDR.CALL%type								-- DEX RMA Nbr                                                                                 
	  ,WORK_ORDER			ORDERS.ORDERNO%type							-- Work Order                                                                            
	  ,LINE_NBR				LINES.ITEM%type								-- Line Nbr                                                                                  
	  ,PART_NUMBER			VARCHAR2(80)									-- Part Number                                                                               
	  ,QUANTITY				NUMBER											-- Quantity                                                                                        
	  ,SERIALS_TBL			XXDEX_CISCO_GLOBAL_K.RCPT_SERIALS_TBL	-- Required                                                                 
	   );                                                                                                                              
	type REQ_RECEIPT_TBL is table of REQ_RECEIPT_REC index by BINARY_INTEGER;                                                          
                                                                                                                                    
	/********************* WORK ORDER RECORD TYPES  ****                                                                               
***************************                                                                                                         
	 ************************************************************************/                                                         
	type WORK_ORDER_REC is record (                                                                                                    
		WO_TRAN_ID			NUMBER							-- WO Transaction ID (Required)                                                                         
	  ,RMA_NBR			   RMAHDR.CALL%type				-- DEX RMA Nbr                                                                                 
	  ,PART_NUMBER			VARCHAR2(80)               -- Part Number                                                                         
	  ,SERIAL_NUMBER		SERIALS.SERIAL%type        -- Serial                                                                             
 Completed                                                                                                                          
	  ,ORIG_SERIAL_NBR	SERIALS.SERIAL%type        -- Original Serial #                                                                 
  (Optional)                                                                                                                        
	  ,STATUS_CODE			VARCHAR2(2)                -- Status Code: WC -                                                                   
 Work Complete.  RC - Received                                                                                                      
	  ,STATUS_DATE			DATE                       -- Status Date                                                                         
	  ,SERIAL_CHG_REASON	VARCHAR2(2)           		-- Change Reason Co                                                                   
de: LM = Lemon , NR = Not Economical to Rep                                                                                         
	   );                                                                                                                              
                                                                                                                                    
	type WORK_ORDERS_TBL is table of WORK_ORDER_REC ind                                                                                
ex by BINARY_INTEGER;                                                                                                               
                                                                                                                                    
                                                                                                                                    
	type SHIP_SERIAL_REC is record (                                                                                                   
	   SERIAL_NUMBER		SERIALS.SERIAL%type			-- Serial Number shipped                                                                   
	  ,ORIG_SERIAL_NUMBER SERIALS.SERIAL%type			-- Optional                                                                            
	  ,COUNTRY_OF_ORIGIN	VARCHAR2(10)					-- Optional                                                                                  
	  );                                                                                                                               
                                                                                                                                    
	type SHIP_SERIALS_TBL is table of SHIP_SERIAL_REC index by BINARY_INTEGE                                                           
R;                                                                                                                                  
                                                                                                                                    
	type SHIP_DETAIL_REC is record (                                                                                                   
		RMA_NBR				RMAHDR.CALL%type				-- DEX RMA Nbr                                                                                     
	  ,WORK_ORDER			ORDERS.ORDERNO%type			-- Work Order                                                                                
	  ,LINE_NBR				LINES.ITEM%type				-- Line Nbr                                                                                      
	  ,PART_NUMBER			VARCHAR2(80)					-- Part Number                                                                                   
	  ,QUANTITY 			NUMBER                                                                                                              
	  ,SERIALS_TBL			XXDEX_CISCO_GLOBAL_K.SHIP_SERIALS_T                                                                               
BL                                                                                                                                  
	  );                                                                                                                               
	type SHIP_DETAILS_TBL is table of SHIP_DETAIL_REC index by BINARY_IN                                                               
TEGER;                                                                                                                              
                                                                                                                                    
	type SHIPMENT_REC is record (                                                                                                      
		DEX_SHIP_ID			NUMBER							-- Ship ID Provided on Ship Release                                                                    
	  ,INTERNAL_SHIP_IND	VARCHAR2(1)						-- Optional (                                                                                
 set to Y for Internal Shipment)                                                                                                    
	  ,PARTNER_SHIP_REF	VARCHAR2(40)					-- Partners Shipping Reference #                                                              
	  ,SHIP_DATE			DATE								-- Date Shipped                                                                                         
	  ,WAYBILL				VARCHAR2(40)					-- Waybill/Tracking Number                                                                          
	  ,CARRIER				VARCHAR2(40)                                                                                                         
	  ,SHIPPING_METHOD	VARCHAR2(20)                                                                                                    
	  ,NBR_OF_CONTAINERS	NUMBER							-- Optional                                                                                      
	  ,GROSS_WEIGHT		NUMBER							-- Optional                                                                                          
	  ,GROSS_WEIGHT_UOM	VARCHAR2(20)					-- Optional                                                                                   
	  ,NET_WEIGHT			NUMBER                     -- Optional                                                                             
	  ,NET_WEIGHT_UOM		VARCHAR2(20)               -- Option                                                                            
al                                                                                                                                  
	  );                                                                                                                               
                                                                                                                                    
                                                                                                                                    
	type RMA_SHIP_DETAIL_REC is record (                                                                                               
	   PARTNER_LINE_NBR	LINES.ITEM%type								-- Line Nbr                                                                             
                                                                                                                                    
	  ,PART_NUMBER			VARCHAR2(80)									-- Part Number                                                                               
	  ,QUANTITY				NUMBER											-- Quantity                                                                                        
	  ,SERIALS_TBL			XXDEX_CISCO_GLOBAL_K.SHIP_SERIALS_TBL	                                                                            
-- Required                                                                                                                         
	   );                                                                                                                              
                                                                                                                                    
	type RMA_SHIP_DETAILS_TBL is table of RMA_SHIP_DETAIL_REC                                                                          
 index by BINARY_INTEGER;                                                                                                           
                                                                                                                                    
	type RMA_SHIPMENT_REC is record (                                                                                                  
      DEX_RMA_NBR   		RMAHDR.CALL%type  			-- DEX RMA Nbr (Optional)                                                                
                                                                                                                                    
	  ,PARTNER_RMA_NBR	RMAHDR.CUSTPO%type			-- Optional if DEX RMA is not provid                                                       
ed                                                                                                                                  
	  ,PARTNER_SHIP_REF	VARCHAR2(40)					-- Partners Shipping Reference #                                                              
	  ,SHIP_DATE			DATE								-- Date Shipped                                                                                         
	  ,WAYBILL				VARCHAR2(40)					-- Waybill/Tracking Number                                                                          
	  ,CARRIER				VARCHAR2(40)                                                                                                         
	  ,SHIPPING_METHOD	VARCHAR2(20)                                                                                                    
	  ,NBR_OF_CONTAINERS	NUMBER							-- Optional                                                                                      
	  ,GROSS_WEIGHT		NUMBER							-- Optional                                                                                          
	  ,GROSS_WEIGHT_UOM	VARCHAR2(20)					-- Optional                                                                                   
	  ,NET_WEIGHT			NUMBER                     -- Optional                                                                             
	  ,NET_WEIGHT_UOM		VARCHAR2(20)               -- Optional                                                                          
	  );                                                                                                                               
                                                                                                                                    
                                                                                                                                    
	/********************* QUALITY DATA RECORD TYPES  ********************                                                             
***********                                                                                                                         
	 ****************************************************************                                                                  
********/                                                                                                                           
                                                                                                                                    
	type QUAL_RPT_SYMP_TBL	is table of VARCHAR2(4) index by BINARY_INT                                                                 
EGER;                                                                                                                               
                                                                                                                                    
                                                                                                                                    
	type QUAL_COMP_REC is record (                                                                                                     
		REPAIR_ASSEMBLY		VARCHAR2(80)                                                                                                     
     ,REF_DES_PREFIX			VARCHAR2(10)                                                                                                 
     ,REF_DES_NUMBER			VARCHAR2(10)                                                                                                 
     ,COMPONENT				VARCHAR2(80)                                                                                                     
     ,FAULT_CODE				VARCHAR2(10)                                                                                                    
     ,CAUSE_CODE				VARCHAR2(10)                                                                                                    
     ,REPAIR_ACTION			VARCHAR2(10)                                                                                                  
     );                                                                                                                             
                                                                                                                                    
 	type QUAL_COMPS_TBL is table of QUAL_COMP_REC inde                                                                                
x by BINARY_INTEGER;                                                                                                                
                                                                                                                                    
                                                                                                                                    
	type QUAL_VERI_REC is record (                                                                                                     
		CODE_GROUP				VARCHAR2(10)                                                                                                        
	  ,TASK_CODE				VARCHAR2(10)                                                                                                       
	  ,TASK_DATA				VARCHAR2(40)                                                                                                       
	   );                                                                                                                              
                                                                                                                                    
	type QUAL_VERI_TBL is table of QUAL_VERI_REC index by B                                                                            
INARY_INTEGER;                                                                                                                      
                                                                                                                                    
	INIT_RPT_SYMP_TBL			QUAL_RPT_SYMP_TBL;                                                                                             
	INIT_QUAL_COMPS_TBL		QUAL_COMPS_TBL;                                                                                               
	INIT_QUAL_VERI_TBL		QUAL_VERI_TBL;                                                                                                 
                                                                                                                                    
	type QUAL_DATA_REC is record (                                                                                                     
	   WO_TRAN_ID				NUMBER                                                                                                            
	  ,RMA_NBR					RMAHDR.CALL%type                                                                                                    
	  ,SERIAL_NUMBER			VARCHAR2(40)                                                                                                    
	  ,ORIG_SERIAL_NUMBER	VARCHAR2(40)                                                                                                 
	  ,PART_NUMBER				VARCHAR2(80)                                                                                                     
	  ,MONTH_OF_MFG			NUMBER(2)                                                                                                        
	  ,YEAR_OF_MFG				NUMBER(4)                                                                                                        
	  ,ACCTING_IND				VARCHAR2(2)                                                                                                      
	  ,REPAIR_START_DATE		DATE                                                                                                         
	  ,REPAIR_END_DATE		DATE                                                                                                           
	  ,REPAIR_ACTION_CODE	VARCHAR2(4)                                                                                                  
	  ,ECN_NUMBER				VARCHAR2(40)                                                                                                      
	  ,MCARD_MATL_NBR			VARCHAR2(80)                                                                                                   
	  ,MCARD_SERIAL_NBR		VARCHAR2(40)                                                                                                  
	  ,PARTNER_RMA_NBR		VARCHAR2(20)                                                                                                   
	  ,CUST_RPT_SYMP_TBL		QUAL_RPT_SYMP_TBL                                                                                            
	  ,DEF_COMPS_TBL			QUAL_COMPS_TBL                                                                                                  
	  ,VERI_DATA_TBL			QUAL_VERI_TBL                                                                                                   
	   );                                                                                                                              
                                                                                                                                    
	type QUAL_DATA_TBL is table of QUAL_DATA_REC index by                                                                              
 BINARY_INTEGER;                                                                                                                    
                                                                                                                                    
	type INT_REQ_LINE is record (                                                                                                      
		DEX_RMA_NBR				RMAHDR.CALL%type                                                                                                   
	  ,WO_TRAN_ID				NUMBER                                                                                                            
	  ,LINE_NBR					NUMBER                                                                                                             
	  ,REQUISITION_NBR		VARCHAR2(30)                                                                                                   
	  ,ERROR_MESSAGE			VARCHAR2(2000)                                                                                                  
		);                                                                                                                                
                                                                                                                                    
	type INT_REQ_LINES_TBL is table of INT_REQ_LINE inde                                                                               
x by BINARY_INTEGER;                                                                                                                
                                                                                                                                    
                                                                                                                                    
	function B2B_USERID return number;                                                                                                 
                                                                                                                                    
	function B2B_EMPNO  return varchar2;                                                                                               
                                                                                                                                    
end XXDEX_CISCO_GLOBAL_K;                                                                                                           
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."XXDEX_CISCO_GLOBA                                                                            
L_K" as                                                                                                                             
/* $Header: XXDEX_CISCO_GLOBAL_K.sql 21.1.0.0 2010/04/01 12:00:00 dexs                                                              
ys ship $ Copyright (c) 2010 DEX Systems, Inc. */                                                                                   
                                                                                                                                    
                                                                                                                                    
	function B2B_USERID return number is                                                                                               
   	myUserId		number := f_dex_user_id;                                                                                              
   begin                                                                                                                            
   	if nvl(myUserID,0) <= 0 then                                                                                                    
	   	select USER_ID                                                                                                                 
   		into   myUserID                                                                                                                
   		from   FND_USER                                                                                                                
   		where  USER_NAME = B2B_USER_NAME;                                                                                              
   	end if;                                                                                                                         
                                                                                                                                    
   	return ( myUserID );                                                                                                            
   exception                                                                                                                        
   	when NO_DATA_FOUND then                                                                                                         
   		return (null);                                                                                                                 
   end B2B_USERID;                                                                                                                  
                                                                                                                                    
   function B2B_EMPNO return varchar2 is                                                                                            
   	myEmpNo		varchar2(40);                                                                                                          
   	myPersonID	number;                                                                                                              
   begin                                                                                                                            
		select EMPLOYEE_ID                                                                                                                
		into   myPersonID                                                                                                                 
		from   FND_USER                                                                                                                   
		where  USER_ID = B2B_USERID;                                                                                                      
                                                                                                                                    
		select EMPLOYEE_NUMBER                                                                                                            
		into   myEmpNo                                                                                                                    
		from   PER_PEOPLE_F                                                                                                               
		where  PERSON_ID = myPersonID                                                                                                     
		and    ROWNUM < 2;                                                                                                                
                                                                                                                                    
		return ( nvl(myEmpNo,'0000') );                                                                                                   
	exception                                                                                                                          
		when NO_DATA_FOUND then                                                                                                           
			return ('0000');                                                                                                                 
	end B2B_EMPNO;                                                                                                                     
                                                                                                                                    
end XXDEX_CISCO_GLOBAL_K;                                                                                                           
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

