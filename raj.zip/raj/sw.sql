column event format a60
set pagesize 80 lines 120

select b.event,count(*),avg(b.wait_time)
from v$session a,v$session_wait b
where a.sid = b.sid
--and a.type != 'BACKGROUND'
and b.wait_time=0
group by b.event 
order by 2
/
