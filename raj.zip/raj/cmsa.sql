clear columns
set feed on
col xdb new_val db noprint
col ucp new_val pgm noprint
col ci new_val cid noprint

col st format a14 heading 'Start Time'
col un format a10 heading 'User Name'
col et format a14 heading 'End Time'
col el format 99990.00 heading 'Elapsed' justify right
col sc format a10 heading 'Status'

set term off
select name xdb
  from v$database;

break on today
column today noprint new_value _date
select to_char(sysdate, 'fmMonth DD, hh24:mi') today from dual;
clear breaks

   select concurrent_program_id ci,
          CONCURRENT_PROGRAM_NAME ucp
     from applsys.fnd_concurrent_programs
    where upper(concurrent_program_name) = upper('&1');

col argument_text format a80
set lines 130
set term on

break on report
compute sum label 'Total Time:' -
        avg label 'Avg Time:  ' -
        min label 'Min Time:  ' -
        max label 'Max Time:  ' of el on report 

ttitle left _date -
       center 'Database: &db' -
       right 'Page :' format 999 sql.pno skip 1 -
       center '&pgm' skip 2

select request_id,
       u.user_name un,
       to_char(r.actual_start_date,'mm/dd hh24:mi:ss') st,
       r.argument_text,
       trunc(to_number(nvl(r.ACTUAL_COMPLETION_DATE,sysdate) - 
       r.actual_start_date) * 1440) + ((to_number(nvl(r.ACTUAL_COMPLETION_DATE,
       sysdate) - r.actual_start_date) * 1440) - trunc(to_number(nvl(
       r.ACTUAL_COMPLETION_DATE,sysdate) - r.actual_start_date) * 
       1440)) * .60 el,
       r.status_code
  from applsys.fnd_user u,
       applsys.fnd_concurrent_requests r,
       applsys.fnd_concurrent_programs p
 where r.concurrent_program_id = p.concurrent_program_id
   and r.program_application_id = p.application_id
   and u.user_id = r.requested_by
   and actual_start_date between (trunc(sysdate) - &2) and sysdate
   and concurrent_program_name = upper('&1')
 order by request_id 
/
ttitle off
