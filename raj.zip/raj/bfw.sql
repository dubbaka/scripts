set linesize 120
set pagesize 1000
col username for a12
col osuser for a12
col p1text format a10
col p2text format a10
col program format a20
set head on
select 
       w.sid, 
       p.spid, 
       x.p1,
       x.p2, 
       decode (x.p3, 
        0, 'A block is being read',
        100, 'We want to NEW the block but the block is currently being read by another session most likely for undo',
	200, 'We want to NEW the block but someone else has is using the current copy so we have to wait for them to finish',
        230, ' Trying to get a buffer in CR/CRX mode , but a modification has started on the buffer that has not yet been completed',
	231, ' CR/CRX scan found the CURRENT block, but a modification has started on the buffer that has not yet been completed',
	130, ' Block is being read by another session and no other suitable block image was found, so we wait until the read is completed. This may also occur after a buffer cache assumed deadlock. The kernel cant get a buffer in a certain amount of time and assumes a deadlock. Therefor it will read the CR version of the block.',
	110, '  We want the CURRENT block either shared or exclusive but the Block is being read into cache by another session, so we have to wait until their read() is completed.',
	120, 'We want to get the block in current mode but someone else is currently reading it into the cache. Wait for them to complete the read. This occurs during buffer lookup.',
	210, 'The session wants the block in SCUR or XCUR mode. If this is a buffer exchange or the session is in discrete TX mode, the session waits for the first time and the second time escalates the block as a deadlock and so does not show up as waiting very long. In this case the statistic: exchange deadlocks is incremented and we yield the CPU for the buffer deadlock wait event.',
	220, 'During buffer lookup for a CURRENT copy of a buffer we have found the buffer but someone holds it in an incompatible mode so we have to wait. ') ,
nvl(w.program, nvl(p.program, '<unknown program>')) program, 
       w.username,
       w.serial#, 
       w.osuser, 
       w.process 
from v$session w, v$session_wait x,
     v$process p
where w.sid = x.sid
and p.background is null
and w.paddr = p.addr (+)
and x.event like 'buffer busy waits'
order by sid;

