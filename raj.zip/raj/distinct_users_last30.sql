select user_name from apps.fnd_user where user_id in ( select user_id from apps.fnd_logins where trunc(end_time) > trunc(sysdate)-30);
