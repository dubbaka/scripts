
set lines 400
set pages 400
select i.instance_name inst_name, decode(request,0,'Holder: ','Waiter: ')||sid sess,
id1, id2, lmode, request, type, ctime/60 "Time(In Min)"
from gv$lock l, gv$instance i
where l.inst_id = i.inst_id
and (id1, id2, type) IN (select id1, id2, type from gv$lock where request>0)
Order by ctime desc,id1, request;

