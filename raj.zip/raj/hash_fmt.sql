set serveroutput on size 200000

declare
     g_debug         varchar2(1) := 'F';
     g_line          number := 0;
     v_dump          varchar2(4000);
     v_max           number := 125;
     v_buff          varchar2(250);
     v_buffin        varchar2(250);
     v_b             number;
     v_i             number;
     v_l             number;
     v_remaining     number;
     v_string        varchar2(100);
     cursor c1_cur is select piece,sql_text text
                      from gv$sqltext
                     where hash_value = &hash_value
                     order by 1;
     procedure buffer_out( p_string  IN  varchar2 ) is
     -- This is not elegant, but I wanted a quick fix to the issue of
     -- having multiple AND phrases on the same output line.  This
     -- procedure simply looks for the string AND and starts a new line
     -- everytime it finds one.

          v_i          number;
          v_string     varchar2(250);
          v_temp       varchar2(250);
     begin
          v_string := rtrim(p_string);
          while v_string is not null  loop
             v_i := instr( upper(v_string), ' AND ' );
             if v_i = 0  then
                    exit;
             else
                 dbms_output.put_line( substr(v_string,1,v_i) );
                 v_string := substr(v_string,v_i+1);
             end if;
          end loop;
          dbms_output.put_line( v_string );
     end buffer_out;
     procedure next_line( p_max IN number, p_remaining IN OUT number ) is
     begin
          while length( v_buff ) > p_max+1  loop
               v_b := length( v_buff );
               v_l := p_max;

               -- Search forward in bufffer for first chr(13)

               v_i := instr( v_buff, chr(13) );
               if v_i <> 0  then
                  if v_i < v_l  then
                     v_l := v_i - 1;
                  end if;
               end if;

               -- Search forward in bufffer for first chr(11)

               v_i := instr( v_buff, chr(11) );
               if v_i <> 0  then
                  if v_i < v_l  then
                     v_l := v_i - 1;
                  end if;
               end if;

               -- Search forward in bufffer for first chr(9)

               v_i := instr( v_buff, chr(9) );
               if v_i <> 0  then
                  if v_i < v_l  then
                     v_l := v_i - 1;
                  end if;
               end if;

               -- Search backwards in potential output string for first blank

               v_i := instr( v_buff, ' ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- If we did not find a blank,
               -- search backwards in potential output string for first comma

               if v_i = 0  then
                  v_i := instr( v_buff, ',', v_l-v_b );
                  if v_i <> 0  and v_i > 2 then
                     v_l := v_i;
                  end if;
               end if;

               -- Search backward in the current output string for ORDER BY
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, ' ORDER BY ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Search backward in the current output string for GROUP BY
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, ' GROUP BY ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Search backward in the current output string for HAVING
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, ' HAVING ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Search backward in the current output string for AND
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, ' AND ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Search backward in the current output string for WHERE
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, ' WHERE ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Search backward in the current output string for FROM
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, ' FROM ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Search backward in the current output string for DECODE
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, ' DECODE', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Search backward in the current output string for (SELECT
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, '(SELECT ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Search backward in the current output string for SELECT
               -- If found, make it the beginning of the next output line (after this one)

               v_i := instr( v_buff, ' SELECT ', v_l-v_b );
               if v_i <> 0  and v_i > 2 then
                  v_l := v_i;
               end if;

               -- Print the subset of the buffer we have selected

               buffer_out( substr( v_buffin, 1, v_l ) );

               -- Remove the subset of the buffer we just printed
               -- And remove leading blanks

               v_buffin := ltrim(substr( v_buffin, v_l+1 ));
               v_buff   := ltrim(substr( v_buff,   v_l+1 ));

               -- Remove leading chr(13)

               v_buffin := ltrim( v_buffin, chr(13) );
               v_buff   := ltrim( v_buff,   chr(13) );

               -- Remove leading chr(11)

               v_buffin := ltrim( v_buffin, chr(11) );
               v_buff   := ltrim( v_buff,   chr(11) );

               -- Remove leading chr(9)

               v_buffin := ltrim( v_buffin, chr(9) );
               v_buff   := ltrim( v_buff,   chr(9) );

          end loop;

          p_remaining := length(v_buffin);
     end next_line;
     procedure squeeze is
     begin

         -- If there are no quotes in the buffer, squeeze out extra blanks

         if instr(v_buffin,'''') = 0  and
            instr(v_buffin,'"')  = 0  then
            while instr(v_buffin,'  ') > 0  loop
                v_buffin := replace(v_buffin,'  ',' ');
            end loop;
         end if;
     end squeeze;
     procedure unprintable is
          v_char    varchar2(1);
          v_count   number;
          v_dump    varchar2(4000);
          v_pos     number;
          v_temp    varchar2(100);
     begin
          g_line := g_line + 1;
          v_count := nvl(length(v_string),0);
          v_pos := 1;
          while v_count > 0  loop
             v_char := substr(v_string,v_pos,1);
             if v_char < ' ' then
                 if g_debug = 'T'  then
                    dbms_output.put_line( 'Unprintable character removed from SQL line ' ||
                                          to_char(g_line) || ': ' ||
                                          to_char(ascii(v_char)) || ' (decimal)' );
                 end if;
             else
                 v_temp := v_temp || v_char;
             end if;
             v_count := v_count - 1;
             v_pos := v_pos + 1;
          end loop;
          if v_string <> v_temp  then
             if g_debug = 'T' then
                seleARNING: Be careful with how you use the above formatted SQL.' );
     dbms_output.put_line( '.        It has been formatted to improve readability, but' );
     dbms_output.put_line( '.        there is no guarantee that the SQL is functionally or' );
     dbms_output.put_line( '.        syntacticly correct.  Most of the time the SQL will' );
     dbms_output.put_line( '.        be accurate, but sometimes it will not be.  Some' );
     dbms_output.put_line( '.        areas that you should pay close attention to are' );
     dbms_output.put_line( '.        comments and quoted strings.' );
     dbms_output.put_line( '.');
     dbms_output.put_line( 'NOTE: All unprintable characters have been stripped out of the' );
     dbms_output.put_line( '.     above SQL, whether or not they were enclosed in quotes.');
     dbms_output.put_line( '.');
end;
/
ttitle off

