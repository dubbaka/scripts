set lines 100 pages 100
select message_type, message_name, mail_status, status,
       to_char(min(begin_date), 'YYYY-MM-DD HH:MI:SS') min_bdate,
       to_char(max(begin_date), 'YYYY-MM-DD HH:MI:SS') max_bdate, count(*) total_cnt
from apps.wf_notifications
where mail_status in ('MAIL')
 and status = 'OPEN'
group by message_type, message_name, mail_status, status
order by 1,2,3,4
/
