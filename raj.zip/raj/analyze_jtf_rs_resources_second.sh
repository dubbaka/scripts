#!/bin/sh

if [ $# != 1 ]
then
   echo "Usage : $0 <instance in uppercase>"
   exit 1
fi


ORACLE_SID=$1
ORAENV_ASK=NO
export PATH=$PATH:/usr/local/bin
. /usr/local/bin/oraenv

sqlplus / << !
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'XXCTSTCA_O', tabname => 'XXCTS_CCO_PROFILE_CONTRACTS', percent => 20 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'XXCTS_O', tabname => 'XXCTS_ENT_CONTSUM_HDR', percent => 30 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'XXCTS_O', tabname => 'XXCTS_ENT_CONTSUM_PLN_PRDFAM', percent => 30 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'XXCTS_O', tabname => 'XXCTS_ENT_CONTSUM_PLND_ITEM', percent => 20 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'XXCTS_O', tabname => 'XXCTS_ENT_CONTSUM_SITE', percent => 30 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'XXCTS_O', tabname => 'XXCTS_ENT_CONTSUM_SL_CVR', percent => 30 ,
   degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'INV', tabname => 'MTL_SYSTEM_ITEMS_B', percent => 30 , degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'INV', tabname => 'MTL_ITEM_CATEGORIES', percent => 30 , degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
begin FND_STATS.GATHER_TABLE_STATS (ownname => 'INV', tabname => 'MTL_CATEGORIES_B', percent => 20 , degree => 20 ,  granularity => 'ALL', cascade => TRUE); end;
/
exec dbms_stats.set_index_stats('XXCTS_O','XXCTS_MTL_SYSTEM_ITEMS_B_N10',NUMLBLKS=>6463400);
!
