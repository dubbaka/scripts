col "Current Function" for a45
col SESSION_ID for 99999999999
col user_function_name for a18
col start_time for a20
col "Date and time of last hit" for a20
col "How many hits a User has made" for 9999
col "Num of hits allowed in session" for 9999
col TIMEOUT for a10
col user_name for a15
SELECT (SELECT user_function_name
FROM apps.fnd_form_functions_vl fffv
WHERE (fffv.function_id = a.function_id)) "Current Function",
TO_CHAR (first_connect, 'MM/DD/YYYY HH:MI:SS') start_time,
TO_CHAR (last_connect,
'MM/DD/YYYY HH:MI:SS'
) "Date and time of last hit",
user_name, session_id,
(SYSDATE - last_connect) * 24 * 60 mins_idle,
apps.fnd_profile.value_specific ('ICX_SESSION_TIMEOUT',
a.user_id,
a.responsibility_id,
a.responsibility_application_id,
a.org_id,
NULL
) TIMEOUT,
counter "How many hits"
FROM apps.icx_sessions a, apps.fnd_user b
WHERE a.user_id = b.user_id AND b.user_name in ('SYSADMIN','APPSDBA') and last_connect > SYSDATE - 287
order by start_time;
