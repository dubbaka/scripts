select sample_time,session_id sid, sesssion_serial# serial#, sql_id, sql_plan_hash_value hash, sql_plan_operation,event,pga_allcoated from dba_hist_active_sess_history
where sql_id is not null and sample_time > sysdate -2  order by pga_allocated desc;
