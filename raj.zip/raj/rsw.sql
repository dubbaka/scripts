column event format a60
set pagesize 80 lines 120

select b.event,count(*),avg(b.wait_time)
from gv$session a,gv$session_wait b
where a.sid = b.sid
and a.inst_id=b.inst_id
--and a.type != 'BACKGROUND'
and b.wait_time=0
group by b.event 
order by 2
/
