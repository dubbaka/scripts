select sid,serial#,inst_id,module,program,action,machine,event,client_identifier,sql_id,PREV_HASH_VALUE,last_call_et,status from gv$session where ecid like '%&1%';
