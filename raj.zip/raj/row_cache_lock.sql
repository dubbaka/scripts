select s.sid,
case KQRFPMOD when 0 then 'NULL' when 3 then 'S' when 5 then 'X' end "Mode",
case KQRFPREQ when 0 then 'NULL' when 3 then 'S' when 5 then 'X' end "Req"
from v$session s, X$KQRFP x
where x.KQRFPSES=s.saddr
and KQRFPCID='&p1raw';
