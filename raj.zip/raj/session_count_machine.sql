set pages 100
set lines 120
accept username char prompt 'Enter Oracle Username : '
spool get_session_count
select username, machine, status, count(*)
  from v$session
 where username = decode ('&username',null,username,'&username')
 group by username, status, machine;
spool off
