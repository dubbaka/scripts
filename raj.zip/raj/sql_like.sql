set pagesize 1000
spool sql.log

select sql_text , FIRST_LOAD_TIME 
from v$sqlarea a 
where 1=1
and upper(a.sql_text) like upper('%&sql_text%')
order by first_load_time
/
spool off
