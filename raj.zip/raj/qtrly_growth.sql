select q1,q2,q3,q4 from
(select round(sum(bytes)/1024/1024/1024) q1 from v$datafile where creation_time between(sysdate-365) and (sysdate-285)) q1t,
(select round(sum(bytes)/1024/1024/1024) q2 from v$datafile where creation_time between(sysdate-284) and (sysdate-195)) q2t,
(select round(sum(bytes)/1024/1024/1024) q3 from v$datafile where creation_time between(sysdate-194) and (sysdate-100)) q3t,
(select round(sum(bytes)/1024/1024/1024) q4 from v$datafile where creation_time between(sysdate-99) and (sysdate)) q4t;
