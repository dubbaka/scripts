set pages 100
set lines 132
col logon_time format a25
col running_in_hrs for 999999999.99
col username form a20
col osuser for a15
col sid format 999999
col act_degree format 99999999999999999
col req_degree format 99999999999
/*
select a.sid, a.username, a.osuser, a.logon_time, b.cnt 
  from v$session a, (select qcsid,count(*) cnt from v$px_session where degree is not null group by qcsid having count(*) > 1) b
where a.sid = b.qcsid
;
*/

select sid, qcsid, server_set, degree, req_degree 
  from v$px_session 	
 order by qcsid;

select a.sid,a.serial#, a.username, a.osuser, to_char(a.logon_time,'MM/DD/YYYY HH24:MI:SS') logon_time, 
       round(a.last_call_et/3600,2) running_in_hrs, b.act_degree, b.req_degree
  from v$session a,  
(select qcsid, count(degree) act_degree, req_degree
  from v$px_session
 where degree is not null
 group by qcsid, req_degree) b
 where a.sid = b.qcsid
;
