set pages 200
col component_name for a45
col parameter for a15
SELECT SC.COMPONENT_NAME, sc.COMPONENT_TYPE, v.PARAMETER_DISPLAY_NAME 
PARAMETER, 
decode(v.PARAMETER_VALUE, 
1, '1 = Statement', 
2, '2 = Procedure', 
3, '3 = Event', 
4, '4 = Exception', 
5, '5 = Error', 
6, '6 = Unexpected', 
to_char(substr(v.PARAMETER_VALUE,1,12))) log_level 
FROM apps.FND_SVC_COMP_PARAM_VALS_V v, apps.FND_SVC_COMPONENTS SC 
WHERE v.COMPONENT_ID=sc.COMPONENT_ID 
AND (v.parameter_name = 'COMPONENT_LOG_LEVEL') 
ORDER BY 2 desc, 4, 1; 
