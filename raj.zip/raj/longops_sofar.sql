CLEAR  COL BREAK COMPUTE
SET    FEEDBACK ON VERIFY OFF ECHO OFF PAUSE OFF PAGES 1000
SELECT '           Sid/Serial# : '''||ses.sid||' , '||ses.serial#||'''
'||'  User Pid (Dont Kill) : '||ses.process||'
'||'    User/OsUsr/Machine : '||ses.usrinfo||'
'||'  Status/Last Call ETU : '||ses.status||' / '||ses.etu||' Min'||'
'||'            Logon Time : '||ses.logon_time||'
'||'
'||'           Target Desc : '||a.target_desc||'
'||'            Start Time : '||a.start_time||'
'||'     Last Updated Time : '||a.last_update_time||'
'||'         What is Doing : '||a.message||'
'||'           Elapsed Min : '||ROUND(elapsed_seconds/60)||'
'||'             Completed : '||ROUND((a.sofar/a.totalwork)*100)||' %'||'
'||'        Time Remaining : '||ROUND(a.time_remaining/60)||'
'||lpad('-',80,'-') SQL_LONG_OPS_DETAIL
FROM   v$session_longops a, (SELECT sid, serial#, status, logon_time, process,
                                    round(last_call_et/60) etu,sql_address,
                                    sql_hash_value, username||' / '||
                                    osuser||' / '||machine usrinfo
                             FROM   v$session
                             WHERE  sid = NVL('&Sid_Mandatory_____',0)) ses
WHERE  a.sid    = ses.sid
ORDER  BY a.start_time;
PROMPT
SET    FEEDBACK ON VERIFY OFF ECHO OFF PAUSE OFF PAGES 32

