set lines 132
set pages 300
break on report
compute sum of count on report
select count(*) kount, program from v$session where type<>'BACKGROUND' group by program order by program;

set pages 400
set lines 150
ttitle 'Current sessions in Oracle with program name'
column pu format a10 heading 'O/S|Login|ID' justify left
column su format a10 heading 'Oracle|User ID' justify left
column stat format a12 heading 'Session|Status' justify left
column ssid format 9999 heading 'Oracle|Sesn|ID' justify right
column sser format 999999 heading 'Oracle|Serial|No' justify right
column spid format 999999 heading 'UNIX|Process|ID' justify right
column prog format a20 heading 'Current Program' justify center word
column logon_time format a15 heading 'Logon_Time' justify center word
column terminal format a10 heading 'Terminal' justify center word
column machine format a10 heading 'Machine' justify center word
column status format a8 heading 'Status' justify center word
column running format 999.99 heading 'Runing|(Min)' justify center word
column sql_text format a64 heading 'Sql_Statements' justify center word wrapped
column spid format 999999 heading 'UNIX|Process|ID' justify right

break on spid skip 1 on spid on ssid on pu on su on machine on running on status
prompt
prompt
prompt 'Enter OS User or Oracle User based on the Need, For all Do not Enter OS User or Oracle User ....'
prompt
prompt
accept osuser char Prompt 'Enter OS Username :'
accept oracle_username char Prompt 'Enter Oracle Username :'
accept run_time char Prompt 'Enter Running Since (in Seconds) :'
set verify off
spool sql_text_in_sessions
select lpad(p.spid,7) spid, sesn.sid ssid, sesn.osuser pu, sesn.username su, sesn.machine,status, 
       round(last_call_et/60,2) running,
       sqlt.sql_text
  from v$sqltext sqlt, v$session sesn, v$process p
 where sqlt.address = sesn.sql_address
   and sqlt.hash_value = sesn.sql_hash_value
   and p.addr = sesn.paddr
   and sesn.username is not null
   and (sesn.sid, sesn.serial#) in
       (select sid, serial#
                from (
                select st.sid, ss.serial#
                from v$sesstat st, v$session ss
                where st.sid = ss.sid
                and statistic#=12
                and st.value > 0
                and ss.username <> 'SYS'
		and upper(ss.username) = decode(upper('&&oracle_username'),null,upper(ss.username),upper('&&oracle_username'))
		and upper(ss.osuser) = decode(upper('&&osuser'),null,upper(ss.osuser),upper('&&osuser'))
		and ss.last_call_et > decode('&run_time',null,0,'&run_time')
                order by value desc)
	)
  order by spid ,sqlt.piece;
spool off
