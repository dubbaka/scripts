sqlplus /nolog<<EOF
CONNECT / AS SYSDBA
@?/rdbms/admin/utlrp.sql
exit
EOF
