select sum(u.blocks)*8/1024 "Total Temp Space Usage in MB"
  from v$session s, v$process p, v$sqlarea a, v$sort_usage u, v$sess_io si
 where s.type!='BACKGROUND'
   and s.username is not null
   and s.paddr=p.addr (+)
   and s.sql_hash_value=a.hash_value (+)
   and s.saddr    = u.session_addr (+)
   and s.sid = si.sid (+)
   and s.username not in ('SYS','SYSTEM')
order by 1
;


