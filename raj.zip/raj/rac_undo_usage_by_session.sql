select s.inst_id,s.sid, 
       s.username,
       trunc(sum(ss.value) / 1024 / 1024,0) as undo_size_mb
from  gv$sesstat ss
  join gv$session s on s.sid = ss.sid
  join gv$statname stat on stat.statistic# = ss.statistic#
where stat.name = 'undo change vector size'
and s.type <> 'BACKGROUND'
and s.username IS NOT NULL
group by s.inst_id,s.sid, s.username having trunc(sum(ss.value) /1024/1024/1024,0) > 50 order by sum(ss.value) / 1024 / 1024;  
