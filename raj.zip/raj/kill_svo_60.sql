select 'alter system kill session '''||sid||','||serial#||''' immediate;'  from v$session where username='XXCTSSVOSTS_U' and program like 'java@%' and status='ACTIVE' and last_call_et/60>60;
