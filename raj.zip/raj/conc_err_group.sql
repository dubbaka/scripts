col "Concurrent Program Name" for a70
col PROGRAM for a20
col requestor for a20
set pages 2000
select distinct
PROGRAM "Concurrent Program Name",requestor,to_char(actual_completion_date,'DD-MON-YYYY HH24') "Completion Time",count(*)
from apps.FND_CONC_REQUESTS_FORM_V
where status_code='E'
and ACTUAL_COMPLETION_DATE > sysdate-1/24
group by PROGRAM,requestor,to_char(actual_completion_date,'DD-MON-YYYY HH24')
order by 3,4
/
