set lines 200
 set pages 999 trims on echo off verify off pau off
    ttitle 'List of Indexes under &owner Schema being Used now by Following Sessions'
    column pu format a15 heading 'O/S|Login_ID' justify left
    column su format a15 heading 'Oracle|User_ID' justify left
    column stat format a8 heading 'Session|Status' justify left
    column ssid format 999999 heading 'Oracle|SID' justify right
    column sser format 999999 heading 'Oracle|Serial#' justify right
    column upid format a10 heading 'UNIX|Process_ID' justify right
    column txt format a28 heading 'Current Program' justify center word
    column logon_time format a15 heading 'Logon_Time' justify center word
    column terminal format a10 heading 'Terminal' justify center word
    column machine format a20 heading 'Machine' justify center word
    column object_name format a30 heading 'OBJECT_NAME' justify center word
    column running_since format 9999999.99 justify center word
accept owner char prompt 'Enter Schema Owner :'
spool indexes_being_used
    select s.osuser pu, s.username pu, s.sid ssid, s.serial# sser, lpad(p.spid,7) upid, s.status stat, sp.object_name,
           s.last_call_et/(3600) running_since, s.program txt
      from v$process p, v$session s, v$sql_plan sp
     where p.addr=s.paddr
       and s.username is not null
       and s.sql_address = sp.address
       and s.sql_hash_value = sp.hash_value
       and sp.object_owner='&&owner'
       and sp.object_name in (select index_name from dba_indexes where owner='&&owner')
     order by 1,2,7 ;
spool off
