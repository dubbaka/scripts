set echo off verify off trimspool on lines 197 pages 500 colsep ','
col "Request Id" for 999999999999
col "Concurrent Program Name" for a45 trunc
col requestor for a15
col Phase for a12
col Status for a12
col "Start Time" for a20
col "Completion Time" for a20
col "Application" for a20 trunc
spool currently_running.lst
select distinct
request_id "Request Id",
PROGRAM "Concurrent Program Name",decode(PHASE_CODE,'C','Completed','I','Inactive','P ','Pending','R','Running','NA') "Phase",decode(STATUS_CODE, 'A','Waiting', 'B','Resuming', 'C','Normal', 'D','Cancelled', 'E','Error', 'F','Scheduled', 'G','Warning', 'H','On Hold', 'I','Normal', 'M', 'No Manager', 'Q','Standby', 'R','Normal', 'S','Suspended', 'T','Terminating', 'U','Disabled', 'W','Paused', 'X','Terminated', 'Z','Waiting') "Status",to_char(ACTUAL_START_DATE,'DD-MON-YYYY HH24:MI') " Start Time",to_char(ACTUAL_COMPLETION_DATE,'DD-MON-YYYY')
from apps.FND_CONC_REQUESTS_FORM_V
where PROGRAM in (
--'AP and PO Accrual Reconciliation Report',
--'Autoinvoice Master Program',
--'FB AGIS Intercompany Balances Elimination Automation Program',
--'FB FA OBIEE Depreciation Journal',
--'FB GL Mass Allocation Automation',
--'FB Process Prepaid Expense Amortization Data',
--'FB SFDC Salesforce to Oracle Ad Account Sync',
--'FB Update Lookup Onhold Invoices',
--'FB: FA Reconciliation Extract Program',
--'Facebook Serf to OAT Exception Report',
--'Interface Move Transactions to Oracle Assets',
'Invoice Validation',
--'Open Purchase Orders Report(by Cost Center)',
--'Period Close Exceptions Report (XML)',
--'Program - Daily Rates Import and Calculation',
--'Report Set',
--'Request Set Stage',
--'Revenue Recognition Execution Report',
--'Transfer Journal Entries to GL',
--'XXFB AP Period Close Automation Run All',
--'XXFB Depreciation Run',
'XXFB Month End Exception Report',
'XXFB: AP Serengeti Invoices Batch Extract Program (Web Service)'
)
and to_char(ACTUAL_COMPLETION_DATE,'DD-MON-YYYY') = '15-OCT-2016'
order by 4 desc;
