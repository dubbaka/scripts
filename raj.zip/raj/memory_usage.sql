SET LINESIZE 132
SET PAGESIZE 500
SET FEEDBACK OFF
SET VERIFY OFF
SET SERVEROUTPUT ON
SET TRIMSPOOL ON
COL "SESSION" FORMAT A50
COL "PID/THREAD" FORMAT A10
COL " CURRENT SIZE" FORMAT A18
COL " MAXIMUM SIZE" FORMAT A18
ttitle center 'List of Sessions using memory more than &&usage_in_mb MB' skip 1 center '*******************************************' skip 2
PROMPT :::::::::::::::::::::::::::::::::: PROGRAM GLOBAL AREA statistics :::::::::::::::::::::::::::::::::
spool memory_usage
SELECT to_char(ssn.sid, '9999') || ' - ' || nvl(ssn.username,
       nvl(bgp.name, 'background')) || ': ' || nvl(lower(ssn.machine), ins.host_name) "SESSION",
       to_char(prc.spid, '999999999') "PID/THREAD", to_char((se1.value/1024)/1024, '999G999G990D00') || ' MB' "CURRENT_SIZE",
       to_char((se2.value/1024)/1024, '999G999G990D00') || ' MB' " MAXIMUM SIZE"
  FROM v$sesstat se1, v$sesstat se2, v$session ssn, v$bgprocess bgp, v$process prc, v$instance ins
 WHERE se1.statistic# = 20
   AND se2.statistic# = 21
   AND se1.sid = ssn.sid
   AND se2.sid = ssn.sid
   AND ssn.paddr = bgp.paddr (+)
   AND ssn.paddr = prc.addr (+)
   AND to_char((se1.value/1024)/1024, '999G999G990D00') > decode('&&usage_in_mb',null,0,'&&usage_in_mb')
 ORDER BY current_size DESC
;

REM Showing UGA statistics for each session and background process
prompt
prompt
PROMPT PROMPT :::::::::::::::::::::::::::::::::::: USER GLOBAL AREA statistics ::::::::::::::::::::::::::::::::::
prompt
prompt
SELECT to_char(ssn.sid, '9999') || ' - ' || nvl(ssn.username,
       nvl(bgp.name, 'background')) || ': ' || nvl(lower(ssn.machine), ins.host_name) "SESSION",
       to_char(prc.spid, '999999999') "PID/THREAD", to_char((se1.value/1024)/1024, '999G999G990D00') || ' MB' "CURRENT_SIZE",
       to_char((se2.value/1024)/1024, '999G999G990D00') || ' MB' " MAXIMUM SIZE"
  FROM v$sesstat se1, v$sesstat se2, v$session ssn, v$bgprocess bgp, v$process prc, v$instance ins
 WHERE se1.statistic# = 15
   AND se2.statistic# = 16
   AND se1.sid = ssn.sid
   AND se2.sid = ssn.sid
   AND ssn.paddr = bgp.paddr (+)
   AND ssn.paddr = prc.addr (+)
   AND to_char((se1.value/1024)/1024, '999G999G990D00') > decode('&&usage_in_mb',null,0,'&&usage_in_mb')
 ORDER BY current_size DESC
;
spool off
