col component_name for a35
col component_status for a25
SELECT component_name, component_status
FROM applsys.fnd_svc_components
WHERE component_type = 'WF_MAILER';
