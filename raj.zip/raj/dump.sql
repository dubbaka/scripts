connect / as sysdba
spool  systemdump.log
oradebug setmypid
oradebug unlimit
oradebug dump systemstate 10
--wait 90 seconds
--oradebug dump systemstate 10
--wait 90 seconds
--oradebug dump systemstate 10
spool off
exit
