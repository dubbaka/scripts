set pagesize 24 linesize 80 echo off feedback 1 wrap on lines 200
column reqid format 9999999999 heading "Request Id"
column sesid format a10 heading "Session"
column ospid format a10 heading "OS Pid"
col username for a10
col module for a35
col event format a30
select
   c.inst_id,a.request_id reqid,
   d.sid||','||d.serial# sesid,
   c.spid ospid,
--   to_char(logon_time,'DD-MON-YYYY HH24:MI:SS'),
   round(d.last_call_et/60,0) "Mins",
   d.username,d.sql_hash_value,
   d.module,d.event
from
   applsys.fnd_concurrent_requests a,
   applsys.fnd_concurrent_processes b,
  gv$process c, gv$session d
where
   a.controlling_manager=b.concurrent_process_id
   and c.inst_id=d.inst_id
   and c.spid=a.oracle_process_id
   and c.addr=d.paddr
   and c.inst_id=d.inst_id
   and d.module like '&Module'
   and a.phase_code='&Phase_Code'
order by 4 desc;
