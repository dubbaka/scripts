set linesize 155; 
set pagesize 200; 
set verify off; 
column MANAGER format a15; 
column MEANING format a15; 
SELECT concurrent_queue_name manager, fcp.last_update_date, fcp.concurrent_process_id pid, meaning, fcp.logfile_name 
FROM apps.fnd_concurrent_queues fcq, apps.fnd_concurrent_processes fcp, apps.fnd_lookups flkup 
WHERE concurrent_queue_name in ('WFMLRSVC')
AND fcq.concurrent_queue_id = fcp.concurrent_queue_id 
AND fcq.application_id = fcp.queue_application_id 
AND flkup.lookup_code=fcp.process_status_code 
AND lookup_type ='CP_PROCESS_STATUS_CODE' 
AND meaning='Active';
