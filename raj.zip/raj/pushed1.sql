set verify off
set pagesize 50
undefine dblink
col dblink format a20
col enq_tid format a20
compute sum of count(*) on dblink
break on dblink skip 2
PROMPT "Pl give the Db link name or press Return for all DB links"

select /*+ rule */ b.dblink , count(*)
from   system.def$_calldest b, system.def$_destination c, system.def$_aqcall a
where b.dblink = c.dblink
and a.enq_tid = b.enq_tid
and a.cscn is not null
and a.cscn < c.last_delivered
and b.dblink like  nvl('&dblink','%')
group by    b.dblink
/

