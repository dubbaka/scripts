                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."K_SHIP_AOL" AUTHID CURRENT_USER as                                                              
/* $Header: K_SHIP_AOL.sql 2.1.1.0 2010/04/19 12:00:00 dex                                                                          
sys ship $ Copyright (c) 2008 DEX Systems, Inc. */                                                                                  
                                                                                                                                    
   procedure LOG_SET;                                                                                                               
   procedure LOG_UNSET;                                                                                                             
                                                                                                                                    
   function  CHECK_SHIP    (                                                                                                        
                             myOrder     varchar2                                                                                   
                            ,myTranID    number default                                                                             
0                                                                                                                                   
                            ,myShipID    number default null                                                                        
                           ) return      varchar2;                                                                                  
                                                                                                                                    
   procedure RETURN_RMA    (                                                                                                        
                             myRetMesg   out  varchar2                                                                              
                            ,myRetCode   out  number                                                                                
                            ,myOrder     in   varchar2                                                                              
                            ,myShip      in   number                                                                                
                            ,myCore      in   varchar2 d                                                                            
efault 'N'                                                                                                                          
                           );                                                                                                       
                                                                                                                                    
   procedure SHIP          (                                                                                                        
                             myRetMesg   out  varchar2                                                                              
                            ,myRetCode   out  number                                                                                
                            ,myShipType  in   varchar2                                                                              
                            ,myOrder     in   varcha                                                                                
r2                                                                                                                                  
                            ,myTranID    in   number                                                                                
                            ,myEmp       in   varchar2                                                                              
                            ,myShipID    in   number         default 0                                                              
                            ,myPickID    in   number                                                                                
         default 0                                                                                                                  
                            ,myShipVia   in   varchar2                                                                              
  default null                                                                                                                      
                            ,myWaybill   in   varchar2       de                                                                     
fault null                                                                                                                          
                            ,myFreight   in   number         defaul                                                                 
t 0                                                                                                                                 
                            ,myWeight    in   number         default 0                                                              
                            ,myDate      in   date                                                                                  
      default SYSDATE                                                                                                               
                            ,myNonSerl   in   varchar2                                                                              
     default 'N'                                                                                                                    
                           );                                                                                                       
   procedure SHIP          (                                                                                                        
                             myShipType  varchar2                                                                                   
                            ,myOrder     varchar2                                                                                   
                            ,myTranID    number                                                                                     
                            ,myEmp       varchar2                                                                                   
                            ,myShipID    number         default                                                                     
0                                                                                                                                   
                            ,myPickID    number         default 0                                                                   
                            ,myShipVia   varchar2       defaul                                                                      
t null                                                                                                                              
                            ,myWaybill   varchar2       default null                                                                
                            ,myFreight   number                                                                                     
  default 0                                                                                                                         
                            ,myWeight    number         default 0                                                                   
                            ,myDate      date                                                                                       
    default SYSDATE                                                                                                                 
                           );                                                                                                       
   function  SHIP          (                                                                                                        
                             myShipType  varchar2                                                                                   
                            ,myOrder     varchar2                                                                                   
                            ,myTranID    number                                                                                     
                            ,myEmp       varchar2                                                                                   
                            ,myShipID    number         defau                                                                       
lt 0                                                                                                                                
                            ,myPickID    number         default 0                                                                   
                            ,myShipVia   varchar2       def                                                                         
ault null                                                                                                                           
                            ,myWaybill   varchar2       default null                                                                
                                                                                                                                    
                            ,myFreight   number         default 0                                                                   
                            ,myWeight    number         default                                                                     
 0                                                                                                                                  
                            ,myDate      date           default SYSDATE                                                             
                           ) return      varchar2;                                                                                  
                                                                                                                                    
   procedure OTV           (                                                                                                        
                             myShipID    number                                                                                     
                            ,myEmp       varchar2                                                                                   
                            ,myShipVia   varchar2                                                                                   
                            ,myWaybill   varchar2                                                                                   
                            ,myFreight   number                                                                                     
                            ,myWeight    number                                                                                     
                           );                                                                                                       
                                                                                                                                    
   procedure OTV_EMAIL     ( myShipID number );                                                                                     
                                                                                                                                    
   procedure PROCESS       (                                                                                                        
                             myPLog     in   varchar2  default 'N                                                                   
'                                                                                                                                   
                            ,myPShipID  in   number    default null                                                                 
                            ,myCust     in   varchar2  defau                                                                        
lt null                                                                                                                             
                           );                                                                                                       
                                                                                                                                    
                                                                                                                                    
   procedure PROCESS_APPS  (                                                                                                        
                             myRetMesg  out  varchar2                                                                               
                            ,myRetCode  out  number                                                                                 
                            ,myPLog     in   varchar2  defa                                                                         
ult 'N'                                                                                                                             
                            ,myPShipID  in   number    default null                                                                 
                           );                                                                                                       
                                                                                                                                    
   procedure PROC_APPS     (                                                                                                        
                             myRetMesg  out  varchar2                                                                               
                            ,myRetCode  out  number                                                                                 
                            ,myCust     in   varchar2                                                                               
                           );                                                                                                       
                                                                                                                                    
end K_SHIP_AOL;                                                                                                                     
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."K_SHIP_AOL" as                                                                               
/* $Header: K_SHIP_AOL.sql 2.1.1.0 2010/04/19 12:00:00 dexsys ship $ C                                                              
opyright (c) 2008 DEX Systems, Inc. */                                                                                              
                                                                                                                                    
   mySect        varchar2(100) := null;                                                                                             
                                                                                                                                    
   myLog         varchar2(1)   := 'N';                                                                                              
                                                                                                                                    
   myUserID      number(15)   := F_DEX_USER_ID;                                                                                     
                                                                                                                                    
   /************************************************************                                                                    
**********************************************/                                                                                     
                                                                                                                                    
   procedure LOG is                                                                                                                 
   begin                                                                                                                            
      if myLog = 'Y' then                                                                                                           
         K_DEX_LOG.LOG ( mySect,null,'K_SHIP_AOL' );                                                                                
                                                                                                                                    
                                                                                                                                    
         dbms_output.put_line ( mySect );                                                                                           
      end if;                                                                                                                       
   end LOG;                                                                                                                         
                                                                                                                                    
   /*******************************************************                                                                         
***************************************************/                                                                                
                                                                                                                                    
                                                                                                                                    
   procedure LOG_SET is                                                                                                             
   begin                                                                                                                            
      myLog := 'Y';                                                                                                                 
      K_DEX_LOG.LOG_SET;                                                                                                            
   end LOG_SET;                                                                                                                     
                                                                                                                                    
   /*******************************************************                                                                         
***************************************************/                                                                                
                                                                                                                                    
                                                                                                                                    
   procedure LOG_UNSET is                                                                                                           
   begin                                                                                                                            
      myLog := 'N';                                                                                                                 
      K_DEX_LOG.LOG_UNSET;                                                                                                          
   end LOG_UNSET;                                                                                                                   
                                                                                                                                    
   /*************************************************                                                                               
****************************************************                                                                                
*****/                                                                                                                              
                                                                                                                                    
   procedure MAIL_SEND (                                                                                                            
                         myFromAddr  varchar2                                                                                       
                        ,myToAddr    varchar2                                                                                       
                        ,myCCAddr    varchar2                                                                                       
                        ,myBCCAddr   varchar2                                                                                       
                        ,mySubj      varchar2                                                                                       
                        ,myBody      varchar2                                                                                       
                       ) is                                                                                                         
      myDBName       varchar2(20);                                                                                                  
      mySubject      varchar2(2000);                                                                                                
      myEmailAddr    varchar2(2000) := myToAddr;                                                                                    
                                                                                                                                    
   begin                                                                                                                            
      select NAME                                                                                                                   
      into   myDBName                                                                                                               
      from   V$DATABASE;                                                                                                            
                                                                                                                                    
      if myDBName = 'PROD' then                                                                                                     
         mySubject   := mySubj;                                                                                                     
                                                                                                                                    
      else                                                                                                                          
         myEmailAddr := DEX_ORG_EMAILS_F ( 'TEST_GROUP' );                                                                          
                                                                                                                                    
         mySubject   := '** ' || myDBName || ' ** ' || myS                                                                          
ubj;                                                                                                                                
      end if;                                                                                                                       
                                                                                                                                    
      K_DEX_MAIL.SEND ( myFromAddr,myEmailAddr,myCCAddr,my                                                                          
BCCAddr,mySubject,myBody );                                                                                                         
   end MAIL_SEND;                                                                                                                   
                                                                                                                                    
   /*****************************************************                                                                           
*************************************/                                                                                              
                                                                                                                                    
     -- special post processing after shipping has occurred                                                                         
   procedure SHIP_POST_PROCESS ( myShipID number) is                                                                                
      myProgName    FND_CONCURRENT_PROGRAMS.CONCURRENT_                                                                             
PROGRAM_NAME%type;                                                                                                                  
      myPrinter     FND_CONCURRENT_PROGRAMS.PRINTER_NAME%ty                                                                         
pe;                                                                                                                                 
                                                                                                                                    
      myAppName     varchar2(20);                                                                                                   
                                                                                                                                    
      myCopies      number;                                                                                                         
                                                                                                                                    
      myParentCode  varchar2(20);                                                                                                   
      myRetMesg     varchar2(2000);                                                                                                 
                                                                                                                                    
      myRequestID   number(15);                                                                                                     
      myCustID      number(15);                                                                                                     
      myOrgID       number(15);                                                                                                     
                                                                                                                                    
   begin                                                                                                                            
   	begin                                                                                                                           
	      select rac.CUSTOMER_ID                                                                                                       
   	         ,dxp.ORG_ID                                                                                                            
	      into   myCustID                                                                                                              
   	         ,myOrgID                                                                                                               
      	from   DEX_PLANTS dxp                                                                                                        
         	   ,XXDEX_PARTIES_V rac                                                                                                   
            	,DEX_SHIP_HISTORY dsh                                                                                                  
	      where  dsh.SHIP_ID = myShipID                                                                                                
   	   and    dsh.SHIP_TYPE not in ('E','D')                                                                                        
      	and    rac.CUSTOMER_NUMBER = decode(dsh.SHIP_TYPE,'C',d                                                                      
sh.SEGMENT1                                                                                                                         
         	                                              ,'R',dsh.S                                                                  
EGMENT5                                                                                                                             
            	                                           ,'W',dsh.SEGME                                                              
NT5                                                                                                                                 
               	                                            ,dsh.SEGMENT2)                                                          
                                                                                                                                    
      	and    dsh.PLANT = dxp.PLANT;                                                                                                
                                                                                                                                    
      	select fna.APPLICATION_SHORT_NAME                                                                                            
      	      ,fcp.CONCURRENT_PROGRAM_NAME                                                                                           
      	      ,dcx.PRINTER_NAME                                                                                                      
      	      ,dcx.COPIES                                                                                                            
      	into   myAppName                                                                                                             
      	      ,myProgName                                                                                                            
      	      ,myPrinter                                                                                                             
      	      ,myCopies                                                                                                              
      	from   DEX_CUSTOMER_DATA dcd                                                                                                 
      	      ,DEX_CUSTOMER_DOCUMENTS dcx                                                                                            
      	      ,FND_CONCURRENT_PROGRAMS_VL fcp                                                                                        
      	      ,FND_APPLICATION fna                                                                                                   
      	where  dcd.CUSTOMER_ID     = myCustID                                                                                        
      	and    dcd.ORG_ID          = myOrgID                                                                                         
      	and    dcd.CUSTOMER_ID     = dcx.CUSTOMER_ID                                                                                 
      	and    dcx.DATA_TYPE       = 'PSP'                                                                                           
                          -- Post Shipping Process                                                                                  
      	and    dcx.LABEL_REPORT_ID = fcp.CONCURRENT_PR                                                                               
OGRAM_ID                                                                                                                            
      	and    fcp.APPLICATION_ID  = fna.APPLICATION_ID                                                                              
      	and    rownum < 2;                                                                                                           
                                                                                                                                    
    	exception                                                                                                                      
    		when NO_DATA_FOUND then                                                                                                       
    			if XXDEX_DEFAULTS_F('POST_SHIPPING_PROCESS') = 'Y' then                                                                      
    				myProgName := 'DEX_SHIP_POST_PROC';                                                                                         
    				myAppName := DEX_APP_F;                                                                                                     
    			end if;                                                                                                                      
		end;                                                                                                                              
                                                                                                                                    
		if myProgName is not null then                                                                                                    
      	myRetMesg := K_DEX_CONC_REQUEST.SUBMIT (                                                                                     
                                                  myRequestID                                                                       
                                                 ,myA                                                                               
ppName                                                                                                                              
                                                 ,myProgName                                                                        
                                                 ,null                                                                              
                                                 ,myPrinter                                                                         
                                                                                                                                    
                                                 ,myCopies                 --                                                       
 Copies                                                                                                                             
                                                 ,myShipID                                                                          
     -- Parameter 1   (ShipID)                                                                                                      
                                                 ,chr(0)                                                                            
      	                                       );                                                                                    
		end if;                                                                                                                           
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         null;                                                                                                                      
   end SHIP_POST_PROCESS;                                                                                                           
                                                                                                                                    
   /********************************************************                                                                        
**************************************************/                                                                                 
                                                                                                                                    
   function CHECK_SHIP (                                                                                                            
                         myOrder    varchar2                                                                                        
                        ,myTranID   number default 0                                                                                
                        ,myShipID   number default null                                                                             
                       ) return     varchar2 is                                                                                     
                                                                                                                                    
      myItemPayPal    varchar2(100);                                                                                                
      myItemAmazon    varchar2(100);                                                                                                
      myItemSrvFee    varchar2(100);                                                                                                
                                                                                                                                    
      myShipto      pls_integer;                                                                                                    
      myPayTranID   pls_integer;                                                                                                    
      myCustID      pls_integer;                                                                                                    
      mySiteUseID   pls_integer;                                                                                                    
                                                                                                                                    
      myRetMesg     varchar2(2000) := null;                                                                                         
                                                                                                                                    
      myInvMgmt     DEX_CUSTOMER_DATA.ADVREP_FLAG%typ                                                                               
e;                                                                                                                                  
      myBillType    DEX_CUSTOMER_DATA.ADVREP_BILL_TYPE%type;                                                                        
      myZeroPrice   DEX_CUSTOMER_DATA.ZERO_PRICE_ALLOWED_FLAG%type                                                                  
;                                                                                                                                   
                                                                                                                                    
      myCardType    DEX_ORDERS.CREDIT_CARD_TYPE%type;                                                                               
      myCardName    DEX_ORDERS.CREDIT_CARD_NAME%type;                                                                               
      myCardAcct    DEX_ORDERS.CREDIT_CARD_ACCT%type;                                                                               
      myCardExp     DEX_ORDERS.CREDIT_CARD_EXP%type;                                                                                
      myCustPO      DEX_ORDERS.CUSTPO%type;                                                                                         
      myOrgID       DEX_ORDERS.ORG_ID%type;                                                                                         
      myStreet      DEX_ORDERS.SHIP_ST1%type;                                                                                       
      myZip         DEX_ORDERS.SHIP_ZIP%type;                                                                                       
      myOrdType     DEX_ORDERS.ORDTYPE%type;                                                                                        
      myBoxKit      DEX_ORDERS.BOX_KIT%type;                                                                                        
      myCust        DEX_ORDERS.CUST%type;                                                                                           
                                                                                                                                    
      myTerms       RA_TERMS.NAME%type;                                                                                             
                                                                                                                                    
      myAmt         number := 0;                                                                                                    
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select S.ITEM                                                                                                              
               ,S.SCRAP                                                                                                             
               ,D.HOLD_CODE                                                                                                         
               ,D.PRICE                                                                                                             
               ,D.STATCODE                                                                                                          
               ,D.STORE                                                                                                             
               ,D.PART                                                                                                              
         from   DEX_SERIALS S                                                                                                       
               ,DEX_LINES D                                                                                                         
         where  S.ORDERNO = D.ORDERNO                                                                                               
         and    S.ITEM    = D.ITEM                                                                                                  
         and    S.ORDERNO = myOrder                                                                                                 
         and    TRAN_ID   = myTranID                                                                                                
         union                                                                                                                      
         select ITEM                                                                                                                
               ,'N'                                                                                                                 
               ,HOLD_CODE                                                                                                           
               ,(QTYSCH * PRICE) PRICE                                                                                              
               ,STATCODE                                                                                                            
               ,STORE                                                                                                               
               ,PART                                                                                                                
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    STATUS  = 'O'                                                                                                       
         and    QTYSCH  > 0                                                                                                         
         union                                                                                                                      
         select ITEM                                                                                                                
               ,'N'                                                                                                                 
               ,HOLD_CODE                                                                                                           
               ,(QTYSCH * PRICE) PRICE                                                                                              
               ,STATCODE                                                                                                            
               ,STORE                                                                                                               
               ,PART                                                                                                                
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    ITEM in                                                                                                             
               (select ITEM                                                                                                         
                from   DEX_SHIP_LINES_INTERFACE                                                                                     
                where  SHIP_ID = myShipID);                                                                                         
                                                                                                                                    
   begin                                                                                                                            
      select H.SHIPTO                                                                                                               
            ,H.CREDIT_CARD_TYPE                                                                                                     
            ,H.CREDIT_CARD_NAME                                                                                                     
            ,H.CREDIT_CARD_ACCT                                                                                                     
            ,H.CREDIT_CARD_EXP                                                                                                      
            ,H.CUSTPO                                                                                                               
            ,H.ORG_ID                                                                                                               
            ,H.SHIP_ST1                                                                                                             
            ,H.SHIP_ZIP                                                                                                             
            ,H.ORDTYPE                                                                                                              
            ,H.CUSTOMER_ID                                                                                                          
            ,H.BILL_SITE_USE_ID                                                                                                     
            ,H.BOX_KIT                                                                                                              
            ,C.ADVREP_FLAG                                                                                                          
            ,C.ADVREP_BILL_TYPE                                                                                                     
            ,C.ZERO_PRICE_ALLOWED_FLAG                                                                                              
            ,H.CUST                                                                                                                 
      into   myShipto                                                                                                               
            ,myCardType                                                                                                             
            ,myCardName                                                                                                             
            ,myCardAcct                                                                                                             
            ,myCardExp                                                                                                              
            ,myCustPO                                                                                                               
            ,myOrgID                                                                                                                
            ,myStreet                                                                                                               
            ,myZip                                                                                                                  
            ,myOrdType                                                                                                              
            ,myCustID                                                                                                               
            ,mySiteUseID                                                                                                            
            ,myBoxKit                                                                                                               
            ,myInvMgmt                                                                                                              
            ,myBillType                                                                                                             
            ,myZeroPrice                                                                                                            
            ,myCust                                                                                                                 
      from   DEX_CUSTOMER_DATA C                                                                                                    
            ,DEX_ORDERS H                                                                                                           
      where  H.CUSTOMER_ID = C.CUSTOMER_ID                                                                                          
      and    H.ORG_ID      = C.ORG_ID                                                                                               
      and    H.ORDERNO     = myOrder;                                                                                               
                                                                                                                                    
      myItemPayPal := XXDEX_DEFAULTS_F ( 'ITEM_PAYPAL_FEE',myOrgID )                                                                
;                                                                                                                                   
      myItemAmazon := XXDEX_DEFAULTS_F ( 'ITEM_AMAZON_FEE',myOrgID );                                                               
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         if c1r.HOLD_CODE is not null then                                                                                          
            return ( 'Item on Hold: ' || c1r.HOLD_CODE );                                                                           
                                                                                                                                    
         elsif c1r.SCRAP = 'Y' then                                                                                                 
            null;                                                                                                                   
                                                                                                                                    
         elsif c1r.PRICE > 0 then                                                                                                   
            null;                                                                                                                   
                                                                                                                                    
         elsif c1r.PART in (myItemPayPal,myItemAmazon) a                                                                            
nd c1r.PRICE < 0 then                                                                                                               
            null;                                                                                                                   
                                                                                                                                    
         elsif c1r.STATCODE = 'W' then                                                                                              
            null;                                                                                                                   
                                                                                                                                    
         elsif instr(c1r.PART,'NON-REPAIR') > 0 then                                                                                
            null;                                                                                                                   
                                                                                                                                    
         elsif myInvMgmt = 'Y' and myOrdType = 'R' and myBillTy                                                                     
pe != 'R' then                                                                                                                      
            null;                                                                                                                   
                                                                                                                                    
         elsif myInvMgmt = 'Y' and myOrdType != 'R' and myBillType = '                                                              
R' then                                                                                                                             
            null;                                                                                                                   
                                                                                                                                    
         elsif myShipto in (96,97) then                                                                                             
            null;                                                                                                                   
                                                                                                                                    
         elsif myZeroPrice = 'Y' then                                                                                               
            null;                                                                                                                   
                                                                                                                                    
         elsif myZeroPrice = 'B' and (myBoxKit = 'Y' or instr(c1r                                                                   
.PART,'BOXKIT') > 0) then                                                                                                           
            null;                                                                                                                   
                                                                                                                                    
         elsif c1r.PRICE = 0 and c1r.STATCODE = 'X' then                                                                            
            return ( 'Zero Price Evaluation' );                                                                                     
                                                                                                                                    
        elsif myCust = 'DEXB' then                                                                                                  
            null;                                                                                                                   
                                                                                                                                    
         else                                                                                                                       
            return ( 'Price Required');                                                                                             
         end if;                                                                                                                    
                                                                                                                                    
         myAmt := myAmt + c1r.PRICE;                                                                                                
      end loop;                                                                                                                     
                                                                                                                                    
      begin                                                                                                                         
         select NAME                                                                                                                
         into   myTerms                                                                                                             
         from   XXDEX_CUSTOMER_PROFILES_V acp                                                                                       
               ,RA_TERMS       rtl                                                                                                  
         where  acp.CUSTOMER_ID    = myCustID                                                                                       
         and    acp.SITE_USE_ID    = mySiteUseID                                                                                    
         and    acp.STATUS         = 'A'                                                                                            
         and    acp.STANDARD_TERMS = rtl.TERM_ID;                                                                                   
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myTerms := 'N/A';                                                                                                       
      end;                                                                                                                          
                                                                                                                                    
      if myTerms = 'Credit Card' and myAmt != 0 and myCardT                                                                         
ype != 'PP' then                                                                                                                    
         myRetMesg := K_DEX_WEB_PAYMENTS.VALID_AUTH ( myOrder                                                                       
,myAmt );                                                                                                                           
                                                                                                                                    
         if myRetMesg != 'VALID' then                                                                                               
            return ( 'Credit Card Declined' || chr(10)                                                                              
|| myRetMesg );                                                                                                                     
         end if;                                                                                                                    
                                                                                                                                    
      else                                                                                                                          
         myTerms := 'N/A';                                                                                                          
      end if;                                                                                                                       
/*                                                                                                                                  
      if myTranID > 0 then                                                                                                          
         update DEX_LINES D set                                                                                                     
         QTYSCH =                                                                                                                   
            (select count('*')                                                                                                      
             from   DEX_SERIALS S                                                                                                   
             where  D.ORDERNO = S.ORDERNO                                                                                           
             and    D.ITEM = S.ITEM                                                                                                 
             and    S.LOCATION in ('STK','SRP','SHI')                                                                               
             and    S.TRAN_ID = myTranID)                                                                                           
         where (D.ORDERNO,D.ITEM) in                                                                                                
             (select distinct ORDERNO,ITEM                                                                                          
              from   DEX_SERIALS                                                                                                    
              where  ORDERNO = myOrder                                                                                              
              and    LOCATION in ('STK','SRP','SHI')                                                                                
              and    TRAN_ID = myTranID);                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      if myTranID > 0 then                                                                                                          
         update DEX_LINES D set                                                                                                     
         QTYSCH = 0                                                                                                                 
         where (D.ORDERNO,D.ITEM) in                                                                                                
             (select distinct ORDERNO,ITEM                                                                                          
              from DEX_SERIALS                                                                                                      
              where ORDERNO = myOrder                                                                                               
              and LOCATION in ('STK','SRP','SHI')                                                                                   
              and TRAN_ID = myTranID);                                                                                              
      end if;                                                                                                                       
*/                                                                                                                                  
      return ( null );                                                                                                              
                                                                                                                                    
--      if myRetMesg is not null then                                                                                               
--         raise_application_error( -20001,myRetMesg );                                                                             
                                                                                                                                    
--      end if;                                                                                                                     
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         return ( SQLERRM );                                                                                                        
   end CHECK_SHIP;                                                                                                                  
                                                                                                                                    
   /*************************************************                                                                               
****************************************************                                                                                
*****/                                                                                                                              
                                                                                                                                    
   procedure LOAD_SERIAL_STOCK ( myOrder varchar2,myTranID number ) is                                                              
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select SERIAL_ID                                                                                                           
               ,TRACK                                                                                                               
         from   DEX_SERIALS                                                                                                         
         where  ORDERNO = myOrder                                                                                                   
         and    TRAN_ID = myTranID;                                                                                                 
                                                                                                                                    
      cursor c2 ( mySerial varchar2 ) is                                                                                            
         select poh.SEGMENT1           PO_NUMBER                                                                                    
               ,pov.SEGMENT1           VENDOR_NUMBER                                                                                
               ,pll.LINE_LOCATION_ID                                                                                                
         from   PO_VENDORS pov                                                                                                      
               ,PO_LINE_LOCATIONS_ALL pll                                                                                           
               ,PO_LINES_ALL pol                                                                                                    
               ,PO_HEADERS_ALL poh                                                                                                  
               ,MTL_UNIT_TRANSACTIONS mut                                                                                           
         where  mut.TRANSACTION_SOURCE_ID      = poh.PO_HEADER_ID                                                                   
         and    poh.PO_HEADER_ID               = pol.P                                                                              
O_HEADER_ID                                                                                                                         
         and    pol.PO_LINE_ID                 = pll.PO_LINE_ID                                                                     
         and    poh.VENDOR_ID                  = pov.V                                                                              
ENDOR_ID                                                                                                                            
         and    mut.INVENTORY_ITEM_ID          = pol.ITEM_ID                                                                        
         and    mut.SERIAL_NUMBER              = mySerial                                                                           
         and    mut.TRANSACTION_SOURCE_TYPE_ID = 1                                                                                  
         order by pll.LAST_UPDATE_DATE;                                                                                             
                                                                                                                                    
      myPOLocnID     number;                                                                                                        
                                                                                                                                    
      myRevision     varchar2(10);                                                                                                  
      myPONum        varchar2(10);                                                                                                  
      myVendor       varchar2(10);                                                                                                  
                                                                                                                                    
   begin                                                                                                                            
      for c1r in c1 loop                                                                                                            
         myPONum    := null;                                                                                                        
         myVendor   := null;                                                                                                        
         myPOLocnID := null;                                                                                                        
         myRevision := null;                                                                                                        
                                                                                                                                    
         for c2r in c2 ( c1r.TRACK ) loop                                                                                           
            myPONum    := c2r.PO_NUMBER;                                                                                            
            myVendor   := c2r.VENDOR_NUMBER;                                                                                        
            myPOLocnID := c2r.LINE_LOCATION_ID;                                                                                     
                                                                                                                                    
            exit;                                                                                                                   
         end loop;                                                                                                                  
                                                                                                                                    
         update DEX_SERIALS set                                                                                                     
         PO_NO            = myPONum                                                                                                 
        ,VENDOR           = myVendor                                                                                                
        ,REVISION         = myRevision                                                                                              
        ,LINE_LOCATION_ID = myPOLocnID                                                                                              
         where SERIAL_ID = c1r.SERIAL_ID;                                                                                           
      end loop;                                                                                                                     
   end LOAD_SERIAL_STOCK;                                                                                                           
                                                                                                                                    
   /************************************************************************                                                        
**********************************/                                                                                                 
                                                                                                                                    
   procedure RETURN_RMA (                                                                                                           
                          myRetMesg   out  varchar2                                                                                 
                         ,myRetCode   out  number                                                                                   
                         ,myOrder     in   varchar2                                                                                 
                         ,myShip      in   number                                                                                   
                         ,myCore      in   varchar2 default 'N'                                                                     
                        ) is                                                                                                        
      myExchFlag        varchar2(1);                                                                                                
      myStatus          varchar2(1);                                                                                                
      myNew             varchar2(1) := 'N';                                                                                         
      myPlant           DEX_PLANTS.PLANT%type;                                                                                      
      myOrdSrc          varchar2(2);                                                                                                
      myCall            varchar2(10);                                                                                               
      myRMA             varchar2(10);                                                                                               
      myCust            varchar2(10);                                                                                               
      myECust           varchar2(10);                                                                                               
                                                                                                                                    
      myPkgCust         DEX_CUSTOMER_DATA.PACKAGE_CUST%type;                                                                        
      myPkgName         DEX_CUSTOMER_DATA.PACKAGE_NAME%t                                                                            
ype;                                                                                                                                
      myParent          DEX_CUSTOMER_DATA.PARENT_CODE%type;                                                                         
                                                                                                                                    
      myCustID          pls_integer;                                                                                                
      mySpclHand        pls_integer;                                                                                                
                                                                                                                                    
      myIntDays         number(5);                                                                                                  
      myInvOrgID        pls_integer;                                                                                                
                                                                                                                                    
      myItem            number(5) := 0;                                                                                             
      myUnique          number(5) := 0;                                                                                             
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select shd.ITEM                                                                                                            
               ,shd.CUSTITEM                                                                                                        
               ,shd.INVENTORY_ITEM_ID                                                                                               
               ,shd.PART                                                                                                            
               ,shd.DESCR       DESCRIPTION                                                                                         
               ,shd.GRP                                                                                                             
               ,shd.OEM                                                                                                             
               ,shd.CUSTPART                                                                                                        
               ,shd.QTYORG                                                                                                          
               ,shd.INV_MGMT                                                                                                        
               ,lne.ATTRIBUTE_CATEGORY                                                                                              
               ,lne.ATTRIBUTE1                                                                                                      
               ,lne.ATTRIBUTE2                                                                                                      
               ,lne.ATTRIBUTE3                                                                                                      
               ,lne.ATTRIBUTE4                                                                                                      
               ,lne.ATTRIBUTE5                                                                                                      
               ,lne.ATTRIBUTE6                                                                                                      
               ,lne.ATTRIBUTE7                                                                                                      
               ,lne.ATTRIBUTE8                                                                                                      
               ,lne.ATTRIBUTE9                                                                                                      
               ,lne.ATTRIBUTE10                                                                                                     
               ,lne.COMMENTS                                                                                                        
               ,lne.CORE_FLAG                                                                                                       
               ,lne.CORE_PRICE                                                                                                      
         from   DEX_LINES lne                                                                                                       
               ,DEX_SHPDETS shd                                                                                                     
         where  shd.ORDERNO            = lne.ORDERNO                                                                                
         and    shd.ITEM               = lne.ITEM                                                                                   
         and    shd.ORDERNO            = myOrder                                                                                    
         and    shd.SHIPMENT           = myShip                                                                                     
         and    nvl(lne.CORE_FLAG,'N') = nvl(myCore,'N')                                                                            
         order by shd.ITEM desc;                                                                                                    
                                                                                                                                    
      cursor c2 ( mySItem number ) is                                                                                               
         select SERIAL                                                                                                              
               ,TAG_NUMBER                                                                                                          
               ,REASON                                                                                                              
               ,SERIAL_ID                                                                                                           
               ,ATTRIBUTE_CATEGORY                                                                                                  
               ,ATTRIBUTE1                                                                                                          
               ,ATTRIBUTE2                                                                                                          
               ,ATTRIBUTE3                                                                                                          
               ,ATTRIBUTE4                                                                                                          
               ,ATTRIBUTE5                                                                                                          
         from   DEX_SERIALS                                                                                                         
         where  ORDERNO  = myOrder                                                                                                  
         and    SHIPMENT = myShip                                                                                                   
         and    ITEM     = mySItem;                                                                                                 
                                                                                                                                    
      cursor c3 is                                                                                                                  
         select rac.CUSTOMER_NUMBER                                                                                                 
         from   XXDEX_PARTIES_V rac                                                                                                 
               ,PO_VENDORS pov                                                                                                      
               ,PO_HEADERS_ALL poh                                                                                                  
               ,PO_LINE_LOCATIONS_ALL pll                                                                                           
               ,DEX_LINES_PURCHASES dlp                                                                                             
               ,DEX_LINES lne                                                                                                       
               ,DEX_SHPDETS shd                                                                                                     
         where  shd.ORDERNO          = lne.ORDERNO                                                                                  
         and    shd.ITEM             = lne.ITEM                                                                                     
         and    shd.ORDERNO          = dlp.ORDERNO                                                                                  
         and    shd.ITEM             = dlp.ITEM                                                                                     
         and    dlp.LINE_LOCATION_ID = pll.LINE_LOCATION_ID                                                                         
         and    pll.PO_HEADER_ID     = poh.PO_HEADER_ID                                                                             
         and    poh.VENDOR_ID        = pov.VENDOR_ID                                                                                
         and    pov.ATTRIBUTE9       = rac.CUSTOMER_ID                                                                              
         and    lne.CORE_FLAG        = 'A'                                                                                          
         and    shd.ORDERNO          = myOrder                                                                                      
         and    shd.SHIPMENT         = myShip                                                                                       
         and    pov.ATTRIBUTE9 is not null;                                                                                         
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'RtrnRMA - Cust Info';                                                                                              
                                                                                                                                    
      select ord.CUST                                                                                                               
            ,ord.CUST                                                                                                               
            ,ord.PLANT                                                                                                              
            ,ord.RMA                                                                                                                
            ,ord.RETURN_RMA                                                                                                         
            ,ord.SPECIAL_HANDLING                                                                                                   
            ,nvl(dcd.INTRANSIT_DAYS,7)                                                                                              
            ,nvl(dcd.EXCHANGE_FLAG,'N')                                                                                             
            ,dcd.PACKAGE_CUST                                                                                                       
            ,dcd.PACKAGE_NAME                                                                                                       
            ,dcd.PARENT_CODE                                                                                                        
            ,dcd.CUSTOMER_ID                                                                                                        
      into   myCust                                                                                                                 
            ,myECust                                                                                                                
            ,myPlant                                                                                                                
            ,myRMA                                                                                                                  
            ,myCall                                                                                                                 
            ,mySpclHand                                                                                                             
            ,myIntDays                                                                                                              
            ,myExchFlag                                                                                                             
            ,myPkgCust                                                                                                              
            ,myPkgName                                                                                                              
            ,myParent                                                                                                               
            ,myCustID                                                                                                               
      from   DEX_CUSTOMER_DATA dcd                                                                                                  
            ,DEX_ORDERS ord                                                                                                         
      where  ord.CUSTOMER_ID = dcd.CUSTOMER_ID                                                                                      
      and    ord.ORG_ID      = dcd.ORG_ID                                                                                           
      and    ord.ORDERNO     = myOrder;                                                                                             
                                                                                                                                    
      if nvl(mySpclHand,0) > 0 then                                                                                                 
         log;                                                                                                                       
         mySect := 'RtrnRMA - Special Handling';                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,32 ) > 0 then                                                                                 
            return;                                                                                                                 
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      if myExchFlag = 'Y' then                                                                                                      
         myOrdSrc := 'AE';                                                                                                          
                                                                                                                                    
      elsif myCore = 'A' then                                                                                                       
         myOrdSrc := 'AC';                                                                                                          
  -- Advanced Core                                                                                                                  
                                                                                                                                    
      elsif myCore = 'Y' then                                                                                                       
         myOrdSrc := 'LC';                                                                                                          
  -- Line Core                                                                                                                      
                                                                                                                                    
      else                                                                                                                          
         myOrdSrc := 'SH';                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      if myOrdSrc = 'AC' then                                                                                                       
         myCust := 'DEXS';                                                                                                          
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'RtrnRMA - c3 loop';                                                                                             
                                                                                                                                    
         for c3r in c3 loop                                                                                                         
            myCust := c3r.CUSTOMER_NUMBER;                                                                                          
                                                                                                                                    
            exit;                                                                                                                   
         end loop;                                                                                                                  
                                                                                                                                    
      elsif myExchFlag = 'Y' or myCore in ('Y','A') then                                                                            
         myCust := 'DEXS';                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      if myCust != 'DEXS' then                                                                                                      
         myECust := null;                                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'RtrnRMA - Org';                                                                                                    
                                                                                                                                    
      select ORGANIZATION_ID                                                                                                        
      into   myInvOrgID                                                                                                             
      from   DEX_ORGANIZATIONS dxo                                                                                                  
      where  PLANT         = myPlant                                                                                                
      and    BUSINESS_TYPE = decode(myExchFlag,'Y','D','R');                                                                        
                                                                                                                                    
      if myCall is not null then                                                                                                    
         begin                                                                                                                      
            select STATUS                                                                                                           
            into   myStatus                                                                                                         
            from   RMAHDR                                                                                                           
            where  CALL = myCall;                                                                                                   
                                                                                                                                    
            if myStatus = 'C' then                                                                                                  
               myCall := null;                                                                                                      
                                                                                                                                    
            else                                                                                                                    
               select nvl(max(ITEM),0)                                                                                              
               into   myItem                                                                                                        
               from   DEX_RMADET                                                                                                    
               where  CALL = myCall;                                                                                                
                                                                                                                                    
               myNew := 'N';                                                                                                        
            end if;                                                                                                                 
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myNew := 'Y';                                                                                                        
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      if myCall is null then                                                                                                        
         log;                                                                                                                       
         mySect := 'RtrnRMA - Call';                                                                                                
                                                                                                                                    
         myCall := F_PREBOOK_CHECK;                                                                                                 
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'RtrnRMA - Update RMA';                                                                                          
                                                                                                                                    
         update DEX_ORDERS set                                                                                                      
         RETURN_RMA = myCall                                                                                                        
         where ORDERNO = myOrder;                                                                                                   
                                                                                                                                    
         myNew := 'Y';                                                                                                              
      end if;                                                                                                                       
                                                                                                                                    
      if myNew = 'Y' then                                                                                                           
         log;                                                                                                                       
         mySect := 'RtrnRMA - Insert RMAHDR';                                                                                       
                                                                                                                                    
         insert into DEX_RMAHDR                                                                                                     
        (CALL                                                                                                                       
        ,CUSTPO                                                                                                                     
        ,SHIPTO                                                                                                                     
        ,DROP_SHIP                                                                                                                  
        ,SHIP_VIA                                                                                                                   
        ,SHIP_NAME                                                                                                                  
        ,SHIP_ATTN                                                                                                                  
        ,SHIP_ST1                                                                                                                   
        ,SHIP_ST2                                                                                                                   
        ,SHIP_CITY                                                                                                                  
        ,SHIP_STATE                                                                                                                 
        ,SHIP_ZIP                                                                                                                   
        ,COUNTRY                                                                                                                    
        ,DATEEXP                                                                                                                    
        ,CUST                                                                                                                       
        ,CUST_EXCHANGE                                                                                                              
        ,CUSTOMER_ID                                                                                                                
        ,BILL_SITE_USE_ID                                                                                                           
        ,SHIP_SITE_USE_ID                                                                                                           
        ,REGION                                                                                                                     
        ,AGENT                                                                                                                      
        ,TLM                                                                                                                        
        ,ORDTYPE                                                                                                                    
        ,PLANT                                                                                                                      
        ,PLANT_ID                                                                                                                   
        ,ORG_ID                                                                                                                     
        ,STATUS                                                                                                                     
        ,DATEOPN                                                                                                                    
        ,AUTHORIZATION                                                                                                              
        ,DISPATCH                                                                                                                   
        ,RELEASE                                                                                                                    
        ,INITIATOR                                                                                                                  
        ,REVERSE_AE                                                                                                                 
        ,BOX_KIT                                                                                                                    
        ,FROM_CODE                                                                                                                  
        ,SHIPMENT                                                                                                                   
        ,ORDER_SOURCE                                                                                                               
        ,ATTRIBUTE_CATEGORY                                                                                                         
        ,ATTRIBUTE1                                                                                                                 
        ,ATTRIBUTE2                                                                                                                 
        ,ATTRIBUTE3                                                                                                                 
        ,ATTRIBUTE4                                                                                                                 
        ,ATTRIBUTE5                                                                                                                 
        ,ATTRIBUTE6                                                                                                                 
        ,ATTRIBUTE7                                                                                                                 
        ,ATTRIBUTE8                                                                                                                 
        ,ATTRIBUTE9                                                                                                                 
        ,ATTRIBUTE10                                                                                                                
        ,ATTRIBUTE11                                                                                                                
        ,ATTRIBUTE12                                                                                                                
        ,ATTRIBUTE13                                                                                                                
        ,ATTRIBUTE14                                                                                                                
        ,ATTRIBUTE15)                                                                                                               
         select myCall                                                                                                              
               ,ord.CUSTPO                                                                                                          
               ,0                                                                                                                   
               ,'N'                                                                                                                 
               ,shp.CARRIER                                                                                                         
               ,shp.NAME                                                                                                            
               ,shp.ATTN                                                                                                            
               ,shp.STREET1                                                                                                         
               ,shp.STREET2                                                                                                         
               ,shp.CITY                                                                                                            
               ,shp.STATE                                                                                                           
               ,shp.ZIP                                                                                                             
               ,nvl(shp.COUNTRY,decode(shp.ORG_ID,206,'US',209,'                                                                    
IE','US'))                                                                                                                          
               ,SYSDATE + myIntDays                                                                                                 
               ,myCust                                                                                                              
                                        -- CUST                                                                                     
               ,myECust                                                                                                             
                                         -- CUST_EXC                                                                                
HANGE                                                                                                                               
               ,rac.CUSTOMER_ID                                                                                                     
                         -- CUSTOMER_ID                                                                                             
               ,shp.BILL_TO_SITE_USE_ID                                                                                             
                                 -- BILL_SITE_USE_ID                                                                                
                                                                                                                                    
               ,shp.SITE_USE_ID                                                                                                     
                    -- SHIP_SITE_USE_ID                                                                                             
               ,ord.REGION                                                                                                          
               ,ord.AGENT                                                                                                           
               ,ord.TLM                                                                                                             
               ,'R'                                                                                                                 
               ,ord.PLANT                                                                                                           
               ,ord.PLANT_ID                                                                                                        
               ,ord.ORG_ID                                                                                                          
               ,'O'                                                                                                                 
                              -- STATUS                                                                                             
               ,SYSDATE                                                                                                             
                                 -- DATEOPN                                                                                         
               ,ord.ORDERNO                                                                                                         
                                     -- AUTHORIZATIO                                                                                
N                                                                                                                                   
               ,substr(replace(ord.ORDERNO || '-' || to_char(myShip),' ','')                                                        
,1,10)               -- DISPATCH                                                                                                    
               ,substr(ord.RELEASE || ' (R) ' || ord.ORDERNO || '-' ||                                                              
to_char(myShip),1,60)     -- RELEASE                                                                                                
               ,decode(myCore,'Y','LINE CORE','A','LINE CORE',null)                                                                 
                              -- INITIATOR                                                                                          
               ,ord.REVERSE_AE                                                                                                      
               ,ord.BOX_KIT                                                                                                         
               ,ord.ORDERNO                                                                                                         
                                           -- FROM_C                                                                                
ODE                                                                                                                                 
               ,myShip                                                                                                              
                       -- SHIPMENT                                                                                                  
               ,myOrdSrc                                                                                                            
                            -- ORDER_SOURCE                                                                                         
               ,ord.ATTRIBUTE_CATEGORY                                                                                              
               ,ord.ATTRIBUTE1                                                                                                      
               ,ord.ATTRIBUTE2                                                                                                      
               ,ord.ATTRIBUTE3                                                                                                      
               ,ord.ATTRIBUTE4                                                                                                      
               ,ord.ATTRIBUTE5                                                                                                      
               ,ord.ATTRIBUTE6                                                                                                      
               ,ord.ATTRIBUTE7                                                                                                      
               ,ord.ATTRIBUTE8                                                                                                      
               ,ord.ATTRIBUTE9                                                                                                      
               ,ord.ATTRIBUTE10                                                                                                     
               ,ord.ATTRIBUTE11                                                                                                     
               ,ord.ATTRIBUTE12                                                                                                     
               ,ord.ATTRIBUTE13                                                                                                     
               ,ord.ATTRIBUTE14                                                                                                     
               ,ord.ATTRIBUTE15                                                                                                     
         from   V_DEX_CUST_SHIP shp                                                                                                 
               ,XXDEX_PARTIES_V rac                                                                                                 
               ,DEX_ORDERS ord                                                                                                      
         where  rac.CUSTOMER_NUMBER = myCust                                                                                        
         and    rac.CUSTOMER_ID     = shp.CUSTOMER_I                                                                                
D                                                                                                                                   
         and    ord.ORG_ID          = shp.ORG_ID                                                                                    
         and    shp.SHIPTO          = 0                                                                                             
         and    ord.ORDERNO         = myOrder;                                                                                      
                                                                                                                                    
         if SQL%notfound then                                                                                                       
            myRetCode := 1;                                                                                                         
            myRetMesg := 'Return RMA Header Not Inserted';                                                                          
                                                                                                                                    
            return;                                                                                                                 
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'RtrnRMA - Item';                                                                                                   
                                                                                                                                    
      select nvl(max(ITEM),0)                                                                                                       
      into   myItem                                                                                                                 
      from   DEX_RMADET                                                                                                             
      where  CALL = myCall;                                                                                                         
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'RtrnRMA - c1 loop';                                                                                                
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         myItem := myItem + 1;                                                                                                      
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'RtrnRMA - Insert DEX_RMADET';                                                                                   
                                                                                                                                    
         insert into DEX_RMADET                                                                                                     
        (CALL                                                                                                                       
        ,ITEM                                                                                                                       
        ,CUSTITEM                                                                                                                   
        ,DATEDET                                                                                                                    
        ,STATCODE                                                                                                                   
        ,STATUS                                                                                                                     
        ,QTYORG                                                                                                                     
        ,STORE                                                                                                                      
        ,INV_MGMT                                                                                                                   
        ,DATESCH                                                                                                                    
        ,PRICE                                                                                                                      
        ,PART                                                                                                                       
        ,DESCR                                                                                                                      
        ,GRP                                                                                                                        
        ,OEM                                                                                                                        
        ,CUSTPART                                                                                                                   
        ,INVENTORY_ITEM_ID                                                                                                          
        ,ORGANIZATION_ID                                                                                                            
        ,SUBINVENTORY_CODE                                                                                                          
        ,ATTRIBUTE_CATEGORY                                                                                                         
        ,ATTRIBUTE1                                                                                                                 
        ,ATTRIBUTE2                                                                                                                 
        ,ATTRIBUTE3                                                                                                                 
        ,ATTRIBUTE4                                                                                                                 
        ,ATTRIBUTE5                                                                                                                 
        ,ATTRIBUTE6                                                                                                                 
        ,ATTRIBUTE7                                                                                                                 
        ,ATTRIBUTE8                                                                                                                 
        ,ATTRIBUTE9                                                                                                                 
        ,ATTRIBUTE10                                                                                                                
        ,COMMENTS                                                                                                                   
        ,CORE_FLAG                                                                                                                  
        ,CORE_PRICE                                                                                                                 
        ) values (                                                                                                                  
         myCall                                                                                                                     
        ,myItem                                                                                                                     
        ,c1r.CUSTITEM                                                                                                               
        ,SYSDATE                                                                                                                    
        ,'N'                                                                                                                        
        ,'O'                                                                                                                        
        ,c1r.QTYORG                                                                                                                 
        ,'R'                                                                                                                        
        ,c1r.INV_MGMT                                                                                                               
        ,SYSDATE + myIntDays                                                                                                        
        ,0                                                                                                                          
        ,c1r.PART                                                                                                                   
        ,c1r.DESCRIPTION                                                                                                            
        ,c1r.GRP                                                                                                                    
        ,c1r.OEM                                                                                                                    
        ,c1r.CUSTPART                                                                                                               
        ,c1r.INVENTORY_ITEM_ID                                                                                                      
        ,myInvOrgID                                                                                                                 
        ,'Repair'                                                                                                                   
        ,c1r.ATTRIBUTE_CATEGORY                                                                                                     
        ,c1r.ATTRIBUTE1                                                                                                             
        ,c1r.ATTRIBUTE2                                                                                                             
        ,c1r.ATTRIBUTE3                                                                                                             
        ,c1r.ATTRIBUTE4                                                                                                             
        ,c1r.ATTRIBUTE5                                                                                                             
        ,c1r.ATTRIBUTE6                                                                                                             
        ,c1r.ATTRIBUTE7                                                                                                             
        ,c1r.ATTRIBUTE8                                                                                                             
        ,c1r.ATTRIBUTE9                                                                                                             
        ,c1r.ATTRIBUTE10                                                                                                            
        ,c1r.COMMENTS                                                                                                               
        ,c1r.CORE_FLAG                                                                                                              
        ,c1r.CORE_PRICE                                                                                                             
        );                                                                                                                          
                                                                                                                                    
         if SQL%notfound then                                                                                                       
            myRetCode := 1;                                                                                                         
            myRetMesg := 'Return RMA Line Not Inserted';                                                                            
                                                                                                                                    
            exit;                                                                                                                   
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'RtrnRMA - DEX_SHPDETS';                                                                                         
                                                                                                                                    
         update DEX_SHPDETS set                                                                                                     
         RETURN_RMA = myCall                                                                                                        
         where ORDERNO  = myOrder                                                                                                   
         and   SHIPMENT = myShip                                                                                                    
         and   ITEM     = myItem;                                                                                                   
                                                                                                                                    
         myUnique := 0;                                                                                                             
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'RtrnRMA - c2 loop';                                                                                             
                                                                                                                                    
         for c2r in c2 ( c1r.ITEM ) loop                                                                                            
            myUnique := myUnique + 1;                                                                                               
                                                                                                                                    
            insert into DEX_RMA_SERIALS                                                                                             
           (CALL                                                                                                                    
           ,SERIAL                                                                                                                  
           ,ITEM                                                                                                                    
           ,UNIQUENO                                                                                                                
           ,STATUS                                                                                                                  
           ,DATEENT                                                                                                                 
           ,TAG_NUMBER                                                                                                              
           ,REASON                                                                                                                  
           ,SERIAL_ID                                                                                                               
           ,ATTRIBUTE_CATEGORY                                                                                                      
           ,ATTRIBUTE1                                                                                                              
           ,ATTRIBUTE2                                                                                                              
           ,ATTRIBUTE3                                                                                                              
           ,ATTRIBUTE4                                                                                                              
           ,ATTRIBUTE5                                                                                                              
           ,SOURCE_SERIAL_ID                                                                                                        
           ) values (                                                                                                               
            myCall                                                                                                                  
           ,c2r.SERIAL                                                                                                              
           ,myItem                                                                                                                  
           ,myUnique                                                                                                                
           ,'O'                                                                                                                     
           ,SYSDATE                                                                                                                 
           ,c2r.TAG_NUMBER                                                                                                          
           ,c2r.REASON                                                                                                              
           ,c2r.SERIAL_ID                                                                                                           
           ,c2r.ATTRIBUTE_CATEGORY                                                                                                  
           ,c2r.ATTRIBUTE1                                                                                                          
           ,c2r.ATTRIBUTE2                                                                                                          
           ,c2r.ATTRIBUTE3                                                                                                          
           ,c2r.ATTRIBUTE4                                                                                                          
           ,c2r.ATTRIBUTE5                                                                                                          
           ,c2r.SERIAL_ID                                                                                                           
           );                                                                                                                       
                                                                                                                                    
            if SQL%notfound then                                                                                                    
               myRetCode := 1;                                                                                                      
               myRetMesg := 'Return RMA Serial Not Insert                                                                           
ed';                                                                                                                                
                                                                                                                                    
               exit;                                                                                                                
            end if;                                                                                                                 
         end loop;                                                                                                                  
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            exit;                                                                                                                   
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      if myOrdSrc = 'AC' then                                                                                                       
         log;                                                                                                                       
         mySect := 'RtrnRMA - Adv Core Load';                                                                                       
                                                                                                                                    
         K_DEX_ADVANCED_CORE.CALL ( myRetMesg,myRetCode,myOrder,myShip                                                              
);                                                                                                                                  
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            return;                                                                                                                 
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetCode := 2;                                                                                                            
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end RETURN_RMA;                                                                                                                  
                                                                                                                                    
   /******************************************************************                                                              
****************************************/                                                                                           
 		-- June 2009 (ac) Modified logic to allow both Serialized a                                                                      
nd Non Serialied on same shipment.                                                                                                  
   procedure SHIP (                                                                                                                 
                    myRetMesg   out  varchar2                                                                                       
                   ,myRetCode   out  number                                                                                         
                   ,myShipType  in   varchar2                                                                                       
                   ,myOrder     in   varchar2                                                                                       
                   ,myTranID    in   number                                                                                         
                   ,myEmp       in   varchar2                                                                                       
                   ,myShipID    in   number     default 0                                                                           
                   ,myPickID    in   number     default 0                                                                           
                                                                                                                                    
                   ,myShipVia   in   varchar2   default null                                                                        
                   ,myWaybill   in   varchar2   default null                                                                        
                   ,myFreight   in   number     default 0                                                                           
                   ,myWeight    in   number     defau                                                                               
lt 0                                                                                                                                
                   ,myDate      in   date       default SYSDATE                                                                     
                   ,myNonSerl   in   varchar2   default 'N'                                                                         
                  ) is                                                                                                              
      myShip          number(10);                                                                                                   
      myItem          number(8);                                                                                                    
      myFYR           number(4);                                                                                                    
      myFMO           number(2);                                                                                                    
      myFWK           number(2);                                                                                                    
      myQty           number(10);                                                                                                   
      myOrgID         number(15);                                                                                                   
      myCCHeadID      number(15);                                                                                                   
      myAShipID       number(15);                                                                                                   
      myRcvTranID     number(15);                                                                                                   
      mySerTranID     number(15);                                                                                                   
      myFeeCtlID      number(15);                                                                                                   
                                                                                                                                    
      myAmt           number;                                                                                                       
      myPrice         number;                                                                                                       
      myFee           number;                                                                                                       
                                                                                                                                    
      myOrdItem       number(5);                                                                                                    
      myFirstDays     number(5);                                                                                                    
      myQtyShp        number(10);                                                                                                   
      myJobNum        number(10);                                                                                                   
      myCustID        number(15);                                                                                                   
      myHeadID        number(15) := 0;                                                                                              
      myBillUseID     number(15);                                                                                                   
                                                                                                                                    
      myHasSerl		 varchar2(1) := 'N';                                                                                               
      myHasNonSerl	 varchar2(1) := 'N';                                                                                             
                                                                                                                                    
      myCoreFlag      varchar2(1) := 'N';                                                                                           
      myCCFlag        varchar2(1);              -- Call                                                                             
 Center Flag                                                                                                                        
      myInvMgmt       varchar2(1);                                                                                                  
      myExchange      varchar2(1);                                                                                                  
      myOrdType       varchar2(1);                                                                                                  
      myEDI           varchar2(1) := 'N';                                                                                           
      myTranFee       varchar2(1);                                                                                                  
      myMatlFee       varchar2(1);                                                                                                  
      myServFee       varchar2(1);                                                                                                  
      myInterco       varchar2(1);                                                                                                  
      myTmp           varchar2(2);                                                                                                  
      myOrderSrc      varchar2(2);                                                                                                  
      myRcptCode      varchar2(2);                                                                                                  
      mySPlant        varchar2(2);                                                                                                  
      myServCode      varchar2(2);                                                                                                  
      mySCust         varchar2(10);                                                                                                 
      mySTSNum        varchar2(10);                                                                                                 
                                                                                                                                    
      myItemPayPal    varchar2(100);                                                                                                
      myItemAmazon    varchar2(100);                                                                                                
      myItemSrvFee    varchar2(100);                                                                                                
                                                                                                                                    
      myOSPDistbPO    varchar2(1);                                                                                                  
                                                                                                                                    
      myPlant         DEX_ORDERS.PLANT%type;                                                                                        
      myRelease       DEX_ORDERS.RELEASE%type;                                                                                      
      myCustExch      DEX_ORDERS.CUST_EXCHANGE%type;                                                                                
      myAttr1         DEX_ORDERS.ATTRIBUTE1%type;                                                                                   
      myBoxKit        DEX_ORDERS.BOX_KIT%type;                                                                                      
      myPriceType     DEX_ORDERS.PRICE_TYPE_CODE%type;                                                                              
      myReturnRMA     DEX_ORDERS.RETURN_RMA%type;                                                                                   
                                                                                                                                    
      myCust          DEX_SHPHDRS.CUST%type;                                                                                        
                                                                                                                                    
      myPkgCust       DEX_CUSTOMER_DATA.PACKAGE_CUST%t                                                                              
ype;                                                                                                                                
      myRetTagFlag    DEX_CUSTOMER_DATA.RETURN_TAG_FLAG%type;                                                                       
      myRMAFlag       DEX_CUSTOMER_DATA.ADVREP_RMA_FLAG%type;                                                                       
      myParentCode    DEX_CUSTOMER_DATA.PARENT_CODE%t                                                                               
ype;                                                                                                                                
      myProgCode      DEX_CUSTOMER_DATA.PROGRAM_CODE%type;                                                                          
                                                                                                                                    
      myPODestType	 RCV_TRANSACTIONS.DESTINATION_TYPE_CODE%type;                                                                    
                                                                                                                                    
      myReturnWaybill DEX_CC_HEADERS.RETURN_WAYBILL%type;                                                                           
                                                                                                                                    
      myCustType      XXDEX_PARTIES_V.CUSTOMER_TYPE%type;                                                                           
                                                                                                                                    
      myCalcCode      DEX_SERVICE_FEES_CONTROL.CALC_CODE%type;                                                                      
      myFeePct        DEX_SERVICE_FEES_CONTROL.FEE_P                                                                                
CT%type;                                                                                                                            
                                                                                                                                    
      myIOrgID        number(15);                                                                                                   
      myDCodeID       number(15);                                                                                                   
      myCCodeID       number(15);                                                                                                   
                                                                                                                                    
      myCostAmt       number;                                                                                                       
                                                                                                                                    
      myRequestID     number(15);                                                                                                   
      myRqstMesg      varchar2(200);                                                                                                
                                                                                                                                    
      type num_tbl_typ is table of number(15) index by binary_integer;                                                              
                                                                                                                                    
                                                                                                                                    
      myStckTbl       num_tbl_typ;                                                                                                  
      myIOrgTbl       num_tbl_typ;                                                                                                  
                                                                                                                                    
      myIdx           binary_integer := 0;                                                                                          
                                                                                                                                    
      ABORT_SHIP      exception;                                                                                                    
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select ser.ITEM                                                                                                            
               ,avg(msn.INTERNAL_COST)  COST                                                                                        
         from   XXDEX_MTL_SERIAL_NUMBERS_V msn                                                                                      
               ,DEX_LINES lne                                                                                                       
               ,DEX_SERIALS ser                                                                                                     
         where  ser.ORDERNO           = lne.ORDERNO                                                                                 
         and    ser.ITEM              = lne.ITEM                                                                                    
         and    lne.ORGANIZATION_ID   = msn.CURRENT_ORGANIZATION_ID                                                                 
         and    ser.TRACK             = msn.SERIAL_NUM                                                                              
BER                                                                                                                                 
         and    lne.INVENTORY_ITEM_ID = msn.INVENTORY_ITEM_ID                                                                       
         and    msn.CURRENT_STATUS    = 3                                                                                           
         and    ser.ORDERNO           = myOrder                                                                                     
         and    ser.SHIPMENT          = myShip                                                                                      
         and    msn.INTERNAL_COST is not null                                                                                       
         group by ser.ITEM;                                                                                                         
                                                                                                                                    
      cursor c2 is                                                                                                                  
         select ITEM                                                                                                                
               ,COMMENTS                                                                                                            
               ,INVENTORY_ITEM_ID                                                                                                   
               ,CORE_FLAG                                                                                                           
               ,PRICE                                                                                                               
         from   DEX_LINES                                                                                                           
         where (ORDERNO,ITEM) in                                                                                                    
               (select ORDERNO,ITEM                                                                                                 
                from   DEX_SHPDETS D                                                                                                
                where  ORDERNO  = myOrder                                                                                           
                and    SHIPMENT = myShip);                                                                                          
                                                                                                                                    
		-- DR# 34317 Modifications need to allow processing of No                                                                         
n-Serialized and Serialized at same time.                                                                                           
		cursor c3 is                                                                                                                      
      	select lne.ORDERNO                                                                                                           
      			,lne.ITEM                                                                                                                  
      			,lne.QTYORG                                                                                                                
      			,nvl(lne.QTYSHP,0) QTYSHP                                                                                                  
      			,'S'		SER_TYPE                                                                                                             
      			,v.QTY                                                                                                                     
      	from   DEX_LINES lne                                                                                                         
      			,V_TRAN_TOTAL v                                                                                                            
      	where  v.TRAN_ID = myTranID                                                                                                  
      	and    v.ORDERNO = lne.ORDERNO                                                                                               
      	and    v.ITEM    = lne.ITEM                                                                                                  
      	union                                                                                                                        
      	select lne.ORDERNO                                                                                                           
      			,lne.ITEM                                                                                                                  
      			,lne.QTYORG                                                                                                                
      			,nvl(lne.QTYSHP,0) QTYSHP                                                                                                  
      			,'N' 		SER_TYPE                                                                                                            
      			,sum(dli.QTY) QTY                                                                                                          
      	from   DEX_LINES lne                                                                                                         
      			,DEX_SHIP_LINES_INTERFACE dli                                                                                              
      	where  dli.SHIP_ID = myShipID                                                                                                
      	and    dli.ORDERNO = lne.ORDERNO                                                                                             
      	and    dli.ITEM    = lne.ITEM                                                                                                
      	group  by lne.ORDERNO                                                                                                        
	      			,lne.ITEM                                                                                                                 
   	   			,lne.QTYORG                                                                                                               
      				,nvl(lne.QTYSHP,0);                                                                                                       
                                                                                                                                    
--                                                                                                                                  
--    myShipType                                                                                                                    
--         N - Normal      (Track/Manifest)                                                                                         
--         X - Transfer                                                                                                             
--         S - Surplus     (Recert/Dismantle)                                                                                       
--         E - External    (Charge)                                                                                                 
--         A - Auto        (Vendor Drop Ship)                                                                                       
--         H - House Scrap                                                                                                          
--         R - Return to Vendor                                                                                                     
--                                                                                                                                  
                                                                                                                                    
   begin                                                                                                                            
      myRetCode := 0;                                                                                                               
                                                                                                                                    
      mySect := 'Ship - Start';                                                                                                     
      log;                                                                                                                          
      mySect := 'Ship - Load Data';                                                                                                 
                                                                                                                                    
      select H.PLANT                                                                                                                
            ,H.ORDTYPE                                                                                                              
            ,H.CUST                                                                                                                 
            ,H.RELEASE                                                                                                              
            ,H.CUST_EXCHANGE                                                                                                        
            ,H.ATTRIBUTE1                                                                                                           
            ,H.BOX_KIT                                                                                                              
            ,decode(H.CC_HEADER_ID,null,'N','Y')                                                                                    
            ,H.CC_HEADER_ID                                                                                                         
            ,H.CUSTOMER_ID                                                                                                          
            ,H.PRICE_TYPE_CODE                                                                                                      
            ,H.ORDER_SOURCE                                                                                                         
            ,H.ORG_ID                                                                                                               
            ,H.BILL_SITE_USE_ID                                                                                                     
            ,H.RETURN_RMA                                                                                                           
            ,nvl(C.ADVREP_FLAG,'N')                                                                                                 
            ,nvl(C.EXCHANGE_FLAG,'N')                                                                                               
            ,C.PACKAGE_CUST                                                                                                         
            ,nvl(C.RETURN_TAG_FLAG,'N')                                                                                             
            ,nvl(C.ADVREP_RMA_FLAG,'N')                                                                                             
            ,nvl(C.CORE_NOTIFY_DAYS_FIRST,0)                                                                                        
            ,C.PARENT_CODE                                                                                                          
            ,C.PROGRAM_CODE                                                                                                         
            ,rac.CUSTOMER_TYPE                                                                                                      
            ,decode(C.INTERCO_ORG_ID,null,'N','Y')                                                                                  
      into   myPlant                                                                                                                
            ,myOrdType                                                                                                              
            ,myCust                                                                                                                 
            ,myRelease                                                                                                              
            ,myCustExch                                                                                                             
            ,myAttr1                                                                                                                
            ,myBoxKit                                                                                                               
            ,myCCFlag                                                                                                               
            ,myCCHeadID                                                                                                             
            ,myCustID                                                                                                               
            ,myPriceType                                                                                                            
            ,myOrderSrc                                                                                                             
            ,myOrgID                                                                                                                
            ,myBillUseID                                                                                                            
            ,myReturnRMA                                                                                                            
            ,myInvMgmt                                                                                                              
            ,myExchange                                                                                                             
            ,myPkgCust                                                                                                              
            ,myRetTagFlag                                                                                                           
            ,myRMAFlag                                                                                                              
            ,myFirstDays                                                                                                            
            ,myParentCode                                                                                                           
            ,myProgCode                                                                                                             
            ,myCustType                                                                                                             
            ,myInterco                                                                                                              
      from   XXDEX_PARTIES_V rac                                                                                                    
            ,DEX_CUSTOMER_DATA C                                                                                                    
            ,DEX_ORDERS H                                                                                                           
      where  H.CUSTOMER_ID = C.CUSTOMER_ID                                                                                          
      and    H.ORG_ID      = C.ORG_ID                                                                                               
      and    H.CUSTOMER_ID = rac.CUSTOMER_ID                                                                                        
      and    H.ORDERNO     = myOrder;                                                                                               
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Defaults';                                                                                                  
                                                                                                                                    
      myItemPayPal := XXDEX_DEFAULTS_F ( 'ITEM_PAYPAL_                                                                              
FEE',myOrgID );                                                                                                                     
      myItemAmazon := XXDEX_DEFAULTS_F ( 'ITEM_AMAZON_FEE',myO                                                                      
rgID );                                                                                                                             
      myItemSrvFee := XXDEX_DEFAULTS_F ( 'ITEM_SERVICE_FEE',myOrgID );                                                              
                                                                                                                                    
                                                                                                                                    
      log;                                                                                                                          
		mySect := 'Ship - Set of Books';                                                                                                  
                                                                                                                                    
		K_DEX_ENVIRONMENT.SET_OF_BOOKS( myOrgID );                                                                                        
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Tran Fee Init';                                                                                             
                                                                                                                                    
      begin                                                                                                                         
         select 'Y'                                                                                                                 
         into   myTranFee                                                                                                           
         from   DEX_CUSTOMER_CONTROL                                                                                                
         where  CUSTOMER_ID = myCustID                                                                                              
         and    ORG_ID      = myOrgID                                                                                               
         and    TYPE        = 'TFB';                                                                                                
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myTranFee := 'N';                                                                                                       
      end;                                                                                                                          
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Matl Fee Init';                                                                                             
                                                                                                                                    
      begin                                                                                                                         
         select 'Y'                                                                                                                 
         into   myMatlFee                                                                                                           
         from   DEX_CUSTOMER_CONTROL                                                                                                
         where  CUSTOMER_ID = myCustID                                                                                              
         and    ORG_ID      = myOrgID                                                                                               
         and    TYPE        = 'MFB'                                                                                                 
         and    DATA        in ('ROAR','SHP');                                                                                      
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myMatlFee := 'N';                                                                                                       
      end;                                                                                                                          
                                                                                                                                    
      if myOrdType = 'S' and myTranFee = 'N' then                                                                                   
         log;                                                                                                                       
         mySect := 'Ship - Sale Fee Init';                                                                                          
                                                                                                                                    
         begin                                                                                                                      
            select FEE_CONTROL_ID                                                                                                   
                  ,FEE_PCT / 100                                                                                                    
                  ,CALC_CODE                                                                                                        
            into   myFeeCtlID                                                                                                       
                  ,myFeePct                                                                                                         
                  ,myCalcCode                                                                                                       
            from   DEX_SERVICE_FEES_CONTROL                                                                                         
            where  CUSTOMER_ID    = myCustID                                                                                        
            and    ENABLED_FLAG   = 'Y'                                                                                             
            and    SALES_FEE_FLAG = 'Y';                                                                                            
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               null;                                                                                                                
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      /*********************************************                                                                                
********                                                                                                                            
      ****************   Transaction Fees   ***************                                                                         
      *****************************************************/                                                                        
                                                                                                                                    
      -- Jan 2008 - this logic was moved here prior to track being shipped fo                                                       
r non-Sales DEX_ORDERS                                                                                                              
      if myTranFee = 'Y' and myOrdType != 'S' then                                                                                  
         log;                                                                                                                       
         mySect := 'Ship - Tran Fee';                                                                                               
                                                                                                                                    
         K_DEX_TRANSACTION_FEES.SHIP ( myRetMesg,myRetC                                                                             
ode,myOrder,null,myTranID );                                                                                                        
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Services Billing Init';                                                                                     
                                                                                                                                    
      begin                                                                                                                         
         select nvl(SEGMENT1,myPlant)                                                                                               
               ,nvl(SEGMENT2,myServCode)                                                                                            
               ,nvl(SEGMENT3,myCust)                                                                                                
         into   mySPlant                                                                                                            
               ,myServCode                                                                                                          
               ,mySCust                                                                                                             
         from   DEX_CUSTOMER_CONTROL                                                                                                
         where  CUSTOMER_ID = myCustID                                                                                              
         and    ORG_ID      = myOrgID                                                                                               
         and    TYPE        = 'SVB'                                                                                                 
         and    DATA        = 'SHP';                                                                                                
                                                                                                                                    
         myServFee := 'Y';                                                                                                          
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myServFee := 'N';                                                                                                       
      end;                                                                                                                          
                                                                                                                                    
      dbms_output.put_line( 'ShipType: ' || myShipType || '                                                                         
Order: ' || myOrder || ' Plant: ' || myPlant || ' Cu                                                                                
st: ' || myCust );                                                                                                                  
      dbms_output.put_line( 'OrdType: ' || myOrdType || ' T                                                                         
ranFee: ' || myTranFee || ' CustID: ' || myCustID ||                                                                                
 ' MOrgID: ' || myOrgID );                                                                                                          
                                                                                                                                    
      if myCust = 'DEXB' and myShipType != 'R' then                                                                                 
         myRcptCode := 'ND';                                                                                                        
      end if;                                                                                                                       
                                                                                                                                    
      if myShipType not in ('X','E','A','R') then                                                                                   
			mySect := 'Ship - Check Ship Zero';                                                                                              
                                                                                                                                    
			myQty := 0;                                                                                                                      
			myRetMesg := null;                                                                                                               
                                                                                                                                    
			if myOrdType != 'S' then                                                                                                         
				myHasSerl := 'Y';                                                                                                               
				myHasNonSerl := 'N';                                                                                                            
                                                                                                                                    
				select count('*')                                                                                                               
            into   myQty                                                                                                            
            from   DEX_SERIALS                                                                                                      
            where  LOCATION = 'PKD'                                                                                                 
            and    ORDERNO  = myOrder                                                                                               
            and    TRAN_ID  = myTranID;                                                                                             
                                                                                                                                    
            if myQty = 0 then                                                                                                       
               myRetMesg := 'Quantity Shipped Zero - Order: ' || myOrder;                                                           
                                                                                                                                    
                                                                                                                                    
               raise ABORT_SHIP;                                                                                                    
            end if;                                                                                                                 
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Ship - Check Over Ship';                                                                                     
                                                                                                                                    
            begin                                                                                                                   
               select 'Y'                                                                                                           
               into   myTmp                                                                                                         
               from   V_TRAN_TOTAL S                                                                                                
                     ,DEX_LINES D                                                                                                   
               where  S.ORDERNO = D.ORDERNO                                                                                         
               and    S.ITEM    = D.ITEM                                                                                            
               and    S.TRAN_ID = myTranID                                                                                          
               and    D.ORDERNO = myOrder                                                                                           
               and    S.QTY + nvl(D.QTYSHP,0) > D.QTYORG;                                                                           
                                                                                                                                    
               myRetMesg := 'Quantity Over Shipped';                                                                                
                                                                                                                                    
                                                                                                                                    
               raise ABORT_SHIP;                                                                                                    
                                                                                                                                    
            exception                                                                                                               
               when others then                                                                                                     
                  myTmp := 'N';                                                                                                     
            end;                                                                                                                    
                                                                                                                                    
			else                                                                                                                             
				for r3 in c3 loop                                                                                                               
					myQty := myQty + r3.QTY;                                                                                                       
					if r3.QTY + r3.QTYSHP > r3.QTYORG then                                                                                         
						myRetMesg := 'Quantity Over Shipped';                                                                                         
						exit;                                                                                                                         
					end if;                                                                                                                        
                                                                                                                                    
					if r3.SER_TYPE = 'N' then                                                                                                      
						myHasNonSerl := 'Y';                                                                                                          
					end if;                                                                                                                        
                                                                                                                                    
					if r3.SER_TYPE = 'S' then                                                                                                      
						myHasSerl := 'Y';                                                                                                             
					end if;                                                                                                                        
				end loop;                                                                                                                       
                                                                                                                                    
				if myQty = 0 then                                                                                                               
				   myRetMesg := 'Quantity Shipped Zero - Order: ' |                                                                             
| myOrder;                                                                                                                          
				end if;                                                                                                                         
                                                                                                                                    
				if myRetMesg is not null then                                                                                                   
					raise ABORT_SHIP;                                                                                                              
				end if;                                                                                                                         
			end if;                                                                                                                          
                                                                                                                                    
      elsif myShipType = 'A' then                                                                                                   
         log;                                                                                                                       
         mySect := 'Ship - Check Ship Zero (A)';                                                                                    
                                                                                                                                    
         select to_number(SEGMENT3)                                                                                                 
               ,to_number(SEGMENT4)                                                                                                 
               ,to_number(ATTRIBUTE2)                                                                                               
               ,to_number(ATTRIBUTE1)                                                                                               
               ,to_number(ATTRIBUTE3)                                                                                               
         into   myQty                                                                                                               
               ,myItem                                                                                                              
               ,myAShipID                                                                                                           
               ,myRcvTranID                                                                                                         
               ,mySerTranID                                                                                                         
         from   DEX_SHIP_INTERFACE                                                                                                  
         where  SHIP_ID = myShipID;                                                                                                 
                                                                                                                                    
         if myQty = 0 then                                                                                                          
            myRetMesg := 'Quantity Shipped Zero (A) - Ship ID                                                                       
: ' || myShipID;                                                                                                                    
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
			begin                                                                                                                            
				select DESTINATION_TYPE_CODE                                                                                                    
				into   myPODestType                                                                                                             
				from   RCV_TRANSACTIONS                                                                                                         
				where  TRANSACTION_ID = myRcvTranID;                                                                                            
			exception                                                                                                                        
				when OTHERS then                                                                                                                
					myPODestType := null;                                                                                                          
			end;                                                                                                                             
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Check Over Ship (A)';                                                                                    
                                                                                                                                    
         begin                                                                                                                      
            select 'Y'                                                                                                              
            into   myTmp                                                                                                            
            from   DEX_LINES                                                                                                        
            where  ORDERNO = myOrder                                                                                                
            and    ITEM    = myItem                                                                                                 
            and    QTYORG  < (nvl(QTYSHP,0) + myQty);                                                                               
                                                                                                                                    
            myRetMesg := 'Quantity Over Shipped (A)';                                                                               
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myTmp := 'N';                                                                                                        
         end;                                                                                                                       
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - OSP Distb PO Chck(A)';                                                                                   
                                                                                                                                    
         -- determine what type of PO this Attribute1                                                                               
 is tied to.                                                                                                                        
         begin                                                                                                                      
            select 'Y'                                                                                                              
            into   myOSPDistbPO                                                                                                     
            from   PO_LINE_LOCATIONS_ALL pll                                                                                        
                  ,PO_HEADERS_ALL poh                                                                                               
                  ,DEX_ORGANIZATIONS dxo                                                                                            
                  ,RCV_TRANSACTIONS rcv                                                                                             
                  ,DEX_SHIP_INTERFACE dsh                                                                                           
            where  dsh.SHIP_ID                 = myShipID                                                                           
            and    dsh.ATTRIBUTE1              = rcv.TRANSACTION_ID                                                                 
            and    rcv.PO_LINE_LOCATION_ID     = pll.                                                                               
LINE_LOCATION_ID                                                                                                                    
            and    pll.PO_HEADER_ID            = poh.PO_HEADE                                                                       
R_ID                                                                                                                                
            and    pll.SHIP_TO_ORGANIZATION_ID = dxo.ORGANIZATION_ID                                                                
            and    poh.ATTRIBUTE1              = 'OSP'                                                                              
            and    dxo.BUSINESS_TYPE           = 'D'                                                                                
            and    rownum < 2;                                                                                                      
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myOSPDistbPO := 'N';                                                                                                 
         end;                                                                                                                       
                                                                                                                                    
         -- don't check for duplicate RCV Trans (Attribute1) already o                                                              
n History table because on OSP Distribution PO there                                                                                
 can be                                                                                                                             
         -- multiple DEXB DEX_ORDERS shipped for a single OSP PO (Rcv                                                               
Transaction)                                                                                                                        
         if myOSPDistbPO != 'Y' then                                                                                                
            begin                                                                                                                   
               log;                                                                                                                 
               mySect := 'Ship - Check Duplicate Tran (A)';                                                                         
                                                                                                                                    
               select 'Y'                                                                                                           
               into   myTmp                                                                                                         
               from   DEX_SHIP_HISTORY                                                                                              
               where  SHIP_TYPE  = 'A'                                                                                              
               and    ATTRIBUTE1 =                                                                                                  
                     (select ATTRIBUTE1                                                                                             
                      from   DEX_SHIP_INTERFACE                                                                                     
                      where  SHIP_ID = myShipID);                                                                                   
                                                                                                                                    
               myRetMesg := 'Duplicate Rcv Tran ID (A)';                                                                            
                                                                                                                                    
               raise ABORT_SHIP;                                                                                                    
                                                                                                                                    
            exception                                                                                                               
               when NO_DATA_FOUND then                                                                                              
                  myTmp := 'N';                                                                                                     
            end;                                                                                                                    
         end if;                                                                                                                    
                                                                                                                                    
      elsif myShipType = 'E' then                                                                                                   
         log;                                                                                                                       
         mySect := 'Ship - Check Ship Zero (E)';                                                                                    
                                                                                                                                    
         select sum(QTYSCH)                                                                                                         
         into   myQty                                                                                                               
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    QTYSCH  > 0;                                                                                                        
                                                                                                                                    
         if myQty = 0 then                                                                                                          
            myRetMesg := 'Quantity Shipped Zero (E) - Order: ' || myOrder;                                                          
                                                                                                                                    
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Check Over Ship (E)';                                                                                    
                                                                                                                                    
         begin                                                                                                                      
            select 'Y'                                                                                                              
            into   myTmp                                                                                                            
            from   DEX_LINES                                                                                                        
            where  ORDERNO = myOrder                                                                                                
            and    QTYORG  < (nvl(QTYSHP,0) + nvl(QTYSCH,0))                                                                        
            and    rownum  < 2;                                                                                                     
                                                                                                                                    
            myRetMesg := 'Quantity Over Shipped (E)';                                                                               
                                                                                                                                    
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myTmp := 'N';                                                                                                        
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      if myCCFlag = 'Y' or myProgCode = 'RC' then                                                                                   
         myEDI := 'Y';                                                                                                              
      end if;                                                                                                                       
                                                                                                                                    
      if nvl(myEDI,'N') = 'N' then                                                                                                  
         log;                                                                                                                       
         mySect := 'Ship - Out EDI';                                                                                                
                                                                                                                                    
         begin                                                                                                                      
            select 'Y'                                                                                                              
            into   myEDI                                                                                                            
            from   DEX_CUSTOMER_CONTROL                                                                                             
            where  CUSTOMER_ID      = myCustID                                                                                      
            and    ORG_ID           = myOrgID                                                                                       
            and    TYPE             = 'B2B'                                                                                         
            and   (nvl(DATA,'SHIP') = 'SHIP' or instr(SEGMENT1,                                                                     
'SHIP') > 0)                                                                                                                        
            and    rownum           < 2;                                                                                            
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myEDI := null;                                                                                                       
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Select Period';                                                                                             
                                                                                                                                    
      K_DEX_PERIOD.PERIOD ( myFYR,myFMO,myFWK,trunc(myDate) );                                                                      
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Select Ship No';                                                                                            
                                                                                                                                    
      select nvl(max(SHIPMENT),0) + 1                                                                                               
      into   myShip                                                                                                                 
      from   DEX_SHPHDRS                                                                                                            
      where  ORDERNO               = myOrder                                                                                        
      and    nvl(INVOICE_TYPE,'I') = 'I';                                                                                           
                                                                                                                                    
      dbms_output.put_line( 'Ship Type: ' || myShipType );                                                                          
                                                                                                                                    
      if myShipType not in ('E','A','R') and myHasSerl                                                                              
= 'Y' then                                                                                                                          
         log;                                                                                                                       
         mySect := 'Ship - Update DEX_SERIALS (Track)                                                                               
';                                                                                                                                  
                                                                                                                                    
         dbms_output.put_line(myTranID || '*' || myShip || '*' || myOrder)                                                          
;                                                                                                                                   
                                                                                                                                    
         update DEX_SERIALS set                                                                                                     
         TRACK = TRACK || '.'                                                                                                       
         where LOCATION = 'SHP'                                                                                                     
         and   ORDERNO  = myOrder                                                                                                   
         and   TRACK in                                                                                                             
              (select TRACK                                                                                                         
               from   DEX_SERIALS                                                                                                   
               where  TRAN_ID   = myTranID                                                                                          
               and    ORDERNO   = myOrder                                                                                           
               and    LOCATION != 'SHP');                                                                                           
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Update DEX_SERIALS (Locn)';                                                                              
                                                                                                                                    
         update DEX_SERIALS set                                                                                                     
         SHIPMENT = myShip                                                                                                          
        ,LOCATION = 'SHP'                                                                                                           
        ,DATELOC  = SYSDATE                                                                                                         
        ,STATUS   = null                                                                                                            
        ,DATESTS  = null                                                                                                            
         where TRAN_ID   = myTranID                                                                                                 
         and   ORDERNO   = myOrder                                                                                                  
         and   LOCATION != 'SHP';                                                                                                   
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'No Records Updated - Tran ID: ' || t                                                                      
o_char(myTranID);                                                                                                                   
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         dbms_output.put_line ( 'Serial Rows Updated: ' || SQL%                                                                     
rowcount );                                                                                                                         
                                                                                                                                    
      elsif myShipType = 'R' then                                                                                                   
         log;                                                                                                                       
         mySect := 'Ship - Update DEX_SERIALS (RTV)';                                                                               
                                                                                                                                    
         update DEX_SERIALS set                                                                                                     
         SHIPMENT = myShip                                                                                                          
        ,LOCATION = 'SHP'                                                                                                           
        ,DATELOC  = SYSDATE                                                                                                         
        ,STATUS   = null                                                                                                            
        ,DATESTS  = null                                                                                                            
        ,REASON   = 'RTV'                                                                                                           
        ,MANIFEST = 'R'                                                                                                             
         where ORDERNO  = myOrder                                                                                                   
         and   TRAN_ID  = myTranID                                                                                                  
         and   LOCATION = 'OTV';                                                                                                    
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'No Records Updated - Tran ID                                                                              
: ' || to_char(myTranID);                                                                                                           
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      if myShipType in ('X','S','H','E') then                -- Tra                                                                 
nsfer/Surplus/House Scrap/External                                                                                                  
         log;                                                                                                                       
         mySect := 'Ship - Insert DEX_SHPHDRS (Transfer                                                                             
)';                                                                                                                                 
                                                                                                                                    
         insert into DEX_SHPHDRS                                                                                                    
        (ORDERNO                                                                                                                    
        ,SHIPMENT                                                                                                                   
        ,CUST                                                                                                                       
        ,NAME                                                                                                                       
        ,CUSTPO                                                                                                                     
        ,RELEASE                                                                                                                    
        ,CUST_EXCHANGE                                                                                                              
        ,DROP_SHIP                                                                                                                  
        ,SHIPTO                                                                                                                     
        ,ORDTYPE                                                                                                                    
        ,TYPE                                                                                                                       
        ,PLANT                                                                                                                      
        ,AGENT                                                                                                                      
        ,TLM                                                                                                                        
        ,STATUS                                                                                                                     
        ,SHIP_YMD                                                                                                                   
        ,DATEPRO                                                                                                                    
        ,EDI                                                                                                                        
        ,PRINT_LABEL                                                                                                                
        ,SHIP_ID                                                                                                                    
        ,PICKLIST_ID                                                                                                                
        ,CREATED_BY                                                                                                                 
        ,CREATION_DATE                                                                                                              
        ,LAST_UPDATED_BY                                                                                                            
        ,LAST_UPDATE_DATE                                                                                                           
        ,SHIP_NAME                                                                                                                  
        ,SHIP_ATTN                                                                                                                  
        ,SHIP_ST1                                                                                                                   
        ,SHIP_ST2                                                                                                                   
        ,SHIP_CITY                                                                                                                  
        ,SHIP_STATE                                                                                                                 
        ,SHIP_ZIP                                                                                                                   
        ,SHIP_VIA                                                                                                                   
        ,WAYBILL                                                                                                                    
        ,FREIGHT                                                                                                                    
        ,WEIGHT                                                                                                                     
        ,DATESHP                                                                                                                    
        ,DRIVER                                                                                                                     
        ,EMPSHP                                                                                                                     
        ,COD                                                                                                                        
        ,COUNTRY                                                                                                                    
        ,CODE                                                                                                                       
        ,REASON                                                                                                                     
        ,PLANT_ID                                                                                                                   
        ,ORG_ID                                                                                                                     
        ,CUSTOMER_ID                                                                                                                
        ,BILL_SITE_USE_ID                                                                                                           
        ,SHIP_SITE_USE_ID)                                                                                                          
         select myOrder                                                                                                             
                         -- ORDERNO                                                                                                 
               ,myShip                                                                                                              
                    -- SHIPMENT                                                                                                     
               ,H.CUST                                                                                                              
                -- CUST                                                                                                             
               ,H.CUSTNAME                                                                                                          
                                  -- NAME                                                                                           
               ,H.CUSTPO                                                                                                            
                          -- CUSTPO                                                                                                 
               ,H.RELEASE                                                                                                           
                    -- RELEASE                                                                                                      
               ,H.CUST_EXCHANGE                                                                                                     
               -- CUST_EXCHANGE                                                                                                     
               ,H.DROP_SHIP                                                                                                         
                -- DROP_SHIP                                                                                                        
               ,H.SHIPTO                                                                                                            
             -- SHIPTO                                                                                                              
               ,H.ORDTYPE                                                                                                           
                                 -- ORDTYPE                                                                                         
               ,H.TYPE                                                                                                              
                            -- TYPE                                                                                                 
               ,H.PLANT                                                                                                             
                    -- PLANT                                                                                                        
               ,H.AGENT                                                                                                             
             -- AGENT                                                                                                               
               ,H.TLM                                                                                                               
                                -- TLM                                                                                              
               ,'S'                                                                                                                 
                       -- STATUS                                                                                                    
               ,to_char(myDate,'YYMMDD')                                                                                            
                 -- SHIP_YMD                                                                                                        
               ,trunc(myDate)                                                                                                       
             -- DATEPRO                                                                                                             
               ,decode(myEDI,'Y','E',null)                                                                                          
                                  -- EDI                                                                                            
               ,decode(TYPE,'T','T','P','Y',decode(myEDI,'Y','E                                                                     
',null))                 -- PRINT_LABEL                                                                                             
               ,myShipID                                                                                                            
                        -- SHIP_ID                                                                                                  
               ,0                                                                                                                   
                   -- PICKLIST_ID                                                                                                   
               ,myUserID                                                                                                            
                  -- CREATED_BY                                                                                                     
               ,SYSDATE                                                                                                             
                -- CREATION_DATE                                                                                                    
               ,myUserID                                                                                                            
                 -- LAST_UPDATED_BY                                                                                                 
               ,SYSDATE                                                                                                             
                    -- LAST_UPDATE_DATE                                                                                             
               ,H.SHIP_NAME                                                                                                         
                        -- SHIP_NAME                                                                                                
               ,H.SHIP_ATTN                                                                                                         
                     -- SHIP_ATTN                                                                                                   
               ,H.SHIP_ST1                                                                                                          
                  -- SHIP_ST1                                                                                                       
               ,H.SHIP_ST2                                                                                                          
              -- SHIP_ST2                                                                                                           
               ,H.SHIP_CITY                                                                                                         
                                    -- SHIP_CITY                                                                                    
               ,H.SHIP_STATE                                                                                                        
                                 -- SHIP_STATE                                                                                      
               ,H.SHIP_ZIP                                                                                                          
                               -- SHIP-ZIP                                                                                          
               ,decode(myShipVia,null,H.SHIP_VIA,myShipVia)                                                                         
                           -- SHIP_VIA                                                                                              
               ,nvl(myWaybill,'N/A')                                                                                                
                       -- WAYBILL                                                                                                   
               ,myFreight                                                                                                           
                  -- FREIGHT                                                                                                        
               ,myWeight                                                                                                            
             -- WEIGHT                                                                                                              
               ,myDate                                                                                                              
                                 -- DATESHP                                                                                         
               ,H.DRIVER                                                                                                            
                            -- DRIVER                                                                                               
               ,myEmp                                                                                                               
                      -- EMPSHP                                                                                                     
               ,H.COD                                                                                                               
                -- COD                                                                                                              
               ,H.COUNTRY                                                                                                           
                                 -- COUNTRY                                                                                         
               ,null                                                                                                                
                            -- CODE                                                                                                 
               ,null                                                                                                                
                    -- REASON                                                                                                       
               ,PLANT_ID                                                                                                            
               ,ORG_ID                                                                                                              
               ,CUSTOMER_ID                                                                                                         
               ,BILL_SITE_USE_ID                                                                                                    
               ,SHIP_SITE_USE_ID                                                                                                    
         from   DEX_ORDERS H                                                                                                        
         where  H.ORDERNO = myOrder;                                                                                                
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'No Records Inserted';                                                                                     
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
      elsif myShipType = 'R' then                -- RTV                                                                             
         log;                                                                                                                       
         mySect := 'Ship - Insert DEX_SHPHDRS (RTV)';                                                                               
                                                                                                                                    
         insert into DEX_SHPHDRS                                                                                                    
        (ORDERNO                                                                                                                    
        ,SHIPMENT                                                                                                                   
        ,CUST                                                                                                                       
        ,NAME                                                                                                                       
        ,CUSTPO                                                                                                                     
        ,RELEASE                                                                                                                    
        ,CUST_EXCHANGE                                                                                                              
        ,DROP_SHIP                                                                                                                  
        ,SHIPTO                                                                                                                     
        ,ORDTYPE                                                                                                                    
        ,TYPE                                                                                                                       
        ,PLANT                                                                                                                      
        ,AGENT                                                                                                                      
        ,TLM                                                                                                                        
        ,STATUS                                                                                                                     
        ,SHIP_YMD                                                                                                                   
        ,DATEPRO                                                                                                                    
        ,EDI                                                                                                                        
        ,PRINT_LABEL                                                                                                                
        ,SHIP_ID                                                                                                                    
        ,PICKLIST_ID                                                                                                                
        ,CREATED_BY                                                                                                                 
        ,CREATION_DATE                                                                                                              
        ,LAST_UPDATED_BY                                                                                                            
        ,LAST_UPDATE_DATE                                                                                                           
        ,SHIP_NAME                                                                                                                  
        ,SHIP_ATTN                                                                                                                  
        ,SHIP_ST1                                                                                                                   
        ,SHIP_ST2                                                                                                                   
        ,SHIP_CITY                                                                                                                  
        ,SHIP_STATE                                                                                                                 
        ,SHIP_ZIP                                                                                                                   
        ,SHIP_VIA                                                                                                                   
        ,WAYBILL                                                                                                                    
        ,FREIGHT                                                                                                                    
        ,WEIGHT                                                                                                                     
        ,DATESHP                                                                                                                    
        ,DRIVER                                                                                                                     
        ,EMPSHP                                                                                                                     
        ,COD                                                                                                                        
        ,COUNTRY                                                                                                                    
        ,CODE                                                                                                                       
        ,REASON                                                                                                                     
        ,PLANT_ID                                                                                                                   
        ,ORG_ID                                                                                                                     
        ,CUSTOMER_ID                                                                                                                
        ,BILL_SITE_USE_ID                                                                                                           
        ,SHIP_SITE_USE_ID)                                                                                                          
         select myOrder                                                                                                             
                     -- ORDERNO                                                                                                     
               ,myShip                                                                                                              
                -- SHIPMENT                                                                                                         
               ,H.CUST                                                                                                              
            -- CUST                                                                                                                 
               ,H.CUSTNAME                                                                                                          
                              -- NAME                                                                                               
               ,H.CUSTPO                                                                                                            
                      -- CUSTPO                                                                                                     
               ,H.RELEASE                                                                                                           
                -- RELEASE                                                                                                          
               ,H.CUST_EXCHANGE                                                                                                     
           -- CUST_EXCHANGE                                                                                                         
               ,H.DROP_SHIP                                                                                                         
            -- DROP_SHIP                                                                                                            
               ,H.SHIPTO                                                                                                            
                                   -- SHIPTO                                                                                        
               ,H.ORDTYPE                                                                                                           
                             -- ORDTYPE                                                                                             
               ,H.TYPE                                                                                                              
                        -- TYPE                                                                                                     
               ,H.PLANT                                                                                                             
                -- PLANT                                                                                                            
               ,H.AGENT                                                                                                             
                                   -- AGENT                                                                                         
               ,H.TLM                                                                                                               
                            -- TLM                                                                                                  
               ,'S'                                                                                                                 
                   -- STATUS                                                                                                        
               ,to_char(myDate,'YYMMDD')                                                                                            
             -- SHIP_YMD                                                                                                            
               ,trunc(myDate)                                                                                                       
                                   -- DATEPRO                                                                                       
               ,decode(myEDI,'Y','E',null)                                                                                          
                              -- EDI                                                                                                
               ,decode(TYPE,'T','T','P','Y',decode(myEDI,'Y','E',nu                                                                 
ll))                 -- PRINT_LABEL                                                                                                 
               ,myShipID                                                                                                            
                    -- SHIP_ID                                                                                                      
               ,0                                                                                                                   
               -- PICKLIST_ID                                                                                                       
               ,myUserID                                                                                                            
              -- CREATED_BY                                                                                                         
               ,SYSDATE                                                                                                             
            -- CREATION_DATE                                                                                                        
               ,myUserID                                                                                                            
             -- LAST_UPDATED_BY                                                                                                     
               ,SYSDATE                                                                                                             
                -- LAST_UPDATE_DATE                                                                                                 
               ,decode(myShipType,'R',D.SHIP_NAME,H.SHIP_NAME)                                                                      
                    -- SHIP_NAME                                                                                                    
               ,decode(myShipType,'R','Return RMA#:'||D.ATTRIBUTE1,H.SH                                                             
IP_ATTN)         -- SHIP_ATTN                                                                                                       
               ,decode(myShipType,'R',D.ADDRESS1,H.SHIP_ST1)                                                                        
              -- SHIP_ST1                                                                                                           
               ,decode(myShipType,'R',D.ADDRESS2,H.S                                                                                
HIP_ST2)                            -- SHIP_ST2                                                                                     
               ,decode(myShipType,'R',D.CITY,H.SHIP_CITY                                                                            
)                               -- SHIP_CITY                                                                                        
               ,decode(myShipType,'R',D.STATE,H.SHIP_STATE)                                                                         
                             -- SHIP_STATE                                                                                          
               ,decode(myShipType,'R',D.POSTAL_CODE,H.SHIP_ZI                                                                       
P)                         -- SHIP-ZIP                                                                                              
               ,decode(myShipVia,null,H.SHIP_VIA,myShipVia)                                                                         
                       -- SHIP_VIA                                                                                                  
               ,nvl(myWaybill,'N/A')                                                                                                
                   -- WAYBILL                                                                                                       
               ,myFreight                                                                                                           
              -- FREIGHT                                                                                                            
               ,myWeight                                                                                                            
                                   -- WEIGHT                                                                                        
               ,myDate                                                                                                              
                             -- DATESHP                                                                                             
               ,H.DRIVER                                                                                                            
                        -- DRIVER                                                                                                   
               ,myEmp                                                                                                               
                  -- EMPSHP                                                                                                         
               ,H.COD                                                                                                               
            -- COD                                                                                                                  
               ,H.COUNTRY                                                                                                           
                             -- COUNTRY                                                                                             
               ,decode(myShipType,'R','RTV',null)                                                                                   
                        -- CODE                                                                                                     
               ,decode(myShipType,'R','RTV',null)                                                                                   
                -- REASON                                                                                                           
               ,H.PLANT_ID                                                                                                          
               ,H.ORG_ID                                                                                                            
               ,H.CUSTOMER_ID                                                                                                       
               ,H.BILL_SITE_USE_ID                                                                                                  
               ,decode(myShipType,'R',nvl(D.SHIP_SITE_USE_ID,H.SH                                                                   
IP_SITE_USE_ID),H.SHIP_SITE_USE_ID)                                                                                                 
         from   DEX_SHIP_INTERFACE D                                                                                                
               ,DEX_ORDERS H                                                                                                        
         where  H.ORDERNO = myOrder                                                                                                 
         and    D.SHIP_ID = myShipID;                                                                                               
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'No Records Inserted';                                                                                     
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
      else                                           --                                                                             
Normal/Drop Ship                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Insert DEX_SHPHDRS (Normal)';                                                                            
                                                                                                                                    
         insert into DEX_SHPHDRS                                                                                                    
        (ORDERNO                                                                                                                    
        ,SHIPMENT                                                                                                                   
        ,CUST                                                                                                                       
        ,NAME                                                                                                                       
        ,CUSTPO                                                                                                                     
        ,RELEASE                                                                                                                    
        ,CUST_EXCHANGE                                                                                                              
        ,DROP_SHIP                                                                                                                  
        ,SHIPTO                                                                                                                     
        ,ORDTYPE                                                                                                                    
        ,TYPE                                                                                                                       
        ,PLANT                                                                                                                      
        ,AGENT                                                                                                                      
        ,TLM                                                                                                                        
        ,STATUS                                                                                                                     
        ,SHIP_YMD                                                                                                                   
        ,DATEPRO                                                                                                                    
        ,EDI                                                                                                                        
        ,PRINT_LABEL                                                                                                                
        ,SHIP_ID                                                                                                                    
        ,ASSURE_SHIP_ID                                                                                                             
        ,PICKLIST_ID                                                                                                                
        ,CREATED_BY                                                                                                                 
        ,CREATION_DATE                                                                                                              
        ,LAST_UPDATED_BY                                                                                                            
        ,LAST_UPDATE_DATE                                                                                                           
        ,SHIP_NAME                                                                                                                  
        ,SHIP_ATTN                                                                                                                  
        ,SHIP_ST1                                                                                                                   
        ,SHIP_ST2                                                                                                                   
        ,SHIP_CITY                                                                                                                  
        ,SHIP_STATE                                                                                                                 
        ,SHIP_ZIP                                                                                                                   
        ,SHIP_VIA                                                                                                                   
        ,WAYBILL                                                                                                                    
        ,FREIGHT                                                                                                                    
        ,WEIGHT                                                                                                                     
        ,DATESHP                                                                                                                    
        ,DRIVER                                                                                                                     
        ,EMPSHP                                                                                                                     
        ,COD                                                                                                                        
        ,COUNTRY                                                                                                                    
        ,PLANT_ID                                                                                                                   
        ,ORG_ID                                                                                                                     
        ,CUSTOMER_ID                                                                                                                
        ,BILL_SITE_USE_ID                                                                                                           
        ,SHIP_SITE_USE_ID)                                                                                                          
         select myOrder                                                                                                             
               ,myShip                                                                                                              
               ,H.CUST                                                                                                              
               ,H.CUSTNAME                                                                                                          
               ,H.CUSTPO                                                                                                            
               ,H.RELEASE                                                                                                           
               ,H.CUST_EXCHANGE                                                                                                     
               ,H.DROP_SHIP                                                                                                         
               ,H.SHIPTO                                                                                                            
               ,H.ORDTYPE                                                                                                           
               ,H.TYPE                                                                                                              
               ,H.PLANT                                                                                                             
               ,H.AGENT                                                                                                             
               ,H.TLM                                                                                                               
               ,'S'                                                                                                                 
               ,to_char(decode(myShipType,'A', D.DATE_S                                                                             
HIPPED, myDate),'YYMMDD')                       -- S                                                                                
HIP_YMD                                                                                                                             
               ,trunc(decode(myShipType,'A', D.DATE_SHIPPED, myDate))                                                               
                                 -- DATEPRO                                                                                         
               ,decode(myEDI,'Y','E',null)                                                                                          
               ,decode(TYPE,'T','T','P','Y',decode(myEDI,'Y','E',null                                                               
))                                                                                                                                  
               ,myShipID                                                                                                            
               ,myAShipID                                                                                                           
               ,myPickID                                                                                                            
               ,CREATED_BY                                                                                                          
               ,SYSDATE                                                                                                             
               ,CREATED_BY                                                                                                          
               ,SYSDATE                                                                                                             
               ,D.SHIP_NAME                                                                                                         
               ,D.ADDRESS4                                                                                                          
               ,D.ADDRESS1                                                                                                          
               ,D.ADDRESS2                                                                                                          
               ,D.CITY                                                                                                              
               ,D.STATE                                                                                                             
               ,D.POSTAL_CODE                                                                                                       
               ,D.SHIP_METHOD_CODE                                                                                                  
               ,D.WAYBILL_NUM                                                                                                       
               ,decode(D.BILLABLE,'Y',D.FREIGHT_AMOUNT,0)                                                                           
               ,D.WEIGHT                                                                                                            
               ,D.DATE_SHIPPED                                                                                                      
               ,H.DRIVER                                                                                                            
               ,D.SHIPPED_BY                                                                                                        
               ,D.COD                                                                                                               
               ,D.COUNTRY                                                                                                           
               ,H.PLANT_ID                                                                                                          
               ,H.ORG_ID                                                                                                            
               ,H.CUSTOMER_ID                                                                                                       
               ,H.BILL_SITE_USE_ID                                                                                                  
               ,nvl(D.SHIP_SITE_USE_ID,H.SHIP_SITE_USE_ID)                                                                          
         from   DEX_SHIP_INTERFACE D                                                                                                
               ,DEX_ORDERS H                                                                                                        
         where  H.ORDERNO = myOrder                                                                                                 
         and    D.SHIP_ID = myShipID;                                                                                               
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'Shphdrs Not Inserted';                                                                                    
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         dbms_output.put_line( mySect || ' ' || SQL%rowcount );                                                                     
      end if;                                                                                                                       
                                                                                                                                    
      if myShipType = 'A' then                                                                                                      
         log;                                                                                                                       
         mySect := 'Ship - Insert DEX_SHPDETS (Auto)'                                                                               
;                                                                                                                                   
                                                                                                                                    
         insert into DEX_SHPDETS                                                                                                    
        (ORDERNO,SHIPMENT,ITEM,CUSTITEM,PART,CUSTPART,DESCR,GRP,OEM,                                                                
BUYER                                                                                                                               
        ,STORE,DATESCH,STATCODE,INV_MGMT,PRICE,QTYORG,QTYSHP,QTYSCR,COST                                                            
                                                                                                                                    
        ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,CUSTOMER_ITEM_ID,SUBINVEN                                                       
TORY_CODE                                                                                                                           
        ,RECEIPT_CODE,QTYRCP,DATE_PROCESS,RETURN_RMA,FEE_TYPE)                                                                      
         select D.ORDERNO,myShip,D.ITEM,D.CUSTITEM,D.PART                                                                           
,D.CUSTPART,D.DESCRIPTION,D.GRP,D.MFG,D.BUYER                                                                                       
        ,D.STORE,D.DATESCH,D.STATCODE,D.INV_MGMT,decode(my                                                                          
OrdType,'S',D.PRICE,decode(myTranFee,'Y',0,D.PRICE))                                                                                
,D.QTYORG                                                                                                                           
        ,to_number(SEGMENT3),0,to_number(nvl(SEGMENT5,'0'))                                                                         
        ,D.INVENTORY_ITEM_ID,D.ORGANIZATION_ID,D.GROUP_ID,D.                                                                        
CUSTOMER_ITEM_ID,D.SUBINVENTORY_CODE                                                                                                
        ,myRcptCode,0,trunc(SYSDATE),myReturnRMA,D.FEE_TYPE                                                                         
         from   DEX_LINES D                                                                                                         
               ,DEX_SHIP_INTERFACE                                                                                                  
         where  D.ORDERNO = myOrder                                                                                                 
         and    D.ITEM    = to_number(SEGMENT4)                                                                                     
         and    SHIP_ID   = myShipID;                                                                                               
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'Ship Line Not Inserted';                                                                                  
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Update Qty (Auto)';                                                                                      
                                                                                                                                    
         update DEX_LINES D set                                                                                                     
         QTYSCH = decode(sign(nvl(QTYSCH,0) - myQty),-1,0,nvl                                                                       
(QTYSCH,0) - myQty)                                                                                                                 
        ,QTYSHP =                                                                                                                   
           (select sum(QTYSHP)                                                                                                      
            from   DEX_SHPDETS S                                                                                                    
            where  S.ORDERNO = D.ORDERNO                                                                                            
            and    S.ITEM    = D.ITEM)                                                                                              
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = myItem;                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - BV Data (Auto)';                                                                                         
                                                                                                                                    
         if mySerTranID is null then         -- if this                                                                             
is null than it is a standard drop ship                                                                                             
            update DEX_BV_DATA set                                                                                                  
            LAST_UPDATE_DATE = SYSDATE                                                                                              
           ,LAST_UPDATED_BY  = myUserID                                                                                             
           ,QUANTITY_SHIPPED = nvl(QUANTITY_SHIPPED,0)                                                                              
 + myQty                                                                                                                            
            where LINE_LOCATION_ID =                                                                                                
               (select PO_LINE_LOCATION_ID                                                                                          
                from   RCV_TRANSACTIONS                                                                                             
                where  TRANSACTION_ID = myRcvTranID);                                                                               
                                                                                                                                    
                                                                                                                                    
         else                                                                                                                       
            -- OSP Drop Ship                                                                                                        
            update DEX_BV_DATA set                                                                                                  
            LAST_UPDATE_DATE = SYSDATE                                                                                              
           ,LAST_UPDATED_BY  = myUserID                                                                                             
           ,QUANTITY_SHIPPED = nvl(QUANTITY_SHIPPED,0) + myQty                                                                      
            where LINE_LOCATION_ID in                                                                                               
               (select dbd.LINE_LOCATION_ID                                                                                         
                from   DEX_BV_DATA dbd                                                                                              
                      ,DEX_BV_DATA_ASSURE dba                                                                                       
                      ,DEX_SERIALS ser                                                                                              
                where  ser.TRAN_ID = mySerTranID                                                                                    
                and    ser.ORDERNO = dba.ASSURE_ORDER                                                                               
                and    ser.ITEM    = dba.ASSURE_ITEM                                                                                
                and    dba.DATA_ID = dbd.DATA_ID);                                                                                  
         end if;                                                                                                                    
                                                                                                                                    
      elsif myShipType = 'E' then                                                                                                   
         log;                                                                                                                       
         mySect := 'Ship - Insert DEX_SHPDETS (Extern                                                                               
al)';                                                                                                                               
                                                                                                                                    
         insert into DEX_SHPDETS                                                                                                    
        (ORDERNO,SHIPMENT,ITEM,CUSTITEM,PART,CUSTPART,DESCR,GRP,                                                                    
OEM,BUYER                                                                                                                           
        ,STORE,DATESCH,STATCODE,INV_MGMT,COST,PRICE,QTYORG,QTYSHP,QT                                                                
YSCR                                                                                                                                
        ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,CUSTOMER_ITEM_ID,SUBI                                                           
NVENTORY_CODE                                                                                                                       
        ,RECEIPT_CODE,QTYRCP,DATE_PROCESS,RETURN_RMA,FEE_TYPE)                                                                      
         select ORDERNO,myShip,ITEM,CUSTITEM,PART,CUS                                                                               
TPART,DESCRIPTION,GRP,MFG,BUYER                                                                                                     
               ,STORE,DATESCH,STATCODE,INV_MGMT,COST,decode(myOrdType,'S                                                            
',PRICE,decode(myTranFee,'Y',0,PRICE)),QTYORG,QTYSCH                                                                                
,0                                                                                                                                  
               ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,CUSTOMER_ITEM_ID                                                         
,SUBINVENTORY_CODE                                                                                                                  
               ,myRcptCode,0,trunc(SYSDATE),myReturnRMA,FEE                                                                         
_TYPE                                                                                                                               
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    nvl(QTYSCH,0) != 0;                                                                                                 
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'Nothing to Process';                                                                                      
                                                                                                                                    
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Update Qty (External)';                                                                                  
                                                                                                                                    
         update DEX_LINES lne set                                                                                                   
         QTYSCH = null                                                                                                              
        ,QTYSHP =                                                                                                                   
           (select sum(shd.QTYSHP)                                                                                                  
            from   DEX_SHPHDRS shh                                                                                                  
                  ,DEX_SHPDETS shd                                                                                                  
            where  shd.ORDERNO  = shh.ORDERNO                                                                                       
            and    shd.SHIPMENT = shh.SHIPMENT                                                                                      
            and    shd.ORDERNO  = lne.ORDERNO                                                                                       
            and    shd.ITEM     = lne.ITEM                                                                                          
            and    nvl(shh.INVOICE_TYPE,'I') = 'I')                                                                                 
        ,STATUS = decode(QTYORG,nvl(QTYSHP,0) + QTYSCH,'S','O')                                                                     
         where ORDERNO = myOrder;                                                                                                   
                                                                                                                                    
                                                                                                                                    
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'Ship - Insert DEX_SHPDETS (Normal)';                                                                            
                                                                                                                                    
         insert into DEX_SHPDETS                                                                                                    
        (ORDERNO,SHIPMENT,ITEM,CUSTITEM,PART,CUSTPART,DESCR                                                                         
,GRP,OEM,BUYER,STORE                                                                                                                
        ,DATESCH,PRICE,QTYORG,INV_MGMT,STATCODE,SCHD_YMD                                                                            
        ,QTYSHP,QTYSCR,QTYINV,COST                                                                                                  
        ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,CUSTOMER_ITEM_ID,                                                               
SUBINVENTORY_CODE                                                                                                                   
        ,RECEIPT_CODE,QTYRCP,DATE_PROCESS,UOM,RETURN_RMA,FEE                                                                        
_TYPE)                                                                                                                              
         select ORDERNO,myShip,ITEM,CUSTITEM,PART,CUSTPART,DESCRIPTION                                                              
               ,GRP,MFG,BUYER,nvl(STORE,'R'),DATESCH                                                                                
,decode(myOrdType,'S',PRICE,decode(myTranFee,'Y',0,P                                                                                
RICE)),QTYORG                                                                                                                       
               ,INV_MGMT,STATCODE,to_char(DATESCH,'YYMMDD')                                                                         
               ,decode(UOM,'LT',QTYORG,0),0,0,0                                                                                     
               ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,C                                                                        
USTOMER_ITEM_ID,SUBINVENTORY_CODE                                                                                                   
               ,myRcptCode,0,trunc(SYSDATE),UOM,myReturnRMA,FEE_TYPE                                                                
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    ITEM in                                                                                                             
               (select ITEM                                                                                                         
                from   DEX_SERIALS                                                                                                  
                where  ORDERNO  = myOrder                                                                                           
                and    TRAN_ID  = myTranID                                                                                          
                and    SHIPMENT = myShip                                                                                            
                and    LOCATION = 'SHP'                                                                                             
                union                                                                                                               
                select ITEM                                                                                                         
                from   DEX_SHIP_LINES_INTERFACE                                                                                     
      			 where  SHIP_ID     = myShipID                                                                                             
      			 and    ORDERNO     = myOrder                                                                                              
      			 );                                                                                                                        
                                                                                                                                    
         if SQL%rowcount = 0 then                                                                                                   
            myRetMesg := 'Shpdets Not Inserted (' || to_char(                                                                       
myTranID) || ')';                                                                                                                   
                                                                                                                                    
             raise ABORT_SHIP;                                                                                                      
         end if;                                                                                                                    
                                                                                                                                    
			if myHasSerl = 'Y' then                                                                                                          
     		   log;                                                                                                                      
     		   mySect := 'Ship - Update Qty (Std)';                                                                                      
                                                                                                                                    
     		   update DEX_SHPDETS D set                                                                                                  
     		   QTYSHP =                                                                                                                  
     		     (select count('*')                                                                                                      
     		      from   DEX_SERIALS S                                                                                                   
     		      where  S.ORDERNO  = D.ORDERNO                                                                                          
     		      and    S.ITEM     = D.ITEM                                                                                             
     		      and    S.TRAN_ID  = myTranID                                                                                           
     		      and    nvl(S.SCRAP,'N') != 'Y'                                                                                         
     		      )                                                                                                                      
     		  ,QTYSCR =                                                                                                                  
     		     (select count('*')                                                                                                      
     		      from   DEX_SERIALS S                                                                                                   
     		      where  S.ORDERNO  = D.ORDERNO                                                                                          
     		      and    S.ITEM     = D.ITEM                                                                                             
     		      and    S.TRAN_ID  = myTranID                                                                                           
     		      and    nvl(S.SCRAP,'N') = 'Y'                                                                                          
     		      and    nvl(S.DIAG_FLAG,'N') != 'Y'                                                                                     
     		      )                                                                                                                      
     		  ,QTYBAD =                                                                                                                  
     		     (select count('*')                                                                                                      
     		      from   DEX_SERIALS S                                                                                                   
     		      where  S.ORDERNO  = D.ORDERNO                                                                                          
     		      and    S.ITEM     = D.ITEM                                                                                             
     		      and    S.TRAN_ID  = myTranID                                                                                           
     		      and    nvl(S.SCRAP,'N') != 'Y'                                                                                         
     		      and    nvl(S.DIAG_FLAG,'N') = 'Y'                                                                                      
     		      )                                                                                                                      
     		   where ORDERNO        = myOrder                                                                                            
     		   and   SHIPMENT       = myShip                                                                                             
     		   and   nvl(UOM,'EA') != 'LT'                                                                                               
     		   and   ITEM in									-- Limit update to DEX_LINES tha                                                                    
t are tied to DEX_SERIALS                                                                                                           
     		   (select ITEM                                                                                                              
     		    from   DEX_SERIALS                                                                                                       
     		    where  TRAN_ID = myTranID                                                                                                
     		   );                                                                                                                        
                                                                                                                                    
        	end if;                                                                                                                    
                                                                                                                                    
        	if myHasNonSerl = 'Y' then                                                                                                 
        		log;                                                                                                                      
        		mySect := 'Ship - Update Qty (NonSerl)';                                                                                  
        		update DEX_SHPDETS D set                                                                                                  
     		   QTYSHP =                                                                                                                  
     		     (select sum(s.QTY)                                                                                                      
     		      from   DEX_SHIP_LINES_INTERFACE S                                                                                      
     		      where  S.SHIP_ID  = myShipID                                                                                           
     		      and    S.ORDERNO  = D.ORDERNO                                                                                          
     		      and    S.ITEM     = D.ITEM                                                                                             
     		      )                                                                                                                      
     		   where ORDERNO  = myOrder                                                                                                  
     		   and   SHIPMENT = myShip                                                                                                   
     		   and   ITEM in 										-- limit update to DEX_LI                                                                         
NES in interface                                                                                                                    
     		   (select ITEM                                                                                                              
     		    from   DEX_SHIP_LINES_INTERFACE                                                                                          
     		    where  SHIP_ID = myShipID                                                                                                
     		   );                                                                                                                        
                                                                                                                                    
	         update DEX_LINES lne set                                                                                                  
	         QTYSCH = null                                                                                                             
	        ,QTYSHP =                                                                                                                  
	           (select sum(shd.QTYSHP)                                                                                                 
	            from   DEX_SHPHDRS shh                                                                                                 
	                  ,DEX_SHPDETS shd                                                                                                 
	            where  shd.ORDERNO  = shh.ORDERNO                                                                                      
	            and    shd.SHIPMENT = shh.SHIPMENT                                                                                     
	            and    shd.ORDERNO  = lne.ORDERNO                                                                                      
	            and    shd.ITEM     = lne.ITEM                                                                                         
	            and    nvl(shh.INVOICE_TYPE,'I') = 'I')                                                                                
			  ,QTYINT = nvl(QTYINT,0) -                                                                                                      
		       (select sum(shd.QTYSHP)                                                                                                    
	            from   DEX_SHPHDRS shh                                                                                                 
	                  ,DEX_SHPDETS shd                                                                                                 
	            where  shd.ORDERNO  = shh.ORDERNO                                                                                      
	            and    shd.SHIPMENT = shh.SHIPMENT                                                                                     
	            and    shd.ORDERNO  = lne.ORDERNO                                                                                      
	            and    shd.ITEM     = lne.ITEM                                                                                         
	            and    nvl(shh.INVOICE_TYPE,'I') = 'I'                                                                                 
	            and    shh.SHIP_ID  = myShipID)                                                                                        
	         where lne.ORDERNO = myOrder                                                                                               
	         and   lne.SERIAL_FLAG = 'N';                                                                                              
                                                                                                                                    
	         log;                                                                                                                      
	         mySect := 'Ship - Update Qty (NonSerl)';                                                                                  
                                                                                                                                    
	         update DEX_LINES lne set                                                                                                  
	         STATUS = 'S'                                                                                                              
	         where ORDERNO = myOrder                                                                                                   
	         and   QTYORG  = nvl(QTYSHP,0)                                                                                             
	         and   STATUS != 'S';                                                                                                      
                                                                                                                                    
	         if myOrdType = 'S' and myShipType = 'E' then                                                                              
	            log;                                                                                                                   
	            mySect := 'Ship - Update Cost (NonSerl)';                                                                              
                                                                                                                                    
	            update DEX_SHPDETS set                                                                                                 
	            COST = F_DEX_ITEM_COST ( INVENTORY_ITEM_ID,                                                                            
ORGANIZATION_ID )                                                                                                                   
	            where ORDERNO  = myOrder                                                                                               
	            and   SHIPMENT = myShip                                                                                                
	            and   STORE    = 'P';                                                                                                  
                                                                                                                                    
	         elsif myOrdType = 'S' and myShipType not in                                                                               
 ('S','X','H') then                                                                                                                 
	            log;                                                                                                                   
	            mySect := 'Ship - Update Cost (NonSerl)';                                                                              
                                                                                                                                    
	            update DEX_SHPDETS set                                                                                                 
	            COST = F_DEX_ITEM_COST ( INVENTORY_ITEM                                                                                
_ID,ORGANIZATION_ID )                                                                                                               
	            where ORDERNO  = myOrder                                                                                               
	            and   SHIPMENT = myShip                                                                                                
	            and   nvl(SUBINVENTORY_CODE,'Main') != 'As Is'                                                                         
;                                                                                                                                   
	         end if;                                                                                                                   
			end if;                                                                                                                          
                                                                                                                                    
         if myCust != 'DEXB' then                                                                                                   
            begin                                                                                                                   
               select ITEM                                                                                                          
                     ,QTYSHP                                                                                                        
               into   myOrdItem                                                                                                     
                     ,myQtyShp                                                                                                      
               from   DEX_SHPDETS                                                                                                   
               where  ORDERNO = myOrder                                                                                             
               and    SHIPMENT = myShip;                                                                                            
                                                                                                                                    
               update DEX_BV_DATA set                                                                                               
               LAST_UPDATE_DATE = SYSDATE                                                                                           
              ,LAST_UPDATED_BY  = myUserID                                                                                          
              ,QUANTITY_SHIPPED = nvl(QUANTITY_SHIPP                                                                                
ED,0) + nvl(myQtyShp,0)                                                                                                             
               where ORDER_NUM  = myOrder                                                                                           
               and   ORDER_ITEM = myOrdItem;                                                                                        
                                                                                                                                    
            exception                                                                                                               
               when OTHERS then                                                                                                     
                  null;                                                                                                             
            end;                                                                                                                    
         end if;                                                                                                                    
                                                                                                                                    
         if myOrdType = 'R' then                                                                                                    
            log;                                                                                                                    
            mySect := 'Ship - Update Statcode';                                                                                     
                                                                                                                                    
            update DEX_SHPDETS set                                                                                                  
            STATCODE = 'S'                                                                                                          
            where  ORDERNO       = myOrder                                                                                          
            and    SHIPMENT      = myShip                                                                                           
            and    nvl(QTYSCR,0) > 0;                                                                                               
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Ship - Auto Cut';                                                                                            
                                                                                                                                    
            insert into DEX_SHPDETS                                                                                                 
           (ORDERNO,SHIPMENT,ITEM,CUSTITEM,PART,CUSTPART,DESCR,GRP,OEM                                                              
           ,DATESCH,STATCODE,PRICE,QTYORG,QTYSHP                                                                                    
           ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,                                                                             
CUSTOMER_ITEM_ID,SUBINVENTORY_CODE                                                                                                  
           ,DATE_PROCESS,RETURN_RMA)                                                                                                
            select ORDERNO,myShip,ITEM,CUSTITEM,PART,CUSTP                                                                          
ART,DESCRIPTION,GRP,MFG                                                                                                             
           ,DATESCH,STATCODE,decode(myOrdType,'S',PRIC                                                                              
E,decode(myTranFee,'Y',0,PRICE)),QTYORG,QTYORG - nvl                                                                                
(QTYSHP,0)                                                                                                                          
           ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,CUSTOMER_ITE                                                                 
M_ID,SUBINVENTORY_CODE                                                                                                              
           ,trunc(SYSDATE),myReturnRMA                                                                                              
            from  DEX_LINES                                                                                                         
            where ORDERNO = myOrder                                                                                                 
            and   QTYORG - nvl(QTYSCH,0) - nvl(QTYCUT,0)                                                                            
 - nvl(QTYSHP,0) > 0                                                                                                                
            and   CUSTITEM in                                                                                                       
                 (select ITEM                                                                                                       
                  from   DEX_SHPDETS                                                                                                
                  where  ORDERNO  = myOrder                                                                                         
                  and    SHIPMENT = myShip)                                                                                         
            and ((instr(PART,'FCX')     > 0 and instr(                                                                              
DESCRIPTION,'UPG') > 0)                                                                                                             
             or   instr(PART,'ADDED')   > 0                                                                                         
             or   instr(PART,'MISSING') > 0);                                                                                       
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Ship - Auto Cut Update';                                                                                     
                                                                                                                                    
            update DEX_LINES set                                                                                                    
            QTYSHP = QTYORG - nvl(QTYSHP,0)                                                                                         
           ,STATUS = 'S'                                                                                                            
            where  ORDERNO = myOrder                                                                                                
            and    ITEM  in                                                                                                         
                  (select ITEM                                                                                                      
                   from   DEX_SHPDETS                                                                                               
                   where  ORDERNO  = myOrder                                                                                        
                   and    SHIPMENT = myShip)                                                                                        
            and ((instr(PART,'FCX')     > 0 and instr(DESCRIPTION                                                                   
,'UPG') > 0)                                                                                                                        
             or   instr(PART,'ADDED')   > 0                                                                                         
             or   instr(PART,'MISSING') > 0);                                                                                       
                                                                                                                                    
         elsif myOrdType = 'S' and myShipType = 'E'                                                                                 
then                                                                                                                                
            log;                                                                                                                    
            mySect := 'Ship - Update Cost';                                                                                         
                                                                                                                                    
            update DEX_SHPDETS set                                                                                                  
            COST = F_DEX_ITEM_COST ( INVENTORY_ITEM_ID                                                                              
,ORGANIZATION_ID )                                                                                                                  
            where ORDERNO  = myOrder                                                                                                
            and   SHIPMENT = myShip                                                                                                 
            and   STORE    = 'P';                                                                                                   
                                                                                                                                    
         elsif myOrdType = 'S' and myShipType not in ('                                                                             
S','X','H') then                                                                                                                    
            log;                                                                                                                    
            mySect := 'Ship - Update Cost';                                                                                         
                                                                                                                                    
            update DEX_SHPDETS set                                                                                                  
            COST = F_DEX_ITEM_COST ( INVENTORY_ITEM_ID,ORGANIZATION_                                                                
ID )                                                                                                                                
            where ORDERNO  = myOrder                                                                                                
            and   SHIPMENT = myShip                                                                                                 
            and   nvl(SUBINVENTORY_CODE,'Main') != '                                                                                
As Is';                                                                                                                             
                                                                                                                                    
            update DEX_SHPDETS set                                                                                                  
            COST = (select round(avg(nvl(ser.COST,0)),2)                                                                            
                    from   DEX_SERIALS ser                                                                                          
                    where  ser.ORDERNO = myOrder                                                                                    
                    and    ser.SHIPMENT = myShip                                                                                    
                    and    ser.ITEM = DEX_SHPDETS.ITEM)                                                                             
            where ORDERNO  = myOrder                                                                                                
            and   SHIPMENT = myShip                                                                                                 
            and   nvl(SUBINVENTORY_CODE,'Main') = 'As Is';                                                                          
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Ship - Update Cost (Internal)';                                                                              
                                                                                                                                    
            for c1r in c1 loop                                                                                                      
               update DEX_SHPDETS set                                                                                               
               COST_INTERNAL = c1r.COST                                                                                             
               where ORDERNO  = myOrder                                                                                             
               and   SHIPMENT = myShip                                                                                              
               and   ITEM     = c1r.ITEM;                                                                                           
            end loop;                                                                                                               
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Auto Ship Sales Service Fees';                                                                              
                                                                                                                                    
      if myOrdType = 'S' and myShipType != 'E' then                                                                                 
         log;                                                                                                                       
         mySect := 'Ship - Auto Cut';                                                                                               
                                                                                                                                    
         insert into DEX_SHPDETS                                                                                                    
        (ORDERNO,SHIPMENT,ITEM,CUSTITEM,PART,CUSTPART,DESCR,GRP,OEM                                                                 
        ,DATESCH,STATCODE,PRICE,QTYORG,QTYSHP                                                                                       
        ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,CUSTOMER_IT                                                                     
EM_ID,SUBINVENTORY_CODE                                                                                                             
        ,DATE_PROCESS,RETURN_RMA,FEE_TYPE)                                                                                          
         select ORDERNO,myShip,ITEM,CUSTITEM,PART,CUSTPART,DESC                                                                     
RIPTION,GRP,MFG                                                                                                                     
        ,DATESCH,STATCODE,decode(myOrdType,'S',PRICE,decode(my                                                                      
TranFee,'Y',0,PRICE)),QTYORG,QTYORG - nvl(QTYSHP,0)                                                                                 
        ,INVENTORY_ITEM_ID,ORGANIZATION_ID,GROUP_ID,                                                                                
CUSTOMER_ITEM_ID,SUBINVENTORY_CODE                                                                                                  
        ,trunc(SYSDATE),myReturnRMA,FEE_TYPE                                                                                        
         from  DEX_LINES                                                                                                            
         where ORDERNO = myOrder                                                                                                    
         and   QTYORG - nvl(QTYSCH,0) - nvl(QTYCUT,0) - nvl(QTYSHP,0)                                                               
> 0                                                                                                                                 
--         and   FEE_TYPE = 'SVC'                                                                                                   
         and   PART in (myItemPayPal,myItemAmazon);                                                                                 
                                                                                                                                    
        log;                                                                                                                        
        mySect := 'Ship - Auto Cut Update';                                                                                         
                                                                                                                                    
        update DEX_LINES set                                                                                                        
        QTYSHP = QTYORG - nvl(QTYSHP,0)                                                                                             
       ,STATUS = 'S'                                                                                                                
         where  ORDERNO = myOrder                                                                                                   
         and    ITEM  in                                                                                                            
                  (select ITEM                                                                                                      
                   from   DEX_SHPDETS                                                                                               
                   where  ORDERNO  = myOrder                                                                                        
                   and    SHIPMENT = myShip)                                                                                        
         and    PART in (myItemPayPal,myItemAmazon);                                                                                
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - c2 loop';                                                                                                   
                                                                                                                                    
      for c2r in c2 loop                                                                                                            
         mySect := 'Ship - STS';                                                                                                    
                                                                                                                                    
         begin                                                                                                                      
            select ltrim(rtrim(replace(sll.STS_NUMBER,'ST                                                                           
S')))                                                                                                                               
            into   myStsNum                                                                                                         
            from   V_DEX_PRICE_LIST_LINES sll                                                                                       
                  ,V_DEX_PRICE_LISTS spl                                                                                            
            where  spl.PRICE_LIST_ID     = sll.PRICE_LIST_ID                                                                        
            and    sll.INVENTORY_ITEM_ID = to_char(c                                                                                
2r.INVENTORY_ITEM_ID)                                                                                                               
            and    spl.TYPE_CODE         = myPriceType                                                                              
            and    spl.CUSTOMER_ID       = myCustID                                                                                 
            and    sll.START_DATE_ACTIVE < trunc(SYSD                                                                               
ATE)                                                                                                                                
            and    sll.END_DATE_ACTIVE is null                                                                                      
            and    rownum                < 2;                                                                                       
                                                                                                                                    
         exception                                                                                                                  
            when NO_DATA_FOUND then                                                                                                 
               myStsNum := null;                                                                                                    
         end;                                                                                                                       
                                                                                                                                    
         if myStsNum is not null then                                                                                               
            mySect := 'Ship - STS Update';                                                                                          
                                                                                                                                    
            update DEX_SHPDETS set                                                                                                  
            STS_NUMBER = myStsNum                                                                                                   
            where ORDERNO  = myOrder                                                                                                
            and   SHIPMENT = myShip                                                                                                 
            and   ITEM     = c2r.ITEM;                                                                                              
         end if;                                                                                                                    
                                                                                                                                    
         if c2r.COMMENTS is not null then                                                                                           
            mySect := 'Ship - DEX_SHPDETS Comment';                                                                                 
                                                                                                                                    
            update DEX_SHPDETS set                                                                                                  
            COMMENTS = c2r.COMMENTS                                                                                                 
            where ORDERNO  = myOrder                                                                                                
            and   SHIPMENT = myShip                                                                                                 
            and   ITEM     = c2r.ITEM;                                                                                              
         end if;                                                                                                                    
                                                                                                                                    
         if c2r.CORE_FLAG in ('Y','A') then                                                                                         
            myCoreFlag := c2r.CORE_FLAG;                                                                                            
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Update Shipment';                                                                                           
                                                                                                                                    
      update DEX_ORDERS ord set                                                                                                     
      SHIPMENT =                                                                                                                    
        (select max(SHIPMENT)                                                                                                       
         from   DEX_SHPHDRS shh                                                                                                     
         where  ord.ORDERNO               = shh.ORDERNO                                                                             
                                                                                                                                    
         and    nvl(shh.INVOICE_TYPE,'I') = 'I')                                                                                    
      where ORDERNO = myOrder;                                                                                                      
                                                                                                                                    
     /*****************************************************                                                                         
      *************    Sales Service Fee    ***************                                                                         
      ****************************************************                                                                          
*/                                                                                                                                  
                                                                                                                                    
      if myOrdType = 'S' and nvl(myFeeCtlID,0) > 0 and myFeePct > 0 then                                                            
         log;                                                                                                                       
         mySect := 'Ship - Sys Fee';                                                                                                
                                                                                                                                    
         K_DEX_SERVICE_FEES.MATL (                                                                                                  
                                   myRetMesg  => myRetMesg                                                                          
                                  ,myRetCode  => myRetCode                                                                          
                                  ,myFeeCtlID => myFeeCt                                                                            
lID                                                                                                                                 
                                  ,myOrder    => myOrder                                                                            
                                  ,myShip     => myShip                                                                             
                                  ,myShipID   => myShipID                                                                           
                                  ,myOrgID    => myOrgID                                                                            
                                  ,myFeePct   => myFee                                                                              
Pct                                                                                                                                 
                                  ,myCalcCode => myCalcCode                                                                         
                                  ,myRef      => myOrder || '-' ||                                                                  
 to_char(myShipID)                                                                                                                  
                                 );                                                                                                 
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            raise ABORT_SHIP;                                                                                                       
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
     /*****************************************************                                                                         
                                                                                                                                    
      *******************    Job Cost   *******************                                                                         
      *****************************************************/                                                                        
      log;                                                                                                                          
      mySect := 'Ship - Job Cost (Ship)';                                                                                           
                                                                                                                                    
      K_DEX_JOB_COST.SHIP ( myRetMesg,myRetCode,myOrder,my                                                                          
Ship,myDate,'SHIP',myShip );                                                                                                        
                                                                                                                                    
      if myRetCode > 0 then                                                                                                         
         raise ABORT_SHIP;                                                                                                          
      end if;                                                                                                                       
                                                                                                                                    
     /**************************************************                                                                            
***                                                                                                                                 
      *******************    Counters   *******************                                                                         
      *****************************************************/                                                                        
                                                                                                                                    
      declare                                                                                                                       
         cursor c1 is                                                                                                               
            select GRP                                                                                                              
                  ,decode(D.STORE,'X','X','A') STORE                                                                                
                  ,sum(nvl(D.QTYSHP,0))                  QTY                                                                        
                  ,sum(nvl(D.QTYSHP,0) * nvl(D.PRICE,0)) AMT                                                                        
            from   DEX_SHPDETS D                                                                                                    
            where  D.ORDERNO = myOrder                                                                                              
            and    D.SHIPMENT = myShip                                                                                              
            group by D.GRP,decode(D.STORE,'X','X','A');                                                                             
                                                                                                                                    
         myCat   varchar2(3);                                                                                                       
         myTCat  varchar2(3);                                                                                                       
                                                                                                                                    
         myAmt   number;                                                                                                            
                                                                                                                                    
      begin                                                                                                                         
         log;                                                                                                                       
         mySect := 'Ship - Productivity Counters (CNT_HOUR)';                                                                       
                                                                                                                                    
                                                                                                                                    
         if myOrdType = 'R' then                                                                                                    
            myCat := 'SHR';                                                                                                         
         elsif myOrdType = 'H' then                                                                                                 
            myCat := 'SHH';                                                                                                         
         elsif myOrdType = 'S' and myInvMgmt = 'Y' then                                                                             
                                                                                                                                    
            myCat := 'SHW';                                                                                                         
         elsif myOrdType = 'S' and myExchange != 'N' then                                                                           
            myCat := 'SHE';                                                                                                         
         elsif myOrdType = 'S' then                                                                                                 
            myCat := 'SHS';                                                                                                         
         else                                                                                                                       
            myCat := 'SHZ';                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         for c1r in c1 loop                                                                                                         
            if c1r.STORE = 'X' then                                                                                                 
               myTCat := 'SHX';                                                                                                     
                                                                                                                                    
            elsif c1r.GRP = 'TRN' then                                                                                              
               myTCat := 'SHT';                                                                                                     
                                                                                                                                    
            elsif c1r.GRP = 'OSP' then                                                                                              
               myTCat := 'SHO';                                                                                                     
                                                                                                                                    
            else                                                                                                                    
               myTCat := myCat;                                                                                                     
            end if;                                                                                                                 
                                                                                                                                    
            P_DEX_CNT_HOUR ( myTCat,c1r.GRP,NULL,myPlant,c1r.QTY,c1r.AMT,N                                                          
ULL,myDate,NULL,'N',null);                                                                                                          
         end loop;                                                                                                                  
      end;                                                                                                                          
                                                                                                                                    
      if myOrdType = 'S' and myEmp is not null then                                                                                 
         log;                                                                                                                       
         mySect := 'Ship - Stock Counters (SHPDETS)';                                                                               
                                                                                                                                    
         select sum(nvl(QTYSHP,0)) QTY                                                                                              
               ,sum(nvl(QTYSHP,0) * nvl(PRICE,0)) AMT                                                                               
         into   myQty                                                                                                               
               ,myAmt                                                                                                               
         from   DEX_SHPDETS                                                                                                         
         where  ORDERNO = myOrder                                                                                                   
         and    SHIPMENT = myShip;                                                                                                  
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Stock Counters (CNT_HOUR)';                                                                              
                                                                                                                                    
         P_DEX_CNT_HOUR ( 'STK',myEmp,NULL,myPlant,myQty,myAmt                                                                      
,NULL,myDate,NULL,'N',null);                                                                                                        
      end if;                                                                                                                       
                                                                                                                                    
     /*****************************************************                                                                         
      *******************    Warranty   ************                                                                                
*******                                                                                                                             
      *****************************************************/                                                                        
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Warranty History';                                                                                          
                                                                                                                                    
      K_DEX_WARRANTY_AOL.SHIP ( myShipId, myOrder);                                                                                 
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Update Transfer Flag (ORDERS)';                                                                             
                                                                                                                                    
      update DEX_ORDERS H set                                                                                                       
      TRANSFER = 'S'                                                                                                                
     ,DATESHP  = SYSDATE                                                                                                            
      where ORDERNO = myOrder                                                                                                       
      and   not exists                                                                                                              
           (select '*'                                                                                                              
            from   DEX_LINES D                                                                                                      
            where  D.ORDERNO = H.ORDERNO                                                                                            
            and    STATUS in ('O','F'));                                                                                            
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Ship - Update EDI Flags (SHPHDRS)';                                                                                
                                                                                                                                    
      update DEX_SHPHDRS set                                                                                                        
      PRINT_LABEL = 'E'                                                                                                             
     ,EDI         = 'E'                                                                                                             
      where ORDERNO  = myOrder                                                                                                      
      and   SHIPMENT = myShip                                                                                                       
      and   SHIPTO in (96,97)                                                                                                       
      and   exists                                                                                                                  
           (select '*'                                                                                                              
            from   DEX_SHPDETS                                                                                                      
            where  DEX_SHPHDRS.ORDERNO  = DEX_SHPDETS.ORDERNO                                                                       
            and    DEX_SHPHDRS.SHIPMENT = DEX_SHPDETS.SH                                                                            
IPMENT                                                                                                                              
            and    STATCODE         = 'N');                                                                                         
                                                                                                                                    
     /**********************************************                                                                                
*******                                                                                                                             
      *******************  Sales Stock  *******************                                                                         
      *****************************************************/                                                                        
                                                                                                                                    
      if myOrdType = 'S' and myShipType = 'N' then                                                                                  
      	if myHasNonSerl = 'Y' then                                                                                                   
	         log;                                                                                                                      
	         mySect := 'Ship - Non Serl Issue';                                                                                        
                                                                                                                                    
	         declare                                                                                                                   
	            myLocID     number(15);                                                                                                
                                                                                                                                    
	            cursor c1 is                                                                                                           
	               select lne.ORGANIZATION_ID                                                                                          
	                     ,lne.SUBINVENTORY_CODE                                                                                        
	                     ,lne.INVENTORY_ITEM_ID                                                                                        
	                     ,sli.LOCATOR_ID                                                                                               
	                     ,sli.QTY                                                                                                      
	               from   DEX_LINES lne                                                                                                
	                     ,DEX_SHIP_LINES_INTERFACE sli                                                                                 
	               where  sli.ORDERNO = lne.ORDERNO                                                                                    
	               and    sli.ITEM    = lne.ITEM                                                                                       
	               and    sli.SHIP_ID = myShipID;                                                                                      
                                                                                                                                    
	         begin                                                                                                                     
	            log;                                                                                                                   
	            mySect := 'Ship - Issue Non Serl loop';                                                                                
                                                                                                                                    
	            for c1r in c1 loop                                                                                                     
	               if myHeadID = 0 then                                                                                                
	                  myHeadID := myShipID;                                                                                            
                                                                                                                                    
	                  log;                                                                                                             
	                  mySect := 'Ship - Issue Non Serl Submit (' || to_char(myHe                                                       
adID) || ')';                                                                                                                       
                                                                                                                                    
	                  K_DEX_STOCK.SET_MODE ( 2,myHeadID );                                                                             
                                                                                                                                    
                     myIdx := myIdx + 1;                                                                                            
                                                                                                                                    
                     myStckTbl ( myIdx ) := myHeadID;                                                                               
                     myIOrgTbl ( myIdx ) := c1r.ORGANIZATION_ID;                                                                    
	               end if;                                                                                                             
                                                                                                                                    
	               log;                                                                                                                
	               mySect := 'Ship - Issue Non Serl Issue';                                                                            
                                                                                                                                    
	               K_DEX_STOCK.ALIAS (                                                                                                 
	                                   myRetMesg => myRetMesg                                                                          
	                                  ,myRetCode => myRetCode                                                                          
	                                  ,myOrgID   => c1r.OR                                                                             
GANIZATION_ID                                                                                                                       
	                                  ,mySubInv  => c1r.SUBINVENTOR                                                                    
Y_CODE                                                                                                                              
	                                  ,myItemID  => c1r.INVENTORY_ITEM_ID                                                              
	                                  ,myLocID   => c1r                                                                                
.LOCATOR_ID                                                                                                                         
	                                  ,myQty     => c1r.QTY                                                                            
	                                  ,myRef     => 'Ship ID: '                                                                        
|| to_char(myShipID)                                                                                                                
	                                 );                                                                                                
                                                                                                                                    
	               if myRetCode > 0 then                                                                                               
	                  raise ABORT_SHIP;                                                                                                
	               end if;                                                                                                             
	            end loop;                                                                                                              
	         end;                                                                                                                      
                                                                                                                                    
    			log;                                                                                                                         
    			mySect := 'Ship - Purge Ship Line Inf';                                                                                      
                                                                                                                                    
    			delete DEX_SHIP_LINES_INTERFACE                                                                                              
    			where  SHIP_ID = myShipID;                                                                                                   
    		end if;                                                                                                                       
                                                                                                                                    
    		if myHasSerl = 'Y' then                                                                                                       
	         log;                                                                                                                      
   	      mySect := 'Ship - Serl Load Revision';                                                                                    
                                                                                                                                    
	         LOAD_SERIAL_STOCK ( myOrder,myTranID );                                                                                   
                                                                                                                                    
                                                                                                                                    
	         log;                                                                                                                      
	         mySect := 'Ship - Issue Stock';                                                                                           
                                                                                                                                    
	         declare                                                                                                                   
	            -- only issue out of stock if not As Is                                                                                
	            cursor c1 is                                                                                                           
	               select ser.TRACK                                                                                                    
	                     ,lne.ORGANIZATION_ID                                                                                          
	               from   DEX_SERIALS ser                                                                                              
	                     ,DEX_LINES lne                                                                                                
	               where  ser.ORDERNO = myOrder                                                                                        
	               and    ser.TRAN_ID = myTranID                                                                                       
	               and    ser.ORDERNO = lne.ORDERNO                                                                                    
	               and    ser.ITEM    = lne.ITEM                                                                                       
	               and    nvl(lne.SUBINVENTORY_CODE,'Main'                                                                             
) != 'As Is';                                                                                                                       
                                                                                                                                    
	         begin                                                                                                                     
	            log;                                                                                                                   
	            mySect := 'Ship - Issue Stock loop';                                                                                   
                                                                                                                                    
	            for c1r in c1 loop                                                                                                     
	               if nvl(myHeadID,0) = 0 then                                                                                         
	                  myHeadID := myRcvTranID;                                                                                         
                                                                                                                                    
	                  if nvl(myHeadID,0) = 0 then                                                                                      
	                     myHeadID := myShipID;                                                                                         
	                  end if;                                                                                                          
                                                                                                                                    
	                  log;                                                                                                             
	                  mySect := 'Ship - Issue Stock Sub                                                                                
mit (' || to_char(myHeadID) || ')';                                                                                                 
                                                                                                                                    
	                  K_DEX_STOCK.SET_MODE ( 2,myHeadID );                                                                             
                                                                                                                                    
                     myIdx := myIdx + 1;                                                                                            
                                                                                                                                    
                     myStckTbl ( myIdx ) := myHeadID;                                                                               
                     myIOrgTbl ( myIdx ) := c1r.ORGANIZATION_ID;                                                                    
	               end if;                                                                                                             
                                                                                                                                    
	               log;                                                                                                                
	               mySect := 'Ship - Issue Stock Issue';                                                                               
                                                                                                                                    
	               K_DEX_STOCK.ISSUE ( c1r.TRACK,'Ship ID: ' ||                                                                        
 to_char(myShipID),myOrder,'N' );                                                                                                   
	            end loop;                                                                                                              
	         end;                                                                                                                      
                                                                                                                                    
	         log;                                                                                                                      
	         mySect := 'Ship - As Is GL Entry';                                                                                        
                                                                                                                                    
	         select max(shd.ORGANIZATION_ID)                                                                                           
	               ,sum(nvl(ser.COST,0))                                                                                               
	         into   myIOrgID                                                                                                           
	               ,myCostAmt                                                                                                          
	         from   DEX_SERIALS ser                                                                                                    
	               ,DEX_SHPDETS shd                                                                                                    
	         where  shd.ORDERNO  = ser.ORDERNO                                                                                         
	         and    shd.ITEM     = ser.ITEM                                                                                            
	         and    shd.SHIPMENT = ser.SHIPMENT                                                                                        
	         and    shd.ORDERNO  = myOrder                                                                                             
	         and    shd.SHIPMENT = myShip                                                                                              
	         and    nvl(shd.SUBINVENTORY_CODE,'Main') = 'As                                                                            
 Is';                                                                                                                               
                                                                                                                                    
	         if myCostAmt > 0 then                                                                                                     
	            mySect := 'Ship - Code ID';                                                                                            
                                                                                                                                    
	            myDCodeID := DEX_ORGANIZATIONS_K.COST_SALES_CODE_ID ( myIOrgID                                                         
 );                                                                                                                                 
	            myCCodeID := DEX_ORGANIZATIONS_K.MATERIAL_CODE_ID ( myIOrgID                                                           
);                                                                                                                                  
                                                                                                                                    
	            if myDCodeID > 0 and myCCodeID > 0 and myCostAmt != 0 then                                                             
	               mySect := 'Ship - As Is Debit';                                                                                     
                                                                                                                                    
	               -- Special entry into GL to offset cost f                                                                           
or As Is shipments since no inventory transaction                                                                                   
	                 myRetMesg := F_DEX_GL_INTERFACE_ID (                                                                              
 myDCodeID,'D',myCostAmt,'I','As Is Fee',myOrder ||                                                                                 
to_char(myShip) );                                                                                                                  
                                                                                                                                    
	               if myRetMesg is not null then                                                                                       
	                  raise ABORT_SHIP;                                                                                                
	               end if;                                                                                                             
                                                                                                                                    
	               mySect := 'Ship - As Is Credit';                                                                                    
                                                                                                                                    
	               myRetMesg := F_DEX_GL_INTERFACE_ID ( myC                                                                            
CodeID,'C',myCostAmt,'I','As Is Fee',myOrder || to_c                                                                                
har(myShip) );                                                                                                                      
                                                                                                                                    
	               if myRetMesg is not null then                                                                                       
	                  raise ABORT_SHIP;                                                                                                
	               end if;                                                                                                             
	            end if;                                                                                                                
	         end if;                                                                                                                   
                                                                                                                                    
			end if;                                                                                                                          
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Purge Resv';                                                                                             
                                                                                                                                    
         delete RESERVATIONS                                                                                                        
         where  PICKLIST_ID in                                                                                                      
               (select PICKLIST_ID                                                                                                  
                from   DEX_SHIP_INTERFACE                                                                                           
                where  SHIP_ID = myShipID)                                                                                          
         and    STATUS = 'C';                                                                                                       
                                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Ship - Issue Elimination';                                                                                      
                                                                                                                                    
         K_DEX_ELIMINATION.ISSUE_OR ( myOrder,myShip );                                                                             
                                                                                                                                    
                                                                                                                                    
      elsif myOrdType = 'S' and myShipType in ('E','A')  then                                                                       
         log;                                                                                                                       
         mySect := 'Ship - Drop Ship/OSP Issue';                                                                                    
                                                                                                                                    
         declare                                                                                                                    
            cursor c1 is                                                                                                            
               select ORGANIZATION_ID                                                                                               
                     ,INVENTORY_ITEM_ID                                                                                             
                     ,SUBINVENTORY_CODE                                                                                             
                     ,sum(QTYSHP)         SHIP                                                                                      
               from   DEX_SHPDETS                                                                                                   
               where  ORDERNO           = myOrder                                                                                   
               and    SHIPMENT          = myShip                                                                                    
               and    SUBINVENTORY_CODE = 'Drop Ship'                                                                               
               and    nvl(myPODestType,'X') = 'INVENTORY'                                                                           
                      -- Only if Inventory Destinati                                                                                
on                                                                                                                                  
               group by ORGANIZATION_ID,INVENTORY_ITEM_ID,SUBINVENTORY_CODE                                                         
                                                                                                                                    
               union                                                                                                                
               --  OSP 3rd Party                                                                                                    
               select pll.SHIP_TO_ORGANIZATION_ID ORGANIZATION_ID                                                                   
                     ,pol.ITEM_ID  INVENTORY_ITEM_iD                                                                                
                     ,'OSP'  SUBINVENTORY_CODE                                                                                      
                     ,count(ser.SERIAL_ID) SHIP                                                                                     
               from   DEX_SERIALS ser                                                                                               
                     ,PO_LINES pol                                                                                                  
                     ,PO_LINE_LOCATIONS pll                                                                                         
               where  ser.TRAN_ID  = mySerTranId                                                                                    
               and    ser.LOCATION = 'SHP'                                                                                          
               and    ser.LINE_LOCATION_ID = pll.LINE_LOCATION_ID                                                                   
               and    pll.PO_LINE_ID = pol.PO_LINE_ID                                                                               
               group by pll.SHIP_TO_ORGANIZATION_ID                                                                                 
                       ,pol.ITEM_ID;                                                                                                
                                                                                                                                    
         begin                                                                                                                      
            log;                                                                                                                    
            mySect := 'Ship - Drop Ship Cursor';                                                                                    
                                                                                                                                    
            for c1r in c1 loop                                                                                                      
               if nvl(myHeadID,0) = 0 then                                                                                          
                  log;                                                                                                              
                  mySect := 'Ship - Drop Ship Submit';                                                                              
                                                                                                                                    
                  myHeadID := myRcvTranID;                                                                                          
                                                                                                                                    
                  if nvl(myHeadID,0) = 0 then                                                                                       
                     myHeadID := myShipID;                                                                                          
                  end if;                                                                                                           
                                                                                                                                    
                  K_DEX_STOCK.SET_MODE ( 2,myHeadID );      -                                                                       
- 2-Concurrent                                                                                                                      
                                                                                                                                    
                  myIdx := myIdx + 1;                                                                                               
                                                                                                                                    
                  myStckTbl ( myIdx ) := myHeadID;                                                                                  
                  myIOrgTbl ( myIdx ) := c1r.ORGANIZATION_ID;                                                                       
               end if;                                                                                                              
                                                                                                                                    
               log;                                                                                                                 
               mySect := 'Ship - Drop Ship Alias';                                                                                  
                                                                                                                                    
               dbms_output.put_line ( 'OrgID: ' || c1r.ORGANIZATION_ID ||                                                           
' ItemID: ' || c1r.INVENTORY_ITEM_ID || ' ShipQty: '                                                                                
 || c1r.SHIP);                                                                                                                      
                                                                                                                                    
               K_DEX_STOCK.ALIAS (                                                                                                  
                                   c1r.ORGANIZATION_I                                                                               
D                                                                                                                                   
                                  ,c1r.SUBINVENTORY_CODE                                                                            
                                  ,c1r.INVENTORY_ITEM_ID                                                                            
                                  ,c1r.SHIP                                                                                         
                                  ,myRcvTranID                                                                                      
                                  ,myOrder                                                                                          
                                  ,'Order: ' || myOrder || ' S                                                                      
hip: ' || to_char(myShip) || ' Ship ID: ' || to_char                                                                                
(myShipID)                                                                                                                          
                                  ,mySerTranID                  --                                                                  
tranid for OSP                                                                                                                      
                                 );                                                                                                 
            end loop;                                                                                                               
         end;                                                                                                                       
      end if;                                                                                                                       
                                                                                                                                    
     /************************************************                                                                              
*****                                                                                                                               
      *******************    WIP Job    *******************                                                                         
      *****************************************************/                                                                        
                                                                                                                                    
      if myOrdType in ('R','H') then                                                                                                
         log;                                                                                                                       
         mySect := 'Ship - Close Job';                                                                                              
                                                                                                                                    
         K_WIP_JOB.JOB_SHIP ( myOrder,myShip );                                                                                     
      end if;                                                                                                                       
                                                                                                                                    
     /**************************************************                                                                            
***                                                                                                                                 
      *******************  Call Center  *******************                                                                         
      *****************************************************/                                                                        
                                                                                                                                    
      if myCCFlag = 'Y' then                                                                                                        
         log;                                                                                                                       
         mySect := 'Ship - Call Center';                                                                                            
                                                                                                                                    
         update DEX_CC_HEADERS set                                                                                                  
         STATUS_CODE      = decode(BOX_KIT_FLAG,'Y',decode(myBoxKi                                                                  
t,'N','CL','RT'), decode(STATUS_CODE,'GN', STATUS_CO                                                                                
DE, 'RT'))                                                                                                                          
        ,CLOSE_DATE       = decode(BOX_KIT_FLAG,'Y',decode(myBoxKit                                                                 
,'N',trunc(SYSDATE),null),null)                                                                                                     
        ,LAST_UPDATE_DATE = SYSDATE                                                                                                 
        ,LAST_UPDATED_BY  = myUserID                                                                                                
         where HEADER_ID    = myCCHeadID                                                                                            
         and   STATUS_CODE != 'CL';                                                                                                 
      end if;                                                                                                                       
                                                                                                                                    
     /************************************************                                                                              
      *******************   DEXB   *******************                                                                              
      ************************************************/                                                                             
                                                                                                                                    
      if myCust = XXDEX_DEFAULTS_F ( 'INTERNAL_CUST_                                                                                
BUY' ) then                                                                                                                         
         log;                                                                                                                       
         mySect := 'Ship - BV Data (Assure)';                                                                                       
                                                                                                                                    
         declare                                                                                                                    
            cursor c1 is                                                                                                            
               select ITEM                                                                                                          
                     ,QTYSHP                                                                                                        
               from   DEX_SHPDETS                                                                                                   
               where  ORDERNO  = myOrder                                                                                            
               and    SHIPMENT = myShip;                                                                                            
                                                                                                                                    
          begin                                                                                                                     
            for c1r in c1 loop                                                                                                      
               if myShipType = 'R' then                                                                                             
                  update DEX_BV_DATA set                                                                                            
                  LAST_UPDATE_DATE  = SYSDATE                                                                                       
                 ,LAST_UPDATED_BY   = myUserID                                                                                      
                 ,QUANTITY_RTV      = QUANTITY_RTV - c1r.QTYSHP                                                                     
                                                                                                                                    
                 ,QUANTITY_RETURNED = nvl(QUANTITY_RETURNED,0) + c1r.QTYSHP                                                         
                  where DATA_ID in                                                                                                  
                       (select DATA_ID                                                                                              
                        from   DEX_BV_DATA_ASSURE                                                                                   
                        where  ASSURE_ORDER = myOrder                                                                               
                        and    ASSURE_ITEM  = c1r.ITEM);                                                                            
                                                                                                                                    
               else                                                                                                                 
                  update DEX_BV_DATA set                                                                                            
                  LAST_UPDATE_DATE = SYSDATE                                                                                        
                 ,LAST_UPDATED_BY  = myUserID                                                                                       
                 ,QUANTITY_TEST    = QUANTITY_TEST - c1                                                                             
r.QTYSHP                                                                                                                            
                 ,QUANTITY_ASSURED = nvl(QUANTITY_ASSURED,0) + c1r.QT                                                               
YSHP                                                                                                                                
                                                                                                                                    

