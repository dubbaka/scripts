                                                                                                                                    
  CREATE OR REPLACE PROCEDURE "APPS"."P_DEX_RELABEL"                                                                                
(                                                                                                                                   
 myRetMesg   out   varchar2                                                                                                         
,myRetCode   out   number                                                                                                           
,myOrder     in    varchar2                                                                                                         
,myTranID    in    number                                                                                                           
,myCust      in    varchar2                                                                                                         
,myTranFee   in    varchar2                                                                                                         
,myLocn      in    varchar2                                                                                                         
) is                                                                                                                                
/* $Header: P_DEX_RELABEL.sql 2.1.0.0 2010/04/25 12:00:00                                                                           
dexsys ship $ Copyright (c) 2008 DEX Systems, Inc. *                                                                                
/                                                                                                                                   
                                                                                                                                    
   mySect       varchar2(100);                                                                                                      
                                                                                                                                    
   ABORT_PROC   exception;                                                                                                          
                                                                                                                                    
   cursor c1 is                                                                                                                     
      select SERIAL_ID                                                                                                              
      from   SERIALS                                                                                                                
      where  ORDERNO  = myOrder                                                                                                     
      and    TRAN_ID  = myTranID                                                                                                    
      and    LOCATION = myLocn;                                                                                                     
                                                                                                                                    
   cursor c2 is                                                                                                                     
      select decode(F_DEX_ITEM_NON ( lne.PART ),'Y','NONREPAIR','STANDARD')                                                         
   DATA_TYPE                                                                                                                        
            ,ser.ORDERNO                                                                                                            
            ,count('*')                                                                                                             
      from   DEX_LINES lne                                                                                                          
            ,DEX_SERIALS ser                                                                                                        
      where  ser.ORDERNO  = lne.ORDERNO                                                                                             
      and    ser.ITEM     = lne.ITEM                                                                                                
      and    ser.ORDERNO  = myOrder                                                                                                 
      and    ser.TRAN_ID  = myTranID                                                                                                
      and    ser.LOCATION = 'FIN'                                                                                                   
      group by decode(F_DEX_ITEM_NON ( lne.PART ),'Y','NONREPA                                                                      
IR','STANDARD'),ser.ORDERNO;                                                                                                        
                                                                                                                                    
begin                                                                                                                               
   myRetCode := 0;                                                                                                                  
                                                                                                                                    
   if myCust != XXDEX_DEFAULTS_F ( 'INTERNAL_CUST_BUY' ) then                                                                       
      mySect := 'Update Serials';                                                                                                   
                                                                                                                                    
      update DEX_SERIALS set                                                                                                        
      LOCATION    = myLocn                                                                                                          
     ,DATELOC     = SYSDATE                                                                                                         
     ,SCRAP       = 'N'                                                                                                             
     ,PICKLIST_ID = 0                                                                                                               
     ,TYPE_CODE   = 'RL'                                                                                                            
      where ORDERNO   = myOrder                                                                                                     
      and   TRAN_ID   = myTranID                                                                                                    
      and   LOCATION != 'SHP';                                                                                                      
                                                                                                                                    
   else                                                                                                                             
      -- location really determine by PO Subinventory.                                                                              
 Drop Ship will go to FIN and ship out.  Others go t                                                                                
o PCK for Stock.                                                                                                                    
                                                                                                                                    
      mySect := 'Update DEXB Serials';                                                                                              
                                                                                                                                    
      update DEX_SERIALS set                                                                                                        
      LOCATION    = (select decode(max(pod.DESTINATION_SUBINVENTORY),                                                               
'Drop Ship','FIN','PCK')                                                                                                            
                     from   PO_DISTRIBUTIONS_ALL pod                                                                                
                     where  pod.LINE_LOCATION_ID = D                                                                                
EX_SERIALS.LINE_LOCATION_ID)                                                                                                        
     ,DATELOC     = SYSDATE                                                                                                         
     ,SCRAP       = 'N'                                                                                                             
     ,PICKLIST_ID = 0                                                                                                               
     ,TYPE_CODE   = 'RL'                                                                                                            
      where ORDERNO   = myOrder                                                                                                     
      and   TRAN_ID   = myTranID                                                                                                    
      and   LOCATION != 'SHP';                                                                                                      
   end if;                                                                                                                          
                                                                                                                                    
   if myTranFee = 'Y' then                                                                                                          
      mySect := 'c1 loop';                                                                                                          
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         mySect := 'Tran Fee';                                                                                                      
                                                                                                                                    
         K_DEX_TRANSACTION_FEES.CHARGE (                                                                                            
                                         myRetMesg  =                                                                               
> myRetMesg                                                                                                                         
                                        ,myRetCode  => myRetCode                                                                    
                                        ,mySerialID =                                                                               
> c1r.SERIAL_ID                                                                                                                     
                                        ,myLocn     => 'QCP'                                                                        
                                        ,myTypeCode =                                                                               
> 'RL'               -- Relabel                                                                                                     
                                        ,myCredit   => 'N'                                                                          
                                       );                                                                                           
                                                                                                                                    
         if myRetCode > 0 then                                                                                                      
            raise ABORT_PROC;                                                                                                       
         end if;                                                                                                                    
      end loop;                                                                                                                     
   end if;                                                                                                                          
                                                                                                                                    
   mySect := 'c2 loop';                                                                                                             
                                                                                                                                    
   for c2r in c2 loop                                                                                                               
      mySect := 'Stck Rels - Process';                                                                                              
                                                                                                                                    
      K_DEX_STOCK_RELEASE.PROCESS (                                                                                                 
                                    myRetMesg   => my                                                                               
RetMesg                                                                                                                             
                                   ,myRetCode   => myRetCode                                                                        
                                   ,myDataType  => c2r.DATA_T                                                                       
YPE                                                                                                                                 
                                   ,myTranID    => myTranID                                                                         
                                   ,myOrder     => c2r.ORDERNO                                                                      
                                   ,myStorage   => null                                                                             
                                                                                                                                    
                                   ,myItem      => 0                                                                                
                                   ,myROAR      => null                                                                             
                                   ,myPart      => null                                                                             
                                   ,myCPart     => null                                                                             
                                   ,myRelease   => 0                                                                                
                                  );                                                                                                
                                                                                                                                    
      if myRetCode > 0 then                                                                                                         
         raise ABORT_PROC;                                                                                                          
      end if;                                                                                                                       
   end loop;                                                                                                                        
                                                                                                                                    
exception                                                                                                                           
   when ABORT_PROC then                                                                                                             
      myRetCode := 1;                                                                                                               
                                                                                                                                    
      rollback;                                                                                                                     
                                                                                                                                    
   when OTHERS then                                                                                                                 
      myRetCode := 2;                                                                                                               
      myRetMesg := mySect || ' ' || SQLERRM;                                                                                        
                                                                                                                                    
      rollback;                                                                                                                     
end;                                                                                                                                
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

