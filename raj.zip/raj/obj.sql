set linesize 120
set pagesize 100
column owner format a10
column object_name format a20
column object_type format a10


select owner, 
       object_name,
       object_id,
       object_type,
       created,
       last_ddl_time,
       status,
       temporary,
       timestamp
from dba_objects
where object_name like upper('&object_name')
/
