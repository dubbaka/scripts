select a.sid,a.serial#,a.username,a.status,a.sql_hash_value,a.last_call_et/60,c.event,to_char(a.logon_time,'DD-MON-YYYY Hh24:MI:SS')
from v$session a,v$process b,v$session_wait c
where a.paddr=b.addr
and a.sid=c.sid
and c.event='latch: cache buffers chains'
order by 5;
