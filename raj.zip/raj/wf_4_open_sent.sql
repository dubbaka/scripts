SELECT notification_id,message_type, status, mail_status, to_char(begin_date,'DD-MON-YYYY HH24:MI') FROM applsys.wf_notifications
WHERE STATUS='OPEN'
AND mail_status = 'SENT'
ORDER BY begin_date DESC
