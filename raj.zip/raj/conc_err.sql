select distinct
request_id "Request Id",PROGRAM "Concurrent Program Name",APPLICATION_NAME "Application",requestor,decode(PHASE_CODE,'C','Completed','I','Inactive','P ','Pending','R','Running','NA') "Phase",decode(STATUS_CODE, 'A','Waiting', 'B','Resuming', 'C','Normal', 'D','Cancelled', 'E','Error', 'F','Scheduled', 'G','Warning', 'H','On Hold', 'I','Normal', 'M', 'No Manager', 'Q','Standby', 'R','Normal', 'S','Suspended', 'T','Terminating', 'U','Disabled', 'W','Paused', 'X','Terminated', 'Z','Waiting') "Status",to_char(ACTUAL_START_DATE,'DD-MON-YYYY HH24:MI') " Start Time",to_char(ACTUAL_COMPLETION_DATE,'DD-MON-YYYY HH24:MI') "Completion Time",round(((actual_completion_date-actual_start_date)*24*60*60/60),2) "Total_Time"
from apps.FND_CONC_REQUESTS_FORM_V
where status_code='E'
and ACTUAL_COMPLETION_DATE > sysdate-1/24;
