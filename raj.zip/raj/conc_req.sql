set lines 200
col Qname for a25
col submit_by for a19
col ConProgName for a55
SELECT  distinct req.request_id req_id,
        usr.user_name submit_by, que.concurrent_queue_name Qname,
        prog.user_concurrent_program_name ConProgName 
FROM    applsys.fnd_concurrent_requests req,
        applsys.fnd_concurrent_programs_tl prog,
        applsys.fnd_application         app,
        applsys.fnd_user                usr,
        applsys.fnd_concurrent_queues_tl   que,
        applsys.fnd_concurrent_processes proc 
WHERE   -- req.Phase_Code = 'R' AND
--    p.spid = req.oracle_process_id
--AND     s.paddr = p.addr
     req.request_id = NVL('&creq_id________________',req.request_id)
AND     UPPER(que.user_concurrent_queue_name) LIKE UPPER('&concurrent_queue_name__%')
AND     req.requested_by = usr.user_id
AND     req.concurrent_program_id = prog.concurrent_program_id
AND     req.program_application_id = app.application_id
AND     prog.application_id = app.application_id
AND     proc.concurrent_queue_id = que.concurrent_queue_id
AND     req.controlling_Manager = proc.concurrent_Process_id
AND 	que.concurrent_queue_name='XXSCM_MAKE_CRITICAL_MGR'
AND     req.ACTUAL_START_DATE > sysdate-1
AND 	que.language='US'
/

