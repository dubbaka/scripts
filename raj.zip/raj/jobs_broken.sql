col priv_user format a7
COL interval format a30

SELECT job, 
       priv_user, 
       last_date,
       last_sec,
       next_date, 
       next_sec, 
       interval,
       failures, 
       broken
FROM dba_jobs
WHERE 1=1 
and broken = 'Y'
and job like '%&job_number%'
/

