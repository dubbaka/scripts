set verify off
set feedback on
set lines 170
set pages 500
Accept table_name char prompt 'Enter Table name :'
Accept index_name char prompt 'Enter Index name :'
column index_owner format a12
column index_type format a10
column owner format a12
column table_name format a25
column index_name format a28
column column_name format a30
column degree format a7
column column_position heading column|position format 9999999
spool index_details
break on owner on table_name on index_name skip 1 on index_name
ttitle center 'Index details info' skip 1 center '******************************' skip 1

select owner, table_name, index_name , index_type, partitioned, logging, tablespace_name, uniqueness, ini_trans, status, degree
  from dba_indexes
 where table_name=decode('&&table_name',null, table_name, '&&table_name')
   and index_name = decode('&&index_name', null, index_name, '&&index_name')
 order by index_name
;
select owner, table_name, index_name, partitioning_type , subpartitioning_type, partition_count, locality
  from dba_part_indexes
 where table_name=decode('&&table_name',null, table_name, '&&table_name')
   and index_name = decode('&&index_name', null, index_name, '&&index_name');

ttitle center 'Index  Partition Info' skip 1 center '******************************' skip 1
set lines 140
col tablespace_name for a15
col subpartition_count heading subpart|count for 99999999
select distinct index_owner, index_name, composite, subpartition_count, tablespace_name, ini_trans, logging --,partition_name
--       , last_analyzed, num_rows, sample_size, round((sample_size/num_rows)*100,2) analye_percent
  from dba_ind_partitions
 where index_name in
(select index_name 
   from dba_indexes 
  Where table_name=decode('&&table_name',null, table_name, '&&table_name')
    and index_name = decode('&&index_name', null, index_name, '&&index_name')
)
;

ttitle center 'Index  Column Info' skip 1 center '******************************' skip 1
break on table_owner on table_name on index_owner on index_name skip 1 on table_owner
select a.table_owner, a.table_name , a.index_owner, a.index_name , a.column_name, a.column_position
  from dba_ind_columns a
 where a.table_name=decode('&&table_name',null, a.table_name, '&&table_name')
   and a.index_name = decode('&&index_name',null,a.index_name,'&&index_name')
 order by a.table_owner, a.table_name, a.index_name , a.column_position
;

spool off
