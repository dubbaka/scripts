set lines 240
 set pages 999 trims on echo off verify off pau off
    ttitle 'Current sessions in Oracle with program name'
    column pu format a10 heading 'O/S|Login|ID' justify left
    column su format a15 heading 'Oracle|User ID' justify left
    column stat format a8 heading 'Session|Status' justify left
    column ssid format 999999 heading 'Oracle|Session|ID' justify right
    column sser format 999999 heading 'Oracle|Serial|No' justify right
    column upid format a15 heading 'UNIX_Process_ID' justify right
    column txt format a52 heading 'Current Program' justify center word
    column logon_time format a20 heading 'Logon_Time' justify center word
    column terminal format a15 heading 'Terminal' justify center word
    column running format 999999.99 heading 'running in|minutes' justify right
    column machine format a33 
prompt
prompt
Prompt 'Here u can Enter OS User or Oracle User or Status based on your requirement ...........'
prompt
accept osuser char prompt 'Enter OS Username : '
accept username char prompt 'Enter Oracle Username : '
accept status char prompt 'Enter Status [ACTIVE/INACTIVE/...] : '
spool session_details
    select s.osuser,s.username su, s.status stat, s.sid ssid,
           s.serial# sser, s.terminal, lpad(p.spid,7) upid, s.program txt,
           to_char(logon_time,'MM/DD/YYYY HH24:MI:SS') logon_time, s.machine,
           round(last_call_et/60,2) running
      from v$process p, v$session s
     where p.addr=s.paddr
       and s.username is not null
       and upper(s.osuser) = decode(upper('&&osuser'),null,upper(s.osuser),upper('&&osuser'))
       and upper(s.username) = decode(upper('&&username'),null,upper(s.username),upper('&&username'))
       and upper(s.status) = decode(upper('&&status'),null,upper(s.status),upper('&&status'))
     order by 1,2,7 ;
spool off
