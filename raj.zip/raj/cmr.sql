set lines 132
set feedback off
set echo off
set verify off
set newpage 0

Column User		format A11
Column sid		format 99999
Column serial#		format 99999
Column Reqno		format 999999999999
column Date		format A16 justify c heading 'Start|Time'
column Program		format A13
column ConQ             format A10 justify c heading 'Queue|Name'
column el               format 99990.00 heading 'Elapsed'
column spid             format a8 heading 'Spid'

col OsId  format A7     justify c heading 'OS|ID'
col Prty  format 99     justify c heading 'pr|ty'

set termout off
break on today
column today noprint new_value _date
select to_char(sysdate, 'fmMonth DD, HH24:MI') today from dual;
column dtbase noprint new_value _instx
select  value   dtbase  from v$parameter where name = 'db_name';
clear breaks
set termout on

ttitle	left _date -
	center 'Jobs Currently running ' -
	right 'Page: ' format 999 sql.pno skip1 -
	center 'Concurrent Manager Report for database :('_instx')' skip2 
set feedback on

select  fu.user_name                         "User",
        fcr.request_id                       "Reqno",
        s.sid, 
        s.serial#, 
        to_char(fcr.actual_start_date,'mm/dd HH24:MI:SS')  "Date",
--      fcr.priority                         "Prty",
        fcp.concurrent_program_name          "Program",
		fcr.concurrent_program_id            "Program ID",
        fcr.oracle_process_id                "spid"      ,
	fq.Concurrent_queue_name             "ConQ",
        round((nvl(fcr.ACTUAL_COMPLETION_DATE,sysdate) - fcr.actual_start_date)
       * 1440,2) el, 
        fcr.parent_request_id,
        fcr.priority
  from	applsys.fnd_concurrent_requests	fcr,
	applsys.fnd_concurrent_programs	fcp,
	applsys.fnd_application		fa,
	applsys.fnd_user		fu,
        applsys.Fnd_Concurrent_Queues   fq,
        applsys.Fnd_Concurrent_Processes fp,
        v$session s,
        v$process p
  where	fcr.phase_code = 'R'
    and fcr.status_code = 'R'
    and	fcr.requested_by = fu.user_id
    and	fcr.concurrent_program_id = fcp.concurrent_program_id
    and	fcr.program_application_id = fa.application_id
    and	fcp.application_id = fa.application_id
    And fcr.Controlling_Manager = fp.Concurrent_Process_ID (+)
    and fp.Concurrent_Queue_ID = fq.Concurrent_Queue_ID(+)
    and fcr.oracle_process_id = p.spid(+)
    and s.paddr(+) = p.addr
 order by fcr.actual_start_date
/
ttitle off
REM fa.application_prefix		"Appl",
REM(sysdate - fcr.request_date) * 24		"Wait",
REM set pagesize 24
