SELECT COUNT(*), message_name FROM applsys.wf_notifications
WHERE STATUS='OPEN'
AND mail_status = 'MAIL'
GROUP BY message_name;
