SELECT fl.meaning,
         fcp.process_status_code,
         DECODE (fcq.concurrent_queue_name,
                 'WFMLRSVC', 'maile r container',
                 'WFALSNRSVC', 'listener container',
                 fcq.concurrent_queue_name),
         fcp.concurrent_process_id,
         os_process_id,
         fcp.logfile_name
    FROM apps.fnd_concurrent_queues fcq,
         apps.fnd_concurrent_processes fcp,
         apps.fnd_lookups fl
   WHERE     fcq.concurrent_queue_id = fcp.concurrent_queue_id --and fcp.process_status_code='A'
         AND fl.lookup_type = 'CP_PROCESS_STATUS_CODE'
         AND fl.lookup_code = fcp.process_status_code
         AND concurrent_queue_name IN ('WFMLRSVC', 'WFALSNRSVC')
ORDER BY fcp.logfile_name;
