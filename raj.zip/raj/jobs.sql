set lines 200
select /*+ RULE */ * from dba_jobs_running;
