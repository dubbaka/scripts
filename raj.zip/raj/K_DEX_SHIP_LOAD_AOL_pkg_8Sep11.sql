                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."K_DEX_SHIP_LOAD_AOL" AUTHID CURRENT_USER                                                        
as                                                                                                                                  
/* $Header: K_DEX_SHIP_LOAD_AOL.sql 2.1.4.0 2010/09/11 12:00:00 dexsys ship                                                         
 $ Copyright (c) 2010 DEX Systems, Inc. */                                                                                          
                                                                                                                                    
   procedure LOG_SET;                                                                                                               
   procedure LOG_UNSET;                                                                                                             
                                                                                                                                    
   procedure ADDRESS  (                                                                                                             
                        myShipID      number                                                                                        
                       ,myCust        varchar2                                                                                      
                       ,myType        varchar2                                                                                      
                       ,myROAR        varchar2                                                                                      
                       ,myOrgID       number                                                                                        
                      );                                                                                                            
                                                                                                                                    
   procedure EMAIL    (                                                                                                             
                        myCust    in  varchar2                                                                                      
                       ,myShipto  in  number                                                                                        
                       ,myOrgID   in  number                                                                                        
                      );                                                                                                            
                                                                                                                                    
   procedure TRACK    (                                                                                                             
                        myRetMesg  out  varchar2                                                                                    
                       ,myPickID        number                                                                                      
                       ,myEmp           varchar2                                                                                    
                       ,myOrder         varchar2                                                                                    
                       ,myTranID        number                                                                                      
                      );                                                                                                            
                                                                                                                                    
   procedure MULTIPACK (                                                                                                            
                        myRetMesg  out  varchar2                                                                                    
                       ,myPickID        number                                                                                      
                       ,myEmp           varchar2                                                                                    
                       ,myOrder         varchar2                                                                                    
                       ,myTranID        number                                                                                      
                      );                                                                                                            
                                                                                                                                    
   procedure MANIFEST (                                                                                                             
                        myRetMesg  out  varchar2                                                                                    
                       ,myPickID        number                                                                                      
                       ,myEmp           varchar2                                                                                    
                       ,myOrder         varchar2                                                                                    
                       ,myTranID        number                                                                                      
                       ,myShipID        number                                                                                      
                       ,myWeight        number                                                                                      
                      );                                                                                                            
                                                                                                                                    
   procedure NONSERL  (                                                                                                             
                        myRetMesg  out  varchar2                                                                                    
                       ,myPickID        number                                                                                      
                       ,myEmp           varchar2                                                                                    
                       ,myOrder         varchar2                                                                                    
                       ,myTranID        number                                                                                      
                       ,myShipID        number                                                                                      
                       ,myWeight        number                                                                                      
                      );                                                                                                            
                                                                                                                                    
   procedure UNPICK   (                                                                                                             
                        myRetMesg  out  varchar2                                                                                    
                       ,myShipID        number                                                                                      
                      );                                                                                                            
                                                                                                                                    
   procedure SCRAP    (                                                                                                             
                        myRetMesg  out  varchar2                                                                                    
                       ,myTranID        number                                                                                      
                       ,myEmpNo         varchar2                                                                                    
                       ,myShipVia       varchar2                                                                                    
                       ,myWaybill       varchar2                                                                                    
                      );                                                                                                            
                                                                                                                                    
end K_DEX_SHIP_LOAD_AOL;                                                                                                            
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."K_DEX_SHIP_LOAD_AOL" as                                                                      
/* $Header: K_DEX_SHIP_LOAD_AOL.sql 2.1.4.0 2010/09/11 1                                                                            
2:00:00 dexsys ship $ Copyright (c) 2010 DEX Systems                                                                                
, Inc. */                                                                                                                           
                                                                                                                                    
   CUSTOMER     XXDEX_CUSTOMERS_DEX_V.CUSTOMER_NUMBER%type := 'xxx'                                                                 
;                                                                                                                                   
   SHIP_TO      number := -9999;                                                                                                    
                                                                                                                                    
   EMAIL_FLAG   DEX_CUSTOMER_SHIP.EMAIL_SHIP_FLAG%type := 'N';                                                                      
   EMAIL_ADDR   DEX_CUSTOMER_SHIP.EMAIL%type;                                                                                       
                                                                                                                                    
   mySect       varchar2(100);                                                                                                      
                                                                                                                                    
   myLog        varchar2(1) := 'N';                                                                                                 
                                                                                                                                    
   /*******************************************************************                                                             
*******************************************/                                                                                        
                                                                                                                                    
   procedure LOG is                                                                                                                 
   begin                                                                                                                            
      if myLog = 'Y' then                                                                                                           
         K_DEX_LOG.LOG ( mySect,null,'K_DEX_SHIP_LOAD_A                                                                             
OL' );                                                                                                                              
      end if;                                                                                                                       
   end LOG;                                                                                                                         
                                                                                                                                    
   /******************************************************************                                                              
********************************************/                                                                                       
                                                                                                                                    
   procedure LOG_SET is                                                                                                             
   begin                                                                                                                            
      myLog := 'Y';                                                                                                                 
      K_DEX_LOG.LOG_SET;                                                                                                            
   end LOG_SET;                                                                                                                     
                                                                                                                                    
   procedure LOG_UNSET is                                                                                                           
   begin                                                                                                                            
      myLog := 'N';                                                                                                                 
      K_DEX_LOG.LOG_UNSET;                                                                                                          
   end LOG_UNSET;                                                                                                                   
                                                                                                                                    
   /*****************************************************************                                                               
*********************************************/                                                                                      
                                                                                                                                    
   function STATUS (                                                                                                                
                     myCustID   number                                                                                              
                    ,myItemID   number                                                                                              
                   ) return     varchar2 is                                                                                         
      myCnt     number(2);                                                                                                          
   begin                                                                                                                            
      select count('*')                                                                                                             
      into   myCnt                                                                                                                  
      from   DEX_LSM_CUSTOMER                                                                                                       
      where  CUSTOMER_ID = myCustID                                                                                                 
      and    LOCN        = 'SHC';                                                                                                   
                                                                                                                                    
      if myCnt > 0 then                                                                                                             
         return ( 'S' );                                                                                                            
      end if;                                                                                                                       
                                                                                                                                    
      select count('*')                                                                                                             
      into   myCnt                                                                                                                  
      from   DEX_LSM_ITEM                                                                                                           
      where  CUSTOMER_ID       = myCustID                                                                                           
      and    INVENTORY_ITEM_ID = myItemID                                                                                           
      and    LOCN              = 'SHC';                                                                                             
                                                                                                                                    
      if myCnt > 0 then                                                                                                             
         return ( 'S' );                                                                                                            
      end if;                                                                                                                       
                                                                                                                                    
      return ( 'O' );                                                                                                               
   end STATUS;                                                                                                                      
                                                                                                                                    
   /***********************************************************************                                                         
***************************************/                                                                                            
                                                                                                                                    
   procedure ADDRESS (                                                                                                              
                       myShipID      number                                                                                         
                      ,myCust        varchar2                                                                                       
                      ,myType        varchar2                                                                                       
                      ,myROAR        varchar2                                                                                       
                      ,myOrgID       number                                                                                         
                     ) is                                                                                                           
   begin                                                                                                                            
      if myType = 'Y' then                                                                                                          
         update DEX_SHIP_INTERFACE D set                                                                                            
        (SHIP_NAME,ADDRESS1,ADDRESS2,ADDRESS4,CITY,STATE,POSTAL_CODE,SHIP_                                                          
METHOD_CODE,COUNTRY) =                                                                                                              
            (select S.NAME,S.STREET1,S.STREET2,S.ATTN,S                                                                             
.CITY,S.STATE,S.ZIP,S.CARRIER,S.COUNTRY                                                                                             
             from   V_DEX_CUST_SHIP S                                                                                               
             where  CUST   = myCust                                                                                                 
             and    SHIPTO = 97                                                                                                     
             and    ORG_ID = myOrgID)                                                                                               
         where SHIP_ID = myShipID                                                                                                   
         and exists                                                                                                                 
            (select '*' from V_DEX_CUST_SHIP S                                                                                      
             where  CUST   = myCust                                                                                                 
             and    SHIPTO = 97                                                                                                     
             and    ORG_ID = myOrgID);                                                                                              
                                                                                                                                    
      elsif myType = 'W' then                                                                                                       
         update DEX_SHIP_INTERFACE D set                                                                                            
        (SHIP_NAME,ADDRESS1,ADDRESS2,ADDRESS4,CITY,STATE                                                                            
,POSTAL_CODE,SHIP_METHOD_CODE,COUNTRY) =                                                                                            
            (select S.NAME,S.STREET1,S.STREET2,S.ATTN,S.CITY,S.                                                                     
STATE,S.ZIP,S.CARRIER,S.COUNTRY                                                                                                     
             from   V_DEX_CUST_SHIP S                                                                                               
             where  CUST   = myCust                                                                                                 
             and    SHIPTO = 98                                                                                                     
             and    ORG_ID = myOrgID)                                                                                               
         where SHIP_ID = myShipID                                                                                                   
         and exists                                                                                                                 
            (select '*' from V_DEX_CUST_SHIP S                                                                                      
             where  CUST = myCust                                                                                                   
             and    SHIPTO = 98                                                                                                     
             and    ORG_ID = myOrgID);                                                                                              
                                                                                                                                    
       elsif myType = 'B' then                                                                                                      
         update DEX_SHIP_INTERFACE D set                                                                                            
        (SHIP_NAME,ADDRESS1,ADDRESS2,ADDRESS4,CITY,STATE,POSTAL_C                                                                   
ODE,SHIP_METHOD_CODE,COUNTRY) =                                                                                                     
            (select S.NAME,S.STREET1,S.STREET2,S.ATTN,S.CITY,S.STATE,S.Z                                                            
IP,S.CARRIER,S.COUNTRY                                                                                                              
             from   V_DEX_CUST_SHIP S                                                                                               
             where  CUST   = myCust                                                                                                 
             and    SHIPTO = 96                                                                                                     
             and    ORG_ID = myOrgID)                                                                                               
         where SHIP_ID = myShipID                                                                                                   
         and exists                                                                                                                 
            (select '*' from V_DEX_CUST_SHIP S                                                                                      
             where  CUST = myCust                                                                                                   
             and    SHIPTO = 96                                                                                                     
             and    ORG_ID = myOrgID);                                                                                              
      end if;                                                                                                                       
   end ADDRESS;                                                                                                                     
                                                                                                                                    
   /************************************************************                                                                    
**************************************************/                                                                                 
                                                                                                                                    
   procedure EMAIL (                                                                                                                
                     myCust    in   varchar2                                                                                        
                    ,myShipto  in   number                                                                                          
                    ,myOrgID   in   number                                                                                          
                   ) is                                                                                                             
                                                                                                                                    
		myIntCust  DEX_ORDERS.CUST%type := nvl(XXDEX_DEFAULTS_                                                                            
F ('INTERNAL_CUST_HOUSE'),'x');                                                                                                     
   begin                                                                                                                            
      if (CUSTOMER != myCust or SHIP_TO != myShipto) and myCust                                                                     
!= myIntCust then                                                                                                                   
                                                                                                                                    
         select EMAIL_SHIP_FLAG                                                                                                     
               ,EMAIL                                                                                                               
         into   EMAIL_FLAG                                                                                                          
               ,EMAIL_ADDR                                                                                                          
         from   XXDEX_PARTIES_V       rac                                                                                           
               ,RA_ADDRESSES_ALL      raa                                                                                           
               ,RA_SITE_USES_ALL      rsu                                                                                           
               ,DEX_CUSTOMER_SHIP dcs                                                                                               
         where  rac.CUSTOMER_ID            = raa.CUSTOMER_ID                                                                        
         and    raa.STATUS                 = 'A'                                                                                    
         and    raa.ADDRESS_ID             = rsu.ADDRESS_ID                                                                         
         and    raa.ORG_ID                 = rsu.ORG_ID                                                                             
         and    rsu.SITE_USE_CODE          = 'SHIP_TO'                                                                              
         and    rsu.STATUS                 = 'A'                                                                                    
         and    rsu.SITE_USE_ID            = dcs.SITE_U                                                                             
SE_ID                                                                                                                               
         and    rac.CUSTOMER_PROSPECT_CODE = 'CUSTOMER'                                                                             
         and    rac.STATUS                 = 'A'                                                                                    
         and    rac.CUSTOMER_NUMBER        = myCust                                                                                 
         and    dcs.SHIPTO                 = myShipto                                                                               
         and    raa.ORG_ID                 = myOrgID;                                                                               
                                                                                                                                    
         CUSTOMER   := myCust;                                                                                                      
         SHIP_TO    := myShipto;                                                                                                    
                                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
   exception                                                                                                                        
      when NO_DATA_FOUND then                                                                                                       
         EMAIL_FLAG := 'N';                                                                                                         
         EMAIL_ADDR := null;                                                                                                        
   end EMAIL;                                                                                                                       
                                                                                                                                    
   /*************************************************                                                                               
****************************************************                                                                                
*********/                                                                                                                          
                                                                                                                                    
   procedure RETURN_SERVICE (                                                                                                       
                              myRShipID   in out  number                                                                            
                             ,myShipID    in      number                                                                            
                             ,myUserID    in      nu                                                                                
mber                                                                                                                                
                             ,myServCode  in      varchar2                                                                          
                             ,myMethType  in      number                                                                            
                             ,myLocnID    in      number                                                                            
                            ) is                                                                                                    
   begin                                                                                                                            
      log;                                                                                                                          
      mySect := 'RtrnServ - Init';                                                                                                  
                                                                                                                                    
      if myLocnID is null then                                                                                                      
         RAISE_APPLICATION_ERROR ( -20001,'Plant Return Location N                                                                  
ot Selected' );                                                                                                                     
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'RtnServ - Insert Interface';                                                                                       
                                                                                                                                    
      insert into DEX_SHIP_INTERFACE                                                                                                
     (SHIP_ID,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_                                                                            
DATE,CREATED_BY                                                                                                                     
     ,STATUS,SHIP_TYPE,PLANT,SEGMENT1,SEGMENT2,SEGMENT3,SEGMEN                                                                      
T4,SHIP_NAME,COUNTRY                                                                                                                
     ,ADDRESS1,ADDRESS2,ADDRESS3,ADDRESS4,CITY,STATE,POST                                                                           
AL_CODE,PROVINCE,COUNTY                                                                                                             
     ,SHIP_METHOD_CODE,COD,COD_AMOUNT,COD_PAYMENT_TYPE                                                                              
,COD_COMMENT                                                                                                                        
     ,PICKLIST_ID,TRAN_ID,PACKAGE_TYPE,ATTRIBUTE1,FREIGHT_QUOTE                                                                     
     ,EMAIL_NOTIFY_FLAG,EMAIL_ADDRESS                                                                                               
     ,RESIDENTIAL,SATURDAY_DELIVERY,SATURDAY                                                                                        
     ,DELIVERY_CONF,SIGNATURE_REQUIRED,OVERSIZE,ADDTIONAL_HANDLING                                                                  
     ,DIMENSION,NEW_FLAG,INT_SHIP_FLAG,LICENSE_PLATE                                                                                
     ,RETURN_DELIVERY,RETURN_DELIVERY_METHOD,RETURN_DELIVE                                                                          
RY_ADD_EMAIL,RETURN_DELIVERY_DESCRIPTION                                                                                            
     ,RETURN_COMPANY,RETURN_CONTACT,RETURN_ADDRESS1,RETURN_ADDR                                                                     
ESS2,RETURN_CITY,RETURN_ADDRESS_CODE                                                                                                
     ,RETURN_STATE_PROVINCE,RETURN_POSTAL_CODE,RETURN_COUNTRY_SYMBO                                                                 
L,RETURN_PHONE,RETURN_FAX,RETURN_RESIDENTIAL)                                                                                       
      select myRShipID,SYSDATE,myUserID,SYSDATE,myUserID                                                                            
            ,'O','S',dsi.PLANT,dsi.SEGMENT1,dsi.SEGME                                                                               
NT2,dsi.SEGMENT3,dsi.SEGMENT4,dsi.SHIP_NAME,dsi.COUN                                                                                
TRY                                                                                                                                 
            ,dsi.ADDRESS1,dsi.ADDRESS2,dsi.ADDRESS3,dsi.ADDRESS4,dsi.CITY,                                                          
dsi.STATE,dsi.POSTAL_CODE,dsi.PROVINCE,dsi.COUNTY                                                                                   
            ,myServCode,dsi.COD,dsi.COD_AMOUNT,dsi.COD                                                                              
_PAYMENT_TYPE,dsi.COD_COMMENT                                                                                                       
            ,dsi.PICKLIST_ID,dsi.TRAN_ID,dsi.PACKAGE_TYPE,dsi.ATTRIBUTE1,d                                                          
si.FREIGHT_QUOTE                                                                                                                    
            ,EMAIL_FLAG,EMAIL_ADDR                                                                                                  
            ,dsi.RESIDENTIAL, 'N', 0                                                                                                
            ,dsi.DELIVERY_CONF,0,dsi.OVERSIZE,dsi.ADDTIONAL_HANDLIN                                                                 
G                                                                                                                                   
            ,dsi.DIMENSION,dsi.NEW_FLAG,dsi.INT_SHIP_FLAG,dsi.LICENSE_PLATE                                                         
            ,1,myMethType,dsi.RETURN_DELIVERY_ADD_EM                                                                                
AIL,dsi.DESCRIPTION                                                                                                                 
            ,hrl.ADDRESS_LINE_1,hrl.ADDRESS_LINE_3,hrl.ADD                                                                          
RESS_LINE_2,null,hrl.TOWN_OR_CITY,null                                                                                              
            ,hrl.REGION_2,hrl.POSTAL_CODE,F_DEX_COUNTRY_CONNECTSH                                                                   
IP ( dcy.DESCRIPTION ),hrl.TELEPHONE_NUMBER_1,hrl.TE                                                                                
LEPHONE_NUMBER_2,0                                                                                                                  
      from   V_DEX_COUNTRY dcy                                                                                                      
            ,HR_LOCATIONS hrl                                                                                                       
            ,DEX_SHIP_INTERFACE dsi                                                                                                 
      where  hrl.COUNTRY     = dcy.COUNTRY_CODE                                                                                     
      and    dsi.SHIP_ID     = myShipID                                                                                             
      and    hrl.LOCATION_ID = myLocnID;                                                                                            
   end RETURN_SERVICE;                                                                                                              
                                                                                                                                    
   /*****************************************************************                                                               
*********************************************/                                                                                      
                                                                                                                                    
   procedure BULK_RETURN_SERVICE (                                                                                                  
                                   myShipID  number                                                                                 
                                  ,myOrder   varchar2                                                                               
                                  ,myTranID  number                                                                                 
                                  ,myUserID  number                                                                                 
                                 ) is                                                                                               
      myRShipID   pls_integer;                                                                                                      
      myBuyCust	DEX_ORDERS.CUST%type := nvl(XXDEX_DEFA                                                                              
ULTS_F ('INTERNAL_CUST_BUY'),'x');                                                                                                  
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select S.SHIP_ID                                                                                                           
               ,nvl(S.RETURN_SHIP_ID,0)      RETURN_SHIP_ID                                                                         
               ,C.RETURN_METHOD_TYPE                                                                                                
               ,dcs.SERVICE_CODE             RETURN_SERV                                                                            
ICE_CODE                                                                                                                            
               ,dxp.RETURN_LOCATION_ID                                                                                              
         from   DEX_CARRIER_SERVICES dcs                                                                                            
               ,DEX_CUSTOMER_DATA C                                                                                                 
               ,XXDEX_CUSTOMERS_DEX_V R                                                                                             
               ,DEX_PLANTS dxp                                                                                                      
               ,DEX_ORDERS H                                                                                                        
               ,DEX_SERIALS S                                                                                                       
         where  S.ORDERNO           = H.ORDERNO                                                                                     
         and    R.CUSTOMER_NUMBER   = decode(H.CUST,myBuyCust                                                                       
,H.CUST_EXCHANGE,H.CUST)                                                                                                            
         and    R.CUSTOMER_ID       = C.CUSTOMER_ID                                                                                 
         and    C.ORG_ID            = decode(H.CUST,m                                                                               
yBuyCust,F_DEXB_ORG_ID ( H.ORDERNO ),H.ORG_ID)                                                                                      
         and    H.PLANT_ID          = dxp.PLANT_ID                                                                                  
         and    C.RETURN_SERVICE_ID = dcs.SERVICE_ID (+)                                                                            
         and    S.ORDERNO           = myOrder                                                                                       
         and    S.LOCATION          = 'PKD'                                                                                         
         and    S.TRAN_ID           = myTranID                                                                                      
         and    S.SHIP_ID           = myShipID                                                                                      
         and    C.RETURN_TAG_FLAG   = 'R';                                                                                          
                                                                                                                                    
   begin                                                                                                                            
      log;                                                                                                                          
      mySect := 'BlkRtnServ - c1 loop';                                                                                             
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         myRShipID := c1r.RETURN_SHIP_ID;                                                                                           
                                                                                                                                    
         if myRShipID = 0 then                                                                                                      
            log;                                                                                                                    
            mySect := 'Track - Load Rtrn Ship ID';                                                                                  
                                                                                                                                    
            select DEX_SHIP_INTERFACE_S.nextval                                                                                     
            into   myRShipID                                                                                                        
            from   DUAL;                                                                                                            
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Track - Rtrn Update Serials';                                                                                
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            RETURN_SHIP_ID = myRShipID                                                                                              
            where SHIP_ID = c1r.SHIP_ID;                                                                                            
         end if;                                                                                                                    
                                                                                                                                    
         RETURN_SERVICE ( myRShipID,c1r.SHIP_ID,myUserID,c1r.RETURN_S                                                               
ERVICE_CODE,c1r.RETURN_METHOD_TYPE,c1r.RETURN_LOCATI                                                                                
ON_ID );                                                                                                                            
      end loop;                                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'BlkRtnServ - Update';                                                                                              
                                                                                                                                    
      update DEX_SHIP_INTERFACE set                                                                                                 
      RETURN_SHIP_ID = myRShipID                                                                                                    
      where SHIP_ID = myShipID;                                                                                                     
   end BULK_RETURN_SERVICE;                                                                                                         
                                                                                                                                    
   /*************************************************                                                                               
**************************************************                                                                                  
    -- This function will separate out Sales Order Li                                                                               
nes for Serials that have different Prices.  This                                                                                   
    -- is only done if the Customer is setup in the Pr                                                                              
ice Xref form to have a Location of Sales Shipment                                                                                  
    -- The Price List used would be taken from the Pr                                                                               
ice Xref Form.                                                                                                                      
    ***********************************************************                                                                     
***************************************/                                                                                            
   function SALES_FEES (myOrder         varchar2                                                                                    
                       ,myTranID     number                                                                                         
                        ) return varchar2 is                                                                                        
                                                                                                                                    
      myRetMesg   varchar2(200);                                                                                                    
      myRetCode   number;                                                                                                           
      myCustID    number;                                                                                                           
      myOrgID     number;                                                                                                           
      mySalesFee  varchar2(1);                                                                                                      
      myItem      number;                                                                                                           
      myNewPrice  number;                                                                                                           
      myTrckCnt   number;                                                                                                           
      myNewItem   number;                                                                                                           
      myResvId    number;                                                                                                           
      myPickID    number;                                                                                                           
      myUserID    number := f_dex_user_id;                                                                                          
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select distinct d.ITEM                                                                                                     
               ,msn.WARRANTY_STATUS                                                                                                 
               ,decode(msn.WARRANTY_STATUS, 'Valid', null, msn.TYPE                                                                 
_CODE)  TYPE_CODE                                                                                                                   
               ,d.PRICE    ORIG_PRICE                                                                                               
               ,d.INVENTORY_ITEM_ID                                                                                                 
               ,d.PART                                                                                                              
               ,d.QTYORG  - nvl(d.QTYSHP,0) QTYOPN                                                                                  
         from   XXDEX_MTL_SERIAL_NUMBERS_V msn                                                                                      
               ,DEX_LINES d                                                                                                         
               ,DEX_SERIALS s                                                                                                       
         where  s.ORDERNO = myOrder                                                                                                 
         and    s.TRAN_ID = myTranID                                                                                                
         and    s.ORDERNO = D.ORDERNO                                                                                               
         and    s.ITEM    = D.ITEM                                                                                                  
         and    s.TRACK   = msn.SERIAL_NUMBER                                                                                       
         and    d.INVENTORY_ITEM_ID = msn.INVENTORY_ITEM_                                                                           
ID                                                                                                                                  
         and    d.ORGANIZATION_ID   = msn.CURRENT_ORGANIZATION_ID                                                                   
         and    d.SUBINVENTORY_CODE = msn.CURRENT_SUBINVENTOR                                                                       
Y_CODE                                                                                                                              
         and    msn.CURRENT_STATUS  = 3                                                                                             
         order by 1;                                                                                                                
                                                                                                                                    
      -- Serials with New Price                                                                                                     
      cursor c2 is                                                                                                                  
         select s.SERIAL_ID                                                                                                         
               ,d.ORGANIZATION_ID                                                                                                   
               ,d.INVENTORY_ITEM_ID                                                                                                 
               ,d.SUBINVENTORY_CODE                                                                                                 
         from   XXDEX_MTL_SERIAL_NUMBERS_V msn                                                                                      
               ,DEX_LINES d                                                                                                         
               ,DEX_SERIALS s                                                                                                       
         where  s.ORDERNO = myOrder                                                                                                 
         and    s.ITEM    = myItem                                                                                                  
         and    s.TRAN_ID = myTranID                                                                                                
         and    s.ORDERNO = D.ORDERNO                                                                                               
         and    s.ITEM    = D.ITEM                                                                                                  
         and    s.TRACK   = msn.SERIAL_NUMBER                                                                                       
         and    d.INVENTORY_ITEM_ID = msn.INVENTORY_ITEM_ID                                                                         
         and    d.ORGANIZATION_ID   = msn.CURRENT_ORGANI                                                                            
ZATION_ID                                                                                                                           
         and    d.SUBINVENTORY_CODE = msn.CURRENT_SUBINVENTORY_CODE                                                                 
         and    msn.CURRENT_STATUS  = 3                                                                                             
         and    decode(msn.WARRANTY_STATUS,'Valid',0, nvl( K_DEX                                                                    
_TRANSACTION_FEES.FEE(myCustID, myOrgID, D.INVENTORY                                                                                
_ITEM_ID, 'SAL', msn.TYPE_CODE),D.PRICE)) = myNewPri                                                                                
ce;                                                                                                                                 
                                                                                                                                    
   begin                                                                                                                            
      myRetMesg := null;                                                                                                            
                                                                                                                                    
      mySect := 'Sales Fee - Set Flag';                                                                                             
                                                                                                                                    
      begin                                                                                                                         
         select 'Y'                                                                                                                 
               ,ord.CUSTOMER_ID                                                                                                     
               ,ord.ORG_ID                                                                                                          
         into   mySalesFee                                                                                                          
               ,myCustID                                                                                                            
               ,myOrgID                                                                                                             
         from   DEX_PRICE_XREF xref                                                                                                 
               ,DEX_ORDERS ord                                                                                                      
         where  ord.CUSTOMER_ID = xref.CUSTOMER_ID                                                                                  
         and    ord.ORDERNO     = myOrder                                                                                           
         and    ord.ORDTYPE     = 'S'                                                                                               
         and    xref.FEE_LOCN   = 'SAL'                                                                                             
         and    rownum          < 2;                                                                                                
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            mySalesFee := 'N';                                                                                                      
      end;                                                                                                                          
                                                                                                                                    
      if mySalesFee = 'N' then                                                                                                      
         return ( null );                                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      for r1 in c1 loop                                                                                                             
         if r1.WARRANTY_STATUS = 'Valid' then                                                                                       
            myNewPrice := 0;                                                                                                        
         else                                                                                                                       
            mySect := 'Sales Fees-Fee';                                                                                             
            myNewPrice := nvl(K_DEX_TRANSACTION_FEES.FEE(myCustID, my                                                               
OrgID, r1.INVENTORY_ITEM_ID, 'SAL', r1.TYPE_CODE,'Y'                                                                                
), r1.ORIG_PRICE);                                                                                                                  
         end if;                                                                                                                    
                                                                                                                                    
         if myNewPrice != r1.ORIG_PRICE then                                                                                        
            myItem := r1.ITEM;                                                                                                      
                                                                                                                                    
            -- Get count                                                                                                            
            select nvl(count(*),0)                                                                                                  
            into   myTrckCnt                                                                                                        
            from   XXDEX_MTL_SERIAL_NUMBERS_V msn                                                                                   
                  ,DEX_LINES d                                                                                                      
                  ,DEX_SERIALS s                                                                                                    
            where  s.ORDERNO = myOrder                                                                                              
            and    s.ITEM    = myItem                                                                                               
            and    s.TRAN_ID = myTranID                                                                                             
            and    s.ORDERNO = D.ORDERNO                                                                                            
            and    s.ITEM    = D.ITEM                                                                                               
            and    s.TRACK   = msn.SERIAL_NUMBER                                                                                    
            and    d.INVENTORY_ITEM_ID = msn.INVENTORY_ITEM_ID                                                                      
                                                                                                                                    
            and    d.ORGANIZATION_ID   = msn.CURRENT_ORGANIZATION_ID                                                                
            and    d.SUBINVENTORY_CODE = msn.CURRENT_SUBINVE                                                                        
NTORY_CODE                                                                                                                          
            and    msn.CURRENT_STATUS  = 3                                                                                          
            and    decode(msn.WARRANTY_STATUS,'Valid',0, nvl( K_DEX_TRANSACT                                                        
ION_FEES.FEE(myCustID, myOrgID, D.INVENTORY_ITEM_ID,                                                                                
 'SAL', msn.TYPE_CODE),D.PRICE)) = myNewPrice;                                                                                      
                                                                                                                                    
            if myTrckCnt = r1.QTYOPN then                                                                                           
               -- Price can be changed on line becuase Open Qty ma                                                                  
tchs Quantity on Picklist                                                                                                           
               update DEX_LINES set PRICE = myNewPri                                                                                
ce                                                                                                                                  
               where  ORDERNO = myOrder                                                                                             
               and    ITEM    = myItem;                                                                                             
                                                                                                                                    
            else                                                                                                                    
               -- move tracks to different line                                                                                     
               mySect := 'Sales Fees - Move';                                                                                       
                                                                                                                                    
               for r2 in c2 loop                                                                                                    
                  K_MOVE_ORDER.SERIAL (                                                                                             
                                       myRetMesg                                                                                    
                                      ,myRetCode                                                                                    
                                      ,myOrder                                                                                      
                                      ,myItem                                                                                       
                                      ,r2.SERIAL_ID                                                                                 
                                      ,myNewPrice                                                                                   
                                   );                                                                                               
                                                                                                                                    
                  if myRetCode != 0 then                                                                                            
                     exit;                                                                                                          
                  end if;                                                                                                           
                                                                                                                                    
                  select ITEM                                                                                                       
                        ,PICKLIST_ID                                                                                                
                  into   myNewItem                                                                                                  
                        ,myPickID                                                                                                   
                  from   DEX_SERIALS                                                                                                
                  where  SERIAL_ID = r2.SERIAL_ID;                                                                                  
                                                                                                                                    
                  if myNewItem != myItem then                                                                                       
                     update RESERVATIONS set                                                                                        
                     QUANTITY = QUANTITY - 1                                                                                        
                     where  ORDER_NUM = myOrder                                                                                     
                     and    ORDER_ITEM = myItem;                                                                                    
                                                                                                                                    
                     begin                                                                                                          
                        select RESERVATION_ID                                                                                       
                        into   myResvID                                                                                             
                        from   RESERVATIONS                                                                                         
                        where  ORDER_NUM = myOrder                                                                                  
                        and    ORDER_ITEM = myNewItem                                                                               
                        and    STATUS = 'P'                                                                                         
                        and    rownum < 2;                                                                                          
                                                                                                                                    
                        update RESERVATIONS set                                                                                     
                        QUANTITY = QUANTITY + 1                                                                                     
                        where  RESERVATION_ID = myResvId;                                                                           
                                                                                                                                    
                     exception                                                                                                      
                        when NO_DATA_FOUND then                                                                                     
                            insert into RESERVATIONS                                                                                
                            (RESERVATION_ID                                                                                         
                            ,CREATION_DATE                                                                                          
                            ,CREATED_BY                                                                                             
                            ,LAST_UPDATE_DATE                                                                                       
                            ,LAST_UPDATED_BY                                                                                        
                            ,ORGANIZATION_ID                                                                                        
                            ,INVENTORY_ITEM_ID                                                                                      
                            ,SUBINVENTORY_CODE                                                                                      
                            ,ORDER_NUM                                                                                              
                            ,ORDER_ITEM                                                                                             
                            ,PICKLIST_ID                                                                                            
                            ,QUANTITY                                                                                               
                            ,STATUS                                                                                                 
                            ) values (                                                                                              
                             RESERVATIONS_S.nextval                                                                                 
 -- RESERVATION_ID                                                                                                                  
                            ,SYSDATE                                                                                                
    -- CREATION_DATE                                                                                                                
                            ,myUserID                                                                                               
      -- CREATED_BY                                                                                                                 
                            ,SYSDATE                                                                                                
     -- LAST_UPDATE_DATE                                                                                                            
                            ,myUserID                                                                                               
          -- LAST_UPDATED_BY                                                                                                        
                            ,r2.ORGANIZATION_ID                                                                                     
                            ,r2.INVENTORY_ITEM_ID                                                                                   
                            ,r2.SUBINVENTORY_CODE                                                                                   
                            ,myOrder                                                                                                
                            ,myNewItem                                                                                              
                            ,myPickID                                                                                               
   -- PICKLIST_ID                                                                                                                   
                            ,1                                                                                                      
  -- QUANTITY                                                                                                                       
                            ,'P'                               -                                                                    
- STATUS                                                                                                                            
                            );                                                                                                      
                     end;                                                                                                           
                  end if;                                                                                                           
               end loop;                                                                                                            
                                                                                                                                    
               if myRetCode != 0 then                                                                                               
                  exit;                                                                                                             
               end if;                                                                                                              
            end if;                                                                                                                 
         end if;                                                                                                                    
      end loop;                                                                                                                     
      return (myRetMesg);                                                                                                           
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
         return (myRetMesg);                                                                                                        
   end SALES_FEES;                                                                                                                  
                                                                                                                                    
   /*************************************************                                                                               
****************************************************                                                                                
*********/                                                                                                                          
                                                                                                                                    
   procedure TRACK (                                                                                                                
                     myRetMesg  out  varchar2                                                                                       
                    ,myPickID        number                                                                                         
                    ,myEmp           varchar2                                                                                       
                    ,myOrder         varchar2                                                                                       
                    ,myTranID        number                                                                                         
                  ) is                                                                                                              
      myShipID      pls_integer;                                                                                                    
      myRShipID     pls_integer;                                                                                                    
                                                                                                                                    
      myUserID      pls_integer := F_DEX_USER_ID;                                                                                   
                                                                                                                                    
      myQuote       number;                                                                                                         
      myOrderQty    number;                                                                                                         
                                                                                                                                    
      mySpclHand    pls_integer := 0;                                                                                               
      mySatDevl     pls_integer := 0;                                                                                               
      myDelvConf    pls_integer := 0;                                                                                               
      mySigReqd     pls_integer := 0;                                                                                               
      myOversize    pls_integer := 0;                                                                                               
      myAddlHand    pls_integer := 0;                                                                                               
      myRetSvcSkip  pls_integer := 0;                                                                                               
                                                                                                                                    
      myStatus      varchar2(1);                                                                                                    
      myPlant       DEX_PLANTS.PLANT%type;                                                                                          
		myBuyCust	DEX_ORDERS.CUST%type := nvl(XXDEX_DEFAULTS_F (                                                                          
'INTERNAL_CUST_BUY'),'x');                                                                                                          
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select S.TRACK                                                                                                             
               ,S.ORDERNO                                                                                                           
               ,S.ITEM                                                                                                              
               ,S.LOCATION                                                                                                          
               ,nvl(S.SHIP_ID,0)                                                                                                    
                                             SHIP_ID                                                                                
                                                                                                                                    
               ,decode(D.PART,XXDEX_DEFAULTS_F ( 'ITEM_NON_REPAIR' ),'W'                                                            
                              ,XXDEX_DEFAULTS_F ( 'ITEM_                                                                            
WRONG_MODEL' ),'W'                                                                                                                  
                              ,nvl(S.SCRAP,'N'))                                                                                    
                                               SCRAP                                                                                
                                                                                                                                    
               ,nvl(S.SORT,'G')                                                                                                     
                             SORT                                                                                                   
               ,S.ROAR                                                                                                              
               ,S.ROWID                                                                                                             
                                 ROW_ID                                                                                             
               ,decode(H.CUST,myBuyCust,H.CUST_EXCHANGE,H.CUST)                                                                     
 CUST                                                                                                                               
               ,H.SHIPTO                                                                                                            
               ,H.SHIP_NAME                                                                                                         
               ,H.SHIP_ST1                                                                                                          
               ,H.SHIP_ST2                                                                                                          
               ,H.SHIP_ATTN                                                                                                         
               ,H.SHIP_CITY                                                                                                         
               ,H.SHIP_ZIP                                                                                                          
               ,H.SHIP_STATE                                                                                                        
               ,H.SHIP_VIA                                                                                                          
               ,H.COUNTRY                                                                                                           
               ,H.TELEPHONE                                                                                                         
               ,H.COD                                                                                                               
               ,H.SATURDAY_DELIVERY                                                                                                 
               ,H.FREIGHT_QUOTE                                                                                                     
               ,H.EMAIL                                                                                                             
               ,decode(H.COD,'Y',D.PRICE,0)                                                                                         
    PRICE                                                                                                                           
               ,H.ORDTYPE                                                                                                           
               ,C.COD_PAYMENT_TYPE                                                                                                  
               ,C.COD_COMMENT                                                                                                       
               ,decode(H.CUST,myBuyCust,F_DEXB_ORG_ID (                                                                             
 H.ORDERNO ),H.ORG_ID)    ORG_ID                                                                                                    
               ,nvl(H.RESIDENTIAL_FLAG,'N')                                                                                         
       RESIDENTIAL_FLAG                                                                                                             
               ,nvl(H.SPECIAL_HANDLING,0)                                                                                           
                        SPECIAL_HANDLING                                                                                            
               ,S.BOX_DIM                                                                                                           
               ,S.RETURN_SHIP_ID                                                                                                    
               ,nvl(C.RETURN_TAG_FLAG,'N')                                                                                          
                      RETURN_TAG_FLAG                                                                                               
               ,C.RETURN_METHOD_TYPE                                                                                                
               ,dcs.SERVICE_CODE                                                                                                    
                       RETURN_SERVICE_CODE                                                                                          
               ,dxp.RETURN_LOCATION_ID                                                                                              
               ,H.CUSTOMER_ID                                                                                                       
               ,D.INVENTORY_ITEM_ID                                                                                                 
               ,S.LICENSE_PLATE_ID                                                                                                  
         from   DEX_CARRIER_SERVICES dcs                                                                                            
               ,DEX_CUSTOMER_DATA C                                                                                                 
               ,XXDEX_CUSTOMERS_DEX_V R                                                                                             
               ,DEX_PLANTS dxp                                                                                                      
               ,DEX_ORDERS H                                                                                                        
               ,DEX_LINES D                                                                                                         
               ,DEX_SERIALS S                                                                                                       
         where  S.ORDERNO           = D.ORDERNO                                                                                     
         and    S.ITEM              = D.ITEM                                                                                        
         and    S.ORDERNO           = H.ORDERNO                                                                                     
         and    R.CUSTOMER_NUMBER   = decode(H.CUST,myBuyCust,H.C                                                                   
UST_EXCHANGE,H.CUST)                                                                                                                
         and    R.CUSTOMER_ID       = C.CUSTOMER_ID                                                                                 
         and    C.ORG_ID            = decode(H.CUST,myBuy                                                                           
Cust,F_DEXB_ORG_ID ( H.ORDERNO ),H.ORG_ID)                                                                                          
         and    H.PLANT_ID          = dxp.PLANT_ID                                                                                  
         and    C.RETURN_SERVICE_ID = dcs.SERVICE_ID (+)                                                                            
         and    S.ORDERNO           = myOrder                                                                                       
         and    S.LOCATION          = 'PKD'                                                                                         
         and    S.TRAN_ID           = myTranID;                                                                                     
                                                                                                                                    
   begin                                                                                                                            
      myRetMesg  := null;                                                                                                           
      EMAIL_FLAG := 'N';                                                                                                            
      EMAIL_ADDR := null;                                                                                                           
                                                                                                                                    
      mySect := 'Track - Sales Fee';                                                                                                
      myRetMesg := SALES_FEES (myOrder, myTranID);                                                                                  
      if myRetMesg is not null then                                                                                                 
         return;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      mySect := 'Track - Plant';                                                                                                    
                                                                                                                                    
      select PLANT                                                                                                                  
      into   myPlant                                                                                                                
      from   PICKLIST                                                                                                               
      where  PICKLIST_ID = myPickID;                                                                                                
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - c1 loop';                                                                                                  
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         if c1r.SHIP_ID > 0 then                                                                                                    
            myShipID := c1r.SHIP_ID;                                                                                                
         else                                                                                                                       
            log;                                                                                                                    
            mySect := 'Track - Load Ship ID';                                                                                       
                                                                                                                                    
            select DEX_SHIP_INTERFACE_S.nextval                                                                                     
            into   myShipID                                                                                                         
            from   DUAL;                                                                                                            
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Track - Update Serials';                                                                                     
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            SHIP_ID = myShipID                                                                                                      
            where ROWID = c1r.ROW_ID;                                                                                               
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Qty';                                                                                                   
                                                                                                                                    
         select sum(QTYORG)                                                                                                         
         into   myOrderQty                                                                                                          
         from   DEX_LINES                                                                                                           
         where  ORDERNO = c1r.ORDERNO                                                                                               
         and    PART  not in (XXDEX_DEFAULTS_F ( 'ITEM_TAX'                                                                         
 ),XXDEX_DEFAULTS_F ( 'ITEM_SERVICE_FEE' ),XXDEX_DEF                                                                                
AULTS_F ( 'ITEM_PAYPAL_FEE' ));                                                                                                     
                                                                                                                                    
         myQuote := c1r.FREIGHT_QUOTE / myOrderQty;                                                                                 
                                                                                                                                    
         if c1r.EMAIL is not null then                                                                                              
            EMAIL_FLAG := 'Y';                                                                                                      
            EMAIL_ADDR := c1r.EMAIL;                                                                                                
                                                                                                                                    
         else                                                                                                                       
            log;                                                                                                                    
            mySect := 'Track - Load EMail';                                                                                         
                                                                                                                                    
            EMAIL ( c1r.CUST,c1r.SHIPTO,c1r.ORG_ID);                                                                                
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Special Handling';                                                                                      
                                                                                                                                    
         mySpclHand := c1r.SPECIAL_HANDLING;                                                                                        
                                                                                                                                    
         if mySpclHand > 0 then                                                                                                     
            if F_DEX_BITAND ( mySpclHand,32 ) > 0 then                                                                              
               myRetSvcSkip:= 1;                                                                                                    
               mySpclHand := mySpclHand - 32;                                                                                       
            else                                                                                                                    
               myRetSvcSkip := 0;                                                                                                   
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,16 ) > 0 then                                                                              
               myAddlHand := 1;                                                                                                     
               mySpclHand := mySpclHand - 16;                                                                                       
            else                                                                                                                    
               myAddlHand := 0;                                                                                                     
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,8 ) > 0 then                                                                               
               myOversize := 1;                                                                                                     
               mySpclHand := mySpclHand - 8;                                                                                        
            else                                                                                                                    
               myOversize := 0;                                                                                                     
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,4 ) > 0 then                                                                               
                                                                                                                                    
               mySigReqd  := 1;                                                                                                     
               mySpclHand := mySpclHand - 4;                                                                                        
            else                                                                                                                    
               mySigReqd  := 0;                                                                                                     
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,2 ) > 0 then                                                                               
               myDelvConf := 1;                                                                                                     
               mySpclHand := mySpclHand - 2;                                                                                        
            else                                                                                                                    
               myDelvConf := 0;                                                                                                     
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,1 ) > 0 then                                                                               
               mySatDevl  := 1;                                                                                                     
               mySpclHand := mySpclHand - 1;                                                                                        
            else                                                                                                                    
               mySatDevl  := 0;                                                                                                     
            end if;                                                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Status';                                                                                                
                                                                                                                                    
         myStatus := STATUS ( c1r.CUSTOMER_ID,c1r.INVENTO                                                                           
RY_ITEM_ID );                                                                                                                       
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Track - Insert Interface';                                                                                      
                                                                                                                                    
         insert into DEX_SHIP_INTERFACE                                                                                             
        (SHIP_ID,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,C                                                                   
REATED_BY                                                                                                                           
        ,STATUS,SHIP_TYPE,PLANT,SEGMENT1,SEGMENT2,SEGMENT3,SEGMENT4,                                                                
SHIP_NAME,COUNTRY,CONSIGNEE_PHONE                                                                                                   
        ,ADDRESS1,ADDRESS2,ADDRESS3,ADDRESS4,CITY,STATE,POSTAL_CODE,PR                                                              
OVINCE,COUNTY                                                                                                                       
        ,SHIP_METHOD_CODE,COD,COD_AMOUNT,COD_PAYMENT_TYPE,COD_CO                                                                    
MMENT                                                                                                                               
        ,PICKLIST_ID,TRAN_ID,PACKAGE_TYPE,ATTRIBUTE1,FREIGHT_QUOTE                                                                  
        ,EMAIL_NOTIFY_FLAG,EMAIL_ADDRESS                                                                                            
        ,RESIDENTIAL,SATURDAY_DELIVERY,SATURDAY                                                                                     
        ,DELIVERY_CONF, SIGNATURE_REQUIRED, OVERSIZE, ADDTIONAL_HANDLING                                                            
                                                                                                                                    
        ,DIMENSION,NEW_FLAG,RETURN_SHIP_ID,LICENSE_PLATE                                                                            
        ) values (                                                                                                                  
         myShipID,SYSDATE,myUserID,SYSDATE,myUserID                                                                                 
        ,myStatus,'T',myPlant,c1r.ORDERNO,c1r.CUST,c1                                                                               
r.TRACK,c1r.ITEM,c1r.SHIP_NAME,c1r.COUNTRY,c1r.TELEP                                                                                
HONE                                                                                                                                
        ,c1r.SHIP_ST1,c1r.SHIP_ST2,null,c1r.SHIP_ATTN,c1r.SHIP_CITY,c1r.S                                                           
HIP_STATE,c1r.SHIP_ZIP,null,null                                                                                                    
        ,c1r.SHIP_VIA,c1r.COD,decode(c1r.COD,'Y',c1r.PRICE,0),c1r.COD_P                                                             
AYMENT_TYPE,c1r.COD_COMMENT                                                                                                         
        ,myPickID,myTranID,'CUSTOM',c1r.SCRAP,myQuote                                                                               
        ,EMAIL_FLAG,EMAIL_ADDR                                                                                                      
        ,decode(c1r.RESIDENTIAL_FLAG,'Y',1,0),decode(mySatDevl,1,'Y',                                                               
'N') ,mySatDevl                                                                                                                     
        ,myDelvConf,mySigReqd,myOversize,myAddlHand                                                                                 
        ,c1r.BOX_DIM,'Y',c1r.RETURN_SHIP_ID,c1r.LICENSE_PLATE_                                                                      
ID                                                                                                                                  
        );                                                                                                                          
                                                                                                                                    
         if c1r.SCRAP != 'N' then                                                                                                   
            log;                                                                                                                    
            mySect := 'Track - Address';                                                                                            
                                                                                                                                    
            ADDRESS ( myShipID,c1r.CUST,c1r.SCRAP,c1r.ROAR,c1r.ORG_ID );                                                            
         end if;                                                                                                                    
                                                                                                                                    
         if c1r.SORT != 'G' then                                                                                                    
            log;                                                                                                                    
            mySect := 'Track - Address';                                                                                            
                                                                                                                                    
            ADDRESS ( myShipID,c1r.CUST,c1r.SORT,c1r.ROAR,c1r.ORG_ID );                                                             
         end if;                                                                                                                    
                                                                                                                                    
         if c1r.ORDTYPE = 'S' and c1r.RETURN_TAG_FLAG = 'R' a                                                                       
nd myRetSvcSkip!=1 then                                                                                                             
            myRShipID := nvl(c1r.RETURN_SHIP_ID,0);                                                                                 
                                                                                                                                    
            if myRShipID = 0 then                                                                                                   
               log;                                                                                                                 
               mySect := 'Track - Load Rtrn Ship ID';                                                                               
                                                                                                                                    
               select DEX_SHIP_INTERFACE_S.nextval                                                                                  
               into   myRShipID                                                                                                     
               from   DUAL;                                                                                                         
                                                                                                                                    
               log;                                                                                                                 
               mySect := 'Track - Rtrn Update Serials';                                                                             
                                                                                                                                    
               update DEX_SERIALS set                                                                                               
               RETURN_SHIP_ID = myRShipID                                                                                           
               where SHIP_ID = myShipID;                                                                                            
                                                                                                                                    
               log;                                                                                                                 
               mySect := 'Track - Rtrn Update DSI';                                                                                 
                                                                                                                                    
               update DEX_SHIP_INTERFACE set                                                                                        
               RETURN_SHIP_ID = myRShipID                                                                                           
               where SHIP_ID = myShipID;                                                                                            
            end if;                                                                                                                 
                                                                                                                                    
            RETURN_SERVICE ( myRShipID,myShipID,myUserID,c1r.                                                                       
RETURN_SERVICE_CODE,c1r.RETURN_METHOD_TYPE,c1r.RETUR                                                                                
N_LOCATION_ID );                                                                                                                    
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Close Picklist';                                                                                           
                                                                                                                                    
      K_PICKLIST.CLOSE ( myPickID,myOrder );                                                                                        
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Track - Complete';                                                                                                 
      log;                                                                                                                          
                                                                                                                                    
      myRetMesg := null;                                                                                                            
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end TRACK;                                                                                                                       
                                                                                                                                    
   /***************************************************                                                                             
****************************************************                                                                                
*******/                                                                                                                            
                                                                                                                                    
   procedure MULTIPACK (                                                                                                            
                         myRetMesg  out  varchar2                                                                                   
                        ,myPickID        number                                                                                     
                        ,myEmp           varchar2                                                                                   
                        ,myOrder         varchar2                                                                                   
                        ,myTranID        number                                                                                     
                     ) is                                                                                                           
      myUserID      pls_integer := F_DEX_USER_ID;                                                                                   
                                                                                                                                    
      myCustID      pls_integer;                                                                                                    
      myOrgID       pls_integer;                                                                                                    
      myShipID      pls_integer;                                                                                                    
      myShipto      pls_integer;                                                                                                    
                                                                                                                                    
      myOrderQty    number;                                                                                                         
      myQuote       number;                                                                                                         
      myShipCount   number;                                                                                                         
      myAmount      number;                                                                                                         
      myFreight     number;                                                                                                         
      myLicPlateID  number;                                                                                                         
                                                                                                                                    
      myScrap       varchar2(1);                                                                                                    
      myCust        DEX_ORDERS.CUST%type;                                                                                           
      mySatDel      varchar2(1);                                                                                                    
      myOrdType     varchar2(1);                                                                                                    
                                                                                                                                    
      mySpclHand    pls_integer := 0;                                                                                               
      mySatDevl     pls_integer := 0;                                                                                               
      myDelvConf    pls_integer := 0;                                                                                               
      mySigReqd     pls_integer := 0;                                                                                               
      myOversize    pls_integer := 0;                                                                                               
      myAddlHand    pls_integer := 0;                                                                                               
      myRetSvcSkip  pls_integer := 0;                                                                                               
                                                                                                                                    
      myCountry     varchar2(2);                                                                                                    
      myResFlag     varchar2(1);                                                                                                    
      myDimension   varchar2(20);                                                                                                   
      myEMail       varchar2(100);                                                                                                  
                                                                                                                                    
      myStatus      varchar2(1) := 'O';                                                                                             
                                                                                                                                    
		myBuyCust	DEX_ORDERS.CUST%type := nvl(XXDEX_DEFAULTS                                                                              
_F ('INTERNAL_CUST_BUY'),'x');                                                                                                      
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select SHIP_ID                                                                                                             
               ,count('*')   QTY                                                                                                    
         from   DEX_SERIALS                                                                                                         
         where  ORDERNO  = myOrder                                                                                                  
         and    LOCATION = 'PKD'                                                                                                    
         and    TRAN_ID  = myTranID                                                                                                 
         group by SHIP_ID;                                                                                                          
                                                                                                                                    
   begin                                                                                                                            
      myRetMesg := null;                                                                                                            
      EMAIL_FLAG := 'N';                                                                                                            
      EMAIL_ADDR := null;                                                                                                           
                                                                                                                                    
      mySect := 'Multi - Sales Fee';                                                                                                
      myRetMesg := SALES_FEES (myOrder, myTranID);                                                                                  
      if myRetMesg is not null then                                                                                                 
         return;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      mySect := 'Multi - Init';                                                                                                     
      log;                                                                                                                          
      mySect := 'Multi - Status';                                                                                                   
                                                                                                                                    
      begin                                                                                                                         
         select 'S'                                                                                                                 
         into   myStatus                                                                                                            
         from   DEX_ORDERS ord                                                                                                      
               ,DEX_LINES lne                                                                                                       
               ,DEX_SERIALS ser                                                                                                     
         where  ser.ORDERNO  = lne.ORDERNO                                                                                          
         and    ser.ITEM     = lne.ITEM                                                                                             
         and    ser.ORDERNO  = ord.ORDERNO                                                                                          
         and    ser.ORDERNO  = myOrder                                                                                              
         and    ser.LOCATION = 'PKD'                                                                                                
         and    ser.TRAN_ID  = myTranID                                                                                             
         and   (exists                                                                                                              
               (select '*'                                                                                                          
                from   DEX_LSM_CUSTOMER dlc                                                                                         
                where  dlc.CUSTOMER_ID = ord.CUSTOMER_ID                                                                            
                and    dlc.LOCN        = 'SHC')                                                                                     
           or   exists                                                                                                              
               (select '*'                                                                                                          
                from   DEX_LSM_ITEM dli                                                                                             
                where  dli.CUSTOMER_ID       = ord.CUSTOM                                                                           
ER_ID                                                                                                                               
                and    dli.INVENTORY_ITEM_ID = lne.INVENTORY_ITEM_ID                                                                
                and    dli.LOCN              = 'SHC'))                                                                              
         and    rownum < 2;                                                                                                         
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myStatus := 'O';                                                                                                        
      end;                                                                                                                          
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Multi - c1 loop';                                                                                                  
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         myShipID := c1r.SHIP_ID;                                                                                                   
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Multi - Load Data';                                                                                             
                                                                                                                                    
         select decode(H.CUST,myBuyCust,CUST_EXCHANGE,CUS                                                                           
T)                      CUST                                                                                                        
               ,decode(H.CUST,myBuyCust,C.CUSTOMER_ID,H.CUSTOMER_ID)                                                                
      CUST_ID                                                                                                                       
               ,decode(H.CUST,myBuyCust,F_DEXB_ORG_ID ( H.ORDERN                                                                    
O ),H.ORG_ID)    ORG_ID                                                                                                             
               ,nvl(H.RESIDENTIAL_FLAG,'N')  RESIDENTI                                                                              
AL_FLAG                                                                                                                             
               ,nvl(H.SPECIAL_HANDLING,0)    SPECIAL_HANDLING                                                                       
               ,H.COUNTRY                                                                                                           
               ,H.FREIGHT_QUOTE                                                                                                     
               ,H.EMAIL                                                                                                             
               ,H.ORDTYPE                                                                                                           
               ,max(S.BOX_DIM)   BOX_DIM                                                                                            
               ,min(SHIPTO)                                                                                                         
               ,sum(decode(H.COD,'Y',D.PRICE,0))                                                                                    
               ,sum(decode(PART,XXDEX_DEFAULTS_F ( 'ITEM_TAX' ),0,QT                                                                
YORG))                                                                                                                              
               ,max(LICENSE_PLATE_ID)                                                                                               
         into   myCust                                                                                                              
               ,myCustID                                                                                                            
               ,myOrgID                                                                                                             
               ,myResFlag                                                                                                           
               ,mySpclHand                                                                                                          
               ,myCountry                                                                                                           
               ,myFreight                                                                                                           
               ,myEMail                                                                                                             
               ,myOrdType                                                                                                           
               ,myDimension                                                                                                         
               ,myShipto                                                                                                            
               ,myAmount                                                                                                            
               ,myOrderQty                                                                                                          
               ,myLicPlateID                                                                                                        
         from   DEX_SERIALS S                                                                                                       
               ,DEX_LINES D                                                                                                         
               ,DEX_ORDERS H                                                                                                        
               ,XXDEX_CUSTOMERS_DEX_V C                                                                                             
         where  S.ORDERNO         = D.ORDERNO                                                                                       
         and    S.ITEM            = D.ITEM                                                                                          
         and    S.ORDERNO         = H.ORDERNO                                                                                       
         and    C.CUSTOMER_NUMBER = decode(H.CUST,myBuyCust,                                                                        
CUST_EXCHANGE,CUST)                                                                                                                 
         and    S.ORDERNO         = myOrder                                                                                         
         and    S.LOCATION        = 'PKD'                                                                                           
         and    S.SHIP_ID         = myShipID                                                                                        
         group by decode(H.CUST,myBuyCust,CUST_EXCHANGE,C                                                                           
UST)                                                                                                                                
                 ,decode(H.CUST,myBuyCust,C.CUSTOMER_ID,H.CUSTOMER_ID)                                                              
                 ,decode(H.CUST,myBuyCust,F_DEXB_ORG_I                                                                              
D ( H.ORDERNO ),H.ORG_ID)                                                                                                           
                 ,nvl(H.RESIDENTIAL_FLAG,'N')                                                                                       
                 ,NVL(H.SPECIAL_HANDLING,0)                                                                                         
                 ,H.COUNTRY                                                                                                         
                 ,H.FREIGHT_QUOTE                                                                                                   
                 ,H.EMAIL                                                                                                           
                 ,H.ORDTYPE;                                                                                                        
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Multi - Count';                                                                                                 
                                                                                                                                    
         -- Feb 2007 - Order Qty in query above overs                                                                               
tated because querying down to Serial table.                                                                                        
         select sum(QTYORG)                                                                                                         
         into   myOrderQty                                                                                                          
         from   DEX_LINES                                                                                                           
         where  ORDERNO = myOrder                                                                                                   
         and    PART  not in (XXDEX_DEFAULTS_F ( 'ITEM_TAX' ),XXDEX_DEFAUL                                                          
TS_F ( 'ITEM_SERVICE_FEE' ),XXDEX_DEFAULTS_F ( 'ITEM                                                                                
_PAYPAL_FEE' ),XXDEX_DEFAULTS_F ( 'ITEM_SHIP_INSURE_                                                                                
FEE' ));                                                                                                                            
                                                                                                                                    
         select count(TRACK)                                                                                                        
         into   myShipCount                                                                                                         
         from   DEX_SERIALS                                                                                                         
         where  LOCATION = 'PKD'                                                                                                    
         and    SHIP_ID  = myShipID;                                                                                                
                                                                                                                                    
         myQuote := (myFreight / myOrderQty) * myShipCount;                                                                         
                                                                                                                                    
         if myEMail is not null then                                                                                                
            EMAIL_FLAG := 'Y';                                                                                                      
            EMAIL_ADDR := myEMail;                                                                                                  
                                                                                                                                    
         else                                                                                                                       
            log;                                                                                                                    
            mySect := 'Multi - Load EMail';                                                                                         
                                                                                                                                    
            EMAIL ( myCust,myShipto,myOrgID );                                                                                      
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Multi - Load Scrap';                                                                                            
                                                                                                                                    
         select SCRAP                                                                                                               
         into   myScrap                                                                                                             
         from   PICKLIST                                                                                                            
         where  PICKLIST_ID = myPickID;                                                                                             
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Multi-Special Handling';                                                                                        
                                                                                                                                    
         if mySpclHand > 0 then                                                                                                     
            if F_DEX_BITAND ( mySpclHand,32 ) > 0 then                                                                              
               myRetSvcSkip := 1;                                                                                                   
               mySpclHand := mySpclHand - 16;                                                                                       
            else                                                                                                                    
               myRetSvcSkip := 0;                                                                                                   
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,16 ) > 0 then                                                                              
               myAddlHand := 1;                                                                                                     
               mySpclHand := mySpclHand - 16;                                                                                       
            else                                                                                                                    
               myAddlHand := 0;                                                                                                     
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,8 ) > 0 then                                                                               
               myOversize := 1;                                                                                                     
               mySpclHand := mySpclHand - 8;                                                                                        
            else                                                                                                                    
               myOversize:= 0;                                                                                                      
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,4 ) > 0 then                                                                               
               mySigReqd := 1;                                                                                                      
               mySpclHand := mySpclHand - 4;                                                                                        
            else                                                                                                                    
               mySigReqd := 0;                                                                                                      
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,2 ) > 0 then                                                                               
               myDelvConf := 1;                                                                                                     
               mySpclHand := mySpclHand - 2;                                                                                        
            else                                                                                                                    
               myDelvConf :=0;                                                                                                      
            end if;                                                                                                                 
                                                                                                                                    
            if F_DEX_BITAND ( mySpclHand,1 ) > 0 then                                                                               
                                                                                                                                    
               mySatDevl :=1;                                                                                                       
               mySpclHand := mySpclHand - 1;                                                                                        
            else                                                                                                                    
               mySatDevl := 0;                                                                                                      
            end if;                                                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Multi - Insert';                                                                                                
                                                                                                                                    
         insert into DEX_SHIP_INTERFACE                                                                                             
        (SHIP_ID,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION                                                                          
_DATE,CREATED_BY                                                                                                                    
        ,STATUS,SHIP_TYPE,PLANT,SEGMENT1,SEGMENT2,SHIP_NAME,C                                                                       
OUNTRY,CONSIGNEE_PHONE                                                                                                              
        ,ADDRESS1,ADDRESS2,ADDRESS3,ADDRESS4,CITY,STATE                                                                             
,POSTAL_CODE,PROVINCE,COUNTY                                                                                                        
        ,SHIP_METHOD_CODE,WEIGHT,WEIGHT_UNIT_CODE,COD,COD_AMOUNT,COD_PAYMEN                                                         
T_TYPE,COD_COMMENT                                                                                                                  
        ,PICKLIST_ID,TRAN_ID,PACKAGE_TYPE,FREIGHT_QUOTE,EMA                                                                         
IL_NOTIFY_FLAG,EMAIL_ADDRESS                                                                                                        
        ,RESIDENTIAL,SATURDAY_DELIVERY,SATURDAY,DELIVERY_CONF,SIGNATURE_REQ                                                         
UIRED,OVERSIZE                                                                                                                      
        ,ADDTIONAL_HANDLING,DIMENSION,NEW_FLAG,LICENSE_PLATE)                                                                       
         select myShipID,SYSDATE,myUserID,SYSDATE,myU                                                                               
serID                                                                                                                               
               ,myStatus,'M',L.PLANT,myOrder,myCust,H.SHIP_NAME,H.COUNTR                                                            
Y,H.TELEPHONE                                                                                                                       
               ,H.SHIP_ST1,H.SHIP_ST2,null,H.SHIP_ATTN,H.SHIP_CI                                                                    
TY,H.SHIP_STATE,H.SHIP_ZIP                                                                                                          
               ,null,null,H.SHIP_VIA,0,'LB',H.COD,myAmount,C.COD_PAYMENT_TYPE                                                       
,C.COD_COMMENT                                                                                                                      
               ,myPickID,myTranID,'CUSTOM',myQuote,EMAIL_FLAG,E                                                                     
MAIL_ADDR                                                                                                                           
               ,decode(NVL(RESIDENTIAL_FLAG,'N'),'Y',1,0),decode(myS                                                                
atDevl,1,'Y','N') ,mySatDevl                                                                                                        
               ,myDelvConf,mySigReqd,myOversize,myAddlHand,myDimension,'Y',                                                         
myLicPlateID                                                                                                                        
         from   DEX_ORDERS H                                                                                                        
               ,DEX_CUSTOMER_DATA C                                                                                                 
               ,PICKLIST L                                                                                                          
         where  C.CUSTOMER_ID = myCustID                                                                                            
         and    C.ORG_ID      = myOrgID                                                                                             
         and    H.ORDERNO     = myOrder                                                                                             
         and    L.PICKLIST_ID = myPickID;                                                                                           
                                                                                                                                    
         if myScrap != 'N' or myScrap IN ( 'B','W') then                                                                            
            log;                                                                                                                    
            mySect := 'Multi - Address';                                                                                            
                                                                                                                                    
            ADDRESS ( myShipID,myCust,myScrap,null,myOrgI                                                                           
D );                                                                                                                                
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Multi - Bulk Rtrn Service';                                                                                     
                                                                                                                                    
         if myOrdType = 'S' and myRetSvcSkip != 1 then                                                                              
            BULK_RETURN_SERVICE ( myShipID,myOrder,myTranID,myUserI                                                                 
D );                                                                                                                                
         end if;                                                                                                                    
      end loop;                                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Multi - Picklist Close';                                                                                           
                                                                                                                                    
      K_PICKLIST.CLOSE ( myPickID,myOrder );                                                                                        
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end MULTIPACK;                                                                                                                   
                                                                                                                                    
   /******************************************************************                                                              
********************************************                                                                                        
		June 2009 (AC) - modifications made to handle both Serial                                                                         
ized and NonSerialized items. This is needed                                                                                        
		                 because single shipments may be a combin                                                                         
ation of Serialized and Nonserialized.                                                                                              
	****************************************************************                                                                   
**********************************************/                                                                                     
   procedure MANIFEST (                                                                                                             
                        myRetMesg  out  varchar2                                                                                    
                       ,myPickID        number                                                                                      
                       ,myEmp           varchar2                                                                                    
                       ,myOrder         varchar2                                                                                    
                       ,myTranID        number                                                                                      
                       ,myShipID        number                                                                                      
                       ,myWeight        number                                                                                      
                     ) is                                                                                                           
      myUserID      pls_integer := F_DEX_USER_ID;                                                                                   
                                                                                                                                    
      myCustID      pls_integer;                                                                                                    
      myOrgID       pls_integer;                                                                                                    
                                                                                                                                    
      myOrderQty    number;                                                                                                         
      myQuote       number;                                                                                                         
      myShipCount   number;                                                                                                         
                                                                                                                                    
      myAmount      number;                                                                                                         
      myFreight     number;                                                                                                         
      myShipto      number;                                                                                                         
      myLicPlateID number;                                                                                                          
                                                                                                                                    
      myScrap       varchar2(1);                                                                                                    
      myCust        DEX_ORDERS.CUST%type;                                                                                           
      mySatDel      varchar2(1);                                                                                                    
      myOrdType     varchar2(1);                                                                                                    
      myIntShipFlag varchar2(1);                                                                                                    
                                                                                                                                    
      myShipName		DEX_SHIP_INTERFACE.SHIP_NAME%type;                                                                                
      myShipAttn		DEX_SHIP_INTERFACE.ADDRESS1%type;                                                                                 
		myStreet1      DEX_SHIP_INTERFACE.ADDRESS1%type;                                                                                  
		myStreet2      DEX_SHIP_INTERFACE.ADDRESS1%type;                                                                                  
		myCity         DEX_SHIP_INTERFACE.CITY%type;                                                                                      
		myState        DEX_SHIP_INTERFACE.STATE%type;                                                                                     
		myCountry      DEX_SHIP_INTERFACE.COUNTRY%type;                                                                                   
		myZip          DEX_SHIP_INTERFACE.POSTAL_CODE%type;                                                                               
		myProvince     DEX_SHIP_INTERFACE.PROVINCE%type;                                                                                  
                                                                                                                                    
		myDstPlantID  number(15);                                                                                                         
      mySpclHand    pls_integer := 0;                                                                                               
      mySatDevl     pls_integer := 0;                                                                                               
      myDelvConf    pls_integer := 0;                                                                                               
      mySigReqd     pls_integer := 0;                                                                                               
      myOversize    pls_integer := 0;                                                                                               
      myAddlHand    pls_integer := 0;                                                                                               
      myRetSvcSkip  pls_integer := 0;                                                                                               
                                                                                                                                    
      myResFlag     varchar2(1);                                                                                                    
      myDimension   varchar2(20);                                                                                                   
      myEMail       varchar2(100);                                                                                                  
      myPlantType	  DEX_CONTROL.PLANT_TYPE%type;                                                                                    
                                                                                                                                    
      myBuyCust	  DEX_ORDERS.CUST%type := nvl(XXDEX_DEFAULTS_F ('INTER                                                              
NAL_CUST_BUY'), 'x');                                                                                                               
                                                                                                                                    
      myStatus      varchar2(1) := 'O';                                                                                             
                                                                                                                                    
   begin                                                                                                                            
      mySect := 'Man - Begin';                                                                                                      
                                                                                                                                    
      EMAIL_FLAG := 'N';                                                                                                            
      EMAIL_ADDR := null;                                                                                                           
                                                                                                                                    
		mySect := 'Man - Plant Type';                                                                                                     
		select nvl(PLANT_TYPE,'I')                                                                                                        
		into   myPlantType                                                                                                                
		from   DEX_CONTROL;                                                                                                               
                                                                                                                                    
      mySect := 'Man - Sales Fee';                                                                                                  
                                                                                                                                    
      myRetMesg := SALES_FEES ( myOrder,myTranID );                                                                                 
                                                                                                                                    
      if myRetMesg is not null then                                                                                                 
         return;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Man - Status';                                                                                                     
                                                                                                                                    
      begin                                                                                                                         
 			select STATUS                                                                                                                   
         into   myStatus                                                                                                            
         from  (select 'S'  STATUS                                                                                                  
		          from   DEX_ORDERS ord                                                                                                   
		                ,DEX_LINES lne                                                                                                    
		                ,DEX_SERIALS ser                                                                                                  
		          where  ser.ORDERNO  = lne.ORDERNO                                                                                       
		          and    ser.ITEM     = lne.ITEM                                                                                          
		          and    ser.ORDERNO  = ord.ORDERNO                                                                                       
		          and    ser.ORDERNO  = myOrder                                                                                           
		          and    ser.LOCATION = 'PKD'                                                                                             
		          and    ser.TRAN_ID  = myTranID                                                                                          
		          and   (exists                                                                                                           
		                (select '*'                                                                                                       
		                 from   DEX_LSM_CUSTOMER dlc                                                                                      
		                 where  dlc.CUSTOMER_ID = ord.CUSTOMER_ID                                                                         
		                 and    dlc.LOCN        = 'SHC')                                                                                  
		            or   exists                                                                                                           
		                (select '*'                                                                                                       
		                 from   DEX_LSM_ITEM dli                                                                                          
		                 where  dli.CUSTOMER_ID       = ord.CUSTOMER_ID                                                                   
		                 and    dli.INVENTORY_ITEM_ID = lne.INV                                                                           
ENTORY_ITEM_ID                                                                                                                      
		                 and    dli.LOCN              = 'SHC'))                                                                           
		          union                                                                                                                   
		          select 'S' STATUS                                                                                                       
		          from    DEX_ORDERS ord                                                                                                  
		                 ,DEX_LINES lne                                                                                                   
		                 ,DEX_SHIP_LINES_INTERFACE ser                                                                                    
		          where  ser.ORDERNO  = lne.ORDERNO                                                                                       
		          and    ser.ITEM     = lne.ITEM                                                                                          
		          and    lne.ORDERNO  = ord.ORDERNO                                                                                       
		          and    ser.SHIP_ID  = myShipID                                                                                          
		          and   (exists                                                                                                           
		                (select '*'                                                                                                       
		                 from   DEX_LSM_CUSTOMER dlc                                                                                      
		                 where  dlc.CUSTOMER_ID = ord.CUST                                                                                
OMER_ID                                                                                                                             
		                 and    dlc.LOCN        = 'SHC')                                                                                  
		            or   exists                                                                                                           
		                (select '*'                                                                                                       
		                 from   DEX_LSM_ITEM dli                                                                                          
		                 where  dli.CUSTOMER_ID       = ord.CUSTOMER_ID                                                                   
		                 and    dli.INVENTORY_ITEM_ID = lne.INVENTOR                                                                      
Y_ITEM_ID                                                                                                                           
		                 and    dli.LOCN              = 'SHC'))                                                                           
		          )                                                                                                                       
         where  rownum < 2;                                                                                                         
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myStatus := 'O';                                                                                                        
      end;                                                                                                                          
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Man - Load Data';                                                                                                  
                                                                                                                                    
		select CUST                                                                                                                       
				,CUST_ID                                                                                                                        
				,ORG_ID                                                                                                                         
				,RESIDENTIAL_FLAG                                                                                                               
				,SPECIAL_HANDLING                                                                                                               
				,COUNTRY                                                                                                                        
				,FREIGHT_QUOTE                                                                                                                  
				,EMAIL                                                                                                                          
				,ORDTYPE                                                                                                                        
				,max(BOX_DIM)                                                                                                                   
				,min(SHIPTO)                                                                                                                    
				,sum(PRICE)                                                                                                                     
				,sum(QTYORG)                                                                                                                    
				,max(LICENSE_PLATE_ID)                                                                                                          
				,max(INT_SHIP_FLAG)                                                                                                             
				,max(DST_PLANT_ID) DST_PLANT_ID                                                                                                 
		into   myCust                                                                                                                     
            ,myCustID                                                                                                               
            ,myOrgID                                                                                                                
            ,myResFlag                                                                                                              
            ,mySpclHand                                                                                                             
            ,myCountry                                                                                                              
            ,myFreight                                                                                                              
            ,myEMail                                                                                                                
            ,myOrdType                                                                                                              
            ,myDimension                                                                                                            
            ,myShipto                                                                                                               
            ,myAmount                                                                                                               
            ,myOrderQty                                                                                                             
            ,myLicPlateID                                                                                                           
            ,myIntShipFlag                                                                                                          
            ,myDstPlantID                                                                                                           
      from (select decode(H.CUST,myBuyCust,CUST_EXCH                                                                                
ANGE,CUST)                      CUST                                                                                                
      		      ,decode(H.CUST,myBuyCust,C.CUSTOMER_ID,H.CUSTOMER_ID)                                                                 
             CUST_ID                                                                                                                
      		      ,decode(H.CUST,myBuyCust,F_DEXB_ORG_ID ( H.                                                                           
ORDERNO ),H.ORG_ID)    ORG_ID                                                                                                       
      		      ,nvl(H.RESIDENTIAL_FLAG,'N') RESIDENTIAL_FLAG                                                                         
      		      ,nvl(H.SPECIAL_HANDLING,0) SPECIAL_HANDLING                                                                           
      		      ,H.COUNTRY                                                                                                            
      		      ,H.FREIGHT_QUOTE                                                                                                      
      		      ,H.EMAIL                                                                                                              
      		      ,H.ORDTYPE                                                                                                            
      		      ,max(S.BOX_DIM)                     BOX_DIM                                                                           
      		      ,min(SHIPTO)                        SHIP                                                                              
TO                                                                                                                                  
      		      ,sum(decode(H.COD,'Y',D.PRICE,0))   PRICE                                                                             
      		      ,sum(decode(PART,XXDEX_DEFAULTS_F ( 'ITEM_TAX' ),0,D.QTYO                                                             
RG)) QTYORG                                                                                                                         
      		      ,max(LICENSE_PLATE_ID) LICENSE_PLATE_ID                                                                               
      		      ,max(decode(nvl(D.REPAIR_PLANT_ID,H.PLANT_ID),H.PL                                                                    
ANT_ID,null,'Y')) INT_SHIP_FLAG                                                                                                     
      		      ,max(nvl(D.REPAIR_PLANT_ID,H.PLANT_ID)) DST_PLANT_ID                                                                  
      		from   DEX_SERIALS S                                                                                                        
      		      ,DEX_LINES D                                                                                                          
      		      ,DEX_ORDERS H                                                                                                         
      		      ,XXDEX_CUSTOMERS_DEX_V C                                                                                              
      		where  S.ORDERNO         = D.ORDERNO                                                                                        
      		and    S.ITEM            = D.ITEM                                                                                           
      		and    S.ORDERNO         = H.ORDERNO                                                                                        
      		and    C.CUSTOMER_NUMBER = decode(H.CUST,myBuyCust,CUS                                                                      
T_EXCHANGE,CUST)                                                                                                                    
      		and    S.ORDERNO         = myOrder                                                                                          
      		and    S.LOCATION        = 'PKD'                                                                                            
      		and    S.SHIP_ID         = myShipID                                                                                         
      		group by decode(H.CUST,myBuyCust,CUST_EXCHANGE,CUST)                                                                        
      		      ,decode(H.CUST,myBuyCust,C.CUSTOMER_ID,H                                                                              
.CUSTOMER_ID)                                                                                                                       
      		      ,decode(H.CUST,myBuyCust,F_DEXB_ORG_ID ( H.ORDERNO                                                                    
 ),H.ORG_ID)                                                                                                                        
      		      ,nvl(H.RESIDENTIAL_FLAG,'N')                                                                                          
      		      ,nvl(H.SPECIAL_HANDLING,0)                                                                                            
      		      ,H.COUNTRY                                                                                                            
      		      ,H.FREIGHT_QUOTE                                                                                                      
      		      ,H.EMAIL                                                                                                              
      		      ,H.ORDTYPE                                                                                                            
      		union all                                                                                                                   
      		select decode(H.CUST,myBuyCust,CUST_EXCHANGE,CUST)                                                                          
             CUST                                                                                                                   
      		      ,decode(H.CUST,myBuyCust,C.CUSTOMER_ID,H.CUSTO                                                                        
MER_ID)             CUST_ID                                                                                                         
      		      ,decode(H.CUST,myBuyCust,F_DEXB_ORG_ID ( H.ORDERNO ),H.ORG_ID)                                                        
    ORG_ID                                                                                                                          
      		      ,nvl(H.RESIDENTIAL_FLAG,'N') RESIDENTIAL_FLAG                                                                         
      		      ,nvl(H.SPECIAL_HANDLING,0) SPECIAL_HANDLING                                                                           
      		      ,H.COUNTRY                                                                                                            
      		      ,H.FREIGHT_QUOTE                                                                                                      
      		      ,H.EMAIL                                                                                                              
      		      ,H.ORDTYPE                                                                                                            
      		      ,max(S.BOX_DIM)                                                                                                       
   BOX_DIM                                                                                                                          
      		      ,min(SHIPTO)                              SHIPTO                                                                      
      		      ,sum(decode(H.COD,'Y',S.QTY * D.PRICE,0))                                                                             
PRICE                                                                                                                               
      		      ,sum(decode(PART,XXDEX_DEFAULTS_F ( 'ITEM_TAX' ),0,QTYORG)                                                            
)         QTYORG                                                                                                                    
      		      ,to_number(null)  LICENSE_PLATE_ID                                                                                    
      		      ,max(decode(nvl(D.REPAIR_PLANT_ID,H.PLANT_ID),H.PL                                                                    
ANT_ID,null,'Y')) INT_SHIP_FLAG                                                                                                     
      		      ,max(nvl(D.REPAIR_PLANT_ID,H.PLANT_ID)) DST_PLANT_ID                                                                  
      		from   DEX_SHIP_LINES_INTERFACE S                                                                                           
      		      ,DEX_LINES D                                                                                                          
      		      ,DEX_ORDERS H                                                                                                         
      		      ,XXDEX_CUSTOMERS_DEX_V C                                                                                              
      		where  S.ORDERNO         = D.ORDERNO                                                                                        
      		and    S.ITEM            = D.ITEM                                                                                           
      		and    S.ORDERNO         = H.ORDERNO                                                                                        
      		and    C.CUSTOMER_NUMBER = decode(H.CUST,myBuyCust,CUST_EXCHANGE,CU                                                         
ST)                                                                                                                                 
      		and    S.ORDERNO         = myOrder                                                                                          
      		and    S.SHIP_ID         = myShipID                                                                                         
      		group by decode(H.CUST,myBuyCust,CUST_EXCHANGE,CUST)                                                                        
      		      ,decode(H.CUST,myBuyCust,C.CUSTOMER_ID,H.C                                                                            
USTOMER_ID)                                                                                                                         
      		      ,decode(H.CUST,myBuyCust,F_DEXB_ORG_ID ( H.ORDERNO )                                                                  
,H.ORG_ID)                                                                                                                          
      		      ,nvl(H.RESIDENTIAL_FLAG,'N')                                                                                          
      		      ,nvl(H.SPECIAL_HANDLING,0)                                                                                            
      		      ,H.COUNTRY                                                                                                            
      		      ,H.FREIGHT_QUOTE                                                                                                      
      		      ,H.EMAIL                                                                                                              
      		      ,H.ORDTYPE                                                                                                            
      		)                                                                                                                           
      group by CUST                                                                                                                 
				,CUST_ID                                                                                                                        
				,ORG_ID                                                                                                                         
				,RESIDENTIAL_FLAG                                                                                                               
				,SPECIAL_HANDLING                                                                                                               
				,COUNTRY                                                                                                                        
				,FREIGHT_QUOTE                                                                                                                  
				,EMAIL                                                                                                                          
				,ORDTYPE;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Man - Count';                                                                                                      
                                                                                                                                    
      -- Feb 2007 - Order Qty in query above overstated because query                                                               
ing down to Serial table.                                                                                                           
      select sum(QTYORG)                                                                                                            
      into   myOrderQty                                                                                                             
      from   DEX_LINES                                                                                                              
      where  ORDERNO = myOrder                                                                                                      
      and    PART  not in (XXDEX_DEFAULTS_F ( 'ITEM_T                                                                               
AX' ),XXDEX_DEFAULTS_F ( 'ITEM_SERVICE_FEE' ),XXDEX_                                                                                
DEFAULTS_F ( 'ITEM_PAYPAL_FEE' ),XXDEX_DEFAULTS_F (                                                                                 
'ITEM_SHIP_INSURE_FEE' ));                                                                                                          
                                                                                                                                    
      select sum(QTY)                                                                                                               
      into   myShipCount                                                                                                            
      from (select count(*) QTY                                                                                                     
      		from   DEX_SERIALS                                                                                                          
      		where  LOCATION    = 'PKD'                                                                                                  
      		and    SHIP_ID     = myShipID                                                                                               
      		union all                                                                                                                   
      		select sum(QTY) QTY                                                                                                         
      		from   DEX_SHIP_LINES_INTERFACE                                                                                             
      		where  SHIP_ID     = myShipID                                                                                               
      	  );                                                                                                                         
                                                                                                                                    
		mySect := 'Man - Prorate Freight Quote';                                                                                          
      myQuote := (myFreight / myOrderQty) * myShipCount                                                                             
;                                                                                                                                   
                                                                                                                                    
      if myEMail is not null then                                                                                                   
         EMAIL_FLAG := 'Y';                                                                                                         
         EMAIL_ADDR := myEMail;                                                                                                     
                                                                                                                                    
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'Man - Load EMail';                                                                                              
                                                                                                                                    
         EMAIL ( myCust,myShipto,myOrgID );                                                                                         
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Man - Load Scrap';                                                                                                 
                                                                                                                                    
      select SCRAP                                                                                                                  
      into   myScrap                                                                                                                
      from   PICKLIST                                                                                                               
      where  PICKLIST_ID = myPickID;                                                                                                
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Man - Special Handling';                                                                                           
                                                                                                                                    
      if mySpclHand > 0 then                                                                                                        
         if F_DEX_BITAND ( mySpclHand,32 ) > 0 then                                                                                 
            myRetSvcSkip := 1;                                                                                                      
            mySpclHand := mySpclHand - 16;                                                                                          
         else                                                                                                                       
            myRetSvcSkip:=0;                                                                                                        
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,16 ) > 0 then                                                                                 
            myAddlHand := 1;                                                                                                        
            mySpclHand := mySpclHand - 16;                                                                                          
         else                                                                                                                       
            myAddlHand:=0;                                                                                                          
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,8 ) > 0 then                                                                                  
            myOversize := 1;                                                                                                        
            mySpclHand := mySpclHand - 8;                                                                                           
         else                                                                                                                       
            myOversize:= 0;                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,4 ) > 0 then                                                                                  
            mySigReqd := 1;                                                                                                         
            mySpclHand := mySpclHand - 4;                                                                                           
         else                                                                                                                       
            mySigReqd := 0;                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,2 ) > 0 then                                                                                  
            myDelvConf := 1;                                                                                                        
            mySpclHand := mySpclHand - 2;                                                                                           
         else                                                                                                                       
            myDelvConf :=0;                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,1 ) > 0 then                                                                                  
            mySatDevl :=1;                                                                                                          
            mySpclHand := mySpclHand - 1;                                                                                           
         else                                                                                                                       
            mySatDevl := 0;                                                                                                         
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
		log;                                                                                                                              
		mySect := 'Man - Ship Adddr';                                                                                                     
		select SHIP_NAME                                                                                                                  
				,SHIP_ST1                                                                                                                       
				,SHIP_ST2                                                                                                                       
				,SHIP_CITY                                                                                                                      
				,SHIP_STATE                                                                                                                     
				,SHIP_ZIP                                                                                                                       
				,COUNTRY                                                                                                                        
				,PROVINCE                                                                                                                       
				,SHIP_ATTN                                                                                                                      
   	into   myShipName                                                                                                               
   			,myStreet1                                                                                                                    
   			,myStreet2                                                                                                                    
   			,myCity                                                                                                                       
   			,myState                                                                                                                      
   			,myZip                                                                                                                        
   			,myCountry                                                                                                                    
   			,myProvince                                                                                                                   
   			,myShipAttn                                                                                                                   
		from   DEX_ORDERS                                                                                                                 
		where  ORDERNO = myOrder;                                                                                                         
                                                                                                                                    
		mySect := 'Man - Int Ship Addr';                                                                                                  
		DBMS_OUTPUT.PUT_LINE('Int Ship Flag: ' || myIntShipFlag                                                                           
|| ' Plant Type: ' || myPlantType);                                                                                                 
		if myIntShipFlag = 'Y' and myPlantType = 'IO' then                                                                                
			begin                                                                                                                            
		   	select DESCRIPTION                                                                                                            
		   			,ADDRESS_LINE_1                                                                                                             
		   			,ADDRESS_LINE_2                                                                                                             
		   			,TOWN_OR_CITY                                                                                                               
		   			,nvl(POSTAL_CODE,0)                                                                                                         
		   			,COUNTRY                                                                                                                    
		   			,REGION_1                                                                                                                   
		   	into   myShipName                                                                                                             
		   			,myStreet1                                                                                                                  
		   			,myStreet2                                                                                                                  
		   			,myCity                                                                                                                     
		   			,myZip                                                                                                                      
		   			,myCountry                                                                                                                  
		   			,myProvince                                                                                                                 
		   	from   HR_LOCATIONS_ALL hrl                                                                                                   
		   			,HR_ORGANIZATION_UNITS hro                                                                                                  
		   	where  hro.ORGANIZATION_ID = myDstPlantID                                                                                     
		   	and    hro.LOCATION_ID = hrl.LOCATION_ID;                                                                                     
                                                                                                                                    
		   	dbms_output.put_line('Address found: ' || myShipName);                                                                        
		   	if myCountry = 'US' then                                                                                                      
		   		myState := substr(myProvince,1,2);                                                                                           
		   	end if;                                                                                                                       
			exception                                                                                                                        
				when NO_DATA_FOUND then                                                                                                         
					null;                                                                                                                          
			end;                                                                                                                             
		end if;                                                                                                                           
                                                                                                                                    
      mySect := 'Man - Insert';                                                                                                     
                                                                                                                                    
      insert into DEX_SHIP_INTERFACE                                                                                                
     (SHIP_ID,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,CREATE                                                                 
D_BY                                                                                                                                
     ,STATUS,SHIP_TYPE,PLANT,SEGMENT1,SEGMENT2,SHIP_NAME,COUNTRY,CONSIGNE                                                           
E_PHONE                                                                                                                             
     ,ADDRESS1,ADDRESS2,ADDRESS3,ADDRESS4,CITY,STATE,POSTAL_CODE,PROVI                                                              
NCE,COUNTY                                                                                                                          
     ,SHIP_METHOD_CODE,WEIGHT,WEIGHT_UNIT_CODE,COD,COD_AMOUNT,COD_P                                                                 
AYMENT_TYPE,COD_COMMENT                                                                                                             
     ,PICKLIST_ID,TRAN_ID,PACKAGE_TYPE,FREIGHT_QUOTE,E                                                                              
MAIL_NOTIFY_FLAG,EMAIL_ADDRESS                                                                                                      
     ,RESIDENTIAL,SATURDAY_DELIVERY,SATURDAY                                                                                        
     ,DELIVERY_CONF,SIGNATURE_REQUIRED,OVERSIZE,ADDTIO                                                                              
NAL_HANDLING                                                                                                                        
     ,DIMENSION,NEW_FLAG,LICENSE_PLATE,INT_SHIP_FLAG)                                                                               
      select myShipID,SYSDATE,myUserID,SYSDATE,myUserID                                                                             
            ,myStatus,'M',L.PLANT,myOrder,myCust,myShipName                                                                         
,myCountry,H.TELEPHONE                                                                                                              
            ,myStreet1,myStreet2,null,myShipAttn,myCity                                                                             
,myState,myZip                                                                                                                      
            ,null,null,H.SHIP_VIA,myWeight,'LB',H.COD,myAmount,                                                                     
C.COD_PAYMENT_TYPE,C.COD_COMMENT                                                                                                    
            ,myPickID,myTranID,'CUSTOM',myQuote,EMAIL_FLAG,EMAIL_ADDR                                                               
            ,decode(NVL(myResFlag,'N'),'Y',1,0),decod                                                                               
e(mySatDevl,1,'Y','N'),mySatDevl                                                                                                    
            ,myDelvConf, mySigReqd, myOversize, myAddlHand                                                                          
            ,myDimension,'Y',myLicPlateID,myIntShipFlag                                                                             
      from   DEX_ORDERS H                                                                                                           
            ,DEX_CUSTOMER_DATA C                                                                                                    
            ,PICKLIST L                                                                                                             
      where  C.CUSTOMER_ID = myCustID                                                                                               
      and    C.ORG_ID      = myOrgID                                                                                                
      and    H.ORDERNO     = myOrder                                                                                                
      and    L.PICKLIST_ID = myPickID;                                                                                              
                                                                                                                                    
      if myScrap != 'N' or  myScrap IN ( 'B','W')  then                                                                             
         log;                                                                                                                       
         mySect := 'Man - Address';                                                                                                 
                                                                                                                                    
         ADDRESS ( myShipID,myCust,myScrap,null,myOrgID                                                                             
);                                                                                                                                  
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Man - Bulk Rtrn Service';                                                                                          
                                                                                                                                    
      if myOrdType = 'S' and myRetSvcSkip!=1 then                                                                                   
         BULK_RETURN_SERVICE ( myShipID,myOrder,myTranID,my                                                                         
UserID );                                                                                                                           
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Man - Close Picklist';                                                                                             
                                                                                                                                    
      K_PICKLIST.CLOSE ( myPickID,myOrder );                                                                                        
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Man - Complete';                                                                                                   
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := 'Order ' || myOrder || ' - ' || mySect || ' ' ||                                                              
 SQLERRM;                                                                                                                           
   end MANIFEST;                                                                                                                    
                                                                                                                                    
   /************************************************************************                                                        
**************************************/                                                                                             
                                                                                                                                    
   procedure NONSERL (                                                                                                              
                      myRetMesg  out  varchar2                                                                                      
                     ,myPickID        number                                                                                        
                     ,myEmp           varchar2                                                                                      
                     ,myOrder         varchar2                                                                                      
                     ,myTranID        number                                                                                        
                     ,myShipID        number                                                                                        
                     ,myWeight        number                                                                                        
                   ) is                                                                                                             
      myUserID      pls_integer := F_DEX_USER_ID;                                                                                   
                                                                                                                                    
      myCustID      pls_integer;                                                                                                    
      myOrgID       pls_integer;                                                                                                    
                                                                                                                                    
      myOrderQty    number;                                                                                                         
      myQuote       number;                                                                                                         
      myShipCount   number;                                                                                                         
                                                                                                                                    
      myAmount      number;                                                                                                         
      myFreight     number;                                                                                                         
      myShipto      number;                                                                                                         
                                                                                                                                    
      myScrap       varchar2(1);                                                                                                    
      myCust        DEX_ORDERS.CUST%type;                                                                                           
      mySatDel      varchar2(1);                                                                                                    
      myOrdType     varchar2(1);                                                                                                    
                                                                                                                                    
      mySpclHand    pls_integer := 0;                                                                                               
      mySatDevl     pls_integer := 0;                                                                                               
      myDelvConf    pls_integer := 0;                                                                                               
      mySigReqd     pls_integer := 0;                                                                                               
      myOversize    pls_integer := 0;                                                                                               
      myAddlHand    pls_integer := 0;                                                                                               
      myRetSvcSkip  pls_integer := 0;                                                                                               
                                                                                                                                    
      myCountry     varchar2(2);                                                                                                    
      myResFlag     varchar2(1);                                                                                                    
      myDimension   varchar2(20);                                                                                                   
      myEMail       varchar2(100);                                                                                                  
                                                                                                                                    
      myStatus      varchar2(1) := 'O';                                                                                             
                                                                                                                                    
		myBuyCust	DEX_ORDERS.CUST%type := nvl(XXDEX_DEFAULTS_F ('INTERNAL_C                                                               
UST_BUY'),'x');                                                                                                                     
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select ITEM                                                                                                                
               ,QTY                                                                                                                 
         from   DEX_SHIP_LINES_INTERFACE                                                                                            
         where  ORDERNO = myOrder                                                                                                   
         and    SHIP_ID = myShipID                                                                                                  
         and    QTY     > 0;                                                                                                        
                                                                                                                                    
   begin                                                                                                                            
      mySect := 'NonSerl - Begin';                                                                                                  
                                                                                                                                    
      EMAIL_FLAG := 'N';                                                                                                            
      EMAIL_ADDR := null;                                                                                                           
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Status';                                                                                                 
                                                                                                                                    
      begin                                                                                                                         
         select 'S'                                                                                                                 
         into   myStatus                                                                                                            
         from   DEX_ORDERS ord                                                                                                      
               ,DEX_LINES lne                                                                                                       
         where  lne.ORDERNO = ord.ORDERNO                                                                                           
         and    lne.ORDERNO = myOrder                                                                                               
         and    lne.QTYSCH  > 0                                                                                                     
         and   (exists                                                                                                              
               (select '*'                                                                                                          
                from   DEX_LSM_CUSTOMER dlc                                                                                         
                where  dlc.CUSTOMER_ID = ord.CUSTOMER_ID                                                                            
                and    dlc.LOCN        = 'SHC')                                                                                     
           or   exists                                                                                                              
               (select '*'                                                                                                          
                from   DEX_LSM_ITEM dli                                                                                             
                where  dli.CUSTOMER_ID       = ord.CUST                                                                             
OMER_ID                                                                                                                             
                and    dli.INVENTORY_ITEM_ID = lne.INVENTORY_ITEM_ID                                                                
                and    dli.LOCN              = 'SHC')                                                                               
)                                                                                                                                   
         and    rownum < 2;                                                                                                         
                                                                                                                                    
      exception                                                                                                                     
         when NO_DATA_FOUND then                                                                                                    
            myStatus := 'O';                                                                                                        
      end;                                                                                                                          
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Load Data';                                                                                              
                                                                                                                                    
      select decode(H.CUST,myBuyCust,CUST_EXCHANGE,CUST)                                                                            
                CUST                                                                                                                
            ,decode(H.CUST,myBuyCust,C.CUSTOMER_ID,H.CUST                                                                           
OMER_ID)             CUST_ID                                                                                                        
            ,decode(H.CUST,myBuyCust,F_DEXB_ORG_ID ( H.ORDERNO ),H.ORG_ID)                                                          
   ORG_ID                                                                                                                           
            ,nvl(H.RESIDENTIAL_FLAG,'N') RESIDENTIAL_FLAG                                                                           
            ,nvl(H.SPECIAL_HANDLING,0) SPECIAL_HANDLING                                                                             
            ,H.COUNTRY                                                                                                              
            ,H.FREIGHT_QUOTE                                                                                                        
            ,H.EMAIL                                                                                                                
            ,H.ORDTYPE                                                                                                              
            ,max(D.INFO4)                                                                                                           
            ,min(H.SHIPTO)                                                                                                          
            ,sum(D.QTYSCH * nvl(D.PRICE,0))        AMOUNT                                                                           
            ,sum(decode(PART,XXDEX_DEFAULTS_F ( 'ITEM_TAX'                                                                          
),0,D.QTYORG))    QTYORG                                                                                                            
      into   myCust                                                                                                                 
            ,myCustID                                                                                                               
            ,myOrgID                                                                                                                
            ,myResFlag                                                                                                              
            ,mySpclHand                                                                                                             
            ,myCountry                                                                                                              
            ,myFreight                                                                                                              
            ,myEMail                                                                                                                
            ,myOrdType                                                                                                              
            ,myDimension                                                                                                            
            ,myShipto                                                                                                               
            ,myAmount                                                                                                               
            ,myOrderQty                                                                                                             
      from   V_DEX_CUSTOMER_ACCTS C                                                                                                 
            ,DEX_ORDERS H                                                                                                           
            ,DEX_LINES D                                                                                                            
            ,DEX_SHIP_LINES_INTERFACE sli                                                                                           
      where  sli.ORDERNO       = D.ORDERNO                                                                                          
      and    sli.ITEM          = D.ITEM                                                                                             
      and    H.ORDERNO         = D.ORDERNO                                                                                          
      and    C.CUSTOMER_NUMBER = decode(H.CUST,myBuyCust,CUST_EXCHANGE,CUST)                                                        
      and    H.ORDERNO         = myOrder                                                                                            
      and    sli.SHIP_ID       = myShipID                                                                                           
      group by decode(H.CUST,myBuyCust,CUST_EXCHANGE,CUST)                                                                          
            ,decode(H.CUST,myBuyCust,C.CUSTOMER_ID,H.CUSTOMER_ID)                                                                   
            ,decode(H.CUST,myBuyCust,F_DEXB_ORG_ID (                                                                                
 H.ORDERNO ),H.ORG_ID)                                                                                                              
            ,nvl(H.RESIDENTIAL_FLAG,'N')                                                                                            
            ,nvl(H.SPECIAL_HANDLING,0)                                                                                              
            ,H.COUNTRY                                                                                                              
            ,H.FREIGHT_QUOTE                                                                                                        
            ,H.EMAIL                                                                                                                
            ,H.ORDTYPE;                                                                                                             
                                                                                                                                    
		/* QTYINT is updated from form. This is not needed.                                                                               
      log;                                                                                                                          
      mySect := 'NonSerl - c1 loop';                                                                                                
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         log;                                                                                                                       
         mySect := 'NonSerl - Update Lines';                                                                                        
                                                                                                                                    
         update DEX_LINES set                                                                                                       
         QTYCUT = nvl(QTYCUT,0) + c1r.QTY                                                                                           
         where ORDERNO = myOrder                                                                                                    
         and   ITEM    = c1r.ITEM;                                                                                                  
      end loop;                                                                                                                     
		*/                                                                                                                                
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Count';                                                                                                  
                                                                                                                                    
      -- Feb 2007 - Order Qty in query above oversta                                                                                
ted because querying down to Serial table.                                                                                          
      select sum(QTYORG)                                                                                                            
      into   myOrderQty                                                                                                             
      from   DEX_LINES                                                                                                              
      where  ORDERNO = myOrder                                                                                                      
      and    PART not in (XXDEX_DEFAULTS_F ( 'ITEM_TAX' ),XXDE                                                                      
X_DEFAULTS_F ( 'ITEM_SERVICE_FEE' ),XXDEX_DEFAULTS_F                                                                                
 ( 'ITEM_PAYPAL_FEE' ),XXDEX_DEFAULTS_F ( 'ITEM_SHIP                                                                                
_INSURE_FEE' ));                                                                                                                    
                                                                                                                                    
      select sum(QTY)                                                                                                               
      into   myShipCount                                                                                                            
      from   DEX_SHIP_LINES_INTERFACE                                                                                               
      where  SHIP_ID = myShipID;                                                                                                    
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Update Picklist';                                                                                        
                                                                                                                                    
      update PICKLIST set                                                                                                           
      QUANTITY = myShipCount                                                                                                        
      where PICKLIST_ID = myPickID;                                                                                                 
                                                                                                                                    
      myQuote := (myFreight / myOrderQty) * myShipCo                                                                                
unt;                                                                                                                                
                                                                                                                                    
      if myEMail is not null then                                                                                                   
         EMAIL_FLAG := 'Y';                                                                                                         
         EMAIL_ADDR := myEMail;                                                                                                     
                                                                                                                                    
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'NonSerl - Load EMail';                                                                                          
                                                                                                                                    
         EMAIL ( myCust,myShipto,myOrgID );                                                                                         
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Load Scrap';                                                                                             
                                                                                                                                    
      select SCRAP                                                                                                                  
      into   myScrap                                                                                                                
      from   PICKLIST                                                                                                               
      where  PICKLIST_ID = myPickID;                                                                                                
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Special Handling';                                                                                       
                                                                                                                                    
      if mySpclHand > 0 then                                                                                                        
         if F_DEX_BITAND ( mySpclHand,32 ) > 0 then                                                                                 
            myRetSvcSkip := 1;                                                                                                      
            mySpclHand := mySpclHand - 16;                                                                                          
         else                                                                                                                       
            myRetSvcSkip:=0;                                                                                                        
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,16 ) > 0 then                                                                                 
            myAddlHand := 1;                                                                                                        
            mySpclHand := mySpclHand - 16;                                                                                          
         else                                                                                                                       
            myAddlHand:=0;                                                                                                          
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,8 ) > 0 then                                                                                  
            myOversize := 1;                                                                                                        
            mySpclHand := mySpclHand - 8;                                                                                           
         else                                                                                                                       
            myOversize:= 0;                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,4 ) > 0 then                                                                                  
            mySigReqd := 1;                                                                                                         
            mySpclHand := mySpclHand - 4;                                                                                           
         else                                                                                                                       
            mySigReqd := 0;                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,2 ) > 0 then                                                                                  
            myDelvConf := 1;                                                                                                        
            mySpclHand := mySpclHand - 2;                                                                                           
         else                                                                                                                       
            myDelvConf :=0;                                                                                                         
         end if;                                                                                                                    
                                                                                                                                    
         if F_DEX_BITAND ( mySpclHand,1 ) > 0 then                                                                                  
            mySatDevl :=1;                                                                                                          
            mySpclHand := mySpclHand - 1;                                                                                           
         else                                                                                                                       
            mySatDevl := 0;                                                                                                         
         end if;                                                                                                                    
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Insert';                                                                                                 
                                                                                                                                    
      insert into DEX_SHIP_INTERFACE                                                                                                
     (SHIP_ID,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATIO                                                                              
N_DATE,CREATED_BY                                                                                                                   
     ,STATUS,SHIP_TYPE,PLANT,SEGMENT1,SEGMENT2,SEGMENT3,SHIP                                                                        
_NAME,COUNTRY,CONSIGNEE_PHONE                                                                                                       
     ,ADDRESS1,ADDRESS2,ADDRESS3,ADDRESS4,CITY,STATE,POSTAL_CODE,PROVINCE,                                                          
COUNTY                                                                                                                              
     ,SHIP_METHOD_CODE,WEIGHT,WEIGHT_UNIT_CODE,COD,COD_AMOUNT,COD_PAYME                                                             
NT_TYPE,COD_COMMENT                                                                                                                 
     ,PICKLIST_ID,TRAN_ID,PACKAGE_TYPE,FREIGHT_QUOTE,EMAIL                                                                          
_NOTIFY_FLAG,EMAIL_ADDRESS                                                                                                          
     ,RESIDENTIAL,SATURDAY_DELIVERY,SATURDAY                                                                                        
     ,DELIVERY_CONF,SIGNATURE_REQUIRED,OVERSIZE,ADDTIONAL_                                                                          
HANDLING                                                                                                                            
     ,DIMENSION,NEW_FLAG)                                                                                                           
      select myShipID,SYSDATE,myUserID,SYSDATE,myUserID                                                                             
            ,myStatus,'M',L.PLANT,myOrder,myCust,'N',H.SHIP_NAME,                                                                   
H.COUNTRY,H.TELEPHONE                                                                                                               
            ,H.SHIP_ST1,H.SHIP_ST2,null,H.SHIP_ATTN,H.SH                                                                            
IP_CITY,H.SHIP_STATE,H.SHIP_ZIP                                                                                                     
            ,null,null,H.SHIP_VIA,myWeight,'LB',H.COD,decode(H.CODE,'Y',                                                            
myAmount),C.COD_PAYMENT_TYPE,C.COD_COMMENT                                                                                          
            ,myPickID,myTranID,'CUSTOM',myQuote,EMAIL_FLAG,EM                                                                       
AIL_ADDR                                                                                                                            
            ,decode(NVL(myResFlag,'N'),'Y',1,0),decode(mySatDevl,1,'Y                                                               
','N'),mySatDevl                                                                                                                    
            ,myDelvConf, mySigReqd,myOversize,myAddlHand                                                                            
            ,myDimension,'Y'                                                                                                        
      from   DEX_ORDERS H                                                                                                           
            ,DEX_CUSTOMER_DATA C                                                                                                    
            ,PICKLIST L                                                                                                             
      where  C.CUSTOMER_ID = myCustID                                                                                               
      and    C.ORG_ID      = myOrgID                                                                                                
      and    H.ORDERNO     = myOrder                                                                                                
      and    L.PICKLIST_ID = myPickID;                                                                                              
                                                                                                                                    
      if myScrap != 'N' or  myScrap IN ( 'B','W')  t                                                                                
hen                                                                                                                                 
         log;                                                                                                                       
         mySect := 'NonSerl - Address';                                                                                             
                                                                                                                                    
         ADDRESS ( myShipID,myCust,myScrap,null,myOrgID );                                                                          
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Close Picklist';                                                                                         
                                                                                                                                    
      K_PICKLIST.CLOSE ( myPickID,myOrder );                                                                                        
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'NonSerl - Complete';                                                                                               
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end NONSERL;                                                                                                                     
                                                                                                                                    
   /*******************************************************************                                                             
*******************************************/                                                                                        
		-- June 2009 (ac) Added logic to handle processing a pick                                                                         
list that has combined Serialized and Non Serialized                                                                                
 items                                                                                                                              
   procedure UNPICK (                                                                                                               
                      myRetMesg  out  varchar2                                                                                      
                     ,myShipID        number                                                                                        
                    ) is                                                                                                            
      myShipType   varchar2(1);                                                                                                     
      myOrdType    varchar2(1);                                                                                                     
      myPickType   varchar2(1);                                                                                                     
      myPlant      DEX_PLANTS.PLANT%type;                                                                                           
      myOrder      varchar2(7);                                                                                                     
      myEmpNo      varchar2(30);                                                                                                    
                                                                                                                                    
      mySubmit     varchar2(1) := 'N';                                                                                              
		myHasSerl	 varchar2(1) := 'N';                                                                                                    
		myHasNonSerl varchar2(1) := 'N';                                                                                                  
                                                                                                                                    
      myUserID     number(15) := F_DEX_USER_ID;                                                                                     
      myPickID     number(15);                                                                                                      
      myOrgID      number(15);                                                                                                      
                                                                                                                                    
      myFYR        number(4);                                                                                                       
      myFMO        number(2);                                                                                                       
      myFWK        number(1);                                                                                                       
                                                                                                                                    
      myAmt        number;                                                                                                          
      myQty        number(10);                                                                                                      
		myRtnShipID	 number;                                                                                                              
		myTLocID		 number;                                                                                                                
		myLoc1		 varchar2(20);                                                                                                            
                                                                                                                                    
      mySAmt       number;                                                                                                          
      mySQty       number(10);                                                                                                      
      myNAmt       number;                                                                                                          
      myNQty       number(10);                                                                                                      
                                                                                                                                    
      cursor c0 is                                                                                                                  
      	select distinct lne.ORDERNO                                                                                                  
      			,decode(ord.ORDTYPE,'S',lne.SERIAL_FLAG, 'Y')                                                                              
SERIAL_FLAG                                                                                                                         
         from   DEX_ORDERS ord                                                                                                      
         		,DEX_LINES lne                                                                                                           
               ,DEX_SERIALS ser                                                                                                     
         where  ser.ORDERNO   = lne.ORDERNO                                                                                         
         and    ser.ITEM      = lne.ITEM                                                                                            
         and    ser.SHIP_ID   = myShipID                                                                                            
         and    ser.LOCATION != 'SHP'                                                                                               
         and    lne.ORDERNO   = ord.ORDERNO                                                                                         
         union all                                                                                                                  
         select distinct lne.ORDERNO                                                                                                
         		,lne.SERIAL_FLAG                                                                                                         
         from   DEX_LINES lne                                                                                                       
         		,DEX_SHIP_LINES_INTERFACE dsl                                                                                            
         where  dsl.SHIP_ID = myShipID                                                                                              
         and    dsl.QTY     > 0                                                                                                     
         and    dsl.ORDERNO = lne.ORDERNO                                                                                           
         and    dsl.ITEM    = lne.ITEM;                                                                                             
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select lne.ORGANIZATION_ID                                                                                                 
               ,lne.INVENTORY_ITEM_ID                                                                                               
               ,lne.SUBINVENTORY_CODE                                                                                               
               ,ser.TRACK                                                                                                           
         from   DEX_LINES lne                                                                                                       
               ,DEX_SERIALS ser                                                                                                     
         where  ser.ORDERNO   = lne.ORDERNO                                                                                         
         and    ser.ITEM      = lne.ITEM                                                                                            
         and    ser.SHIP_ID   = myShipID                                                                                            
         and    ser.LOCATION != 'SHP';                                                                                              
                                                                                                                                    
		cursor c2 is                                                                                                                      
         select lne.ORGANIZATION_ID                                                                                                 
         		,lne.SUBINVENTORY_CODE                                                                                                   
         		,lne.INVENTORY_ITEM_ID                                                                                                   
         		,lne.ITEM                                                                                                                
               ,dsl.QTY                                                                                                             
               ,dsl.LOCATOR_ID                                                                                                      
         from   DEX_LINES lne                                                                                                       
         		,DEX_SHIP_LINES_INTERFACE dsl                                                                                            
         where  dsl.SHIP_ID = myShipID                                                                                              
         and    dsl.QTY     > 0                                                                                                     
         and    dsl.ORDERNO = lne.ORDERNO                                                                                           
         and    dsl.ITEM    = lne.ITEM;                                                                                             
                                                                                                                                    
   begin                                                                                                                            
      myRetMesg := null;                                                                                                            
                                                                                                                                    
      mySect := 'Unpick - Begin';                                                                                                   
      log;                                                                                                                          
      mySect := 'Unpick - Load Data';                                                                                               
                                                                                                                                    
      select SHIP_TYPE                                                                                                              
            ,PICKLIST_ID                                                                                                            
            ,decode(SHIP_TYPE,'M',SEGMENT1,null)                                                                                    
            ,decode(SHIP_TYPE,'M',SEGMENT3,'X')                                                                                     
            ,RETURN_SHIP_ID                                                                                                         
      into   myShipType                                                                                                             
            ,myPickID                                                                                                               
            ,myOrder                                                                                                                
            ,myPickType                                                                                                             
            ,myRtnShipID                                                                                                            
      from   DEX_SHIP_INTERFACE D                                                                                                   
      where  SHIP_ID = myShipID;                                                                                                    
                                                                                                                                    
  	   log;                                                                                                                          
  	   mySect := 'Unpick - Get EmpNo';                                                                                               
                                                                                                                                    
	   begin                                                                                                                           
	      select EMPNO                                                                                                                 
	      into   myEmpNo                                                                                                               
	      from   V_DEX_EMPS vde                                                                                                        
	            ,FND_USER fnd                                                                                                          
	      where  fnd.USER_ID = myUserId                                                                                                
	      and    fnd.EMPLOYEE_ID = vde.PERSON_ID                                                                                       
	      and    rownum < 2;                                                                                                           
                                                                                                                                    
	   exception                                                                                                                       
	      when NO_DATA_FOUND then                                                                                                      
	      	myEmpNo := '0000';                                                                                                          
	   end;                                                                                                                            
                                                                                                                                    
      if myShipType in ('T','M') then                                                                                               
      	for r0 in c0 loop                                                                                                            
				if r0.SERIAL_FLAG = 'Y' then                                                                                                    
					myHasSerl := 'Y';                                                                                                              
				end if;                                                                                                                         
                                                                                                                                    
				if r0.SERIAL_FLAG = 'N' then                                                                                                    
					myHasNonSerl := 'Y';                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				myOrder := r0.ORDERNO;                                                                                                          
			end loop;                                                                                                                        
                                                                                                                                    
       	if myHasSerl = 'Y'  then                                                                                                    
         	log;                                                                                                                      
         	mySect := 'Unpick - Load Order';                                                                                          
                                                                                                                                    
         	select S.ORDERNO                                                                                                          
         	      ,nvl(S.TECH,myEmpNo)                                                                                                
         	      ,H.ORDTYPE                                                                                                          
         	      ,H.PLANT                                                                                                            
         	      ,H.ORG_ID                                                                                                           
         	into   myOrder                                                                                                            
         	      ,myEmpNo                                                                                                            
         	      ,myOrdType                                                                                                          
         	      ,myPlant                                                                                                            
         	      ,myOrgID                                                                                                            
         	from   DEX_SERIALS S                                                                                                      
         	      ,DEX_ORDERS H                                                                                                       
         	where  S.ORDERNO = H.ORDERNO                                                                                              
         	and    S.SHIP_ID = myShipID                                                                                               
         	and    rownum < 2;                                                                                                        
                                                                                                                                    
         	log;                                                                                                                      
         	mySect := 'Unpick - Load Order';                                                                                          
                                                                                                                                    
         	select count('*') * -1                                                                                                    
         	      ,sum(decode(S.SCRAP,'Y',0,D.PRICE)) * -1                                                                            
         	into   mySQty                                                                                                             
         	      ,mySAmt                                                                                                             
         	from   DEX_SERIALS S                                                                                                      
         	      ,DEX_LINES D                                                                                                        
         	where  S.ORDERNO = D.ORDERNO                                                                                              
         	and    S.ITEM    = D.ITEM                                                                                                 
         	and    S.SHIP_ID = myShipID;                                                                                              
                                                                                                                                    
         	if myOrdType = 'S' then                           --                                                                      
Must Be Before Update Serials                                                                                                       
         	   log;                                                                                                                   
         	   mySect := 'Unpick - Update Stock';                                                                                     
                                                                                                                                    
         	   K_DEX_STOCK.SET_MODE ( 2,myShipID );      -- 2                                                                         
-Concurrent                                                                                                                         
                                                                                                                                    
         	   mySubmit := 'Y';                                                                                                       
                                                                                                                                    
         	   -- Must be before update SERIALS                                                                                       
                                                                                                                                    
         	   for c1r in c1 loop                                                                                                     
         	      K_DEX_STOCK.ORG_TBL_LOAD ( c1r.ORGANIZATION                                                                         
_ID );                                                                                                                              
                                                                                                                                    
         	      K_DEX_STOCK.TRANSFER ( c1r.ORGANIZATION_ID,c1r.INVENTO                                                              
RY_ITEM_ID,c1r.SUBINVENTORY_CODE,'99010102',c1r.TRAC                                                                                
K );                                                                                                                                
         	   end loop;                                                                                                              
         	end if;                                                                                                                   
                                                                                                                                    
         	log;                                                                                                                      
         	mySect := 'Unpick - Update Serials';                                                                                      
                                                                                                                                    
	         update DEX_SERIALS set                                                                                                    
	         LOCATION   = decode(myOrdType,'S','BCX','FIN')                                                                            
   -- Use BCX because BCK Errors because of T_SERIAL                                                                                
S lockout                                                                                                                           
	        ,TRACK      = decode(myOrdType,'S',replace(ORDERNO || to_ch                                                                
ar(ITEM,'000') || to_char(UNIQUENO,'0000'),' ',''),T                                                                                
RACK)                                                                                                                               
	        ,DATELOC    = SYSDATE                                                                                                      
	        ,MANIFEST   = null                                                                                                         
	        ,TECH       = myEmpNo                                                                                                      
	        ,TAG_NUMBER = null                                                                                                         
	        ,STORAGE    = decode(myOrdType,'S',null,'99010102                                                                          
')                                                                                                                                  
	         where SHIP_ID  = myShipID                                                                                                 
	         and   LOCATION = 'PKD';                                                                                                   
	     	end if;                                                                                                                      
                                                                                                                                    
  			if myHasNonSerl = 'Y' then                                                                                                     
	         log;                                                                                                                      
	         mySect := 'Unpick - Load Order';                                                                                          
                                                                                                                                    
	         select ORDTYPE                                                                                                            
	               ,PLANT                                                                                                              
	               ,ORG_ID                                                                                                             
	         into   myOrdType                                                                                                          
	               ,myPlant                                                                                                            
	               ,myOrgID                                                                                                            
	         from   DEX_ORDERS                                                                                                         
	         where  ORDERNO = myOrder;                                                                                                 
                                                                                                                                    
	         log;                                                                                                                      
	         mySect := 'Unpick - Qty/Amt';                                                                                             
                                                                                                                                    
	         select sum(sli.QTY * -1)                QTY                                                                               
	               ,sum(sli.QTY * -1 * lne.PRICE)    AMT                                                                               
	         into   myNQty                                                                                                             
	               ,myNAmt                                                                                                             
	         from   DEX_LINES lne                                                                                                      
	               ,DEX_SHIP_LINES_INTERFACE sli                                                                                       
	         where  sli.ORDERNO = lne.ORDERNO                                                                                          
	         and    sli.ITEM    = lne.ITEM                                                                                             
	         and    sli.SHIP_ID = myShipID;                                                                                            
                                                                                                                                    
	         log;                                                                                                                      
	         mySect := 'Unpick - c2 loop';                                                                                             
                                                                                                                                    
	 			if mySubmit = 'N' then                                                                                                         
	            log;                                                                                                                   
   	         mySect := 'Unpick - Update Stock';                                                                                     
                                                                                                                                    
      	      K_DEX_STOCK.SET_MODE ( 2,myShipID );                                                                                   
-- 2-Concurrent                                                                                                                     
                                                                                                                                    
      	      mySubmit := 'Y';                                                                                                       
            end if;                                                                                                                 
                                                                                                                                    
				myTLocID := null;                                                                                                               
                                                                                                                                    
				for c2r in c2 loop                                                                                                              
					log;                                                                                                                           
					mySect := 'Unpick - Update Lines (c2)';                                                                                        
                                                                                                                                    
	            if myTLocID is null then                                                                                               
	            	select SEGMENT1                                                                                                       
      	 			into   myLoc1                                                                                                            
      	 			from   MTL_ITEM_LOCATIONS                                                                                                
      	 			where  INVENTORY_LOCATION_ID = c2r.LOCATOR_ID;                                                                           
                                                                                                                                    
	            	K_DEX_STOCK_LOCATORS.VERIFY ( myTLocID,c2r.                                                                           
ORGANIZATION_ID,c2r.SUBINVENTORY_CODE,myLoc1,XXDEX_D                                                                                
EFAULTS_F ( 'LOCATOR_RC' ),'Y' );                                                                                                   
	            end if;                                                                                                                
                                                                                                                                    
					K_DEX_STOCK.ORG_TBL_LOAD ( c2r.ORGANIZATION_ID );                                                                              
                                                                                                                                    
	            K_DEX_STOCK.TRANSFER (                                                                                                 
	                                   myOrgID   => c2r.ORGANIZ                                                                        
ATION_ID                                                                                                                            
	                                  ,myItemID  => c2r.INVENTORY_ITEM_I                                                               
D                                                                                                                                   
	                                  ,myQty     => c2r.QTY                                                                            
	                                  ,mySubInv  => c2r.SUBINVENTORY_CODE                                                              
	                                  ,myLocID   => c2r                                                                                
.LOCATOR_ID                                                                                                                         
	                                  ,myTSubInv => c2r.SUBINVENTORY_                                                                  
CODE                                                                                                                                
	                                  ,myTLocID  => myTLocID                                                                           
	                                  ,myTOrgID  => c2r.ORGANIZATION_I                                                                 
D                                                                                                                                   
	                                 );                                                                                                
	         end loop;                                                                                                                 
			end if;                                                                                                                          
                                                                                                                                    
         if myOrdType = 'S' then                                                                                                    
            log;                                                                                                                    
            mySect := 'Unpick - Update Resv';                                                                                       
                                                                                                                                    
            update RESERVATIONS set                                                                                                 
            STATUS           = 'P'                                                                                                  
           ,LAST_UPDATE_DATE = SYSDATE                                                                                              
           ,LAST_UPDATED_BY  = myUserID                                                                                             
            where PICKLIST_ID = myPickID;                                                                                           
                                                                                                                                    
            log;                                                                                                                    
            mySect := 'Unpick - Update Locn';                                                                                       
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            LOCATION = 'BCK'                                                                                                        
           ,TYPE_CODE  = null                                                                                                       
           ,SERIAL     = ORIG_SERIAL                                                                                                
            where SHIP_ID  = myShipID                                                                                               
            and   LOCATION = 'BCX';                                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Unpick - Update Picklist';                                                                                      
                                                                                                                                    
         update PICKLIST set                                                                                                        
         STATUS = 'O'                                                                                                               
         where PICKLIST_ID = myPickID;                                                                                              
                                                                                                                                    
         if SQL%rowcount > 0 then                                                                                                   
            log;                                                                                                                    
            mySect := 'Unpick - Cancel Picklist';                                                                                   
                                                                                                                                    
            K_PICKLIST.CANCEL ( myPickID,myOrder );                                                                                 
                                                                                                                                    
            update DEX_SERIALS set                                                                                                  
            SHIP_ID = null                                                                                                          
           ,RETURN_SHIP_ID = null                                                                                                   
            where  SHIP_ID = myShipID;                                                                                              
                                                                                                                                    
         else                                                                                                                       
            if myOrdType = 'S' then                                                                                                 
               log;                                                                                                                 
               mySect := 'Unpick - remove reservation';                                                                             
                                                                                                                                    
               delete RESERVATIONS                                                                                                  
               where  PICKLIST_ID = myPickID;                                                                                       
                                                                                                                                    
               log;                                                                                                                 
               mySect := 'Unpick - update SERIALS (BCK)';                                                                           
                                                                                                                                    
                                                                                                                                    
               update DEX_SERIALS set                                                                                               
               LOCATION    = 'BCK'                                                                                                  
              ,BOX_DIM     = NULL                                                                                                   
              ,DATELOC     = SYSDATE                                                                                                
              ,STORAGE     = null                                                                                                   
              ,TRACK       = replace(ORDERNO || to_cha                                                                              
r(ITEM,'000') || to_char(UNIQUENO,'0000'),' ','')                                                                                   
              ,DATESTS     = SYSDATE                                                                                                
              ,REASON      = null                                                                                                   
              ,PICKLIST_ID = null                                                                                                   
              ,SHIP_ID     = null                                                                                                   
              ,RETURN_SHIP_ID = null                                                                                                
               where SHIP_ID   = myShipID                                                                                           
               and   LOCATION != 'SHP';                                                                                             
                                                                                                                                    
            else                                                                                                                    
               log;                                                                                                                 
               mySect := 'Unpick - update SERIALS';                                                                                 
                                                                                                                                    
               update DEX_SERIALS set                                                                                               
               DATESTS     = SYSDATE                                                                                                
              ,REASON      = null                                                                                                   
              ,PICKLIST_ID = null                                                                                                   
              ,SHIP_ID     = null                                                                                                   
              ,RETURN_SHIP_ID = null                                                                                                
               where SHIP_ID   = myShipID                                                                                           
               and   LOCATION != 'SHP';                                                                                             
            end if;                                                                                                                 
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Unpick - Update Ship Intf';                                                                                     
                                                                                                                                    
         delete DEX_SHIP_INTERFACE                                                                                                  
         where SHIP_ID = myShipID;                                                                                                  
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Unpick - Update Ship Lines Intf';                                                                               
                                                                                                                                    
         delete DEX_SHIP_LINES_INTERFACE                                                                                            
         where SHIP_ID = myShipID;                                                                                                  
                                                                                                                                    
			log;                                                                                                                             
			mySect := 'Unpick - Return Ship ID';                                                                                             
                                                                                                                                    
			if myRtnShipID is not null then                                                                                                  
				delete DEX_SHIP_INTERFACE                                                                                                       
				where  SHIP_ID = myRtnShipID;                                                                                                   
			end if;                                                                                                                          
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Unpick - update CNT_HOUR';                                                                                      
                                                                                                                                    
         myQty := nvl(myNQty,0) + nvl(mySQty,0);                                                                                    
         myAmt := nvl(myNAmt,0) + nvl(mySAmt,0);                                                                                    
                                                                                                                                    
         P_DEX_CNT_HOUR ( 'PKD',myEmpNo,NULL,myPlant,myQty,myAmt,NULL,                                                              
SYSDATE,NULL,'N',null );                                                                                                            
                                                                                                                                    
      else                                                                                                                          
         log;                                                                                                                       
         mySect := 'Unpick - update DEX_SHIP_INTERFAC                                                                               
E';                                                                                                                                 
                                                                                                                                    
         update DEX_SHIP_INTERFACE set                                                                                              
         STATUS           = 'R'                                                                                                     
        ,LAST_UPDATED_BY  = myUserID                                                                                                
        ,LAST_UPDATE_DATE = SYSDATE                                                                                                 
         where SHIP_ID = myShipID;                                                                                                  
      end if;                                                                                                                       
                                                                                                                                    
      if mySubmit = 'Y' then                                                                                                        
         log;                                                                                                                       
         mySect := 'Unpick - Submit';                                                                                               
                                                                                                                                    
         K_DEX_STOCK.PROCESS_TBL ( myUserID => myUserID,m                                                                           
yMOrgID => myOrgID );                                                                                                               
      end if;                                                                                                                       
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Unpick - Complete';                                                                                                
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end UNPICK;                                                                                                                      
                                                                                                                                    
   /***********************************************************                                                                     
***************************************************/                                                                                
                                                                                                                                    
                                                                                                                                    
   procedure SCRAP (                                                                                                                
                     myRetMesg  out  varchar2                                                                                       
                    ,myTranID        number                                                                                         
                    ,myEmpNo         varchar2                                                                                       
                    ,myShipVia       varchar2                                                                                       
                    ,myWaybill       varchar2                                                                                       
                   ) is                                                                                                             
      myUserID      pls_integer := F_DEX_USER_ID ( myEmpNo );                                                                       
      myShipID      pls_integer;                                                                                                    
      mySeg4        varchar2(25);                                                                                                   
                                                                                                                                    
      cursor c1 is                                                                                                                  
         select S.ORDERNO                                                                                                           
               ,H.CUST                                                                                                              
               ,S.PICKLIST_ID                                                                                                       
               ,sum(decode(D.PART,XXDEX_DEFAULTS_F ( 'ITEM_TAX' ),0,D                                                               
.QTYORG))    QTY                                                                                                                    
         from   DEX_SERIALS S                                                                                                       
               ,DEX_LINES D                                                                                                         
               ,DEX_ORDERS H                                                                                                        
         where  S.ORDERNO  = D.ORDERNO                                                                                              
         and    S.ITEM     = D.ITEM                                                                                                 
         and    S.ORDERNO  = H.ORDERNO                                                                                              
         and    S.LOCATION = 'FIN'                                                                                                  
         and    S.TRAN_ID  = myTranID                                                                                               
         and    (S.SCRAP    = 'Y' or nvl(s.SORT,'G') = 'B')                                                                         
         group by S.ORDERNO,H.CUST,S.PICKLIST_ID;                                                                                   
                                                                                                                                    
   begin                                                                                                                            
      myRetMesg := null;                                                                                                            
      EMAIL_FLAG := 'N';                                                                                                            
      EMAIL_ADDR := null;                                                                                                           
                                                                                                                                    
      mySect := 'Scr - Begin';                                                                                                      
      log;                                                                                                                          
      mySect := 'Scr - Load Data';                                                                                                  
                                                                                                                                    
      for c1r in c1 loop                                                                                                            
         log;                                                                                                                       
         mySect := 'Scr - Ship ID';                                                                                                 
                                                                                                                                    
         select DEX_SHIP_INTERFACE_S.nextval                                                                                        
         into   myShipID                                                                                                            
         from   DUAL;                                                                                                               
                                                                                                                                    
         mySeg4 := null;                                                                                                            
         if c1r.PICKLIST_ID is not null then                                                                                        
            log;                                                                                                                    
            mySect := 'Scr - RvnShr Scrap';                                                                                         
                                                                                                                                    
            -- old version : SHR-SCRAP,  new version : SHR-ASIS                                                                     
            begin                                                                                                                   
               select decode(ORDERNO,'SHR', 'SHR-SCRAP', 'SHR-ASI                                                                   
S')                                                                                                                                 
               into   mySeg4                                                                                                        
               from   PICKLIST                                                                                                      
               where  PICKLIST_ID = c1r.PICKLIST_ID                                                                                 
               and    PICK_TYPE = 'X'                                                                                               
               and    (SCRAP = 'Y' or ORDERNO='SHR');                                                                               
            exception                                                                                                               
               when OTHERS then                                                                                                     
                  null;                                                                                                             
            end;                                                                                                                    
         end if;                                                                                                                    
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Scr - Update';                                                                                                  
                                                                                                                                    
         update DEX_SERIALS set                                                                                                     
         SHIP_ID  = myShipID                                                                                                        
        ,LOCATION = 'PKD'                                                                                                           
         where ORDERNO  = c1r.ORDERNO                                                                                               
         and   (SCRAP    = 'Y' or nvl(SORT,'G') = 'B')                                                                              
         and   LOCATION = 'FIN'                                                                                                     
         and   TRAN_ID  = myTranID;                                                                                                 
                                                                                                                                    
         log;                                                                                                                       
         mySect := 'Scr - Insert';                                                                                                  
                                                                                                                                    
         insert into DEX_SHIP_INTERFACE                                                                                             
        (SHIP_ID,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,CREATE                                                              
D_BY                                                                                                                                
        ,STATUS,SHIP_TYPE,PLANT,SEGMENT1,SEGMENT2,SEGMENT4,SHIP_NAME,COUN                                                           
TRY,CONSIGNEE_PHONE                                                                                                                 
        ,ADDRESS1,ADDRESS2,ADDRESS3,ADDRESS4,CITY,STATE,PO                                                                          
STAL_CODE,PROVINCE,COUNTY                                                                                                           
        ,SHIP_METHOD_CODE,WEIGHT,WEIGHT_UNIT_CODE,CO                                                                                
D,COD_AMOUNT,COD_PAYMENT_TYPE,COD_COMMENT                                                                                           
        ,PICKLIST_ID,TRAN_ID,PACKAGE_TYPE,SATURDAY_DELIVERY,FR                                                                      
EIGHT_QUOTE                                                                                                                         
        ,SHIPPED_BY,WAYBILL_NUM,FREIGHT_AMOUNT,DATE_SHIPPED)                                                                        
         select myShipID,SYSDATE,myUserID,SYSDATE,myUserI                                                                           
D                                                                                                                                   
        ,'C','M',H.PLANT,c1r.ORDERNO,H.CUST,mySeg4,H.SHIP_NAME,H.COUNTRY,H.T                                                        
ELEPHONE                                                                                                                            
        ,H.SHIP_ST1,H.SHIP_ST2,null,H.SHIP_ATTN,H.SHIP_CITY,H.SHIP_ST                                                               
ATE,H.SHIP_ZIP,null,null                                                                                                            
        ,myShipVia,0,'LB',H.COD,0,C.COD_PAYMENT_TYPE,                                                                               
C.COD_COMMENT                                                                                                                       
        ,0,myTranID,'CUSTOM','N',0,myUserID,myWaybill,0,SYSDATE                                                                     
         from  DEX_ORDERS H                                                                                                         
              ,DEX_CUSTOMER_DATA C                                                                                                  
         where H.CUSTOMER_ID = C.CUSTOMER_ID                                                                                        
         and   H.ORG_ID      = C.ORG_ID                                                                                             
         and   H.ORDERNO     = c1r.ORDERNO;                                                                                         
      end loop;                                                                                                                     
                                                                                                                                    
      log;                                                                                                                          
      mySect := 'Scr - Complete';                                                                                                   
      log;                                                                                                                          
                                                                                                                                    
   exception                                                                                                                        
      when OTHERS then                                                                                                              
         myRetMesg := mySect || ' ' || SQLERRM;                                                                                     
   end SCRAP;                                                                                                                       
end K_DEX_SHIP_LOAD_AOL;                                                                                                            
                                                                                                                                    
                                                                                                                                    
                                                                                                                                    

