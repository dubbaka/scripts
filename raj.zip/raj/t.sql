select  sid,
substr(username,1,15) "DB UserName",
substr(osuser,1,15) "OS UserName",
substr(command,1,3) CMD,
substr(machine,1,10) Machine,
terminal, process, status,
substr(program,1,50) "OS Program Name"
from v$session
where type = 'USER'
and username='APPS'
order by username
