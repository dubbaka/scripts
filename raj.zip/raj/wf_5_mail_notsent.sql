select notification_id,message_type, status, mail_status, to_char(begin_date,'DD-MON-YYYY HH24:MI') from applsys.WF_NOTIFICATIONS
where status = 'OPEN' and mail_status = 'MAIL' and trunc(begin_date) >trunc(sysdate)-1 order by 5; 
