set lines 200
col username for a12
col rbs_name for a15
col program for a30
col module for a30
col sid for 9999
SELECT s.username,
       s.sid,s.serial#,s.module,
       round(t.used_ublk*8192/1024/1024,0) "RbsUsed(MB)",
--       t.used_urec,
--       t.log_io,
--       t.phy_io,
--   t.xidusn,
     s.status,
--     s.program,s.sql_hash_value,
round(s.last_call_et/60,0) "Mins",
--       r.usn ,
--       r.name "RBS_NAME",
       t.start_uext,
       t.start_time,
	s.sql_hash_value
--       t.status "Rbs Status"
FROM v$transaction t, v$session s, v$rollname r
WHERE t.addr = s.taddr
and r.usn = t.xidusn
and t.used_ublk*8192/1024/1024 > 200
order by 6 desc
/
