set linesize 300
col corrid format A50

select NVL(substr(wfe.corrid,1,50),'NULL - No Value') corrid, decode(wfe.state,0,'0 = Ready',1,'1 = Delayed',2,'2 = Retained', 3,'3 = Exception',to_char(substr(wfe.state,1,12))) State, count(*) COUNT
from applsys.wf_deferred wfe group by wfe.corrid, wfe.state;

select NVL(substr(wfe.corrid,1,50),'NULL - No Value') corrid, decode(wfe.state,0,'0 = Ready',1,'1 = Delayed',2,'2 = Retained', 3,'3 = Exception',to_char(substr(wfe.state,1,12))) State,
count(*) COUNT
from applsys.wf_notification_out wfe group by wfe.corrid, wfe.state;
