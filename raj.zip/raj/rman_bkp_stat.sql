set lines 155
col sid for 999999
col username for a5
col opname for a35
select SID,username, opname,to_char(START_TIME,'dd mm yyyy hh:mm:ss'),TOTALWORK, sofar, (sofar/totalwork) * 100 done,TIME_REMAINING/3600/24 "Remaining Time",
to_char(sysdate + TIME_REMAINING/3600/24,'dd mm yyyy hh:mm:ss') end_at
from v$session_longops
where totalwork > sofar
AND opname NOT LIKE '%aggregate%'
AND opname like 'RMAN%'
/
