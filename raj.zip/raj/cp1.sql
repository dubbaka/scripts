set lines 200
col Qname for a25
col submit_by for a19
col ConProgName for a65
SELECT  req.request_id,que.concurrent_queue_name Qname, prog.user_concurrent_program_name ConProgName,to_char(req.ACTUAL_START_DATE,'DD-MON-YYYY HH24:MI')
FROM    applsys.fnd_concurrent_requests req,
        applsys.fnd_concurrent_programs_tl prog,
        applsys.fnd_application         app,
        applsys.fnd_user                usr,
        applsys.fnd_concurrent_queues_tl   que,
        applsys.fnd_concurrent_processes proc 
WHERE   -- req.Phase_Code = 'R' AND
--    p.spid = req.oracle_process_id
--AND     s.paddr = p.addr
     req.request_id = NVL('&creq_id________________',req.request_id)
--AND     UPPER(que.user_concurrent_queue_name) LIKE UPPER('&concurrent_queue_name__%')
AND     req.requested_by = usr.user_id
AND     req.requested_by = 0
AND     req.concurrent_program_id = prog.concurrent_program_id
AND     req.program_application_id = app.application_id
AND     prog.application_id = app.application_id
AND     proc.concurrent_queue_id = que.concurrent_queue_id
AND     req.controlling_Manager = proc.concurrent_Process_id
AND     req.ACTUAL_START_DATE between to_date ('06-JAN-2015 14:06','DD-MON-YYYY HH24:MI') and to_date ('06-JAN-2015 14:09','DD-MON-YYYY HH24:MI')
AND 	que.language='US'  and prog.language='US'
--group by que.concurrent_queue_name, prog.user_concurrent_program_name,to_char(req.ACTUAL_START_DATE,'DD-MON-YYYY')
order by 3
/

