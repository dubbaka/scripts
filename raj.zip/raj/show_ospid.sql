select a.os_process_id from apps.fnd_concurrent_processes a, apps.fnd_concurrent_requests p
  where p.controlling_manager = a.concurrent_process_id
  and   p.request_id = &request_id; 
