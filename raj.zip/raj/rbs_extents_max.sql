select segment_name,
tablespace_name,
count(extent_id) "Extent Count",
status,
sum(blocks) "Total Blocks",
round(sum(blocks)*8/(1024*1024),2) "Total Space in GB"
from dba_undo_extents
where segment_name in
('_SYSSMU1464_4024468881$',
'_SYSSMU1540_2101193832$',
'_SYSSMU508_1507082914$',
'_SYSSMU522_74487972$',
'_SYSSMU529_2858627219$',
'_SYSSMU542_3135401005$',
'_SYSSMU564_2399399155$',
'_SYSSMU645_4172544783$',
'_SYSSMU675_200197297$',
'_SYSSMU732_3056123474$',
'_SYSSMU944_3755150845$',
'_SYSSMU985_851647792$')
group by segment_name, tablespace_name, status
order by segment_name,status;
