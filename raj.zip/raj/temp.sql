select '
   Cursors (Sum): '||to_char(sum(count(*)),'9990.99')||'
   Cursors (Min): '||to_char(min(count(*)),'9990.99')||'
   Cursors (Max): '||to_char(max(count(*)),'9990.99')||'
   Cursors (Avg): '||to_char(avg(count(*)),'9990.99')||'
   Users        : '||to_char(count(count(*)),'9990.99') text
from v$open_cursor a,v$session b
where a.username='APPS' and b.module like 'PA%' and a.sid=b.sid 
group by a.user_name
;
