----------------------------------------------------------------------------------------------------
-- SCCS INFO : creq.sql [1.26] 07/28/06 17:14:01
-- FILE INFO : creq.sql
-- CREATED   : ckarthik
-- DATE      : 07/02/2000
----------------------------------------------------------------------------------------------------
CLEAR  COL BREAK COMPUTE
SET    TIMING ON SERVEROUT ON LINES 120 PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT

COL req_id      FORMAT 999999999
COL spid        FORMAT A5
COL pid         FORMAT A6
COL sid         FORMAT 9999
COL submit_by   FORMAT A11 TRUNC
COL ConProg     FORMAT A57
COL ConProgName FORMAT A71 TRUNC head "Con. Prog Name (QUEUE NAME - QUEUE pid)"
COL Active4     FORMAT A6  HEADING STATUS trunc

BREAK ON REPORT
COMPUTE SUM OF RUNNING ON REPORT

SELECT  distinct que.user_concurrent_queue_name ConProg, count(*) running
FROM    applsys.fnd_concurrent_requests req,
        applsys.fnd_concurrent_programs_tl prog,
        applsys.fnd_application         app,
        applsys.fnd_user                usr,
        applsys.fnd_concurrent_queues_tl   que,
        applsys.fnd_concurrent_processes proc ,
        v$session s, v$process p
WHERE   req.Phase_Code = 'R' AND
p.spid = req.oracle_process_id
AND     s.paddr = p.addr
AND     req.requested_by = usr.user_id
AND     req.concurrent_program_id = prog.concurrent_program_id
AND     req.program_application_id = app.application_id
AND     prog.application_id = app.application_id
AND     proc.concurrent_queue_id = que.concurrent_queue_id
AND     req.controlling_Manager = proc.concurrent_Process_id
GROUP   BY que.user_concurrent_queue_name
/


SELECT  distinct req.request_id req_id, p.spid, s.sid,s.process pid,
        usr.user_name submit_by, ---que.concurrent_queue_name Qname,
        prog.user_concurrent_program_name||'('||que.user_concurrent_queue_name||'-'||proc.Os_Process_ID||')'
        ConProgName ,
        substr(s.status,1,1)||LPAD(((s.last_call_et/60)-mod((s.last_call_et/60),60))/60,2,'0')||
        ':'|| LPAD(ROUND(mod((s.last_call_et/60),60)),2,'0') Active4
FROM    applsys.fnd_concurrent_requests req,
        applsys.fnd_concurrent_programs_tl prog,
        applsys.fnd_application         app,
        applsys.fnd_user                usr,
        applsys.fnd_concurrent_queues_tl   que,
        applsys.fnd_concurrent_processes proc ,
        v$session s, v$process p
WHERE   req.Phase_Code = 'R' AND
  p.spid = req.oracle_process_id
AND     s.paddr = p.addr
AND     req.request_id = NVL('&creq_id________________',req.request_id)
AND     s.sid = NVL('&sid____________________',s.sid)
AND     UPPER(que.user_concurrent_queue_name) LIKE UPPER('&concurrent_queue_name__%')
AND     req.requested_by = usr.user_id
AND     req.concurrent_program_id = prog.concurrent_program_id
AND     req.program_application_id = app.application_id
AND     prog.application_id = app.application_id
AND     proc.concurrent_queue_id = que.concurrent_queue_id
AND     req.controlling_Manager = proc.concurrent_Process_id
ORDER   BY 7
/

SET    TIMING OFF PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT


