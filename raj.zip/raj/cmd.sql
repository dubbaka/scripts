col det heading 'CONCURRENT REQUEST DETAILS'

select  'Request ID   : ' || fcr.request_id || chr(10) || 
        'User(Resp)   : ' || fu.user_name || ' (' ||
        b.responsibility_name || ')' || chr(10) ||
        'Program Name : ' || fcp.concurrent_program_name || chr(10) ||
        'Conc Program : ' || pt.user_concurrent_program_name || chr(10) ||
        'Time Details : ' ||
        to_char(fcr.actual_start_date,'mm/dd/yy HH24:MI:SS') || ' - ' ||
        nvl(to_char(fcr.actual_completion_date,'mm/dd/yy HH24:MI:SS'),
        ' Not complete ') ||  chr(10)  ||
        'Elapsed Time : ' ||
        to_char((nvl(fcr.actual_completion_date,sysdate) - fcr.actual_start_date) * 1440,'99990.00') || ' minutes' || chr(10) ||
        'Status       : ' ||
        decode(status_code,'C', 'Completed','D','Cancelled',
        'E', 'Error', 'R', 'Running', 'P','Pending', 
        'X','Terminated', 'G','Warning', ' ') || ' ' || chr(10) ||
        'Arguments    : '||
        fcr.argument_text ||chr(10)||
        'Trace Enabled: ' ||nvl(fcr.enable_trace,'N') det,
        'Logfile Name : '||
        fcr.logfile_name,
        'Output File  : '||
        fcr.outfile_name|| chr(10), 
        'SPID : '||fcr.oracle_process_id
  from  applsys.fnd_responsibility_tl b,
        applsys.fnd_concurrent_programs fcp,
        applsys.fnd_concurrent_programs_tl pt,
        applsys.fnd_user                fu,
        applsys.fnd_concurrent_requests fcr
 where fcr.concurrent_program_id = fcp.concurrent_program_id
   and fcr.program_application_id = fcp.application_id
   and fcp.application_id = pt.application_id
   and fcp.concurrent_program_id = pt.concurrent_program_id
   and pt.language = 'US'
   and fu.user_id = fcr.requested_by
   and b.responsibility_id  = fcr.responsibility_id
   and b.application_id = fcr.responsibility_application_id
   and fcr.request_id =  &1
/

