
COLUMN USERNAME FORMAT a10
COLUMN status FORMAT a8
set linesize 100
set pagesize 15 

Rem # rbs_used.sql
set feedback on
set linesize 132
set echo off
column RBS_NAME format a10
TTITLE 'Total Blocks used by a user in a rbs'
SELECT s.username,
       s.sid, 
       t.used_ublk*8192/1024/1024 "RbsUsed(MB)", 
       t.used_urec, 
       t.log_io, 
       t.phy_io, 
    --   t.xidusn,
       r.usn ,
       r.name "RBS_NAME",
       t.start_uext,
       t.start_time,
       t.status
FROM v$transaction t, v$session s, v$rollname r
WHERE t.addr = s.taddr 
and r.usn = t.xidusn
order by s.sid 
/

