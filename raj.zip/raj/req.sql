select request_id, phase, status from apps.fnd_amp_requests_v where request_id='&1';
