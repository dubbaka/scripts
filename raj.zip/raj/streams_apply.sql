COLUMN apply_name              FORMAT A20             HEADING 'Apply'
COLUMN process_name            FORMAT A07             HEADING 'Process'
COLUMN sid                     FORMAT A08             HEADING 'Sid'
COLUMN state                   FORMAT A17             HEADING 'State'
COLUMN total_messages_dequeued FORMAT 99G999G999G999  HEADING 'Nb Msg dequeued'
COLUMN total_applied           FORMAT 999G999G999G999 HEADING 'Total TX Applied' 
SELECT r.apply_name, substr(s.program, instr(s.program,'(')+1,4) process_name, 
       r.sid||','||r.serial# sid, r.state, 
       r.total_messages_dequeued, c.total_applied 
FROM v$streams_apply_reader r,  v$streams_apply_coordinator c,  
     v$session s, dba_apply ap 
WHERE r.sid = s.sid 
  AND r.serial# = s.serial# 
  AND r.apply_name = ap.apply_name 
  AND r.apply_name = c.apply_name 
ORDER BY 1
/
