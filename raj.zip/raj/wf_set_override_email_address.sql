select fscpv.parameter_value
    from fnd_svc_comp_params_tl fscpt
    ,fnd_svc_comp_param_vals fscpv
    where fscpt.display_name = 'Test Address'
    and fscpt.parameter_id = fscpv.parameter_id;
 
update
    fnd_svc_comp_param_vals fscpv
set
    fscpv.PARAMETER_VALUE = '&override_email_address'
where
    fscpv.parameter_id in (
        select
            fscpt.parameter_id
        from
            fnd_svc_comp_params_tl fscpt
        where
            fscpt.display_name = 'Test Address');
 
select fscpv.parameter_value
    from fnd_svc_comp_params_tl fscpt
    ,fnd_svc_comp_param_vals fscpv
    where fscpt.display_name = 'Test Address'
    and fscpt.parameter_id = fscpv.parameter_id;
 
commit;
