column event format a40
set pagesize 80

select b.event,count(*),avg(b.wait_time)
from gv$session a,gv$session_wait b
where a.sid = b.sid
and a.type != 'BACKGROUND'
and b.wait_time=0
group by b.event 
order by 2
/
