set echo on pagesize 0
rem spool nologind.lst
select owner, index_name , logging, temporary
from dba_indexes
where logging <> 'YES'
and temporary <> 'Y'
order by 1,2;
rem spool off
