connect / as sysdba
spool  systemdump267.log
oradebug setmypid
oradebug unlimit
oradebug dump systemstate 267
spool off
exit

