set pagesize 100

select a.usn, b.name, a.status
from v$rollstat a, v$rollname b
where a.usn = b.usn
order by usn
/


