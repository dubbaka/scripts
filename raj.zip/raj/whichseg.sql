select segment_name, partition_name, segment_type, extent_id
from dba_extents
where file_id = &1
and &2 between block_id and (block_id + blocks - 1);
