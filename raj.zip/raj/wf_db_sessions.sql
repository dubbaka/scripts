
set lines 200
col module for a45
col action for a45
select inst_id,sid,serial#,module,action,to_char(logon_time,'dd-mon-YYYY hh24:MI') from gv$session where module like '%WFMLR%';
