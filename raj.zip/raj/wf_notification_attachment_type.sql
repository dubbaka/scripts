SELECT flv.file_id
      ,'Requisition'             Transaction_TYPE
      ,aia.requisition_header_id trsanction_id
      ,aia.segment1              transaction_num
      ,aia.creation_date         creation_date
      ,fu.user_name              user_name
      ,ppx.full_name             full_name
      ,flv.file_name             file_name
      ,flv.file_content_type     file_content_type
      ,flv.upload_date           upload_date
      ,wfn.message_type          item_type
      ,wfn.item_key              item_key
      ,wfn.notification_id       notification_id
FROM   apps.fnd_attached_documents fad,
       apps.fnd_documents fl,
       apps.fnd_document_datatypes_vl dt,
       apps.fnd_lobs flv,
       apps.po_requisition_headers_all aia,
       apps.po_requisition_lines_all   prl,
       apps.fnd_user fu,
       apps.per_people_x ppx,
       apps.hr_operating_units hou,
       apps.wf_notifications wfn
WHERE  fad.document_id        =  fl.document_id
AND    fl.media_id            =  flv.file_id
AND    fu.user_id             =  aia.created_by
AND    fu.employee_id         =  ppx.person_id(+)
AND    aia.org_id             =  hou.organization_id
AND    aia.requisition_header_id = prl.requisition_header_id
-- AND    fad.entity_name        = 'REQ_LINES'
AND    dt.datatype_id         =  fl.datatype_id
AND    dt.name                =  'FILE'
---AND    flv.file_content_type  =  'application/octet-stream:'
AND    flv.file_name  LIKE  '%pdf'
AND    to_number(fad.pk1_value)    =  prl.requisition_line_id
AND    wfn.message_type            =  'REQAPPRV'
AND    aia.requisition_header_id   =  TO_NUMBER(SUBSTR(wfn.item_key, 1, (INSTR(wfn.item_key, '-')) - 1))
AND    wfn.notification_id         =  104150666;
