select count(1) from applsys.WF_NOTIFICATIONS
where status = 'OPEN' and mail_status = 'MAIL' and trunc(begin_date) >trunc(sysdate)-1; 
