@q
set pages 100
undef hash_value
undef tblname
col object for a35
col object_type for a20
set verify off
col pid format 9999 heading 'PID'
col spid format a6 heading 'SERVER|PID'
col sid format 9999 heading 'SID'
col serial# format 99999 heading 'SERIAL'
col process format a6 heading 'CLIENT|PID'
col osuser format a8 heading 'OS|USERNAME'
col username format a12 heading 'ORACLE|USERNAME'
col logical format b99999999999 heading 'LOGICAL|READS'
col physical_reads format b99999999 heading 'PHYSICAL|READS'
col audsid format b99999999 heading 'AUDIT|SESSION'
col program format a15 heading 'PROGRAM NAME'
col logon_time format a8 heading 'LOGON|TIME'
col module format a15 heading 'MODULE'
col status format a10 heading 'STATUS'
col client_info format a6 heading 'CLIENT|INFO'
rem
select s.inst_id, s.process,
       p.spid,
       p.pid,
       s.sid,
       s.serial#,
       s.osuser,
       s.username,
       i.block_gets + i.consistent_gets logical,
       i.physical_reads,
       s.audsid, s.status, s.action,
       to_char( s.logon_time, 'hh24:mi:ss' ) logon_time,
       substr(s.program,1,15),
       substr(s.module,1,15),substr(s.client_info,1,6) client_info,sql_hash_value,last_call_et/60 last_call_min
  from gv$process p, gv$session s, gv$sess_io i
 where i.sid = s.sid
   and s.paddr = p.addr
	and sql_hash_value=&&hash_value
and p.inst_id = s.inst_id and s.inst_id = i.inst_id
 order by block_gets + consistent_gets desc;

@qSessAll

select * from gv$session_wait where sid=&sid;

select sql_text
from gv$sqltext
where hash_value = &&hash_value
order by piece;

@@hash_fmt

set linesize 120
set pages 1000
rem
col "ORDER"             format a12
col "OPERATION" format a80
col "OPTIONS"           format a14
col "OBJECT_NAME"       format a30
col "OPTIMIZER" format a8
col "ROWS"              format 999999999
col id format 999
col child_number format 99
rem
select distinct child_number,id
     , lpad (' ', depth) || operation||' '||options||' '||object_name||' '||optimizer operation
     , cost
  from gv$sql_plan
 where hash_value = &&hash_value
 order by child_number,id;


select owner||'.'||object_name object,object_type from dba_objects
where object_name =upper('&objname');

select num_rows,last_analyzed  from dba_tables Where owner||'.'||table_name='&tblname' 
and '&&tblname' is not null;

col segment_name for a30
select owner,segment_name,extents,blocks from dba_segments
where owner||'.'||segment_name='&&tblname';

