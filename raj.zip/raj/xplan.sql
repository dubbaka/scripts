explain plan for 
SELECT /*+ Index(pha PO_HEADERS_U1) */ DISTINCT 
 :p_period_name,
            pha.segment1 po_number,
            pla.line_num po_line_number,
            hou.name po_operating_unit,
            msib.segment1 po_item_number,
            pla.item_description po_item_description,
            DECODE(serial_number_control_code,
                    1,'Bulk',
                    5,'Serial',
                    'Other') po_type_serial_bulk,
            pla.quantity po_quantity,
            pla.unit_price po_unit_price,
            pha.po_header_id po_header_id,
            pla.po_line_id po_line_id,
            pha.currency_code po_currency_code,
            rt.transaction_id rcv_transaction_id,
            rt.po_distribution_id rcv_po_distribution_id,
            gcc_ap.segment1,
            gcc_ap.segment3,
            fnd_flex_ext.get_segs('SQLGL','GL#',50308,mta.reference_account) rcv_rec_acct,
            msib.expense_account rcv_expense_account,
            msib.inventory_item_id rcv_inventory_item_id,
            rt.transaction_date rcv_transaction_date,
            rsh.shipment_header_id rcv_shipment_header_id,
            rsh.receipt_num rcv_receipt_num,
            rst.serial_num rcv_serial_num,
            rsl.shipment_line_id rcv_shipment_line_id,
            SIGN(mmt.transaction_quantity) rcv_receipt_quantity,
            SIGN(mmt.transaction_quantity) * pla.unit_price rcv_receipt_amount,
            SIGN(mmt.transaction_quantity) * pla.unit_price rcv_conv_receipt_amount,
            gl.currency_code rcv_currency_code,
            1 rcv_currency_conversion_rate,
            --is_rcv_in_gl(rsh.shipment_header_id),
            fma.transaction_header_id,
            fma.parent_mass_addition_id fa_mass_addition_id,
            NULL fa_queue_name,
            fma.serial_number fa_serial_number,
            fma.payables_units fa_fixed_assets_units,
            DECODE(rt.transaction_type,'RETURN TO RECEIVING',SIGN(mmt.transaction_quantity)*-1 * fma.fixed_assets_cost,SIGN(mmt.transaction_quantity) * fma.fixed_assets_cost) fa_fixed_assets_cost,
            gcc_fa.segment1,
            gcc_fa.segment3,
            fnd_flex_ext.get_segs('SQLGL','GL#',50308,fma.payables_code_combination_id) fa_acct,
            fma.payables_code_combination_id,
            fma.asset_number fa_asset_number,
            fma.fa_asset_category,
            fma.asset_id,
            NULL fa_add_to_asset_id,
            fma.book_type_code fa_book_type_code,
            fma.feeder_system_name,
            --is_intl_xfer_asset(fma.asset_id),
            gl.ledger_id,
            rt.transaction_type
       FROM
            --rcv_transactions             rt,
            (select * from rcv_transactions rt1 where not exists (SELECT /*+ index(ifb XXFB_INV_FA_BULKASSET_U1) */1 FROM xxfb_inv_fa_bulkasset ifb WHERE transaction_id = transaction_id+0 and rcv_transaction_id=rt1.transaction_id)) rt,
            mtl_material_transactions    mmt,
            mtl_unit_transactions        mut,
            mtl_transaction_accounts     mta,
            rcv_shipment_headers         rsh,
            rcv_shipment_lines           rsl,
            rcv_serial_transactions      rst,
            xxfb_fa_recon_fa_metadata    fma,
            po_headers_all               pha,
            po_lines_all                 pla,
            mtl_system_items_b           msib,
            gl_code_combinations         gcc_ap,
            hr_all_organization_units    haou,
            hr_operating_units           hou,
            gl_ledgers                   gl,
            csi_item_instances           cii,
            csi_i_assets                 cia,
            gl_periods                   gp,
            gl_code_combinations         gcc_fa
      WHERE rt.transaction_date BETWEEN gp.start_date AND (gp.end_date+1)-1/(24*60*60)
         AND fma.period_name = gp.period_name
         and fma.payables_code_combination_id is not null
         AND rt.source_document_code = 'PO'
         AND mmt.transaction_id=mut.transaction_id
         AND rt.organization_id = haou.organization_id
         AND rt.transaction_type IN ('DELIVER','CORRECT','RETURN TO RECEIVING')
         AND rt.destination_type_code IN('INVENTORY','RECEIVING')
         AND rt.transaction_id = mmt.rcv_transaction_id
         AND mmt.transaction_id = mta.transaction_id
         AND mta.accounting_line_type = 2
         AND rt.shipment_header_id = rsh.shipment_header_id
         AND rt.shipment_line_id = rsl.shipment_line_id
         AND rt.transaction_id = rst.transaction_id
         AND rsl.item_id = msib.inventory_item_id
         AND msib.organization_id = 82
         AND rt.po_header_id = pha.po_header_id
         AND rt.po_line_id = pla.po_line_id
         and pla.po_header_id = pha.po_header_id
         and pha.po_header_id = pha.po_header_id+0
         AND rt.po_distribution_id = fma.po_distribution_id
         AND pha.segment1 = fma.po_number
         AND rst.serial_num = mut.serial_number
         AND cia.fa_asset_id = fma.asset_id
         AND mut.serial_number=cii.serial_number
         AND mut.inventory_item_id=cii.inventory_item_id
         AND mta.reference_account = gcc_ap.code_combination_id
         --AND gcc_fa.code_combination_id = 11203
         AND fma.payables_code_combination_id = gcc_fa.code_combination_id
         AND cia.instance_id = cii.instance_id
         AND (
         (cii.instance_description = fma.attribute8)
           OR 
           trunc(cia.active_end_date) BETWEEN gp.start_date AND (gp.end_date+1)-1/(24*60*60)
           OR trunc(cia.active_start_date) BETWEEN gp.start_date AND (gp.end_date+1)-1/(24*60*60)
           )
         AND gp.period_set_name = 'FB_GL_PERIOD' AND gp.period_name = :p_period_name
         AND pha.org_id = hou.organization_id
         AND pha.currency_code = gl.currency_code
         AND pha.org_id = hou.organization_id
         AND hou.set_of_books_id = gl.ledger_id
         AND  fma.po_number is not null
         --AND not exists (SELECT * FROM xxfb_inv_fa_bulkasset WHERE rcv_transaction_id=rt.transaction_id);
select plan_table_output  from table(dbms_xplan.display('plan_table',null,'basic +predicate +cost'));
