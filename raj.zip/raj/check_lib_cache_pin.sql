col sid format 9999999
col holder format 9999999
REM Sessions waiting for a Library Cache Pin: 
prompt Sessions waiting for a Library Cache Pin: 
select /*+ RULE */ sid Waiter, 
substr(rawtohex(p1),1,30) Handle, 
substr(rawtohex(p2),1,30) Pin_addr 
from v$session_wait where wait_time=0 and event like 'library cache pin%'; 

REM Objects concerning to Library Cache Pin we are waiting for: 
prompt Objects concerning to Library Cache Pin we are waiting for: 
select /*+ RULE */ to_char(SESSION_ID,'9999999') sid , 
substr(LOCK_TYPE,1,30) Type, 
substr(lock_id1,1,30) Object_Name, 
substr(mode_held,1,4) HELD, substr(mode_requested,1,4) REQ, 
lock_id2 Lock_addr 
from dba_lock_internal 
where 
mode_requested<>'None' 
and mode_requested<>mode_held 
and session_id in ( select sid 
from v$session_wait where wait_time=0 
and event like 'library cache pin%') ; 

REM Library Cache Pin holders we are waiting for: 
prompt Library Cache Pin holders we are waiting for: 

select /*+ RULE */ sid Holder ,KGLPNUSE Sess , KGLPNMOD Held, KGLPNREQ Req 
from x$kglpn , v$session 
where KGLPNHDL in (select p1raw from v$session_wait 
where wait_time=0 and event like 'library cache pin%') 
and KGLPNMOD <> 0 
and v$session.saddr=x$kglpn.kglpnuse ; 

REM What are the holders waiting for? 
prompt What are the holders waiting for? 

select /*+ RULE */ sid,substr(event,1,30),wait_time 
from v$session_wait 
where sid in (select sid from x$kglpn , v$session 
where KGLPNHDL in (select p1raw from v$session_wait 
where wait_time=0 and event like 'library cache pin%') 
and KGLPNMOD <> 0 
and v$session.saddr=x$kglpn.kglpnuse ) 
; 
