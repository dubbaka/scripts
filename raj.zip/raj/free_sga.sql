select KSMCHCLS,KSMCHCOM,count(*),sum(KSMCHSIZ),avg(KSMCHSIZ),max(KSMCHSIZ)
from x$ksmsp
group by KSMCHCLS,KSMCHCOM
order by 3
/

