set linesize 200 pages 2000
col Time(min) format a13
col user_concurrent_program_name format a45
col argument_text for a65
@/home/oracle/dba/rajendra/scripts/alter_ss_date
select distinct request_id,
        user_concurrent_program_name,
        decode (phase_code,'R', 'RUNNING', 
                           'P', 'PENDING', 
                           'I', 'INACTIVE',
                           'C', 'Completed',
                            phase_code) phase_code,
        decode (status_code,'A', 'WAITING', 
                            'B', 'RESUMING', 
                            'C', 'NORNAL', 
                            'D', 'CANCELLED', 
                            'E', 'ERROR',
                            'F', 'SCHEDULED',
                            'G', 'WARNING',
                            'H', 'ON HOLD',
                            'I', 'NORNAL',
                            'M', 'NO MANAGER',
                            'Q', 'STANDBY', 
                            'S', 'SUSPENDED', 
                            'T', 'TERMINATE', 
                            'X', 'TERMINATED',
                            'Z', 'WAITING',
                            'R', 'NORMAL',
                            'U', 'DISABLED',
                            'W', 'PAUSED',
                            status_code) status_code,
        actual_start_date,
        actual_completion_date,
        decode(actual_completion_date, null, 'Not Completed', round((actual_completion_date-actual_start_date)*24*60,2) ) "Time(min)",argument_text
from    xxfbdba.fnd_conc_requests_archive cr, apps.fnd_concurrent_programs_tl cp
where   cr.concurrent_program_id = cp.concurrent_program_id
and     cp.user_concurrent_program_name like '%&concurrent_prgm_name%' and argument_text not in 'OEOL'
order by user_concurrent_program_name, to_number(request_id)
/

