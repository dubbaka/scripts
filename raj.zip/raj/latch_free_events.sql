set linesize 132
column name format a40
column sid format 9999
column event format a30

PROMPT 'SESSIONS AND THE FILES THAT ARE WAITING FOR SCATTERD AND SEQ READ'


select sw.sid, sw.event, file#, sw.p2 block#, name
from v$dbfile df, v$session_wait sw
where df.file# = sw.p1
and sw.event in ('db file scattered read', 'db file sequential read')  
/

column name format a50
column sid format 9999

PROMPT 'SESSIONS AND THE LATCHE NAMES THAT ARE WAITING FOR LATCH FREE EVENT'


select sw.sid, sw.event, l.latch#, l.name
from v$latch l, v$session_wait sw
where sw.event='latch free'
and l.latch# = sw.p2
/
