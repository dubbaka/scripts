insert into cits_cases values ('&create_date','&caseno','&priority','&impact','&urgency','&issue','&owner','&instance','&details','&jiracase','&oraclesr','&effortinhrs');
commit;
