col username for a15
col event for a30
select a.sid,a.serial#,b.spid,a.machine,a.username,a.status,a.sql_hash_value,c.event,to_char(a.logon_time,'DD-MON-YYYY HH24:MI:SS'),a.last_call_et/60,a.machine
from v$session a,v$process b,v$session_wait c
where a.paddr=b.addr
and a.sid=c.sid
and a.machine in ('prn-omgprdapp01')
order by 5
/
