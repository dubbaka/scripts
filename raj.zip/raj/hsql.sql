select sql_text from v$sql where hash_value='&a';
