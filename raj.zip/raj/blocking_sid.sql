set lines 150 pages 150
select inst_id,sid,serial#,status,machine,program,module,to_char(logon_time,'DD/MM/YY HH24:MI:SS'),username,action,blocking_instance,blocking_session,last_call_et,client_identifier from gv$session where blocking_session is not null;
