set linesize 132
col Time(min) format a13
col user_concurrent_program_name format a40
@/usr/tools/oracle/scripts/alter_ss_date
select  user_concurrent_program_name,
        argument_text,count(*)
from    apps.fnd_concurrent_requests cr, apps.fnd_concurrent_programs_tl cp
where   cr.concurrent_program_id = cp.concurrent_program_id
and     cp.user_concurrent_program_name like '%&concurrent_prgm_name%' 
group by user_concurrent_program_name,argument_text
order by 3,2
/

