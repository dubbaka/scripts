set lines 80
set pages 100
spool check_logs_generated
ttitle center 'List of Redo Logs generated on Daily Basis' skip 1 center '********************************************' skip 2
select trunc(first_time) DAY, count(*)
  from v$log_history
 group by trunc(first_time)
;

ttitle center 'List of Redo Logs generated today on Hourly Basis' skip 1 center '********************************************' skip 2
select to_char(first_time,'MM/DD/YYYY HH24') DATE_TIME, count(*)
  from v$log_history
 where trunc(first_time)=trunc(sysdate)
 group by to_char(first_time,'MM/DD/YYYY HH24')
;
spool off
