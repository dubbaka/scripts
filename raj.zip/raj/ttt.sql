SELECT distinct printer
-- ,responsibility_id,requested_by,request_id,SYSDATE NowSysTimeIs, A.ACTUAL_START_date ACTUAL_START ,
-- A.ACTUAL_COMPLETION_date ACTUAL_COMPLETION,argument_text,((A.ACTUAL_COMPLETION_DATE - A.ACTUAL_START_DATE)*(24*60*60)) "DURATION(SEC)",
-- A.REQUEST_ID,
-- B.USER_CONCURRENT_PROGRAM_NAME,
-- A.ARGUMENT3,
---- ((sysdate - A.ACTUAL_START_DATE)*(24*60)) "DUR(SEC)",
--DECODE(A.PHASE_CODE,'C','COMPLETED','P','PENDING','R','RUNNING','***')
--PHASE,
--DECODE(A.STATUS_CODE,'C','COMPLETED','I','INACTIVE','R','RUNNING','***')
--STATUS, A.REQUESTED_START_DATE, ((A.ACTUAL_START_DATE - A.REQUESTED_START_DATE)*(24*60*60)) "LAUNCH(SEC)",
-- A.PHASE_CODE,
-- A.STATUS_CODE,
-- A.REQUEST_DATE,
-- A.COMPLETION_TEXT,
-- A.ARGUMENT_TEXT,
-- a.argument1,
-- a.argument2,
-- A.REQUESTED_BY,
-- A.RESPONSIBILITY_ID,
-- a.parent_request_id,
-- a.concurrent_program_id
FROM apps.FND_CONCURRENT_PROGRAMS_TL B,
apps.FND_CONCURRENT_REQUESTS A
WHERE A.CONCURRENT_PROGRAM_ID = B.CONCURRENT_PROGRAM_ID
and trunc(request_date) = trunc(Sysdate )
and status_code in ('G')
and printer not in ('TR2-ZEB1', 'noprint','sao-zebra1')
