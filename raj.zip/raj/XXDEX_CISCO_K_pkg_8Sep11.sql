                                                                                                                                    
  CREATE OR REPLACE PACKAGE "APPS"."XXDEX_CISCO_K" as                                                                               
/* $Header: XXDEX_CISCO_K.sql 2.1.16.0 2011/05/25 12:00:00 dexsys ship $ Co                                                         
pyright (c) 2011 DEX Systems, Inc. */                                                                                               
                                                                                                                                    
   procedure LOG_SET;                                                                                                               
   procedure LOG_UNSET;                                                                                                             
                                                                                                                                    
	procedure RMA_CREATE  ( myInvOrgID			in 	NUMBER                                                                                    
								  ,mySubInvCode		in 	VARCHAR2		-- (Optional)                                                                                
								  ,myRMAHeader			in 	XXDEX_CISCO_GLOBAL_K.RMA_HEADER_REC                                                                    
								  ,myRMADetails	  	in 	XXDEX_CISCO_GLOBAL_K.RMA_DET                                                                         
AILS_TBL := XXDEX_CISCO_GLOBAL_K.INIT_RMA_DETAILS_TB                                                                                
L                                                                                                                                   
   							  ,myRMASerials		in 	XXDEX_CISCO_GLOBAL_K.RMA_SERIALS_TBL := XXDEX                                                        
_CISCO_GLOBAL_K.INIT_RMA_SERIALS_TBL                                                                                                
								  ,myRMANbr				out 	VARCHAR2		-- will be filled in only if                                                                  
successfull                                                                                                                         
								  ,myPartnerRMA		out	VARCHAR2                                                                                               
								  ,myRMAErrors			out	XXDEX_CISCO_GLOBAL_K.RMA_                                                                              
ERRORS_TBL                                                                                                                          
								  );                                                                                                                        
                                                                                                                                    
	procedure RMA_RESPONSE ( myInvOrgID			in		NUMBER                                                                                   
						  		   ,mySubInvCode		in 	VARCHAR2			-- (Optional                                                                             
)                                                                                                                                   
							  	   ,myRMANbr			in 	VARCHAR2                                                                                               
								   ,myPartnerRMA		in		VARCHAR2			-- (Optional)                                                                              
								   ,myStatusCode 		in 	VARCHAR2  		-- A = Accept, R =                                                                       
 Reject                                                                                                                             
								   ,myErrMessage		in		VARCHAR2			-- Reject Error Message                                                                    
								  	);                                                                                                                       
                                                                                                                                    
	procedure RMA_RECEIPT ( myInvOrgID			in 	NUMBER                                                                                    
								  ,mySubInvCode		in 	VARCHAR2			-- Optional                                                                                 
								  ,myReceipts	  		in 	XXDEX_CISCO_GLOBAL_K.RECEIPTS_TBL                                                                     
								  );                                                                                                                        
                                                                                                                                    
	procedure STATUS_UPDATE ( myInvOrgID		in 	NUMBER                                                                                   
								    ,mySubInvCode		in 	VARCHAR2			-- Optional                                                                               
									 ,myWorkOrders		in 	XXDEX_CISCO_GLOBAL_K.WORK_ORDERS_TBL                                                                   
 							 		 );                                                                                                                      
                                                                                                                                    
	procedure QUALITY_UPDATE ( myInvOrgID		in 	NUMBER                                                                                  
								  	  ,mySubInvCode	in 	VARCHAR2			-- Optional                                                                               
									  ,myQualRcds		in 	XXDEX_CISCO_GLOBAL_K.QUAL_DATA_TBL                                                                      
									  );                                                                                                                       
                                                                                                                                    
	procedure SHIP_CONFIRM ( myInvOrgID			in 	NUMBER                                                                                   
								   ,mySubInvCode		in 	VARCHAR2			-- Optional                                                                                
								   ,myShipHeader		in 	XXDEX_CISCO_GLOBAL_K.SHIPMENT_REC                                                                     
								   ,myShipDetails  	in 	XXDEX_CISCO_GLOBAL_K.SH                                                                             
IP_DETAILS_TBL                                                                                                                      
									);                                                                                                                         
                                                                                                                                    
	procedure SHIP_CANCEL  ( myShipID			in    NUMBER );                                                                                
                                                                                                                                    
	procedure RMA_SHIPMENT ( myInvOrgID			in 	NUMBER                                                                                   
								   ,mySubInvCode		in 	VARCHAR2			-- Optional                                                                                
								   ,myShipHeader 		in 	XXDEX_CISCO_GLOBAL_K.RMA_SHIPMENT_REC                                                                
									,myShipDetails  	in 	XXDEX_CISCO_GLOBAL_K.RMA_SHI                                                                          
P_DETAILS_TBL                                                                                                                       
								  );                                                                                                                        
                                                                                                                                    
                                                                                                                                    
	-- Denied Party Screening needs to be done before we generated a Ship ID.                                                          
	-- Need more discussion on if holds should be at RM                                                                                
A or Order level                                                                                                                    
	procedure RMA_HOLD	 ( myRMANbr			in VARCHAR2                                                                                       
								  ,myHoldName		in VARCHAR2                                                                                                  
								  ,myStatus			in VARCHAR2  		-- A = Apply Hold, R                                                                           
= Release Hold                                                                                                                      
								  );                                                                                                                        
                                                                                                                                    
	-- Entitlement Check for List of Serials                                                                                           
	procedure ENTITLE_API ( myRetCode	out number                                                                                       
								  ,myRetMesg	out varchar2                                                                                                   
								  ,mySerials	in out XXDEX_GLOBAL_K.WARRANTY_TBL                                                                             
								  );                                                                                                                        
                                                                                                                                    
	/** FOR OUBOUND IT SOMETHING WENT WRONG -- EITHER RESET OR NOTIF                                                                   
Y. **/                                                                                                                              
	procedure RMACREATEREQ_EXCEPTION ( myRMANbr			in	VARCHAR2                                                                          
												 ,myLineID			in	NUMBER                                                                                                  
												 ,myInvOrgID		in	NUMBER                                                                                                 
												 ,mySubInvCode		in	VARCHAR2                                                                                             
												 ,myAuditRefId		in	NUMBER                                                                                               
												 ,myException		in	VARCHAR2                                                                                              
												 );                                                                                                                     
                                                                                                                                    
	procedure WORKORDER_EXCEPTION ( myRMANbr		in	VARCHAR2                                                                              
											 ,myWorkOrder	in VARCHAR2                                                                                                
 										    ,myInvOrgID	in	NUMBER                                                                                                
										    ,mySubInvCode	in	VARCHAR2                                                                                             
										    ,myTranSetID  in number                                                                                               
										    ,myAuditRefId	in	NUMBER                                                                                               
										    ,myException	in	VARCHAR2                                                                                              
											 );                                                                                                                      
                                                                                                                                    
	procedure DELIVERY_SEND_EXCEPTION ( myRMANbr			in	VA                                                                               
RCHAR2                                                                                                                              
											 	  ,myShipID			in number                                                                                                
 										    	  ,myInvOrgID		in	NUMBER                                                                                            
										    	  ,mySubInvCode	in	VARCHAR2                                                                                          
										    	  ,myAuditRefId	in	NUMBER                                                                                            
										    	  ,myException		in	VARCHAR2                                                                                          
												 );                                                                                                                     
                                                                                                                                    
                                                                                                                                    
	procedure SEND_RMA_ASN	( myRetCode		   out	number                                                                                  
									 ,myRetMesg			out  	varchar2                                                                                               
									 ,myRMANbr			in 	varchar2                                                                                                  
									 );                                                                                                                        
                                                                                                                                    
	procedure UPDATE_INTERNAL_REQ ( myShipID		in	number                                                                                
										    ,myReqNbr		in	number                                                                                                  
										    ,myErrMesg		in varchar2 default null                                                                                  
										    );                                                                                                                    
                                                                                                                                    
	procedure UPDATE_INTERNAL_REQ ( myShipID			in	number                                                                               
										    ,myIntReqLines	in XXDEX_CISCO_GLOBAL_K.INT_REQ_LINES_TBL                                                              
										    );                                                                                                                    
                                                                                                                                    
                                                                                                                                    
	procedure INTERNAL_RECEIPT	( myShipID			in number                                                                                  
										 ,myReceipts		in XXDEX_CISCO_GLOBAL_K.REQ_RECEIPT_                                                                        
TBL                                                                                                                                 
										 );                                                                                                                       
                                                                                                                                    
	procedure RECEIPTS_PROC ( myRetCode		   out	number                                                                                 
									 ,myRetMesg			out  	varchar2                                                                                               
									 ,myShipID			in		number default null                                                                                       
									 );                                                                                                                        
                                                                                                                                    
                                                                                                                                    
	procedure REPAIR_PROC ( myRetCode		   out	number                                                                                   
									 ,myRetMesg			out  	varchar2                                                                                               
									 );                                                                                                                        
                                                                                                                                    
	procedure SHIP_CUST_PROC ( myRetCode	out	number                                                                                    
									  ,myRetMesg	out  	varchar2                                                                                                
									  ,myShipId		in		number                                                                                                    
									 );                                                                                                                        
                                                                                                                                    
                                                                                                                                    
	procedure ENABLEMENT_API ( myRetCode 	out number                                                                                   
									  ,myRetMesg   out number                                                                                                  
									  ,myEMMType	in	 varchar2                                                                                                  
									  ,myRecordId	in	 number                                                                                                   
									  );                                                                                                                       
                                                                                                                                    
	procedure INBOUND ( myFFHdrID	in number);                                                                                          
                                                                                                                                    
	procedure INBOUND ( myRetCode 	out number                                                                                          
							 ,myRetMesg		out varchar2                                                                                                    
							 ,myFFSubType	in	 varchar2 default null                                                                                      
							 );                                                                                                                          
                                                                                                                                    
	procedure FIND_RMA ( myInvOrgId		in		number                                                                                        
							  ,myRMANbr			in 	varchar2                                                                                                   
							  ,myDexRMA			out 	varchar2                                                                                                  
							  ,myPartnerRMA 	out	varchar2                                                                                                
							  );                                                                                                                         
                                                                                                                                    
	procedure PRISMA_UPLOAD ( myRetCode		out	number                                                                                    
									 ,myRetMesg		out	varchar2                                                                                                  
									 ,myShipID		in	number                                                                                                      
									 ,myLicPlatID	in	number                                                                                                    
									);                                                                                                                         
                                                                                                                                    
	function FILTER_EMAIL_LIST ( myEmailList IN XXCTS_B2B_DEX_INTEGR                                                                   
ATION_PUB.MAIL_DIST_TAB_TYPE ) return XXCTS_B2B_DEX_                                                                                
INTEGRATION_PUB.MAIL_DIST_TAB_TYPE;                                                                                                 
                                                                                                                                    
	function FILTER_EMAIL ( myEmailAddr in varchar2) return varchar2;                                                                  
                                                                                                                                    
end XXDEX_CISCO_K;                                                                                                                  
                                                                                                                                    
CREATE OR REPLACE PACKAGE BODY "APPS"."XXDEX_CISCO_K" as                                                                            
/* $Header: XXDEX_CISCO_K.sql 2.1.16.0 2011/05/25 12                                                                                
:00:00 dexsys ship $ Copyright (c) 2011 DEX Systems,                                                                                
 Inc. */                                                                                                                            
                                                                                                                                    
   mySect             varchar2(100);                                                                                                
   myFromInternal		 varchar2(1) := 'N';                                                                                             
   myLog              varchar2(1) := 'N';                                                                                           
   myLogNum           binary_integer := 0;                                                                                          
                                                                                                                                    
   myHost             varchar2(100);                                                                                                
   myDBName           varchar2(20);                                                                                                 
                                                                                                                                    
	myOutHdrID			number;                                                                                                               
	myOutDataID			number;                                                                                                              
	myOutEmail			DEX_FLAT_FILE_HDR.EMAIL%type;                                                                                         
	myOutSubType		DEX_FLAT_FILE_HDR.TRANSACTION_SUB_TYPE%                                                                              
type;                                                                                                                               
                                                                                                                                    
	myFromAddr			varchar2(400) := DEX_PLANT_EMAILS_F ( 'FROM' );                                                                       
	myTechEmail			varchar2(400) := DEX_PLANT_EMAILS_F ('TECH_SUP                                                                       
PORT');                                                                                                                             
	mySubj				varchar2(200);                                                                                                           
	myBody				varchar2(2000);                                                                                                          
                                                                                                                                    
	myDfltSubInv		varchar2(20) := 'CUST';                                                                                              
                                                                                                                                    
                                                                                                                                    
   /*************************************************                                                                               
***************************************************                                                                                 
    **********************************************                                                                                  
Private  *******************************************                                                                                
                                                                                                                                    
    *************************************************************************                                                       
***************************/                                                                                                        
                                                                                                                                    
   /**********************************************************************                                                          
****************/                                                                                                                   
                                                                                                                                    
   procedure LOG is                                                                                                                 
   begin                                                                                                                            
      if myLog = 'Y' then                                                                                                           
         myLogNum := myLogNum + 1;                                                                                                  
                                                                                                                                    
         insert into DEX_LOG                                                                                                        
        (USER_ID,PROGRAM,LOG_DATE,LOG_NUM,SECTION)                                                                                  
         values                                                                                                                     
        (0,'XXDEX_CISCO_K',SYSDATE,myLogNum,mySect);                                                                                
      end if;                                                                                                                       
                                                                                                                                    
      -- commit;                                                                                                                    
   end LOG;                                                                                                                         
                                                                                                                                    
   /********************************************************                                                                        
******************************/                                                                                                     
                                                                                                                                    
   procedure LOG_SET is                                                                                                             
   begin                                                                                                                            
      myLog := 'Y';                                                                                                                 
   end LOG_SET;                                                                                                                     
                                                                                                                                    
   /*************************************************                                                                               
*************************************/                                                                                              
                                                                                                                                    
   procedure LOG_UNSET is                                                                                                           
   begin                                                                                                                            
      myLog := 'N';                                                                                                                 
   end LOG_UNSET;                                                                                                                   
                                                                                                                                    
	/******************************************************************                                                                
****************************/                                                                                                       
	function FIND_ORGID_BY_CODE ( myOrgCd varchar2 ) return number is                                                                  
		myOrgId number;                                                                                                                   
	begin                                                                                                                              
		select ORGANIZATION_ID                                                                                                            
		into   myOrgID                                                                                                                    
		from   ORG_ORGANIZATION_DEFINITIONS                                                                                               
		where  ORGANIZATION_CODE = myOrgCd;                                                                                               
		return ( myOrgID );                                                                                                               
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			return (null);                                                                                                                   
	end FIND_ORGID_BY_CODE;                                                                                                            
                                                                                                                                    
	/****************************************************                                                                              
******************************************/                                                                                         
	procedure LOG_BUSINESS_EXCEPTION ( myEntityID	in varchar2                                                                          
											    ,myInvOrgID	in number                                                                                                
											    ,myErrMesg		in varchar2                                                                                              
											    ,myExceptName	in varchar2                                                                                            
											    ) is                                                                                                                 
                                                                                                                                    
		myInvOrgCd			ORG_ORGANIZATION_DEFINITIONS.ORGANIZATION_CODE%type;                                                                 
		myLogOrgId			number := myInvOrgId;                                                                                                
		myNEntityID			number;                                                                                                             
		myMessage			varchar2(500);                                                                                                        
	begin                                                                                                                              
		mySect := 'Log Bus Except - OrgCd';                                                                                               
		select ORGANIZATION_CODE                                                                                                          
		into   myInvOrgCd                                                                                                                 
		from   ORG_ORGANIZATION_DEFINITIONS                                                                                               
		where  ORGANIZATION_ID = nvl(myInvOrgID, XXDEX_DEFAULTS_F('DEFAULT_                                                               
PLANT'));                                                                                                                           
                                                                                                                                    
		begin                                                                                                                             
			myNEntityID := to_number(myEntityID);                                                                                            
		exception                                                                                                                         
			when OTHERS then                                                                                                                 
				myNEntityID := null;                                                                                                            
		end;                                                                                                                              
                                                                                                                                    
		myMessage := substr('InvOrg: ' || myInvOrgID || ' Entit                                                                           
y: ' || myEntityID || ' Error: ' || nvl(myErrMesg,my                                                                                
ExceptName),1,500);                                                                                                                 
                                                                                                                                    
		mySect := 'Log Bus Except - Log';                                                                                                 
		-- dbms_output.put_line('Log Bus Except Entity: ' || myEntityID || ' Or                                                           
gCd: ' || myInvOrgCd || ' Err: ' || myErrMesg || ' E                                                                                
xtpName: ' || myExceptName);                                                                                                        
		XXCTS_INV_UTL_PVT.LOG_EXCEPTION (                                                                                                 
													 p_logging_entity_id_i  => nvl(myNEntityID,0)                                                                          
													,p_logged_at_location_i => myInvOrgCd                                                                                  
  													,p_error_message_i      => myMessage                                                                                 
  													,p_exception_name_i     => myExceptName                                                                              
													);                                                                                                                     
	exception                                                                                                                          
		when NO_DATA_FOUND then                                                                                                           
				null;                                                                                                                           
	end LOG_BUSINESS_EXCEPTION;                                                                                                        
                                                                                                                                    
   /***************************************************************                                                                 
*********************************/                                                                                                  
                                                                                                                                    
   procedure GET_HOST_NAME is                                                                                                       
   begin                                                                                                                            
                                                                                                                                    
      select NAME                                                                                                                   
      into   myDBName                                                                                                               
      from   V$DATABASE;                                                                                                            
                                                                                                                                    
      myHost := f_dex_get_db_value('OV');                                                                                           
      -- dbms_output.put_line ( 'Host: ' || myHost);                                                                                
   end;                                                                                                                             
                                                                                                                                    
                                                                                                                                    
	/***************************************************************                                                                   
****************/                                                                                                                   
		-- Starts specific B2B                                                                                                            
	procedure RUN_B2B_TASK ( myFFHdrID 	pls_integer                                                                                    
									,myFFDataID	pls_integer default null                                                                                       
									) is                                                                                                                       
                                                                                                                                    
      mySuccess   varchar2(1);                                                                                                      
      myRetMesg   varchar2(1000);                                                                                                   
      myOutput    varchar2(255);                                                                                                    
                                                                                                                                    
      myRows      pls_integer;                                                                                                      
      myBytes     pls_integer;                                                                                                      
  	begin                                                                                                                            
  		if myFFDataID is not null then                                                                                                  
  			 P_DEX_RUNB2BTASKCTRL_JAVA (                                                                                                   
                      	              myFFHdrID      -- Task ID                                                                      
                      	             ,myFFDataID     -- Data ID                                                                      
                      	             ,-1             --                                                                              
 History ID                                                                                                                         
                      	             ,null           -- User Input                                                                   
                      	             ,'N'                                                                                            
-- Return Output                                                                                                                    
                      	             ,'N'            -- Use Ca                                                                       
ller Input                                                                                                                          
                      	             ,mySuccess                                                                                      
                      	             ,myRetMesg                                                                                      
                      	             ,myOutput                                                                                       
                      	             ,myRows                                                                                         
                      	             ,myBytes                                                                                        
                      	            );                                                                                               
		else                                                                                                                              
			P_DEX_RUNB2BTASK_JAVA (                                                                                                          
         	                     myFFHdrID      -- Tas                                                                                
k ID                                                                                                                                
         	                    ,-1             -- History ID                                                                         
         	                    ,null           -- User Input                                                                         
         	                    ,'N'            -- Return O                                                                           
utput                                                                                                                               
         	                    ,'N'            -- Use Caller Input                                                                   
         	                    ,mySuccess                                                                                            
         	                    ,myRetMesg                                                                                            
         	                    ,myOutput                                                                                             
         	                    ,myRows                                                                                               
         	                    ,myBytes                                                                                              
         	                   );                                                                                                     
  		end if;                                                                                                                         
                                                                                                                                    
      if mySuccess = 'N' then                                                                                                       
      	K_DEX_MAIL.SEND ( myOutEmail,'B2B Error Task: ' || myFFHdrID ||                                                              
 ' Dataid: ' ||myFFDataID, myRetMesg);                                                                                              
      end if;                                                                                                                       
	end RUN_B2B_TASK;                                                                                                                  
                                                                                                                                    
	/*******************************************************                                                                           
***********************************/                                                                                                
	function SHIP_INV_ORG_ID ( myShipID number) return number is                                                                       
		myInvOrgID number;                                                                                                                
	begin                                                                                                                              
		select max(ord.PLANT_ID)                                                                                                          
		into   myInvOrgID                                                                                                                 
		from   DEX_ORDERS ord                                                                                                             
				,DEX_SERIALS ser                                                                                                                
		where  ser.SHIP_ID = myShipID                                                                                                     
		and    ser.ORDERNO = ord.ORDERNO;                                                                                                 
		return ( myInvOrgID );                                                                                                            
	end SHIP_INV_ORG_ID;                                                                                                               
                                                                                                                                    
	/*****************************************************                                                                             
*************************************/                                                                                              
	function ITEM_SERL_CTRL ( myItemID number, myIOrgID number defau                                                                   
lt DEX_ORGANIZATIONS_K.MASTER_ID) return number is                                                                                  
		myCtrl number;                                                                                                                    
	begin                                                                                                                              
		begin                                                                                                                             
			select SERIAL_NUMBER_CONTROL_CODE                                                                                                
			into   myCtrl                                                                                                                    
			from   V_DEX_PART_DATA                                                                                                           
			where  INVENTORY_ITEM_ID = myItemID                                                                                              
			and    ORGANIZATION_iD   = myIOrgId;                                                                                             
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myCtrl := 5;                                                                                                                    
		end;                                                                                                                              
		return (myCtrl);                                                                                                                  
	end ITEM_SERL_CTRL;                                                                                                                
                                                                                                                                    
                                                                                                                                    
	/*******************************************************************                                                               
*************                                                                                                                       
	 Checks if Fault Code/Cause Code/Rep Arction Codes.                                                                                
	 *************************************************************                                                                     
******************/                                                                                                                 
	function VALIDATE_CODE ( myValSetName varchar2, myCode va                                                                          
rchar2 ) return varchar2 is                                                                                                         
		myValCode	varchar2(20) := null;                                                                                                   
	begin                                                                                                                              
		if myValSetname = 'DEX_FAIL_CODES_RESOLUTION' then                                                                                
			select FAIL_CODE                                                                                                                 
			into   myValCode                                                                                                                 
			from   DEX_FAIL_CODES                                                                                                            
			where  FAIL_TYPE = 'R'                                                                                                           
			and    ENABLED_FLAG = 'Y'                                                                                                        
			and    FAIL_CODE = myCode                                                                                                        
			and    rownum < 2;                                                                                                               
		else                                                                                                                              
			select FLEX_VALUE                                                                                                                
			into   myValCode                                                                                                                 
			from   V_DEX_FLEX_VALUES                                                                                                         
			where  FLEX_VALUE_SET_NAME = myValSetName                                                                                        
			and    FLEX_VALUE = myCode                                                                                                       
			and    rownum < 2;                                                                                                               
		end if;                                                                                                                           
                                                                                                                                    
		return ( myValCode );                                                                                                             
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			return ( null);                                                                                                                  
	end VALIDATE_CODE;                                                                                                                 
                                                                                                                                    
	/***************************************************                                                                               
*****************************                                                                                                       
	  Returns site use id for the address                                                                                              
	 ***********************************************************                                                                       
********************/                                                                                                               
	function FIND_SITE_USE ( myCustID		number                                                                                          
									,myOrigID		number                                                                                                          
									,mySiteUse		varchar2                                                                                                       
									,myStreet1		varchar2                                                                                                       
									,myCity			varchar2                                                                                                         
									,myZip			varchar2                                                                                                          
									) return number is                                                                                                         
                                                                                                                                    
		mySiteUseID number;                                                                                                               
	begin                                                                                                                              
		select S.SITE_USE_ID                                                                                                              
		into   mySiteUseId                                                                                                                
		from   XXDEX_SITE_USES_V s                                                                                                        
				,XXDEX_ADDRESSES_V a                                                                                                            
		where  a.CUSTOMER_ID = myCustID                                                                                                   
		and    upper(a.ADDRESS1) = upper(myStreet1)                                                                                       
		and    upper(a.CITY) = upper(myCity)                                                                                              
		and    a.POSTAL_CODE = myZip                                                                                                      
		and    a.ADDRESS_ID  = s.ADDRESS_ID                                                                                               
		and    s.SITE_USE_CODE = mySiteUse                                                                                                
		and    a.STATUS = 'A'                                                                                                             
      and    s.STATUS = 'A'                                                                                                         
		and    rownum < 2;                                                                                                                
		return ( mySiteUseID);                                                                                                            
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			return (null);                                                                                                                   
	end;                                                                                                                               
                                                                                                                                    
   /*************************************************************                                                                   
***************************************                                                                                             
    **********************************************  Global  ****                                                                    
***************************************                                                                                             
    ************************************************************                                                                    
****************************************/                                                                                           
	/************************************************************                                                                      
****************************************                                                                                            
	 	This procedure is execute by C3 B2B when an RMA Create Reque                                                                     
st (3A4) is received from an Authorized                                                                                             
	 	Partner.  If the RMA is successfully created, then a DEX RMA                                                                     
Nbr will be returned as an out parameter                                                                                            
			along with the Partners RMA.  If rejected, then the RMA Reje                                                                     
ct reasons will be returned and the                                                                                                 
		DEX RMA will be null.                                                                                                             
	*********************************************************************                                                              
*********************************/                                                                                                  
	procedure RMA_CREATE  ( myInvOrgID			in 	NUMBER                                                                                    
								  ,mySubInvCode		in 	VARCHAR2		-- (Optional)                                                                                
								  ,myRMAHeader			in 	XXDEX_CISCO_GLOBAL_K.RMA_HEADER_REC                                                                    
								  ,myRMADetails	  	in 	XXDEX_CISCO_GLOBAL_K.RMA_DE                                                                          
TAILS_TBL := XXDEX_CISCO_GLOBAL_K.INIT_RMA_DETAILS_T                                                                                
BL                                                                                                                                  
   							  ,myRMASerials		in 	XXDEX_CISCO_GLOBAL_K.RMA_SERIALS_TBL := XXDE                                                         
X_CISCO_GLOBAL_K.INIT_RMA_SERIALS_TBL                                                                                               
								  ,myRMANbr				out 	VARCHAR2		-- will be filled in only if                                                                  
 successfull                                                                                                                        
								  ,myPartnerRMA		out	VARCHAR2                                                                                               
								  ,myRMAErrors			out	XXDEX_CISCO_GLOBAL_K.RMA                                                                               
_ERRORS_TBL                                                                                                                         
								  ) is                                                                                                                      
                                                                                                                                    
	myRetCode		number;                                                                                                                 
	myRetMesg		varchar2(2000);                                                                                                         
                                                                                                                                    
	myBillRec		XXDEX_CISCO_GLOBAL_K.ADDRESS_REC;                                                                                       
	myShipRec		XXDEX_CISCO_GLOBAL_K.ADDRESS_REC;                                                                                       
	myWSerials 		XXDEX_GLOBAL_K.WARRANTY_TBL;                                                                                          
	myRMAList		XXDEX_PROCESS_K.RMA_TBL;                                                                                                
                                                                                                                                    
	myCust	 		XXDEX_CUSTOMERS_ALL_V.CUSTOMER_NUMBER%type;                                                                              
	myAgent			RMAHDR.AGENT%type;                                                                                                       
	myTLM				RMAHDR.TLM%type;                                                                                                          
	myCCOID			RMAHDR.CUST_NUMBER%type;			-- stors CCO ID                                                                               
	myOrdtype		RMAHDR.ORDTYPE%type;                                                                                                    
	myOrder			RMAHDR.ORDERNO%type;                                                                                                     
	myContract		RMAHDR.CONTRACT%type;                                                                                                  
	myShipName  	RMAHDR.SHIP_NAME%type;                                                                                                
	myShipAttn  	RMAHDR.SHIP_ATTN%type;                                                                                                
	myShipSt1   	XXDEX_ADDRESSES_V.ADDRESS1%type;                                                                                      
	myShipSt2   	XXDEX_ADDRESSES_V.ADDRESS2%type;                                                                                      
	myShipCity  	XXDEX_ADDRESSES_V.CITY%type;                                                                                          
	myShipState 	XXDEX_ADDRESSES_V.STATE%type;                                                                                         
	myShipZip   	XXDEX_ADDRESSES_V.POSTAL_CODE%type;                                                                                   
	myCountry   	XXDEX_ADDRESSES_V.COUNTRY%type;                                                                                       
	myProvince  	XXDEX_ADDRESSES_V.PROVINCE%type;                                                                                      
	myCustPO			RMAHDR.CUSTPO%type;                                                                                                     
	myEmail			RMAHDR.NOTIFY_EMAIL%type;                                                                                                
	myTelephone 	RMAHDR.TELEPHONE%type;                                                                                                
	myShipVia		XXDEX_CARRIER_ORGS_V.SERVICE_CODE%type;                                                                                 
	myParentCode 	XXDEX_CUSTOMERS_ALL_V.PARENT_CODE%type;                                                                              
	myPlant			DEX_PLANTS.PLANT%type;                                                                                                   
	myPriceTypeCd	RMAHDR.PRICE_TYPE_CODE%type;                                                                                         
	myPartialShp	RMAHDR.PARTIAL_SHP%type;                                                                                              
	myCall			RMAHDR.CALL%type;                                                                                                         
	myStatus			RMAHDR.STATUS%type;                                                                                                     
	myAuthorization	RMAHDR.AUTHORIZATION%type;                                                                                         
	myInvMgmt		varchar2(1);                                                                                                            
	mySerCtrl		varchar2(1);                                                                                                            
	myHComments		RMAHDR.COMMENTS%type;                                                                                                 
	myCustExch		RMAHDR.CUST_EXCHANGE%type;                                                                                             
	myLComments		RMADET.COMMENTS%type;                                                                                                 
	myDescr			V_DEX_PART_DATA.DESCRIPTION%type;                                                                                        
	mySerial			RMA_SERIALS.SERIAL%type;                                                                                                
	myAction			varchar2(1);                                                                                                            
	myDate			date;                                                                                                                     
                                                                                                                                    
	myShipUseID		number;                                                                                                               
	myBillUseID		number;                                                                                                               
	myOrgID	  		number;                                                                                                                
	myPOrgID	  		number;                                                                                                               
	myCustID			number;                                                                                                                 
	myShipTo			number;                                                                                                                 
	myOutRepID		number;                                                                                                                
	myInRepId		number;                                                                                                                 
	myLineId			number;                                                                                                                 
	myItem			number;                                                                                                                   
	myCustItem		number;                                                                                                                
	myQtyOrg			pls_integer;                                                                                                            
	mySerCnt			number;                                                                                                                 
	mySerInsCnt 	number;                                                                                                               
	myRMASerID  	number;                                                                                                               
                                                                                                                                    
	myLineCnt		number;                                                                                                                 
	myEdx				number := 0;                                                                                                              
	myWdx				number := 0;                                                                                                              
                                                                                                                                    
	myPart			V_DEX_PART_DATA.ITEM_NUMBER%type;                                                                                         
	myItemID			number;                                                                                                                 
   myDesc      	V_DEX_PART_DATA.DESCRIPTION%type;                                                                                   
   myMfg       	V_DEX_PART_DATA.OEM%type;                                                                                           
   myCItemId   	pls_integer;                                                                                                        
   myGrpID     	pls_integer;                                                                                                        
   myGrp       	RMADET.GRP%type;                                                                                                    
                                                                                                                                    
	myDfltCurrCode RMAHDR.CURRENCY_CODE%type;                                                                                          
	myCurrCode		RMAHDR.CURRENCY_CODE%type;                                                                                             
   myCustPart		RMADET.CUSTPART%type;                                                                                                
	mySchdDate		date;                                                                                                                  
	myStatCode		varchar2(1);                                                                                                           
	myPrice			number;                                                                                                                  
	myRtnRMAFlag   varchar2(1) := 'N';                                                                                                 
	myRMAOrd			number;                                                                                                                 
	myPlantId		number;                                                                                                                 
	myRepPlantId	pls_integer;                                                                                                          
	myIOrgId			pls_integer;                                                                                                            
	myMastOrg		varchar2(1);                                                                                                            
	myDEXFlag		varchar2(1);                                                                                                            
	myActive			varchar2(1);                                                                                                            
	myIntRMA			varchar2(1);                                                                                                            
	myDropShip		varchar2(1);                                                                                                           
	myCustLoad		varchar2(1);                                                                                                           
                                                                                                                                    
	myUserID			number := nvl(F_DEX_USER_ID,0);                                                                                         
                                                                                                                                    
	LINE_ERROR		EXCEPTION;                                                                                                             
	ABORT_PROC 		EXCEPTION;                                                                                                            
                                                                                                                                    
                                                                                                                                    
	procedure PUSH_ERROR is                                                                                                            
	begin                                                                                                                              
		myEdx := myEdx + 1;                                                                                                               
		-- dbms_output.put_line('push err: ' || myEdx || ' Err:                                                                           
 ' || myRetMesg);                                                                                                                   
		myRMAErrors(myEdx).PARTNER_RMA_NBR := myPartnerRMA;                                                                               
		myRMAErrors(myEdx).LINE_ID := myLineID;                                                                                           
		myRMAErrors(myEdx).PARTNER_LINE_NBR := myCustItem;                                                                                
		myRMAErrors(myEdx).ERROR_MESSAGE := myRetMesg;                                                                                    
                                                                                                                                    
	end PUSH_ERROR;                                                                                                                    
                                                                                                                                    
	begin                                                                                                                              
		SAVEPOINT RMACREATE_SAVEPOINT;                                                                                                    
                                                                                                                                    
		myUserID  := XXDEX_CISCO_GLOBAL_K.B2B_USERID;                                                                                     
                                                                                                                                    
                                                                                                                                    
		mySect := 'RMA Create - Set Vars';                                                                                                
		myShipRec := myRMAHeader.SHIP_TO_ADDRESS;                                                                                         
		myBillRec := myRMAHeader.BILL_TO_ADDRESS;                                                                                         
		myShipAttn := myShipRec.CONTACT_NAME;                                                                                             
		myEmail	  := myShipRec.EMAIL_ADDR;                                                                                                
		myTelephone := myShipRec.PHONE_NBR;                                                                                               
		myPriceTypeCd := myRMAHeader.ORDER_REASON_CD;                                                                                     
		myOrdType := myRMAHeader.ORDER_TYPE;                                                                                              
		myShipVia := myRMAHeader.SHIP_METHOD;                                                                                             
		myCCOID := myRMAHeader.CCO_ID;                                                                                                    
		myContract := myRMAHeader.CONTRACT_NBR;                                                                                           
		myAction	  := myRMAHeader.ACTION_CODE;                                                                                            
		myDate	  := myRMAHeader.ACTION_DATE;                                                                                              
		myCustPO   := myRMAHeader.PARTNER_RMA_NBR;                                                                                        
		myShipVia  := myRMAHeader.SHIP_METHOD;                                                                                            
		myHComments := myRMAHeader.COMMENTS;                                                                                              
		myAuthorization  := myRMAHeader.AUTHORIZATION;                                                                                    
		myIntRMA	  := nvl(myRMAHeader.INTERNAL_RMA_IND,'N');                                                                              
		myPartnerRMA := myCustPO;                                                                                                         
                                                                                                                                    
                                                                                                                                    
		if nvl(myAction,'x') not in ('N','U','C') then                                                                                    
			myRetMesg := 'Invalid Header Action Code: ' || myAction;                                                                         
			raise ABORT_PROC;                                                                                                                
		end if;                                                                                                                           
		if nvl(myOrdType,'x') not in ('R','S') then                                                                                       
			myRetMesg := 'Invalid Order Type: ' || myOrdType;                                                                                
			raise ABORT_PROC;                                                                                                                
		end if;                                                                                                                           
                                                                                                                                    
		-- dbms_output.put_line('RMA Create Partner RMA: '                                                                                
 || myCustpo || ' AuthRMA: ' || myAuthorization || '                                                                                
 PlantID: ' || myInvOrgID);                                                                                                         
		mySect := 'RMA Create - Plant';                                                                                                   
		begin                                                                                                                             
			myPlantId := myInvOrgID;                                                                                                         
			select ORG_ID                                                                                                                    
					,PLANT                                                                                                                         
					,CURRENCY_CODE                                                                                                                 
			into   myOrgID                                                                                                                   
					,myPlant                                                                                                                       
					,myDfltCurrCode                                                                                                                
			from   DEX_PLANTS                                                                                                                
			where  PLANT_ID = myPlantId;                                                                                                     
			myPOrgID := myOrgID;                                                                                                             
                                                                                                                                    
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRetMesg := 'Invalid Inventory Org ID (' || myInvORgID || ')';                                                                 
				raise ABORT_PROC;                                                                                                               
		end;                                                                                                                              
                                                                                                                                    
		mySect := 'RMA Create - Org ID';                                                                                                  
		myMastOrg :=  XXDEX_DEFAULTS_F ('RMA_MASTER_ORG', myPlantId);                                                                     
		if myMastOrg = 'Y' then                                                                                                           
			myIOrgID := DEX_ORGANIZATIONS_K.MASTER_ID;                                                                                       
		else                                                                                                                              
			myIOrgID := DEX_ORGANIZATIONS_K.BUS_TYPE(myPlantId, 'R                                                                           
');                                                                                                                                 
		end if;                                                                                                                           
		myCustLoad := nvl(XXDEX_DEFAULTS_F('CUST_DYNAMIC_LOAD',myOrgID                                                                    
),'N');                                                                                                                             
                                                                                                                                    
		mySect := 'RMA Create - Cust';                                                                                                    
		begin                                                                                                                             
			myCust := myRMAHeader.CUSTOMER_NUMBER;                                                                                           
			select CUSTOMER_ID                                                                                                               
					,OUTSIDE_SALESREP_ID                                                                                                           
					,OUTSIDE_SALESREP_NUMBER                                                                                                       
					,INSIDE_SALESREP_ID                                                                                                            
					,INSIDE_SALESREP_NUMBER                                                                                                        
					,PARENT_CODE                                                                                                                   
					,nvl(ADVREP_FLAG,'N')                                                                                                          
					,CUSTOMER_NAME                                                                                                                 
					,nvl(myShipVia,SHIP_VIA)                                                                                                       
					,SHIP_PARTIAL                                                                                                                  
			into   myCustID                                                                                                                  
					,myOutRepID                                                                                                                    
					,myAgent                                                                                                                       
					,myInRepId                                                                                                                     
					,myTLM                                                                                                                         
					,myParentCode                                                                                                                  
					,myInvMgmt                                                                                                                     
					,myShipName                                                                                                                    
					,myShipVia                                                                                                                     
					,myPartialShp                                                                                                                  
			from   XXDEX_CUSTOMERS_ALL_V                                                                                                     
			where  CUSTOMER_NUMBER = myCust                                                                                                  
			and    ORG_ID = myOrgID                                                                                                          
			and    rownum < 2;                                                                                                               
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
					myCustID := null;                                                                                                              
					begin                                                                                                                          
						select CUSTOMER_ID                                                                                                            
								,CUSTOMER_NAME                                                                                                              
								,SHIP_VIA                                                                                                                   
						into   myCustID                                                                                                               
								,myShipName                                                                                                                 
								,myShipVia                                                                                                                  
						from   XXDEX_PARTIES_V                                                                                                        
						where  CUSTOMER_NUMBER = myCust;                                                                                              
					exception                                                                                                                      
						when NO_DATA_FOUND then                                                                                                       
								myCustID := null;                                                                                                           
					end;                                                                                                                           
		end;                                                                                                                              
		if myCustID is null then                                                                                                          
				myRetMesg := 'Invalid Customer Number: ' || myCust || ' OrgI                                                                    
D: ' || myOrgID;                                                                                                                    
				raise ABORT_PROC;                                                                                                               
		end if;                                                                                                                           
                                                                                                                                    
		if F_DEX_CUST_CTRL ( myCustID,'RED',myOrgID,'T' ) =                                                                               
'Y' then                                                                                                                            
			myRetMesg := 'Customer has been blocked from Creating RMAs';                                                                     
			raise ABORT_PROC;                                                                                                                
		end if;                                                                                                                           
                                                                                                                                    
		if myCCOID is null then                                                                                                           
			myRetMesg := 'CCO ID is required.';                                                                                              
			raise ABORT_PROC;                                                                                                                
		end if;                                                                                                                           
                                                                                                                                    
		if myPriceTypeCd is null then                                                                                                     
			myPriceTypeCd := F_DEX_CUST_CTRL(myCustID, 'DPL',                                                                                
 myOrgID, 'D');                                                                                                                     
			-- dbms_output.put_line('Ord Reasn CustID: ' || myCustID ||                                                                      
 ' Orgid: ' || myOrgID || ' TypCd: ' || myPriceTypeC                                                                                
d);                                                                                                                                 
			if myPriceTypeCd is null then                                                                                                    
				-- use template                                                                                                                 
				myPriceTypeCd := F_DEX_CUST_CTRL(0, 'DPL', myOrgID, 'D');                                                                       
				-- dbms_output.put_line('Ord Reasn CustID: ' || 0 || ' Orgi                                                                     
d: ' || myOrgID || ' TypCd: ' || myPriceTypeCd);                                                                                    
			end if;                                                                                                                          
			if myPriceTypeCd is null then                                                                                                    
				myRetMesg := 'Order Reason Code not specified and no Defaul                                                                     
t setup for Customer';                                                                                                              
				raise ABORT_PROC;                                                                                                               
			end if;                                                                                                                          
		end if;                                                                                                                           
                                                                                                                                    
		mySect := 'RMA Create - Partial Ship Control';                                                                                    
		begin                                                                                                                             
			select SEGMENT1                                                                                                                  
         into   myPartialShp                                                                                                        
         from   DEX_CUSTOMER_CONTROL                                                                                                
         where  CUSTOMER_ID = myCustID                                                                                              
         and    ORG_ID      = myOrgID                                                                                               
         and    TYPE        = 'PSA'                                                                                                 
         and    DATA        = myOrdType;                                                                                            
      exception                                                                                                                     
      	when NO_DATA_FOUND then                                                                                                      
      		null;                                                                                                                       
      end;                                                                                                                          
                                                                                                                                    
		mySect := 'RMA Create - Currency Code';                                                                                           
		myCurrCode := F_DEX_CUST_CTRL ( myCustID,'DCC',myOrgID,'D' );                                                                     
		if myCurrCode is null then                                                                                                        
			myCurrCode := nvl(F_DEX_CUST_CTRL ( 0,'DCC',myOrgI                                                                               
D,'D' ), myDfltCurrCode);			-- Template                                                                                             
		end if;                                                                                                                           
                                                                                                                                    
		mySect := 'RMA Create - Find Ship To';                                                                                            
		-- dbms_output.put_line('Ship To UseID: ' || myShipRec.SITE_US                                                                    
E_ID || ' CustID: ' || myCustID || ' OrgID: ' || myO                                                                                
rgID || ' Street: ' ||myShipRec.STREET1 || ' City: '                                                                                
 ||myShipRec.CITY || ' Zip: ' || myShipRec.POSTAL_CO                                                                                
DE);                                                                                                                                
		myShipUseID := myShipRec.SITE_USE_ID;                                                                                             
                                                                                                                                    
		if myShipUseID is null then                                                                                                       
			myShipUseID := FIND_SITE_USE ( myCustID	=> myCustID                                                                              
                                                                                                                                    
													,myOrigID	=> myOrgID                                                                                                   
													,mySiteUse	=> 'SHIP_TO'                                                                                                
													,myStreet1	=> myShipRec.STREET1                                                                                        
													,myCity		=> myShipRec.CITY                                                                                             
													,myZip		=> myShipRec.POSTAL_CODE                                                                                       
													);                                                                                                                     
		end if;                                                                                                                           
                                                                                                                                    
		mySect := 'RMA Create - Ship To (' || myShipUseID || '                                                                            
)';                                                                                                                                 
		begin                                                                                                                             
			select SITE_USE_ID                                                                                                               
					,substr(ADDRESS1,1,60)                                                                                                         
					,substr(ADDRESS2,1,60)                                                                                                         
					,substr(CITY,1,20)                                                                                                             
					,substr(decode(COUNTRY,'US',STATE,'XX'),1,2)                                                                                   
					,substr(POSTAL_CODE,1,10)                                                                                                      
					,substr(COUNTRY,1,2)                                                                                                           
					,substr(nvl(PROVINCE,STATE),1,60)                                                                                              
			into   myShipUseID                                                                                                               
					,myShipSt1                                                                                                                     
					,myShipSt2                                                                                                                     
					,myShipCity                                                                                                                    
					,myShipState                                                                                                                   
					,myShipZip                                                                                                                     
					,myCountry                                                                                                                     
					,myProvince                                                                                                                    
			from   XXDEX_CUSTOMERS_SHIP_V                                                                                                    
			where  SITE_USE_ID = myShipUseID                                                                                                 
			and    CUSTOMER_ID = myCustID;                                                                                                   
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRetMesg := 'Invalid Ship To Site (' || myShipUseID |                                                                          
| ') for Cust: ' || myCust;                                                                                                         
				raise ABORT_PROC;                                                                                                               
		end;                                                                                                                              
                                                                                                                                    
		if myIntRMA = 'Y' then                                                                                                            
			mySect := 'RMA Create - Int RMA Addr';                                                                                           
			-- get address from Ship Rcd                                                                                                     
			myShipSt1    := myShipRec.STREET1;                                                                                               
   		myShipSt2    := myShipRec.STREET2;                                                                                             
   		myShipCity   := myShipRec.CITY;                                                                                                
   		myShipState  := myShipRec.STATE;                                                                                               
   		myShipZip    := myShipRec.POSTAL_CODE;                                                                                         
   		myCountry    := myShipRec.COUNTRY;                                                                                             
   		myProvince	 := myShipRec.PROVINCE;                                                                                             
                                                                                                                                    
			mySect := 'RMA Create - Int RMA Authorization';                                                                                  
   		begin                                                                                                                          
   			select SHIP_NAME                                                                                                              
   					,CUST                                                                                                                       
   			into   myShipName                                                                                                             
   					,myCustExch                                                                                                                 
   			from   DEX_ORDERS                                                                                                             
   			where  ORDERNO	= myAuthorization;                                                                                             
			exception                                                                                                                        
				when NO_DATA_FOUND then                                                                                                         
					null;                                                                                                                          
   		end;                                                                                                                           
		end if;                                                                                                                           
		myDropShip := myIntRMA;                                                                                                           
                                                                                                                                    
		mySect := 'RMA CReate - Bill To';                                                                                                 
		myBillUseID := myBillRec.SITE_USE_ID;                                                                                             
		if myBillUseID is null then                                                                                                       
			myBillUseID := FIND_SITE_USE ( myCustID	=> myCustID                                                                              
													,myOrigID	=> myOrgID                                                                                                   
													,mySiteUse	=> 'BILL_TO'                                                                                                
													,myStreet1	=> myBillRec.STREET1                                                                                        
													,myCity		=> myBillRec.CITY                                                                                             
													,myZip		=> myBillRec.POSTAL_CODE                                                                                       
													);                                                                                                                     
		end if;                                                                                                                           
		begin                                                                                                                             
			select SITE_USE_ID                                                                                                               
					,ORG_ID                                                                                                                        
			into   myBillUseID                                                                                                               
					,myOrgID                                                                                                                       
			from   XXDEX_CUSTOMERS_BILL_V                                                                                                    
			where  SITE_USE_ID = myBillUseID                                                                                                 
			and    CUSTOMER_ID = myCustID;                                                                                                   
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRetMesg := 'Invalid Bill To Site (' || myBillUs                                                                               
eID || ') for Cust: ' || myCust;                                                                                                    
				raise ABORT_PROC;                                                                                                               
		end;                                                                                                                              
                                                                                                                                    
		if myShipVia is not null then                                                                                                     
			begin                                                                                                                            
				select 0                                                                                                                        
				into   myShipTo                                                                                                                 
				from   XXDEX_CARRIER_ORGS_V                                                                                                     
				where  SERVICE_CODE = myShipVIa                                                                                                 
				and    ORG_ID = myPOrgID;                                                                                                       
			exception                                                                                                                        
				when NO_DATA_FOUND then                                                                                                         
					myRetMesg := 'Invalid Shipping Method (' || myShipVia ||                                                                       
')';                                                                                                                                
					raise ABORT_PROC;                                                                                                              
			end;                                                                                                                             
		end if;                                                                                                                           
                                                                                                                                    
		begin                                                                                                                             
			select TYPE                                                                                                                      
			into   myPriceTypeCd                                                                                                             
			from   V_DEX_PRICE_LIST_TYPES                                                                                                    
			where  TYPE		 = myPriceTypeCd;                                                                                                   
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRetMesg := 'Invalid Order Reason Code (' || myPriceTyp                                                                        
eCd || ')';                                                                                                                         
				raise ABORT_PROC;                                                                                                               
		end;                                                                                                                              
                                                                                                                                    
		begin                                                                                                                             
			mySect := 'Create RMA - Find RMA';                                                                                               
			select CALL                                                                                                                      
					,STATUS                                                                                                                        
			into   myCall                                                                                                                    
					,myStatus                                                                                                                      
			from   XXDEX_RMAHDR_ALL_V                                                                                                        
			where  CUST = myCust                                                                                                             
			and    PLANT_ID = myPlantID                                                                                                      
			and    CUSTPO = myCustPO                                                                                                         
			and    ROWNUM < 2;                                                                                                               
                                                                                                                                    
			-- July 2010: Error out if RMA Already exists for Pl                                                                             
ant and Custpo (Auth's RMA)                                                                                                         
			myRetMesg := 'RMA (' || myCall || ') already exists for Partner RMA:'  ||                                                        
 myCustPO;                                                                                                                          
			raise ABORT_PROC;                                                                                                                
			/*                                                                                                                               
			if myStatus != 'P' then                                                                                                          
				myRetMesg := 'RMA Status is Open. No Update are allowed.';                                                                      
				raise ABORT_PROC;                                                                                                               
                                                                                                                                    
			elsif myAction = 'N' then                                                                                                        
				myRetMesg := 'RMA (' || myCall || ') already exist                                                                              
s for Partner RMA:'  || myCustPO;                                                                                                   
				raise ABORT_PROC;                                                                                                               
			end if;                                                                                                                          
			*/                                                                                                                               
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				if myAction in ('U','C') then                                                                                                   
					myRetMesg := 'RMA Not found for Partner RMA: ' || myCustP                                                                      
O || '. Cannot perform Update/Cancel Action.';                                                                                      
					raise ABORT_PROC;                                                                                                              
				end if;                                                                                                                         
		end;                                                                                                                              
		if myCall is null then                                                                                                            
			myCall := F_PREBOOK_CHECK;                                                                                                       
			mySect := 'Create RMA - Insert RMAHDR';                                                                                          
                                                                                                                                    
			-- dbms_output.put_line('insert rmahdr: ' || myCall || ' plantid: ' |                                                            
| myPlantId);                                                                                                                       
			insert into DEX_RMAHDR (                                                                                                         
	 		 CALL,PLANT,PLANT_ID,ORG_ID,STATUS,CUST,CUSTOMER_ID,ORDTYP                                                                      
E,CUSTPO,RELEASE,ORDER_SOURCE                                                                                                       
			,CREATION_DATE,BILL_SITE_USE_ID,SHIP_SITE_USE_ID,LAST_UPDATE_DATE,LAST_                                                          
UPDATED_BY,CREATED_BY                                                                                                               
			,SHIPTO,DROP_SHIP,SHIP_VIA,SHIP_NAME,SHIP_ATTN,SHIP_S                                                                            
T1,SHIP_ST2,SHIP_CITY,SHIP_STATE,SHIP_ZIP                                                                                           
			,PROVINCE,COUNTRY,PRICE_TYPE_CODE,CUST_EXCHANGE,CREDIT_CARD                                                                      
_METHOD                                                                                                                             
			,OUTSIDE_SALESREP_ID,INSIDE_SALESREP_ID,AGENT,TLM,AUTHORIZATION,PAR                                                              
TIAL_SHP                                                                                                                            
			,CONTRACT,CUST_NUMBER,NOTIFY_EMAIL,TELEPHONE,ATTRIBUTE_CATEGORY                                                                  
			,CURRENCY_CODE,EXCHANGE_RATE_DATE                                                                                                
			) values (                                                                                                                       
			 myCall,myPlant,myPlantId,myOrgID,'P',myCust,myCustI                                                                             
D,myOrdType,myCustPO,to_char(SYSDATE,'DD-MON-YYYY HH                                                                                
24:MI:SS'),'C3'                                                                                                                     
			,SYSDATE,myBillUseID,myShipUseID,SYSDATE,myUserId,myUserID                                                                       
		   ,myShipTo,myDropShip,myShipVia,myShipName,myShi                                                                                
pAttn,myShipSt1,myShipSt2,myShipCity,myShipState,myS                                                                                
hipZip                                                                                                                              
		   ,myProvince,myCountry,myPriceTypeCd,myCustExch,'N'                                                                             
		   ,myOutRepID,myInRepID,myAgent,myTLM,myAuthorization,myPartialS                                                                 
hp                                                                                                                                  
		   ,myContract,myCCOID,myEmail,myTelephone,myParentCode                                                                           
		   ,myCurrCode,trunc(SYSDATE)                                                                                                     
		   );                                                                                                                             
                                                                                                                                    
		elsif myAction = 'U' then                                                                                                         
			mySect := 'Create RMA - Update RMAHDR';                                                                                          
			update DEX_RMAHDR set                                                                                                            
			 BILL_SITE_USE_ID = myBillUseID                                                                                                  
			,SHIP_SITE_USE_ID = myShipUseID                                                                                                  
			,LAST_UPDATE_DATE = SYSDATE                                                                                                      
			,LAST_UPDATED_BY  = myUserID                                                                                                     
			,SHIPTO = myShipTo                                                                                                               
			,SHIP_VIA = myShipVia                                                                                                            
			,SHIP_NAME = myShipName                                                                                                          
			,SHIP_ATTN = myShipAttn                                                                                                          
			,SHIP_ST1 = myShipSt1                                                                                                            
			,SHIP_ST2 = myShipSt2                                                                                                            
			,SHIP_CITY = myShipCity                                                                                                          
			,SHIP_STATE = myShipState                                                                                                        
			,SHIP_ZIP = myShipZip                                                                                                            
			,PROVINCE = myProvince                                                                                                           
			,COUNTRY = myCountry                                                                                                             
			,PRICE_TYPE_CODE = myPriceTypeCd                                                                                                 
			,NOTIFY_EMAIL = myEmail                                                                                                          
			,TELEPHONE = myTelephone                                                                                                         
			 where CALL = myCall;                                                                                                            
                                                                                                                                    
		elsif myAction = 'C' then                                                                                                         
			mySect := 'Create RMA - Cancel RMAHDR';                                                                                          
			update RMAHDR set                                                                                                                
			STATUS = 'N'                                                                                                                     
		  ,LAST_UPDATE_DATE = SYSDATE                                                                                                     
		  ,LAST_UPDATED_BY  = myUserID                                                                                                    
		   where CALL = myCall;                                                                                                           
		end if;                                                                                                                           
                                                                                                                                    
		mySect := 'Create RMA - Detail';                                                                                                  
                                                                                                                                    
		myLineCnt := myRMADetails.COUNT;                                                                                                  
		for i in 1 .. myLineCnt loop                                                                                                      
			begin                                                                                                                            
				mySect := 'Create RMA - Det Vars';                                                                                              
				myLineID := myRMADetails(i).LINE_ID;                                                                                            
				myCustItem := myRMADetails(i).PARTNER_LINE_NBR;                                                                                 
				myPart   := myRMADetails(i).PART_NUMBER;                                                                                        
				myItemID := F_DEX_ITEM_ID(myPart);                                                                                              
				myAction	:= myRMADetails(i).ACTION_CODE;                                                                                        
				myQtyOrg	:= myRMADetails(i).QUANTITY;                                                                                           
				myStatCode := myRMADetails(i).STAT_CODE;                                                                                        
				mySchdDate := myRMADetails(i).SCHEDULE_DATE;                                                                                    
				myLComments := myRMADetails(i).COMMENTS;                                                                                        
                                                                                                                                    
				if nvl(myRMADEtails(i).ORDER_REASON_CD,myPriceTypeCd) != myPri                                                                  
ceTypeCd then                                                                                                                       
					myRetMesg := 'Line Reason Code doesn match Order Reason Cod                                                                    
e';                                                                                                                                 
					raise LINE_ERROR;                                                                                                              
				end if;                                                                                                                         
                                                                                                                                    
				if nvl(myQtyOrg,0) = 0 then                                                                                                     
					myRetMesg := 'Line Quantity (' || myQtyOrg || ') must                                                                          
 be greater than 0';                                                                                                                
					raise LINE_ERROR;                                                                                                              
				end if;                                                                                                                         
                                                                                                                                    
				if nvl(myAction,'x') not in ('N','U','C') then                                                                                  
					myRetMesg := 'Invalid Line Action Code: ' || myAction;                                                                         
					raise ABORT_PROC;                                                                                                              
				end if;                                                                                                                         
                                                                                                                                    
				mySect := 'Create RMA - Find DET Item';                                                                                         
                                                                                                                                    
				begin                                                                                                                           
					select ITEM                                                                                                                    
					into   myItem                                                                                                                  
					from   DEX_RMADET                                                                                                              
					where	 CALL = myCall                                                                                                           
					and    CUSTITEM = myCustItem                                                                                                   
					and    rownum < 2;                                                                                                             
					if myAction = 'N' then                                                                                                         
						myRetMesg := 'Line Number: ' || myCustItem || ' already ex                                                                    
ists on RMA.  Cannot add as new.';                                                                                                  
						raise LINE_ERROR;                                                                                                             
					end if;                                                                                                                        
				exception                                                                                                                       
					when NO_DATA_FOUND then                                                                                                        
						if myAction in ('U','C') then                                                                                                 
							myRetMesg := 'Line Number: ' || myCustItem || ' no                                                                           
t found on RMA.  Cannot update or cancel.';                                                                                         
							raise LINE_ERROR;                                                                                                            
						end if;                                                                                                                       
				end;                                                                                                                            
                                                                                                                                    
				mySect := 'Create RMA - Find Part';                                                                                             
				begin                                                                                                                           
			 		select substr(DESCRIPTION,1,80)                                                                                               
	  						,GROUP_ID                                                                                                                  
	    					,nvl(GRP,'EVL')                                                                                                           
		    				,OEM                                                                                                                      
		    				,ACTIVE_FLAG                                                                                                              
		    				,DEX_ITEM_DATA_FLAG                                                                                                       
					into 	 myDescr                                                                                                                 
		      			,myGrpID                                                                                                                 
	   					,myGrp                                                                                                                     
	    					,myMfg                                                                                                                    
	    					,myActive                                                                                                                 
	    					,myDEXFlag                                                                                                                
					from   V_DEX_PART_DATA                                                                                                         
					where  INVENTORY_ITEM_ID = myItemID                                                                                            
					and    ORGANIZATION_ID   = myIOrgID;                                                                                           
				exception                                                                                                                       
					when NO_DATA_FOUND then                                                                                                        
						myRetMesg := 'Part: ' || myPart || ' Not Found.';                                                                             
						raise LINE_ERROR;                                                                                                             
				end;                                                                                                                            
                                                                                                                                    
                                                                                                                                    
	         if myActive != 'Y' then                                                                                                   
   	         myRetMesg := 'Part: ' || myPart || ' is Inactive' ;                                                                    
   	         raise LINE_ERROR;                                                                                                      
                                                                                                                                    
      	   elsif myDEXFlag = 'N' and XXDEX_DEFAULTS_F ( 'ITEM_DYNAMIC_LOAD'                                                          
 ) = 'Y' then                                                                                                                       
         	   begin                                                                                                                  
               	select GROUP_ID                                                                                                     
                  	   ,GRP                                                                                                          
                     	,OEM                                                                                                          
   	            into   myGrpID                                                                                                      
      	               ,myGrp                                                                                                        
         	            ,myMfg                                                                                                        
               	from   XXDEX_ITEM_DATA_TEMPLATE_V                                                                                   
               	where  ORGANIZATION_ID   = myIOrgID;                                                                                
                                                                                                                                    
            	exception                                                                                                              
               	when NO_DATA_FOUND then                                                                                             
                  	myRetMesg := 'Template Not Found for Organizatio                                                                 
n (' || to_char(myIOrgID) || ')';                                                                                                   
                  	raise LINE_ERROR;                                                                                                
            	end;                                                                                                                   
         	end if;                                                                                                                   
                                                                                                                                    
                                                                                                                                    
				mySect := 'Create RMA - Det Price';                                                                                             
				myPrice := F_DEX_PRICE(myItemID,myCustID,myPriceTypeCd,                                                                         
myCurrCode);                                                                                                                        
				myItem := myItem + 1;                                                                                                           
                                                                                                                                    
				mySect := 'Create RMA - Set Repair Org';                                                                                        
				XXDEX_PROCESS_K.REPAIR_ROUTING ( myRetCode		=> myRetCode                                                                        
									  					  ,myRetMesg		=> myRetMesg                                                                                          
									  					  ,myRepPlantId	=> myRepPlantId                                                                                     
									  					  ,myOrdType		=> myOrdtype                                                                                          
									  					  ,myRetPlantID	=> myPlantId                                                                                        
									  					  ,myReasonCd		=> myPriceTypeCd                                                                                     
								  						  ,myItemId			=> myItemID                                                                                           
								  						  );                                                                                                                
                                                                                                                                    
				if myRetCode != 0 then                                                                                                          
					raise LINE_ERROR;                                                                                                              
				end if;                                                                                                                         
                                                                                                                                    
				if myAction = 'N' then                                                                                                          
					mySect := 'Create RMA - Insert RMADET';                                                                                        
					-- dbms_output.put_line('insert rmadet: ' || my                                                                                
Call || ' Item: ' || myItem);                                                                                                       
				   select nvl(max(ITEM),0) + 1                                                                                                  
				   into   myItem                                                                                                                
				   from   DEX_RMADET                                                                                                            
				   where  CALL = myCall;                                                                                                        
                                                                                                                                    
			      insert into DEX_RMADET (                                                                                                   
					 CALL,ITEM,DATEDET,CUSTITEM,PART,CUSTPART,DESCR,STATCO                                                                         
DE                                                                                                                                  
					,GRP,OEM,STATUS,QTYORG,PRICE,STORE,INV_MGMT,DATESCH,ORGANIZATION_ID,RE                                                         
PAIR_PLANT_ID                                                                                                                       
					,SUBINVENTORY_CODE,CUSTOMER_ITEM_ID,INVENTORY_ITEM_ID,GROUP                                                                    
_ID,CORE_FLAG                                                                                                                       
					,ECHELON,ATTRIBUTE_CATEGORY                                                                                                    
					 ) values (                                                                                                                    
					  myCall,myItem,SYSDATE,myCustItem,myPart,myCustPart,myDescr,                                                                  
nvl(myStatCode,'N')                                                                                                                 
					 ,myGrp,myMfg,'O',myQtyOrg,nvl(myPrice,0),'R',myInvMg                                                                          
mt,nvl(mySchdDate,add_months(trunc(SYSDATE),1)),myIO                                                                                
rgID,myRepPlantId                                                                                                                   
					 ,mySubInvCode,myCItemId,myItemId,myGrpId,'N'                                                                                  
					 ,mySerCtrl,myParentCode                                                                                                       
					  );                                                                                                                           
				elsif myAction = 'U' then                                                                                                       
					mySect := 'Create RMA - Update RMADET';                                                                                        
					update DEX_RMADET set                                                                                                          
					PART = myPart                                                                                                                  
				  ,CUSTPART = myCustPart                                                                                                        
				  ,DESCR = myDescr                                                                                                              
				  ,STATCODE = nvl(myStatCode,'N')                                                                                               
				  ,GRP = myGrp                                                                                                                  
				  ,OEM = myMfg                                                                                                                  
				  ,QTYORG = myQtyOrg                                                                                                            
				  ,PRICE = nvl(myPrice,0)                                                                                                       
				  ,DATESCH = nvl(mySchdDate, DATESCH)                                                                                           
				  ,REPAIR_PLANT_ID = myRepPlantID                                                                                               
				  ,SUBINVENTORY_CODE = mySubInvCode                                                                                             
				  ,CUSTOMER_ITEM_id = myCItemID                                                                                                 
				  ,INVENTORY_ITEM_ID = myItemID                                                                                                 
				  ,GROUP_ID = myGrpID                                                                                                           
				  ,ECHELON = mySerCtrl                                                                                                          
				   where CALL = myCall                                                                                                          
				   and   CUSTITEM = myCustItem;                                                                                                 
				elsif myAction = 'C' then                                                                                                       
					update DEX_RMADET set                                                                                                          
					QTYORG = 0                                                                                                                     
					where CALL = myCall                                                                                                            
				   and   CUSTITEM = myCustItem;                                                                                                 
				end if;                                                                                                                         
                                                                                                                                    
				mySerCnt := myRMASerials.COUNT;                                                                                                 
				mySerInsCnt := 0;                                                                                                               
				mySect := 'Create RMA - Serials';                                                                                               
                                                                                                                                    
				for x in 1 .. mySerCnt loop                                                                                                     
					if myRMASerials(x).LINE_ID = myLineID then                                                                                     
						 mySerial := myRMASerials(x).SERIAL_NUMBER;                                                                                   
                                                                                                                                    
						 if myIntRMA != 'Y' then                                                                                                      
						 	myRetMesg := K_SERIALS.CHECK_TRACK (                                                                                        
                                           myCust                                                                                   
                                          ,nvl(myOrd                                                                                
er,'XXX')                                                                                                                           
                                          ,myItem                                                                                   
                                          ,myPart                                                                                   
                                          ,myCustPart                                                                               
                                          ,''                                                                                       
                                          ,mySerial                                                                                 
                                          ,myCall                                                                                   
                                         );                                                                                         
						end if;                                                                                                                       
      				if myRetMesg is not null then                                                                                             
      					-- continue to loop to record all duplicates                                                                             
      					myRetCode := 1;                                                                                                          
         				PUSH_ERROR;                                                                                                            
                                                                                                                                    
      				else                                                                                                                      
                                                                                                                                    
							mySerInsCnt := mySerInsCnt + 1;                                                                                              
							select RMA_SERIALS_S.nextval                                                                                                 
							into   myRMASerID                                                                                                            
							from   dual;                                                                                                                 
                                                                                                                                    
                                                                                                                                    
							insert into RMA_SERIALS (                                                                                                    
							CALL, ITEM, SERIAL , UNIQUENO, STATUS, REPORTED_FAILURE                                                                      
						  ,RMA_SERIAL_ID                                                                                                              
							) values (                                                                                                                   
							 myCAll, myItem, mySerial ,mySerInsCnt, 'O', myRMASerials                                                                    
(x).FAILURE_DESCR                                                                                                                   
							,myRMASerID                                                                                                                  
							 );                                                                                                                          
                                                                                                                                    
							mySect := 'Create RMA - Ser Warr Set';                                                                                       
							myWdx := myWdx + 1;                                                                                                          
							myWSerials(myWdx).SERIAL_NUMBER := mySerial;                                                                                 
							myWSerials(myWdx).INVENTORY_ITEM_ID := myItemID;                                                                             
							myWSerials(myWdx).RMA_SERIAL_ID := myRMASerID;                                                                               
						 	myWSerials(myWdx).CUSTPART := myCustPart;                                                                                   
						   myWSerials(myWdx).DATERCV := trunc(SYSDATE);                                                                               
							myWSerials(myWdx).PLANT_ID := myPlantId;                                                                                     
							myWSerials(myWdx).CUSTOMER_ID := myCustID;                                                                                   
							myWSerials(myWdx).ORDTYPE := myOrdType;                                                                                      
							myWSerials(myWdx).DATA_KEY := myCCOId;                                                                                       
							myWSerials(myWdx).CONTRACT := myContract;                                                                                    
   					end if;                                                                                                                     
					end if;                                                                                                                        
				end loop;                                                                                                                       
                                                                                                                                    
				if mySerInsCnt > myQtyOrg then                                                                                                  
					myRetMesg := 'Serials Provided (' || mySerInsCnt || ') cannot exceed                                                           
 Line Qty (' || myQtyOrg || ')';                                                                                                    
					raise LINE_ERROR;                                                                                                              
				end if;                                                                                                                         
			exception                                                                                                                        
				when LINE_ERROR then                                                                                                            
					myRetCode := 1;                                                                                                                
					PUSH_ERROR;                                                                                                                    
				when OTHERS then                                                                                                                
					myRetCode := 2;                                                                                                                
					myRetMesg := mySect || ' ' || SQLERRM;                                                                                         
					PUSH_ERROR;                                                                                                                    
			end;                                                                                                                             
			myRetCode := 0;                                                                                                                  
			myRetMesg := null;                                                                                                               
		end loop;                                                                                                                         
		-- dbms_output.put_line('After loop Wdx: ' || myWdx ||                                                                            
 ' myEdx: ' || myEdx);                                                                                                              
                                                                                                                                    
		if myWdx > 0 and myEdx = 0 then			-- only check warr                                                                              
ant if no errors (myEdx = 0)                                                                                                        
			mySect := 'Create RMA - Ser Warr Check';                                                                                         
			K_DEX_WARRANTY_AOL.CHECK_WARRANTY ( myWSerials );                                                                                
                                                                                                                                    
			mySect := 'Create RMA - Set Warr Status';                                                                                        
			for i in 1 .. myWdx loop                                                                                                         
				myRMASerID := myWSerials(i).RMA_SERIAL_ID;                                                                                      
				update RMA_SERIALS set                                                                                                          
				WARR_TYPE        = myWSerials(i).WARR_TYPE                                                                                      
			  ,WARRANTY         = myWSerials(i).WARRANTY		-- Invalid/Valid                                                                   
			  ,BEYOND_ECON_FLAG = myWSerials(i).BEYOND_ECON_FLAG                                                                             
                                                                                                                                    
			  ,WARRANTY_REASON  = myWSerials(i).WARRANTY_REASON                                                                              
			   where RMA_SERIAL_ID = myRMASerID;                                                                                             
			end loop;                                                                                                                        
		end if;                                                                                                                           
                                                                                                                                    
                                                                                                                                    
		if myEdx > 0 then                                                                                                                 
			-- dbms_output.put_line ('rollback to create savepoint');                                                                        
			ROLLBACK TO RMACREATE_SAVEPOINT;                                                                                                 
		else                                                                                                                              
			myRMANbr	:= myCall;                                                                                                              
			-- dbms_output.put_line('return myRMANbr: ' || myRMANbr);                                                                        
		end if;                                                                                                                           
	exception                                                                                                                          
		when ABORT_PROC then                                                                                                              
			myRetCode := 1;                                                                                                                  
			PUSH_ERROR;                                                                                                                      
			ROLLBACK TO RMACREATE_SAVEPOINT;                                                                                                 
		when OTHERS then                                                                                                                  
			myRetCode := 2;                                                                                                                  
			myRetMesg := mySect || ' ' || SQLERRM;                                                                                           
			PUSH_ERROR;                                                                                                                      
			ROLLBACK TO RMACREATE_SAVEPOINT;                                                                                                 
	end RMA_CREATE;                                                                                                                    
                                                                                                                                    
                                                                                                                                    
	/*******************************************************                                                                           
*********************************************                                                                                       
	 	This procedure is execute by C3 B2B after sending an RM                                                                          
A Create Request (3A4) to an Outsource                                                                                              
	 	Partner.  If the RMA Creation was successfuly by the Outsource                                                                   
 Partner, then the Partner's RMA                                                                                                    
	 	will be passed to this procedure. If the Unsuccessful, then a Reject                                                             
 Reason will be passed                                                                                                              
	 	and the Partner RMA will be null.                                                                                                
	*********************************************************************                                                              
*********************************/                                                                                                  
                                                                                                                                    
	procedure RMA_RESPONSE ( myInvOrgID			in		NUMBER                                                                                   
						  		   ,mySubInvCode		in 	VARCHAR2			-- (Optional)                                                                            
							  	   ,myRMANbr			in 	VARCHAR2                                                                                               
								   ,myPartnerRMA		in		VARCHAR2			-- (Optional                                                                               
)                                                                                                                                   
								   ,myStatusCode 		in 	VARCHAR2  		-- A = Accept, R = Reject                                                                
								   ,myErrMessage		in		VARCHAR2			-- Reject Error Me                                                                         
ssage                                                                                                                               
								  	) is                                                                                                                     
                                                                                                                                    
		myFTP 		varchar2(1);                                                                                                              
		myPlantId	number;                                                                                                                 
		myHoldChecks varchar2(1);                                                                                                         
		myRMAList	XXDEX_PROCESS_K.RMA_TBL;                                                                                                
		myRetCode	number;                                                                                                                 
		myRetMesg   varchar2(1000);                                                                                                       
	begin                                                                                                                              
		SAVEPOINT RMARESP_SAVEPOINT;                                                                                                      
		-- dbms_output.put_line ('RMA Response Status: ' || myStatusCode                                                                  
|| ' Msg: ' || myErrMessage || ' RMA: ' || myRMANbr                                                                                 
|| ' InvOrgID: ' || myInvOrgID);                                                                                                    
		begin                                                                                                                             
			mySect := 'RMA Response - Find';                                                                                                 
			select PLANT_ID                                                                                                                  
				   ,decode(PLANT_CODE,'A','N','Y')                                                                                              
			into   myPlantID                                                                                                                 
					,myHoldChecks                                                                                                                  
			from 	 XXDEX_CISCO_RMAHDRS_V                                                                                                     
			where  RMA_NBR = myRMANbr                                                                                                        
			and    RETURN_ORGANIZATION_ID = myInvOrgID                                                                                       
			and    nvl(RETURN_SUBINVENTORY_CODE,myDfltSubInv) = nv                                                                           
l(mySubInvCode,myDfltSubInv);                                                                                                       
                                                                                                                                    
                                                                                                                                    
			if myStatusCode = 'A' then                                                                                                       
				update DEX_RMAHDR set                                                                                                           
			   MSG_STATUS    = null                                                                                                          
			  ,MESSAGE       = null                                                                                                          
				where  CALL = myRMANbr;                                                                                                         
                                                                                                                                    
				mySect := 'Create RMA - Complete RMA';                                                                                          
				XXDEX_PROCESS_K.COMPLETE_RMA ( myRetCode 		=> myRetCode                                                                         
 										   			,myRetMesg 		=> myRetMesg                                                                                          
 										   			,myRMAList		=> myRMAList                                                                                           
 										   			,myRMA			=> myRMANbr                                                                                               
 										   			,myRtnPlantID	=> myPlantId                                                                                         
 										   			,myHoldChecks  => myHoldChecks                                                                                     
													);                                                                                                                     
                                                                                                                                    
				if myRetCode = 2 then                                                                                                           
						XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                               
    													  p_exception_name_i        => 'DEX_A                                                                              
PPL_ERROR'                                                                                                                          
     													 ,p_appl_short_name_i       => DEX_APP_F                                                                          
     													 ,p_token_name_list_i       => xxcts_fea_u                                                                        
tl_exception.token_name_tab_type                                                                                                    
					                                                 ('ERROR_MESSAGE')                                                             
                                                                                                                                    
     													 ,p_token_value_list_i      => xxcts_fea_utl_exception.toke                                                       
n_value_tab_type                                                                                                                    
										                                   (myRetMesg)                                                                            
     													 );                                                                                                               
				end if;                                                                                                                         
                                                                                                                                    
			else                                                                                                                             
				-- dbms_output.put_line('update rma: ' || myRMANbr || ' Msg:                                                                    
' || myErrMessage);                                                                                                                 
				mySect := 'Create RMA - Update RMA Error';                                                                                      
				update DEX_RMAHDR set                                                                                                           
				MESSAGE    = myErrMessage                                                                                                       
      	  ,MSG_STATUS = 'Y'                                                                                                          
				where  CALL = myRMANbr;                                                                                                         
			end if;                                                                                                                          
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				myRetMesg := 'RMA Not Found (RMA: ' || myRMANbr || ' I                                                                          
nv Org ID: ' || myInvOrgID;                                                                                                         
				XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                                 
    													  p_exception_name_i        => 'DEX_APPL_ERROR'                                                                    
     													 ,p_appl_short_name_i       => DEX_                                                                               
APP_F                                                                                                                               
     													 ,p_token_name_list_i       => xxcts_fea_utl_exception                                                            
.token_name_tab_type                                                                                                                
					                                                 ('E                                                                           
RROR_MESSAGE')                                                                                                                      
     													 ,p_token_value_list_i      => xxcts_fea_utl_                                                                     
exception.token_value_tab_type                                                                                                      
										                                   (myRetMesg)                                                                            
     													 );                                                                                                               
                                                                                                                                    
		end;                                                                                                                              
	exception                                                                                                                          
		when XXCTS_FEA_UTL_EXCEPTION.BUSINESS_EXCEPTION the                                                                               
n                                                                                                                                   
			LOG_BUSINESS_EXCEPTION ( myEntityID	   => myRMANbr                                                                               
										   ,myInvOrgID	 	=> myInvOrgID                                                                                            
										   ,myErrMesg	 	=> myRetMesg                                                                                              
										   ,myExceptName 	=> XXDEX_CISCO_GLOBAL_K.CTS_DEX_RMA_RESPONSE                                                            
_FAILED                                                                                                                             
										  );                                                                                                                      
                                                                                                                                    
			ROLLBACK TO RMARESP_SAVEPOINT;                                                                                                   
			-- dbms_output.put_line('Business Exception: ' || SQLERRM);                                                                      
			RAISE;                                                                                                                           
		when OTHERS then                                                                                                                  
			ROLLBACK TO RMARESP_SAVEPOINT;                                                                                                   
			myRetMesg := mySect || ' Error: ' || SQLERRM;                                                                                    
			mySect := 'Create RMA - Others Exception';                                                                                       
			begin                                                                                                                            
				LOG_BUSINESS_EXCEPTION ( myEntityID		=> myRMANbr                                                                                
											   ,myInvOrgID	 	=> myInvOrgID                                                                                           
											   ,myErrMesg	 	=> myRetMesg                                                                                             
											   ,myExceptName 	=> XXDEX_CISCO_GLOBAL_K.CTS_DEX_RMA_RESPON                                                             
SE_FAILED                                                                                                                           
											  );                                                                                                                     
                                                                                                                                    
                                                                                                                                    
				XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                                 
    													  p_exception_name_i        => 'DEX_APPL_ERROR'                                                                    
     													 ,p_appl_short_name_i       => DEX_                                                                               
APP_F                                                                                                                               
     													 ,p_token_name_list_i       => xxcts_fea_utl_exception                                                            
.token_name_tab_type                                                                                                                
					                                                 ('E                                                                           
RROR_MESSAGE')                                                                                                                      
     													 ,p_token_value_list_i      => xxcts_fea_utl_                                                                     
exception.token_value_tab_type                                                                                                      
										                                   (myRetMesg)                                                                            
     													 );                                                                                                               
			exception                                                                                                                        
				when OTHERS then                                                                                                                
					RAISE;                                                                                                                         
			end;                                                                                                                             
	end RMA_RESPONSE;                                                                                                                  
                                                                                                                                    
                                                                                                                                    
	/*************************************************************************                                                         
***************************                                                                                                         
	 	This procedure is execute by C3 B2B after receiving Receipt Notices (4B2)                                                        
 from the Outsourced and                                                                                                            
	 	Authorized providers. The Receipt process will rec                                                                               
eived the Serial on the DEX Order and move it                                                                                       
	 	to the appropriate floor location.                                                                                               
	***********************************************************************                                                            
*******************************/                                                                                                    
                                                                                                                                    
                                                                                                                                    
	procedure RMA_RECEIPT ( myInvOrgID			in 	NUMBER                                                                                    
								  ,mySubInvCode		in 	VARCHAR2			-- Optional                                                                                 
								  ,myReceipts	  		in 	XXDEX_CISCO_GLOBAL_K.RECEIPTS_TBL                                                                     
								  ) is                                                                                                                      
                                                                                                                                    
		myRetCode		number;                                                                                                                
		myRetMesg		varchar2(1000);                                                                                                        
                                                                                                                                    
		myRcptCnt		pls_integer;                                                                                                           
		mySerCnt			pls_integer;                                                                                                           
                                                                                                                                    
		myOrgID			number;                                                                                                                 
		myPlantID		number := myInvOrgID;                                                                                                  
		myCustID			number;                                                                                                                
		myBillID			number;                                                                                                                
		myShipID			number;                                                                                                                
		myFindCustID	number;                                                                                                              
		myItemID			number;                                                                                                                
		myCItemID		number;                                                                                                                
		myRPlantID		number;                                                                                                               
		myIORgID			number;                                                                                                                
		myUserID			number := F_DEX_USER_ID;                                                                                               
		myItem			number;                                                                                                                  
		myQtyUnRcv		number;                                                                                                               
		myQtyOrg			number;                                                                                                                
		myQtyRcv			number;                                                                                                                
		myLineCnt		number;                                                                                                                
		myRcvQty			number;                                                                                                                
		mySerialID		number;                                                                                                               
		myRMAPrice		number;                                                                                                               
		mySerlCtrl		number;                                                                                                               
		mySerTranId		number;                                                                                                              
		myLotQty			number;                                                                                                                
		myLotCntInd		varchar2(1);                                                                                                         
                                                                                                                                    
		myRMA				DEX_RMAHDR.CALL%type;                                                                                                    
		myCall			DEX_RMAHDR.CALL%type;                                                                                                    
		myStatus			DEX_RMAHDR.STATUS%type;                                                                                                
		myCustPO			DEX_RMAHDR.CUSTPO%type;                                                                                                
		myRelease		DEX_RMAHDR.RELEASE%type;                                                                                               
		myCust			DEX_RMAHDR.CUST%type;                                                                                                    
		myFindCust		DEX_RMAHDR.CUST%type;                                                                                                 
		myOrder		 	DEX_RMAHDR.ORDERNO%type;                                                                                               
		myWaybill		DEX_RECEIPTS.WAYBILL_NUM%type;                                                                                         
		myPrevCall		DEX_RMAHDR.CALL%type := 0;                                                                                            
		myPlant			DEX_PLANTS.PLANT%type;                                                                                                  
		myPriceTypeCd 	DEX_RMAHDR.PRICE_TYPE_CODE%type;                                                                                   
		myOrdType		RMAHDR.ORDTYPE%type;                                                                                                   
                                                                                                                                    
		myCustName		XXDEX_CUSTOMERS_ALL_V.CUSTOMER_NAME%type;                                                                             
		myParent			XXDEX_CUSTOMERS_ALL_V.PARENT_CODE%type;                                                                                
                                                                                                                                    
		myRecvRMAFlag  DEX_CUSTOMER_DATA.RECV_RMA_FLAG%type;                                                                              
                                                                                                                                    
		myPart	   	DEX_RMADET.PART%type;                                                                                                  
		myCPart			DEX_RMADET.CUSTPART%type;                                                                                               
		myTrack			RMA_SERIALS.SERIAL%type;                                                                                                
		myCrossDock    DEX_SERIALS.LOCATION%type;                                                                                         
		myXDockLocn		DEX_SERIALS.LOCATION%type;                                                                                           
		myRcvDate		date;                                                                                                                  
                                                                                                                                    
		myMastOrg		varchar2(1);                                                                                                           
		myActive			varchar2(1);                                                                                                           
                                                                                                                                    
		myEmpNo			varchar2(10);                                                                                                           
                                                                                                                                    
		mySerials		XXDEX_CISCO_GLOBAL_K.RCPT_SERIALS_TBL;                                                                                 
                                                                                                                                    
                                                                                                                                    
		cursor c1 is                                                                                                                      
			select ORDERNO                                                                                                                   
			from   DEX_ORDERS                                                                                                                
			where  RMA = myCall                                                                                                              
			order by decode(CLOSED_FLAG,'O',1,2), DATERCV DESC;                                                                              
                                                                                                                                    
		RECEIPT_ERROR EXCEPTION;                                                                                                          
		RMA_NOT_FOUND	EXCEPTION;                                                                                                          
		PART_NOT_FOUND	EXCEPTION;                                                                                                         
                                                                                                                                    
	begin                                                                                                                              
		SAVEPOINT RECEIPT_SAVEPOINT;                                                                                                      
		myEmpNo  := nvl(XXDEX_CISCO_GLOBAL_K.B2B_EMPNO,'0000');                                                                           
                                                                                                                                    
		mySect := 'RMA Receipt - Find Plant: ' || myPlantID;                                                                              
		select ORG_ID                                                                                                                     
				,PLANT                                                                                                                          
		into   myOrgID                                                                                                                    
				,myPlant                                                                                                                        
		from   DEX_PLANTS                                                                                                                 
		where  PLANT_ID = myPlantID;                                                                                                      
                                                                                                                                    
		myCrossDock := XXDEX_DEFAULTS_F ( 'REPAIR_PLANT_CROSS_DOCK'                                                                       
,myPlantID );                                                                                                                       
                                                                                                                                    
		myRcptCnt := myReceipts.COUNT;                                                                                                    
		for i in 1 .. myRcptCnt loop                                                                                                      
			begin                                                                                                                            
				myRetMesg := null;                                                                                                              
				mySect := 'RMA Receipt - Find RMA';                                                                                             
                                                                                                                                    
				myRMA := myReceipts(i).RMA_NBR;			-- DEX RMA NBR                                                                                
                                                                                                                                    
				/*                                                                                                                              
	      	dbms_output.put_line('myReceipts(' || i || ').RMA_NBR: ' ||    my                                                           
Receipts(i).RMA_NBR);                                                                                                               
	      	dbms_output.put_line('myReceipts(' || i || ').PA                                                                            
RTNER_RMA: ' ||    myReceipts(i).PARTNER_RMA_NBR);                                                                                  
				dbms_output.put_line('myReceipts(' || i || ').PAR                                                                               
T_NUMBER: ' ||   myReceipts(i).PART_NUMBER);                                                                                        
				dbms_output.put_line('myReceipts(' || i || ').QUANTITY:                                                                         
 ' ||       myReceipts(i).QUANTITY);                                                                                                
				dbms_output.put_line('myReceipts(' || i || ').RECEIPT_DATE: ' |                                                                 
|    myReceipts(i).RECEIPT_DATE);                                                                                                   
	      	*/                                                                                                                          
                                                                                                                                    
				begin                                                                                                                           
					if myRMA is null then                                                                                                          
							myCustPO := myReceipts(i).PARTNER_RMA_NBR;                                                                                   
							mySect := 'RMA by Custpo: ' || myCustPO || ' PlantID: ' || myPlantId                                                         
;                                                                                                                                   
							select CALL                                                                                                                  
									,STATUS                                                                                                                    
									,CUSTOMER_ID                                                                                                               
			  						,CUST                                                                                                                    
				  					,BILL_SITE_USE_ID                                                                                                        
				  					,SHIP_SITE_USE_ID                                                                                                        
				  					,ORG_ID                                                                                                                  
				  					,CUSTPO                                                                                                                  
			  						,RELEASE                                                                                                                 
			  						,nvl(CUST_EXCHANGE,CUST)                                                                                                 
			  						,PRICE_TYPE_CODE                                                                                                         
			  						,ORDTYPE                                                                                                                 
							into   myCall                                                                                                                
									,myStatus                                                                                                                  
									,myCustID                                                                                                                  
				  					,myCust                                                                                                                  
				  					,myBillID                                                                                                                
				  					,myShipID                                                                                                                
				  					,myOrgID                                                                                                                 
			  						,myCustPO                                                                                                                
			  						,myRelease                                                                                                               
			  						,myFindCust                                                                                                              
			  						,myPriceTypeCd                                                                                                           
			  						,myOrdType                                                                                                               
							from   DEX_RMAHDR                                                                                                            
							where  CUSTPO    = myCustPO                                                                                                  
							and    PLANT_ID  = myPlantID                                                                                                 
							and    rownum < 2;                                                                                                           
							myRMA := myCall;                                                                                                             
					else                                                                                                                           
							mySect := 'RMA: ' || myRMA || ' PlantID: ' || myPlantId;                                                                     
							select CALL                                                                                                                  
										,STATUS                                                                                                                   
										,CUSTOMER_ID                                                                                                              
			  						,CUST                                                                                                                    
			  						,BILL_SITE_USE_ID                                                                                                        
				  					,SHIP_SITE_USE_ID                                                                                                        
				  					,ORG_ID                                                                                                                  
				  					,CUSTPO                                                                                                                  
				  					,RELEASE                                                                                                                 
			  						,nvl(CUST_EXCHANGE,CUST)                                                                                                 
			  						,PRICE_TYPE_CODE                                                                                                         
			  						,ORDTYPE                                                                                                                 
							into 	 myCall                                                                                                                
								   ,myStatus                                                                                                                
									,myCustID                                                                                                                  
				  					,myCust                                                                                                                  
				  					,myBillID                                                                                                                
				  					,myShipID                                                                                                                
				  					,myOrgID                                                                                                                 
			  						,myCustPO                                                                                                                
			  						,myRelease                                                                                                               
			  						,myFindCust                                                                                                              
			  						,myPriceTypeCd                                                                                                           
			  						,myOrdType                                                                                                               
							from   DEX_RMAHDR                                                                                                            
							where  CALL  = myRMA                                                                                                         
							and    PLANT_ID = myPlantID;                                                                                                 
							-- dbms_output.put_line ('found RMA: ' || myCall |                                                                           
| 'status: ' || myStatus);                                                                                                          
					end if;                                                                                                                        
                                                                                                                                    
					-- get latest order tied to RMA                                                                                                
					myOrder := null;                                                                                                               
					for r1 in c1 loop                                                                                                              
						myOrder := r1.ORDERNO;                                                                                                        
						exit;                                                                                                                         
					end loop;                                                                                                                      
				exception                                                                                                                       
					when NO_DATA_FOUND then                                                                                                        
							myRetMesg := 'RMA Not Found in Plant. ' || mySect;                                                                           
							raise RECEIPT_ERROR;                                                                                                         
					when OTHERS then                                                                                                               
							myRetMesg := mySect || ' - ' || SQLERRM;                                                                                     
							-- dbms_output.put_line('others error: ' || myRetMesg);                                                                      
							raise RECEIPT_ERROR;                                                                                                         
				end;                                                                                                                            
                                                                                                                                    
				if myStatus != 'O' then                                                                                                         
					myRetMesg := mySect || ' RMA is not Open. Cannot receive uni                                                                   
ts.';                                                                                                                               
					raise RECEIPT_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				mySect := 'RMA Receipts - Cust Data: ' || myFindCust;                                                                           
				begin                                                                                                                           
					select CUSTOMER_NAME                                                                                                           
							,CUSTOMER_ID                                                                                                                 
					into   myCustName                                                                                                              
							,myFindCustID                                                                                                                
					from   XXDEX_PARTIES_V                                                                                                         
					where  CUSTOMER_NUMBER = myFindCust                                                                                            
					and    rownum < 2;                                                                                                             
                                                                                                                                    
					select dcd.PARENT_CODE                                                                                                         
				  			,nvl(dcd.RECV_RMA_FLAG,'N')                                                                                                
				  	into   myParent                                                                                                              
			  				,myRecvRMAFlag                                                                                                             
					from   DEX_CUSTOMER_DATA dcd                                                                                                   
					where  dcd.CUSTOMER_ID = myFindCustID                                                                                          
					and    dcd.ORG_ID = myOrgID;                                                                                                   
				exception                                                                                                                       
					when NO_DATA_FOUND then                                                                                                        
						begin                                                                                                                         
							select dcd.PARENT_CODE                                                                                                       
					  				,nvl(dcd.RECV_RMA_FLAG,'N')                                                                                              
					  		into   myParent                                                                                                            
			  						,myRecvRMAFlag                                                                                                           
							from   DEX_CUSTOMER_DATA dcd                                                                                                 
							where  dcd.CUSTOMER_ID = 0                                                                                                   
							and    dcd.ORG_ID = myOrgID                                                                                                  
							and    XXDEX_DEFAULTS_F ( 'CUST_DYNAMIC_LOAD' ) = '                                                                          
Y';                                                                                                                                 
						exception                                                                                                                     
							when NO_DATA_FOUND then                                                                                                      
								myRetMesg := 'Customer: ' || myFindCust || '                                                                                
not setup in Operating Unit.';                                                                                                      
								raise RECEIPT_ERROR;                                                                                                        
						end;                                                                                                                          
				end;                                                                                                                            
                                                                                                                                    
                                                                                                                                    
				mySect := 'RMA Receipt - Find Item';                                                                                            
				myPart := myReceipts(i).PART_NUMBER;                                                                                            
                                                                                                                                    
				myItemID := F_DEX_ITEM_ID(myPart);                                                                                              
                                                                                                                                    
				mySerlCtrl := ITEM_SERL_CTRL (myItemID, myInvOrgId)                                                                             
;                                                                                                                                   
				myRcvQty   := myReceipts(i).QUANTITY;                                                                                           
				mySerials  := myReceipts(i).SERIALS_TBL;                                                                                        
				myRcvDate  := myReceipts(i).RECEIPT_DATE;                                                                                       
				mySerCnt   := mySerials.COUNT;                                                                                                  
                                                                                                                                    
				/* 6/28/2010 -- all receipts must be serialized at this tim                                                                     
e.                                                                                                                                  
				if mySerCnt = 0 then                                                                                                            
					myRetMesg := 'No Serials Specified  - RMA: ' || myRMA || ' Part: ' || m                                                        
yPart;                                                                                                                              
				elsif mySerlCtrl = 1 and mySerCnt > 1 then			-- no serialized contr                                                             
ol then                                                                                                                             
					myRetMesg := 'Only one Serial can be specified for non serialized                                                              
 Parts - RMA: ' || myRMA || ' Part: ' || myPart;                                                                                    
				elsif mySerlCtrl != 1 and mySerCnt != myRcvQty then                                                                             
                                                                                                                                    
					myRetMesg := 'Serial Cnt:' || mySerCnt || ' does not match Qty: ' || myR                                                       
cvQty || ' - RMA: ' || myRMA || ' Part: ' || myPart;                                                                                
                                                                                                                                    
				elsif mySerlCtrl = 1 then                                                                                                       
					myLotCntInd := 'F';			-- force to lot                                                                                          
					myLotQty    := myRcvQty;                                                                                                       
				else                                                                                                                            
					myLotCntInd := null;                                                                                                           
					myLotQty    := null;                                                                                                           
				end if;                                                                                                                         
				*/                                                                                                                              
				-- dbms_output.put_line('i: ' || i || ' serctrl: ' || myserlctrl || ' se                                                        
rcnt: ' || mysercnt || ' rcvqty: ' || myrcvqty);                                                                                    
				if mySerlCtrl != 1 and mySerCnt != myRcvQty then                                                                                
					myRetMesg := 'Serial Cnt: ' || mySerCnt || ' does                                                                              
 not match Qty: ' || myRcvQty || ' - RMA: ' || myRMA                                                                                
 || ' Part: ' || myPart;                                                                                                            
					raise RECEIPT_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				select sum(QTYORG)                                                                                                              
						,sum(nvl(QTYRCV,0))                                                                                                           
						,count(*)                                                                                                                     
						,max(REPAIR_PLANT_ID)                                                                                                         
						,max(ORGANIZATION_ID)                                                                                                         
				into   myQtyOrg                                                                                                                 
						,myQtyRcv                                                                                                                     
						,myLineCnt                                                                                                                    
						,myRPlantID                                                                                                                   
						,myIOrgId                                                                                                                     
				from   DEX_RMADET                                                                                                               
				where  CALL = myCall                                                                                                            
				and    PART = myPart;                                                                                                           
                                                                                                                                    
				if myLineCnt = 0 and myRecvRMAFlag = 'Y' then			-- Y=Prebook Requi                                                              
red no changes allowed.                                                                                                             
					myRetMesg := 'Part Not Found on RMA - RMA: ' || m                                                                              
yRMA || ' Part: ' || myPart || ' not found';                                                                                        
					raise RECEIPT_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				mySect := 'RMA Receipt - Repair Plant';                                                                                         
				myXDockLocn := null;                                                                                                            
				XXDEX_PROCESS_K.REPAIR_ROUTING ( myRetCode		=> myRe                                                                             
tCode                                                                                                                               
									  					  ,myRetMesg		=> myRetMesg                                                                                          
									  					  ,myRepPlantId	=> myRPlantId                                                                                       
									  					  ,myOrdType		=> myOrdType                                                                                          
									  					  ,myRetPlantID	=> myPlantId                                                                                        
									  					  ,myReasonCd		=> myPriceTypeCd                                                                                     
								  						  ,myItemId			=> myItemID                                                                                           
								  						  );                                                                                                                
				if myRetCode != 0 then                                                                                                          
					raise RECEIPT_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				if myRPlantID = myPlantID then                                                                                                  
					-- validate the Part is enabled in the organiation                                                                             
					myIOrgID := DEX_ORGANIZATIONS_K.BUS_TYPE(myPlantID, 'R');                                                                      
					if myIOrgId is null then                                                                                                       
						myRetMesg := 'Repair Plant: ' || myRPlantID || '                                                                              
 does not not have Repair Organization setup in DEX                                                                                 
Organizations';                                                                                                                     
						raise RECEIPT_ERROR;                                                                                                          
					end if;                                                                                                                        
					myActive := XXDEX_ITEM_ACTIVE_F(myItemID, myIOrgID);                                                                           
					if nvl(myActive,'N') != 'Y' then                                                                                               
						myRetMesg :=  'Part: ' || myPart || ' is not activ                                                                            
e in Repair Organization: ' || myIOrgID;                                                                                            
						raise RECEIPT_ERROR;                                                                                                          
					end if;                                                                                                                        
				else                                                                                                                            
					if myIOrgId is null then                                                                                                       
						myIOrgID := DEX_ORGANIZATIONS_K.MASTER_ID;                                                                                    
					end if;                                                                                                                        
					myXDockLocn := myCrossDock;					-- set to cross                                                                                
 dock location control                                                                                                              
				end if;                                                                                                                         
                                                                                                                                    
				myQtyUnRcv := myQtyOrg - myQtyRcv;                                                                                              
                                                                                                                                    
				if myRcvQty > myQtyUnRcv and myRecvRMAFlag = 'Y' t                                                                              
hen                                                                                                                                 
					myRetMesg := 'Qty to be Rcvd will exceed RMA Qty - RMA: ' || myRMA ||                                                          
 ' Part: ' || myPart || ' RMA Qty: ' || myQtyOrg ||                                                                                 
' Qty Already Rcvd: ' || myQtyRcv || ' Qty to be Rcv                                                                                
d: ' || myRcvQty;                                                                                                                   
					raise RECEIPT_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
   			mySect := 'RMA Receipts - Cust Part';                                                                                         
   			myCPart := K_DEX_CUST_ITEM.FIND ( myCustID  => my                                                                             
CustID                                                                                                                              
                 										,myItemID  => myItemID                                                                                   
                 										,myCItemID => myCItemID                                                                                  
                 										);                                                                                                       
                                                                                                                                    
				mySect := 'RMA Receipt - Serials';                                                                                              
                                                                                                                                    
				mySerials := myReceipts(i).SERIALS_TBL;                                                                                         
				mySerCnt := mySerials.COUNT;                                                                                                    
                                                                                                                                    
                                                                                                                                    
				myRetCode := 0;                                                                                                                 
				--dbms_output.put_line ('serials loop cnt: ' || mySerCnt                                                                        
 || ' rpct: ' || i);                                                                                                                
				for j in 1 .. mySerCnt loop                                                                                                     
                                                                                                                                    
					-- find next rma line with open qty for part                                                                                   
					mySect := 'RMA Receipt - Find Item';                                                                                           
					select min(ITEM)                                                                                                               
					into   myItem                                                                                                                  
					from   DEX_RMADET                                                                                                              
					where  CALL = myCall                                                                                                           
					and    PART = myPart                                                                                                           
					and    QTYORG - nvl(QTYRCV,0) > 0;                                                                                             
                                                                                                                                    
					if myItem is null then                                                                                                         
							-- find any rma line for part                                                                                                
							select min(ITEM)                                                                                                             
							into   myItem                                                                                                                
							from   DEX_RMADET                                                                                                            
							where  CALL = myCall                                                                                                         
							and    PART = myPart;                                                                                                        
					end if;                                                                                                                        
                                                                                                                                    
					if myItem is not null then                                                                                                     
							mySect := 'RMA Receipt - Find Price';                                                                                        
							select PRICE                                                                                                                 
							into   myRMAPrice                                                                                                            
							from   DEX_RMADET                                                                                                            
							where  CALL = myCall                                                                                                         
							and    ITEM = myItem;                                                                                                        
					else                                                                                                                           
						myRMAPrice := 0;                                                                                                              
					end if;                                                                                                                        
                                                                                                                                    
					myTrack := mySerials(j).SERIAL_NUMBER;                                                                                         
					myRcvDate := nvl(mySerials(j).RECEIPT_DATE, myRcv                                                                              
Date);                                                                                                                              
                                                                                                                                    
					mySerialID := null;                                                                                                            
					mySect := 'RMA Receipt - Recv Expres';                                                                                         
					K_DEX_RECV_EXPRESS.TRACK (                                                                                                     
							                     myRetMesg     => myRetMesg                                                                              
							                    ,myRetCode     => myRetCode                                                                              
							                    ,myOrder       => myOrder                                                                                
							                    ,mySerialID	  => mySerialID                                                                              
							                    ,myEmpNo       => myEmpNo                                                                                
							                    ,myCust        => myCust                                                                                 
							                    ,myCustName    => myCustName                                                                             
							                    ,myCustID      => myCustID                                                                               
							                    ,myBillID      => myBillID                                                                               
							                    ,myShipID      => myShipID                                                                               
							                    ,myParent      => myParen                                                                                
t                                                                                                                                   
							                    ,myWaybill     => myWaybill                                                                              
							                    ,myCustPO      => myCustPO                                                                               
							                    ,myPRelease    => myRelease                                                                              
							                    ,myPlantID     => myPlantID                                                                              
							                    ,myOrgID       => myOrgID                                                                                
							                    ,myPlant       => myPlant                                                                                
							                    ,myCPart       => myCPart                                                                                
							                    ,myCItemID     => myCItemID                                                                              
							                    ,myPart        => myPart                                                                                 
							                    ,myItemID      => myItemID                                                                               
							                    ,myIOrgID      => myIOrgID                                                                               
							                    ,myRPlantID    => myRPlantID                                                                             
                                                                                                                                    
							                    ,myTrack       => myTrack                                                                                
							                    ,myUserID      => myUserID                                                                               
							                    ,myPBNum       => myCall                                                                                 
							                    ,myPBItem      => myItem                                                                                 
							                    ,myXDockLocn   => myXDockLocn                                                                            
							                    ,myLotQty      => myLotQty                                                                               
							                    ,myLotCntInd   => myLotCntInd                                                                            
							                    ,myRMAPrice	  => myRMAPrice                                                                              
							                    );                                                                                                       
                                                                                                                                    
					if myRetCode != 0 then                                                                                                         
						--dbms_output.put_line('return from track: ' |                                                                                
| myRetMesg);                                                                                                                       
						raise RECEIPT_ERROR;                                                                                                          
					end if;                                                                                                                        
                                                                                                                                    
					dbms_output.put_line('Track Loaded SerialID: ' || mySerialID || ' Mfg:                                                         
 ' || mySerials(j).MFG_DATE || ' Rcpt Dt: ' || mySer                                                                                
ials(j).RECEIPT_DATE);                                                                                                              
					mySect := 'RMA Receipt - Updt Serial';                                                                                         
					update DEX_SERIALS set                                                                                                         
					RECEIVE_DATE = myRcvDate                                                                                                       
				  ,ATTRIBUTE5 = mySerials(j).MFG_DATE                                                                                           
				  ,REF_SERIAL_ID = mySerials(j).REF_SERIAL_ID                                                                                   
					where  SERIAL_ID = mySerialID;                                                                                                 
				end loop;                                                                                                                       
                                                                                                                                    
				if myRetCode != 0 then                                                                                                          
					raise RECEIPT_ERROR;                                                                                                           
				end if;                                                                                                                         
			exception                                                                                                                        
				when RECEIPT_ERROR then                                                                                                         
						--dbms_output.put_line ('receipt error throw except: ' || myRe                                                                
tMesg);                                                                                                                             
						XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                               
           													  p_exception_name_i        => 'DE                                                                          
X_APPL_ERROR'                                                                                                                       
           													 ,p_appl_short_name_i       => DEX_APP_F                                                                    
                                                                                                                                    
           													 ,p_token_name_list_i       => xxcts_fea_utl_exceptio                                                       
n.token_name_tab_type                                                                                                               
											                                                                                                                         
    ('ERROR_MESSAGE')                                                                                                               
           													 ,p_token_value_list_i      => x                                                                            
xcts_fea_utl_exception.token_value_tab_type                                                                                         
           													                                   (                                                                        
myRetMesg)                                                                                                                          
           													 );                                                                                                         
                                                                                                                                    
				when OTHERS then                                                                                                                
						myRetMesg := mySect || ' Error: ' || SQLERRM;                                                                                 
						dbms_output.put_line(substr('Other Error: ' || SQLERRM,1,255));                                                               
                                                                                                                                    
						XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                               
           													  p_exception_name_i        => 'DEX_APPL_                                                                   
ERROR'                                                                                                                              
           													 ,p_appl_short_name_i       => DEX_APP_F                                                                    
           													 ,p_token_name_list_i       => xxc                                                                          
ts_fea_utl_exception.token_name_tab_type                                                                                            
											                                                 ('E                                                                     
RROR_MESSAGE')                                                                                                                      
           													 ,p_token_value_list_i      => xxcts_fe                                                                     
a_utl_exception.token_value_tab_type                                                                                                
           													                                   (myRetMe                                                                 
sg)                                                                                                                                 
           													 );                                                                                                         
			end;                                                                                                                             
		end loop;                                                                                                                         
	exception                                                                                                                          
		when XXCTS_FEA_UTL_EXCEPTION.BUSINESS_EXCEPTION then                                                                              
			ROLLBACK TO RECEIPT_SAVEPOINT;                                                                                                   
                                                                                                                                    
			if myFromInternal = 'Y' then                                                                                                     
				raise_application_error ( -20001, myRetMesg );                                                                                  
			else                                                                                                                             
				LOG_BUSINESS_EXCEPTION ( myEntityID	   => nvl(myRMA,myCall)                                                                     
											   ,myInvOrgID	 	=> myInvOrgID                                                                                           
											   ,myErrMesg	 	=> myRetMesg                                                                                             
											   ,myExceptName 	=> XXDEX_CISCO_GLOBAL_K                                                                                
.CTS_DEX_RMA_RECEIPT_FAILED                                                                                                         
											  );                                                                                                                     
				RAISE;                                                                                                                          
			end if;                                                                                                                          
                                                                                                                                    
		when OTHERS then                                                                                                                  
			myRetMesg := mySect || ' Error: ' || SQLERRM;                                                                                    
			ROLLBACK TO RECEIPT_SAVEPOINT;                                                                                                   
                                                                                                                                    
			if myFromInternal = 'Y' then                                                                                                     
				raise_application_error ( -20001, myRetMesg );                                                                                  
			else                                                                                                                             
				begin                                                                                                                           
					LOG_BUSINESS_EXCEPTION ( myEntityID	   => nvl(myRMA,myCall)                                                                    
												   ,myInvOrgID	 	=> myInvOrgID                                                                                          
												   ,myErrMesg	 	=> myRetMesg                                                                                            
												   ,myExceptName 	=> XXDEX_CISCO_GLOBAL_K.CTS_DEX_RMA_RECEIPT_                                                          
FAILED                                                                                                                              
												  );                                                                                                                    
					XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                                
    													  p_exception_name_i        => 'DEX_APPL_ERROR'                                                                    
     													 ,p_appl_short_name_i       => DEX_APP                                                                            
_F                                                                                                                                  
     													 ,p_token_name_list_i       => xxcts_fea_utl_exception.to                                                         
ken_name_tab_type                                                                                                                   
					                                                 ('ERRO                                                                        
R_MESSAGE')                                                                                                                         
     													 ,p_token_value_list_i      => xxcts_fea_utl_exc                                                                  
eption.token_value_tab_type                                                                                                         
										                                   (myRetMesg)                                                                            
     													 );                                                                                                               
				exception                                                                                                                       
					when OTHERS then                                                                                                               
						RAISE;                                                                                                                        
				end;                                                                                                                            
			end if;                                                                                                                          
	end RMA_RECEIPT;                                                                                                                   
                                                                                                                                    
	/***************************************************************                                                                   
*************************************                                                                                               
	  function called internally by another procedure                                                                                  
	  ****************************************************************                                                                 
***********************************/                                                                                                
	function RMA_RECEIPT ( myInvOrgID			in 	NUMBER                                                                                     
								  ,mySubInvCode		in 	VARCHAR2			-- Optional                                                                                 
								  ,myReceipts	  		in 	XXDEX_CISCO_GLOBAL_K.RECEIPTS_TBL                                                                     
								  ) return varchar2 is                                                                                                      
                                                                                                                                    
		myRetMesg varchar2(2000);                                                                                                         
	begin                                                                                                                              
		myFromInternal := 'Y';                                                                                                            
		RMA_RECEIPT ( myInvOrgID		 => myInvOrgId                                                                                          
						 ,mySubInvCode		 => mySubInvCode                                                                                              
						 ,myReceipts	    => myReceipts                                                                                                
						 );                                                                                                                           
		myFromInternal := 'N';                                                                                                            
		return ( myRetMesg );                                                                                                             
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			myFromInternal := 'N';                                                                                                           
			myRetMesg := replace( SQLERRM,'ORA-20001: ','');			--- trim off erro                                                             
r number                                                                                                                            
			-- dbms_output.put_line( 'function rma_receipt: ' || myRetMesg);                                                                 
			return ( myRetMesg );                                                                                                            
	end RMA_RECEIPT;                                                                                                                   
                                                                                                                                    
	/***********************************************************                                                                       
*****************************************                                                                                           
	 Will determine the Repair RMA/Order for the Work Order Tran                                                                       
ID and Serial                                                                                                                       
	 **************************************************************                                                                    
*************************************/                                                                                              
	procedure FIND_REPAIR_ORDER( myRetCode     out number                                                                              
										 ,myRetMesg     out varchar2                                                                                              
										 ,myRepOrder    out varchar2                                                                                              
									  	 ,myRepRMA      out varchar2                                                                                            
									  	 ,myRecPlantID  out number                                                                                              
									  	 ,myRepPlantID  out number                                                                                              
									  	 ,mySerialID	 out number                                                                                                
									  	 ,myInvOrgId	 in  number                                                                                                
									  	 ,myWOTranID    in  number                                                                                              
									  	 ,myRMANbr		 in  varchar2                                                                                               
									  	 ,mySerial      in  varchar2                                                                                            
									  	) is                                                                                                                    
                                                                                                                                    
		myCust 	ORDERS.CUST%type;                                                                                                         
		myIntRMA	SERIALS.RMA_NUMBER%type;                                                                                                 
		FIND_ERROR EXCEPTION;                                                                                                             
	begin                                                                                                                              
		begin                                                                                                                             
			mySect := 'Find Rep Order - Select';                                                                                             
			select ord.RMA                                                                                                                   
					,nvl(lne.REPAIR_PLANT_ID,ord.PLANT_ID)                                                                                         
					,ord.PLANT_ID                                                                                                                  
					,ord.ORDERNO                                                                                                                   
					,ser.SERIAL_ID                                                                                                                 
					,ser.RMA_NUMBER                                                                                                                
			into   myRepRMA                                                                                                                  
					,myRepPlantID                                                                                                                  
					,myRecPlantId                                                                                                                  
					,myRepOrder                                                                                                                    
					,mySerialID                                                                                                                    
					,myIntRMA                                                                                                                      
			from   DEX_ORDERS ord                                                                                                            
					,DEX_LINES lne                                                                                                                 
					,DEX_SERIALS ser                                                                                                               
			where  ser.TRAN_SET_ID  = myWOTranID                                                                                             
			and	 (ser.ORIG_SERIAL = mySerial or ser.SERIAL      = mySerial or                                                                
ser.TRACK = mySerial)                                                                                                               
			and    ser.ORDERNO      = lne.ORDERNO                                                                                            
			and    ser.ITEM         = lne.ITEM                                                                                               
			and    lne.ORDERNO      = ord.ORDERNO;                                                                                           
   	exception                                                                                                                       
			when NO_DATA_FOUND then                                                                                                          
				myRetMesg := 'Serial: ' || mySerial || ' not found for Work Order Tran I                                                        
D: ' || myWOTranID;                                                                                                                 
				raise FIND_ERROR;                                                                                                               
   	end;                                                                                                                            
                                                                                                                                    
		if myRepPlantId != myInvOrgID then                                                                                                
			myRetMesg := 'Inv Org ID: ' || myInvOrgID || ' is not tied to Wo                                                                 
rk Order Tran ID: ' || myWOTranID;                                                                                                  
			raise FIND_ERROR;                                                                                                                
		end if;                                                                                                                           
                                                                                                                                    
   	if myRepPlantID != myRecPlantID then                                                                                            
			mySect := 'Find Rep RMA/Order';                                                                                                  
			-- Find RMA/Order tied to WO TranID in Repair Plant                                                                              
			begin                                                                                                                            
				select CALL                                                                                                                     
				into   myRepRMA                                                                                                                 
				from   DEX_RMAHDR                                                                                                               
				where  CALL = myIntRMA                                                                                                          
				and    PLANT_ID = myRepPlantID;                                                                                                 
                                                                                                                                    
				myRepOrder := null;                                                                                                             
				mySerialID := null;                                                                                                             
				begin                                                                                                                           
					select s.SERIAL_ID                                                                                                             
							,s.ORDERNO                                                                                                                   
					into   mySerialID                                                                                                              
							,myRepOrder                                                                                                                  
					from   DEX_ORDERS o                                                                                                            
							,DEX_SERIALS s                                                                                                               
					where  o.RMA = myRepRMA                                                                                                        
					and    o.PLANT_ID = myRepPlantID                                                                                               
					and    o.ORDERNO = s.ORDERNO                                                                                                   
					and   (s.SERIAL = mySerial or s.TRACK = mySerial)                                                                              
					and    rownum < 2;                                                                                                             
				exception                                                                                                                       
					when NO_DATA_FOUND then                                                                                                        
						null;                                                                                                                         
				end;                                                                                                                            
			exception                                                                                                                        
				when NO_DATA_FOUND then                                                                                                         
					myRetMesg := 'Cannot find Repair RMA/Order for Wor                                                                             
k Order Tran ID: ' || myWOTranID || ' RMA: ' || myRM                                                                                
ANbr;                                                                                                                               
					raise FIND_ERROR;                                                                                                              
			end;                                                                                                                             
		end if;                                                                                                                           
		myRetCode := 0;                                                                                                                   
                                                                                                                                    
	exception                                                                                                                          
		when FIND_ERROR then                                                                                                              
			myRetCode := 1;                                                                                                                  
		when OTHERS then                                                                                                                  
			myRetCode := 2;                                                                                                                  
			myRetMesg := mySect || ' ' || SQLERRM;                                                                                           
	end FIND_REPAIR_ORDER;                                                                                                             
	/*************************************************************                                                                     
***************************************                                                                                             
	 	This procedure is execute by C3 B2B after Work Order Status C                                                                    
ompletd (7B1) notifications are received                                                                                            
	 	from the Outsource /Autohorized and Repair Net partners.  Th                                                                     
is procedure will move the Serials to the                                                                                           
	 	appropriate location in preperation of shipment.                                                                                 
	*************************************************************                                                                      
*****************************************/                                                                                          
                                                                                                                                    
	procedure STATUS_UPDATE	 ( myInvOrgID		in 	NUMBER                                                                                  
								    ,mySubInvCode		in 	VARCHAR2			-- Optional                                                                               
									 ,myWorkOrders		in 	XXDEX_CISCO_GLOBAL_K.WORK_ORDE                                                                         
RS_TBL                                                                                                                              
 							 		 ) is                                                                                                                    
                                                                                                                                    
		myRetMesg	varchar2(1000);                                                                                                         
		myRetCode	number;                                                                                                                 
		myWOCnt		number;                                                                                                                  
                                                                                                                                    
		mySerial 	SERIALS.SERIAL%type;                                                                                                    
		myOSerial 	SERIALS.SERIAL%type;                                                                                                   
		myFSerial 	SERIALS.SERIAL%type;                                                                                                   
		myOrder		SERIALS.ORDERNO%type;                                                                                                    
		myCust		ORDERS.CUST%type;                                                                                                         
		myLocation	SERIALS.LOCATION%type;                                                                                                 
		myScrap	   SERIALS.SCRAP%type;                                                                                                    
		myFailure	SERIALS.FAILURE%type;                                                                                                   
		myReason	 	SERIALS.REASON%type;                                                                                                   
                                                                                                                                    
		myPart		LINES.PART%type;                                                                                                          
		myWOPart		LINES.PART%type;                                                                                                        
		myRMA			ORDERS.RMA%type;                                                                                                          
		myWORma		ORDERS.RMA%type;                                                                                                         
                                                                                                                                    
		myWOTranID	number;                                                                                                                
		mySerialID	number;                                                                                                                
		myWarrID		number;                                                                                                                 
		myStep		number;                                                                                                                   
		myItemID		number;                                                                                                                 
		myWOItemID	number;                                                                                                                
		myPrice		number;                                                                                                                  
		myPlantID	number;                                                                                                                 
		myItem		number;                                                                                                                   
                                                                                                                                    
		myActive		varchar2(1);                                                                                                            
		myStatus		varchar2(10);                                                                                                           
		myStatDate	date;                                                                                                                  
		mySerChgRsn	varchar2(200);                                                                                                        
                                                                                                                                    
		myRcptDtl	XXDEX_CISCO_GLOBAL_K.RECEIPTS_TBL;                                                                                      
		mySerials	XXDEX_CISCO_GLOBAL_K.RCPT_SERIALS_TBL;                                                                                  
		myRdx			pls_integer;                                                                                                              
		mySdx			pls_integer;                                                                                                              
                                                                                                                                    
		myRepRMA		ORDERS.RMA%type;                                                                                                        
		myAuthorization	ORDERS.RMA%type;                                                                                                  
		myRepPlantID	number;                                                                                                              
		myRecPlantID	number;                                                                                                              
                                                                                                                                    
		UPDATE_ERROR	EXCEPTION;                                                                                                           
	begin                                                                                                                              
		SAVEPOINT STATUS_SAVEPOINT;                                                                                                       
		mySect := 'WO Update - Begin';                                                                                                    
		myWOCnt := myWorkOrders.COUNT;                                                                                                    
		for i in 1 .. myWOCnt loop                                                                                                        
			begin                                                                                                                            
				mySerial    := myWorkOrders(i).SERIAL_NUMBER;                                                                                   
				myOSerial   := myWorkOrders(i).ORIG_SERIAL_NBR;                                                                                 
				mySerial   := nvl(mySerial,myOSerial);                                                                                          
				myOSerial  := nvl(myOSerial,mySerial);                                                                                          
                                                                                                                                    
                                                                                                                                    
				myWOTranID  := myWorkOrders(i).WO_TRAN_ID;                                                                                      
				myStatus	   := myWorkOrders(i).STATUS_CODE;                                                                                     
				myStatDate  := myWorkOrders(i).STATUS_DATE;                                                                                     
				mySerChgRsn := myWorkOrders(i).SERIAL_CHG_REASON;                                                                               
				myWOPart		:= myWorkOrders(i).PART_NUMBER;                                                                                       
				myWORma     := myWorkOrders(i).RMA_NBR;                                                                                         
                                                                                                                                    
				mySect := 'WO Update - Find WO';                                                                                                
                                                                                                                                    
				FIND_REPAIR_ORDER(myRetCode     => myRetCode                                                                                    
									  ,myRetMesg     => myRetMesg                                                                                              
									  ,myRepOrder    => myOrder                                                                                                
									  ,myRepRMA      => myRepRMA                                                                                               
									  ,myRecPlantID  => myRecPlantID                                                                                           
									  ,myRepPlantID  => myRepPlantID                                                                                           
									  ,mySerialID	  => mySerialID                                                                                              
									  ,myInvOrgId	  => myInvOrgId                                                                                              
									  ,myWOTranID    => myWOTranID                                                                                             
									  ,myRMANbr      => myWORMA                                                                                                
									  ,mySerial      => myOSerial                                                                                              
									  );                                                                                                                       
				if myRetCode != 0 then                                                                                                          
					raise UPDATE_ERROR;                                                                                                            
				end if;                                                                                                                         
                                                                                                                                    
				if myStatus = 'RC' then                                                                                                         
					if  mySerialID is not null then                                                                                                
						myRetMesg := 'Serial: ' || myOSerial || ' already re                                                                          
cieved.';                                                                                                                           
						raise UPDATE_ERROR;                                                                                                           
                                                                                                                                    
					else                                                                                                                           
						-- Add to RMA Receipt Structure. Process Receipts a                                                                           
fter                                                                                                                                
						mySect := 'WO Update - Receipt';                                                                                              
						myRdx := 0;                                                                                                                   
						for i in 1 .. myRcptDtl.COUNT loop                                                                                            
							if myWOPart = myRcptDtl(i).PART_NUMBER and myR                                                                               
cptDtl(i).RMA_NBR = myRepRMA then                                                                                                   
								myRdx := i;                                                                                                                 
								exit;                                                                                                                       
							end if;                                                                                                                      
						end loop;                                                                                                                     
						if myRdx = 0 then                                                                                                             
							myRdx := myRcptDtl.COUNT + 1;                                                                                                
							myRcptDtl(myRdx).RMA_NBR := myRepRMA;                                                                                        
							myRcptDtl(myRdx).PART_NUMBER := myWOPart;                                                                                    
							myRcptDtl(myRdx).RECEIPT_DATE := TRUNC(SYSDATE);                                                                             
						end if;                                                                                                                       
						mySerials := myRcptDtl(myRdx).SERIALS_TBL;                                                                                    
						mySdx := mySerials.COUNT;                                                                                                     
						mySdx := mySdx + 1;                                                                                                           
						mySerials(mySdx).SERIAL_NUMBER := mySerial;                                                                                   
						mySerials(mySdx).ORIG_SERIAL_NBR := myOSerial;                                                                                
						myRcptDtl(myRdx).SERIALS_TBL := mySerials;                                                                                    
						myRcptDtl(myRdx).QUANTITY := mySerials.COUNT;                                                                                 
         		end if;                                                                                                                  
                                                                                                                                    
				elsif myStatus = 'WC' then                                                                                                      
					mySect := 'WO Update - Work Order Complete';                                                                                   
					begin                                                                                                                          
						select loc.STEP                                                                                                               
								,lne.PART                                                                                                                   
								,lne.INVENTORY_ITEM_ID                                                                                                      
								,ser.LOCATION                                                                                                               
								,lne.ITEM                                                                                                                   
						into   myStep                                                                                                                 
								,myPart                                                                                                                     
								,myItemID                                                                                                                   
								,myLocation                                                                                                                 
								,myItem                                                                                                                     
						from   DEX_LINES lne                                                                                                          
								,DEX_LOCATIONS loc                                                                                                          
								,DEX_SERIALS ser                                                                                                            
						where  ser.ORDERNO = myOrder                                                                                                  
						and    ser.SERIAL_ID = mySerialID                                                                                             
						and    ser.LOCATION != 'SHP'                                                                                                  
						and    ser.LOCATION = loc.LOCATION                                                                                            
						and    ser.ORDERNO = lne.ORDERNO                                                                                              
						and    ser.ITEM    = lne.ITEM                                                                                                 
						and    rownum < 2;                                                                                                            
                                                                                                                                    
						if myPart != myWOPart then                                                                                                    
							myWOItemID := F_DEX_ITEM_ID(myWOPart);                                                                                       
							myActive := XXDEX_ITEM_ACTIVE_F ( myWOItemID, myInvOrgID);                                                                   
   			   		if myActive = 'N' then                                                                                                   
   	 						myRetMesg := 'Part Number: ' || myWOPart || ' Not Active in Org:                                                         
' || DEX_ORGANIZATIONS_K.CODE ( myInvOrgID);                                                                                        
   	 						raise UPDATE_ERROR;                                                                                                      
   	 					end if;                                                                                                                   
	      		 	end if;                                                                                                                  
						if myStep >= 7 then                                                                                                           
							myRetMesg := 'Work Order Complete for this Serial: ' || myOSer                                                               
ial || ' has already been processed. Loction in ' ||                                                                                
 myLocation;                                                                                                                        
							raise UPDATE_ERROR;                                                                                                          
						end if;                                                                                                                       
                                                                                                                                    
						myScrap := null;                                                                                                              
						myFailure := null;                                                                                                            
						if mySerChgRsn = 'NR' then                                                                                                    
							myReason := 'NR - Not Economical to Repair';                                                                                 
						elsif mySerChgRsn = 'LM' then                                                                                                 
							myReason := 'LM - Lemon';                                                                                                    
						elsif mySerChgRsn is not null then                                                                                            
							myReason := mySerChgRsn;                                                                                                     
						else                                                                                                                          
							myReason := null;                                                                                                            
						end if;                                                                                                                       
                                                                                                                                    
						if mySerial = myOSerial and mySerChgRsn = 'NR' then				                                                                       
	-- Not Economical to Repair                                                                                                        
							myScrap := 'Y';                                                                                                              
							myFailure := XXDEX_DEFAULTS_F ( 'BER_SCRAP_CO                                                                                
DE' );                                                                                                                              
						end if;                                                                                                                       
                                                                                                                                    
						-- dbms_output.put_line('update serial id:' || myS                                                                            
erialID);                                                                                                                           
						mySect := 'WO Update - Update Serials';                                                                                       
						update DEX_SERIALS set                                                                                                        
						LOCATION = 'QCS'                                                                                                              
					  ,SERIAL = mySerial                                                                                                           
					  ,TRACK  = mySerial                                                                                                           
					  ,REASON = nvl(myReason, REASON)                                                                                              
					  ,EXCHANGE_FLAG = decode(mySerial, myOSerial, 'N','Y')                                                                        
					  ,SCRAP   = nvl(myScrap, SCRAP)                                                                                               
					  ,FAILURE = nvl(myFailure, FAILURE)                                                                                           
					   where  SERIAL_ID = mySerialID;                                                                                              
                                                                                                                                    
					   if myItemID != myWOItemID then                                                                                              
					   	mySect := 'WO Update - Move Order';                                                                                        
					   	K_MOVE_ORDER.SERIAL (                                                                                                      
   			                               myRetMesg   => myRetMesg                                                                       
   			                              ,myRetCode   => myRetCode                                                                       
   			                              ,myOrder     => myOrd                                                                           
er                                                                                                                                  
   			                              ,myItem      => myItem                                                                          
      			                              ,mySerialID  => mySerialID                                                                   
      			                              ,myNPrice    =>                                                                              
 myPrice                                                                                                                            
      			                              ,myNItemID   => myWOItemID                                                                   
      			                             );                                                                                            
							if myRetCode != 0 then                                                                                                       
								raise UPDATE_ERROR;                                                                                                         
							end if;                                                                                                                      
						end if;                                                                                                                       
                                                                                                                                    
					exception                                                                                                                      
						when NO_DATA_FOUND then                                                                                                       
							myRetMesg := 'Serial: ' || myOSerial || ' has not been r                                                                     
eceived for Work Order Tran ID: ' || myWOTranID;                                                                                    
							raise UPDATE_ERROR;                                                                                                          
					end;                                                                                                                           
				end if;                                                                                                                         
			exception                                                                                                                        
				when UPDATE_ERROR then                                                                                                          
					XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                                
    													  p_exception_name_i        => 'DEX_APPL_E                                                                         
RROR'                                                                                                                               
     													 ,p_appl_short_name_i       => DEX_APP_F                                                                          
     													 ,p_token_name_list_i       => xxcts_fea_utl_ex                                                                   
ception.token_name_tab_type                                                                                                         
					                                                 ('ERROR_MESSAGE')                                                             
     													 ,p_token_value_list_i      => xxcts_f                                                                            
ea_utl_exception.token_value_tab_type                                                                                               
										                                   (myRetMesg)                                                                            
     													 );                                                                                                               
			end;                                                                                                                             
		end loop;                                                                                                                         
                                                                                                                                    
		-- Use Standard RMA Receipt API to receive in product                                                                             
		myRdx := myRcptDtl.COUNT;                                                                                                         
		if myRdx > 0 then                                                                                                                 
			begin                                                                                                                            
				RMA_RECEIPT ( myInvOrgID	=> myInvOrgID                                                                                          
							  	 ,mySubInvCode	=> mySubInvcode                                                                                            
								 ,myReceipts	=> myRcptDtl                                                                                                   
					 			);                                                                                                                         
			exception                                                                                                                        
				when OTHERS then                                                                                                                
					myRetMesg := SQLERRM;                                                                                                          
					XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                                
    													  p_exception_name_i        => 'DEX_APPL_ERROR'                                                                    
     													 ,p_appl_short_name_i       => DEX_A                                                                              
PP_F                                                                                                                                
     													 ,p_token_name_list_i       => xxcts_fea_utl_exception.                                                           
token_name_tab_type                                                                                                                 
					                                                 ('ER                                                                          
ROR_MESSAGE')                                                                                                                       
     													 ,p_token_value_list_i      => xxcts_fea_utl_e                                                                    
xception.token_value_tab_type                                                                                                       
										                                   (myRetMesg)                                                                            
     													 );                                                                                                               
			end;                                                                                                                             
		end if;                                                                                                                           
                                                                                                                                    
	exception                                                                                                                          
		when XXCTS_FEA_UTL_EXCEPTION.BUSINESS_EXCEPTION then                                                                              
			ROLLBACK TO STATUS_SAVEPOINT;                                                                                                    
                                                                                                                                    
			if myFromInternal = 'Y' then                                                                                                     
				raise_application_error ( -20001, myRetMesg );                                                                                  
			else                                                                                                                             
				LOG_BUSINESS_EXCEPTION ( myEntityID	   => myWORMA                                                                               
											   ,myInvOrgID	 	=> myInvOrgID                                                                                           
											   ,myErrMesg	 	=> myRetMesg                                                                                             
											   ,myExceptName 	=> XXDEX_CISCO_GLOBAL_K.CTS_DEX_STAT                                                                   
US_UPDATE_FAILED                                                                                                                    
											  );                                                                                                                     
                                                                                                                                    
				-- dbms_output.put_line('Business Exception: ' || SQLERRM);                                                                     
				RAISE;                                                                                                                          
			end if;                                                                                                                          
                                                                                                                                    
		when OTHERS then                                                                                                                  
			myRetMesg := mySect || ' Error: ' || SQLERRM;                                                                                    
			ROLLBACK TO STATUS_SAVEPOINT;                                                                                                    
                                                                                                                                    
			if myFromInternal = 'Y' then                                                                                                     
				raise_application_error ( -20001, myRetMesg );                                                                                  
			else                                                                                                                             
				begin                                                                                                                           
					LOG_BUSINESS_EXCEPTION ( myEntityID	   => myWORMA                                                                              
												   ,myInvOrgID	 	=> myInvOrgID                                                                                          
												   ,myErrMesg	 	=> myRetMesg                                                                                            
												   ,myExceptName 	=> XXDEX_CISCO_GLOBAL_K.CTS                                                                           
_DEX_STATUS_UPDATE_FAILED                                                                                                           
												  );                                                                                                                    
                                                                                                                                    
					XXCTS_FEA_UTL_EXCEPTION.THROW (                                                                                                
    														  p_exception_name_i        => 'DEX_APPL_ERROR'                                                                   
     														 ,p_appl_short_name_i       => DEX_APP_F                                                                         
     														 ,p_token_name_list_i       => xxc                                                                               
ts_fea_utl_exception.token_name_tab_type                                                                                            
					         	                                        ('ERROR_                                                                     
MESSAGE')                                                                                                                           
     														 ,p_token_value_list_i      => xxcts_fea_utl_exce                                                                
ption.token_value_tab_type                                                                                                          
											                                   (myRetMesg)                                                                           
     														 );                                                                                                              
				exception                                                                                                                       
					when OTHERS then                                                                                                               
						RAISE;                                                                                                                        
				end;                                                                                                                            
			end if;                                                                                                                          
	end STATUS_UPDATE;                                                                                                                 
                                                                                                                                    
	/************************************************************                                                                      
****************************************                                                                                            
	  function called internally by another procedure                                                                                  
	  *************************************************************                                                                    
**************************************/                                                                                             
	function STATUS_UPDATE	 ( myInvOrgID		in 	NUMBER                                                                                   
								     ,mySubInvCode		in 	VARCHAR2			-- Optional                                                                              
									  ,myWorkOrders		in 	XXDEX_CISCO_GLOBAL_K.WORK_ORDERS_                                                                     
TBL                                                                                                                                 
 							 		 )  return varchar2 is                                                                                                   
                                                                                                                                    
		myRetMesg varchar2(2000);                                                                                                         
	begin                                                                                                                              
		myFromInternal := 'Y';                                                                                                            
		STATUS_UPDATE (  myInvOrgID		 => myInvOrgId                                                                                       
							 ,mySubInvCode		 => mySubInvCode                                                                                             
							 ,myWorkOrders	    => myWorkOrders                                                                                           
							 );                                                                                                                          
		myFromInternal := 'N';                                                                                                            
		return ( myRetMesg );                                                                                                             
	exception                                                                                                                          
		when OTHERS then                                                                                                                  
			myFromInternal := 'N';                                                                                                           
			myRetMesg := replace( SQLERRM,'ORA-20001: ','');			--- trim off error                                                            
number                                                                                                                              
			-- dbms_output.put_line( 'function status_update: ' || myRetMesg);                                                               
			return ( myRetMesg );                                                                                                            
	end STATUS_UPDATE;                                                                                                                 
                                                                                                                                    
	/*********************************************************                                                                         
*******************************************                                                                                         
	 	This procedure is execute by C3 B2B after Quality Data No                                                                        
tifications (7C6) are received from                                                                                                 
	 	Outsource /Autohorized and Repair Net partners.  This procedure w                                                                
ill populdate the failure data                                                                                                      
	 	and failure detail data associated to the Serial.                                                                                
	***********************************************************************                                                            
*******************************/                                                                                                    
	procedure QUALITY_UPDATE ( myInvOrgID		in 	NUMBER                                                                                  
								  	  ,mySubInvCode	in 	VARCHAR2			-- Optional                                                                               
									  ,myQualRcds		in 	XXDEX_CISCO_GLOBAL_K.QUAL_DATA_TBL                                                                      
									  ) is                                                                                                                     
                                                                                                                                    
		myRepSyms		XXDEX_CISCO_GLOBAL_K.QUAL_RPT_SYMP_TBL;                                                                                
		myComps			XXDEX_CISCO_GLOBAL_K.QUAL_COMPS_TBL;                                                                                    
		myDatas			XXDEX_CISCO_GLOBAL_K.QUAL_VERI_TBL;                                                                                     
                                                                                                                                    
		myUserID			number;                                                                                                                
                                                                                                                                    
		myDate			date := SYSDATE;                                                                                                         
		myRepDate		date;                                                                                                                  
		myMfgDate		date;                                                                                                                  
                                                                                                                                    
		myMfgYear		number(4);                                                                                                             
		myMfgMon			number(2);                                                                                                             
		myTranID    	number;                                                                                                              
		myFailID    	number;                                                                                                              
		mySerialID		number;                                                                                                               
		myWarrID			number;                                                                                                                
		myRptSymID  	number;                                                                                                              
		myFirstRptSymID number;                                                                                                           
		myFailCdID  	number;                                                                                                              
		myRepActID  	number;                                                                                                              
		myFailDtlID		number;                                                                                                              
		myItemID			number;                                                                                                                
		myNItemID		number;                                                                                                                
		myROrgID			number;                                                                                                                
		myPrice			number;                                                                                                                 
		myCustID			number;                                                                                                                
		myEmpID			number;                                                                                                                 
		myRProcID		number;                                                                                                                
		myCPrice			number;                                                                                                                
		myStep			number;                                                                                                                  
		myWOTranID		number;                                                                                                               
		myRecPlantID 	number;                                                                                                             
		myRepPlantId 	number;                                                                                                             
		myRepRuleID	 	number;                                                                                                             
		mySvcCatgID	 	number;                                                                                                             
		myItem			number;                                                                                                                  
                                                                                                                                    
		mySerial			SERIALS.SERIAL%type;                                                                                                   
		myFSerial		SERIALS.SERIAL%type;                                                                                                   
		myOSerial		SERIALS.SERIAL%type;                                                                                                   
                                                                                                                                    
		myRMANbr			ORDERS.RMA%type;                                                                                                       
		myOrder			ORDERS.ORDERNO%type;                                                                                                    
		myExchOrder 	ORDERS.ORDERNO%type;                                                                                                 
		myRepRMA			ORDERS.RMA%type;                                                                                                       
		mySympCd			varchar2(15);                                                                                                          
                                                                                                                                    
		myOrigRepActCd	varchar2(20);                                                                                                      
		myEmpNo			varchar2(20);                                                                                                           
		myRepGrp			V_DEX_PART_DATA.REPAIR_GRP%type;                                                                                       
		myCustBuy		ORDERS.CUST%type;                                                                                                      
		myBillType		DEX_CUSTOMER_DATA.ADVREP_BILL_TYPE%typ                                                                                
e;                                                                                                                                  
		myAdvRep			DEX_CUSTOMER_DATA.ADVREP_FLAG%type;                                                                                    
		myWarranty		SERIALS.WARRANTY%type;                                                                                                
		myWarr			varchar2(1);                                                                                                             
		myScrap			SERIALS.SCRAP%type;                                                                                                     
		myOrdType		ORDERS.ORDTYPE%type;                                                                                                   
		myRProcCode		DEX_CODES.CODE%type;                                                                                                 
		myParent			DEX_CUSTOMER_DATA.PARENT_CODE%type;                                                                                    
		myRepActCd		varchar2(20);                                                                                                         
		myAcctgInd		varchar2(10);                                                                                                         
		myPart			DEX_LINES.PART%type;                                                                                                     
		myOrigPart		DEX_LINES.PART%type;                                                                                                  
		myPartExchFlag	varchar2(1);                                                                                                       
                                                                                                                                    
		myFaultCd		varchar2(50);                                                                                                          
		myCauseCd		varchar2(50);                                                                                                          
		myRepairCd		varchar2(50);                                                                                                         
                                                                                                                                    
		myRetCode		number;                                                                                                                
		myRetMesg		varchar2(1000);                                                                                                        
                                                                                                                                    
		QUALITY_ERROR	EXCEPTION;                                                                                                          
		TABLE_ERROR 	EXCEPTION;                                                                                                           
                                                                                                                                    
		function GET_CODE_ID (myType varchar2, myCode varchar2) return numbe                                                              
r is                                                                                                                                
			myCodeId number;                                                                                                                 
		begin                                                                                                                             
			select dc.CODE_ID                                                                                                                
			into   myCodeID                                                                                                                  
			from   DEX_CODES dc                                                                                                              
					,DEX_CODE_TYPES  dct                                                                                                           
			where dct.LOCATION = 'QCP'                                                                                                       
			and   dct.TYPE = myType                                                                                                          
			and   dct.CODE_TYPE_ID = dc.CODE_TYPE_ID                                                                                         
			and   dc.CODE = myCode;                                                                                                          
			return ( myCodeID );                                                                                                             
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				return (null);                                                                                                                  
		end GET_CODE_ID;                                                                                                                  
                                                                                                                                    
		function GET_FAIL_ID(myFailCode varchar2, myFailType varchar2)                                                                    
 return number is                                                                                                                   
			myCodeID number;                                                                                                                 
		begin                                                                                                                             
			select FAIL_CODE_ID                                                                                                              
			into   myCodeID                                                                                                                  
			from   DEX_FAIL_CODES                                                                                                            
			where  FAIL_TYPE = myFailType                                                                                                    
			and    FAIL_CODE = myFailCode;                                                                                                   
			return ( myCodeID );                                                                                                             
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				return (null);                                                                                                                  
		end GET_FAIL_ID;                                                                                                                  
                                                                                                                                    
		function REPAIR_RULE_ID ( myFaultCd varchar2, myCauseC                                                                            
d varchar2, myRepairCd varchar2 ) return number is                                                                                  
			myRuleID number;                                                                                                                 
		begin                                                                                                                             
			select REPAIR_RULE_ID                                                                                                            
			into   myRuleID                                                                                                                  
			from   XXDEX_CISCO_REPAIR_COMB_V                                                                                                 
			where  SERVICE_CATEGORY_ID = mySvcCatgID                                                                                         
			and    FAULT_CODE = myFaultCd                                                                                                    
			and    CAUSE_CODE = myCauseCd                                                                                                    
			and    REPAIR_CODE = myRepairCd;                                                                                                 
			return ( myRuleID );                                                                                                             
		exception                                                                                                                         
			when NO_DATA_FOUND then                                                                                                          
				return (null);                                                                                                                  
		end REPAIR_RULE_ID;                                                                                                               
                                                                                                                                    
	begin                                                                                                                              
		SAVEPOINT QUALITY_SAVEPOINT;                                                                                                      
                                                                                                                                    
		mySect := 'Quality - Begin';                                                                                                      
		myUserID := XXDEX_CISCO_GLOBAL_K.B2B_USERID;                                                                                      
		myEmpNo	:= XXDEX_CISCO_GLOBAL_K.B2B_EMPNO;                                                                                        
                                                                                                                                    
		select EMPLOYEE_ID                                                                                                                
		into   myEmpID                                                                                                                    
		from   FND_USER                                                                                                                   
		where  USER_ID = myUserID;                                                                                                        
                                                                                                                                    
		myCustBuy := XXDEX_DEFAULTS_F('INTERNAL_CUST_BUY');                                                                               
                                                                                                                                    
		mySect := 'Quality - loop';                                                                                                       
		for i in 1 .. myQualRcds.COUNT loop                                                                                               
			begin                                                                                                                            
				if myRProcID is null then                                                                                                       
					begin                                                                                                                          
						mySect := 'Quality - Repair Proc';                                                                                            
						select dc.CODE_ID                                                                                                             
								,dc.CODE                                                                                                                    
						into   myRProcID                                                                                                              
								,myRProcCode                                                                                                                
						from   DEX_CODES dc                                                                                                           
								,DEX_CODE_TYPES  dct                                                                                                        
						where dct.LOCATION = 'QCP'                                                                                                    
						and   dct.TYPE = 'Process'                                                                                                    
						and   dct.CODE_TYPE_ID = dc.CODE_TYPE_ID                                                                                      
						and   upper(dc.DESCRIPTION) = 'REPAIR';                                                                                       
					exception                                                                                                                      
						when NO_DATA_FOUND then                                                                                                       
							myRetMesg := 'Repair Process Step not found.';                                                                               
							raise QUALITY_ERROR;                                                                                                         
					end;                                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				mySect := 'Quality - Table Var';                                                                                                
				begin                                                                                                                           
					mySerial   := myQualRcds(i).SERIAL_NUMBER;                                                                                     
				exception                                                                                                                       
					when OTHERS then                                                                                                               
						 raise TABLE_ERROR;                                                                                                           
				end;                                                                                                                            
                                                                                                                                    
				mySerial   := myQualRcds(i).SERIAL_NUMBER;                                                                                      
				myOSerial  := myQualRcds(i).ORIG_SERIAL_NUMBER;                                                                                 
				mySerial   := nvl(mySerial,myOSerial);                                                                                          
				myOSerial  := nvl(myOSerial,mySerial);                                                                                          
                                                                                                                                    
				if mySerial is null and myOSerial is null then                                                                                  
					myRetMesg := 'Original Serial or Serial must be sspecified';                                                                   
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				myWOTranID := myQualRcds(i).WO_TRAN_ID;                                                                                         
				myRMANbr   := myQualRcds(i).RMA_NBR;                                                                                            
				myRepDate  := nvl(myQualRcds(i).REPAIR_END_DATE,trunc(SY                                                                        
SDATE));                                                                                                                            
				myAcctgInd := myQualRcds(i).ACCTING_IND;                                                                                        
				myPart	  := myQualRcds(i).PART_NUMBER;                                                                                          
				myNItemId  := F_DEX_ITEM_ID(myPart);                                                                                            
				if nvl(myNItemID,0) = 0 and myPart is not null then                                                                             
					myRetMesg := 'Invalid Part Number: ' ||myPart;                                                                                 
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				myMfgYear := myQualRcds(i).YEAR_OF_MFG;                                                                                         
				myMfgMon  := myQualRcds(i).MONTH_OF_MFG;                                                                                        
				if myMfgMon is not null and myMfgYear is not null then                                                                          
					begin                                                                                                                          
						myMfgDate  := to_date( to_char(myMfgMon) || '/01/' || to_char(myMfgYea                                                        
r), 'mm/dd/yyyy');                                                                                                                  
					exception                                                                                                                      
						when OTHERS then                                                                                                              
							myRetMesg := 'Manufacturer Date Month (' || myMfgMon || ') or Year                                                           
 (' || myMfgYear || ') invalid.';                                                                                                   
							raise QUALITY_ERROR;                                                                                                         
					end;                                                                                                                           
				elsif myMfgMon is not null or myMfgYear is not null th                                                                          
en                                                                                                                                  
					myRetMesg := 'Incomplete Mfg Date provided';                                                                                   
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				-- dbms_output.put_line('WO: ' || myWOTranID || ' Serial: '                                                                     
|| mySerial || ' RMA: ' || myRMANbr);                                                                                               
				mySect := 'Quality - Find Repair Order';                                                                                        
				FIND_REPAIR_ORDER(myRetCode     => myRetCode                                                                                    
									  ,myRetMesg     => myRetMesg                                                                                              
									  ,myRepOrder    => myOrder                                                                                                
									  ,myRepRMA      => myRepRMA                                                                                               
									  ,myRecPlantID  => myRecPlantID                                                                                           
									  ,myRepPlantID  => myRepPlantID                                                                                           
									  ,mySerialID	  => mySerialID                                                                                              
									  ,myInvOrgId	  => myInvOrgId                                                                                              
									  ,myWOTranID    => myWOTranID                                                                                             
									  ,myRMANbr      => myRMANbr                                                                                               
									  ,mySerial      => myOSerial                                                                                              
									  );                                                                                                                       
                                                                                                                                    
				-- dbms_output.put_line('code: ' || myRetCode || ' Mes                                                                          
g: ' || myRetMesg);                                                                                                                 
				if myRetCode != 0 then                                                                                                          
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				if mySerialID is null then                                                                                                      
					myRetMesg := 'Serial: ' || mySerial || ' has not been receiv                                                                   
ed for Work Order Tran ID: ' || myWOTranID || ' RMA:                                                                                
 ' || myRMANbr;                                                                                                                     
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				mySect := 'Quality - Find Serial';                                                                                              
				select loc.Step                                                                                                                 
						,ser.FAILURE_ID                                                                                                               
						,ser.WARRANTY_ID                                                                                                              
						,lne.INVENTORY_ITEM_ID                                                                                                        
						,lne.ORGANIZATION_ID                                                                                                          
						,lne.PRICE                                                                                                                    
						,ord.CUSTOMER_ID                                                                                                              
						,nvl(dcd.ADVREP_FLAG,'N')                                                                                                     
						,dcd.ADVREP_BILL_TYPE                                                                                                         
						,ord.ORDTYPE                                                                                                                  
						,ser.SCRAP                                                                                                                    
						,dcd.PARENT_CODE                                                                                                              
						,ser.WARRANTY                                                                                                                 
						,lne.ITEM                                                                                                                     
				into   myStep                                                                                                                   
						,myFailID                                                                                                                     
						,myWarrID                                                                                                                     
						,myItemID                                                                                                                     
						,myROrgID                                                                                                                     
						,myPrice                                                                                                                      
						,myCustID                                                                                                                     
						,myAdvRep                                                                                                                     
						,myBillType                                                                                                                   
						,myOrdType                                                                                                                    
						,myScrap                                                                                                                      
						,myParent                                                                                                                     
						,myWarranty                                                                                                                   
						,myItem                                                                                                                       
				from   DEX_LOCATIONS loc                                                                                                        
						,DEX_FAILURE df                                                                                                               
						,DEX_CUSTOMER_DATA dcd                                                                                                        
						,DEX_ORDERS ord                                                                                                               
						,DEX_LINES lne                                                                                                                
						,DEX_SERIALS ser                                                                                                              
				where  ser.SERIAL_ID = mySerialID                                                                                               
				and    ser.ORDERNO   = lne.ORDERNO                                                                                              
				and    ser.ITEM      = lne.ITEM                                                                                                 
				and    lne.ORDERNO   = ord.ORDERNO                                                                                              
				and    ord.ORG_ID		= dcd.ORG_ID                                                                                                 
				and    ord.CUSTOMER_ID = dcd.CUSTOMER_ID                                                                                        
				and    ser.LOCATION != 'SHP'                                                                                                    
				and    ser.LOCATION = loc.LOCATION                                                                                              
				and    ser.FAILURE_ID = df.FAILURE_ID (+);                                                                                      
                                                                                                                                    
				mySect := 'Quality - Svc Categ';                                                                                                
				myPartExchFlag := 'N';                                                                                                          
				mySvcCatgID := XXDEX_SERVICE_CATEGORY_ID_F(myItemID, myROrgID);                                                                 
                                                                                                                                    
				if myNItemID != myItemID then                                                                                                   
					myPartExchFlag := 'Y';                                                                                                         
					mySvcCatgID := XXDEX_SERVICE_CATEGORY_ID_F(myNItemID, myROrgID);                                                               
				end if;                                                                                                                         
                                                                                                                                    
				if myStep > 8 then                                                                                                              
					myRetMesg := 'Serial: ' || mySerial || ' has already processed thr                                                             
u quality inspection';                                                                                                              
					raise QUALITY_ERROR;                                                                                                           
                                                                                                                                    
				elsif myOSerial != mySerial then                                                                                                
					begin                                                                                                                          
						mySect := 'Quality - Exch Check Serial';                                                                                      
						select ORDERNO                                                                                                                
						into   myExchOrder                                                                                                            
						from   DEX_SERIALS                                                                                                            
						where  SERIAL = mySerial                                                                                                      
						and    LOCATION != 'SHP'                                                                                                      
						and    rownum < 2;                                                                                                            
                                                                                                                                    
						myRetMesg := 'Exchange Serial: ' || mySerial || ' alre                                                                        
ady exists on open Order: ' || myExchOrder;                                                                                         
						raise QUALITY_ERROR;                                                                                                          
                                                                                                                                    
					exception                                                                                                                      
						when NO_DATA_FOUND then                                                                                                       
							null;                                                                                                                        
					end;                                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				mySect := 'Quality - Set Tables';                                                                                               
				myRepSyms	:= myQualRcds(i).CUST_RPT_SYMP_TBL;                                                                                   
				myComps		:= myQualRcds(i).DEF_COMPS_TBL;                                                                                        
				myDatas		:= myQualRcds(i).VERI_DATA_TBL;                                                                                        
                                                                                                                                    
				myOrigRepActCd := myQualRcds(i).REPAIR_ACTION_CODE;                                                                             
				myRepActID := GET_FAIL_ID(myOrigRepActCd,'R');                                                                                  
                                                                                                                                    
				-- dbms_output.put_line('Serial: ' || mySerial ||                                                                               
' RepAct: ' || myOrigRepActCd || ' UnkRep: ' || myUn                                                                                
kRepActID || ' UnkSymp: ' || myUnkSympID);                                                                                          
                                                                                                                                    
				if myRepActID is null  then                                                                                                     
					myRetMesg := 'Serial: ' || mySerial || ' has inva                                                                              
lid Repair Action: ' || myOrigRepActCd;                                                                                             
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				myRptSymID := null;                                                                                                             
				myFailCdID := null;                                                                                                             
				myFirstRptSymID := null;                                                                                                        
				mySect := 'Quality - Find Reported Symptoms';                                                                                   
				-- dbms_output.put_line('Rep Sym Count: ' || myRep                                                                              
syms.COUNT);                                                                                                                        
				for x in 1 .. myRepsyms.COUNT loop                                                                                              
					myRptSymID :=  GET_FAIL_ID(myRepSyms(x),'C');                                                                                  
					 -- dbms_output.put_line('cust symp: ' || myRepS                                                                               
yms(x) || ' cust repid: ' || myRptSymID);                                                                                           
					if myRptSymID is null and myRepSyms(x) is not null then                                                                        
						myRetMesg := 'Serial: ' || mySerial || ' has in                                                                               
valid Customer Reported Symptom: ' || myRepSyms(x);                                                                                 
						exit;                                                                                                                         
					end if;                                                                                                                        
					if myFirstRptSymID is null then                                                                                                
						myFirstRptSymId := myRptSymID;                                                                                                
						-- use first customer reported as Symptom Code                                                                                
						myFailCdID := GET_FAIL_ID(myRepSyms(x),'S');                                                                                  
					end if;                                                                                                                        
				end loop;                                                                                                                       
				if myRetMesg is not null then                                                                                                   
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
                                                                                                                                    
				mySEct := 'Quality - Validate Comp Data';                                                                                       
			   for x in 1 .. myComps.COUNT loop                                                                                              
			   	if myComps(x).COMPONENT is null then                                                                                         
			   		myRetMesg := 'Serial: ' || mySerial || ' - Component                                                                        
Part Missing.';                                                                                                                     
			   		exit;                                                                                                                       
			   	end if;                                                                                                                      
			   	if myComps(x).REPAIR_ASSEMBLY is null then                                                                                   
			   		myRetMesg := 'Serial: ' || mySerial || ' - Assembly P                                                                       
art Missing.';                                                                                                                      
						exit;                                                                                                                         
			   	end if;                                                                                                                      
			   	myFaultCd  := VALIDATE_CODE('CISCO_FAULT_CODE' , myComp                                                                      
s(x).FAULT_CODE);                                                                                                                   
			   	if myFaultCd is null then                                                                                                    
			   		myRetMesg := 'Serial: ' || mySerial || ' - In                                                                               
valid Component Fault Code: ' || myComps(x).FAULT_CO                                                                                
DE || ' Component: ' || myComps(x).COMPONENT;                                                                                       
						exit;                                                                                                                         
					end if;                                                                                                                        
					myCauseCd  := VALIDATE_CODE('CISCO_CAUSE_CODE' , myCom                                                                         
ps(x).CAUSE_CODE);                                                                                                                  
					if myCauseCd is null then                                                                                                      
			   		myRetMesg := 'Serial: ' || mySerial || ' - Inv                                                                              
alid Component Cause Code: ' || myComps(x).CAUSE_COD                                                                                
E || ' Component: ' || myComps(x).COMPONENT;                                                                                        
						exit;                                                                                                                         
					end if;                                                                                                                        
					myRepairCd := VALIDATE_CODE('DEX_FAIL_CODES_RESOLUTION'                                                                        
 , myComps(x).REPAIR_ACTION);                                                                                                       
					if myRepairCd is null then                                                                                                     
						myRetMesg := 'Serial: ' || mySerial || ' - Invalid Component R                                                                
epair Actione Code: ' || myComps(x).REPAIR_ACTION ||                                                                                
 ' Component: ' || myComps(x).COMPONENT;                                                                                            
						exit;                                                                                                                         
					end if;                                                                                                                        
					myRepRuleID := REPAIR_RULE_ID (myFaultCd,myCauseCd,myRepair                                                                    
Cd);                                                                                                                                
					if myRepRuleID is null then                                                                                                    
						myRetMesg := 'Serial: ' || mySerial || ' Component: ' || myC                                                                  
omps(x).COMPONENT || ' - Repair Rule Not Found for P                                                                                
art: ' || myPart ||                                                                                                                 
								' Fault Cd: ' || myFaultCd || ' Cause Cd: ' || myC                                                                          
auseCd || ' Repair Cd: ' || myRepairCd;                                                                                             
						exit;                                                                                                                         
					end if;                                                                                                                        
				end loop;                                                                                                                       
				if myRetMesg is not null then                                                                                                   
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				if myOSerial != mySerial then                                                                                                   
					mySect := 'Quality - Updt Exch Serial';                                                                                        
					update DEX_SERIALS set                                                                                                         
					TRACK  = mySerial                                                                                                              
				  ,SERIAL = mySerial                                                                                                            
				  ,EXCHANGE_FLAG = 'Y'                                                                                                          
				   where  SERIAL_ID = mySerialID;                                                                                               
				end if;                                                                                                                         
				if myNItemID != myItemID then                                                                                                   
					mySect := 'Qualty - Move Diff Part';                                                                                           
					K_MOVE_ORDER.SERIAL(                                                                                                           
					                     myRetMesg   => myRetMesg                                                                                  
			                          ,myRetCode   => myRetCode                                                                              
			                          ,myOrder     => myOrder                                                                                
			                          ,myItem      => myItem                                                                                 
			                          ,mySerialID  => mySerialID                                                                             
			                          ,myNPrice    => myPrice                                                                                
			                          ,myNItemID   => myNItem                                                                                
ID                                                                                                                                  
			                          );                                                                                                     
					if myRetCode != 0 then                                                                                                         
						raise QUALITY_ERROR;                                                                                                          
					end if;                                                                                                                        
				end if;                                                                                                                         
                                                                                                                                    
				-- Set Fail Code Symptom to No Data if none provided.                                                                           
				myFailCdID := nvl(myFailCdID,GET_FAIL_ID('ND','S'));                                                                            
                                                                                                                                    
				mySect := 'Quality - Calc Price';                                                                                               
				if myWarranty = 'Valid' then                                                                                                    
		   	   myWarr := 'Y';                                                                                                             
      		else                                                                                                                        
         		myWarr := 'N';                                                                                                           
      		end if;                                                                                                                     
				myCPrice  := nvl(F_DEX_PRICE_CALC (                                                                                             
         	                                    myItemID                                                                              
         	                                   ,myCustID                                                                              
         	                                   ,myOrdType                                                                             
         	                                   ,myAdvRep                                                                              
         	                                   ,myBillType                                                                            
         	                                   ,myScrap                                                                               
         	                                   ,mySeri                                                                                
alID                                                                                                                                
         	                                   ,myWarr                                                                                
         	                                   ,myPrice                                                                               
         	                                  ),0);                                                                                   
                                                                                                                                    
                                                                                                                                    
 				select TRANSACTION_s.nextval                                                                                                   
      		into   myTranID                                                                                                             
      		from   DUAL;                                                                                                                
                                                                                                                                    
				mySect := 'Quality - Serials Intf';                                                                                             
		   	insert into DEX_SERIALS_INTERFACE                                                                                             
	   	  (TRAN_ID                                                                                                                     
	   	  ,LOCATION                                                                                                                    
	   	  ,DATELOC                                                                                                                     
	   	  ,SCRAP                                                                                                                       
	   	  ,SWAP                                                                                                                        
	   	  ,SERIAL                                                                                                                      
	   	  ,INSPECTOR                                                                                                                   
	   	  ,FAILURE                                                                                                                     
	   	  ,LABEL_DATA1                                                                                                                 
	   	  ,LABEL_DATA2                                                                                                                 
	   	  ,WARRANTY_ID                                                                                                                 
	   	  ,FAILURE_ID                                                                                                                  
	   	  ,QUALITY_ID                                                                                                                  
	   	  ,CODE                                                                                                                        
	   	  ,SCRAP_CTL                                                                                                                   
	   	  ,MRB_REASON                                                                                                                  
	   	  ,QUALITY                                                                                                                     
	   	  ,SERIAL_ID                                                                                                                   
	   	  ,TRACK                                                                                                                       
	   	  ,CREATED_BY                                                                                                                  
	   	  ,CREATION_DATE                                                                                                               
	   	  ,ORDERNO                                                                                                                     
	   	  ,ITEM                                                                                                                        
	   	  ,MRB_FLAG                                                                                                                    
	   	  ,DATE_MRB                                                                                                                    
	   	  ,STATUS                                                                                                                      
	   	  ,UNIQUENO                                                                                                                    
	   	  ,AQL                                                                                                                         
	   	  ,REPORTED                                                                                                                    
	   	  ,WARRANTY                                                                                                                    
	   	  ,FAILANAL                                                                                                                    
	   	  ,REASON                                                                                                                      
	   	  ,REVISION                                                                                                                    
	   	  ,TAG_NUMBER                                                                                                                  
	   	  ,SORT                                                                                                                        
	   	  ) select                                                                                                                     
	   	   myTranID                                                                                                                    
	   	  ,'QCP'                                                                                                                       
	   	  ,SYSDATE                                                                                                                     
	   	  ,ser.SCRAP                                                                                                                   
	   	  ,ser.SWAP                                                                                                                    
	   	  ,ser.SERIAL                                                                                                                  
	   	  ,myEmpNo                                                                                                                     
	   	  ,ser.FAILURE                                                                                                                 
	   	  ,ser.LABEL_DATA1                                                                                                             
	   	  ,ser.LABEL_DATA2                                                                                                             
	   	  ,ser.WARRANTY_ID                                                                                                             
	   	  ,ser.FAILURE_ID                                                                                                              
	   	  ,ser.QUALITY_ID                                                                                                              
	   	  ,null                                                                                                                        
	   	  ,ser.SCRAP_CTL                                                                                                               
	   	  ,ser.MRB_REASON                                                                                                              
	   	  ,'QCP'                                                                                                                       
	   	  ,ser.SERIAL_ID                                                                                                               
	   	  ,ser.TRACK                                                                                                                   
	   	  ,myUserID                                                                                                                    
	   	  ,SYSDATE                                                                                                                     
	   	  ,ser.ORDERNO                                                                                                                 
	   	  ,ser.ITEM                                                                                                                    
	   	  ,ser.MRB_FLAG                                                                                                                
	   	  ,ser.DATE_MRB                                                                                                                
	   	  ,'A'         -- Accept                                                                                                       
	   	  ,ser.UNIQUENO                                                                                                                
	   	  ,'N'                                                                                                                         
	   	  ,ser.REPORTED                                                                                                                
	   	  ,ser.WARRANTY                                                                                                                
	   	  ,'Y'                                                                                                                         
	   	  ,''                                                                                                                          
	   	  ,ser.REVISION                                                                                                                
	   	  ,ser.TAG_NUMBER                                                                                                              
	   	  ,ser.SORT                                                                                                                    
	   	  from DEX_SERIALS ser                                                                                                         
	   	  where ser.SERIAL_ID = mySerialID;                                                                                            
                                                                                                                                    
                                                                                                                                    
				mySect := 'Quality - QCProd Intf';                                                                                              
	   	   insert into DEX_QCPROD_INTERFACE                                                                                            
	   	  (TRAN_ID                                                                                                                     
	   	  ,CREATED_BY                                                                                                                  
	   	  ,CREATION_DATE                                                                                                               
	   	  ,LOGIN_ID                                                                                                                    
	   	  ,SERIAL_ID                                                                                                                   
	   	  ,PRICE_COUNTERS                                                                                                              
	   	  ,GRP_REPAIR                                                                                                                  
	   	  ,REJECT_CODE_ID                                                                                                              
	   	  ) values (                                                                                                                   
	   	   myTranID                                                                                                                    
	   	  ,myUserID                                                                                                                    
	   	  ,myDate                                                                                                                      
	   	  ,myUserID                                                                                                                    
	   	  ,mySerialID                                                                                                                  
	   	  ,myCPrice                                                                                                                    
	   	  ,myRepGrp                                                                                                                    
	   	  ,null                                                                                                                        
	   	  );                                                                                                                           
                                                                                                                                    
			   delete DEX_FAILURE_INTERFACE WHERE FAILURE_ID = myFailID;                                                                     
        	   delete DEX_FAILURE_DETAIL_INTERFACE WHERE FAILU                                                                         
RE_ID = myFailID;                                                                                                                   
                                                                                                                                    
				mySect := 'Quality - Failur Intf';                                                                                              
      	   insert into DEX_FAILURE_INTERFACE                                                                                         
	   	   (TRAN_ID                                                                                                                    
	   	   ,FAILURE_ID                                                                                                                 
	   	   ,LAST_UPDATE_DATE                                                                                                           
	   	   ,LAST_UPDATED_BY                                                                                                            
	   	   ,CREATION_DATE                                                                                                              
	   	   ,CREATED_BY                                                                                                                 
	   	   ,SERIAL_NUMBER                                                                                                              
	   	   ,TRACK_NUMBER                                                                                                               
	   	   ,SERIAL_ID                                                                                                                  
	   	   ,CUST_FAIL_CODE_ID                                                                                                          
	   	   ,FAILURE_SYMPTOM_CODE_ID                                                                                                    
	   	   ,REPAIR_ACTION_CODE_ID                                                                                                      
	   	   ,DAMAGED                                                                                                                    
	   	   ,DOA                                                                                                                        
	   	   ,NTF                                                                                                                        
	   	   ,VERIFIED                                                                                                                   
	   	   ,EDI                                                                                                                        
	   	   ,COMMENTS                                                                                                                   
	   	   ,COSMETIC_CRITERIA                                                                                                          
	   	   ,REPORTED_FAILURE                                                                                                           
	   	   ,QAD_FLAG                                                                                                                   
	   	   ,BURNIN_REJECT_DATE                                                                                                         
	   	   ,ATTRIBUTE_CATEGORY                                                                                                         
	   	   ,ATTRIBUTE1                                                                                                                 
	   	   ,ATTRIBUTE2                                                                                                                 
	   	   ,ATTRIBUTE3                                                                                                                 
	   	   ,ATTRIBUTE4                                                                                                                 
	   	   ,ATTRIBUTE5                                                                                                                 
	   	   ,ATTRIBUTE6                                                                                                                 
	   	   ,ATTRIBUTE7                                                                                                                 
	   	   ,ATTRIBUTE8                                                                                                                 
	   	   ,ATTRIBUTE9                                                                                                                 
	   	   ,ATTRIBUTE10                                                                                                                
	   	   ,ATTRIBUTE11                                                                                                                
	   	   ,ATTRIBUTE12                                                                                                                
	   	   ,ATTRIBUTE13                                                                                                                
	   	   ,ATTRIBUTE14                                                                                                                
	   	   ,ATTRIBUTE15                                                                                                                
	   	   ,ATTRIBUTE16                                                                                                                
	   	   ,ATTRIBUTE17                                                                                                                
	   	   ,ATTRIBUTE18                                                                                                                
	   	   ,ATTRIBUTE19                                                                                                                
	   	   ,ATTRIBUTE20                                                                                                                
	   	   ,ATTRIBUTE21                                                                                                                
	   	   ,ATTRIBUTE22                                                                                                                
	   	   ,ATTRIBUTE23                                                                                                                
	   	   ,ATTRIBUTE24                                                                                                                
	   	   ,ATTRIBUTE25                                                                                                                
	   	   ,ATTRIBUTE26                                                                                                                
	   	   ,ATTRIBUTE27                                                                                                                
	   	   ,ATTRIBUTE28                                                                                                                
	   	   ,ATTRIBUTE29                                                                                                                
	   	   ,ATTRIBUTE30                                                                                                                
	   	   ,ATTRIBUTE31                                                                                                                
	   	   ,ATTRIBUTE32                                                                                                                
	   	   ,ATTRIBUTE33                                                                                                                
	   	   ,ATTRIBUTE34                                                                                                                
	   	   ,ATTRIBUTE35                                                                                                                
	   	   ,RECORD_STATUS)                                                                                                             
	   	    select                                                                                                                     
	   	    myTranID                                                                                                                   
	   	   ,myFailID                                                                                                                   
	   	   ,SYSDATE                                                                                                                    
	   	   ,myUserID                                                                                                                   
	   	   ,SYSDATE                                                                                                                    
	   	   ,myUserID                                                                                                                   
	   	   ,ser.SERIAL                                                                                                                 
	   	   ,ser.TRACK                                                                                                                  
	   	   ,ser.SERIAL_ID                                                                                                              
	   	   ,myFirstRptSymID                                                                                                            
	   	   ,myFailCdID                                                                                                                 
	   	   ,myRepActID                                                                                                                 
	   	   ,nvl(df.DAMAGED,'N')                                                                                                        
	   	   ,nvl(df.DOA,'N')                                                                                                            
	   	   ,nvl(df.NTF,'N')                                                                                                            
	   	   ,nvl(df.VERIFIED,'N')                                                                                                       
	   	   ,nvl(df.EDI,'N')                                                                                                            
	   	   ,df.COMMENTS                                                                                                                
	   	   ,df.COSMETIC_CRITERIA                                                                                                       
	   	   ,df.REPORTED_FAILURE                                                                                                        
	   	   ,df.QAD_FLAG                                                                                                                
	   	   ,df.BURNIN_REJECT_DATE                                                                                                      
	   	   ,df.ATTRIBUTE_CATEGORY                                                                                                      
	   	   ,df.ATTRIBUTE1                                                                                                              
	   	   ,df.ATTRIBUTE2                                                                                                              
	   	   ,df.ATTRIBUTE3                                                                                                              
	   	   ,df.ATTRIBUTE4                                                                                                              
	   	   ,df.ATTRIBUTE5                                                                                                              
	   	   ,df.ATTRIBUTE6                                                                                                              
	   	   ,df.ATTRIBUTE7                                                                                                              
	   	   ,df.ATTRIBUTE8                                                                                                              
	   	   ,df.ATTRIBUTE9                                                                                                              
	   	   ,df.ATTRIBUTE10                                                                                                             
	   	   ,df.ATTRIBUTE11                                                                                                             
	   	   ,df.ATTRIBUTE12                                                                                                             
	   	   ,df.ATTRIBUTE13                                                                                                             
	   	   ,df.ATTRIBUTE14                                                                                                             
	   	   ,df.ATTRIBUTE15                                                                                                             
	   	   ,df.ATTRIBUTE16                                                                                                             
	   	   ,df.ATTRIBUTE17                                                                                                             
	   	   ,df.ATTRIBUTE18                                                                                                             
	   	   ,df.ATTRIBUTE19                                                                                                             
	   	   ,df.ATTRIBUTE20                                                                                                             
	   	   ,df.ATTRIBUTE21                                                                                                             
	   	   ,df.ATTRIBUTE22                                                                                                             
	   	   ,df.ATTRIBUTE23                                                                                                             
	   	   ,df.ATTRIBUTE24                                                                                                             
	   	   ,df.ATTRIBUTE25                                                                                                             
	   	   ,df.ATTRIBUTE26                                                                                                             
	   	   ,df.ATTRIBUTE27                                                                                                             
	   	   ,df.ATTRIBUTE28                                                                                                             
	   	   ,df.ATTRIBUTE29                                                                                                             
	   	   ,df.ATTRIBUTE30                                                                                                             
	   	   ,df.ATTRIBUTE31                                                                                                             
	   	   ,df.ATTRIBUTE32                                                                                                             
	   	   ,df.ATTRIBUTE33                                                                                                             
	   	   ,df.ATTRIBUTE34                                                                                                             
	   	   ,df.ATTRIBUTE35                                                                                                             
	   	   ,'CHANGED'                                                                                                                  
	   	    from DEX_FAILURE df                                                                                                        
	   	    	  ,DEX_SERIALS ser                                                                                                        
	   	    where ser.SERIAL_ID = mySerialID                                                                                           
	   	    and   ser.FAILURE_ID = df.FAILURE_ID (+);                                                                                  
                                                                                                                                    
				select max(FAILURE_DETAIL_ID)                                                                                                   
				into   myFailDtlID                                                                                                              
				from   DEX_FAILURE_DETAIL                                                                                                       
				where  FAILURE_ID = myFailID                                                                                                    
				and    PROCESS_CODE_ID = myRProcID;			-- Repair Process Step.                                                                   
                                                                                                                                    
				if myFailDtlId is null then                                                                                                     
                                                                                                                                    
					select DEX_FAILURE_DETAIL_S.nextval                                                                                            
					into   myFailDtlID                                                                                                             
					from   dual;                                                                                                                   
                                                                                                                                    
					select nvl(max(STEP),0)                                                                                                        
      			into   myStep                                                                                                              
      			from   DEX_FAILURE_DETAIL                                                                                                  
      			where  FAILURE_ID = myFailID;                                                                                              
                                                                                                                                    
					mySect := 'Quality - Failure Dtl Intf';                                                                                        
                                                                                                                                    
				   insert into DEX_FAILURE_DETAIL_INTERFACE                                                                                     
      	     (TRAN_ID                                                                                                                
      	     ,FAILURE_DETAIL_ID                                                                                                      
      	     ,FAILURE_ID                                                                                                             
      	     ,FAIL_CODE_ID                                                                                                           
      	     ,ACTION_CODE_ID                                                                                                         
      	     ,STEP                                                                                                                   
      	     ,LAST_UPDATE_DATE                                                                                                       
      	     ,LAST_UPDATED_BY                                                                                                        
      	     ,CREATION_DATE                                                                                                          
      	     ,CREATED_BY                                                                                                             
      	     ,PROCESS                                                                                                                
      	     ,PROCESS_CODE_ID                                                                                                        
      	     ,PASS                                                                                                                   
      	     ,EMPLOYEE_ID                                                                                                            
      	     ,RECORD_STATUS                                                                                                          
      	     ,LAST_UPDATE_LOGIN                                                                                                      
      	     ) values (                                                                                                              
      	      myTranID                                                                                                               
      	     ,myFailDtlID                                                                                                            
      	     ,myFailID                                                                                                               
      	     ,myFailCdID                                                                                                             
      	     ,myRepActId                                                                                                             
      	     ,myStep                                                                                                                 
      	     ,myRepDate                                                                                                              
      	     ,myUserID                                                                                                               
      	     ,myRepDate                                                                                                              
      	     ,myUserID                                                                                                               
      	     ,myRProcCode                                                                                                            
      	     ,myRProcID                                                                                                              
      	     ,'Y'                                                                                                                    
      	     ,myEmpID                                                                                                                
      	     ,'INSERT'                                                                                                               
      	     ,0                                                                                                                      
      	     );                                                                                                                      
  				else                                                                                                                          
				   insert into DEX_FAILURE_DETAIL_INTERFACE                                                                                     
      	     (TRAN_ID                                                                                                                
      	     ,FAILURE_ID                                                                                                             
      	     ,FAILURE_DETAIL_ID                                                                                                      
      	     ,LAST_UPDATED_BY                                                                                                        
      	     ,LAST_UPDATE_DATE                                                                                                       
      	     ,CREATION_DATE                                                                                                          
      	     ,CREATED_BY                                                                                                             
      	     ,PROCESS                                                                                                                
        		  ,PROCESS_CODE_ID                                                                                                        
        		  ,PASS                                                                                                                   
        		  ,STEP                                                                                                                   
        		  ,EMPLOYEE_ID                                                                                                            
        		  ,COMMENTS                                                                                                               
        		  ,FAIL_CODE_ID                                                                                                           
        		  ,ACTION_CODE_ID                                                                                                         
        		  ,ATTRIBUTE_CATEGORY                                                                                                     
        		  ,ATTRIBUTE1                                                                                                             
        		  ,ATTRIBUTE2                                                                                                             
        		  ,ATTRIBUTE3                                                                                                             
        		  ,ATTRIBUTE4                                                                                                             
        		  ,ATTRIBUTE5                                                                                                             
        		  ,ATTRIBUTE6                                                                                                             
        		  ,ATTRIBUTE7                                                                                                             
        		  ,ATTRIBUTE8                                                                                                             
        		  ,ATTRIBUTE9                                                                                                             
        		  ,ATTRIBUTE10                                                                                                            
        		  ,ATTRIBUTE11                                                                                                            
        		  ,ATTRIBUTE12                                                                                                            
        		  ,ATTRIBUTE13                                                                                                            
        		  ,ATTRIBUTE14                                                                                                            
        		  ,ATTRIBUTE15                                                                                                            
        		  ,ATTRIBUTE16                                                                                                            
        		  ,ATTRIBUTE17                                                                                                            
        		  ,ATTRIBUTE18                                                                                                            
        		  ,ATTRIBUTE19                                                                                                            
        		  ,ATTRIBUTE20                                                                                                            
        		  ,ATTRIBUTE21                                                                                                            
        		  ,ATTRIBUTE22                                                                                                            
        		  ,ATTRIBUTE23                                                                                                            
        		  ,ATTRIBUTE24                                                                                                            
        		  ,ATTRIBUTE25                                                                                                            
        		  ,LAST_UPDATE_LOGIN                                                                                                      
        		  ,RECORD_STATUS                                                                                                          
      	     ) select                                                                                                                
      	      myTranID                                                                                                               
      	     ,myFailID                                                                                                               
      	     ,myFailDtlID                                                                                                            
      	     ,myUserID                                                                                                               
      	     ,myRepDate                                                                                                              
      	     ,myRepDate                                                                                                              
      	     ,myUserId                                                                                                               
      	     ,PROCESS                                                                                                                
        		  ,PROCESS_CODE_ID                                                                                                        
        		  ,PASS                                                                                                                   
        		  ,STEP                                                                                                                   
        		  ,myEmpID                                                                                                                
        		  ,COMMENTS                                                                                                               
        		  ,myFailCdID                                                                                                             
      	     ,myRepActId                                                                                                             
        		  ,ATTRIBUTE_CATEGORY                                                                                                     
        		  ,ATTRIBUTE1                                                                                                             
        		  ,ATTRIBUTE2                                                                                                             
        		  ,ATTRIBUTE3                                                                                                             
        		  ,ATTRIBUTE4                                                                                                             
        		  ,ATTRIBUTE5                                                                                                             
        		  ,ATTRIBUTE6                                                                                                             
        		  ,ATTRIBUTE7                                                                                                             
        		  ,ATTRIBUTE8                                                                                                             
        		  ,ATTRIBUTE9                                                                                                             
        		  ,ATTRIBUTE10                                                                                                            
        		  ,ATTRIBUTE11                                                                                                            
        		  ,ATTRIBUTE12                                                                                                            
        		  ,ATTRIBUTE13                                                                                                            
        		  ,ATTRIBUTE14                                                                                                            
        		  ,ATTRIBUTE15                                                                                                            
        		  ,ATTRIBUTE16                                                                                                            
        		  ,ATTRIBUTE17                                                                                                            
        		  ,ATTRIBUTE18                                                                                                            
        		  ,ATTRIBUTE19                                                                                                            
        		  ,ATTRIBUTE20                                                                                                            
        		  ,ATTRIBUTE21                                                                                                            
        		  ,ATTRIBUTE22                                                                                                            
        		  ,ATTRIBUTE23                                                                                                            
        		  ,ATTRIBUTE24                                                                                                            
        		  ,ATTRIBUTE25                                                                                                            
        		  ,myUserId                                                                                                               
        		  ,'CHANGE'                                                                                                               
        		   from DEX_FAILURE_DETAIL                                                                                                
        		   where  FAILURE_DETAIL_ID = myFailDtlID;                                                                                
        		end if;                                                                                                                   
                                                                                                                                    
			   K_DEX_QCPROD.INSPECT (                                                                                                        
        	           					   myRetMesg => myRetMesg                                                                                  
        	           					  ,myRetCode => myRetCode                                                                                  
        	           					  ,myTranID  => myTranID                                                                                   
        	           					  ,myAction  => 'Accept'                                                                                   
        	           					 );                                                                                                        
				if myRetCode != 0 then                                                                                                          
					raise QUALITY_ERROR;                                                                                                           
				end if;                                                                                                                         
                                                                                                                                    
				mySect := 'Quality - Failure Comp';                                                                                             
				delete DEX_FAILURE_COMP                                                                                                         
				where  FAILURE_DETAIL_ID = myFailDtlId;                                                                                         
                                                                                                                                    
				mySect := 'Quality - Comp Loop';                                                                                                
                                                                                                                                    
			   for x in 1 .. myComps.COUNT loop                                                                                              
                                                                                                                                    
			   	mySect := 'Quality - Comp Insert';                                                                                           
                                                                                                                                    
					myRepRuleID := REPAIR_RULE_ID (myComps(x).FAULT_CODE,myComps(x                                                                 
).CAUSE_CODE,myComps(x).REPAIR_ACTION);                                                                                             
					insert into DEX_FAILURE_COMP                                                                                                   
					(FAILURE_COMP_ID                                                                                                               
					,FAILURE_DETAIL_ID                                                                                                             
					,LAST_UPDATED_BY                                                                                                               
					,LAST_UPDATE_DATE                                                                                                              
					,CREATED_BY                                                                                                                    
					,CREATION_DATE                                                                                                                 
					,COMPONENT                                                                                                                     
					,ATTRIBUTE_CATEGORY                                                                                                            
					,ATTRIBUTE1                                                                                                                    
					,ATTRIBUTE2                                                                                                                    
					,ATTRIBUTE3                                                                                                                    
					,ATTRIBUTE4                                                                                                                    
					,ATTRIBUTE5                                                                                                                    
					,ATTRIBUTE6                                                                                                                    
					,ATTRIBUTE7                                                                                                                    
					) values (                                                                                                                     
					 DEX_FAILURE_COMP_S.nextval                                                                                                    
					,myFailDtlID                                                                                                                   
					,myUserId                                                                                                                      
					,myDate                                                                                                                        
					,myUserId                                                                                                                      
					,myDate                                                                                                                        
					,myComps(x).COMPONENT                                                                                                          
					,myParent                                                                                                                      
					,myComps(x).FAULT_CODE                                                                                                         
					,myComps(x).CAUSE_CODE                                                                                                         
					,myComps(x).REPAIR_ACTION                                                                                                      
					,myComps(x).REF_DES_PREFIX                                                                                                     
					,myComps(x).REF_DES_NUMBER                                                                                                     
					,myComps(x).REPAIR_ASSEMBLY                                                                                                    
					,myRepRuleID                                                                                                                   
					 );                                                                                                                            
				end loop;                                                                                                                       
                                                                                                                                    
				-- Compute Repair Action for Header Level                                                                                       
				mySect := 'Quality - Head Rep Act';                                                                                             
				myRepActCd := nvl(XXDEX_CISCO_FAIL_COMP_RESO_F(mySerialID),myOrigRe                                                             
pActCd);                                                                                                                            
				myRepActID := GET_FAIL_ID(myRepActCd,'R');                                                                                      
                                                                                                                                    
				mySect := 'Quality - Failure Data';                                                                                             
				select FAILURE_ID                                                                                                               
				into   myFailID                                                                                                                 
				from   DEX_SERIALS                                                                                                              
				where  SERIAL_ID = mySerialID;                                                                                                  
                                                                                                                                    
				mySect := 'Quality - Set Repair Action';                                                                                        
				update DEX_FAILURE set                                                                                                          
				REPAIR_ACTION_CODE_ID = myRepActID                                                                                              
			  ,ATTRIBUTE1 = myOrigRepActCd                                                                                                   
				where  FAILURE_ID = myFailID;                                                                                                   
                                                                                                                                    
            mySect := 'Quality - Set Action Code';                                                                                  
                                                                                                                                    
				update DEX_FAILURE_DETAIL set                                                                                                   
				ACTION_CODE_ID = myRepActID                                                                                                     
				where  FAILURE_DETAIL_ID = myFailDtlID;                                                                                         
                                                                                                                                    
				mySect := 'Quality - Other Cust Report Syptoms';                                                                                
				for x in 1 .. myRepsyms.COUNT loop                                                                                              
					myRptSymID :=  GET_FAIL_ID(myRepSyms(x),'C');                                                                                  
					if myRptSymID = myFirstRptSymID then                                                                                           
						null;		-- ignore because first valid Cust Rept S                                                                              
ymp stored on DEX_FAILURE                                                                                                           
					else                                                                                                                           
						insert into DEX_FAILURE_MORE (                                                                                                
					   FAILURE_MORE_ID                                                                                                             
					  ,LAST_UPDATE_DATE                                                                                                            
					  ,LAST_UPDATED_BY                                                                                                             
					  ,CREATION_DATE                                                                                                               
					  ,CREATED_BY                                                                                                                  
					  ,FAILURE_ID                                                                                                                  
					  ,REPORTED_ID                                                                                                                 
					  ,REPORTED_NOTE                                                                                                               
					   ) values (                                                                                                                  
					   DEX_FAILURE_MORE_S.nextval                                                                                                  
					  ,myDate                                                                                                                      
					  ,myUserID                                                                                                                    
					  ,myDate                                                                                                                      
					  ,myUserId                                                                                                                    
					  ,myFailId                                                                                                                    
					  ,myRptSymId                                                                                                                  
					  ,myRepSyms(x)                                                                                                                
					  );                                                                                                                           
					end if;                                                                                                                        
				end loop;                                                                                                                       
                                                                                                                                    
				mySect := 'Quality - Data loop';                                                                                                
                                                                                                                                    
				for x in 1 .. myDatas                                                                                                           
                                                                                                                                    

