select al.name from gv$log_history lh, gv$archived_log al 
                           where lh.recid >= 
                           (select min(recid)-4 from gv$log_history where first_change# <= 
                           (select min(change#) from gv$recover_file) 
                           and next_change# >= 
                           (select min(change#) from gv$recover_file)) 
                           and lh.first_change# = al.first_change# 
                           and lh.thread# = al.thread# 
                           and al.standby_dest = 'NO';
