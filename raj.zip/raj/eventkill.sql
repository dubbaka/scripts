set pages 1000
set lines 150
select 'kill -9 '|| p.spid
from
v$session s,v$process p, v$session_wait e
where s.paddr=p.addr
--and t.address=s.sql_address
and type!='BACKGROUND'
and e.sid=s.sid
and e.event like '%&name%'
and s.sid!=7
/
