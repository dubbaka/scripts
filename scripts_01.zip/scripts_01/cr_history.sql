set lines 230 feed off echo off pages 100 COLSEP '|';
col Time(min) format a13
col user_concurrent_program_name format a55
col user_concurrent_program_name heading 'Concurrent Program'
col argument_text for a65
col user_name format a15 heading 'User'
col start_date format a15 heading 'Start Time'
col request_id heading 'RequestID'
col Status heading 'Status'
col Phase heading 'Phase'
col description format a20 heading 'User Name'
col argument_text for a65
column Mins form 999999 heading 'Time(min)'
select * from
(select distinct request_id,
        user_concurrent_program_name,
        decode (phase_code,'R', 'RUNNING',
                           'P', 'PENDING',
                           'I', 'INACTIVE',
                           'C', 'Completed',
                            phase_code) Phase,
        decode (status_code,'A', 'WAITING',
                            'B', 'RESUMING',
                            'C', 'Normal',
                            'D', 'CANCELLED',
                            'E', 'ERROR',
                            'F', 'SCHEDULED',
                            'G', 'WARNING',
                            'H', 'ON HOLD',
                            'I', 'Normal',
                            'M', 'NO MANAGER',
                            'Q', 'STANDBY',
                            'S', 'SUSPENDED',
                            'T', 'TERMINATE',
                            'X', 'TERMINATED',
                            'Z', 'WAITING',
                            'R', 'NORMAL',
                            'U', 'DISABLED',
                            'W', 'PAUSED',
                            status_code) Status,
        to_char(actual_start_date,'DD-MON-YYYY HH24:MI') "Start_Time",
        to_char(actual_completion_date,'DD-MON-YYYY HH24:MI') "Completion Time",
        decode(actual_completion_date, null, 'Not Completed', round((actual_completion_date-actual_start_date)*24*60,0) ) "Time(min)",cr.argument_text, ROW_NUMBER() OVER (ORDER BY actual_start_date) rno
from    apps.fnd_concurrent_requests cr, apps.fnd_concurrent_programs_tl cp
where   cr.concurrent_program_id = cp.concurrent_program_id
and cr.phase_code='C' and cp.language='US'
and     cp.user_concurrent_program_name = '&program_name'
--and     ( cr.argument_text like 'arg_text%' or cr.argument_text is null )
order by to_number(request_id) desc )
where rownum < 11;
