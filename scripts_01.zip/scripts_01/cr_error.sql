rem =========================================================================+    
rem Program:           	crerror.sql
rem Author:             Justin Morton                                             
rem Creation Date:      02/12/2004                                                
rem Description:      	This script checks the completion status of concurrent
rem			requests that have completed in "Error" or "Warning" in
rem			the past 1 hour.  As such, this script will be executed 
rem			once an hour by the crstatus.sh shell script.                                       
rem Interfaces:         N/A  
rem Parameters:		N/A
rem Output:		crstatus.lst
rem History:
rem
rem Case/                                                                   
rem Tracking #  Date            Author          Description               
rem ========== 	==========	======		===========
rem N/A        	02/19/2001      Justin Morton   Creation of Script                    
rem         
rem =========================================================================+           
rem Dresser Inc.  All Rights Reserved.  Contains confidential and 
rem proprietary information of Vartec and may not be disclosed to any third party. 
rem =========================================================================+  
set linesize 132
set pagesize 46
column CURRENT_TIME new_value today
column DATABASE new_value dbname
select to_char(sysdate,'MM/DD/RR HH24:MI:SS AM') CURRENT_TIME,
       name DATABASE
from   v$database
/
ttitle left today center 'CR Error Report' right dbname skip 2
--btitle 'Vartec Proactive Monitoring'
column REQUEST justify left heading 'Request' format 99999999
column PHASE heading 'Phase' format A10
column STATUS heading 'Status' format A10
column PROGRAM heading 'Program Name' format A35
column REQUESTOR heading 'Requestor' format A9
column COMPLETED heading 'Completed' format A23
--spool crerror.lst
select 	substr(request_id,1,8) REQUEST, 
	decode(phase_code,'C','Completed')PHASE,
	decode(status_code,'G','Warning','E','Error','X','Terminated')STATUS,
	substr(program,1,35)PROGRAM,
	substr(requestor,1,9)REQUESTOR,
	to_char(actual_completion_date,'DD-MON-RRRR HH24:MI:SS AM')COMPLETED
from 	apps.fnd_conc_req_summary_v
where 	phase_code = 'C'
and 	status_code in ('E')
--and 	actual_completion_date >= sysdate - .042
and 	actual_completion_date >= sysdate - &&time_in_hours/24 
--and 	actual_completion_date >= sysdate - 5 
order by COMPLETED, PROGRAM, REQUESTOR asc
/
--spool off
ttitle off
--btitle off
clear columns
