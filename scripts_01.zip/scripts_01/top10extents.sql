col owner format a10 trunc
col segment_name format a30 trunc
set lines 132
select * from (
select owner,segment_name,segment_type,extents,next_extent,pct_increase
from dba_segments
where extents > 10
and owner != 'SYS'
order by 4 desc,1,2)
where rownum < 21
/
