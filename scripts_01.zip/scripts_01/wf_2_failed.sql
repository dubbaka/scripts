set lines 180 pages 200
col from_user for a25
col to_user for a70
col mail_status for a15
col status for a10
Select NOTIFICATION_ID, MESSAGE_TYPE, MESSAGE_NAME, STATUS, MAIL_STATUS, FROM_USER, TO_USER from applsys.wf_notifications where MAIL_STATUS='FAILED';
