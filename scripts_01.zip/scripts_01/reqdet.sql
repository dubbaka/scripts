set echo off
set linesize 150
set serveroutput on size 1000000
set heading off
set feed off
set veri off
undefine reqid
/* Script Prepared by Vikram Hebbar on 08-10-2002 */
accept reqid prompt 'Request ID: '
DECLARE
TYPE reqdet_rec IS RECORD( request_date DATE,
                            requested_start_date DATE,
                            actual_start_date DATE,
                            actual_completion_date DATE,
                            noa NUMBER(3),
                            paid NUMBER(15),
                            prid NUMBER(15),
                            phase_code VARCHAR2(1),
                            phase VARCHAR2(10),
                            status_code VARCHAR2(1),
                            status VARCHAR2(10),
                            priority NUMBER(15),
                            cmgr NUMBER(15),
                            log VARCHAR2(255),
                            outf VARCHAR2(255),
                            spid NUMBER(30),
                            pid VARCHAR2(240),
                            uname VARCHAR2(100),
                            description VARCHAR2(240),
                            rname VARCHAR2(100),
                            pname VARCHAR2(30),
                            uprname VARCHAR2(240),
                            qaid NUMBER(15),
                            qid NUMBER(15),
                            argument_text VARCHAR2(240),
                            hold_flag VARCHAR2(30));
  reqdet reqdet_rec;
  TYPE q_rec IS RECORD(qname VARCHAR2(30),
                       quname VARCHAR2(240));
  que q_rec;
  l_argq_str VARCHAR2(100);
  l_argo_l VARCHAR2(240);
  CURSOR cparam IS
    SELECT form_left_prompt
    FROM   apps.fnd_descr_flex_col_usage_vl
    WHERE  application_id = reqdet.paid AND
           descriptive_flexfield_name = '$SRS$.' || reqdet.pname
    ORDER  BY column_seq_num ASC;
  noa NUMBER(15);
  l_parm_cnt_o NUMBER(4);
  arg_len NUMBER;
  com_occur NUMBER;
  com_prev NUMBER := 0;
  p_start NUMBER;
  p_length NUMBER;
  l_parm_cnt_q VARCHAR2(240);
  dummy NUMBER;
  label_flag VARCHAR2(1) := 'N';

BEGIN
    --
  SELECT req.request_date,
         req.requested_start_date,
         req.actual_start_date,
         req.actual_completion_date,
         req.number_of_arguments,
         req.program_application_id,
         req.concurrent_program_id,
         req.phase_code,
         decode(req.phase_code,
                'P',
                'Pending',
                'R',
                'Running',
                'C',
                'Completed',
                req.phase_code),
         req.status_code,
         decode(req.status_code,
                'Q',
                'Standby',
                'I',
                'Normal',
                'H',
                'On Hold',
                'C',
                'Normal',
                'M',
                'No Manager',
                'R',
                'Normal',
                'P',
                'Scheduled',
                'S',
                'Suspended',
                'T',
                'Terminating',
                'U',
                'Disabled',
                'W',
                'Paused',
                'X',
                'Terminated',
                'Z',
                'Waiting',
                'B',
                'Resuming',
                'E',
                'Error',
                'D',
                'Cancelled',
                'E',
                'Error',
                req.status_code),
         req.priority,
         req.controlling_manager,
         req.logfile_name,
         req.outfile_name,
         req.oracle_process_id,
         req.os_process_id,
         u.user_name,
         u.description,
         r.responsibility_name,
         p.concurrent_program_name,
         ptl.user_concurrent_program_name,
         req.queue_app_id,
         req.queue_id,
         req.argument_text,
         decode(req.hold_flag,
                'Y',
                '[INACTIVE - ON HOLD]',
                '')
  INTO   reqdet
  FROM   applsys.fnd_concurrent_requests    req,
         applsys.fnd_user                   u,
         applsys.fnd_concurrent_programs    p,
         applsys.fnd_concurrent_programs_tl ptl,
         applsys.fnd_responsibility_tl      r
  WHERE  req.request_id = &reqid AND req.requested_by = u.user_id AND
         req.program_application_id = p.application_id AND
         req.concurrent_program_id = p.concurrent_program_id AND
         p.application_id = ptl.application_id AND
         p.concurrent_program_id = ptl.concurrent_program_id AND
         req.responsibility_application_id = r.application_id AND
         req.responsibility_id = r.responsibility_id AND
         ROWNUM = 1;
END;
/
