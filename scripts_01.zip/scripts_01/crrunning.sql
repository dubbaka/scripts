rem =========================================================================+    
rem Program:           	crrunning.sql
rem Author:             Justin Morton                                             
rem Creation Date:      02/19/2001                                                
rem Description:      	This script reports information on running concurrent
rem			requests. 
rem Interfaces:         N/A  
rem Parameters:		N/A
rem Output:		crrunning.lst
rem History:
rem
rem Case/                                                                   
rem Tracking #  Date            Author          Description               
rem ========== 	==========	======		===========
rem N/A        	02/19/2001      Justin Morton   Creation of Script                    
rem 		12/11/2001	Justin Morton	added join to fnd_concurrent_requests.
rem						added oracle_process_id        
rem						increased status column size
rem		01/22/2002	Justin Morton	restricted conc progs 40112 + 40113 
rem						from where clause
rem =========================================================================+           
rem Dresser Inc.  All Rights Reserved.  Contains confidential and 
rem proprietary information of VarTec and may not be disclosed to any third party. 
rem =========================================================================+  
set linesize 132 
set pagesize 56
column CURRENT_TIME new_value today
column DATABASE new_value dbname
select to_char(sysdate,'MM/DD/RR HH24:MI:SS AM') CURRENT_TIME,
       name DATABASE
from   v$database
/
ttitle left today center 'Running Concurrent Requests Report' right dbname skip 2
-- btitle 'Vartec Proactive Monitoring'
column REQUEST justify left heading 'Request' format a10
column PHASE heading 'Phase' format A8
column STATUS heading 'Status' format A8
column PROGRAM heading 'Program Name' format A25
column REQUESTOR heading 'Requestor' format A9
column START_TIME heading 'Start Time' format A15
column RUN_TIME justify left heading 'Runtime(m)' format 9,9999.99
column OSPID heading 'OSPID' format a5
column SID heading 'DBSID' format 99999
spool crrunning.lst
select 	substr(fcrv.request_id,1,10)REQUEST,
	decode(fcrv.phase_code,'P','Pending','R','Running','I','Inactive','Completed')PHASE,
	decode(fcrv.status_code,
	'A','Waiting',
	'B','Resuming',
	'C','Normal',
	'F','Scheduled',
	'G','Warning',
	'H','On Hold',
	'I','Normal',
	'M','No Manager',
	'Q','Standby',
	'R','Normal',
	'S','Suspended',
	'T','Terminating',
	'U','Disabled',
	'W','Paused',
	'X','Terminated',
	'Z','Waiting',fcrv.status_code)STATUS,
	substr(fcrv.program,1,25)PROGRAM,
        substr(fcrv.requestor,1,9)REQUESTOR,
        to_char(fcrv.actual_start_date,'MM/DD/RR HH24:MI')START_TIME,
	round(((sysdate - fcrv.actual_start_date)*1440),2)RUN_TIME,
 	substr(fcr.oracle_process_id,1,7)OSPID,
        vs.sid SID
        --substr(fcr.os_process_id,1,7)OS_PID
from 	apps.fnd_conc_req_summary_v fcrv,
	apps.fnd_concurrent_requests fcr,
        v$session vs,
        v$process vp
where 	fcrv.phase_code = 'R'
and	fcrv.request_id = fcr.request_id
and     fcr.oracle_process_id= vp.spid
and     vs.paddr = vp.addr
and	fcrv.concurrent_program_id not in ('40112','40113','36887')
order by PHASE, STATUS, REQUEST desc
/
