col machine format a10 
col LatestCall format 99,999
select * from (
select count(*),p.spid, s.machine, 
to_char(min(logon_time),'mm/dd hh24:mi'), to_char(max(logon_time),'mm/dd hh24:mi'),
min(floor(last_call_et/60)) "LatestCall"
from v$session s, v$process p
where p.addr = s.paddr
group by p.spid, s.machine
order by 1 desc)
where rownum < 11;
