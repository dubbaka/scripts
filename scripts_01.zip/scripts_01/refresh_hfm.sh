#!/bin/ksh
#
#  - stop app server
#  - drop db schemas
#  - import from schema dump
#  - reset db passwords
#  - reset apps 'sysadmin' password

send_mail()
{
  tail -50 /home/oracle/scripts/refresh_vertex.log |  mailx -s "$message" \
  -S smtp=smtp.uber.com \
  -S from="rdasari@uber.com" \
  $1
}

send_page()
{
  tail -50 /home/oracle/scripts/refresh_vertex.log |  mailx -s "$message" $1
}

echo ========`date`=======


. /usr/local/bin/dbenv vtxuat

echo $PATH

sqlplus $conn1 <<EOF
set echo on time on
prompt '...drop 5 schema vertex users....'
shut immediate;
startup restrict;
drop user VTX70_TPS cascade;
drop user VTX70_RPT cascade;
shut immediate;
startup;
EOF



echo "... Import Datapump Vertex schemas"
#impdp $conn remap_tablespace=temp01:temp directory=frcexport dumpfile=vertex_full_%U_$(date +%Y%m%d).dmp logfile=impdp_vertex_full_$(date +%w).log$1 cluster=N PARALLEL=4
impdp $conn  directory=frcexport dumpfile=vertex_full_%U_$(date +%Y%m%d).dmp logfile=impdp_vertex_full_$(date +%w).log$1 cluster=N PARALLEL=4
#impdp $conn  directory=frcexport dumpfile=vertex_full_%U_20180530.dmp logfile=impdp_vertex_full_$(date +%w).log$1 cluster=N PARALLEL=4


sqlplus $conn <<EOF
set echo on time on
prompt '...reset password for 5 schema vertex users....'
alter user VTX70_TPS identified by VTX70_TPS;
alter user VTX70_RPT identified by VTX70_RPT;
EOF

imp_succ_count=`grep 'successfully completed' /home/oracle/scripts/refresh_vertex.log | grep -v grep | wc -l`

if [ $imp_succ_count -eq 1 ]
then
  ssh $apphost date
  ssh_status=$?
  if [ $ssh_status -ne 0 ]
  then
    subject="VTX$1 Refresh failed!"
    message="VTX$1 Refresh on $host FAILED : ssh to $apphost failed on `date`"
    send_page "$paging_list"
  else
    JAVA_COUNT=`ssh $apphost 'ps -ef |grep java' | grep -v grep   | wc -l`
    export JAVA_COUNT
    if [ $JAVA_COUNT -lt 1 ]
    then
      subject="VTX$1 Refresh failed!"
      message="VTX$1 Refresh on $host FAILED : Services on VTX$1 failed to start on `date`"
      send_page "$paging_list"
    else
      subject="VTX$1 Refresh completed successfully!"
      message="VTX$1 Refresh on $host: SUCCESSFULLY completed on `date`"
      send_mail "$mailing_list"
    fi
  fi
else
  subject="VTX$1 Refresh failed!"
  message="VTX$1 Refresh on $host FAILED : Import of dump files failed on `date`"
  send_page "$paging_list"
fi

fi # MAIN if condition closing
