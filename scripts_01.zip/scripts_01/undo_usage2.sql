set pagesize 50
select tablespace_name, status, round(sum(blocks)*8192/1024/1024/1024,2) "Size in GB" 
from dba_undo_extents 
--where tablespace_name in ('APPS_UNDOTBS1', 'APPS_UNDOTBS2')
group by tablespace_name, status
order by tablespace_name, status
/
