select a.sql_text, b.sid 
from gv$sqlarea a , gv$session b
where 1=1
and a.hash_value = b.sql_hash_value
and a.address = b.sql_address
and upper(a.sql_text) like upper('%&sql_text%')
/
