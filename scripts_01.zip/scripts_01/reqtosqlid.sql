set linesize 120
select sid, pid, vp.spid, vs.process, sql_id, status
from v$session vs, v$process vp, applsys.fnd_concurrent_requests fcr
where vs.paddr=vp.addr
and vp.spid=fcr.oracle_process_id
and fcr.request_id=&reqid;
