set pages 40 lines 200 
alter session set nls_date_format='YYYY-DD-MM HH24:MI:SS'; 
 -- SELECT to_char(a.sample_time,'DD-MON-YYYY HH24') "Sample Time",a.event,a.sql_id,count(1)
 SELECT a.event,sql_id,count(1)
  FROM
  dba_hist_active_sess_history a
  WHERE
  a.sample_time > TO_DATE('2017-23-02 05:00:00') and a.sample_time < TO_DATE('2017-23-02 08:00:00')
--   and instance_number=1
 and a.event='block change tracking buffer space'
--  and a.event in ('log file sync','log buffer space')
  group by a.sql_id,a.event
  ORDER BY  3 desc;
