set linesize 180
col program format a45
col module format a60
col username format a15
select
   ses.sid,
   ses.username,
   program, 
   module,
   ses.status,
   round( tra.used_ublk * 8 / 1024 , 2) "Size MB"
from
   gv$session     ses,
   gv$transaction tra
where
--   ses.status = 'ACTIVE' and
   ses.saddr = tra.ses_addr
order by tra.used_ublk asc;
