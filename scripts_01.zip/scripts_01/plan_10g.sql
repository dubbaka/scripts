set lines 200
set pages 200
variable a varchar2(13);
begin
select sql_id into :a from v$session where sid='&sid';
end;
/
SELECT * FROM table(DBMS_XPLAN.DISPLAY_CURSOR((:a)));
