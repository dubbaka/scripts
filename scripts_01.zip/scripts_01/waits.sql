col event format a60
select event,count(*) from gv$session_wait 
where event not like '%timer'
and event not like 'SQL*Net%client'
and event not like 'rdbms ipc%'
and event not like 'queue message%'
and event not like 'Streams%'
--and wait_time = 0
group by event
order by 2 desc
/

