set echo off verify off trimspool on lines 197 pages 500 colsep ','
col "Request Id" for 999999999999
col "Concurrent Program Name" for a45 trunc
col requestor for a15
col Phase for a12
col Status for a12
col "Start Time" for a20
col "Completion Time" for a20
col "Application" for a20 trunc
spool currently_running.lst
select distinct
request_id "Request Id",PROGRAM "Concurrent Program Name",APPLICATION_NAME "Application",requestor,decode(PHASE_CODE,'C','Completed','I','Inactive','P ','Pending','R','Running','NA') "Phase",decode(STATUS_CODE, 'A','Waiting', 'B','Resuming', 'C','Normal', 'D','Cancelled', 'E','Error', 'F','Scheduled', 'G','Warning', 'H','On Hold', 'I','Normal', 'M', 'No Manager', 'Q','Standby', 'R','Normal', 'S','Suspended', 'T','Terminating', 'U','Disabled', 'W','Paused', 'X','Terminated', 'Z','Waiting') "Status",to_char(ACTUAL_START_DATE,'DD-MON-YYYY HH24:MI') " Start Time",round(((sysdate-actual_start_date)*24*60*60/60),2) "Total_Time"
from apps.FND_CONC_REQUESTS_FORM_V
where status_code='R' and phase_code='R' 
order by 8 desc;
