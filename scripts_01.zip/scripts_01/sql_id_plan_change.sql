set lines 200
set pages 60
set feedback off
set verify off
col execs for 999,999,999
col min_etime for 999,999.99
col max_etime for 999,999.99
col avg_etime for 999,999.999
col avg_lio for 999,999,999.9
col norm_stddev for 999,999.9999
col begin_interval_time for a30
col node for 9999999999
prompt
prompt
prompt
accept num_days prompt "How many days old sqls you want to check (default 1 day)  :"
break on plan_hash_value on startup_time skip 1
select * from (
select sample_end,sql_id, sum(execs), min(avg_etime) min_exectime, max(avg_etime) max_exectime, stddev_etime/min(avg_etime) norm_stddev
from (
select sample_end,sql_id, plan_hash_value, execs, avg_etime,stddev(avg_etime) over (partition by sql_id) stddev_etime
from (
select to_char(ss.begin_interval_time,'DD-MON-YYYY') sample_end,sql_id, plan_hash_value,sum(nvl(executions_delta,0)) execs,
(sum(elapsed_time_delta)/decode(sum(nvl(executions_delta,0)),0,1,sum(executions_delta))/1000000) avg_etime
 from DBA_HIST_SQLSTAT S, DBA_HIST_SNAPSHOT SS, (
    SELECT /*+ NO_MERGE */ MIN(snap_id) min_snap, MAX(snap_id) max_snap
    FROM dba_hist_snapshot sn
    WHERE sn.begin_interval_time BETWEEN (SYSDATE - nvl(to_number('&num_days'),1)) AND SYSDATE
    ) snp
where ss.snap_id = S.snap_id
and s.snap_id BETWEEN snp.min_snap AND snp.max_snap
and ss.instance_number = S.instance_number
and executions_delta > 0
group by to_char(ss.begin_interval_time,'DD-MON-YYYY'),sql_id, plan_hash_value
)
)
group by sample_end,sql_id, stddev_etime
)
where norm_stddev > nvl(to_number('&min_stddev'),2)
and max_exectime > nvl(to_number('&min_exectime'),1)
order by norm_stddev
/
prompt
prompt
prompt
accept space prompt "******************************Press Enter for Continue :*******************"
prompt "Plan change history for specific SQLID"
prompt
prompt
prompt
accept sql_id prompt "Enter SQL_ID     :"

set linesize 200
set pages 99
set verify off
set feedback off

column sample_end format a21

select s.snap_id,to_char(s.begin_interval_time,'DD-MON-YYYY DY HH24:MI') sample_end
, q.sql_id
, q.plan_hash_value
, q.EXECUTIONS_DELTA "executions"
, q.VERSION_COUNT "VersionCount"
, q.INVALIDATIONS_DELTA  "Invalidation"
, round(disk_reads_delta/executions_delta) "Phy IO/Exec"
, round(buffer_gets_delta/executions_delta) "LogIO/Exec"
, round(elapsed_time_delta*0.0000001/executions_delta,2) "Elapsed_Time_In_Sec/Exec"
, round(cpu_time_delta*0.0000001/executions_delta,2) "CPU_Time_In_Sec/Exec"
, round(rows_processed_delta/executions_delta) "Rows/Exec"
from dba_hist_sqlstat q, dba_hist_snapshot s
where q.SQL_ID=trim('&sql_id')
and s.snap_id = q.snap_id
and s.dbid = q.dbid
and s.instance_number = q.instance_number
and q.executions_delta > 0
and begin_interval_time BETWEEN (SYSDATE - nvl(to_number('&num_days'),1)) AND SYSDATE
order by q.sql_id,s.snap_id desc
/
prompt
prompt
prompt
prompt
accept space prompt "******************************Press Enter for Continue :*******************"
prompt
prompt
prompt "Object details for specific SQLID whose plan changed"
set linesize 200
set verify off
set feedback off
set pages 99

column object_owner format a15 wrap
column object_name format a50 wrap
column object_type format a20 wrap
select distinct q.sql_id,p.object_owner,p.object_name,p.object_type
from dba_hist_sqlstat q, dba_hist_snapshot s,dba_hist_sql_plan p
where s.snap_id = q.snap_id
and q.SQL_ID=trim('&sql_id')
and s.dbid = q.dbid
and s.dbid=p.dbid
and q.dbid=p.dbid
and s.instance_number = q.instance_number
and p.sql_id = q.sql_id
and p.object_type is not null
and s.begin_interval_time BETWEEN (SYSDATE - nvl(to_number('&num_days'),1)) AND SYSDATE
order by object_owner,object_name,object_type
/
prompt
prompt
prompt
accept space prompt "******************************Press Enter for Continue :*******************"
prompt
prompt
prompt "Explain plan detail for SQLID with plan change"
prompt

set linesize 150
set pages 99

prompt "********************************************************************************************"
prompt "SELECT * FROM table(dbms_xplan.display_awr(nvl('sql_id',null),nvl('plan_hash_value',null),null));"
prompt "plan_hash_value is optional and you should press <Enter> for null"
prompt "********************************************************************************************"

SELECT * FROM table(dbms_xplan.display_awr(nvl('&sql_id',null),nvl('&plan_hash_value',null),null));
