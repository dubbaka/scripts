set linesize 180
set pagesize 50
col machine format a40
select inst_id, sid, process, machine, status, round(last_call_et/60,2) from gv$session
where machine like '%&machine%'
order by 6 asc;

