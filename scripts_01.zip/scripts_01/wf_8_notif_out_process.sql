col corrid for a45
select NVL(substr(wfe.corrid,1,40),'NULL - No Value') corrid,
decode(wfe.state,
0,' 0 = Ready',
1,'1 = Delayed',
2,'2 = Retained',
3,'3 = Exception',
to_char(substr(wfe.state,1,12))) State,
count(*) COUNT
from applsys.wf_notification_out wfe
where NVL(substr(wfe.corrid,1,40),'NULL - No Value') like '%POAPPRV%'
group by wfe.corrid, wfe.state;
 
