set echo on
alter session set current_schema=apps;
select count(*) from wf_notifications
where status='OPEN'
and begin_date > sysdate-1
and mail_status='MAIL';
