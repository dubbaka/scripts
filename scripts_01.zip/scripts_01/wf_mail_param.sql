col parameter_name for a25
col parameter_value for a35
set lines 200
select p.parameter_id,
p.parameter_name,
v.parameter_value, c.component_id
from apps.fnd_svc_comp_param_vals_v v,
apps.fnd_svc_comp_params_b p,
apps.fnd_svc_components c
where c.component_type = 'WF_MAILER'
and v.component_id = c.component_id
and v.parameter_id = p.parameter_id
and p.parameter_name in ('ACCOUNT', 'REPLYTO', 'OUTBOUND_SERVER', 'INBOUND_SERVER') order by c.component_id, p.parameter_name;
