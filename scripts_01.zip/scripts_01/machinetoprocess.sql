set lines 2000;
set linesize 2000;
col p.program for a20;
col p.spid for a10;
col s.machine for a20;
col s.event for a30;
SELECT p.program, p.spid, s.sid, s.serial#,s.machine, s.event
FROM v$session s, v$process p
WHERE s.paddr = p.addr
and s.machine like '%adf%';
