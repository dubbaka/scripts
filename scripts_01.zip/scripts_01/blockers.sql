select inst_id, sid "Blocking Session", status, round(last_call_et/60,2) "Last Call (Min)"
from gv$session
where (sid, inst_id) in (
select blocking_session, blocking_instance
from gv$session
where blocking_session is not null);
