-- @topsql.sql


clear columns breaks computes

col dr head 'PIO blks' for 999,999,999
col bg head 'LIOs' for 999,999,999
col sr head 'Sorts' for 999,999
col exe head 'Runs' for 999,999,999
col rp head 'Rows' for 9,999,999,999
col rpr head 'LIOs|per Row' for 999,999,999
col rpe head 'LIOs|per Run' for 999,999,999

set lines 95 pau off pages 45

-- use HASH_VALUE for SQL_ID for pre 10g databases

select * from (
select SQL_ID, sum(BUFFER_GETS)/greatest(sum(ROWS_PROCESSED)) rpr, sum(ROWS_PROCESSED) rp, sum(DISK_READS) dr, sum(BUFFER_GETS) bg
, sum(EXECUTIONS) exe, sum(BUFFER_GETS)/greatest(sum(EXECUTIONS)) rpe
from v$sql
where command_type in (2,3,6,7)
and ROWS_PROCESSED != 0 and EXECUTIONS != 0
group by SQL_ID
order by rpr desc)
where rownum <= 41;
