select blocking_session, blocking_instance, sid "waiting_session", inst_id "waiting_instance"
from gv$session
where blocking_session is not null;
