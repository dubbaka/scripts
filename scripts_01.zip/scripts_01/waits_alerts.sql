col event format a45
select count(*),event from v$session_wait 
where wait_time = 0
and (event like 'library cache %'
or event in ('latch free','enqueue','buffer busy wait','write complete wait','log file sync')
or event like 'db file s%'
or event like 'direct path %' 
or event like 'SQL*Net%dblink')
group by event
/

