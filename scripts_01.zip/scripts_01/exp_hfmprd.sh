#!/bin/sh
#
# Export HFM database
#
#

set -u

readonly MAILING_LIST="rdasari@uber.com,kudikala@uber.com"
readonly HFM_SOURCE="/home/oracle/rdasari/scripts/hfm.env"
readonly HFM_EXP_DIR="HYP_EXP"
readonly HFM_EXP_FILE="hyp_hfm_full_%U_`date +"%Y%m%d"`.dmp"
readonly HFM_EXP_LOG="/u01/app/expbkp/exp_hfm_`date +"%Y%m%d"`.log"
readonly HFM_EXP_LOG2="/u01/app/expbkp/exp_hfm_exa.log"
readonly HFM_SCHEMA="HYP_HFM"

#### added dumpfile cleanup.#####
find /u01/app/expbkp -mtime +10 -exec rm {} \;
#####

echo "======= Exporting HFM Database ============" > $HFM_EXP_LOG
echo "=== Exporting $HFM_SCHEMA ===" >> $HFM_EXP_LOG

date >> $HFM_EXP_LOG
echo ""

. $HFM_SOURCE
##### Added parallelism and removed filesize.   Abe  11/14/2012 #####
#### expdp system/<pwd> schemas=$HFM_SCHEMA directory=$HFM_EXP_DIR dumpfile=$HFM_EXP_FILE job_name=expdp_vtxprd_exa FILESIZE=2G logfile=exp_hfm_exa.log compression=ALL  >> $HFM_EXP_LOG
expdp system/db0rlsystem8502 schemas=$HFM_SCHEMA directory=$HFM_EXP_DIR dumpfile=$HFM_EXP_FILE job_name=expdp_hfmprd logfile=exp_hfm_exa.log compression=ALL parallel=4 cluster=N >> $HFM_EXP_LOG
#expdp system/dbsys4me2u schemas=$HFM_SCHEMA directory=$HFM_EXP_DIR dumpfile=$HFM_EXP_FILE job_name=expdp_hfmprd logfile=exp_hfm_exa.log compression=ALL parallel=4 cluster=N version=11.2.0.3.0 >> $HFM_EXP_LOG
#expdp system/<pwd> schemas=$HFM_SCHEMA directory=$HFM_EXP_DIR dumpfile=$HFM_EXP_FILE job_name=expdp_vtxprd_exa logfile=exp_hfm_exa.log compression=ALL cluster=N >> $HFM_EXP_LOG

cat $HFM_EXP_LOG2 >> $HFM_EXP_LOG
echo "======= Export Complete ===================" >> $HFM_EXP_LOG

echo "======= Change permissions of dump file =======" >> $HFM_EXP_LOG
#chmod og+r /mnt/rman_isi_backuptemp/vtxprd/exp/vertex_full_0*_`date +"%Y%m%d"`.dmp >> $HFM_EXP_LOG
chmod og+r /u01/app/expbkp/hyp_hfm_full_0*_`date +"%Y%m%d"`.dmp >> $HFM_EXP_LOG

#echo "======= Remove old dump files from HYPERION DR server =======" >> $HFM_EXP_LOG
#echo "Start Time: `date`"
#ssh -t -t oracle@phx2p-dbadm01 'cd /u01/app/expbkp; rm -f /u01/app/expbkp/hyp_hfm_full_0*.dmp; exit' >> $HFM_EXP_LOG

echo "End Time: `date`"

echo "======= SCP dump files to DR server phx2p-dbadm01 =======" >> $HFM_EXP_LOG
echo "Start Time: `date`"
scp /u01/app/expbkp/hyp_hfm_full_0*_`date +"%Y%m%d"`.dmp oracle@phx2p-dbadm01:/u01/app/expbkp >> $HFM_EXP_LOG
echo "End Time: `date`"

subject="[INFO]:["`date "+%F %R"`"]:["`hostname -s`"]:[HFM][${0##*/}] Export log of schemas HYP_HFM "
mail -s "$subject" $MAILING_LIST < $HFM_EXP_LOG

