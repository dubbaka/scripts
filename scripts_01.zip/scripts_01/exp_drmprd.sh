#!/bin/bash --
#
# Export DRM database
#
#

set -u

readonly MAILING_LIST="rdasari@uber.com,kudikala@uber.com,sreedhar.marepally@uber.com"
readonly DRM_SOURCE="/home/oracle/rdasari/scripts/hfm.env"
readonly DRM_EXP_DIR="HYP_EXP"
readonly DRM_EXP_FILE="drm_db_full_%U_`date +"%Y%m%d"`.dmp"
readonly DRM_EXP_LOG="/u01/app/expbkp/exp_drm_`date +"%Y%m%d"`.log"
readonly DRM_EXP_LOG2="/u01/app/expbkp/exp_drm_exa.log"
readonly DRM_SCHEMA="DRM_DB"

#### added dumpfile cleanup.#####
find /u01/app/expbkp -mtime +10 -exec rm {} \;
#####

echo "======= Exporting DRM Database ============" > $DRM_EXP_LOG
echo "=== Exporting $DRM_SCHEMA ===" >> $DRM_EXP_LOG

date >> $DRM_EXP_LOG
echo ""

. $DRM_SOURCE
##### Added parallelism and removed filesize. #####
#### expdp system/<pwd> schemas=$DRM_SCHEMA directory=$DRM_EXP_DIR dumpfile=$DRM_EXP_FILE job_name=expdp_vtxprd_exa FILESIZE=2G logfile=exp_hfm_exa.log compression=ALL  >> $DRM_EXP_LOG
expdp system/db0rlsystem8502 schemas=$DRM_SCHEMA directory=$DRM_EXP_DIR dumpfile=$DRM_EXP_FILE job_name=expdp_drmprd logfile=exp_drm_exa.log compression=ALL parallel=4 cluster=N version=11.2.0.3.0 >> $DRM_EXP_LOG
#expdp system/<pwd> schemas=$DRM_SCHEMA directory=$DRM_EXP_DIR dumpfile=$DRM_EXP_FILE job_name=expdp_drmprd logfile=exp_drm_exa.log compression=ALL cluster=N >> $DRM_EXP_LOG

cat $DRM_EXP_LOG2 >> $DRM_EXP_LOG
echo "======= Export Complete ===================" >> $DRM_EXP_LOG

echo "======= Change permissions of dump file =======" >> $DRM_EXP_LOG
#chmod og+r /mnt/rman_isi_backuptemp/vtxprd/exp/vertex_full_0*_`date +"%Y%m%d"`.dmp >> $DRM_EXP_LOG
chmod og+r /u01/app/expbkp/drm_db_full_0*_`date +"%Y%m%d"`.dmp >> $DRM_EXP_LOG

#echo "======= Remove old dump files from HYPERION DR server =======" >> $DRM_EXP_LOG
#echo "Start Time: `date`"
#ssh -t -t oracle@phx2p-dbadm01 'cd /u01/app/expbkp; rm -f /u01/app/expbkp/drm_db_full_0*.dmp; exit' >> $DRM_EXP_LOG

echo "End Time: `date`"

echo "======= SCP dump files to DR server phx2p-dbadm01 =======" >> $DRM_EXP_LOG
echo "Start Time: `date`"
scp /u01/app/expbkp/drm_db_full_0*_`date +"%Y%m%d"`.dmp oracle@phx2p-dbadm01:/u01/app/expbkp >> $DRM_EXP_LOG
echo "End Time: `date`"

subject="[INFO]:["`date "+%F %R"`"]:["`hostname -s`"]:[DRM][${0##*/}] Export log of schemas HYP_DRM "
mail -s "$subject" $MAILING_LIST < $DRM_EXP_LOG

