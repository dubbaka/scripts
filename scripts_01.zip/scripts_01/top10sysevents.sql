set lines 132
col event format a25 trunc
col average_wait format 99999.99
select * from (
select event,total_waits,time_waited,average_wait
from v$system_event
where event not like '%ipc%'
and event not like '%timer%'
and event not like 'SQL*Net%'
and event not like 'pipe%'
and event not like 'wakeup%'
and event not like 'Null%'
and event not like 'PX%'
order by 3 desc)
where rownum < 11
/

