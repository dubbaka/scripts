select translate(decode(USER_CONCURRENT_QUEUE_NAME,'Standard Manager','Std Mgr',
'Output Post Processor','OPP',
'FB CreditCard','FB Credit',
'FB SCM Custom Manager','FB SCM Cust',
'Receiving Transaction Manager','RCV Txn Mgr',
'XXFB Salesforce Interface','FBSFDC',
'Conflict Resolution Manager','CRM'), ' ''', '_'), nvl(errored.err,0) val
FROM (select fcq.concurrent_queue_name,count(status_code) err
from
apps.fnd_concurrent_queues fcq,
apps.fnd_concurrent_processes fcp,
apps.fnd_conc_req_summary_v fcr
where fcp.concurrent_queue_id = fcq.concurrent_queue_id
and fcp.queue_application_id = fcq.application_id
and fcr.controlling_manager = fcp.concurrent_process_id
and fcr.status_code='E' and ACTUAL_COMPLETION_DATE > sysdate-3/24
group by concurrent_queue_name) errored,
apps.fnd_concurrent_queues_vl q
WHERE q.control_code is null
AND q.concurrent_queue_name = errored.concurrent_queue_name(+)
AND q.enabled_flag = 'Y'
and q.USER_CONCURRENT_QUEUE_NAME in ('Output Post Processor','Standard Manager','FB CreditCard','FB SCM Custom Manager','Receiving Transaction Manager','XXFB Salesforce Interface','Conflict Resolution Manager');
