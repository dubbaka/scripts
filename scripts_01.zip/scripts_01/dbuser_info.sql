set linesize 180
col username format a30
col external_name format a60
select username, authentication_type, external_name, account_status 
from dba_users 
where username like '%&USER%';
