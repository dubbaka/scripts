set pages 40 lines 200 
alter session set nls_date_format='YYYY-DD-MM HH24:MI:SS'; 
 SELECT to_char(a.sample_time,'DD-MON-YYYY HH24') "Sample Time",a.WAIT_CLASS,count(1)
  FROM
  dba_hist_active_sess_history a
  WHERE
  a.sample_time > TO_DATE('2017-24-02 09:00:00') and a.sample_time < TO_DATE('2017-24-02 10:00:00')
  and instance_number=1
  group by a.WAIT_CLASS,to_char(a.sample_time,'DD-MON-YYYY HH24')
  ORDER BY 3 desc;
