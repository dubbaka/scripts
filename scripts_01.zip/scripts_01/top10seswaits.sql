col event format a35
col totwaits format 999999999
col tottime format 999999.90
col maxtime format 999999.90
col avgtime format 999999.90
prompt Note - time is in seconds
select * from (
select count(*),e.event,
       sum(e.total_waits) totwaits,
       sum(e.time_waited) / 100 tottime,
       max(e.time_waited) / 100 maxtime,
       (sum(e.time_waited) / sum(e.total_waits)) / 100 avgtime
from v$session_event e, v$session s
where e.total_waits > 0
and e.event not like '%time%'
and e.event not like 'SQL*Net%'
and e.event not like 'pipe%'
and e.event not like '%ipc%'
and e.sid = s.sid
and s.type = 'USER'
group by event
order by 4 desc)
where rownum < 11
/
