select y4,y3,y2,y1 from
(select round(sum(bytes)/1024/1024/1024) y4 from v$datafile where creation_time between(sysdate-1460) and (sysdate-1096)) q1t,
(select round(sum(bytes)/1024/1024/1024) y3 from v$datafile where creation_time between(sysdate-1095) and (sysdate-731)) q2t,
(select round(sum(bytes)/1024/1024/1024) y2 from v$datafile where creation_time between(sysdate-730) and (sysdate-366)) q3t,
(select round(sum(bytes)/1024/1024/1024) y1 from v$datafile where creation_time between(sysdate-365) and (sysdate)) q4t;
