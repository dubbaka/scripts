set verify off
set lines 132
set pages 40
col bgpe format 999,999,999
col drpe format 999,999,999
col first_load_time format a18 trunc
col subsqltxt format a120 trunc head SQL_TEXT_60
select * from (
select hash_value,
	executions,
	buffer_gets,
	disk_reads,sorts,
       buffer_gets/decode(executions,0,1,executions) bgpe, 
       disk_reads/decode(executions,0,1,executions) drpe,
       substr(sql_text,1,120) subsqltxt
from v$sqlarea
where hash_value <> 0
and executions > 5
and buffer_gets/decode(executions,0,1,executions) > 50000
and upper(sql_text) not like 'BEGIN %'
order by 6 desc)
where rownum < 11;

