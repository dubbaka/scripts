/* topwritedf.sql
     see the top 10 io datafiles for write activity */
col fsmtpt format a5 head MtPt
col fname format a35 head FileName 
set verify off
select * from (
select substr(f.name,8,(instr(f.name,'/',9,1) -8)) fsmtpt,
       substr(f.name,(instr(f.name,'/',-1,1)+1)) fname,
       s.phyrds, s.phywrts,s.lstiotim,s.avgiotim
  from v$datafile f, v$filestat s
 where f.file# = s.file#
order by 4 desc)
where rownum < 11;


