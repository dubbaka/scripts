set serveroutput on size 1000000
set linesize 132
begin
 for i in (select vs.sid,
                  vs.serial#,
                  vs.process,
                  vp.spid,
                  vs.username,
                  vs.osuser,
                  vs.command,
                  vs.status,
                  vs.server,
                  vs.schemaname,
                  vs.machine,
                  vs.action,
                  vs.module,
                  vs.logon_time,
                  vp.terminal,
                  vp.program,
                  vp.latchwait,
                  vp.latchspin,
                  vp.pga_used_mem,
                  vp.pga_alloc_mem,
                  vp.pga_freeable_mem,
                  vp.pga_max_mem
           from v$session vs,
                v$process vp
           where vs.paddr = vp.addr
           and   vs.sid = '&dbsid')
 loop
  dbms_output.put_line('-------------------------------------------------------');
  dbms_output.put_line('------------------ Session Information ----------------');
  dbms_output.put_line('-------------------------------------------------------');
  dbms_output.put_line(rpad('DB SID:',30)||i.sid);
  dbms_output.put_line(rpad('DB Serial#:',30)||i.serial#);
  dbms_output.put_line(rpad('DB PID:',30)||i.process);
  dbms_output.put_line(rpad('OS PID:',30)||i.spid);
  dbms_output.put_line(rpad('DB User:',30)||i.username);
  dbms_output.put_line(rpad('OS User:',30)||i.osuser);
  dbms_output.put_line(rpad('Command:',30)||i.command);
  dbms_output.put_line(rpad('Status:',30)||i.status);
  dbms_output.put_line(rpad('Server:',30)||i.server);
  dbms_output.put_line(rpad('Schema:',30)||i.schemaname);
  dbms_output.put_line(rpad('Machine:',30)||i.machine);
  dbms_output.put_line(rpad('Action:',30)||i.action);
  dbms_output.put_line(rpad('Module:',30)||i.module);
  dbms_output.put_line(rpad('Logon Time:',30)||to_char(i.logon_time,'DD-MON-RRRR HH24:MI:SS'));
  dbms_output.put_line(rpad('Terminal:',30)||i.terminal);
  dbms_output.put_line(rpad('Program:',30)||i.program);
  dbms_output.put_line(rpad('Latch Wait:',30)||i.latchwait);
  dbms_output.put_line(rpad('Latch Spin:',30)||i.latchspin);
  dbms_output.put_line(rpad('PGA Used Mem:',30)||i.pga_used_mem);
  dbms_output.put_line(rpad('PGA Alloc Mem:',30)||i.pga_alloc_mem);
  dbms_output.put_line(rpad('PGA Freeable Mem:',30)||i.pga_freeable_mem);
  dbms_output.put_line(rpad('PGA Max Mem:',30)||i.pga_max_mem);

 end loop;

end;
/
