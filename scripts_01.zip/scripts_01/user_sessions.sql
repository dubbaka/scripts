set pagesize 50
col module format a50
col process format a15
col machine format a20
set linesize 180
select s.inst_id, sid, s.serial#,  s.process, machine,
module, status, blocking_session , round(last_call_et/60) "Last Call"
from gv$session s, gv$process p
where client_identifier='&USERNAME'
and s.paddr=p.addr
and s.inst_id=p.inst_id
--and status='ACTIVE'
order by status asc, last_call_et;

