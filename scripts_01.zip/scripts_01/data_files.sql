set linesize 120
col file_name format a65
select file_name, autoextensible, round(bytes/1024/1024/1024,2) "Size in GB", round(maxbytes/1024/1024/1024,2) "MaxSize in GB"
from dba_data_files
where tablespace_name='&tablespace_name';
