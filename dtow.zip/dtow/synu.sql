set long 9999
spool &&1
select table_owner, db_link, table_name from user_SYNONYMS
where synonym_name = upper('&&1') ;
spool off
