column oldlio noprint
column oldpio noprint
column lio format a28
column pio format a28
select 'Logical Reads = '||(l.value-&&oldlio-4) LIO,
'Physical Reads = '||(p.value-&&oldpio) PIO, l.value oldlio, p.value oldpio
from v$sesstat l, v$sesstat p 
where l.statistic# = 9 and p.statistic# = 40
and l.sid = &&session_id and p.sid = l.sid;
