set heading off
set verify off
set feedback off
set linesize 400
spool tmpdistr.sql
SELECT
'SELECT SUM(Count_Column*Count_Column)/(SUM(Count_Column)*SUM(Count_All))'||
'FROM   (SELECT COUNT('|| '&&1'||') Count_Column, COUNT(*) Count_All FROM '||
'&&2'|| ' GROUP BY '||'&&1'||');' FROM DUAL;
spool off
@tmpdistr
