-- Copyright 2003 Dan Tow, All rights reserved
set echo off
set lines 64
set pages 9999
set heading off
set feedback off
set verify off
set heading off
spool tmpshow.sql
select sql_text from pm_sql where hash_value=&&1 order by piece;
spool off
!(tr -d '\n' < tmpshow.sql ;echo)| sed 's/  *; *$/;/' | sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^)]*)/:x1/g'|sed 's/DD HH24 MI SS/DD:HH24:MI:SS/g' | sed 's/,TO_CHAR/, TO_CHAR/g'| sed 's/,/ ,/g' | tr -s ' ' '\n' | sed '/^([0-9][0-9]*))*$/s/[0-9][0-9]*/&,-14325/'  | grep -v '^ *$' > tmpshow2.sql
!./ppd2
!echo explain plan for > tmpshow.sql
!cat tmpppout >> tmpshow.sql
!echo ';' >> tmpshow.sql
delete from plan_table;
spool tmp
@tmpshow.sql
spool off
set timing off
set lines 240
set pages 9999
set feedback off
set verify off
set heading off
set term off
spool tmpplan.out
SELECT LPAD(' ',2*(LEVEL-1))||OPERATION||' '||OPTIONS||' '|| DECODE(OBJECT_INSTANCE, NULL, OBJECT_NAME,
			TO_CHAR(OBJECT_INSTANCE)||'*'|| OBJECT_NAME) PLAN
			FROM PLAN_TABLE
			START WITH ID=0
			CONNECT BY PRIOR ID = PARENT_ID
			ORDER BY ID;
spool off                                                                      
rollback;
!sed '1 d' tmpshow.sql > tmpplanrpt.txt
!sed 's/  *$//' tmpplan.out >> tmpplanrpt.txt
!cat tmpplanrpt.txt
set term on
