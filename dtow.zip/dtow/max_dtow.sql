set echo off verify off head off feed off pages 0 trimspool on
alter session set nls_date_format='DD-MON-YYYY==>HH:MI:SS:AM';
select max(SNAP_DATE_TIME)||','||round((sysdate - max(SNAP_DATE_TIME))*1440,0) from spt_dtow.DTOW_DELAY_SNAP;
exit
