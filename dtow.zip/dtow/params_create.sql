create table pm_report_params (min_time_of_day char(2),max_time_of_day char(2), exclude_weekend_flag char(1), backwards_reach number,
start_of_interval date, end_of_interval date);
insert into pm_report_params values ('08','17','Y',7,sysdate-10000,sysdate+10000);
commit;

