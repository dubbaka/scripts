# set up environment
# run with cron entry like:
# 5 * * * * /home/oracle/scripts/dtow/drivergen.sh > /dev/null
. /opt/app/oracle/db_omsprd/11.2.0.3/OMSPRD1_xd01db01.env
cd /home/oracle/scripts/dtow
echo test `date` >> testlog
sqlplus spt_dtow/simple4dtow@xd0101-vip.thefacebook.com:1551/OMSPRD @hourdriver3 > /dev/null &
sleep 10
sqlplus spt_dtow/simple4dtow@xd0102-vip.thefacebook.com:1551/OMSPRD @hourdriver3 > /dev/null &
echo testend `date` >> testlog
