select sql_text from pm_sql where hash_value  = &&1;
