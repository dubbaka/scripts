--Copyright 2002 Dan Tow, all rights reserved
column mode_held format a10
column mode_requested format a14
column waiting format 999999
column holding format 999999
column lock_type format a15
column delay format a10
column osuser format a8
column machine format a8
column program format a20
column root_sid format 999999
column seq# format 999999999
select /*+ ordered */ w.sid waiting, h.sid holding,
decode(w.type,'MR','Media Recovery', 'RT', 'Redo Thread',
'UN','User Name', 'TX', 'Transaction', 'TM', 'DML', 'UL', 'PL/SQL User Lock'
,'DX', 'Distributed Xaction', 'CF', 'Control File', 'IS', 'Instance State',
'FS', 'File Set', 'IR', 'Instance Recovery', 'ST', 'Disk Space Transaction',
'TS', 'Temp Segment', 'IV', 'Library Cache Invalidation',
'LS', 'Log Start or Switch', 'RW', 'Row Wait', 'SQ', 'Sequence Number',
'TE', 'Extend Table', 'TT', 'Temp Table', w.type) lock_type,
decode(h.lmode, 0, 'None', 1, 'Null', 2, 'Row-S (SS)', 3, 'Row-X (SX)',
4, 'Share', 5, 'S/Row-X (SSX)', 6, 'Exclusive', to_char(h.lmode)) mode_held,
decode(w.request, 0, 'None', 1, 'Null', 2, 'Row-S (SS)', 3, 'Row-X (SX)',
4, 'Share', 5, 'S/Row-X (SSX)', 6, 'Exclusive',
to_char(w.request)) mode_requested, w.id1, w.id2
from v$lock w, v$lock h
where h.block =  1 and  h.lmode != 0 and  h.lmode != 1
and  w.request != 0 and  w.type = h.type and  w.id1=h.id1
and  w.id2 = h.id2 order by 1;
select h.sid Root_sid, decode(sw.WAIT_TIME, 0, decode(sw.event,
'SQL*Net message from client','idle',
'db file scattered read','scanIO',
'db file sequential read','indexIO',sw.event), 'CPU') delay,
sw.seq#, s.OSUSER, s.process, s.machine, s.program
from
(select sid from v$lock h
where lmode !=0 and lmode !=1 and block=1
and exists (select null from v$lock w where h.id1 = w.id1 and h.id2=w.id2
            and w.request !=0 and h.type=w.type)
and not exists (select null from v$lock w where w.request !=0
               and h.sid = w.sid
               and exists (select null from v$lock h2 where
                          h2.id1=w.id1 and h2.id2=w.id2 and h2.type=w.type
                          and h2.lmode!=0 and h2.lmode!=1 and h2.block=1))
) h,
v$session s, v$session_wait sw
where h.sid+0 = s.sid
and decode(sw.wait_time,0,sw.event,'CPU')!='enqueue'
and s.sid+0 = sw.sid order by 1;
select /*+ ordered */ h.sid holding, w.sid waiting,
decode(w.type,'MR','Media Recovery', 'RT', 'Redo Thread',
'UN','User Name', 'TX', 'Transaction', 'TM', 'DML', 'UL', 'PL/SQL User Lock'
,'DX', 'Distributed Xaction', 'CF', 'Control File', 'IS', 'Instance State',
'FS', 'File Set', 'IR', 'Instance Recovery', 'ST', 'Disk Space Transaction',
'TS', 'Temp Segment', 'IV', 'Library Cache Invalidation',
'LS', 'Log Start or Switch', 'RW', 'Row Wait', 'SQ', 'Sequence Number',
'TE', 'Extend Table', 'TT', 'Temp Table', w.type) lock_type,
decode(h.lmode, 0, 'None', 1, 'Null', 2, 'Row-S (SS)', 3, 'Row-X (SX)',
4, 'Share', 5, 'S/Row-X (SSX)', 6, 'Exclusive', to_char(h.lmode)) mode_held,
decode(w.request, 0, 'None', 1, 'Null', 2, 'Row-S (SS)', 3, 'Row-X (SX)',
4, 'Share', 5, 'S/Row-X (SSX)', 6, 'Exclusive',
to_char(w.request)) mode_requested, w.id1, w.id2
from v$lock w, v$lock h
where h.block =  1 and  h.lmode != 0 and  h.lmode != 1
and  w.request != 0 and  w.type = h.type and  w.id1=h.id1
and  w.id2 = h.id2 order by 1,2;
