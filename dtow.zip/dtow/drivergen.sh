# set up environment
# run with cron entry like:
# 5 * * * * /net/dba/fbmon/bin/dtow/drivergen.sh > /dev/null
. /u01/app/oracle/product/db_omsprd/12.1.0.2/OMSPRD1_finprd1-vip.env
cd /net/dba/fbmon/bin/dtow
echo test `date` >> testlog
sqlplus spt_dtow/a1s2d3f412432@finprd1-vip.thefacebook.com:1551/OMSPRD @hourdriver3 > /dev/null &
sleep 10
sqlplus spt_dtow/a1s2d3f412432@finprd2-vip.thefacebook.com:1551/OMSPRD @hourdriver3 > /dev/null &
echo testend `date` >> testlog
