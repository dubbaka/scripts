grant connect, resource, select any table, select any dictionary to DTOW;
grant execute on DBMS_LOCK to DTOW;