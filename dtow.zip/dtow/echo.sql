select lpad('.',&&2,'.')||'&&3'||' c='||'&&4'||', R='||'&&5' step from dual;
