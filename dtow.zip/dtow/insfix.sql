--insfix.sql
insert into dtow_sql_statement_fix values (&&1, '&&2', sysdate, sysdate, null);
commit;
@checksql &&1
