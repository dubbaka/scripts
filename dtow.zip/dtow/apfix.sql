--apfix.sql
update pm_sql_statement_fix set reference=reference||'&&2'
where reference = '&&1';
commit;
select * from pm_sql_statement_fix where reference like '&&1'||'%';
