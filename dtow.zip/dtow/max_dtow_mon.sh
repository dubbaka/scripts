#!/bin/sh
source /net/dba/fbmon/bin/dtow/dtow_mon_params.env >/dev/null 2>&1
WarningEmailList='it-omg-dba@fb.com,it-omg-dba-pager@fb.com,oncall+oracle_dba@xmail.facebook.com,tasks+Finance_Platform_Eng&oncall&hi-pri@xmail.facebook.com'
echo $WarningEmailList
db_name=$1
hostname=$(hostname -s)
date=`date "+%m-%d-%Y %H:%M"`
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"
ORACLE_SID=$1
source /usr/local/bin/dbenv $ORACLE_SID >/dev/null 2>&1
LOG_FILE=/tmp/dtow_${db_name}.log
/bin/rm /tmp/max_dtow.txt
sqlplus -s "/ as sysdba" @/net/dba/fbmon/bin/dtow/max_dtow.sql > /tmp/max_dtow.txt

for line in `cat /tmp/max_dtow.txt`
do
   current_max_snap_time=$( echo $line | awk -F',' '{print $1}' )
   behind_minutes=$( echo $line | awk -F',' '{print $2}' )

      if [[ $behind_minutes -gt $WarningThreshold ]]
     then
        echo "DTOW Top SQL is  $behind_minutes minutes behind. Current Max Snap Time is  $current_max_snap_time "
        echo -e "DTOW Top SQL is  $behind_minutes minutes behind current sysdate.\n\n Current Max Snap Time is  $current_max_snap_time " |  mailx -s "[INFO]: $hostname : DTOW Top SQL is $behind_minutes minutes behind current sysdate" "it-omg-dba@fb.com,it-omg-dba-pager@fb.com,oncall+oracle_dba@xmail.facebook.com,tasks+Finance_Platform_Eng&oncall&hi-pri@xmail.facebook.com"
     else
        echo "DTOW Top SQL is  $behind_minutes minutes behind. Current Max Snap Time is  $current_max_snap_time "
        continue;
     fi

     if [[ $behind_minutes -gt $CriticalThreshold  ]]
     then
        echo "DTOW Top SQL is  $behind_minutes minutes behind. Current Max Snap Time is  $current_max_snap_time "
        echo -e "DTOW Top SQL is  $behind_minutes minutes behind current sysdate.\n\n Current Max Snap Time is  $current_max_snap_time " |  mail -s "[CRITICAL]: $hostname : DTOW Top SQL is $behind_minutes minutes behind current sysdate" $CriticalEmailList
     else
        echo "DTOW Top SQL is  $behind_minutes minutes behind. Current Max Snap Time is  $current_max_snap_time "
        continue;
     fi
done
