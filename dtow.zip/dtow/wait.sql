set pages 999
select count(*), decode(wait_time, 0, event,
         decode(s.command, 0, decode(s.status, 'INACTIVE', '???','?'),
                              decode(s.status, 'INACTIVE', '??', 'CPU'))) delay
from v$session_wait w, v$session s
where s.sid=w.sid and s.status='ACTIVE'
and s.sid=&&1
group by decode(wait_time, 0, event,
         decode(s.command, 0, decode(s.status, 'INACTIVE', '???','?'),
                              decode(s.status, 'INACTIVE', '??', 'CPU'))) 
order by 1 desc;
