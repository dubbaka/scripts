set lines 80
column table_owner format a30
column stats format a3
set pages 0
spool tableout
select owner, table_name, decode(num_rows, null, 'N','Y') stats
 from dba_tables
order by owner, table_name;
spool off
