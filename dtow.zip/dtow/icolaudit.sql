set lines 80
column column_name format a30
column table_owner format a15
set pages 0
spool icolout
select table_owner, index_name, column_name from dba_ind_columns
order by table_owner, table_name, index_name, column_position;
spool off
