select num_distinct from all_tab_columns where column_name =
upper('&&1') and table_name = upper('&&2');
