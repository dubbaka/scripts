set timing off
set lines 320
set pages 9999
set feedback off
set verify off
spool ex.out
set term off
spool off
set heading off
spool tmpdet.sql
select '@detailq8', level, ''''||'&&1'||'''', ''''||OPERATION||'''',
substr(''''||rpad(to_char(level),3)||OPERATION||' '||OPTIONS||' '||
decode(OBJECT_INSTANCE, null, OBJECT_NAME,
			      to_char(OBJECT_INSTANCE)||'*'|| OBJECT_NAME)||
			      '''', 1, 80) str,
nvl(substr(OBJECT_NAME, 1, 40),''' ''') oname,
nvl(OBJECT_OWNER, ''' ''') oowner, nvl(to_char(cost),'_'),
nvl(to_char(cardinality),'_')
from plan_table
start with id=0 AND STATEMENT_ID = 'dantow'
connect by prior id = parent_id AND STATEMENT_ID = 'dantow'
order by id;
spool off
spool tmpdet2.sql
@tmpdet
spool off
spool tmpdet3.sql
@tmpdet2
spool off
spool tmpex.out
@tmpdet3
spool off
set term on
set heading on
!grep -v '^$' tmpex.out|sed 's/  *$//' |tee -a ex.out
set timing on
