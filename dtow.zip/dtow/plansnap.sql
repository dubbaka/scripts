insert into dtow_sqlplan_tmp select /*+ ordered */                         
        distinct t.hash_value, t.plan_hash, id, parent_id, operation,         
        options, object_name, object_owner, cost, cardinality                  
        from (select distinct hash_value, plan_hash
              from dtow_sql_plan_comb_tmp) t, v$sql_plan p                 
        where p.hash_value = t.hash_value;      
delete from dtow_sqlplan_tmp p where exists (select null
from dtow_sqlplan_tmp p2
  where p.hash_value = p2.hash_value and p.plan_hash = p2.plan_hash
  and p.id=p2.id
  and (p2.cost > nvl(p.cost,0)
   OR p2.cost = nvl(p.cost,0) and p2.cardinality > nvl(p.cardinality,0)));
insert into dtow_sql_plan_comb select distinct hash_value, plan_hash, sysdate   
               from dtow_sqlplan_tmp t
where not exists (select null from dtow_sql_plan_comb c
where c.hash_value=t.hash_value and c.plan_hash=t.plan_hash);  
insert into dtow_sqlplan select * from dtow_sqlplan_tmp;
delete from dtow_sqlplan_tmp;
delete from dtow_sql_plan_comb_tmp;
commit;
