select /* test 53623atx8qq0b */ /*+ gather_plan_statistics */ *
FROM
(SELECT fbpaymentbatchapproval.seq_number,
fbpaymentbatchapproval.payment_service_request_id,
fbpaymentbatchapproval.revision_number,
fbpaymentbatchapproval.call_app_pay_service_req_code,
fbpaymentbatchapproval.payment_type,
fbpaymentbatchapproval.no_of_payments,
fbpaymentbatchapproval.bank_account_number,
fbpaymentbatchapproval.bank_acct_currency,
fbpaymentbatchapproval.currency,
fbpaymentbatchapproval.amount,
fbpaymentbatchapproval.approval_status,
fbpaymentbatchapproval.ap_approved_by,
fbpaymentbatchapproval.ap_approved_date,
fbpaymentbatchapproval.finance1_approved_by,
fbpaymentbatchapproval.finance1_approved_date,
fbpaymentbatchapproval.finance2_apprv_req_flag,
fbpaymentbatchapproval.finance2_approved_by,
fbpaymentbatchapproval.finance2_approved_date,
fbpaymentbatchapproval.batch_status,
fbpaymentbatchapproval.comments,
fbpaymentbatchapproval.created_by,
(SELECT full_name
FROM
fnd_user fu
, per_people_x pp
WHERE fu.user_id     = fbpaymentbatchapproval.created_by
AND fu.employee_id = pp.person_id)
||DECODE(fbpaymentbatchapproval.created_by,NULL,' ',':N')||fbpaymentbatchapproval.creation_date created_by_name,
fbpaymentbatchapproval.creation_date,
fbpaymentbatchapproval.last_updated_by,
(SELECT full_name
FROM
fnd_user fu
,per_people_x pp
WHERE fu.user_id     = fbpaymentbatchapproval.last_updated_by
AND fu.employee_id = pp.person_id) last_updated_by_name,
fbpaymentbatchapproval.last_update_date,
fbpaymentbatchapproval.last_update_login,
'N' select_flag,
DECODE(xxfb_payment_batch_apprv_pkg.xxfb_get_pay_batch_user_role(org_id, legal_entity_id)
, 'AP', DECODE(fbpaymentbatchapproval.approval_status,'PENDING_AP_APPROVAL','Y','N')
, 'GUEST', 'N'
, 'FIN', DECODE(fbpaymentbatchapproval.approval_status,'PENDING_FINANCE1_APPROVAL','Y'
,'PENDING_FINANCE2_APPROVAL',DECODE(fbpaymentbatchapproval.finance1_approved_by
,FND_PROFILE.VALUE('USER_ID'), 'N'
,'Y'))) enable_flag,
(SELECT full_name
FROM
fnd_user fu
, per_people_x pp
WHERE fu.user_id     = fbpaymentbatchapproval.ap_approved_by
AND fu.employee_id = pp.person_id)
||DECODE(fbpaymentbatchapproval.ap_approved_by,NULL,' ',':N')||fbpaymentbatchapproval.ap_approved_date ap_approver_name,
(SELECT full_name
FROM
fnd_user fu
,per_people_x pp
WHERE fu.user_id = fbpaymentbatchapproval.finance1_approved_by
AND fu.employee_id = pp.person_id)
||DECODE(fbpaymentbatchapproval.finance1_approved_by,NULL,' ',':N')||fbpaymentbatchapproval.finance1_approved_date Finance1_Approver_Name,
(SELECT full_name
FROM
fnd_user fu
,per_people_x pp
WHERE fu.user_id     = fbpaymentbatchapproval.finance2_approved_by
AND fu.employee_id = pp.person_id)
||DECODE(fbpaymentbatchapproval.finance2_approved_by,NULL,' ',':N')||fbpaymentbatchapproval.finance2_approved_date Finance2_approver_name,
decode(fbpaymentbatchapproval.approval_status, 'PENDING_AP_APPROVAL','Pending AP Approval'
, 'PENDING_FINANCE1_APPROVAL','Pending Finance1 Approval'
, 'PENDING_FINANCE2_APPROVAL','Pending Finance2 Approval'
, 'APPROVED', 'Approved'
, 'REJECTED', 'Rejected') status_description,
org_id,
legal_entity_id,
(SELECT bank_Account_name
FROM
ce_bank_accounts
WHERE bank_account_num = fbpaymentbatchapproval.bank_account_number
AND NVL(end_date, SYSDATE+1) >= SYSDATE) bank_acct_name
,v.new_suppliers
,v.payment_above_1m
,v.supp_not_paid_in_6_months
,v.multiple_payments
,v.invoices_po_not_matched
,v.supp_pay_variance
FROM
xxfb_payment_batch_approval fbpaymentbatchapproval
,xxfb_payments_detail_v v
WHERE seq_number = (SELECT MAX(seq_number)
FROM
xxfb_payment_batch_approval p1
WHERE fbpaymentbatchapproval.payment_service_request_id = p1.payment_service_request_id)
AND fbpaymentbatchapproval.payment_service_request_id = v.payment_service_request_id(+)) QRSLT 
WHERE (1=1 AND APPROVAL_STATUS like :N0 AND
EXISTS(SELECT 1
FROM 
xxfb_iby_pay_batch_approvers a
,fnd_user fu
WHERE QRSLT.org_id = NVL(a.operating_unit_id,QRSLT.org_id)
AND QRSLT.legal_entity_id = NVL(a.legal_entity_id,QRSLT.legal_entity_id)
AND a.person_id = fu.employee_id
AND fu.user_id  = FND_PROFILE.VALUE('USER_ID')
AND TRUNC(SYSDATE) <= NVL(a.end_date,TRUNC(SYSDATE+1)))
AND NOT EXISTS(SELECT 1
FROM
xxfb_payment_batch_approval p
WHERE p.seq_number          = QRSLT.seq_number
AND p.finance1_approved_by = FND_PROFILE.VALUE('USER_ID')
))
ORDER BY creation_date desc;
