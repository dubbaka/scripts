CREATE OR REPLACE VIEW dtow_ap_ael_sl_pay_v (
   accounted_cr,
   accounted_dr,
   entered_cr,
   entered_dr,
   accounting_date,
   acct_line_type,
   acct_line_type_name,
   aeh_id,
   ael_id,
   ael_table,
   ae_line_reference,
   application_id,
   code_combination_id,
   comments,
   currency_code,
   currency_conversion_date,
   currency_conversion_rate,
   currency_conversion_type,
   currency_user_conversion_type,
   doc_sequence_id,
   doc_sequence_name,
   doc_sequence_value,
   gl_transfer_status,
   gl_transfer_status_name,
   transfer_status_detail_name,
   org_id,
   set_of_books_id,
   source_id,
   source_table,
   tax_code,
   third_party_type,
   third_party_id,
   third_party_number,
   third_party_name,
   third_party_sub_id,
   third_party_sub_name,
   trx_class,
   trx_class_name,
   trx_date,
   trx_hdr_id,
   trx_hdr_table,
   trx_number_displayed,
   trx_number_n,
   trx_type_c,
   trx_type_name,
   accounting_event_number,
   accounting_event_type,
   accounting_event_type_name,
   accounting_line_number,
   je_category,
   user_je_category_name,
   aeh_accounting_error_code,
   aeh_accounting_error_name,
   ael_accounting_error_code,
   ael_accounting_error_name,
   trx_hdr_currency,
   last_update_date,
   last_updated_by,
   creation_date,
   created_by,
   last_update_login,
   request_id,
   program_application_id,
   program_id,
   program_update_date,
   bank_account_name,
   applied_to_trx_hdr_table,
   applied_to_trx_hdr_id,
   applied_to_trx_hdr_number_disp,
   applied_to_trx_hdr_number_c,
   applied_to_trx_hdr_currency,
   trx_line_number,
   trx_line_type,
   trx_line_type_name,
   po_order_number,
   po_order_release_num,
   rcv_receipt_num,
   payment_cleared_date,
   bank_statement_number,
   payment_recon_currency,
   bank_statement_line_number,
   bank_statement_doc_seq_id,
   bank_statement_doc_seq_name,
   bank_statement_doc_seq_value,
segment1,
segment2,
segment3,
segment4,
segment5,
segment6,
chart_of_accounts_id
)
AS
   SELECT ael.accounted_cr accounted_cr, ael.accounted_dr accounted_dr,
          ael.entered_cr entered_cr, ael.entered_dr entered_dr,
          aeh.accounting_date accounting_date,
          ael.ae_line_type_code acct_line_type,
          l3.displayed_field acct_line_type_name, aeh.ae_header_id aeh_id,
          ael.ae_line_id ael_id, 'APAEL' ael_table,
          DECODE (
             ae.event_type_code,
             'PAYMENT CLEARING',    l10.displayed_field
                                 || ' '
                                 || ae.event_number
                                 || ', '
                                 || l11.displayed_field
                                 || ' '
                                 || ael.ae_line_number
                                 || ', '
                                 || l13.displayed_field
                                 || ' '
                                 || sh.statement_number
                                 || ', '
                                 || l11.displayed_field
                                 || ' '
                                 || sl.line_number,
             'PAYMENT UNCLEARING',    l10.displayed_field
                                   || ' '
                                   || ae.event_number
                                   || ', '
                                   || l11.displayed_field
                                   || ' '
                                   || ael.ae_line_number
                                   || ', '
                                   || l13.displayed_field
                                   || ' '
                                   || sh.statement_number
                                   || ', '
                                   || l11.displayed_field
                                   || ' '
                                   || sl.line_number,
             DECODE (
                ael.source_table,
                'AP_INVOICE_PAYMENTS',    l10.displayed_field
                                       || ' '
                                       || ae.event_number
                                       || ', '
                                       || l11.displayed_field
                                       || ' '
                                       || ael.ae_line_number
                                       || ', '
                                       || l12.displayed_field
                                       || ' '
                                       || i.invoice_num,
                   l10.displayed_field
                || ' '
                || ae.event_number
                || ', '
                || l11.displayed_field
                || ' '
                || ael.ae_line_number
                || ', '
                || l8.displayed_field
                || ' '
                || c.check_number
             )
          ) ae_line_reference,
          200 application_id, ael.code_combination_id code_combination_id,
          ael.description comments, ael.currency_code currency_code,
          ael.currency_conversion_date currency_conversion_date,
          ael.currency_conversion_rate currency_conversion_rate,
          ael.currency_conversion_type currency_conversion_type,
          glct.user_conversion_type currency_user_conversion_type,
          ael.subledger_doc_sequence_id doc_sequence_id,
          fd.NAME doc_sequence_name,
          ael.subledger_doc_sequence_value doc_sequence_value,
          aeh.gl_transfer_flag gl_transfer_status,
          l4.displayed_field gl_transfer_status_name,
          l9.displayed_field transfer_status_detail_name, aeh.org_id org_id,
          aeh.set_of_books_id set_of_books_id, ael.source_id source_id,
          ael.source_table source_table, AT.NAME tax_code,
          'CUSTOMER' third_party_type, ael.third_party_id third_party_id,
          v.segment1 third_party_number, v.vendor_name third_party_name,
          ael.third_party_sub_id third_party_sub_id,
          vs.vendor_site_code third_party_sub_name, 'PAY' trx_class,
          l8.displayed_field trx_class_name, c.check_date trx_date,
          c.check_id trx_hdr_id, 'APC' trx_hdr_table,
          TO_CHAR (c.check_number) trx_number_displayed,
          c.check_number trx_number_n, c.payment_method_lookup_code trx_type_c,
          l1.displayed_field trx_type_name,
          ae.event_number accounting_event_number,
          ae.event_type_code accounting_event_type,
          l5.displayed_field accounting_event_type_name,
          ael.ae_line_number accounting_line_number,
          aeh.ae_category je_category,
          jc.user_je_category_name user_je_category_name,
          aeh.accounting_error_code aeh_accounting_error_code,
          l6.displayed_field aeh_accounting_error_name,
          ael.accounting_error_code ael_accounting_error_code,
          l7.displayed_field ael_accounting_error_name,
          c.currency_code trx_hdr_currency,
          ael.last_update_date last_update_date,
          ael.last_updated_by last_updated_by, ael.creation_date creation_date,
          ael.created_by created_by, ael.last_update_login last_update_login,
          ael.request_id request_id,
          ael.program_application_id program_application_id,
          ael.program_id program_id,
          ael.program_update_date program_update_date,
/*---------------------------------------------------------------*/ /* AP Payment Specific columns */ /*---------------------------------------------------------------*/
          c.bank_account_name bank_account_name,
          'AP_INVOICES' applied_to_trx_hdr_table,
          i.invoice_id applied_to_trx_hdr_id,
          DECODE (
             ael.source_table,
             'AP_INVOICE_DISTRIBUTIONS', ael.reference5,
             i.invoice_num
          ) applied_to_trx_hdr_number_disp,
          DECODE (
             ael.source_table,
             'AP_INVOICE_DISTRIBUTIONS', ael.reference5,
             i.invoice_num
          ) applied_to_trx_hdr_number_c,
          i.invoice_currency_code applied_to_trx_hdr_currency,
/*---------------------------------------------------------------*/ /* Columns for cash basis accounting */ /*---------------------------------------------------------------*/
          d.distribution_line_number trx_line_number,
          d.line_type_lookup_code trx_line_type,
          l2.displayed_field trx_line_type_name, ph.segment1 po_order_number,
          pr.release_num po_order_release_num, rsh.receipt_num rcv_receipt_num,
/*---------------------------------------------------------------*/ /* AP Reconciliation Specific columns */ /*---------------------------------------------------------------*/
          DECODE (
             ae.event_type_code,
             'PAYMENT CLEARING', c.cleared_date,
             'PAYMENT UNCLEARING', c.cleared_date,
             NULL
          ) payment_cleared_date,
          DECODE (
             ae.event_type_code,
             'PAYMENT CLEARING', sh.statement_number,
             'PAYMENT UNCLEARING', sh.statement_number,
             NULL
          ) bank_statement_number,
          DECODE (
             ae.event_type_code,
             'PAYMENT CLEARING', sh.currency_code,
             'PAYMENT UNCLEARING', sh.currency_code,
             NULL
          ) payment_recon_currency,
          DECODE (
             ae.event_type_code,
             'PAYMENT CLEARING', sl.line_number,
             'PAYMENT UNCLEARING', sl.line_number,
             NULL
          ) bank_statement_line_number,
          DECODE (
             ae.event_type_code,
             'PAYMENT CLEARING', sh.doc_sequence_id,
             'PAYMENT UNCLEARING', sh.doc_sequence_id,
             NULL
          ) bank_statement_doc_seq_id,
          DECODE (
             ae.event_type_code,
             'PAYMENT CLEARING', fd2.NAME,
             'PAYMENT UNCLEARING', fd2.NAME,
             NULL
          ) bank_statement_doc_seq_name,
          DECODE (
             ae.event_type_code,
             'PAYMENT CLEARING', sh.doc_sequence_value,
             'PAYMENT UNCLEARING', sh.doc_sequence_value,
             NULL
          ) bank_statement_doc_seq_value,
cc.segment1,
cc.segment2,
cc.segment3,
cc.segment4,
cc.segment5,
cc.segment6,
cc.chart_of_accounts_id
     FROM gl_code_combinations cc,
          ap_invoice_distributions d,
          ap_invoices i,
          ap_invoice_payments p,
          ap_checks c,
          ap_accounting_events ae,
          ap_ae_headers aeh,
          ap_ae_lines ael,
          ce_statement_lines sl,
          ce_statement_headers sh,
          ce_statement_reconciliations csr,
          po_vendor_sites vs,
          po_vendors v,
          ap_tax_codes AT,
          rcv_shipment_headers rsh,
          po_releases pr,
          po_headers ph,
          po_distributions pd,
          rcv_transactions rct,
          gl_je_categories jc,
          gl_daily_conversion_types glct,
          fnd_document_sequences fd,
          fnd_document_sequences fd2,
          ap_lookup_codes l1,
          ap_lookup_codes l2,
          ap_lookup_codes l3,
          ap_lookup_codes l4,
          ap_lookup_codes l5,
          ap_lookup_codes l6,
          ap_lookup_codes l7,
          ap_lookup_codes l8,
          ap_lookup_codes l9,
          ap_lookup_codes l10,
          ap_lookup_codes l11,
          ap_lookup_codes l12,
          ap_lookup_codes l13
    WHERE l1.lookup_code = c.payment_method_lookup_code
      AND l1.lookup_type = 'PAYMENT METHOD'
      AND cc.code_combination_id = ael.code_combination_id
      AND l2.lookup_code(+) = d.line_type_lookup_code
      AND l2.lookup_type(+) = 'INVOICE DISTRIBUTION TYPE'
      AND l3.lookup_code = ael.ae_line_type_code
      AND l3.lookup_type = 'AE LINE TYPE'
      AND l4.lookup_code = aeh.gl_transfer_flag
      AND l4.lookup_type = 'POSTING STATUS'
      AND l5.lookup_code = ae.event_type_code
      AND l5.lookup_type = 'EVENT TYPE'
      AND l6.lookup_code(+) = aeh.accounting_error_code
      AND l6.lookup_type(+) = 'ACCOUNTING ERROR TYPE'
      AND l7.lookup_code(+) = ael.accounting_error_code
      AND l7.lookup_type(+) = 'ACCOUNTING ERROR TYPE'
      AND l8.lookup_code = 'Payments'
      AND l8.lookup_type = 'POSTING CATEGORY'
      AND l9.lookup_code(+) = ael.gl_transfer_error_code
      AND l9.lookup_type(+) = 'POSTING EXCEPTIONS'
      AND l10.lookup_code = 'EVENT'
      AND l10.lookup_type = 'VIEW_ACCOUNTING'
      AND l11.lookup_code = 'LINE'
      AND l11.lookup_type = 'VIEW_ACCOUNTING'
      AND l12.lookup_code = 'APPLIED_TO'
      AND l12.lookup_type = 'VIEW_ACCOUNTING'
      AND l13.lookup_code = 'BANK_STATEMENT'
      AND l13.lookup_type = 'VIEW_ACCOUNTING'
      AND AT.tax_id(+) = ael.tax_code_id
      AND jc.je_category_name = aeh.ae_category
      AND rsh.shipment_header_id(+) = rct.shipment_header_id
      AND d.rcv_transaction_id = rct.transaction_id(+)
      AND pr.po_release_id(+) = pd.po_release_id
      AND ph.po_header_id(+) = pd.po_header_id
      AND pd.po_distribution_id(+) = d.po_distribution_id
      AND ael.currency_conversion_type = glct.conversion_type(+)
      AND c.doc_sequence_id = fd.doc_sequence_id(+)
      AND sh.doc_sequence_id = fd2.doc_sequence_id(+)
      AND ael.third_party_sub_id = vs.vendor_site_id
      AND ael.third_party_id = v.vendor_id
      AND i.invoice_id(+) = p.invoice_id
      AND c.check_id = ae.source_id
      AND ae.source_table = 'AP_CHECKS'
      AND ae.accounting_event_id = aeh.accounting_event_id
      AND aeh.ae_header_id = ael.ae_header_id
      AND sl.statement_header_id = sh.statement_header_id(+)
      AND csr.statement_line_id = sl.statement_line_id(+)
      AND c.check_id = csr.reference_id(+)
      AND csr.reference_type(+) = 'PAYMENT'
      AND csr.current_record_flag(+) = 'Y'
      AND DECODE (ael.source_table, 'AP_INVOICE_PAYMENTS', ael.source_id, NULL) =
                                                      p.invoice_payment_id(+)
      AND DECODE (
             ael.source_table,
             'AP_INVOICE_DISTRIBUTIONS', ael.source_id,
             NULL
          ) = d.invoice_distribution_id(+)
