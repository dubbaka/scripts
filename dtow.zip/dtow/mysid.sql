column session_id new_value session_id
column oldlio new_value oldlio
column oldpio new_value oldpio
select s.sid session_id, p.spid "Oracle_PID",
s.process "Client_PID" from v$session s, v$process p
where s.paddr=p.addr
and s.audsid = userenv('SESSIONID');
set term off
select l.value oldlio, p.value oldpio
from v$sesstat l, v$sesstat p
where l.statistic# = 9 and p.statistic# = 40
and l.sid = &&session_id and p.sid = &&session_id ;
set term on
