select request_id, count(*) from pm_snapshot where sql_hash_value = &&1
group by request_id;
