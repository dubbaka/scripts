select trunc(snap_date_time), plan_hash, count(*) from dtow_snapshot where sql_hash_value = 
&&1 or plan_hash = &&1 group by trunc(snap_date_time), plan_hash order by 1,2;
