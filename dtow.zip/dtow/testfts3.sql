set timing on
set verify off
spool testfts2
@mysid
select count(*), avg(org_id) 
from oe_order_lines_all where mod(header_id,16) = 15;
@reads
select count(*), avg(org_id)
from oe_order_lines_all where mod(header_id,16) = 15
and HEADER_ID>(-999999999999999999999999999999999);
@reads
select count(*), avg(org_id) 
from oe_order_lines_all where mod(header_id,16) = 15;
@reads
select count(*), avg(org_id)
from oe_order_lines_all where mod(header_id,16) = 15
and HEADER_ID>(-999999999999999999999999999999999);
@reads
spool off
quit
