-- Copyright 2003 Dan Tow, All rights reserved
set pagesize 0
set feedback off
set heading off
set verify off
set num 15
set lines 240
spool tmplongrpt
select '@rptlongsql', sql_hash,
((600*disk_reads)+buffer_gets)/(60000*greatest(1,executions)) secperexec,
disk_reads/greatest(1,executions) PIOperExec,
buffer_gets/greatest(1,executions) LIOperExec,
rows_processed/greatest(1,executions) RowsperExec, executions
snap_date_time
from pm_sqlarea s
where ((600*disk_reads)+buffer_gets)/(60000*greatest(1,executions)) > 300
and snap_date_time > sysdate-7
and snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
order by 3 desc;
spool off
!sed -n '1,10 p' tmplongrpt.lst | awk '{n++} {print $1, $2, $3, $4, $5, $6, $7, n}' > tmplongrpt.sql
set lines 80
@rptlongsummary.sql
@tmplongrpt
!SUFFIX=`sed -n -e '1 p' longsummary.txt | sed -e 's/.* for //' -e 's/ ON  /./' -e 's/[	 ][	 ]*/\./g' | sed 's/$/txt/' ` ;export SUFFIX ;mv longsummary.txt longsummary.$SUFFIX
