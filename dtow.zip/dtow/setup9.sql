drop index PM_SNAP_SUMMARY_U1;
create index PM_SNAP_SUMMARY_U1 on PM_SNAP_SUMMARY(sql_hash, plan_hash);
create index PM_SNAP_SUMMARY_N2 on PM_SNAP_SUMMARY(plan_hash);
