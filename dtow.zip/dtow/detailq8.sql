--copyright 2003 Dan Tow, All Rights Reserved 
select decode('&&3', 'INDEX', '@getcnq8'||' '''||'&&5'||''''||' '''||
'&&6'||'''', '@echo1') op,
''''||'&&2'||'''', '&&1', ''''||'&&4'||'''', '&&7', '&&8'
from dual;
