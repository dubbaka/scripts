alter table pm_snapshot add (action varchar2(32));
alter table pm_snapshot modify (event_type varchar2(64));
alter table pm_snap_tmp add (action varchar2(32));
alter table pm_snap_tmp modify (event_type varchar2(64));

