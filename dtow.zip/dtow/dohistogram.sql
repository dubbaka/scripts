set heading off
set feedback off
set lines 160
spool tmpdohist.sql
select 'ANALYZE TABLE '||owner||'.'||table_name||
' COMPUTE STATISTICS FOR COLUMNS '||column_name||' SIZE 254;'
from perf11i.xxpm_histograms;
spool off
spool tmphistresult
@tmpdohist
spool off
quit;
