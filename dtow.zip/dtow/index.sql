select index_name, column_name from all_ind_columns where table_name=
upper('&&1') order by table_owner, index_name, column_position;
