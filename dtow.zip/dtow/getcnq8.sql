select '@getcsq',  '&&3', 
nvl(max(POS#),-1) mpos, nvl(max(o.obj#),-1) mobj, 
&&4, ''''||'&&5'||': ''', '&&6', '&&7'
from
sys.icol$ ic,
sys.obj$ o,
sys.user$ u
where u.NAME = '&&2'
and o.name = '&&1'
and o.type# = 1
and o.OWNER# = u.USER#
and ic.obj# = o.obj#;
