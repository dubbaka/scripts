set heading off
set feedback off
set verify off
set timing off
spool tmpcntr.sql
select 'select count(*) from '||'&&1'||';' from dual;
spool off
set timing on
@tmpcntr
