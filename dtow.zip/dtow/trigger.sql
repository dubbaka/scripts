select trigger_name, trigger_type from dba_triggers where table_name =
upper('&&1');
