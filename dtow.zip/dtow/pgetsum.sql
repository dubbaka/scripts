-- Copyright 2003 Dan Tow, All rights reserved
set timing off
set pagesize 0
set feedback off
set heading off
set verify off
delete from pm_snap_summary;
delete from pm_report_params;
insert into pm_report_params values('&&1', '&&2', '&&3', &&4, 
to_date('&&5','YYYYMMDDHH24MI'), to_date('&&6','YYYYMMDDHH24MI'));
insert into pm_snap_summary
select a.sql_hash, count(*) cnt, to_number(null) from pm_report_params p,
pm_snapshot s,
pm_sqlarea a where a.sql_hash=s.sql_hash_value and a.command_type in (2,3,6,7)
--and schema = 'APPS'
and nvl(schema,'X') != 'PERF11I'
and to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
group by a.sql_hash;
commit;
set num 15
column sumcnt new_value sumcnt
select sum(cnt) sumcnt from pm_snap_summary;
spool tmprpt
select '@prptsql', sql_hash, cnt, &sumcnt
from pm_snap_summary s
order by cnt desc;
spool off
!sed -n '1,30 p' tmprpt.lst | awk '{n++} {print $1, $2, $3, $4, n}' > tmprpt.sql
@prptsum.sql
@tmprpt
!SUFFIX=`sed -n -e '1 p' fullsummary.txt | sed -e 's/.* for //' -e 's/ ON  /./' -e 's/[	 ][	 ]*/\./g' | sed 's/$/txt/' ` ;export SUFFIX ;mv fullsummary.txt fullsummary.$SUFFIX
