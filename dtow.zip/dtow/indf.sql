select index_name, column_expression from all_ind_expressions
where table_name  = upper('&&1') order by index_name, column_position;
