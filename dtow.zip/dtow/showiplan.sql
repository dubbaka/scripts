-- Copyright 2003 Dan Tow, All rights reserved
set timing off
!echo > tmpppout
set echo off
set lines 64
set pages 9999
set heading off
set feedback off
set verify off
set heading off
spool tmpshow.sql
select * from 
(select sql_text from pm_sql where hash_value=&&1 order by piece) t
union all
select * from 
(select sql_text from v$sqltext where hash_value=&&1 
and not exists (select null from pm_sql where hash_value=&&1)
order by address, piece) t ;
spool off
!(tr -d '\n' < tmpshow.sql ;echo)| sed 's/  *; *$/;/' | sed 's/ \. /./g' | sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^)(]*([^)(]*([^)(]*)[^)(]*)[^)(]*)/:xxx1/g'| sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^)(]*([^)(]*)[^)(]*)/:xx1/g'| sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^.)(]*)/:x1/g'| sed 's/:[a-zA-Z0-9_][a-zA-Z0-9_]* *[+-] *[0-9.][0-9.]*/:XY1/g' | sed 's/DD HH24 MI SS/DD:HH24:MI:SS/g' | sed 's/,TO_CHAR/, TO_CHAR/g'| sed 's/,/ ,/g' | tr -s ' ' '\n' | sed '/^([0-9][0-9]*))*$/s/[0-9][0-9]*/&,-14325/'  | grep -v '^ *$' > tmpshow3.sql
!(tr -d '\n' < tmpshow.sql ;echo)| sed 's/  *; *$/;/' | sed 's/ \. /./g' | sed 's/,TO_CHAR/, TO_CHAR/g'| sed 's/,/ ,/g' | tr -s ' ' '\n' | sed '/^([0-9][0-9]*))*$/s/[0-9][0-9]*/&,-14325/'  | grep -v '^ *$' > tmpshow2.sql
!./ppd2
!echo explain plan set statement_id = \'datow\' for > tmpshow.sql
!cat tmpshow3.sql >> tmpshow.sql
!echo ';' >> tmpshow.sql
delete from plan_table where statement_id = 'datow';
spool tmp
@tmpshow.sql
spool off
set timing off
set lines 240
set pages 9999
set feedback off
set verify off
set heading off
set term off
spool tmpplan.out
SELECT LPAD(' ',2*(LEVEL-1))||OPERATION||' '||OPTIONS||' '|| DECODE(OBJECT_INSTANCE, NULL, OBJECT_NAME,
			TO_CHAR(OBJECT_INSTANCE)||'*'|| OBJECT_NAME) PLAN
			FROM PLAN_TABLE
			START WITH ID=0 AND STATEMENT_ID = 'datow'
			CONNECT BY PRIOR ID = PARENT_ID 
                               AND STATEMENT_ID = 'datow'
			ORDER BY ID;
spool off                                                                      
rollback;
!cp tmpppout tmpplanrpt.txt
!sed 's/  *$//' tmpplan.out >> tmpplanrpt.txt
!cat tmpplanrpt.txt
set term on
