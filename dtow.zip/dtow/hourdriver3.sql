exec dtow_perfsnap_psp;
@plansnap
quit
