set feedback on 
column column format a35
set verify off
select idx.name "Index", decode(c.type#,0,LOWER(decode(bitand(c.property, 1),
1, ac.name, c.name)),2,LOWER(decode(bitand(c.property, 1),
1,ac.name, c.name)),12,INITCAP(decode(bitand(c.property, 1),
1,ac.name, c.name)),UPPER(decode(bitand(c.property, 1),
1,ac.name, c.name))) "Column"
from sys.col$ c, sys.obj$ idx, sys.obj$ base, sys.icol$ ic, 
       sys.attrcol$ ac                                                          
where base.obj# = c.obj#                                                        
  and ic.bo# = base.obj#                                                        
  and ic.intcol# = c.intcol#                                                    
  and base.owner# = userenv('SCHEMAID')
  and ic.obj# = idx.obj#                                                        
  and c.obj# = ac.obj#(+)                                                       
  and c.intcol# = ac.intcol#(+)                                                 
  and base.name = upper('&&1')
order by idx.name, ic.pos#;
