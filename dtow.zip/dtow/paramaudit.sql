column name format a33
column value format a45
set pages 0
spool paramsout
select name, value from v$parameter order by name;
select name, value from v$parameter2 order by name;
spool off
