set lines 80
column column_name format a30
column table_owner format a30
column stats format a3
set pages 0
spool indexout
select table_owner, index_name, decode(distinct_keys, null, 'N','Y') stats
 from dba_indexes
order by table_owner, index_name;
spool off
