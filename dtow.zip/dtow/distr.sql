set heading off
set lines 160
set feedback off
set verify off
set timing off
spool tmpdistr.sql
select 'select count(*), count('||'&&1'||'), count(distinct '||'&&1'||
') from '||'&&2'||';' from dual;
spool off
@tmpdistr
set timing on
