select blevel from all_indexes where index_name = upper('&&1');
