column sumdelay new_value sumdelay
column "Delay%" format 999.99
select sum(decode(event_type,'CP',cnt-1,cnt)) sumdelay from pm_delay_snap s
where to_number(to_char(s.snap_date_time,'HH24')) between 8 and 17
and to_char(s.snap_date_time,'DAY') not like 'S%'
and s.snap_date_time > sysdate-7
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
;
select sum(decode(event_type,'CP',cnt-1,cnt))*100/&sumdelay "Delay%",
decode(event_type,
'IN','db file sequential read', 'FT', 'db file scattered read', 'MO',
'SQL*Net more data to client', 'MF', 'SQL*Net more data from client', 'LF',
'latch free', 'QM', 'queue messages',                                          
'BB', 'buffer busy waits', 'LK', 'enqueue', 'FB', 'free buffer waits',
'LS', 'log file sync', 'CP', 'CPU', event_type) event
from pm_delay_snap s 
where to_number(to_char(s.snap_date_time,'HH24')) between 8 and 17
and to_char(s.snap_date_time,'DAY') not like 'S%'
and s.snap_date_time > sysdate-7
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
group by decode(event_type,
'IN','db file sequential read', 'FT', 'db file scattered read', 'MO',          
'SQL*Net more data to client', 'MF', 'SQL*Net more data from client', 'LF',
'latch free', 'QM', 'queue messages',                                          
'BB', 'buffer busy waits', 'LK', 'enqueue', 'FB', 'free buffer waits',
'LS', 'log file sync', 'CP', 'CPU', event_type)
order by 1 desc;
