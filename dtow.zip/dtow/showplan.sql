-- Copyright 2003 Dan Tow, All rights reserved
!echo > tmpppout
set timing off
column operation format a30
column options format a30
column str format a80
column object_name format a30
column object_owner format a30
column oname format a40
column oowner format a30
column oper format a50
set pages 9999
set feedback off
set verify off
set echo off
set heading off
set lines 64
spool tmpshow.sql
select sql_text from dtow_sql where hash_value=&&1 order by piece;
spool off
set lines 360
!(tr -d '\n' < tmpshow.sql ;echo)| sed 's/  *; *$/;/' | sed 's/ \. /./g' | sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^)(]*([^)(]*([^)(]*)[^)(]*)[^)(]*)/:xxx1/g'| sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^)(]*([^)(]*)[^)(]*)/:xx1/g'| sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^.)(]*)/:x1/g'| sed 's/:[a-zA-Z0-9_][a-zA-Z0-9_]* *[+-] *[0-9.][0-9.]*/:XY1/g' | sed 's/DD HH24 MI SS/DD:HH24:MI:SS/g' | sed 's/,TO_CHAR/, TO_CHAR/g'| sed 's/,/ ,/g' | tr -s ' ' '\n' | sed '/^([0-9][0-9]*))*$/s/[0-9][0-9]*/&,-14325/'  | grep -v '^ *$' > tmpshow3.sql
!(tr -d '\n' < tmpshow.sql ;echo)| sed 's/  *; *$/;/' | sed 's/ \. /./g' | sed 's/,TO_CHAR/, TO_CHAR/g'| sed 's/,/ ,/g' | tr -s ' ' '\n' | sed '/^([0-9][0-9]*))*$/s/[0-9][0-9]*/&,-14325/'  | grep -v '^ *$' > tmpshow2.sql
!ppd2
!echo explain plan set statement_id = \'datow\' for > tmpshow.sql
!cat tmpshow3.sql >> tmpshow.sql
!echo ';' >> tmpshow.sql
delete from apps.plan_table where statement_id = 'datow';
insert into apps.plan_table (id, parent_id, statement_id, operation,
options, object_name, object_owner, cost, cardinality)
select distinct id, parent_id, 'datow', operation,
options, object_name, object_owner, cost, cardinality
from dtow_sqlplan where hash_value = &&1 and plan_hash = &&2
;
set term off
spool off
set heading off
spool tmpdet.sql
select '@detailq8', level, ''''||'&&1'||'''', ''''||OPERATION||'''' oper,
substr(''''||rpad(to_char(level),3)||OPERATION||' '||OPTIONS||' '||
decode(OBJECT_INSTANCE, null, OBJECT_NAME,
                              to_char(OBJECT_INSTANCE)||'*'|| OBJECT_NAME)||
                              '''', 1, 80) str,
nvl(substr(OBJECT_NAME, 1, 40),''' ''') oname,
nvl(OBJECT_OWNER, ''' ''') oowner, nvl(to_char(cost),'_'),
nvl(to_char(cardinality),'_')
from apps.plan_table
start with id=0 and statement_id = 'datow'
connect by prior id = parent_id and statement_id = 'datow'
order by id;
spool off
rollback;
spool tmpdet2.sql
@tmpdet
spool off
spool tmpdet3.sql
@tmpdet2
spool off
spool tmpex.out
@tmpdet3
spool off
set term on
set heading on
!grep -v '^$' tmpex.out|sed 's/  *$//' |tee ex.out
!cp tmpppout tmpplanrpt.txt
!cat ex.out >> tmpplanrpt.txt
!cat tmpplanrpt.txt
set term on
