-- Copyright 2003 Dan Tow, All rights reserved
set timing off
set lines 80
set pagesize 0
set feedback off
set heading off
set num 15
set verify off
column sumcnt new_value sumcnt
column snapcnt new_value snapcnt
column appload new_value appload
column "Rank#" format 9999 
column "EstSec/Exec" format 9999999999
column "Executions" format 999999999
column "PhysIO/Exec" format 9999999999
column "LogicalIO/Exec" format 9999999999999
column "Rows/Exec" format 99999999
column "SQL_Hash" format 9999999999
select sum(cnt) sumcnt from pm_snap_summary;
spool tmplongglobal
select '       Long-Running SQL Summary for '||instance_name||' ON  '||
to_char(sysdate,'DD-MON-YYYY HH24:MI') from v$instance;
select ' ' from dual;
select '   Global Summaries:' from dual;
select 'TOTAL Snapshot Count:', count(*) snapcnt,'First Snapshot: '||
to_char(min(snap_date_time),'YYYY/MON/DD-HH24:MI')||'   Last_Snapshot: '||
to_char(max(snap_date_time),'YYYY/MON/DD-HH24:MI')
from pm_snapshot s
where sql_hash_value in (542663648,1387304933,3013821302,2328204476,203690072)
and snap_date_time > sysdate-7
and snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and schema = 'PERF11I';
spool off
set pagesize 9999
set heading off
spool tmplongsql
select 'Long-Running SQL Summary:' from dual;
set heading on
select rank() over (order by 
((600*disk_reads)+buffer_gets)/(60000*greatest(1,executions)) desc) "Rank#",
((600*disk_reads)+buffer_gets)/(60000*greatest(1,executions)) "EstSec/Exec",
executions "Executions", disk_reads/greatest(1,executions) "PhysIO/Exec",
buffer_gets/greatest(1,executions) "LogicalIO/Exec",
rows_processed/greatest(1,executions) "Rows/Exec", SQL_Hash "SQL_Hash"
from pm_sqlarea s
where ((600*disk_reads)+buffer_gets)/(60000*greatest(1,executions)) > 300
and snap_date_time > sysdate-7
and snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
order by 2 desc;
spool off
!mv tmplongglobal.lst longsummary.txt
!sed -n '1,25 p' tmplongsql.lst >> longsummary.txt
