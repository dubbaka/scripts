:
# set up environment
# run with cron entry like:
# 5 * * * * /home/dtow/scripts/o9scr/drivergen.sh > /dev/null
. /u01/app/gemdev11/applmgr/appl/APPSORA.env;CDPATH=.:$ORACLE_HOME:$ORACLE_HOME/appsutil
cd /home/dtow/scripts/o9scr
echo test `date` >> testlog
echo <passwd> | sqlplus dtow@gemprd01 @hourdriver3 > /dev/null
