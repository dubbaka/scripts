set timing off
set lines 80
set pagesize 0
set feedback off
set heading off
set num 15
set verify off
column sumcnt new_value sumcnt
column snapcnt new_value snapcnt
column appload new_value appload
column appload format 999.99 
column profiled format 999.99 
column "Load%" format 999.99 
column "Avg_Delay_Cnt" format 999.99 
column "Schema" format a40
column "TDCase" format a8
select sum(cnt) sumcnt from dtow_snap_summary;
column sumdelay new_value sumdelay
column "Delay%" format 999.99
select sum(decode(event_type,'CP',cnt-1,cnt)) sumdelay from dtow_report_params p,
dtow_delay_snap s
where 
to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and event_type not like '--%'
and s.event_type != 'PL/SQL lock timer'
;
spool tmpglobal
select '       TopSQL Load Summary for '||instance_name||' ON  '||
to_char(sysdate,'DD-MON-YYYY HH24:MI') from v$instance;
select ' ' from dual;
select '   Global Summaries:' from dual;
select /*+ index(s DTOW_SNAPSHOTX_N2) */
'TOTAL Snapshot Count:', count(*) snapcnt,'First Snapshot: '||
to_char(min(snap_date_time),'YYYY/MON/DD-HH24:MI')||'   Last_Snapshot: '||
to_char(max(snap_date_time),'YYYY/MON/DD-HH24:MI')
from dtow_snapshot s, dtow_report_params p
where sql_hash_value in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and schema in ('DTOW','DANTOW');
select /*+ index(s DTOW_SNAPSHOTX_N2) */
'Avg Load/Snapshot:', count(*)/&snapcnt appload
from dtow_report_params p,
dtow_snapshot s
where to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
--and nvl(schema,'X') != 'PERF11I'
and sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and event_type not like '--%'
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI');
--and schema = 'APPS';
select 'Profiled Load%:',
&sumcnt*100/(&snapcnt*&appload) profiled from dual;
set heading on
set pages 9999
select sum(decode(event_type,'CP',cnt-1,cnt))*100/&sumdelay "Delay%",
decode(event_type,
'IN','db file sequential read', 'FT', 'db file scattered read', 'MO',          
'SQL*Net more data to client', 'MF', 'SQL*Net more data from client', 'LF',
'latch free', 'QM', 'queue messages',                                          
'BB', 'buffer busy waits', 'LK', 'enqueue', 'FB', 'free buffer waits',
'LS', 'log file sync', 'CP', 'CPU', event_type) "Event"
from dtow_report_params p,
dtow_delay_snap s 
where to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and event_type not like '--%'
and s.event_type != 'PL/SQL lock timer'
group by decode(event_type,
'IN','db file sequential read', 'FT', 'db file scattered read', 'MO',          
'SQL*Net more data to client', 'MF', 'SQL*Net more data from client', 'LF',
'latch free', 'QM', 'queue messages',
'BB', 'buffer busy waits', 'LK', 'enqueue', 'FB', 'free buffer waits',
'LS', 'log file sync', 'CP', 'CPU', event_type)
order by 1 desc;

select /*+ index(s DTOW_SNAPSHOTX_N2) */
count(*)/&snapcnt "Avg_Delay_Cnt", schema "Schema"
from dtow_report_params p,
dtow_snapshot s
where sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and event_type not like '--%'
group by schema order by 1 desc;
set heading off
select /*+ index(s DTOW_SNAPSHOTX_N2) */
'Average CPU Count/Snap:            ',
count(*)/&snapcnt Avg_Delay_Cnt
from dtow_report_params p,
dtow_snapshot s
where sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and schema is not null
and event_type = 'CP';
select /*+ index(s DTOW_SNAPSHOTX_N2) */
'Average Index I/O Count/Snap:      ',
count(*)/&snapcnt Avg_Delay_Cnt
from dtow_report_params p,
dtow_snapshot s
where sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and schema is not null
and event_type = 'IN';
select /*+ index(s DTOW_SNAPSHOTX_N2) */
'Avg Full Table Scan I/O Count/Snap:',
count(*)/&snapcnt Avg_Delay_Cnt
from dtow_report_params p,
dtow_snapshot s
where sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and schema is not null
and event_type = 'FT';
select /*+ index(s DTOW_SNAPSHOTX_N2) */
'Avg Other Count/Snap:              ',
count(*)/&snapcnt Avg_Delay_Cnt
from dtow_report_params p,
dtow_snapshot s
where sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and event_type not like '--%'
and schema is not null
and event_type not in ('CP','IN','FT');
select '     Breakdowns of Load:' from dual;
set heading on
-- select count(*)*100/(&appload*&snapcnt) "Load%", program
-- from  dtow_snapshot s
-- where to_number(to_char(s.snap_date_time,'HH24')) between 8 and 17
-- and to_char(s.snap_date_time,'DAY') not like 'S%'
-- and schema = 'APPS'
-- group by program order by 1 desc;
select /*+ index(s DTOW_SNAPSHOTX_N2) */
count(*)*100/(&appload*&snapcnt) "Load%", decode(command_type,
2,'INSERT',3,'SELECT',6,'UPDATE',7,'DELETE',47,'PL/SQL',to_number(null),
decode(s.sql_hash_value, 0, 'HASH=0', 'OTHER Non-Captured SQL'),
'OTHER SQL TYPE')
"SQL Command"
from  dtow_report_params p,
dtow_snapshot s, dtow_sqlarea a
where to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
--and schema = 'APPS'
--and nvl(schema,'X') != 'PERF11I'
and sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and a.sql_hash(+)=s.sql_hash_value 
and event_type not like '--%'
group by decode(command_type,
2,'INSERT',3,'SELECT',6,'UPDATE',7,'DELETE',47,'PL/SQL',to_number(null),
decode(s.sql_hash_value, 0, 'HASH=0', 'OTHER Non-Captured SQL'),
'OTHER SQL TYPE')
order by 1 desc;
select /*+ index(s DTOW_SNAPSHOTX_N2) */
count(*)*100/(&appload*&snapcnt) "Load%", module "Module"
from  dtow_report_params p,
dtow_snapshot s
where to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and event_type not like '--%'
--and schema = 'APPS'
--and nvl(schema,'X') != 'PERF11I'
and sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
group by module having count(*)*100/(&appload*&snapcnt) >=0.5 order by 1 desc;
select /*+ index(s DTOW_SNAPSHOTX_N2) */
count(*)*100/(&appload*&snapcnt) "Load%", username "OSUser"
from  dtow_report_params p,
dtow_snapshot s
where to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
--and schema = 'APPS'
--and nvl(schema,'X') != 'PERF11I'
and sql_hash_value not in (3202417217,1937567492,337693849,3540288097,
211469072, 1075220795, 2058280464)
and event_type not like '--%'
group by username having count(*)*100/(&appload*&snapcnt) >=0.5 order by 1 desc;
select /*+ index(s DTOW_SNAPSHOTX_N2) */
count(*) "Excess Count",
to_char(snap_date_time,'YYYY/MON/DD-HH24:MI:SS')
from dtow_report_params p,
dtow_snapshot s 
where to_number(to_char(s.snap_date_time,'HH24')) between p.min_time_of_day
 and p.max_time_of_day
and (nvl(p.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-p.backwards_reach
and s.snap_date_time >= p.start_of_interval
and s.snap_date_time <= p.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
and event_type not like '--%'
group by to_char(snap_date_time,'YYYY/MON/DD-HH24:MI:SS')
having count(*) > 99 order by 1 desc;
spool off
set heading off
spool tmptopsql
select 'Top SQL Load Summary:' from dual;
set heading on
select rank() over (order by cnt desc) "Rank#",
trunc(cnt*1000/&sumcnt)/10 "Load%", sql_hash, cnt, f.reference "TDCase"
from dtow_snap_summary s, dtow_sql_statement_fix f
where s.sql_hash=f.hash_value(+)
order by cnt desc;
spool off
!mv tmpglobal.lst fullsummary.txt
!sed -n '1,30 p' tmptopsql.lst >> fullsummary.txt
