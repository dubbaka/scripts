spool setup_dtow_snaps

drop table dtow_snap_tmp;
drop table dtow_sqlarea_tmp;
drop table dtow_sqlplan_tmp;
drop table dtow_last_snap_tmp;
create global temporary table dtow_snap_tmp on commit preserve rows
        as
        select s.sql_address, s.sql_hash_value,
        decode(wait_time, 0, decode(event,
              'db file sequential read', 'IN', 'db file scattered read', 'FT',
              'SQL*Net more data to client', 'MO', 'latch free', 'LF',
              'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
              'FB', 'log file sync', 'LS', event), 'CP') event_type,
        s.osuser username, s.username schema,
        s.program, s.module, s.audsid
        from v$session s
        where 1=2;

create global temporary table dtow_sqlarea_tmp on commit preserve rows as select hash_value sql_hash, executions,
     greatest(0.00001,sysdate-to_date(first_load_time,'YYYY-MM-DD/HH24:MI:SS'))
        load_duration, disk_reads, buffer_gets, rows_processed, command_type
        from v$sqlarea t
        where 1=2;


create global temporary table dtow_sqlplan_tmp on commit preserve rows as select * from dtow_sqlplan where 1=2;

alter table dtow_sqlarea_tmp add (plan_hash number);

create global temporary table dtow_last_snap_tmp on commit preserve rows as select distinct 
                                   SQL_ADDRESS from dtow_snap_tmp ;

