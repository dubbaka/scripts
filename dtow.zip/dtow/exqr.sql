set timing off
set lines 320
set pages 9999
set feedback off
set verify off
delete from plan_table;
spool ex.out
get &&1
0 explain plan for
/
spool off
set heading off
spool tmpdet.sql
select 
rpad(to_char(level),level, ' ')||OPERATION||' '||OPTIONS||' '||
decode(OBJECT_INSTANCE, null, OBJECT_NAME,
			      to_char(OBJECT_INSTANCE)||'*'|| OBJECT_NAME)||
                              ' c='|| nvl(to_char(cost),'_')||
                              ' r='|| nvl(to_char(cardinality),'_')
			      str
from plan_table
start with id=0
connect by prior id = parent_id
order by id;
spool off
rollback;
