select object_type from dba_objects where object_name = upper('&&1')
and owner=upper('&&2');
