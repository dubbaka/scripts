
@echo1 '2055952395' 1 '1  SELECT STATEMENT  ' 10653221440 _                                                                                                                                                                                                                                                                                                             

@echo1 '2055952395' 2 '2  NESTED LOOPS  ' 5 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID FND_USER' 2 1                                                                                                                                                                                                                                                                                                     

@getcnq8 'FND_USER_U1' 'APPLSYS' '2055952395' 4 '4  INDEX UNIQUE SCAN FND_USER_U1' 1 1                                                                                                                                                                                                                                                                                  

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID BATCHED PER_ALL_PEOPLE_F' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'PER_PEOPLE_F_PK' 'HR' '2055952395' 4 '4  INDEX RANGE SCAN PER_PEOPLE_F_PK' 1 2                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 2 '2  NESTED LOOPS  ' 5 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID FND_USER' 2 1                                                                                                                                                                                                                                                                                                     

@getcnq8 'FND_USER_U1' 'APPLSYS' '2055952395' 4 '4  INDEX UNIQUE SCAN FND_USER_U1' 1 1                                                                                                                                                                                                                                                                                  

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID BATCHED PER_ALL_PEOPLE_F' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'PER_PEOPLE_F_PK' 'HR' '2055952395' 4 '4  INDEX RANGE SCAN PER_PEOPLE_F_PK' 1 2                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 2 '2  NESTED LOOPS  ' 5 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID FND_USER' 2 1                                                                                                                                                                                                                                                                                                     

@getcnq8 'FND_USER_U1' 'APPLSYS' '2055952395' 4 '4  INDEX UNIQUE SCAN FND_USER_U1' 1 1                                                                                                                                                                                                                                                                                  

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID BATCHED PER_ALL_PEOPLE_F' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'PER_PEOPLE_F_PK' 'HR' '2055952395' 4 '4  INDEX RANGE SCAN PER_PEOPLE_F_PK' 1 2                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 2 '2  NESTED LOOPS  ' 5 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID FND_USER' 2 1                                                                                                                                                                                                                                                                                                     

@getcnq8 'FND_USER_U1' 'APPLSYS' '2055952395' 4 '4  INDEX UNIQUE SCAN FND_USER_U1' 1 1                                                                                                                                                                                                                                                                                  

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID BATCHED PER_ALL_PEOPLE_F' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'PER_PEOPLE_F_PK' 'HR' '2055952395' 4 '4  INDEX RANGE SCAN PER_PEOPLE_F_PK' 1 2                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 2 '2  NESTED LOOPS  ' 5 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID FND_USER' 2 1                                                                                                                                                                                                                                                                                                     

@getcnq8 'FND_USER_U1' 'APPLSYS' '2055952395' 4 '4  INDEX UNIQUE SCAN FND_USER_U1' 1 1                                                                                                                                                                                                                                                                                  

@echo1 '2055952395' 3 '3  TABLE ACCESS BY INDEX ROWID BATCHED PER_ALL_PEOPLE_F' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'PER_PEOPLE_F_PK' 'HR' '2055952395' 4 '4  INDEX RANGE SCAN PER_PEOPLE_F_PK' 1 2                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 2 '2  TABLE ACCESS BY INDEX ROWID BATCHED CE_BANK_ACCOUNTS' 2 1                                                                                                                                                                                                                                                                                     

@getcnq8 'CE_BANK_ACCOUNTS_N3' 'CE' '2055952395' 3 '3  INDEX RANGE SCAN CE_BANK_ACCOUNTS_N3' 1 1                                                                                                                                                                                                                                                                        

@echo1 '2055952395' 2 '2  SORT AGGREGATE ' _ 1                                                                                                                                                                                                                                                                                                                          

@echo1 '2055952395' 3 '3  NESTED LOOPS ANTI ' 12 1                                                                                                                                                                                                                                                                                                                      

@echo1 '2055952395' 4 '4  NESTED LOOPS  ' 4 1                                                                                                                                                                                                                                                                                                                           

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 5 '5  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 1 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 5 '5  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N15' 'IBY' '2055952395' 6 '6  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N15' 2 1                                                                                                                                                                                                                                                                     

@echo1 '2055952395' 4 '4  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 8 2                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 5 '5  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 2 6                                                                                                                                                                                                                                                                     

@echo1 '2055952395' 2 '2  SORT AGGREGATE ' _ 1                                                                                                                                                                                                                                                                                                                          

@echo1 '2055952395' 3 '3  FILTER  ' _ _                                                                                                                                                                                                                                                                                                                                 

@echo1 '2055952395' 4 '4  NESTED LOOPS  ' 4 1                                                                                                                                                                                                                                                                                                                           

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 5 '5  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 1 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 5 '5  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N2' 'IBY' '2055952395' 6 '6  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N2' 2 1                                                                                                                                                                                                                                                                       

@echo1 '2055952395' 4 '4  TABLE ACCESS BY INDEX ROWID GL_DAILY_RATES' 3 1                                                                                                                                                                                                                                                                                               

@getcnq8 'GL_DAILY_RATES_U1' 'GL' '2055952395' 5 '5  INDEX UNIQUE SCAN GL_DAILY_RATES_U1' 2 1                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 4 '4  FAST DUAL  ' 2 1                                                                                                                                                                                                                                                                                                                              

@echo1 '2055952395' 4 '4  FAST DUAL  ' 2 1                                                                                                                                                                                                                                                                                                                              

@echo1 '2055952395' 2 '2  SORT GROUP BY ' _ 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 3 '3  NESTED LOOPS ANTI ' 2699839 9                                                                                                                                                                                                                                                                                                                 

@echo1 '2055952395' 4 '4  HASH JOIN ANTI ' 2699658 9                                                                                                                                                                                                                                                                                                                    

@echo1 '2055952395' 5 '5  HASH JOIN OUTER ' 2699646 9                                                                                                                                                                                                                                                                                                                   

@echo1 '2055952395' 6 '6  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 6 9                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N15' 'IBY' '2055952395' 7 '7  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N15' 3 9                                                                                                                                                                                                                                                                     

@echo1 '2055952395' 6 '6  VIEW  ' 2699640 1                                                                                                                                                                                                                                                                                                                             

@echo1 '2055952395' 7 '7  FILTER  ' _ _                                                                                                                                                                                                                                                                                                                                 

@echo1 '2055952395' 8 '8  NESTED LOOPS  ' 9695 167824                                                                                                                                                                                                                                                                                                                   

@echo1 '2055952395' 9 '9  TABLE ACCESS STORAGE FULL IBY_PAYMENTS_ALL' 9656 167824                                                                                                                                                                                                                                                                                       

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 9 '9  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 0 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 8 '8  SORT AGGREGATE ' _ 1                                                                                                                                                                                                                                                                                                                          

@echo1 '2055952395' 9 '9  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 21 3                                                                                                                                                                                                                                                                                    

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 10 '10 INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 3 19                                                                                                                                                                                                                                                                   

@echo1 '2055952395' 5 '5  VIEW  VW_SQ_1' 12 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 6 '6  NESTED LOOPS ANTI ' 12 1                                                                                                                                                                                                                                                                                                                      

@echo1 '2055952395' 7 '7  NESTED LOOPS  ' 4 1                                                                                                                                                                                                                                                                                                                           

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 8 '8  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 1 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 8 '8  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N15' 'IBY' '2055952395' 9 '9  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N15' 2 1                                                                                                                                                                                                                                                                     

@echo1 '2055952395' 7 '7  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 8 2                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 8 '8  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 2 6                                                                                                                                                                                                                                                                     

@echo1 '2055952395' 4 '4  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 20 1                                                                                                                                                                                                                                                                                    

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 5 '5  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 2 19                                                                                                                                                                                                                                                                    

@echo1 '2055952395' 2 '2  SORT AGGREGATE ' _ 1                                                                                                                                                                                                                                                                                                                          

@echo1 '2055952395' 3 '3  FILTER  ' _ _                                                                                                                                                                                                                                                                                                                                 

@echo1 '2055952395' 4 '4  NESTED LOOPS  ' 4 1                                                                                                                                                                                                                                                                                                                           

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 5 '5  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 1 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 5 '5  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N2' 'IBY' '2055952395' 6 '6  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N2' 2 1                                                                                                                                                                                                                                                                       

@echo1 '2055952395' 4 '4  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 21 1                                                                                                                                                                                                                                                                                    

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 5 '5  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 3 19                                                                                                                                                                                                                                                                    

@echo1 '2055952395' 4 '4  NESTED LOOPS ANTI ' 11 1                                                                                                                                                                                                                                                                                                                      

@echo1 '2055952395' 5 '5  NESTED LOOPS  ' 4 1                                                                                                                                                                                                                                                                                                                           

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 6 '6  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 1 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 6 '6  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N2' 'IBY' '2055952395' 7 '7  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N2' 2 1                                                                                                                                                                                                                                                                       

@echo1 '2055952395' 5 '5  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 7 3                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 6 '6  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 2 5                                                                                                                                                                                                                                                                     

@echo1 '2055952395' 2 '2  SORT AGGREGATE ' _ 1                                                                                                                                                                                                                                                                                                                          

@echo1 '2055952395' 3 '3  NESTED LOOPS  ' 8 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 4 '4  NESTED LOOPS  ' 8 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 5 '5  NESTED LOOPS  ' 7 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 6 '6  NESTED LOOPS  ' 6 1                                                                                                                                                                                                                                                                                                                           

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 7 '7  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 1 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 7 '7  TABLE ACCESS BY INDEX ROWID BATCHED IBY_DOCS_PAYABLE_ALL' 5 1                                                                                                                                                                                                                                                                                 

@getcnq8 'IBY_DOCS_PAYABLE_ALL_N2' 'IBY' '2055952395' 8 '8  INDEX RANGE SCAN IBY_DOCS_PAYABLE_ALL_N2' 2 27                                                                                                                                                                                                                                                              

@getcnq8 'AP_INVOICES_U1' 'AP' '2055952395' 6 '6  INDEX UNIQUE SCAN AP_INVOICES_U1' 1 1                                                                                                                                                                                                                                                                                 

@getcnq8 'IBY_PAYMENTS_ALL_U1' 'IBY' '2055952395' 5 '5  INDEX UNIQUE SCAN IBY_PAYMENTS_ALL_U1' 0 1                                                                                                                                                                                                                                                                      

@echo1 '2055952395' 4 '4  TABLE ACCESS BY INDEX ROWID IBY_PAYMENTS_ALL' 1 1                                                                                                                                                                                                                                                                                             

@echo1 '2055952395' 2 '2  SORT AGGREGATE ' _ 1                                                                                                                                                                                                                                                                                                                          

@echo1 '2055952395' 3 '3  FILTER  ' _ _                                                                                                                                                                                                                                                                                                                                 

@echo1 '2055952395' 4 '4  NESTED LOOPS  ' 7 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 5 '5  NESTED LOOPS  ' 7 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 6 '6  NESTED LOOPS  ' 4 1                                                                                                                                                                                                                                                                                                                           

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 7 '7  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 1 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 7 '7  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N15' 'IBY' '2055952395' 8 '8  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N15' 2 1                                                                                                                                                                                                                                                                     

@echo1 '2055952395' 6 '6  TABLE ACCESS BY INDEX ROWID BATCHED IBY_PAYMENTS_ALL' 3 1                                                                                                                                                                                                                                                                                     

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 7 '7  INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 2 1                                                                                                                                                                                                                                                                     

@echo1 '2055952395' 8 '8  SORT GROUP BY NOSORT ' 21 1                                                                                                                                                                                                                                                                                                                   

@echo1 '2055952395' 9 '9  TABLE ACCESS BY INDEX ROWID IBY_PAYMENTS_ALL' 21 3                                                                                                                                                                                                                                                                                            

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 10 '10 INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 3 19                                                                                                                                                                                                                                                                   

@echo1 '2055952395' 7 '7  FAST DUAL  ' 2 1                                                                                                                                                                                                                                                                                                                              

@getcnq8 'IBY_PAY_SERVICE_REQUESTS_U1' 'IBY' '2055952395' 5 '5  INDEX UNIQUE SCAN IBY_PAY_SERVICE_REQUESTS_U1' 0 1                                                                                                                                                                                                                                                      

@echo1 '2055952395' 4 '4  SORT GROUP BY NOSORT ' 21 1                                                                                                                                                                                                                                                                                                                   

@echo1 '2055952395' 9 '9  TABLE ACCESS BY INDEX ROWID IBY_PAYMENTS_ALL' 21 3                                                                                                                                                                                                                                                                                            

@getcnq8 'IBY_PAYMENTS_ALL_N14' 'IBY' '2055952395' 10 '10 INDEX RANGE SCAN IBY_PAYMENTS_ALL_N14' 3 19                                                                                                                                                                                                                                                                   

@echo1 '2055952395' 2 '2  SORT ORDER BY ' 10653221440 2                                                                                                                                                                                                                                                                                                                 

@echo1 '2055952395' 3 '3  FILTER  ' _ _                                                                                                                                                                                                                                                                                                                                 

@echo1 '2055952395' 4 '4  HASH JOIN OUTER ' 10653217533 1103                                                                                                                                                                                                                                                                                                            

@echo1 '2055952395' 5 '5  HASH JOIN  ' 159 1103                                                                                                                                                                                                                                                                                                                         

@echo1 '2055952395' 6 '6  VIEW  VW_SQ_3' 53 6373                                                                                                                                                                                                                                                                                                                        

@echo1 '2055952395' 7 '7  SORT GROUP BY ' 53 6373                                                                                                                                                                                                                                                                                                                       

@echo1 '2055952395' 8 '8  TABLE ACCESS STORAGE FULL XXFB_PAYMENT_BATCH_APPROVAL' 51 6424                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 6 '6  HASH JOIN RIGHT ANTI ' 106 1112                                                                                                                                                                                                                                                                                                               

@echo1 '2055952395' 7 '7  TABLE ACCESS STORAGE FULL XXFB_PAYMENT_BATCH_APPROVAL' 54 494                                                                                                                                                                                                                                                                                 

@echo1 '2055952395' 7 '7  TABLE ACCESS STORAGE FULL XXFB_PAYMENT_BATCH_APPROVAL' 52 1607                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 5 '5  VIEW  XXFB_PAYMENTS_DETAIL_V' 10653217375 6373                                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 6 '6  HASH JOIN  ' 105 6373                                                                                                                                                                                                                                                                                                                         

@echo1 '2055952395' 7 '7  VIEW  VW_SQ_2' 53 6373                                                                                                                                                                                                                                                                                                                        

@echo1 '2055952395' 8 '8  SORT GROUP BY ' 53 6373                                                                                                                                                                                                                                                                                                                       

@echo1 '2055952395' 9 '9  TABLE ACCESS STORAGE FULL XXFB_PAYMENT_BATCH_APPROVAL' 51 6424                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 7 '7  TABLE ACCESS STORAGE FULL XXFB_PAYMENT_BATCH_APPROVAL' 52 6424                                                                                                                                                                                                                                                                                

@echo1 '2055952395' 4 '4  NESTED LOOPS  ' 7 1                                                                                                                                                                                                                                                                                                                           

@echo1 '2055952395' 5 '5  TABLE ACCESS BY INDEX ROWID FND_USER' 2 1                                                                                                                                                                                                                                                                                                     

@getcnq8 'FND_USER_U1' 'APPLSYS' '2055952395' 6 '6  INDEX UNIQUE SCAN FND_USER_U1' 1 1                                                                                                                                                                                                                                                                                  

@echo1 '2055952395' 5 '5  TABLE ACCESS STORAGE FULL FIRST ROWS XXFB_IBY_PAY_BATCH_APPROVERS' 5 1                                                                                                                                                                                                                                                                        
