select table_owner, clustering_factor, distinct_keys, blevel, leaf_blocks,
avg_leaf_blocks_per_key from all_indexes where index_name = upper('&&1');
