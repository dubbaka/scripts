	
	
		
99+


Search

ATTACHMENT
Download
-- Copyright 2003 Dan Tow, All rights reserved
-----------snapsql_sp.sql--------------
--copyright 2003 Dan Tow All rights reserved
--modified to randomize call times and to run 12 snaps over an hour with 
--  a single connection D. Tow 7/10/03
--modified to remove inactive sessions that masquerade as CPU consumers
--  D. Tow 7/17/03
--modified to add collection of request_id data and to eliminate errors when 
--  runs overlap a bit D. Tow 7/22/03
--modified to add collection of action data from v$session, to distinguish 
--  online from batch load and to see the online responsibilities. Also 
-- modified to add SQL collection for delay events beyond just CPU, I/O,
-- and more data to client. - D. Tow 12/15/03
-- modified to add PLAN_HASH_VALUE collection for grouping of related SQL
-- - D. Tow 1/5/04
-- modified to add PLAN_HASH to sqlarea snaps, and to use v$sql in place of 
-- v$sqlarea. Modifications made to get a single clean snapshot from
-- v$sql, since that often has mutliple records for the same SQL, not all
-- of which are useful. Using last_load_time, not first_load_time for duration
-- calculations, because v$sql (and v$sqlarea, for that matter) counts are 
-- since last_load_time, not first_load_time. Collecting fresh v$sql snapshots
-- every week or so, now, when SQL appears in multiple weeks, since stats
-- vary over time, and recent stats are useful, along with some history.
-- new sqlarea snap column last_snap_date_time shows when the data shown
-- were collected, but snap_date_time shows the first time in that one-week 
-- period that that particular SQL statement was snapshotted producing load.
-- Snap_date_time is used to determine when the week is finished and a fresh
-- snapshot is desired. There is only ever one snapshot for a given 
-- sql_hash/plan_hash/inst_id combination. Last_snap_tmp is used to 
-- see which SQL was seen executing during the *previous* snapshot. This in
-- turn is used in the new facility to take one last snapshot *after* SQL 
-- completes, because this is often the only way to get a meaningful snapshot,
-- especially, of v$sql (or v$sqlarea) data, of SQL that only ever executes
-- one time at a time, but that is nonetheless high-load. This also results 
-- in better, less-expensive snapshotting of SQL that executes very many times
-- in a loop, before going idle. Also added new snapshotting of
-- v$sqltext_with_newlines to support easy construction of stored outlines
-- and possibly better reporting of well-formatted SQL.
-- - D. Tow 6/22/05

-- If you already have stats tables from ealier versions, comment out creation 
-- statements below, as needed.

--Be sure to set up PLAN_TABLE, if needed, with $ORACLE_HOME/rdbms/admin/utlxplan.sql

spool setup_dtow_snaps

create table dtow_delay_snap as
select sysdate snap_date_time, 1 cnt, decode(wait_time, 0, decode(event,
'db file sequential read', 'IN', 'db file scattered read', 'FT',
'SQL*Net more data to client', 'MO', 'latch free', 'LF', 'queue messages',
'QM', 'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
'FB', 'log file sync', 'LS', event), 'CP') event_type
from v$session s
where 1=2;

create table dtow_snap_tmp
        as
        select s.sql_address, s.sql_hash_value,
        decode(wait_time, 0, decode(event,
              'db file sequential read', 'IN', 'db file scattered read', 'FT',
              'SQL*Net more data to client', 'MO', 'latch free', 'LF',
              'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
              'FB', 'log file sync', 'LS', event), 'CP') event_type,
        s.osuser username, s.username schema,
        s.program, s.module, s.audsid
        from v$session s
        where 1=2;

create table dtow_sqlarea_tmp as select hash_value sql_hash, executions,
     greatest(0.00001,sysdate-to_date(first_load_time,'YYYY-MM-DD/HH24:MI:SS'))
        load_duration, disk_reads, buffer_gets, rows_processed, command_type
        from v$sqlarea t
        where 1=2;

create table dtow_sqlarea as select t.*, sysdate snap_date_time
from dtow_sqlarea_tmp t;

create index dtow_sqlarea_n1 on dtow_sqlarea(sql_hash);

create table dtow_sql as
        select t.hash_value, t.piece,
        t.sql_text from v$sqltext t
        where 1=2;

create index dtow_sql_n1 on dtow_sql(hash_value, piece);

create table dtow_snapshot as
      select t.sql_hash_value, sysdate snap_date_time, t.event_type, t.username,
        t.schema, t.program, t.module, 1 request_id, 1 prog_id,
        1 app_id, 1 plan_hash
        from dtow_snap_tmp  t, v$sql p
        where t.sql_address=p.address(+);

create index dtow_snapshot_n1 on dtow_snapshot(sql_hash_value, plan_hash);

create index dtow_snapshot_n2 on dtow_snapshot(snap_date_time);

create table dtow_errors (v_label varchar2(500),error_date date);

create table dtow_report_params (min_time_of_day CHAR(2),
max_time_of_day CHAR(2),
exclude_weekend_flag CHAR(1), backwards_reach number,
start_of_interval DATE, end_of_interval DATE);

insert into dtow_report_params values ('00','24','N',100000,
sysdate, sysdate);

create table dtow_snap_summary(sql_hash number, cnt number, plan_hash number);

create index DTOW_SNAP_SUMMARY_U1 on DTOW_SNAP_SUMMARY(sql_hash, plan_hash);

create index DTOW_SNAP_SUMMARY_N2 on DTOW_SNAP_SUMMARY(plan_hash);

create table dtow_sql_statement_fix(hash_value number, reference varchar2(80),
creation_date date, update_date date, notes varchar2(800));

create index dtow_sql_statement_fix_n1 on dtow_sql_statement_fix(hash_value);

create table dtow_sqlplan as select hash_value, 2119953407 plan_hash,
id, parent_id, operation,
options, object_name, object_owner, cost, cardinality from v$sql_plan
where 1=2;

create index dtow_sqlplan_n1 on dtow_sqlplan(plan_hash);

create table dtow_sqlplan_tmp as select * from dtow_sqlplan where 1=2;

create table dtow_sql_plan_comb_tmp(hash_value number,plan_hash number);

create table dtow_sql_plan_comb(hash_value number,plan_hash number,
snap_date_time date);

create unique index dtow_sql_plan_comb_u1
        on dtow_sql_plan_comb(hash_value, plan_hash);


alter table dtow_sqlarea_tmp add (plan_hash number);

alter table dtow_sqlarea add (plan_hash number, last_snap_date_time date,
first_snap_flag CHAR(1), last_snap_flag CHAR(1));

drop index dtow_SQLAREA_N1;

create index dtow_SQLAREA_N1 on dtow_sqlarea(sql_hash, last_snap_flag);
create table dtow_last_snap_tmp as select distinct 
                                   SQL_ADDRESS from dtow_snap_tmp ;

create table dtow_SQLTEXT_W_NEWLINES as select * from dtow_sql
where 1=2;

create index dtow_SQLTEXT_W_NEWLINES_N1 on
dtow_SQLTEXT_W_NEWLINES(hash_value, piece);

grant insert, select on dtow_SQLTEXT_W_NEWLINES to public;

update dtow_sqlarea set last_snap_date_time = snap_date_time,
first_snap_flag = 'Y', last_snap_flag='Y';

commit;

analyze table dtow_sqlarea estimate statistics sample 100000 rows;


--Be sure to create stats on tables/indexes after about a week of data collects.

create or replace procedure dtow_perfsnap_indiv is
v_label varchar2(500);
begin

        v_label := 'deleting tmp data';
        delete from dtow_snap_tmp;
        delete from dtow_sqlarea_tmp;

v_label := 'taking delay snap';
insert into dtow_delay_snap
select sysdate snap_date_time, count(*) cnt, decode(wait_time, 0, decode(event,
'db file sequential read', 'IN', 'db file scattered read', 'FT',
'SQL*Net more data to client', 'MO', 'latch free', 'LF', 'queue messages',
'QM', 'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
'FB', 'log file sync', 'LS', event), decode(s.command,0,'?','CP')) event_type
from v$session s
where s.status = 'ACTIVE'
and decode(wait_time, 0, event, 'CP') not in ('SQL*Net message from client',
'rdbms ipc message', 'smon timer', 'pmon timer', 'pipe get',
'wakeup time manager', 'unread message', 'log file parallel write',
'wait for unread message on broadcast channel','gcs remote message',
'ges remote message')
group by decode(wait_time, 0, decode(event,
'db file sequential read', 'IN', 'db file scattered read', 'FT',
'SQL*Net more data to client', 'MO', 'latch free', 'LF', 'queue messages',
'QM', 'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
'FB', 'log file sync', 'LS', event), decode(s.command,0,'?','CP'));

        v_label := 'insert data from session wait';
        insert into dtow_snap_tmp (sql_address, sql_hash_value, event_type,
        username, schema, program, module, audsid)
        select s.sql_address, s.sql_hash_value,
        decode(wait_time, 0, decode(event,
              'db file sequential read', 'IN', 'db file scattered read', 'FT',
              'SQL*Net more data to client', 'MO', 'latch free', 'LF',
              'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
           'FB', 'log file sync', 'LS', event), decode(s.command,0,'?','CP')),
        s.osuser , s.username,
        s.program, s.module, s.audsid
        from v$session s
        where s.status='ACTIVE'
        and decode(wait_time, 0, event, 'CP') not in
           ('SQL*Net message from client', 'rdbms ipc message', 'smon timer',
            'pmon timer', 'pipe get', 'wakeup time manager', 'unread message',
            'log file parallel write', 'queue messages',
'wait for unread message on broadcast channel','gcs remote message',
'ges remote message');

        v_label := 'insert data into  dtow_sqlarea_tmp';
        insert into dtow_sqlarea_tmp (
         sql_hash, executions, load_duration, disk_reads, buffer_gets,
         rows_processed, command_type, plan_hash)
        select hash_value, executions,
     greatest(0.00001,sysdate-to_date(last_load_time,'YYYY-MM-DD/HH24:MI:SS'))
        load_duration, disk_reads, buffer_gets, rows_processed, command_type,
        plan_hash_value
        from (select p2.hash_value, p2.executions,
                     p2.last_load_time, p2.disk_reads, p2.buffer_gets,
                     p2.rows_processed, p2.command_type, p2.plan_hash_value,
rank () OVER (PARTITION BY p2.address order by p2.plan_hash_value desc,
executions desc, p2.child_number asc) rnk
                                from (select distinct sql_address
                                      from dtow_snap_tmp)  t2, v$sql p2
                                where t2.sql_address=p2.address ) iv
        where rnk=1;

        v_label := 'update  dtow_sqlarea';

        update /*+ rule */
        dtow_sqlarea a set (executions, load_duration, disk_reads, buffer_gets,
        rows_processed, command_type, last_snap_date_time)
        = (select executions,
        load_duration,
        disk_reads, buffer_gets, rows_processed, command_type, sysdate
        from dtow_sqlarea_tmp t
        where a.sql_hash=t.sql_hash
          AND a.plan_hash = t.plan_hash
          AND ROWNUM = 1)
        where a.last_snap_flag='Y'
          AND (a.sql_hash, a.plan_hash ) IN (
              SELECT DISTINCT t.sql_hash, t.plan_hash
                         FROM dtow_sqlarea a2, dtow_sqlarea_tmp t
                        WHERE t.executions >= a2.executions
                          AND t.sql_hash = a2.sql_hash
                          AND t.plan_hash = a2.plan_hash
                          AND a2.last_snap_flag='Y'
                          AND a2.executions < 10
                          AND a2.snap_date_time > sysdate - 7);

update /*+ rule */ dtow_sqlarea a set last_snap_flag='N'
     where last_snap_flag = 'Y'
       AND (a.sql_hash, a.plan_hash ) IN (
              SELECT DISTINCT t.sql_hash, t.plan_hash
                         FROM dtow_sqlarea a2, dtow_sqlarea_tmp t
                        WHERE t.sql_hash = a2.sql_hash
                          AND t.plan_hash = a2.plan_hash
                          AND a2.last_snap_flag='Y'
                          AND a2.snap_date_time <= sysdate - 7);

        v_label := 'insert data into dtow_sqlarea';
        insert into dtow_sqlarea
        (sql_hash, executions, load_duration, disk_reads,
         buffer_gets, rows_processed, command_type, snap_date_time,
         plan_hash, last_snap_date_time, first_snap_flag, last_snap_flag)
        select T.SQL_HASH,T.EXECUTIONS,T.LOAD_DURATION,
               T.DISK_READS, T.BUFFER_GETS,T.ROWS_PROCESSED,T.COMMAND_TYPE,
               sysdate, plan_hash, sysdate,'Y','Y'
          from dtow_sqlarea_tmp t
        where not exists (select null from dtow_sqlarea a
        where a.sql_hash=t.sql_hash
          and a.plan_hash=t.plan_hash );

        insert into dtow_sqlarea
        (sql_hash, executions, load_duration, disk_reads,
         buffer_gets, rows_processed, command_type, snap_date_time,
         plan_hash, last_snap_date_time, first_snap_flag, last_snap_flag)
        select T.SQL_HASH,T.EXECUTIONS,T.LOAD_DURATION,
               T.DISK_READS, T.BUFFER_GETS,T.ROWS_PROCESSED,T.COMMAND_TYPE,
               sysdate, plan_hash, sysdate,'N','Y'
          from dtow_sqlarea_tmp t
        where not exists (select null from dtow_sqlarea a
        where a.sql_hash=t.sql_hash
          and a.plan_hash=t.plan_hash
          and last_snap_flag='Y');

        v_label := 'insert last-snap data into dtow_sqlarea_tmp';
        delete from dtow_sqlarea_tmp;
        insert into dtow_sqlarea_tmp
        (sql_hash, executions, load_duration, disk_reads, buffer_gets,
         rows_processed, command_type, plan_hash)
        select hash_value, executions,
     greatest(0.00001,sysdate-to_date(last_load_time,'YYYY-MM-DD/HH24:MI:SS'))
        load_duration, disk_reads, buffer_gets, rows_processed, command_type,
        plan_hash_value
        from (select p2.hash_value, p2.executions,
                     p2.last_load_time, p2.disk_reads, p2.buffer_gets,
                     p2.rows_processed, p2.command_type, p2.plan_hash_value,
rank () OVER (PARTITION BY p2.address order by p2.plan_hash_value desc,
executions desc, p2.child_number asc) rnk
                                from (select distinct l.sql_address
                                      from dtow_last_snap_tmp l,
                                           dtow_snap_tmp t
                                     where l.sql_address=t.sql_address(+)
                                       and t.sql_address is null /*not exists*/
                                      ) t2, v$sql p2
                                where t2.sql_address=p2.address ) iv
        where rnk=1;

        v_label := 'last-snap update of dtow_sqlarea';
        update /*+ rule */
        dtow_sqlarea a set (executions, load_duration, disk_reads, buffer_gets,
        rows_processed, command_type, last_snap_date_time)
        = (select executions,
        load_duration,
        disk_reads, buffer_gets, rows_processed, command_type, sysdate
        from dtow_sqlarea_tmp t
        where a.sql_hash=t.sql_hash
          AND a.plan_hash = t.plan_hash
          AND ROWNUM = 1)
        where a.last_snap_flag='Y'
          AND (a.sql_hash, a.plan_hash ) IN (
              SELECT DISTINCT t.sql_hash, t.plan_hash
                         FROM dtow_sqlarea a2, dtow_sqlarea_tmp t
                        WHERE t.sql_hash = a2.sql_hash
                          AND t.plan_hash = a2.plan_hash
                          AND a2.last_snap_flag='Y'
                          AND a2.snap_date_time > sysdate - 7);

update /*+ rule */ dtow_sqlarea a set last_snap_flag='N'
     where last_snap_flag = 'Y'
       AND (a.sql_hash, a.plan_hash ) IN (
              SELECT DISTINCT t.sql_hash, t.plan_hash
                         FROM dtow_sqlarea a2, dtow_sqlarea_tmp t
                        WHERE t.sql_hash = a2.sql_hash
                          AND t.plan_hash = a2.plan_hash
                          AND a2.last_snap_flag='Y'
                          AND a2.snap_date_time <= sysdate - 7);

        v_label := 'last-snap insert data into dtow_sqlarea';
        insert into dtow_sqlarea
        (sql_hash, executions, load_duration, disk_reads,
         buffer_gets, rows_processed, command_type, snap_date_time,
         plan_hash, last_snap_date_time, first_snap_flag, last_snap_flag)
        select T.SQL_HASH,T.EXECUTIONS,T.LOAD_DURATION,
               T.DISK_READS, T.BUFFER_GETS,T.ROWS_PROCESSED,T.COMMAND_TYPE,
               sysdate, plan_hash, sysdate,'Y','Y'
          from dtow_sqlarea_tmp t
        where not exists (select null from dtow_sqlarea a
        where a.sql_hash=t.sql_hash
          and a.plan_hash=t.plan_hash );

        insert into dtow_sqlarea
        (sql_hash, executions, load_duration, disk_reads,
         buffer_gets, rows_processed, command_type, snap_date_time,
         plan_hash, last_snap_date_time, first_snap_flag, last_snap_flag)
        select T.SQL_HASH,T.EXECUTIONS,T.LOAD_DURATION,
               T.DISK_READS, T.BUFFER_GETS,T.ROWS_PROCESSED,T.COMMAND_TYPE,
               sysdate, plan_hash, sysdate,'N','Y'
          from dtow_sqlarea_tmp t
        where not exists (select null from dtow_sqlarea a
        where a.sql_hash=t.sql_hash
          and a.plan_hash=t.plan_hash
          and a.last_snap_flag='Y' );

        v_label := 'insert data into dtow_sql and dtow_sqltext_w_newlines';
        insert into dtow_sql (hash_value, piece, sql_text)
        select /*+ push_subq leading(st) use_hash(st t) */ distinct t.hash_value, t.piece,
        t.sql_text from v$sqltext t, dtow_snap_tmp st
        where t.hash_value=st.sql_hash_value
        and t.address=st.sql_address
        and not exists
        (select /*+ index(s DTOW_SQL_N1) */
                null from dtow_sql s where s.hash_value = st.sql_hash_value
                                     and s.piece=0);

        INSERT INTO dtow_sqltext_w_newlines
        SELECT /*+ push_subq leading(st) use_hash(st t) */ DISTINCT
           t.hash_value, t.piece, t.sql_text
              FROM v$sqltext_with_newlines t, dtow_snap_tmp st
             WHERE t.hash_value = st.sql_hash_value
               AND t.address = st.sql_address
               AND NOT EXISTS (
                        SELECT /*+ index(s DTOW_SQLTEXT_W_NEWLINES_N1) */ NULL
                          FROM dtow_sqltext_w_newlines s
                         WHERE s.hash_value = st.sql_hash_value
                           AND s.piece = 0);

        insert into dtow_sql_plan_comb_tmp
        select distinct t.sql_hash_value, p.plan_hash_value
        from dtow_snap_tmp  t, (select /*+ ordered */ t2.sql_address address,
                                       max(p2.plan_hash_value)
                                                        plan_hash_value
                                from dtow_snap_tmp  t2, v$sql p2
                                where t2.sql_address=p2.address
                                and p2.plan_hash_value != 0
                                group by  t2.sql_address) p
        where t.sql_address=p.address
        and not exists (select null from dtow_sql_plan_comb c
                        where c.hash_value = t.sql_hash_value
                          and c.plan_hash  = p.plan_hash_value);

        v_label := 'insert data into snapshot';
        insert into dtow_snapshot (sql_hash_value, snap_date_time,
        event_type, username, schema, program, module, request_id,
        prog_id, app_id, plan_hash)
        select t.sql_hash_value, sysdate, t.event_type, t.username,
        t.schema, t.program, t.module, null, null, null,
        p.plan_hash_value
        from dtow_snap_tmp  t, (select t2.sql_address address,
                                       nvl(max(p2.plan_hash_value),0)
                                                        plan_hash_value
                                from dtow_snap_tmp  t2, v$sql p2
                                where t2.sql_address=p2.address(+)
                                and p2.plan_hash_value(+) != 0
                                group by  t2.sql_address) p
        where t.sql_address=p.address(+);

v_label := 'storing last-snap addresses for the next snapshot on this instance';

delete from dtow_last_snap_tmp t;

insert into dtow_last_snap_tmp (sql_address)
       select distinct t.SQL_ADDRESS from dtow_snap_tmp t;

        commit;
        exception
        when others then
                v_label := v_label||'  SQL-Err '||substr(sqlerrm,1,200);
                insert into dtow_errors values (v_label,sysdate);
                commit;
                raise_application_error(-20000,v_label);
end;
/
show err


create or replace procedure dtow_perfsnap_psp is                                
v_cnt number;                                                                   
v_start_t date;                                                                 
v_sleep_sec number;                                                             
begin                                                                           
v_cnt:=0;                                                                       
select sysdate into v_start_t from dual;                                        
while v_cnt < 12 loop                                                           
select                                                                          
trunc((v_start_t-sysdate)*86400+(300*v_cnt)+mod(abs(sum(sql_hash_value)),300))  
into v_sleep_sec                                                                
from v$session;                                                                 
v_cnt:=v_cnt+1;                                                                 
DBMS_LOCK.SLEEP(v_sleep_sec);                                                   
IF v_sleep_sec > 0 THEN                                                         
dtow_perfsnap_indiv();                                                          
END IF;                                                                         
end loop;                                                                       
end;                                                                            
/                                                                               
show err

spool off


