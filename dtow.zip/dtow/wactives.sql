set pages 999
select s.sid, audsid, seq#, SQL_HASH_VALUE, OSUSER,
PROCESS, MACHINE, PROGRAM, TYPE, USERNAME, r.request_id,
p.concurrent_program_name,
decode(wait_time, 0, event,
         decode(s.command, 0, decode(s.status, 'INACTIVE', '???','?'),
                              decode(s.status, 'INACTIVE', '??', 'CPU'))) delay
from v$session_wait w, v$session s, fnd_concurrent_requests r,
fnd_concurrent_programs p
where s.sid=w.sid and s.sid = &&1
and event not in ('pmon timer', 'smon timer')
and s.audsid = r.oracle_session_id(+)
and r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID(+)
and r.PROGRAM_APPLICATION_ID = p.application_id(+)
order by 1 asc;
