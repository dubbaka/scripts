select * from v$instance;
