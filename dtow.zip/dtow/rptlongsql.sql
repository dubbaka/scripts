-- Copyright 2003 Dan Tow, All rights reserved
set heading off
set lines 80
spool tmplongrpt
select ' ' from dual;
select '      RankID='||to_char(&&7,99999999),
'     Est. Sec/Exec='||to_char(&&2,999999999),
' Executions='||to_char(&&6,99999999),
'PhysIO/Exec='||to_char(&&3,999999999),
' LogicalIO/Exec='||to_char(&&4,999999999999),
' Rows/Exec='||to_char(&&5,999999999), '  SQL_Hash='||to_char(&&1,9999999999)
from dual;
select 'First Seen Date= '||min(s.snap_date_time),
'  SQLArea Snapshot Date= '||max(a.snap_date_time),
'Last Seen Date=  '||max(s.snap_date_time), ' Observed Total Runtime= '||
to_char(count(*)*307,99999999)
from pm_snapshot s, pm_sqlarea a where a.sql_hash=&&1
and s.sql_hash_value=&&1;
set heading on
select count(*) cnt, max(request_id) req_id, username, schema,
module||program module_program
from pm_snapshot s where sql_hash_value=&&1
and to_number(to_char(s.snap_date_time,'HH24')) between 8 and 17
and to_char(s.snap_date_time,'DAY') not like 'S%'
and s.snap_date_time > sysdate-7
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
group by username, schema, module||program ;
set heading off
spool off
@showplan &&1
!cat tmplongrpt.lst tmpplanrpt.txt >> longsummary.txt
