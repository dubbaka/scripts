select lpad('.',&&4,'.')||'&&5'||
'?'||
' c='||'&&6'||', R='||'&&7' from dual where -1='&&3' 
union all
select lpad('.',&&4,'.')||'&&5'||
decode(c1.type#, 2, lower(c1.NAME), 12, initcap(c1.name), upper(c1.name))||
' c='||'&&6'||', R='||'&&7'
from 
sys.col$   c1,
sys.icol$ ic1
where     ic1.obj# = '&&3'
and       ic1.pos# =   1
and        c1.obj# = ic1.bo#
and        c1.col# = ic1.col#
and &&2 =   1
union all
select lpad('.',&&4,'.')||'&&5'||
decode(c1.type#, 2, lower(c1.NAME), 12, initcap(c1.name), upper(c1.name))||','||
decode(c2.type#, 2, lower(c2.NAME), 12, initcap(c2.name), upper(c2.name))||
' c='||'&&6'||', R='||'&&7'
from
sys.col$    c1
,sys.icol$ ic1
,sys.col$   c2
,sys.icol$ ic2
where      ic1.obj# = '&&3'
and        ic1.pos# =   1
and         c1.obj# = ic1.bo#
and         c1.col# = ic1.col#
and        ic2.obj# = '&&3'
and        ic2.pos# =   2
and         c2.obj# = ic2.bo#
and         c2.col# = ic2.col#
and &&2 =    2
union all
select lpad('.',&&4,'.')||'&&5'||
decode(c1.type#, 2, lower(c1.NAME), 12, initcap(c1.name), upper(c1.name))||','||
decode(c2.type#, 2, lower(c2.NAME), 12, initcap(c2.name), upper(c2.name))||','||
decode(c3.type#, 2, lower(c3.NAME), 12, initcap(c3.name), upper(c3.name))||
' c='||'&&6'||', R='||'&&7'
from
sys.col$    c1
,sys.icol$ ic1
,sys.col$   c2
,sys.icol$ ic2
,sys.col$   c3
,sys.icol$ ic3
where      ic1.obj# = '&&3'
and        ic1.pos# =   1
and         c1.obj# = ic1.bo#
and         c1.col# = ic1.col#
and        ic2.obj# = '&&3'
and        ic2.pos# =   2
and         c2.obj# = ic2.bo#
and         c2.col# = ic2.col#
and        ic3.obj# = '&&3'
and        ic3.pos# =   3
and         c3.obj# = ic3.bo#
and         c3.col# = ic3.col#
and &&2 =    3
union all
select lpad('.',&&4,'.')||'&&5'||
decode(c1.type#, 2, lower(c1.NAME), 12, initcap(c1.name), upper(c1.name))||','||
decode(c2.type#, 2, lower(c2.NAME), 12, initcap(c2.name), upper(c2.name))||','||
decode(c3.type#, 2, lower(c3.NAME), 12, initcap(c3.name), upper(c3.name))||','||
decode(c4.type#, 2, lower(c4.NAME), 12, initcap(c4.name), upper(c4.name))||
' c='||'&&6'||', R='||'&&7'
from
sys.col$    c1
,sys.icol$ ic1
,sys.col$   c2
,sys.icol$ ic2
,sys.col$   c3
,sys.icol$ ic3
,sys.col$   c4
,sys.icol$ ic4
where      ic1.obj# = '&&3'
and        ic1.pos# =   1
and         c1.obj# = ic1.bo#
and         c1.col# = ic1.col#
and        ic2.obj# = '&&3'
and        ic2.pos# =   2
and         c2.obj# = ic2.bo#
and         c2.col# = ic2.col#
and        ic3.obj# = '&&3'
and        ic3.pos# =   3
and         c3.obj# = ic3.bo#
and         c3.col# = ic3.col#
and        ic4.obj# = '&&3'
and        ic4.pos# =   4
and         c4.obj# = ic4.bo#
and         c4.col# = ic4.col#
and &&2 =    4
union all
select lpad('.',&&4,'.')||'&&5'||
decode(c1.type#, 2, lower(c1.NAME), 12, initcap(c1.name), upper(c1.name))||','||
decode(c2.type#, 2, lower(c2.NAME), 12, initcap(c2.name), upper(c2.name))||','||
decode(c3.type#, 2, lower(c3.NAME), 12, initcap(c3.name), upper(c3.name))||','||
decode(c4.type#, 2, lower(c4.NAME), 12, initcap(c4.name), upper(c4.name))||','||
decode(c5.type#, 2, lower(c5.NAME), 12, initcap(c5.name), upper(c5.name))||
' c='||'&&6'||', R='||'&&7'
from
sys.col$    c1
,sys.icol$ ic1
,sys.col$   c2
,sys.icol$ ic2
,sys.col$   c3
,sys.icol$ ic3
,sys.col$   c4
,sys.icol$ ic4
,sys.col$   c5
,sys.icol$ ic5
where      ic1.obj# = '&&3'
and        ic1.pos# =   1
and         c1.obj# = ic1.bo#
and         c1.col# = ic1.col#
and        ic2.obj# = '&&3'
and        ic2.pos# =   2
and         c2.obj# = ic2.bo#
and         c2.col# = ic2.col#
and        ic3.obj# = '&&3'
and        ic3.pos# =   3
and         c3.obj# = ic3.bo#
and         c3.col# = ic3.col#
and        ic4.obj# = '&&3'
and        ic4.pos# =   4
and         c4.obj# = ic4.bo#
and         c4.col# = ic4.col#
and        ic5.obj# = '&&3'
and        ic5.pos# =   5
and         c5.obj# = ic5.bo#
and         c5.col# = ic5.col#
and &&2 >=   5
;
