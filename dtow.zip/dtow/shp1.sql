-- Copyright 2003 Dan Tow, All rights reserved
set echo off
set lines 64
set pages 9999
set heading off
set feedback off
set verify off
set heading off
spool tmpshp.sql
select sql_text from pm_sql where hash_value=&&1 order by piece;
spool off
