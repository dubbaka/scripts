set pages 0
set heading off
set lines 160
set feedback off
spool makesyns.sql
select 'create synonym '||synonym_name||' for apps.'||synonym_name||';'
from dba_synonyms where owner = 'APPS';
select 'create synonym '||table_name||' for apps.'||table_name||';'
from dba_tables where owner = 'APPS';
select 'create synonym '||view_name||' for apps.'||view_name||';'
from dba_views where owner = 'APPS';
spool off
spool makesyns.out
@makesyns
spool off
