select CONCURRENT_PROGRAM_NAME , 
a.APPLICATION_SHORT_NAME
from fnd_application a, fnd_concurrent_programs p,
fnd_concurrent_requests r 
where r.request_id=&&1
and r.PROGRAM_APPLICATION_ID=p.application_id
and a.APPLICATION_ID=p.application_id
and r.CONCURRENT_PROGRAM_ID=p.CONCURRENT_PROGRAM_ID;
