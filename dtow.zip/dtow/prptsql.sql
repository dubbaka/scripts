-- Copyright 2003 Dan Tow, All rights reserved
set heading off
column username format a8
column schema format a6
column module_program format a55
column "Conc_Prog/App" format a30
column cnt format 9999
column req_id format 99999999
set lines 80
spool tmprpt
select ' ' from dual;
select 'RankID='||&&4, 'Weight%='||trunc(&&2*1000/&&3)/10,
'Weight='|| &&2, 'SQL_Hash='||&&1 from dual;
select 'Executions='||executions||
' Executions/Day='||trunc(executions*10/greatest(load_duration,0.001))/10||
' RuntimeEstHrs/Hour='||trunc((disk_reads+(buffer_gets/600))/greatest(1,
load_duration*86400))/100,
'Rows/Exec='||
trunc(rows_processed*10/greatest(1,executions))/10||
' I/Os/Exec='||trunc(disk_reads*10/greatest(1,executions))/10||
' Logical I/Os/Exec='||trunc(buffer_gets*10/greatest(1,executions))/10
from pm_sqlarea where sql_hash=&&1;
set lines 120
set heading on
select count(*) cnt, max(s.request_id) req_id,
decode(r.request_id, null, ' ',
p.CONCURRENT_PROGRAM_NAME || '/'||a.APPLICATION_SHORT_NAME) "Conc_Prog/App",
username, schema,
module||program module_program, sref.reference "TDCase"
from pm_report_params pa, pm_snapshot s, fnd_application a,
fnd_concurrent_programs p, fnd_concurrent_requests r, pm_sql_statement_fix sref
where r.request_id(+)=s.request_id
and s.sql_hash_value=sref.hash_value(+)
and r.PROGRAM_APPLICATION_ID=p.application_id(+)
and a.APPLICATION_ID(+)=p.application_id
and r.CONCURRENT_PROGRAM_ID=p.CONCURRENT_PROGRAM_ID(+)
and s.sql_hash_value=&&1 
and to_number(to_char(s.snap_date_time,'HH24')) between pa.min_time_of_day
 and pa.max_time_of_day
and (nvl(pa.exclude_weekend_flag,'N')!='Y'
     OR to_char(s.snap_date_time,'DAY') not like 'S%')
and s.snap_date_time > sysdate-pa.backwards_reach
and s.snap_date_time >= pa.start_of_interval
and s.snap_date_time <= pa.end_of_interval
and s.snap_date_time > to_date('2003/07/17 16:27','YYYY/MM/DD HH24:MI')
group by username, schema, module||program, 
decode(r.request_id, null, ' ',
p.CONCURRENT_PROGRAM_NAME || '/'||a.APPLICATION_SHORT_NAME), sref.reference;
set heading off
set lines 80
spool off
@showplan &&1
!cat tmprpt.lst tmpplanrpt.txt >> fullsummary.txt
