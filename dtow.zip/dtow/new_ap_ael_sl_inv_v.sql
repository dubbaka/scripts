CREATE OR REPLACE VIEW dtow_ap_ael_sl_inv_v (
   application_id,
   set_of_books_id,
   org_id,
   trx_class,
   trx_class_name,
   trx_type_name,
   trx_type_c,
   trx_number_c,
   trx_number_displayed,
   comments,
   doc_sequence_id,
   doc_sequence_name,
   doc_sequence_value,
   accounted_cr,
   accounted_dr,
   accounting_date,
   acct_line_type,
   acct_line_type_name,
   aeh_id,
   ael_id,
   ael_table,
   ae_line_reference,
   code_combination_id,
   currency_code,
   currency_conversion_date,
   currency_conversion_rate,
   currency_conversion_type,
   currency_user_conversion_type,
   entered_cr,
   entered_dr,
   gl_transfer_status,
   gl_transfer_status_name,
   transfer_status_detail_name,
   source_id,
   source_table,
   tax_code,
   third_party_type,
   third_party_id,
   third_party_number,
   third_party_name,
   third_party_sub_id,
   third_party_sub_name,
   trx_date,
   trx_hdr_id,
   trx_hdr_table,
   je_category,
   user_je_category_name,
   last_update_date,
   last_updated_by,
   creation_date,
   created_by,
   last_update_login,
   request_id,
   program_application_id,
   program_id,
   program_update_date,
   trx_line_number,
   trx_line_type,
   trx_line_type_name,
   accounting_event_number,
   accounting_event_type,
   accounting_event_type_name,
   accounting_line_number,
   aeh_accounting_error_code,
   aeh_accounting_error_name,
   ael_accounting_error_code,
   ael_accounting_error_name,
   trx_hdr_currency,
   po_order_number,
   po_order_release_num,
   rcv_receipt_num,
segment1,
segment2,
segment3,
segment4,
segment5,
segment6,
chart_of_accounts_id
)
AS
   SELECT 200 application_id, aeh.set_of_books_id set_of_books_id,
          aeh.org_id org_id, 'INV' trx_class, l8.displayed_field
                trx_class_name,
          l1.displayed_field trx_type_name,
          i.invoice_type_lookup_code trx_type_c, i.invoice_num trx_number_c,
          i.invoice_num trx_number_displayed, ael.description comments,
          ael.subledger_doc_sequence_id doc_sequence_id,
          fd.NAME doc_sequence_name,
          ael.subledger_doc_sequence_value doc_sequence_value,
          ael.accounted_cr accounted_cr, ael.accounted_dr accounted_dr,
          aeh.accounting_date accounting_date,
          ael.ae_line_type_code acct_line_type,
          l3.displayed_field acct_line_type_name, aeh.ae_header_id aeh_id,
          ael.ae_line_id ael_id, 'APID' ael_table,
          DECODE (
             ael.source_table,
             'AP_INVOICES',    l10.displayed_field
                            || ' '
                            || ae.event_number
                            || ', '
                            || l11.displayed_field
                            || ' '
                            || ael.ae_line_number
                            || ', '
                            || l8.displayed_field
                            || ' '
                            || i.invoice_num,
                l10.displayed_field
             || ' '
             || ae.event_number
             || ', '
             || l11.displayed_field
             || ' '
             || ael.ae_line_number
             || ', '
             || l12.displayed_field
             || ' '
             || d.distribution_line_number
          ) ae_line_reference,
          ael.code_combination_id code_combination_id,
          ael.currency_code currency_code,
          ael.currency_conversion_date currency_conversion_date,
          ael.currency_conversion_rate currency_conversion_rate,
          ael.currency_conversion_type currency_conversion_type,
          glct.user_conversion_type currency_user_conversion_type,
          ael.entered_cr entered_cr, ael.entered_dr entered_dr,
          aeh.gl_transfer_flag gl_transfer_status,
          l4.displayed_field gl_transfer_status_name,
          l9.displayed_field transfer_status_detail_name,
          ael.source_id source_id, ael.source_table source_table,
          AT.NAME tax_code, 'SUPPLIER' third_party_type,
          ael.third_party_id third_party_id, v.segment1 third_party_number,
          v.vendor_name third_party_name,
          ael.third_party_sub_id third_party_sub_id,
          vs.vendor_site_code third_party_sub_name, i.invoice_date trx_date,
          i.invoice_id trx_hdr_id, 'API' trx_hdr_table,
          aeh.ae_category je_category,
          jc.user_je_category_name user_je_category_name,
          ael.last_update_date last_update_date,
          ael.last_updated_by last_updated_by, ael.creation_date creation_date,
          ael.created_by created_by, ael.last_update_login last_update_login,
          ael.request_id request_id,
          ael.program_application_id program_application_id,
          ael.program_id program_id,
          ael.program_update_date program_update_date,
/*---------------------------------------------------------------*/ /* AP Invoice Specific columns */ /*---------------------------------------------------------------*/
          d.distribution_line_number trx_line_number,
          d.line_type_lookup_code trx_line_type,
          l2.displayed_field trx_line_type_name,
          ae.event_number accounting_event_number,
          ae.event_type_code accounting_event_type,
          l5.displayed_field accounting_event_type_name,
          ael.ae_line_number accounting_line_number,
          aeh.accounting_error_code aeh_accounting_error_code,
          l6.displayed_field aeh_accounting_error_name,
          ael.accounting_error_code ael_accounting_error_code,
          l7.displayed_field ael_accounting_error_name,
          i.invoice_currency_code trx_hdr_currency,
          ph.segment1 po_order_number, pr.release_num po_order_release_num,
          rsh.receipt_num rcv_receipt_num,
cc.segment1,
cc.segment2,
cc.segment3,
cc.segment4,
cc.segment5,
cc.segment6,
cc.chart_of_accounts_id
     FROM gl_code_combinations cc,
          ap_accounting_events ae,
          ap_ae_headers aeh,
          ap_ae_lines ael,
          ap_invoice_distributions d,
          ap_invoices i,
          po_vendor_sites vs,
          po_vendors v,
          rcv_shipment_headers rsh,
          po_releases pr,
          po_headers ph,
          po_distributions pd,
          rcv_transactions rct,
          gl_daily_conversion_types glct,
          fnd_document_sequences fd,
          gl_je_categories jc,
          ap_lookup_codes l1,
          ap_tax_codes AT,
          ap_lookup_codes l2,
          ap_lookup_codes l3,
          ap_lookup_codes l4,
          ap_lookup_codes l5,
          ap_lookup_codes l6,
          ap_lookup_codes l7,
          ap_lookup_codes l8,
          ap_lookup_codes l9,
          ap_lookup_codes l10,
          ap_lookup_codes l11,
          ap_lookup_codes l12
    WHERE l2.lookup_code(+) = d.line_type_lookup_code
      AND cc.code_combination_id=ael.code_combination_id
      AND l2.lookup_type(+) = 'INVOICE DISTRIBUTION TYPE'
      AND l3.lookup_code = ael.ae_line_type_code
      AND l3.lookup_type = 'AE LINE TYPE'
      AND l4.lookup_code =    aeh.gl_transfer_flag
                           || ''
      AND l4.lookup_type = 'POSTING STATUS'
      AND l5.lookup_code = ae.event_type_code
      AND l5.lookup_type = 'EVENT TYPE'
      AND l6.lookup_code(+) = aeh.accounting_error_code
      AND l6.lookup_type(+) = 'ACCOUNTING ERROR TYPE'
      AND l7.lookup_code(+) = ael.accounting_error_code
      AND l7.lookup_type(+) = 'ACCOUNTING ERROR TYPE'
      AND l8.lookup_code = 'Invoices'
      AND l8.lookup_type = 'POSTING CATEGORY'
      AND l9.lookup_code(+) = ael.gl_transfer_error_code
      AND l9.lookup_type(+) = 'POSTING EXCEPTIONS'
      AND l10.lookup_code = 'EVENT'
      AND l10.lookup_type = 'VIEW_ACCOUNTING'
      AND l11.lookup_code = 'LINE'
      AND l11.lookup_type = 'VIEW_ACCOUNTING'
      AND l12.lookup_code = 'DIST_LINE_NUM'
      AND l12.lookup_type = 'VIEW_ACCOUNTING'
      AND AT.tax_id(+) = ael.tax_code_id
      AND jc.je_category_name = aeh.ae_category
      AND rsh.shipment_header_id(+) = rct.shipment_header_id
      AND d.rcv_transaction_id = rct.transaction_id(+)
      AND pr.po_release_id(+) = pd.po_release_id
      AND ph.po_header_id(+) = pd.po_header_id
      AND pd.po_distribution_id(+) = d.po_distribution_id
      AND ael.currency_conversion_type = glct.conversion_type(+)
      AND ael.subledger_doc_sequence_id = fd.doc_sequence_id(+)
      AND ael.third_party_sub_id = vs.vendor_site_id
      AND ael.third_party_id = v.vendor_id
      AND l1.lookup_code = i.invoice_type_lookup_code
      AND l1.lookup_type = 'INVOICE TYPE'
      AND ae.accounting_event_id = aeh.accounting_event_id
      AND i.invoice_id = ae.source_id
      AND ae.source_table = 'AP_INVOICES'
      AND aeh.ae_header_id = ael.ae_header_id
      AND DECODE (
             ael.source_table,
             'AP_INVOICE_DISTRIBUTIONS', ael.source_id,
             NULL
          ) = d.invoice_distribution_id(+)
