-- Copyright 2003 Dan Tow, All rights reserved
!echo > tmpppout
set echo off
set lines 64
set pages 9999
set heading off
set feedback off
set verify off
set heading off
!(tr -d '\n' < tmpshow.sql ;echo)| sed 's/  *; *$/;/' | sed 's/ \. /./g' | sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^)(]*([^)(]*([^)(]*)[^)(]*)[^)(]*)/:xxx1/g'| sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^)(]*([^)(]*)[^)(]*)/:xx1/g'| sed 's/[a-zA-Z0-9_][a-zA-Z0-9_]*(:[^)(]*)/:x1/g'| sed 's/:[a-zA-Z0-9_][a-zA-Z0-9_]* *[+-] *[0-9.][0-9.]*/:XY1/g' | sed 's/DD HH24 MI SS/DD:HH24:MI:SS/g' | sed 's/,TO_CHAR/, TO_CHAR/g'| sed 's/,/ ,/g' | tr -s ' ' '\n' | sed '/^([0-9][0-9]*))*$/s/[0-9][0-9]*/&,-14325/'  | grep -v '^ *$' > tmpshow3.sql
!(tr -d '\n' < tmpshow.sql ;echo)| sed 's/  *; *$/;/' | sed 's/ \. /./g' | sed 's/,TO_CHAR/, TO_CHAR/g'| sed 's/,/ ,/g' | tr -s ' ' '\n' | sed '/^([0-9][0-9]*))*$/s/[0-9][0-9]*/&,-14325/'  | grep -v '^ *$' > tmpshow2.sql
!./ppd2
!cat tmpshow3.sql > tmpshow.sql
