-- Copyright 2003 Dan Tow, All rights reserved
set heading off
column username format a8
column schema format a6
column module_program format a48
column "Conc_Prog/App" format a30
column cnt format 9999
column req_id format 99999999
set lines 80
spool tmpsqlhash
select count(*)||' distinct SQL hashes for this plan hash.'
 from dtow_snap_summary where plan_hash=&&1;
set heading on
select cnt, sql_hash from dtow_snap_summary where plan_hash=&&1
order by cnt desc, sql_hash asc;
spool off
set heading off
!sed -n '1,15 p' tmpsqlhash.lst > sqlhashlist.txt
!sed -n '6 p' sqlhashlist.txt | awk '{print "@rptsql9", $2, "&&1 &&2 &&3 &&4"}' > tmprptsql9.sql
spool tmprpt1
select ' ' from dual;
select 'RankID='||&&4, 'Weight%='||trunc(&&2*1000/&&3)/10,
'Weight='|| &&2, 'Plan_Hash='||&&1 from dual;
spool off
@tmprptsql9
!cat tmprpt1.lst tmprpt2.lst sqlhashlist.txt tmprpt3.lst tmpplanrpt.txt >> fullsummary.txt
