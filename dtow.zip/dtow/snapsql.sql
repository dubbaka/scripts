--copyright 2003 Dan Tow All rights reserved
delete from pm_snap_tmp;
insert into pm_delay_snap 
select sysdate snap_date_time, count(*) cnt, decode(wait_time, 0, decode(event,
'db file sequential read', 'IN', 'db file scattered read', 'FT',
'SQL*Net more data to client', 'MO', 'latch free', 'LF', 'queue messages',
'QM', 'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
'FB', 'log file sync', 'LS', event), 'CP') event_type
from v$session_wait w,  v$session s
where s.sid=w.sid
and s.status = 'ACTIVE'
and decode(wait_time, 0, event, 'CP') not in ('SQL*Net message from client',
'rdbms ipc message', 'smon timer', 'pmon timer', 'pipe get',
'wakeup time manager', 'unread message', 'log file parallel write')
group by decode(wait_time, 0, decode(event,
'db file sequential read', 'IN', 'db file scattered read', 'FT',
'SQL*Net more data to client', 'MO', 'latch free', 'LF', 'queue messages',
'QM', 'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
'FB', 'log file sync', 'LS', event), 'CP') 
order by 1 desc;
insert into pm_snap_tmp select s.sql_address, s.sql_hash_value, 
decode(w.wait_time, 0, decode(w.event, 'db file scattered read', 'FT',
'db file sequential read',
'IN','SQL*Net more data to client','MO','XX'), 'CP'), s.osuser , s.username,
s.program, s.module, s.audsid
from v$session s, v$session_wait w 
where w.sid=s.sid 
and s.status='ACTIVE'
and (w.wait_time!=0 or w.event in ('db file scattered read',
'db file sequential read',
'SQL*Net more data to client'));
delete from pm_sqlarea_tmp;
insert into pm_sqlarea_tmp select distinct hash_value, executions,
greatest(0.00001,sysdate-to_date(first_load_time,'YYYY-MM-DD/HH24:MI:SS'))
load_duration, disk_reads,
buffer_gets, rows_processed, command_type
from v$sqlarea t
where (t.hash_value, t.address) in (select st.sql_hash_value,st.sql_address
from pm_snap_tmp st);
update /*+ rule */
pm_sqlarea a set (executions, load_duration, disk_reads, buffer_gets,
rows_processed, command_type, snap_date_time) = (select executions,
load_duration, disk_reads, buffer_gets,
rows_processed, command_type, sysdate
from pm_sqlarea_tmp t
where a.sql_hash=t.sql_hash and rownum=1)
where a.sql_hash in (select distinct t.sql_hash from pm_sqlarea a2,
pm_sqlarea_tmp t
where t.executions >= a2.executions
and t.sql_hash = a2.sql_hash);
insert into pm_sqlarea select t.*, sysdate from pm_sqlarea_tmp t
where not exists (select null from pm_sqlarea a
where a.sql_hash=t.sql_hash);
insert into pm_sql select distinct t.hash_value, t.piece,
t.sql_text from v$sqltext t, pm_snap_tmp st
where t.hash_value=st.sql_hash_value
and t.address=st.sql_address
and not exists 
(select null from pm_sql s where s.hash_value = st.sql_hash_value
                             and s.piece=0);
insert into pm_snapshot select sql_hash_value, sysdate, event_type, username,
schema, program, module, r.request_id, r.CONCURRENT_PROGRAM_ID,
r.PROGRAM_APPLICATION_ID
from pm_snap_tmp t, apps.fnd_concurrent_requests r
where t.audsid=r.oracle_session_id(+);
commit;
!sleep 307
