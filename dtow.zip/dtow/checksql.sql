--checksql.sql
select * from pm_sql_statement_fix where hash_value = &&1;
