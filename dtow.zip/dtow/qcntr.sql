select num_rows from all_tables where table_name = upper('&&1');
