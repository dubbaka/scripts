create table xxpm_histograms(table_name varchar2(30),column_name varchar2(30),
owner varchar2(30), bucket_cnt number);
grant select on xxpm_histograms to public;
insert into xxpm_histograms values ('AP_AE_HEADERS_ALL','GL_TRANSFER_RUN_ID',
'AP',254);
commit;
