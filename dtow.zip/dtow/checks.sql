select event_type, count(*)                                                    
from pm_snapshot where sql_hash_value =
&&1 group by event_type;
