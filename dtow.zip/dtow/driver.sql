-- Copyright 2003 Dan Tow, All rights reserved
!sed -n '1,30 p' tmprpt.lst | awk '{n++} {print $1, $2, $3, $4, n}' > tmprpt.sql
