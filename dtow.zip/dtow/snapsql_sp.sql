-- Copyright 2003 Dan Tow, All rights reserved
-----------snapsql_sp.sql--------------
--copyright 2003 Dan Tow All rights reserved
--modified to add truncate and convert them to procedure  c. kim 7/9/03
--modified to add latch event c. kim 7/10/03 
--modified to randomize call times and to run 12 snaps over an hour with 
--  a single connection D. Tow 7/10/03
--modified to remove inactive sessions that masquerade as CPU consumers
--  D. Tow 7/17/03
--modified to add collection of request_id data and to eliminate errors when 
--  runs overlap a bit D. Tow 7/22/03
--modified to add collection of action data from v$session, to distinguish 
--  online from batch load and to see the online responsibilities. Also 
-- modified to add SQL collection for delay events beyond just CPU, I/O,
-- and more data to client. - D. Tow 12/15/03

alter table pm_snapshot add (action varchar2(32));
alter table pm_snapshot modify (event_type varchar2(64));
alter table pm_snap_tmp add (action varchar2(32));
alter table pm_snap_tmp modify (event_type varchar2(64));

create or replace procedure perfsnap_psp is
v_cnt number;
v_start_t date;
v_sleep_sec number;
begin
v_cnt:=0;
select sysdate into v_start_t from dual;
while v_cnt < 12 loop
select 
trunc((v_start_t-sysdate)*86400+(300*v_cnt)+mod(abs(value),300))
into v_sleep_sec
from v$sysstat where statistic#=9;
v_cnt:=v_cnt+1;
DBMS_LOCK.SLEEP(v_sleep_sec);
perfsnap_indiv();
end loop;
end;
/
create or replace procedure perfsnap_indiv is
v_label	varchar2(500);
begin
	v_label := 'deleting tmp data';
	delete from pm_snap_tmp;
	delete from pm_sqlarea_tmp;

insert into pm_delay_snap 
select sysdate snap_date_time, count(*) cnt, decode(wait_time, 0, decode(event,
'db file sequential read', 'IN', 'db file scattered read', 'FT',
'SQL*Net more data to client', 'MO', 'latch free', 'LF', 'queue messages',
'QM', 'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
'FB', 'log file sync', 'LS', event), 'CP') event_type
from v$session_wait w, v$session s
where s.sid=w.sid
and s.status = 'ACTIVE'
and decode(wait_time, 0, event, 'CP') not in ('SQL*Net message from client',
'rdbms ipc message', 'smon timer', 'pmon timer', 'pipe get',
'wakeup time manager', 'unread message', 'log file parallel write')
group by decode(wait_time, 0, decode(event,
'db file sequential read', 'IN', 'db file scattered read', 'FT',
'SQL*Net more data to client', 'MO', 'latch free', 'LF', 'queue messages',
'QM', 'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
'FB', 'log file sync', 'LS', event), 'CP'); 

	v_label := 'insert data from session wait';
	insert into pm_snap_tmp (sql_address, sql_hash_value, event_type,
        username, schema, program, module, audsid, action) 
        select s.sql_address, s.sql_hash_value,
        decode(wait_time, 0, decode(event,
              'db file sequential read', 'IN', 'db file scattered read', 'FT',
              'SQL*Net more data to client', 'MO', 'latch free', 'LF',
              'buffer busy waits', 'BB', 'enqueue', 'LK', 'free buffer waits',
              'FB', 'log file sync', 'LS', event), 'CP'),
        s.osuser , s.username,
	s.program, s.module, s.audsid, s.action
	from v$session s, v$session_wait w
	where w.sid=s.sid
        and s.status='ACTIVE'
        and decode(wait_time, 0, event, 'CP') not in
           ('SQL*Net message from client', 'rdbms ipc message', 'smon timer',
            'pmon timer', 'pipe get', 'wakeup time manager', 'unread message',
            'log file parallel write', 'queue messages');

	v_label := 'insert data into  pm_sqlarea_tmp';
	insert into pm_sqlarea_tmp select distinct hash_value, executions,
     greatest(0.00001,sysdate-to_date(first_load_time,'YYYY-MM-DD/HH24:MI:SS'))
	load_duration, disk_reads, buffer_gets, rows_processed, command_type
	from v$sqlarea t
	where (t.hash_value, t.address)
               in (select st.sql_hash_value,st.sql_address
	       from pm_snap_tmp st);

	v_label := 'update  pm_sqlarea';
	update /*+ rule */
	pm_sqlarea a set (executions, load_duration, disk_reads, buffer_gets,
	rows_processed, command_type, snap_date_time) = (select executions,
        load_duration, 
	disk_reads, buffer_gets, rows_processed, command_type, sysdate
	from pm_sqlarea_tmp t
	where a.sql_hash=t.sql_hash and rownum=1)
	where a.sql_hash in (   select distinct t.sql_hash 
				from pm_sqlarea a2,
				pm_sqlarea_tmp t
				where t.executions >= a2.executions
				and t.sql_hash = a2.sql_hash);

	v_label := 'insert data into pm_sqlarea';
        insert into pm_sqlarea select t.*, sysdate from pm_sqlarea_tmp t
	where not exists (select null from pm_sqlarea a
	where a.sql_hash=t.sql_hash);

	v_label := 'insert data into pm_sql';
	insert into pm_sql (hash_value, piece, sql_text)
        select distinct t.hash_value, t.piece,
	t.sql_text from v$sqltext t, pm_snap_tmp st
	where t.hash_value=st.sql_hash_value
	and t.address=st.sql_address
	and not exists
	(select null from pm_sql s where s.hash_value = st.sql_hash_value
                                     and s.piece=0);

	v_label := 'insert data into snapshot';
	insert into pm_snapshot (sql_hash_value, snap_date_time,
        event_type, username, schema, program, module, request_id,
        prog_id, app_id, action)
        select sql_hash_value, sysdate, event_type, username,
	schema, program, module, r.request_id, r.CONCURRENT_PROGRAM_ID,
        r.PROGRAM_APPLICATION_ID, t.action
	from pm_snap_tmp  t, apps.fnd_concurrent_requests r
        where t.audsid=r.oracle_session_id(+);

	commit;
	exception 
	when others then
		v_label := v_label||'  SQL-Err '||substr(sqlerrm,1,200);
		insert into pm_errors values (error_id_s.nextval,v_label,sysdate);
		commit;
		raise_application_error(-20000,v_label);
end;
/
show err
