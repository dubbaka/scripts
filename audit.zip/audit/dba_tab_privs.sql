col grantee format a40
col owner format a20
col table_name format a50
col GRANTOR format a20
col privilege format a20
set lines 200 pages 200
select * from DBA_TAB_PRIVS order by grantee;
exit
