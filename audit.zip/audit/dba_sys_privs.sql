col grantee format a40
col privilege format a50
set lines 200 pages 200
select * from DBA_sys_PRIVS order by grantee;
exit
