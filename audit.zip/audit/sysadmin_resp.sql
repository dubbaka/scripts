col responsibility_name format a50
col user_name format a20
col end_date format a20
set lines 200 pages 200
SELECT distinct fu.user_name, frt.RESPONSIBILITY_NAME, furg.end_date
FROM
         apps.fnd_user_resp_groups furg,
         apps.FND_RESPONSIBILITY fr,
         apps.fnd_responsibility_tl frt,
         apps.fnd_user fu
WHERE fu.user_id = furg.user_id
AND   furg.responsibility_id = fr.RESPONSIBILITY_ID
AND   frt.responsibility_id = fr.RESPONSIBILITY_ID
AND   frt.RESPONSIBILITY_NAME like 'System Administrator'
ORDER BY 1;
exit
