col user_name format a35
col creation_date format a30
col description format a50
set linesize 300 pages 200
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
select username,created from dba_users where creation_date like '%2017%';
exit
