set lines 200 pages 200
col user_concurrent_program_name format a80
select distinct user_concurrent_program_name, CREATION_DATE from apps.fnd_concurrent_programs_tl where CREATION_DATE like '%2017%';
exit
