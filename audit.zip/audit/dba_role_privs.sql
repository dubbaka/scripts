col grantee format a40
col GRANTED_ROLE format a40
col privilege format a20
set lines 200 pages 200
select * from DBA_role_PRIVS order by grantee;
exit
