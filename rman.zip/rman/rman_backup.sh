#!/bin/bash
################################################################################
#
# Author : Rajesh Gunda
# Usage:   $ /net/dba/fbmon/bin/rman/rman_backup.sh <full/incr> <retention_period>
#
# History:
#
# Date                  Who                     Vesion          Details
# ----------            --------                --------        -------------
# 04/19/2016           rajeshgunda               1.0             Initial draft
#
#################################################################################
Set_Env()
{
wdir="/net/dba/fbmon"
logdir=$wdir/log/rman
TSTMP="`date +%Y%m%d_%H%M`"
HOSTNAME=$(hostname -a)
logfile="$logdir/${dbname}_${HOSTNAME}_rman_$backuptype_${TSTMP}.log"
purge_logfile=$logdir/rman_purge_${db_name}_${TSTMP}.log
lockfile="$logdir/${dbname}_${HOSTNAME}_rman_$backuptype.lck"
gridhome="/u01/app/12.1.0.2/grid"
NOTIFY="rajeshgunda@fb.com,rajendra@fb.com"
backup_mount=/mnt/rman_isi_backup/$dbname/rman
TS2=$(date "+%m-%d-%Y")
DB_TAG=$(echo TAG_DB_FULL_${TSTMP})
BACKUP_COMMENT_ID=INC_0_${DB_TAG}
PURGE_COMMENT_ID=PURGE_${TSTMP}
purge_logfile=$logdir/rman_purge_${db_name}_${ts}.log
echo "[$TSTMP]:[$dbname]:[rman]:[INFO]:Script started" | tee -a $logfile
# Below condition is to make sure parallel run of same script is not executed
if [  -f $lockfile ] 
then
 echo "[$TSTMP]:[$dbname]:[rman]:[ERROR]:Lockfile $lockfile found...Another rman job is running..." | tee -a $logfile
 exit 1
else
 echo "[$TSTMP]:[$dbname]:[rman]:[ERROR]:Lockfile $lockfile is placed" | tee -a $logfile
 touch $lockfile
fi
export ORACLE_SID=$(grep ^${db_name} /etc/oratab |grep -iv Agent |awk -F":" '{print $1}')
export ORACLE_HOME=$(grep ^${db_name} /etc/oratab |grep -iv Agent |awk -F":" '{print $2}')
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"
# Sourcing database environment
source /usr/local/bin/dbenv ${ORACLE_SID} 1>/dev/null 2>&1
# Validating the environment variables
if [ "${ORACLE_HOME} " == " " ]
then
 echo "[$TSTMP]:[$dbname]:[rman]:[ERROR]:Failed to source $dbname environment" | tee -a $logfile
 remove_lock
 exit 1
fi
}

validations()
{
if [ ! -d $wdir ]
then
 echo "[$TSTMP]:[$HOSTNAME-$dbname]:[rman]:[ERROR]:rman script directory $wdir is missing" | tee -a $logfile
 remove_lock
 exit 1
fi
if [ ! -d /net/dba/fbmon/log/rman ]
then
 echo "[$TSTMP]:[$HOSTNAME-$dbname]:[rman]:[ERROR]:rman log directory $logdir is missing" | tee -a $logfile
 remove_lock
 exit 1
fi
if [ ! -d ${backup_mount} ]
then
 echo "[$TSTMP]:[$HOSTNAME-$dbname]:[rman]:[ERROR]:rman backup mount ${backup_mount} for $dbname is missing" | tee -a $logfile
 remove_lock
 exit 1
else
 mkdir -p 
fi
}

remove_lock()
{
echo "[$TSTMP]:[$dbname]:[rman]:[ERROR]:Removed $lockfile" | tee -a $logfile
rm -f $lockfile
}

run_backup()
{
if [ $( echo $backuptype | tr [A-Z] [a-z] ) == "full" ]
then
 ltype=0
else
 ltype=1
fi
echo "[$TSTMP]:[$dbname]:[rman]:[INFO]:Starting RMAN $backuptype.." | tee -a $logfile
rman target / <<EOF > $logfile
set echo on
run {
SET COMMAND ID TO '${BACKUP_COMMENT_ID}';
backup INCREMENTAL LEVEL $ltype  database  TAG = '${DB_TAG}'  section size = 64G filesperset 1 plus archivelog TAG = '${DB_TAG}';
backup  as copy current controlfile format '${backup_mount}/c-%I-%s_%p.rman';
}
EOF
}

validate_backup()
{
sqlplus  -s '/as sysdba' << EOF >> ${logfile}
set pages 30 lines 234
col INPUT_BYTES_DISPLAY form a20
col OUTPUT_BYTES_DISPLAY form a20
col INPUT_BYTES_PER_SEC_DISPLAY form a30
col OUTPUT_BYTES_PER_SEC_DISPLAY form a30
col TIME_TAKEN_DISPLAY form a20
select COMMAND_ID,INPUT_TYPE,STATUS,INPUT_BYTES_DISPLAY,OUTPUT_BYTES_DISPLAY,COMPRESSION_RATIO,INPUT_BYTES_PER_SEC_DISPLAY,OUTPUT_BYTES_PER_SEC_DISPLAY,TIME_TAKEN_DISPLAY from v\$rman_backup_job_details
where command_id='${BACKUP_COMMENT_ID}';
EOF
let  err_cnt1=$(grep -E "^(RMAN-|ORA-)"  $logfile|grep -v grep |wc -l)
let  err_cnt2=$(grep -E "Recovery Manager complete"  $logfile |grep -v grep | wc -l)
let  err_cnt3=$(grep -E "(COMPLETED)"  $logfile |grep -v -E "(grep|ERRORS|WARNINGS)" |wc -l)
 if [ err_cnt1 -eq 0 ] && [ $err_cnt2 -eq 1 ] && [ $err_cnt3 == 1 ]
 then
  tail -50 $logfile |mail -s "[$TSTMP]:[$dbname]:[rman]:[INFO]:FULL backup completed successfully" $NOTIFY
  purge_archives
 else
  tail -50 ${purge_logfile} |mail -s "[$TSTMP]:[$dbname]:[rman]:[CRITICAL]:RMAN $backuptype FAILED..Check logs for more details!!!" $NOTIFY
  echo "$dbname@$HOSTNAME RMAN $backuptype failed..check logs for more details" | mail -s "[$TSTMP]:[$dbname]:[rman]:[CRITICAL]:RMAN $backuptype FAILED..Check logs for more details!!!" $NOTIFY2  
 fi
}

purge_archives()
{
echo "[$TSTMP]:[$dbname]:[rman]:[INFO]:Starting archive purge" | tee -a $logfile
$ORACLE_HOME/bin/rman target / <<EOF > ${purge_logfile}
set echo on
run {
SET COMMAND ID TO '${PURGE_COMMENT_ID}';
crosscheck backup ;
delete noprompt backupset completed before "to_date('${TS2}','MM-DD-YYYY')-${retention}";
}
EOF
${ORACLE_HOME}/bin/sqlplus  -s '/as sysdba' << EOF >> ${purge_logfile}
set echo on
set pages 30 lines 234
col INPUT_BYTES_DISPLAY form a20
col OUTPUT_BYTES_DISPLAY form a20
col INPUT_BYTES_PER_SEC_DISPLAY form a30
col OUTPUT_BYTES_PER_SEC_DISPLAY form a30
col TIME_TAKEN_DISPLAY form a20
select COMMAND_ID,INPUT_TYPE,STATUS,INPUT_BYTES_DISPLAY,OUTPUT_BYTES_DISPLAY,COMPRESSION_RATIO,INPUT_BYTES_PER_SEC_DISPLAY,OUTPUT_BYTES_PER_SEC_DISPLAY,TIME_TAKEN_DISPLAY from v\$rman_backup_job_details
where command_id='${PURGE_COMMENT_ID}';
EOF
let  err_cnt1=$(grep -E "^(RMAN-|ORA-|EXPIRED)" ${purge_logfile}  |grep -v grep | wc -l)
let  err_cnt2=$(grep -E "Recovery Manager complete"  ${purge_logfile} |grep -v grep | wc -l)
 if [ $err_cnt1 -eq 0 ] && [ err_cnt2 == 1 ]
 then
  tail -50 ${purge_logfile} |mail -s "[$TSTMP]:[$dbname]:[rman]:[INFO]: Archive Purge completed successfully" $NOTIFY
 else
  tail -50 ${purge_logfile} |mail -s "[$TSTMP]:[$dbname]:[rman]:[CRITICAL]:Archive purge has errors!!!" $NOTIFY
  echo "$dbname@$HOSTNAME archive purge failed..check logs for more details" | mail -s "[$TSTMP]:[$dbname]:[rman]:[CRITICAL]:Archive purge has errors!!!" $NOTIFY2
 fi
}


######## MAIN #######
script_name=$0
(( $# != 3 )) && { echo "USAGE: $script_name <DB name> <full/incr> <retention_period>"; exit 1; }
dbname=$1
backuptype=$2
retention=$3

# Source variables
Set_Env
# Check all required directories are mounted and have available permissions.
validations
# Below loop checks on all cluster nodes if any backup job is already running.
for chost in $( $gridhome/bin/olsnodes )
do
 rman_running_check=$( ssh $chost "ps -fu oracle|grep `basename $script_name`|grep -w $dbname|grep -v grep|grep -v '/bin/sh -c'|wc -l" )
 if [ ${rman_running_check} -gt 0 ]
 then
  echo "[$TSTMP]:[$dbname]:[rman]:[ERROR]:rman backup already running on $chost...Exiting script" | tee -a $logfile
  mail -s "[$TSTMP]:[$dbname]:[rman]:[CRITICAL]:$db_name RMAN is running ...RMAN backup cannot start!!!"  it-omg-dba-pager@fb.com it-dba@fb.com < /dev/null
  exit 1;
 fi
done
# Execute rman backup based on the parameters passed
run_backup
# Validates log files for any errors and communicate support accordingly
validate_backup
# Remove the lockfile
remove_lock
