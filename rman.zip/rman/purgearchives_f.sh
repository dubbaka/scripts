#!/bin/sh
############################################################################
# Name          : rman_arch_purge.sh
# Version       : 1.0
# Date          : 08-Dec-2015
# Author        : Rajesh Gunda
# Functionality : Purge archive log files.
#############################################################################

(( $# != 2 )) && { echo "USAGE:  rman_arch_purge.sh <db_name> <retention> "; exit; }

db_name=$1
RETENTION_HRS=$2

MAIL_LIST=it-dba@fb.com
PAGER_MAIL_LIST=it-omg-dba-pager@fb.com

hn=$(hostname -a)
ts=`date "+%m%d%Y_%H%M"`
TS2=`date "+%m-%d-%Y"`
LOG_FILE=/net/dba/fbmon/log/rman/purge_arch_purge_${db_name}_${ts}.log

export ORACLE_SID=$(grep ^${db_name} /etc/oratab |grep -iv Agent |awk -F":" '{print $1}')
export ORACLE_HOME=$(grep ^${db_name} /etc/oratab |grep -iv Agent |awk -F":" '{print $2}')
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"

if [ -f /usr/local/bin/dbenv ]
then
        . /usr/local/bin/dbenv ${ORACLE_SID}
else
        export PATH=$PATH:/usr/local/bin
        export ORACLE_SID=${ORACLE_SID}
        export ORAENV_ASK=NO
        . oraenv
fi

rman target /  << EOF  > ${LOG_FILE}
set echo on;
sql 'alter session set NLS_DATE_FORMAT="DD-MON-YYYY HH24:MI:SS"';
DELETE NOPROMPT force ARCHIVELOG ALL completed before 'SYSDATE-${RETENTION_HRS}/24';
exit;
EOF

let  err_cnt1=$(grep -E "^(RMAN-|ORA-)"  ${LOG_FILE}|grep -v grep |wc -l)
let  err_cnt2=$(grep -E "Recovery Manager complete"  ${LOG_FILE} |grep -v grep | wc -l)
if (( err_cnt1 == 0 )) && (( err_cnt2 == 1 ))  ; then
  echo  "Arch Backup completed sucessfully" > /net/dba/fbmon/log/rman/${db_name}_${ts}_purgearchives.log 
else
    tail -50  ${LOG_FILE} |mail -s "--[CRITICAL]: ${db_name}@$hn  Archive  purge has errors!!!"  ${MAIL_LIST}
fi
