#!/bin/bash
set -x
##############################################
(( $# != 2 )) && { echo "USAGE:  rman_full.sh <db_name>  <retention> "; exit; }
db_name=$1
retention=$2
##############################################


####
####   check if there is another RMAN backup running on the database.  If so this backup will not run.
####


rman_check_running=/tmp/rman_full_${db_name}
cat /dev/null > $rman_check_running

for nn in $(/u01/app/grid/12.1/bin/olsnodes)
do
   ssh $nn "ps -fu oracle|grep rman_full.sh|grep -w $db_name|grep -v grep|grep -v '/bin/sh -c'"  >> $rman_check_running
done

let running=$(cat $rman_check_running |wc -l)

if (( running > 1 )) ;  then
   echo " $db_name RMAN is running ... FULL RMAN backup cannot start!!!"
   mail -s "[CRITICAL]: ERROR:  $db_name RMAN is running ... FULL RMAN backup cannot start!!!"  it-omg-dba-pager@fb.com it-dba@fb.com < /dev/null
   #mail -s "[CRITICAL]: ERROR:  $db_name RMAN is running ... FULL RMAN backup cannot start!!!"  rmohamamd@fb.com < /dev/null
   exit;
fi

##############################################
hn=$(hostname -a)
#BK_DIR=/mnt/vol/gfsora/$db_name/rman
#BK_DIR=/mnt/rman_isi_backup/$db_name/rman
#BK_DIR=/mnt/rman_isi_backup/$db_name/rman
BK_DIR=/mnt/rman_isi_backup/secdw_bm_prn/rman
ts=`date "+%m%d%Y_%H%M"`
TS2=`date "+%m-%d-%Y"`
DB_TAG=`echo TAG_DB_FULL_${ts}`;
BACKUP_COMMENT_ID=INC_0_${DB_TAG}
PURGE_COMMENT_ID=PURGE_${ts}


logfile=/mnt/rman_isi_backup/secdw_bm_prn/logs/rman_full_${db_name}_${ts}.log
purge_logfile=/mnt/rman_isi_backup/secdw_bm_prn/logs/rman_purge_${db_name}_${ts}.log

### find /home/oracle/logs -mtime +30 -exec rm {} \;

export ORACLE_SID=$(grep ^$db_name /etc/oratab |grep -i ${db_name}: |cut -d: -f1)
export ORACLE_HOME=$(grep ^$db_name /etc/oratab |grep -i ${db_name}: |cut -d: -f2)
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"

#/u01/app/oracle/product/11.2.0.3/db_secdw/bin/rman target / <<EOF > $logfile
$ORACLE_HOME/bin/rman target / <<EOF > $logfile
set echo on
run {
SET COMMAND ID TO '${BACKUP_COMMENT_ID}';
backup as compressed backupset INCREMENTAL LEVEL 0  database  TAG = '${DB_TAG}'  format '/mnt/rman_isi_backup/secdw_bm_prn/rman/%d_datafiles_INC0_%D-%M-%Y_%U' section size = 64G filesperset 1 plus archivelog not backed up 1 times TAG = '${DB_TAG}' format '/mnt/rman_isi_backup/secdw_bm_prn/rman/%d_archplus_%D-%M-%Y_%U';
}
EOF


###################################################################################

$ORACLE_HOME/bin/sqlplus  -s '/as sysdba' << EOF >> ${logfile}
set pages 30 lines 234
col INPUT_BYTES_DISPLAY form a20
col OUTPUT_BYTES_DISPLAY form a20
col INPUT_BYTES_PER_SEC_DISPLAY form a30
col OUTPUT_BYTES_PER_SEC_DISPLAY form a30
col TIME_TAKEN_DISPLAY form a20
select COMMAND_ID,INPUT_TYPE,STATUS,INPUT_BYTES_DISPLAY,OUTPUT_BYTES_DISPLAY,COMPRESSION_RATIO,INPUT_BYTES_PER_SEC_DISPLAY,OUTPUT_BYTES_PER_SEC_DISPLAY,TIME_TAKEN_DISPLAY from v\$rman_backup_job_details
where command_id='${BACKUP_COMMENT_ID}';
EOF


let  err_cnt1=$(grep -E "^(RMAN-|ORA-)"  $logfile|grep -v grep |wc -l)
let  err_cnt2=$(grep -E "Recovery Manager complete"  $logfile |grep -v grep | wc -l)
let  err_cnt3=$(grep -E "(COMPLETED)"  $logfile |grep -v -E "(grep|ERRORS|[CRITICAL]S)" |wc -l)

if (( err_cnt1 == 0 )) && (( err_cnt2 == 1 )) && (( err_cnt3 == 1 )) ; then

  tail -50 $logfile |mail -s "[INFO]:${db_name}@$hn  FULL backup completed successfully-> Start Purging $retention days old "   it-dba@fb.com tvishal@fb.com rmohammad@fb.com ramkumars@fb.com
 #tail -50 $logfile |mail -s "[INFO]:${db_name}@$hn  FULL backup completed successfully-> Start Purging $retention days old "   rmohamamd@fb.com




####   start purging old RMAN backups ####

#/u01/app/oracle/product/11.2.0.3/db_secdw/bin/rman target / <<EOF > ${purge_logfile}
$ORACLE_HOME/bin/rman target / <<EOF > ${purge_logfile}
set echo on
run {
SET COMMAND ID TO '${PURGE_COMMENT_ID}';
crosscheck backup ;
delete noprompt backupset completed before "to_date('${TS2}','MM-DD-YYYY')-${retention}";
}
EOF

${ORACLE_HOME}/bin/sqlplus  -s '/as sysdba' << EOF >> ${purge_logfile}
set echo on
set pages 30 lines 234
col INPUT_BYTES_DISPLAY form a20
col OUTPUT_BYTES_DISPLAY form a20
col INPUT_BYTES_PER_SEC_DISPLAY form a30
col OUTPUT_BYTES_PER_SEC_DISPLAY form a30
col TIME_TAKEN_DISPLAY form a20
select COMMAND_ID,INPUT_TYPE,STATUS,INPUT_BYTES_DISPLAY,OUTPUT_BYTES_DISPLAY,COMPRESSION_RATIO,INPUT_BYTES_PER_SEC_DISPLAY,OUTPUT_BYTES_PER_SEC_DISPLAY,TIME_TAKEN_DISPLAY from v\$rman_backup_job_details
where command_id='${PURGE_COMMENT_ID}';
EOF


let  err_cnt1=$(grep -E "^(RMAN-|ORA-|EXPIRED)" ${purge_logfile}  |grep -v grep | wc -l)
let  err_cnt2=$(grep -E "Recovery Manager complete"  ${purge_logfile} |grep -v grep | wc -l)

if (( err_cnt1 == 0 )) && (( err_cnt2 == 1 ))  ; then
    tail -50 ${purge_logfile} |mail -s "[INFO]:${db_name}@$hn  Purge completed successfully"   it-dba@fb.com tvishal@fb.com rmohammad@fb.com ramkumars@fb.com
    #tail -50 ${purge_logfile} |mail -s "[INFO]:${db_name}@$hn  Purge completed successfully" rmohammad@fb.com
else
    tail -50 ${purge_logfile} |mail -s "[CRITICAL]: ${db_name}@$hn  purge has errors!!!"  it-dba@fb.com tvishal@fb.com rmohammad@fb.com ramkumars@fb.com
    #tail -50 ${purge_logfile} |mail -s "[CRITICAL]: ${db_name}@$hn  purge has errors!!!"  rmohammad@fb.com
fi

#### End  purgin old RMAN backups ####



else
    tail -50 ${logfile} |mail -s "[CRITICAL]: ${db_name}@$hn  FULL  backup has errors!!!"  it-dba@fb.com tvishal@fb.com rmohammad@fb.com ramkumars@fb.com
    #tail -50 ${logfile} |mail -s "[CRITICAL]: ${db_name}@$hn  FULL  backup has errors!!!" rmohammad@fb.com


fi
