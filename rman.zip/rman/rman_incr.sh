#!/bin/bash

(( $# != 1 )) && { echo "USAGE:  rman_incr.sh <db_name>"; exit; }
db_name=$1

####   check if there is another RMAN backup running on the database.  If so this backup will not run.

rman_check_running=/tmp/rman_incr_${db_name}
cat /dev/null > $rman_check_running

for nn in $(/u01/app/12.1.0.2/grid/bin/olsnodes)
do
   ssh $nn "ps -fu oracle|grep rman_incr|grep -w $db_name|grep -v grep|grep -v '/bin/sh -c'"  >> $rman_check_running
done

let running=$(cat $rman_check_running |wc -l) 

if (( running > 1 )) ;  then
   echo "Cannot start Incremental RMAN backup,  there is another RMAN backup  running ... "
   exit;
fi

hn=$(hostname -a)
ts=`date "+%m%d%Y_%H%M"`
BK_DIR=/mnt/rman_isi_backup/${db_name}/rman
DB_TAG=`echo TAG_DB_INC_${ts}`;
ARCH_TAG=`echo TAG_DB_ARCH_${ts}`;
BACKUP_COMMENT_ID=INC_1_${DB_TAG}
logfile=/net/dba/fbmon/log/rman/rman_incr_${db_name}_${ts}.log
export ORACLE_SID=$(grep ^${db_name} /etc/oratab |grep -iv Agent |awk -F":" '{print $1}')
export ORACLE_HOME=$(grep ^${db_name} /etc/oratab |grep -iv Agent |awk -F":" '{print $2}')
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"
if [ -f /usr/local/bin/dbenv ]
then
        . /usr/local/bin/dbenv ${ORACLE_SID}
else
        export PATH=$PATH:/usr/local/bin
        export ORACLE_SID=${ORACLE_SID}
        export ORAENV_ASK=NO
        . oraenv
fi

rman target / <<EOF > $logfile
set echo on
run {
SET COMMAND ID TO '${BACKUP_COMMENT_ID}';
backup INCREMENTAL LEVEL 1 CUMULATIVE database TAG = '${DB_TAG}'  section size = 64G filesperset 1  plus archivelog TAG = '${DB_TAG}';
backup  as copy current controlfile format '${BK_DIR}/c-%I-%s_%p.rman';
backup  filesperset 20 archivelog from time 'sysdate - 2' not backed up 1 times delete input TAG = '${ARCH_TAG}';
}
EOF

sqlplus  -s '/as sysdba' << EOF >> ${logfile}
set pages 30 lines 234
col INPUT_BYTES_DISPLAY form a20
col OUTPUT_BYTES_DISPLAY form a20
col INPUT_BYTES_PER_SEC_DISPLAY form a30
col OUTPUT_BYTES_PER_SEC_DISPLAY form a30
col TIME_TAKEN_DISPLAY form a20
select COMMAND_ID,INPUT_TYPE,STATUS,INPUT_BYTES_DISPLAY,OUTPUT_BYTES_DISPLAY,COMPRESSION_RATIO,INPUT_BYTES_PER_SEC_DISPLAY,OUTPUT_BYTES_PER_SEC_DISPLAY,TIME_TAKEN_DISPLAY from v\$rman_backup_job_details
where command_id='${BACKUP_COMMENT_ID}';
EOF

let  err_cnt1=$(grep -E "^(RMAN-|ORA-)"  $logfile|grep -v grep |wc -l)
let  err_cnt2=$(grep -E "Recovery Manager complete"  $logfile |grep -v grep | wc -l)
let  err_cnt3=$(grep -E "(COMPLETED)"  $logfile |grep -v -E "(grep|ERRORS|WARNINGS)" |wc -l)

if (( err_cnt1 == 0 )) && (( err_cnt2 == 1 )) && (( err_cnt3 == 1 )) ; then
  tail -50 $logfile |mail -s "${db_name}@$hn  Incremental  backup completed successfully "   it-dba@fb.com
else
    tail -50 ${logfile} |mail -s "--WARNING: ${db_name}@$hn   Incremental backup has errors!!!"  it-dba@fb.com 
fi

