#!/bin/bash

db_name=dwrac
BK_DIR=/mnt/vol/gfsora/${db_name}/rman
ts=`date "+%m%d%Y"`

export ORACLE_SID=$(grep ^$db_name /etc/oratab |grep -v ${db_name}: |cut -d: -f1) 
export ORACLE_HOME=$(grep ^$db_name /etc/oratab |grep -v ${db_name}: |cut -d: -f2) 
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"

export SNAP_CON_DG=+DATA_XD02

$ORACLE_HOME/bin/rman target / <<EOF > /net/dba/fbmon/log/rman/rman_config_${db_name}_${ts}.log

CONFIGURE DEVICE TYPE DISK CLEAR;
CONFIGURE DEVICE TYPE DISK PARALLELISM 40 BACKUP TYPE TO compressed BACKUPSET;
CONFIGURE CONTROLFILE AUTOBACKUP on;
CONFIGURE COMPRESSION ALGORITHM 'MEDIUM';
CONFIGURE MAXSETSIZE TO unlimited;
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '${SNAP_CON_DG}/${db_name}/CONTROLFILE/snapcf_${db_name}.f';
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 8 DAYS; 


configure channel 1 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db01.thefacebook.com:1521/${db_name}';
configure channel 2 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db01.thefacebook.com:1521/${db_name}';
configure channel 3 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db01.thefacebook.com:1521/${db_name}';
configure channel 4 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db01.thefacebook.com:1521/${db_name}';
configure channel 5 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db01.thefacebook.com:1521/${db_name}';

configure channel 6 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db02.thefacebook.com:1521/${db_name}';
configure channel 7 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db02.thefacebook.com:1521/${db_name}';
configure channel 8 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db02.thefacebook.com:1521/${db_name}';
configure channel 9 device type disk   format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db02.thefacebook.com:1521/${db_name}';
configure channel 10 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db02.thefacebook.com:1521/${db_name}';

configure channel 11 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db03.thefacebook.com:1521/${db_name}';
configure channel 12 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db03.thefacebook.com:1521/${db_name}';
configure channel 13 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db03.thefacebook.com:1521/${db_name}';
configure channel 14 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db03.thefacebook.com:1521/${db_name}';
configure channel 15 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db03.thefacebook.com:1521/${db_name}';

configure channel 16 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db04.thefacebook.com:1521/${db_name}';
configure channel 17 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db04.thefacebook.com:1521/${db_name}';
configure channel 18 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db04.thefacebook.com:1521/${db_name}';
configure channel 19 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db04.thefacebook.com:1521/${db_name}';
configure channel 20 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd02db04.thefacebook.com:1521/${db_name}';



configure channel 31 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db01.thefacebook.com:1521/${db_name}';
configure channel 32 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db01.thefacebook.com:1521/${db_name}'; 
configure channel 33 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db01.thefacebook.com:1521/${db_name}';
configure channel 34 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db01.thefacebook.com:1521/${db_name}';
configure channel 35 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db01.thefacebook.com:1521/${db_name}';

configure channel 36 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db02.thefacebook.com:1521/${db_name}';
configure channel 37 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db02.thefacebook.com:1521/${db_name}';
configure channel 38 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db02.thefacebook.com:1521/${db_name}';
configure channel 39 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db02.thefacebook.com:1521/${db_name}';
configure channel 40 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db02.thefacebook.com:1521/${db_name}';

configure channel 21 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db03.thefacebook.com:1521/${db_name}';
configure channel 22 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db03.thefacebook.com:1521/${db_name}'; 
configure channel 23 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db03.thefacebook.com:1521/${db_name}';
configure channel 24 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db03.thefacebook.com:1521/${db_name}';
configure channel 25 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db03.thefacebook.com:1521/${db_name}';

configure channel 26 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db04.thefacebook.com:1521/${db_name}';
configure channel 27 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db04.thefacebook.com:1521/${db_name}';
configure channel 28 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db04.thefacebook.com:1521/${db_name}';
configure channel 29 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db04.thefacebook.com:1521/${db_name}';
configure channel 30 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd01db04.thefacebook.com:1521/${db_name}';

EOF

tail -50 /net/dba/fbmon/log/rman/rman_config_${db_name}_${ts}.log |mail -s "--NOTE: ${db_name}@Exadata RMAN config has been changed !!! "   it-dba@fb.com 

