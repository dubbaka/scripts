#!/bin/bash

db_name=vtxprd
BK_DIR=/mnt/rman_isi_backup/$db_name/rman
ts=`date "+%m%d%Y_%H%M"`
logfile=/net/dba/fbmon/log/rman/rman_config_${db_name}_${ts}.log

export ORACLE_SID=$(grep ^$db_name /etc/oratab |grep -v ${db_name}: |cut -d: -f1) 
export ORACLE_HOME=$(grep ^$db_name /etc/oratab |grep -v ${db_name}: |cut -d: -f2) 
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"
export SNAP_CON_DG=+DATA_XD01

$ORACLE_HOME/bin/rman target / <<EOF > $logfile

CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 30 DAYS;
CONFIGURE BACKUP OPTIMIZATION OFF; # default
CONFIGURE DEFAULT DEVICE TYPE TO DISK; # default
CONFIGURE CONTROLFILE AUTOBACKUP ON;
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '$BK_DIR/%F'; # default
CONFIGURE DEVICE TYPE DISK PARALLELISM 6 BACKUP TYPE TO COMPRESSED BACKUPSET;
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default
configure channel  1 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd05dbadm08.thefacebook.com:1521/${db_name}';
configure channel  2 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd05dbadm08.thefacebook.com:1521/${db_name}';
configure channel  3 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd05dbadm08.thefacebook.com:1521/${db_name}';
configure channel  4 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd05dbadm08.thefacebook.com:1521/${db_name}';
configure channel  5 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd05dbadm08.thefacebook.com:1521/${db_name}';

configure channel  6 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd05dbadm08.thefacebook.com:1521/${db_name}';
configure channel  7 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/${db_name}sys1@xd05dbadm08.thefacebook.com:1521/${db_name}';
CONFIGURE MAXSETSIZE TO UNLIMITED;
CONFIGURE ENCRYPTION FOR DATABASE OFF; # default
CONFIGURE ENCRYPTION ALGORITHM 'AES128'; # default
CONFIGURE COMPRESSION ALGORITHM 'MEDIUM' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE;
CONFIGURE ARCHIVELOG DELETION POLICY TO NONE; # default
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '${SNAP_CON_DG}/${db_name}/CONTROLFILE/snapcf_${db_name}.f';


EOF


###################################################################################

tail -50 /net/dba/fbmon/log/rman/rman_config_${db_name}_${ts}.log |mail -s "--NOTE: ${db_name}@Exadata RMAN config has been changed !!! "   it-dba@fb.com

