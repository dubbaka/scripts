#!/bin/bash

db_name=OMSUAT2
BK_DIR=/mnt/rman_isi_backup/${db_name}/rman
ts=`date "+%m%d%Y_%H%M"`
logfile=/net/dba/fbmon/log/rman/rman_config_${db_name}_${ts}.log

export ORACLE_SID=$(grep ^$db_name /etc/oratab |grep -v ${db_name}: |cut -d: -f1) 
export ORACLE_HOME=$(grep ^$db_name /etc/oratab |grep -v ${db_name}: |cut -d: -f2) 
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"
export SNAP_CON_DG=+DATA1_XD05

$ORACLE_HOME/bin/rman target / <<EOF > $logfile

CONFIGURE DEVICE TYPE DISK CLEAR; 
CONFIGURE DEVICE TYPE DISK PARALLELISM 8 BACKUP TYPE TO compressed BACKUPSET;
CONFIGURE CONTROLFILE AUTOBACKUP on;
CONFIGURE COMPRESSION ALGORITHM 'MEDIUM';
CONFIGURE MAXSETSIZE TO unlimited; 
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '$BK_DIR/%F';
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 16 DAYS; 

configure channel  1 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/omsuat2sys1@xd05db03.thefacebook.com:1541/${db_name}';
configure channel  2 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/omsuat2sys1@xd05db03.thefacebook.com:1541/${db_name}';
configure channel  3 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/omsuat2sys1@xd05db03.thefacebook.com:1541/${db_name}';
configure channel  4 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/omsuat2sys1@xd05db03.thefacebook.com:1541/${db_name}';

configure channel 5 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/omsuat2sys1@xd05db04.thefacebook.com:1541/${db_name}';
configure channel 6 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/omsuat2sys1@xd05db04.thefacebook.com:1541/${db_name}';
configure channel 7 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/omsuat2sys1@xd05db04.thefacebook.com:1541/${db_name}';
configure channel 8 device type disk  format '$BK_DIR/%d_%s_%p_%T.rman' connect ='sys/omsuat2sys1@xd05db04.thefacebook.com:1541/${db_name}';

EOF


###################################################################################

tail -50 /net/dba/fbmon/log/rman/rman_config_${db_name}_${ts}.log |mail -s "--NOTE: ${db_name}@Exadata RMAN config has been changed !!! "   it-dba@fb.com

