#!/bin/bash
##############################################
(( $# != 1 )) && { echo "USAGE:  rman_full.sh <db_name>"; exit; }
db_name=$1
##############################################

##############################################
hn=$(hostname -a)
BK_DIR=/mnt/vol/t2_bi_vol001/dwrac/rman
ts=`date "+%m%d%Y_%H%M"`

logfile=/net/dba/fbmon/log/rman_full_${db_name}_${ts}.log


export ORACLE_SID=$(grep ^$db_name /etc/oratab |grep -v ${db_name}: |cut -d: -f1) 
export ORACLE_HOME=$(grep ^$db_name /etc/oratab |grep -v ${db_name}: |cut -d: -f2) 
export NLS_DATE_FORMAT="yyyy-mm-dd HH24:MI:SS"

$ORACLE_HOME/bin/rman target / <<EOF > $logfile


CONFIGURE SNAPSHOT CONTROLFILE NAME TO '/mnt/vol/t2_bi_vol001/dwrac/rman/snapcf_dwrac.f';

run {

allocate channel c1 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman';
allocate channel c2 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman';
allocate channel c3 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman';
allocate channel c4 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman';
allocate channel c5 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman';

allocate channel c6 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db02.thefacebook.com:1521/dwrac';
allocate channel c7 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db02.thefacebook.com:1521/dwrac';
allocate channel c8 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db02.thefacebook.com:1521/dwrac';
allocate channel c9 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db02.thefacebook.com:1521/dwrac';
allocate channel c10 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db02.thefacebook.com:1521/dwrac';

allocate channel c11 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db03.thefacebook.com:1521/dwrac';
allocate channel c12 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db03.thefacebook.com:1521/dwrac';
allocate channel c13 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db03.thefacebook.com:1521/dwrac';
allocate channel c14 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db03.thefacebook.com:1521/dwrac';
allocate channel c15 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db03.thefacebook.com:1521/dwrac';

allocate channel c16 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db04.thefacebook.com:1521/dwrac';
allocate channel c17 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db04.thefacebook.com:1521/dwrac';
allocate channel c18 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db04.thefacebook.com:1521/dwrac';
allocate channel c19 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db04.thefacebook.com:1521/dwrac';
allocate channel c20 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd02db04.thefacebook.com:1521/dwrac';

allocate channel c21 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db03.thefacebook.com:1521/dwrac';
allocate channel c22 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db03.thefacebook.com:1521/dwrac'; 
allocate channel c23 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db03.thefacebook.com:1521/dwrac';
allocate channel c24 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db03.thefacebook.com:1521/dwrac';
allocate channel c25 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db03.thefacebook.com:1521/dwrac';

allocate channel c26 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db04.thefacebook.com:1521/dwrac';
allocate channel c27 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db04.thefacebook.com:1521/dwrac';
allocate channel c28 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db04.thefacebook.com:1521/dwrac';
allocate channel c29 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db04.thefacebook.com:1521/dwrac';
allocate channel c30 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db04.thefacebook.com:1521/dwrac';

allocate channel c31 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db01.thefacebook.com:1521/dwrac';
allocate channel c32 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db01.thefacebook.com:1521/dwrac'; 
allocate channel c33 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db01.thefacebook.com:1521/dwrac';
allocate channel c34 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db01.thefacebook.com:1521/dwrac';
allocate channel c35 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db01.thefacebook.com:1521/dwrac';

allocate channel c36 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db02.thefacebook.com:1521/dwrac';
allocate channel c37 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db02.thefacebook.com:1521/dwrac';
allocate channel c38 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db02.thefacebook.com:1521/dwrac';
allocate channel c39 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db02.thefacebook.com:1521/dwrac';
allocate channel c40 device type disk  format '/mnt/vol/t2_bi_vol001/dwrac/rman/%d_%s_%p.rman' connect ='sys/dwracsys1@xd01db02.thefacebook.com:1521/dwrac';


set MAXCORRUPT for DATAFILE  '+DATA_XD02/dwrac/datafile/mstrstat_data.17852.813618975'   to  200 ;
backup INCREMENTAL LEVEL 0   database   skip readonly  section size = 64G filesperset 1 ;
backup  as copy current controlfile format '/mnt/vol/t2_bi_vol001/dwrac/rman/c-%I-%s_%p.rman';
backup  as copy current controlfile format '/mnt/vol/t2_bi_vol001/dwrac/rman/c-%I-%s_%p.rman';


release channel c1  ;
release channel c2  ;
release channel c3  ;
release channel c4  ;
release channel c5  ;

release channel c6  ;
release channel c7  ;
release channel c8  ;
release channel c9  ;
release channel c10  ;

release channel c11  ;
release channel c12  ;
release channel c13  ;
release channel c14  ;
release channel c15  ;

release channel c16  ;
release channel c17  ;
release channel c18  ;
release channel c19  ;
release channel c20  ;

release channel c21  ;
release channel c22  ;
release channel c23  ;
release channel c24  ;
release channel c25  ;

release channel c26  ;
release channel c27  ;
release channel c28  ;
release channel c29  ;
release channel c30  ;

release channel c31  ;
release channel c32  ;
release channel c33  ;
release channel c34  ;
release channel c35  ;

release channel c36  ;
release channel c37  ;
release channel c38  ;
release channel c39  ;
release channel c40  ;


}

EOF


###################################################################################
let  err_cnt=$(grep -E "^(RMAN-|ORA-)"  $logfile  |wc -l)

if (( err_cnt != 0 )) ; then
    tail -50 $logfile |mail -s "--WARNING: ${db_name}@$hn  FULL  backup has errors!!!"  it-dba@fb.com
else
    tail -50 $logfile |mail -s "${db_name}@$hn  FULL backup completed successfully"   it-dba@fb.com
fi

