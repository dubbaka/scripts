SELECT  wpb.NAME,
      wpb.BACKORDERS_ONLY_FLAG,
  oeh.order_number,
         NVL(wpb.AUTODETAIL_PR_FLAG, NULL),
              NVL(wpb.AUTO_PICK_CONFIRM_FLAG, NULL),
              NVL(wpb.PICK_SEQUENCE_RULE_ID, ''),
              NVL(wpb.PICK_GROUPING_RULE_ID, ''),
              NVL(wpb.EXISTING_RSVS_ONLY_FLAG, 'N'),
              NVL(wpb.ORDER_HEADER_ID, 0),
              NVL(wpb.INVENTORY_ITEM_ID, 0),
              NVL(wpb.TRIP_ID, 0),
              NVL(wpb.TRIP_STOP_ID, 0),
              NVL(wpb.DELIVERY_ID, 0),
              NVL(wpb.ORDER_TYPE_ID, 0),
              NVL(wpb.FROM_SCHEDULED_SHIP_DATE, NULL),
              NVL(wpb.SHIP_TO_LOCATION_ID, 0),
              NVL(wpb.DEFAULT_STAGE_SUBINVENTORY, ''),
              NVL(wpb.SHIP_FROM_LOCATION_ID, -1),
              NVL(wpb.AUTOCREATE_DELIVERY_FLAG, NULL),
              NVL(wpb.ORDER_LINE_ID, 0),
              NVL(wpb.DOCUMENT_SET_ID, '-1')
FROM    WSH_PICKING_BATCHES wpb
	  , oe_order_headers_all oeh
WHERE   wpb.BATCH_ID =&batch_id 
AND wpb.ORDER_HEADER_ID = oeh.header_id
