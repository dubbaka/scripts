CREATE OR REPLACE PACKAGE XXYH_CUSTOMER_INTERFACE_PKG AS

FUNCTION derive_gl (l_alter_company IN VARCHAR2, 
                            l_coa           IN NUMBER,
                            l_gl_id         IN NUMBER)
           RETURN NUMBER;

PROCEDURE   XXYH_CUSTOMER_INSERT_NEW( retcode  out NUMBER,
                              errbuf   out VARCHAR2,
                              p_org_id in  NUMBER);



END XXYH_CUSTOMER_INTERFACE_PKG;
/
CREATE OR REPLACE PACKAGE BODY XXYH_CUSTOMER_INTERFACE_PKG AS
 PROCEDURE   XXYH_CUSTOMER_INSERT_NEW( retcode  out NUMBER,
                              errbuf   out VARCHAR2,
                              p_org_id in  NUMBER)
    IS
/*  **************************************************************
 *  $Header: XXYH_CUSTOMER_INSERT.sql  $
 *  **************************************************************
 *
 *                          GoTo  CRM Customer Insert
 *
 *            Module  Name   :  XXYH_CUSTOMER_INSERT.pls
 *            Created By     :
 *            Creation Date  :
 *
 *            Description    :  This Module will do the loading of
 *                              any new customers    from CRM
 *                              into OF Customer interface
 *                              tables
 *
 *            External Systems : CRM
 *             Accessed
 *
 *
 *            GoTo Custom
 *              Tables used   :  xxyh_customer_interface_temp
 *
 *            Parameters       : Org Id
 *
 *
 *            Arguments        : IN  org_id
 *                               OUT None
 *
 *            Modification History
 *
 *  Name           Date       Change Log
 *
 *
 */

      v_org_id                  NUMBER ;
      v_client_count            NUMBER ;
      v_acct_count              NUMBER ;
      v_temp                    NUMBER ;
      v_count                   NUMBER ;
      v_contact_count           NUMBER ;
      v_advertiser_id           VARCHAR2(20);
      v_mp_invoice              VARCHAR2(20);
      v_CUST_TYPE               VARCHAR2(15);
      v_crm_cust_type           VARCHAR2(15);
      Rec_count                 NUMBER := 0;
      Rec_count_c2              NUMBER := 0;
      Last_advid                VARCHAR2(20);
      v_PSite_flag              VARCHAR2(1);
      v_Ptest_flag              NUMBER;
      v_country                 VARCHAR2(80);
      v_vat_code                varchar2(20);
      v_org_name                varchar2(50);
      v_cur_code                varchar2(10) ;
      v_customer_name           VARCHAR2(300) ;
      v_profile_count           NUMBER := 0 ;
      v_profile_count1          NUMBER := 0 ;
      v_state                   varchar2(200) ;
      v_county                  varchar2(100) ;
      v_city                    VARCHAR2(200);
      v_first_name              VARCHAR2(200) ;
      v_last_name               VARCHAR2(200) ;
      v_middle_initial          VARCHAR2(10) ;
      v_pay_term                VARCHAR2(50) ;
      v_collector               VARCHAR2(100) ;
      v_gl_id_clearing          NUMBER(15) ;
      v_gl_id_factor            NUMBER(15) ;
      v_gl_id_freight           NUMBER(15) ;
      v_gl_id_rec               NUMBER(15) ;
      v_gl_id_remittance        NUMBER(15) ;
      v_gl_id_rev               NUMBER(15) ;
      v_gl_id_tax               NUMBER(15) ;
      v_gl_id_unbilled          NUMBER(15) ;
      v_gl_id_unearned          NUMBER(15) ;
      v_gl_id_unpaid_rec        NUMBER(15) ;
      v_language                VARCHAR2(10) ;
      v_client_id               VARCHAR2(100);
      v_acct_id              VARCHAR2(100);
      v_rec_cnt              NUMBER :=0;
      /* Added By Sai Prasad on 05/26/2005 to avoid inserting duplicate records
         in RA_CUSTOMER_INTERFACE_ALL table*/
         v_rec_exists VARCHAR2(1) :='N';
         v_str        VARCHAR2(1000);
         v_rec_id     NUMBER :=0;
         v_prev_advertiser_id VARCHAR2(100);
         v_prev_account_id    VARCHAR2(100);
     /* Changes End*/
      v_Request_Phase		VARCHAR2(20);
      v_Request_Status	VARCHAR2(20);
      v_Request_Message	VARCHAR2(100);
      v_Request_Status_B	BOOLEAN;
      v_Dev_Request_Phase	VARCHAR2(20);
      v_Dev_Request_Status	VARCHAR2(20);
      x_req_id                  NUMBER;
      v_cur_opened              VARCHAR2(1) := 'N';
      v_cont_exists             VARCHAR2(1) := 'N';
      v_con_id                  NUMBER;
      v_ph_id                   NUMBER;
      v_contact_id              NUMBER;
      v_orig_system_contact_ref VARCHAR2(240):= NULL;
      v_orig_system_tel_ref      VARCHAR2(240):= NULL;
      v_alter_company      VARCHAR2 (10);
      v_legal_entity       VARCHAR2 (10);
      v_sob                NUMBER ;
      v_coa                NUMBER ;

      CURSOR rec_client  IS
      SELECT client_id,
             client_name
      FROM xxyh_client
      WHERE  new_client='Y'
      AND    org_id = p_org_id;

      CURSOR rec_cust IS
              SELECT  ADVERTISER_ID,CONTACT_NAME,nvl(CONTACT_COMPANY,contact_name)
                      contact_company,
                      CONTACT_EMAIL,
                      CONTACT_STREET1,CONTACT_STREET2,
                      contact_street3, contact_street4,
                      CONTACT_CITY,CONTACT_STATE,
                      CONTACT_ZIP,CONTACT_COUNTRY,CONTACT_PHONE,
                      CONTACT_INVOICE,MP_INVOICE ,
                      contact_first_name, contact_last_name,
                      contact_middle_initial,
                      customer_class_code,
                      site_use_attribute1,
                      vat_code,
                      vat_reference,
                      county,
                      de_tax_status,
                      contact_title, org_id, language_id,
                      client_name_furigana,
                      account_name_furigana,
                      first_name_furigana,
                      last_name_furigana,
                      department,
                      fuken,
                      president_name,
                      business_type,
                      business_item,
                      market_name,
                      personal_id,
                      customer_category,
                      site_use_attribute5,
                      site_use_attribute2,
                      old_customer_id,
                      old_site_use_id,
                      old_contact_id,
                      area_code,
                      contact_type,
                      phone_type,
                      cust_collector_name,
		      cust_terms_name,
		      site_collector_name,
            	      site_terms_name,
            	      customer_category_code,
            	      cust_payment_type,
            	      cust_currency_code,
            	      site_currency_code,
            	      cust_override_terms,
		      cust_discount_terms,
		      cust_statements,
		      cust_credit_balance_stmts,
		      cust_stmt_cycle_name,
		      cust_dunning_letters,
		      cust_dunning_letters_set,
		      cust_cons_inv_flag,
		      cust_cons_inv_type,
		      cust_interest_rate,
		      cust_max_interest_charge,
		      cust_minfc_balance_amt,
		      cust_minfc_invoice_amt,
		      cust_auto_rec_minrcpt_amt,
		      cust_min_stmt_amt,
		      cust_min_dunning_amt ,
		      cust_min_dunning_inv_amt  ,
		      cust_trx_credit_limit ,
		      cust_overall_credit_limit,
		      site_override_terms,
		      site_discount_terms,
		      site_statements,
		      site_credit_balance_stmts,
		      site_stmt_cycle_name ,
		      site_dunning_letters,
		      site_dunning_letters_set,
		      site_cons_inv_flag,
		      site_cons_inv_type,
		      site_interest_rate,
		      site_max_interest_charge,
		      site_minfc_balance_amt,
		      site_minfc_invoice_amt,
		      site_auto_rec_minrcpt_amt,
		      site_min_stmt_amt,
		      site_min_dunning_amt,
		      site_min_dunning_inv_amt,
		      site_trx_credit_limit,
		      site_overall_credit_limit,
		      primary_flag
             FROM    xxyh_customer_interface_temp
             WHERE   Rec_status is NULL
             AND     mp_invoice IS NOT NULL
             and     org_id =p_org_id
             and     rownum <=50000
             For Update of Rec_Status
       Order by org_id, Advertiser_id,mp_invoice;

       CURSOR rec_site IS
       SELECT  location, site_use_id, address_id, org_id
       FROM    ra_site_uses_morg
       WHERE status='A' and primary_flag ='N' and site_use_code='BILL_TO'
       and creation_date > sysdate - 1;




    BEGIN

 	    Insert into /*+ APPEND */ xxyh_customer_interface_temp
              --    NULL;
                  (         ADVERTISER_ID    ,
                            CONTACT_NAME      ,
                            CONTACT_COMPANY    ,
                            CONTACT_EMAIL       ,
                            CONTACT_STREET1  ,
                            CONTACT_STREET2 ,
                            CONTACT_CITY     ,
                            CONTACT_STATE   ,
                            CONTACT_ZIP     ,
                            CONTACT_COUNTRY ,
                            CONTACT_PHONE  ,
                            CONTACT_INVOICE       ,
                            MP_INVOICE      ,
                            REC_STATUS      ,
                            INT_LOAD_ID         ,
                            CONTACT_MODIFIED   ,
                            CONTACT_FIRST_NAME   ,
                            CONTACT_LAST_NAME     ,
                            CONTACT_MIDDLE_INITIAL       ,
                            CONTACT_STREET3,
                            CONTACT_STREET4,
                            CUSTOMER_CLASS_CODE,
                            SITE_USE_ATTRIBUTE1,
                            VAT_CODE,
                            VAT_REFERENCE,
                            CONTACT_TITLE,
                            DE_TAX_STATUS,
                            COUNTY,
                            ORG_ID,
                            LANGUAGE_ID,
                            client_name_furigana,
                            account_name_furigana,
                            first_name_furigana,
                            last_name_furigana,
                            department,
                            fuken,
                            president_name,
                            business_type,
                            business_item ,
                            market_name,
                            personal_id,
                            customer_category,
                            LEGAL_ENTITY,
            		STATE_REGISTRATION,
            		SITE_USE_ATTRIBUTE5,
            		OLD_CUSTOMER_ID,
            		OLD_SITE_USE_ID,
            		OLD_CONTACT_ID,
            		AREA_CODE,
            		contact_type,
            		phone_type,
            		site_use_attribute2,
            		cust_collector_name,
            		cust_terms_name,
            		site_collector_name,
            		site_terms_name,
            		customer_category_code,
            		cust_payment_type,
            		cust_currency_code,
            		site_currency_code,
            		CUST_OVERRIDE_TERMS,
			cust_discount_terms,
			cust_statements,
			cust_credit_balance_stmts,
			cust_stmt_cycle_name,
			cust_dunning_letters,
			cust_dunning_letters_set,
			cust_cons_inv_flag,
			cust_cons_inv_type,
			cust_interest_rate,
			cust_max_interest_charge,
			cust_minfc_balance_amt,
			cust_minfc_invoice_amt,
			cust_auto_rec_minrcpt_amt,
			cust_min_stmt_amt,
			cust_min_dunning_amt,
			cust_min_dunning_inv_amt,
			cust_trx_credit_limit,
			cust_overall_credit_limit,
			site_override_terms,
			site_discount_terms,
			site_statements,
			site_credit_balance_stmts,
			site_stmt_cycle_name,
			site_dunning_letters,
			site_dunning_letters_set,
			site_cons_inv_flag,
			site_cons_inv_type ,
			site_interest_rate,
			site_max_interest_charge,
			site_minfc_balance_amt,
			site_minfc_invoice_amt,
			site_auto_rec_minrcpt_amt,
			site_min_stmt_amt,
			site_min_dunning_amt,
			site_min_dunning_inv_amt,
			site_trx_credit_limit,
			site_overall_credit_limit,
			primary_flag)
            	--	NULL;
            	       (select /* + full(d) full(b) full(c) parallel(d,2) parallel(b,2) parallel(c,2) */
			--null;
			c.client_id,
			     'xxx',
			      substrb(d.client_name,1,190),
			      substrb(c.client_email,1,99),
			      substrb(b.account_name,1,220),
			      substrb(NVL(c.address_1,d.address_1),1,200),
			      substrb(NVL(c.city,d.city),1,59),
			      substrb(NVL(c.state,d.state),1,50),
			      substrb(NVL(c.zip_code,d.zip_code),1,99),
			      substrb(NVL(c.country,d.country),1,50),
			      c.client_phone,
			      --decode (b.payment_type,'PREPAYS',0,'INVOICED',1,'INVOICE',1,1),
			      b.payment_type,
			      c.account_id,
			      null,
			      d.id,
			      sysdate,
			      substrb(c.first_name,1,99),
			      substrb(c.last_name,1,99),
			      substrb(c.middle_initial,1,9),
			      substrb(nvl(c.address_2,d.address_2),1,99),
			      substrb(nvl(c.address_3,d.address_3),1,99),
			      decode(d.agency_flag,'Y','AGENCY','AGENCY','AGENCY',null),
			      decode(promo_code,'none','NONE',upper(promo_code)),
			      b.vat_code,
			      substrb(b.vat_reference,1,48),
			      substrb(c.contact_title,1,39),
			      b.de_tax_status,
			      substrb(c.county,1,47),
			      p_org_id,
			      c.language_id,
			      substrb(d.client_name_furigana,1,290),
			      substrb(b.account_name_furigana,1,290),
			      substrb(c.first_name_furigana,1,149),
			      substrb(c.last_name_furigana,1,149),
			      substrb(c.department ,1,149),
			      c.fuken,
			      substrb(b.president_name,1,149),
			      substrb(b.business_type,1,149),
			      substrb(b.business_item,1,149),
			      b.organization,
			      b.personal_id,
			      decode(b.at_type_id,1,'SEARCH',4,'LOCAL'),
			      NULL,
			      NULL,
			      b.site_use_attrib5,
			      d.old_customer_id,
			      b.old_site_use_id,
                 	      c.old_contact_id,
                 	      c.area_code,
                 	      c.contact_type,
                 	      c.phone_type,
                 	      b.site_use_attrib2,
                 	      d.cust_collector_name,
                 	      d.cust_terms_name,
                 	      b.site_collector_name,
                 	      b.site_terms_name,
                 	      d.customer_category_code,
                 	      d.cust_payment_type,
                 	      d.cust_currency_code,
                 	      b.site_currency_code,
                 	      d.cust_override_terms,
			      d.cust_discount_terms,
			      d.cust_statements,
			      d.cust_credit_balance_stmts,
			      d.cust_stmt_cycle_name,
			      d.cust_dunning_letters,
			      d.cust_dunning_letters_set,
			      d.cust_cons_inv_flag,
			      d.cust_cons_inv_type,
			      d.cust_interest_rate,
			      d.cust_max_interest_charge,
			      d.cust_minfc_balance_amt,
			      d.cust_minfc_invoice_amt,
			      d.cust_auto_rec_minrcpt_amt,
			      d.cust_min_stmt_amt,
			      d.cust_min_dunning_amt,
			      d.cust_min_dunning_inv_amt,
			      d.cust_trx_credit_limit ,
			      d.cust_overall_credit_limit,
			      b.site_override_terms,
			      b.site_discount_terms,
			      b.site_statements,
			      b.site_credit_balance_stmts,
			      b.site_stmt_cycle_name,
			      b.site_dunning_letters,
			      b.site_dunning_letters_set,
			      b.site_cons_inv_flag,
			      b.site_cons_inv_type,
			      b.site_interest_rate,
			      b.site_max_interest_charge,
			      b.site_minfc_balance_amt,
			      b.site_minfc_invoice_amt,
			      b.site_auto_rec_minrcpt_amt,
			      b.site_min_stmt_amt,
			      b.site_min_dunning_amt,
			      b.site_min_dunning_inv_amt,
			      b.site_trx_credit_limit,
			      b.site_overall_credit_limit,
			      b.primary_flag
                 	  FROM
			      xxyh_client_primary_contact c,
			      xxyh_client_account b,
			      xxyh_client d
			  WHERE b.org_id = p_org_id
			    and c.org_id = p_org_id
			    and d.org_id = p_org_id
			    and b.account_id=c.account_id
			    and d.client_status='ACTIVE'
			 -- and d.client_id = b.client_id
			    and b.client_id=c.client_id
			    and c.client_id!='-1'
			    and b.client_id!='-1'
			    and d.client_id!='-1'
			    and nvl(b.processed_flag,'N') = 'N'
			    and nvl(c.processed_flag,'N') = 'N'
			    and d.client_id=c.client_id
			    and c.new_contact='Y'
			    and d.new_client='Y'
			    --and nvl(d.processed_flag,'N') = 'N'
			    and b.new_account='Y'
			    -- below added by kwlee on jan 24,2000 to prevent duplicates
			    and d.rowid=(select min(e.rowid) from
					      xxyh_client e where e.client_id=d.client_id
					      and e.new_client='Y' and nvl(e.processed_flag,'N')='N' and e.org_id = p_org_id)
					      and d.new_client='Y' and nvl(d.processed_flag,'N')='N');

     --NULL;
    /* FOR  c1_count in rec_client LOOP

            update xxyh_customer_interface_temp temp
            set contact_company=substrb(c1_count.client_name,1,190)
            where advertiser_id=c1_count.client_id
            and   org_id = p_org_id;

         END  LOOP;*/
         


       update xxyh_client
         set processed_flag='Y'
       where nvl(processed_flag,'N') = 'N'
        and client_status='ACTIVE'
        and client_id in
       (select advertiser_id from xxyh_customer_interface_temp
        where rec_status is null and org_id = p_org_id )
       and new_client = 'Y'
       and org_id = p_org_id;


        update xxyh_customer_interface_temp temp
          set contact_company=(select customer_name from
                               ra_hcustomers
                               where customer_number=
                              temp.advertiser_id)
        where rec_status is null and contact_company is null and org_id = p_org_id
         ;


        update xxyh_client_primary_contact
         set processed_flag='Y'
        where nvl(processed_flag,'N') = 'N'
        and account_id in
         (select mp_invoice from xxyh_customer_interface_temp
         where rec_status is null and org_id = p_org_id )
        and new_contact = 'Y'
        and org_id = p_org_id;

        update xxyh_client_account
         set processed_flag='Y'
        where nvl(processed_flag,'N') = 'N'
        and account_id in
         (select mp_invoice from xxyh_customer_interface_temp
         where rec_status is null and org_id = p_org_id )
        and new_account = 'Y'
        and org_id =p_org_id;

      --  NULL;



       -- prompt Note also that the following customers errored out (if any):

       /*
         select substr(advertiser_id,1,10), substr(contact_company,1,15),
           mp_invoice, substr(contact_last_name,15)
          from goto_customer_interface_temp
         where rec_status ='E' ;
       */


       FND_FILE.put_line(FND_FILE.output, '==============================') ;

       FND_FILE.put_line(FND_FILE.output,
            ' All done with inserting into goto_customer_interface_temp ') ;


       FND_FILE.put_line(FND_FILE.log,
            ' All done with inserting into goto_customer_interface_temp ') ;

        -- The following added on Jul 14, 99 to
        --  handle primary site flag update



       /*FOR c1_count IN rec_site LOOP

          v_cur_opened := 'Y';
          Select customer_id into v_temp from ra_addresses_morg
	  Where address_id=c1_count.address_id;

	  Select count(*) into v_count from ra_addresses_morg
	  Where customer_id = v_temp and
                org_id      = c1_count.org_id ;

	  IF V_COUNT=1 THEN

	      Update ra_site_uses_morg
	       Set primary_flag='Y' where site_use_id=c1_count.site_use_id;

           End if;

        END  LOOP;*/

        FND_FILE.put_line(FND_FILE.output, '==============================') ;

        FND_FILE.put_line(FND_FILE.output,
         ' Now Inserting into Oracle Interface Tables ') ;

        FND_FILE.put_line(FND_FILE.output, '==============================') ;

        FND_FILE.put_line(FND_FILE.output,
          'Following Customers and Accounts were Processed');

        FND_FILE.put_line(FND_FILE.output, '==============================') ;

       --   <<Exec_Cursor>>
       fnd_file.put_line(fnd_file.log,'Again near label');
       v_cur_opened := 'N';

        FOR c1_count IN rec_cust LOOP

		    v_client_id := c1_count.advertiser_id;
		    v_acct_id := c1_count.mp_invoice;
		    Rec_count   := Rec_count + 1 ;
	            v_profile_count := 0 ;
	            v_org_name      := NULL ;
	            v_profile_count1 := 0 ;
	            v_vat_code  := NULL ;
	            v_pay_term  := NULL ;
	            v_collector := NULL ;
	            v_cur_opened := 'Y';



	          /* Code Added by Venky to get  currency - 08/23/00 */

	            BEGIN

	               Select setb.currency_code,
	                      setb.org_name
	               into V_cur_code,
	                    v_org_name
	               from goto_set_of_books_currency  setb
	               where  setb.org_id  = c1_count.org_id ;

	            EXCEPTION

	              When others then
	                Raise_application_error(
	                -20001, 'Currency Org  Validation Failed') ;

	            END  ;

	            If c1_count.advertiser_id =
	              NVL(Last_advid,c1_count.advertiser_id) THEN
			Rec_count_c2 := Rec_count_c2 + 1;
		    Else
			Rec_count_c2 := 1;
		    End if;

	          -- Code Added by venky to derive the Vat_tax_code  - 09/22/00
	          -- Added New VAT codes for DE Launch  - 10/10/00
	          -- Added VAT code logic from tax code attribute1 - 03/25/04

	            BEGIN

	             -- IF  v_org_name <> 'US' THEN
	             /*
	              Select decode(c1_count.vat_code,'-1','UNKNOWN',
	                                         '1','UK-PPD-VAT',
	                                         '2','UK-INV-VAT',
	                                         '3','UK-PPD-ZERO',
	                                         '4','UK-INV-ZERO',
	                                         '5','UK-PPD-EXEMPT',
	                                         '6','UK-INV-EXEMPT',
	                                         '7','IntraEU-PPD-ZERO',
	                                         '8','IntraEU-INV-ZERO',
	                                         '9','IntraEU-PPD-TAXED',
	                                         '10','IntraEU-INV-TAXED',
	                                         '20','DE-PPD-VAT',
	                                         '21','DE-INV-VAT',
						 '22','IntraEU-PPD-TAXED',
						 '23','IntraEU-INV-TAXED',
						 '24','IntraEU-PPD-ZERO',
				   		 '25','IntraEU-INV-ZERO',
	                                         '26','DE-PPD-ZERO',
	                                         '27','DE-INV-ZERO',
	                                         '32','FR-PPD-VAT',
	                                         '30','FR-INV-VAT',
	                                         '33','FR-PPD-ZERO',
	                                         '31','FR-INV-ZERO',
	                                         '41','JP-PPD-TAX',
	                                         '40','JP-INV-TAX',
	                                         '50','KR-INV-VAT',
	                                         '51','KR-PPD-VAT',
	                                         '52','KR-PPD-ZERO',
	                                         '53','KR-INV-ZERO',
	                                         '60','IT-PPD-VAT',
	                                         '61','IT-INV-VAT',
	                                         '62','IntraEU-PPD-TAXED-IT',
	                                         '63','IntraEU-INV-TAXED-IT',
	                                         '64','IntraEU-PPD-ZERO-IT',
	                                         '65','IntraEU-INV-ZERO-IT',
	 				         '66','IT-PPD-ZERO',
	                                         '67','IT-INV-ZERO',
	 					 '70','SP-PPD-VAT',
						 '71','SP-INV-VAT',
						 '72','IntraEU-PPD-TAXED-SP',
	                                         '73','IntraEU-INV-TAXED-SP',
	                                         '74','IntraEU-PPD-ZERO-SP',
	                                         '75','IntraEU-INV-ZERO-SP',
	                                         '76','SP-PPD-ZERO',
	                                         '77','SP-INV-ZERO',
	                                         '80','IE-INV-VAT',
	                                         '81','IE-INV-ZERO',
	                                         '82','IE-PPD-VAT',
	                                         '83','IE-PPD-ZERO'
	                                         )
	               into v_vat_code  from dual ;
	              */

	              IF v_org_name <> 'US' THEN
                      fnd_file.put_line(fnd_file.log,'Near Vat tax'||c1_count.vat_code);
	              IF c1_count.vat_code IS NOT NULL THEN
	              SELECT '1'
	                INTO v_vat_code
	               FROM ar_vat_tax_all
	               WHERE tax_code = c1_count.vat_code AND
	                     org_id     = c1_count.org_id 
	               and   sysdate between start_date and nvl(end_date,sysdate)
	               and   rownum<=1;

	              END IF ;


	             END IF ;

	            EXCEPTION
	            WHEN NO_DATA_FOUND THEN
	                  arp_standard.debug(' EXCEPTION : goto_customer_insert' ) ;
	                ROLLBACK ;
	                errbuf := sqlerrm ;
	                retcode := sqlcode ;
	                FND_FILE.put_line(FND_FILE.log,
	                   'Customer Number : ' || c1_count.advertiser_id ||
	                   ' Account        : ' || c1_count.mp_invoice ||
	                   'VAT Code        : ' || c1_count.vat_code ) ;
	                 RAISE_APPLICATION_ERROR(-20002, errbuf||
	                '  1.  VAT code Derivation Failed   ' ) ;

	            END ;

		/*    BEGIN

	    	      SELECT customer_number,
	                     location
		      INTO   V_advertiser_id,
	                     V_mp_invoice
		      FROM  goto_customer_info_v
		     WHERE customer_number = c1_count.advertiser_id
		      AND  location  = c1_count.mp_invoice ;

		    EXCEPTION
	            WHEN  NO_DATA_FOUND THEN

			v_advertiser_id  := NULL ;
			v_mp_invoice    := NULL ;
	            ---		Rec_status := 'Rejected';

		    END;*/

	            -- 1 FOR INVOICED CUSTOMER
	            -- 0 FOR PREPAYS CUSTOMER
		    BEGIN

			SELECT count(*)
	                INTO v_ptest_flag
			FROM
	                ra_hcustomers a,
	                ra_addresses_morg  b,
	                ra_site_uses_morg c,
			ar_hcustomer_profiles d,
	                ar_hcustomer_profile_classes e
			WHERE a.customer_id = b.customer_id
			AND b.address_id = c.address_id
			AND c.primary_flag = 'Y'
			AND a.customer_number = c1_count.advertiser_id
			AND a.customer_id = d.customer_id
			AND d.customer_profile_class_id = e.customer_profile_class_id ;

		   EXCEPTION

	            WHEN NO_DATA_FOUND THEN

			v_ptest_flag  := 0;
		   END;

	          -- Get profile class

		/*    BEGIN

		      SELECT DECODE(NVL(C1_COUNT.CONTACT_INVOICE,1),0,'PREPAYS',
				1,'INVOICED','TEST')
		      INTO v_crm_cust_type
		       FROM DUAL;

	            -- If profile = INVOICED and class = AGENCY from crm
	            -- then switch OF profile to AGENCY.

		    SELECT decode(nvl(c1_count.customer_class_code,'X'), 'AGENCY',
			decode(v_crm_cust_type, 'INVOICED',
	                   'AGENCY', v_crm_cust_type), v_crm_cust_type)
	 	    INTO V_CUST_TYPE
		    FROM DUAL;

		    END;*/

	            --Commented on 06/15/2005
	            /*BEGIN

	              Select  MEANING into v_language
	              From FND_LOOKUP_VALUES_VL
	              Where lookup_type = 'GOTO_LANGUAGE_ID'
	              AND SYSDATE BETWEEN NVL(START_DATE_ACTIVE, SYSDATE)
	                         AND NVL(END_DATE_ACTIVE, SYSDATE)
	              AND LOOKUP_CODE = c1_count.language_id ;

	             EXCEPTION

	             WHEN NO_DATA_FOUND Then
	               v_language := 'US' ;
	             END;*/



	          -- Change the Profile class for AGENCY
	          -- at account level and collector for INVOICED and AGENCY

	       /*     IF v_cust_type in ( 'AGENCY', 'INVOICED' )  THEN

	              BEGIN

	              BEGIN
	               SELECT
	               attribute2
	               INTO
	                    v_collector
	               FROM
	               ar_collectors
	               WHERE
	               name = upper(v_org_name) ;

	              EXCEPTION
	                WHEN OTHERS THEN

	                 v_collector := NULL ;

	              END  ;


	             BEGIN

	              IF v_cust_type = 'INVOICED' THEN

	                SELECT
	                name
	                INTO
	                v_pay_term
	                FROM
	                goto_markettoorg_all a,
	                ra_terms b
	                WHERE
	                a.invoice_term_id = b.term_id
	                AND market_name = c1_count.market_name ;


	              ELSIF v_cust_type = 'AGENCY' THEN

	              SELECT
	                name
	                INTO
	                v_pay_term
	                FROM
	                goto_markettoorg_all a,
	                ra_terms b
	                WHERE
	                a.agency_term_id = b.term_id
	                AND market_name = c1_count.market_name;


	              END IF ;

	              EXCEPTION

	              WHEN OTHERS THEN

	                 v_pay_term := NULL ;
	              END ;

	            END ;

	            END IF ;*/

	            -- Do not Create profile Records at Cust level if alrady exists

	            BEGIN

	               SELECT count(*)
	               INTO   v_profile_count
	               FROM
	               ar_hcustomer_profiles a,
	               ra_hcustomers b
	               WHERE
	                   b.customer_number = c1_count.advertiser_id
	               AND a.customer_id   = b.customer_id
	               AND a.site_use_id is NULL ;

	               SELECT count(*)
	               INTO   v_profile_count1
	               FROM
	               ra_customer_profiles_int_all  a
	               WHERE
	                a.orig_system_customer_ref = 'OV-'||c1_count.advertiser_id
	               AND a.orig_system_address_ref is NULL
	               AND a.interface_status is NULL ;


	               FND_FILE.PUT_LINE(FND_FILE.LOG,'Count'||v_profile_count||'---'||v_profile_count1);

	            EXCEPTION

	            WHEN OTHERS THEN

	                 v_profile_count := 0   ;
	                 v_profile_count1 := 0  ;

	            END ;

		    IF C1_COUNT.CONTACT_STREET1 is NULL THEN
			C1_COUNT.CONTACT_STREET1 := 'TYPE HERE ADDRESS LINE 1';
		    End if;

		    IF C1_COUNT.CONTACT_COUNTRY is NULL then
			C1_COUNT.CONTACT_COUNTRY := 'US';
		    End if;

		    If Rec_count_c2 = 1 and nvl(v_ptest_flag,0) = 0
	              and c1_count.contact_invoice IN ('INVOICED','INVOICE','AGENCY') then
			V_PSite_flag := 'Y';
		    Else
			V_Psite_flag := 'N';
		    End if;

		  --  IF (c1_count.advertiser_id = v_advertiser_id AND
	          --  c1_count.mp_invoice = v_mp_invoice) THEN

		--	UPDATE  goto_customer_interface_temp
		--	SET rec_status  = 'DUPLICATED'
	        --        Where Current of rec_cust;
			/*WHERE advertiser_id  = c1_count.advertiser_id
			AND mp_invoice = c1_count.mp_invoice  ; */
		 --   ELSE
			/*
			 * Check the given country name.
	 	  	 * Updated by SCHAN ON 23,aug-99*/
	               -- Removed the code - Venky 17-Dec-01
	               /*
			select count(*) into v_count
			from goto_country_lookup
			where name=c1_count.contact_country;

			if v_count=1 then
	 			select code into v_country
				from goto_country_lookup
				where name=c1_count.contact_country;
			else
	 			v_country:=c1_count.contact_country;
			end if;
	               */

	             SELECT
	               decode(c1_count.contact_country, 'UK',
	                     'GB', c1_count.contact_country)
	             INTO v_country
	             FROM dual ;

	           BEGIN
	            fnd_file.put_line(FND_FILE.LOG,'Before if');
	         /*   IF c1_count.site_use_attribute5 IS NOT NULL
	            THEN
	            BEGIN
		                 SELECT trim(upper(description))
		   		INTO v_legal_entity
		                   FROM fnd_lookup_values_vl
		                  WHERE lookup_type = 'GOTO_LEGAL_ENTITY'
		                    AND SYSDATE BETWEEN NVL (start_date_active, SYSDATE)
		                                    AND NVL (end_date_active, SYSDATE)
		                    AND meaning = c1_count.site_use_attribute5;
		              EXCEPTION
		                 WHEN NO_DATA_FOUND THEN
		                    arp_standard.DEBUG (' EXCEPTION : goto_customer_insert');
		                    errbuf := SQLERRM;
		                    retcode := SQLCODE;
		                    ROLLBACK;
		                    fnd_file.put_line (fnd_file.LOG
		                                      ,    'Customer Number : '
		                                        || c1_count.advertiser_id
		                                        || ' Account        : '
		                                        || c1_count.mp_invoice);
		                    raise_application_error
		                                  (-20002
		                                  ,    errbuf
		                                    || '  Stage 4.  Legal Entity  Derivation Failed   ');
        	     END;
        	     END IF;*/

                    fnd_file.put_line(FND_FILE.LOG,'Before Variables');

	             v_customer_name := substrb(c1_count.contact_company,1,45) ;
	             v_city          := substrb(c1_count.contact_city,1,60) ;
	             v_state         := substrb(c1_count.contact_state,1,60) ;
	             v_county        := substrb(c1_count.county,1,60) ;
	             v_first_name    := substrb(c1_count.contact_first_name,1,35) ;
	             v_last_name     := substrb(c1_count.contact_last_name,1,49) ;
	             v_middle_initial := substrb(c1_count.contact_middle_initial,1,3) ;
	       	/*BEGIN

	             SELECT
	                gl_id_clearing,
	                gl_id_factor,
	                gl_id_freight,
	                gl_id_rec,
	                gl_id_remittance,
	                gl_id_rev,
	                gl_id_tax,
	                gl_id_unbilled,
	                gl_id_unearned,
	                gl_id_unpaid_rec,
	                set_of_books_id
	             INTO
	                v_gl_id_clearing,
	                v_gl_id_factor,
	                v_gl_id_freight,
	                v_gl_id_rec,
	                v_gl_id_remittance,
	                v_gl_id_rev,
	                v_gl_id_tax,
	                v_gl_id_unbilled,
	                v_gl_id_unearned,
	                v_gl_id_unpaid_rec,
	                v_sob
	              FROM
	                 goto_markettoorg_all
	              WHERE market_name = UPPER(c1_count.market_name);



	              IF v_legal_entity = 'IE' THEN
		         BEGIN
		              SELECT alter_company
		                INTO v_alter_company
		                FROM goto_markettoorg_all
		               WHERE market_name = c1_count.market_name;

		              SELECT chart_of_accounts_id
		                INTO v_coa
		                FROM gl_sets_of_books
		               WHERE set_of_books_id = v_sob ;

		              SELECT derive_gl (v_alter_company, v_coa, gl_id_clearing)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_factor)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_freight)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_rec)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_remittance)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_rev)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_tax)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_unbilled)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_unearned)
		                    ,derive_gl (v_alter_company, v_coa, gl_id_unpaid_rec)
		                INTO v_gl_id_clearing
		                    ,v_gl_id_factor
		                    ,v_gl_id_freight
		                    ,v_gl_id_rec
		                    ,v_gl_id_remittance
		                    ,v_gl_id_rev
		                    ,v_gl_id_tax
		                    ,v_gl_id_unbilled
		                    ,v_gl_id_unearned
		                    ,v_gl_id_unpaid_rec
		               FROM goto_markettoorg_all
		              WHERE market_name = c1_count.market_name;
		          EXCEPTION
		                WHEN OTHERS  THEN
		                     arp_standard.DEBUG
		                     (' EXCEPTION : goto_customer_insert');
		                          ROLLBACK;
		                             errbuf := SQLERRM;
		                             retcode := SQLCODE;
		                             fnd_file.put_line (fnd_file.LOG
		                                               ,    'Customer Number : '
		                                                 || c1_count.advertiser_id
		                                                 || ' Account        : '
		                                                 || c1_count.mp_invoice);
		                             raise_application_error
		                                       (-20002
		                                       ,    errbuf
		                                         || '  Stage 5.  GL CCID  Derivation Failed   ');
		          END;
		      END IF;
                    END;*/


		     v_gl_id_clearing     := NULL;
		     v_gl_id_factor       := NULL;
		     v_gl_id_freight      := NULL;
		     v_gl_id_rec          := NULL;
		     v_gl_id_remittance   := NULL;
		     v_gl_id_rev          := NULL;
		     v_gl_id_tax          := NULL;
		     v_gl_id_unbilled     := NULL;
		     v_gl_id_unearned     := NULL;
		     v_gl_id_unpaid_rec   := NULL;

		     --NULL;


		    /* Added by Sai Prasad on 05/26/2005*/

		     IF NVL(v_prev_advertiser_id,'@') = C1_COUNT.advertiser_id
		       AND NVL(v_prev_account_id,'#') = C1_COUNT.mp_invoice
		     THEN
		               		v_rec_id := v_rec_id + 1;
		     ELSE
		                     	v_rec_id := 1;
		     END IF;

		     BEGIN
		     	SELECT 'Y','N'
		     	INTO    v_rec_exists,
		     	        v_cont_exists
		     	FROM	ra_customers_interface_all
		     	WHERE   orig_system_customer_ref = 'OV-'||C1_COUNT.advertiser_id
		     	AND     orig_system_address_ref  = 'OV-'||C1_COUNT.advertiser_id||C1_COUNT.MP_INVOICE
		     	AND     interface_status IS NULL;

		     	FND_FILE.PUT_LINE(FND_FILE.LOG,'Customer Duplicate Check'||v_rec_exists);
		     EXCEPTION
		     	WHEN NO_DATA_FOUND THEN
		     		BEGIN
			     	      SELECT customer_number,
				             location,
				             'Y',
				             'N'
				      INTO   V_advertiser_id,
					     V_mp_invoice,
					     v_rec_exists,
					     v_cont_exists
				      FROM  goto_customer_info_v
				      WHERE customer_number = c1_count.advertiser_id
				      AND  location  = c1_count.mp_invoice ;
				   FND_FILE.PUT_LINE(FND_FILE.LOG,'Customer Exists'||v_rec_exists);

				EXCEPTION
				      WHEN  NO_DATA_FOUND THEN
				      	v_advertiser_id  := NULL ;
					v_mp_invoice    := NULL ;
					v_rec_exists := 'N';
					v_cont_exists := 'N';
				END;


			/*	IF v_rec_exists = 'Y'
				THEN
					BEGIN
					      SELECT 'Y'
					      INTO    v_cont_exists
					      FROM    ra_contacts
					      WHERE   orig_system_reference=(c1_count.mp_invoice||'-'||rtrim(SUBSTRb(C1_COUNT.CONTACT_PHONE,1,25))||'CON'||to_char(v_rec_id));

					      FND_FILE.PUT_LINE(FND_FILE.LOG,'CContact Check'||v_cont_exists);
					EXCEPTION
					  WHEN  NO_DATA_FOUND THEN
						v_cont_exists := 'N';
					  WHEN  TOO_MANY_ROWS THEN
					  	v_cont_exists := 'Y';
					END;
				END IF;*/
		     	WHEN TOO_MANY_ROWS THEN
		     		v_rec_exists := 'Y';
		     		v_cont_exists := 'N';
		     END;



		     IF v_rec_exists = 'N'
		     THEN

		     /* Changes Ends*/
		       FND_FILE.PUT_LINE(FND_FILE.LOG,'Customer Insert'||v_rec_exists);
		    INSERT INTO RA_CUSTOMERS_INTERFACE_ALL
		   			(orig_system_customer_ref,  --NOT NULL VARCHAR2(240)
		   			site_use_code,              --NULL     VARCHAR2(30)
		   			orig_system_address_ref,    --NULL     VARCHAR2(240)
		   			insert_update_flag,         --NOT NULL VARCHAR2(1)
		   			validated_flag,             --NULL     VARCHAR2(1)
		   			customer_status,            --NULL     VARCHAR2(1)
		   			customer_number,            --NULL     VARCHAR2(30)
		   			customer_name,              --NULL     VARCHAR2(50)
		   			customer_type,              --NULL     VARCHAR2(25)
		   			location,                   --NULL     VARCHAR2(40)
		   			address1,                   --NULL     VARCHAR2(240)
		   			address2,                   --NULL     VARCHAR2(240)
		   	                address3,
		   	                address4,
		   			city,                       --NULL     VARCHAR2(60)
		   			state,                      --NULL     VARCHAR2(60)
		   			county,                     --NULL     VARCHAR2(60)
		   			country,                    --NULL     VARCHAR2(60)
		   			postal_code,                --NULL     VARCHAR2(60)
		   			last_updated_by,            --NOT NULL VARCHAR2(15)
		   			last_update_date,           --DATE
		   			created_by,                 --NOT NULL VARCHAR2(15)
		   			creation_date,              --DATE
		   			--primary_site_use_flag,      --NULL     VARCHAR2(1)
		   			customer_class_code,        --NULL     VARCHAR2(30)
		   			demand_class_code,          --NULL     VARCHAR2(30)
		   			bill_to_orig_address_ref,
		   	                site_use_attribute1,
		   	                site_use_tax_code,
		   	                site_use_tax_reference,
		   	                org_id,
		   	                site_use_attribute3,
		   	                customer_name_phonetic,
		   	                address_lines_phonetic,
		   	                province,
		   	                customer_attribute1,
		   	                customer_attribute_category,
		   	                site_use_attribute4,
		   	                site_use_attribute5,
		   	                site_use_attribute_category,
		   	                gl_id_clearing,
		   	                gl_id_factor,
		   	                gl_id_freight,
		   	                gl_id_rec,
		   	                gl_id_remittance,
		   	                gl_id_rev,
		   	                gl_id_tax,
		   	                gl_id_unbilled,
		   	                gl_id_unearned,
		   	                gl_id_unpaid_rec,
		   	                gdf_address_attr_cat,
		   	                gdf_address_attribute11,
		   			gdf_address_attribute12,
		   	                gdf_address_attribute13,
		   	                gdf_address_attribute14,
		   	                customer_category_code,
		   	                customer_attribute15,
		   	                site_use_attribute15,
		   	                site_use_attribute2,
		   	                address_category_code,
		   	                primary_site_use_flag
		   	                )
		   		     VALUES(	'OV-'||C1_COUNT.ADVERTISER_ID,
		   			'BILL_TO',
		   			'OV-'||C1_COUNT.ADVERTISER_ID||C1_COUNT.MP_INVOICE,
		   			'I',
		   			NULL,                  -------'Y',
		   			'A',
		   			C1_COUNT.ADVERTISER_ID,
		   			rtrim(v_customer_name),
		   			'R', -- TYPE
		   			C1_COUNT.MP_INVOICE, -- LOCATION
		   			rtrim(substr(C1_COUNT.CONTACT_STREET1,1,80)),
		   			rtrim(substr(C1_COUNT.CONTACT_STREET2,1,80)),
		   	                rtrim(substr(c1_count.contact_street3,1,80)),
		   	                rtrim(substr(c1_count.contact_street4,1,80)),
		   			rtrim(v_CITY),
		   			nvl(rtrim(v_state),v_org_name),
		   			rtrim(nvl(rtrim(ltrim(v_County)),nvl(v_state,v_org_name))),
		   			rtrim(v_country), --C1_COUNT.CONTACT_COUNTRY
		   			rtrim(C1_COUNT.CONTACT_ZIP),
		   			0, --1318,
		   			SYSDATE,
		   			0, --1318,
		   			SYSDATE,
		   			--V_PSite_flag,      ----- ONLY ONE PER CUSTOMER
		   			c1_count.customer_class_code,-- class code
		   			NULL,
		   			NULL,
		   	                nvl(rtrim(upper(
		   	                substr(c1_count.site_use_attribute1,1,49) )),'NONE'),
		   	                c1_count.vat_code,
		   	                c1_count.vat_reference,
		   	                c1_count.org_id,
		   	                c1_count.language_id,
		   	                substrb(c1_count.client_name_furigana,1,100),
		   	                substrb(c1_count.account_name_furigana,1,100),
		   	                c1_count.fuken,
		   	                substrb(c1_count.contact_company,1,149),
		   	                'YSM',
		   	                c1_count.market_name,
		   	                c1_count.site_use_attribute5,
		   	                'YSM',
		   	                v_gl_id_clearing,
		   	                v_gl_id_factor,
		   	                v_gl_id_freight,
		   	                v_gl_id_rec,
		   	                v_gl_id_remittance,
		   	                v_gl_id_rev,
		   	                v_gl_id_tax,
		   	                v_gl_id_unbilled,
		   	                v_gl_id_unearned,
		   	                v_gl_id_unpaid_rec,
		   	                'JA.KR.ARXCUDCI.VAT',
		   	                c1_count.president_name,
		   	                c1_count.business_type,
		   	                c1_count.business_item,
		   	                c1_count.personal_id,
		   	                c1_count.customer_category_code,
		   	                c1_count.old_customer_id,
		   	                c1_count.old_site_use_id,
		   	                c1_count.site_use_attribute2,
		   	                c1_count.customer_category,
		   	                c1_count.primary_flag
	                );
	               END IF; --v_rec_exists = 'N'

	             EXCEPTION

	             WHEN OTHERS THEN
	                arp_standard.debug(' EXCEPTION : goto_customer_insert' ) ;
	                ROLLBACK ;
	                errbuf := sqlerrm ;
	                retcode := sqlcode ;
	                FND_FILE.put_line(FND_FILE.log,
	                   'Customer Number : ' || c1_count.advertiser_id ||
	                   ' Account        : ' || c1_count.mp_invoice ) ;
	                 RAISE_APPLICATION_ERROR(-20002, errbuf||
	                '  2.  Ra_customers Insert  Failed    ' ) ;
	             END ;


		    IF C1_COUNT.CONTACT_PHONE is NULL then
			C1_COUNT.CONTACT_PHONE := 'NO TEL NO.';
		     END IF ;

	            BEGIN


		     FND_FILE.PUT_LINE(FND_FILE.LOG,'Contact Insert'||v_cont_exists);
		     IF NVL(v_contact_id,000000009) <> c1_count.old_contact_id
		     THEN
		     	    	v_ph_id := 1;
		     	    	v_con_id := NVL(v_con_id,0) +1;
		     	    	v_orig_system_contact_ref := c1_count.mp_invoice||c1_count.old_contact_id||'CUSTCON'||to_char(v_con_id);
		     	     	v_orig_system_tel_ref :=c1_count.mp_invoice||'-'||c1_count.old_contact_id||'-'||rtrim(SUBSTRb(C1_COUNT.CONTACT_PHONE,1,25))||'CON'||to_char(v_ph_id);    ----orig_system_telephone_ref

		     ELSE
		     	     	v_ph_id := NVL(v_ph_id,0) + 1;
		     	     	v_con_id := v_con_id;
		     	     	v_orig_system_contact_ref :=c1_count.mp_invoice||c1_count.old_contact_id||'CUSTCON'||to_char(v_con_id);
		     		v_orig_system_tel_ref :=c1_count.mp_invoice||'-'||c1_count.old_contact_id||'-'||rtrim(SUBSTRb(C1_COUNT.CONTACT_PHONE,1,25))||'CON'||to_char(v_ph_id);    ----orig_system_telephone_ref

		     END IF;

		     INSERT INTO  RA_CONTACT_PHONES_INT_ALL
			(orig_system_contact_ref,         --NOT NULL VARCHAR2(240)
			orig_system_telephone_ref,        --NOT NULL VARCHAR2(240)
			orig_system_customer_ref,         --NOT NULL VARCHAR2(240)
			orig_system_address_ref,          --NOT NULL VARCHAR2(240)
			insert_update_flag,               --NOT NULL VARCHAR2(1)
			--validated_flag,
	                contact_title,                     --NULL
			contact_first_name,               --NULL     VARCHAR2(40)
			contact_last_name,                --NULL     VARCHAR2(50)
			contact_job_title,                --NULL     VARCHAR2(30)
			telephone,                        --NULL     VARCHAR2(25)
			telephone_extension,              --NULL     VARCHAR2(20)
			telephone_area_code,              --NULL     VARCHAR2(10)
			--validated_flag,                   --NULL     VARCHAR2(1)
			last_update_date,                 --DATE
			last_updated_by,                  --NOT NULL VARCHAR2(15)
			creation_date,                    --DATE
			created_by,                       --NULL     VARCHAR2(15)
			email_address,                    --NULL     VARCHAR2(240)
			telephone_type,                   --NULL     VARCHAR2(15)
	                org_id ,
	                contact_attribute_category,
	                contact_attribute1,
	                contact_attribute2,
	                contact_attribute3
	               )
		     VALUES
	               (v_orig_system_contact_ref,     ----orig_system_contact_ref
			v_orig_system_tel_ref,    ----orig_system_telephone_ref
			'OV-'||C1_COUNT.ADVERTISER_ID,           ---orig_system_customer_ref
			'OV-'||C1_COUNT.ADVERTISER_ID||C1_COUNT.MP_INVOICE,            ---orig_system_address_ref
			'I',
			--'Y',
	                substrb(c1_count.contact_title,1,29),
			rtrim(v_first_name||' '||
	                v_middle_initial),
			rtrim(v_last_name),
			NULL,
			rtrim(SUBSTRb(C1_COUNT.CONTACT_PHONE,1,25)),
			NULL,
			c1_count.area_code,
			--'Y',
			SYSDATE,
			0,--1318,
			SYSDATE,
			0, --1318,
			rtrim(c1_COUNT.CONTACT_EMAIL),
			NVL(c1_count.phone_type,'GEN'),
	                c1_count.org_id,
	                'YSM',
	                substrb(c1_count.first_name_furigana,1,149),
	                substrb(c1_count.last_name_furigana,1,149),
	                substrb(c1_count.department,1,149)
	                );

	                v_prev_advertiser_id := C1_COUNT.advertiser_id;
	                v_prev_account_id := C1_COUNT.mp_invoice;
	                v_contact_id      := C1_COUNT.old_contact_id;

	             EXCEPTION

	             WHEN OTHERS THEN
	                arp_standard.debug(' EXCEPTION : goto_customer_insert' ) ;
	                ROLLBACK ;
	                errbuf := sqlerrm ;
	                retcode := sqlcode ;
	                 FND_FILE.put_line(FND_FILE.log,
	                   'Customer Number : ' || c1_count.advertiser_id ||
	                  ' Account        : ' || c1_count.mp_invoice ) ;
	                 RAISE_APPLICATION_ERROR(-20003, errbuf||
	                '3.  Ra_contacts Insert  Failed    ' );
	             END ;

		  /* Added by Sai Prasad on 05/26/2005*/

		  IF v_rec_exists = 'N'
		   THEN
		  /* Changes Ends*/

		    FND_FILE.PUT_LINE(FND_FILE.LOG,'PRFOILES Insert'||v_rec_exists);
		    IF Rec_count_c2 = 1 Then

	                IF nvl(v_profile_count,0) = 0 AND
	                   nvl(v_profile_count1,0) = 0 THEN


		        INSERT INTO RA_CUSTOMER_PROFILES_INT_ALL
					(insert_update_flag,        --NULL     VARCHAR2(1)
					--validated_flag,           --NULL     VARCHAR2(1)
					orig_system_customer_ref,   --NOT NULL VARCHAR2(240)
					--orig_system_address_ref,     --NULL     VARCHAR2(240)
					customer_profile_class_name,  --NULL     VARCHAR2(30)
					last_updated_by,            --NULL     VARCHAR2(15)
					last_update_date,           --DATE
					creation_date,              --DATE
					credit_hold,                --NOT NULL VARCHAR2(1)
					created_by,                 --NULL     VARCHAR2(15)
					currency_code,              --NULL VARCHAR2(15)
	                                org_id,
	                                standard_term_name,
	                                collector_name,
	                                override_terms,
	                                discount_terms,
					statements ,
					credit_balance_statements ,
					statement_cycle_name      ,
					dunning_letters           ,
					dunning_letter_set_name,
					cons_inv_flag             ,
					cons_inv_type             ,
					interest_rate             ,
					max_interest_charge       ,
					min_fc_balance_amount     ,
					min_fc_invoice_amount     ,
					auto_rec_min_receipt_amount,
					min_statement_amount       ,
					min_dunning_amount         ,
					min_dunning_invoice_amount ,
					trx_credit_limit           ,
					overall_credit_limit )
				VALUES('I',
					--'Y',
					'OV-'||C1_COUNT.ADVERTISER_ID,
					--c1_count.MP_INVOICE,
					c1_count.cust_payment_type,
					0,
					sysdate,
					sysdate,
					'N',
					0,
					c1_count.cust_currency_code,
					c1_count.Org_id,
					c1_count.cust_terms_name,
					c1_count.cust_collector_name,
					c1_count.cust_override_terms,
					c1_count.cust_discount_terms,
					c1_count.cust_statements,
					c1_count.cust_credit_balance_stmts,
					c1_count.cust_stmt_cycle_name,
					c1_count.cust_dunning_letters,
					c1_count.cust_dunning_letters_set,
					c1_count.cust_cons_inv_flag,
					c1_count.cust_cons_inv_type,
					c1_count.cust_interest_rate,
					c1_count.cust_max_interest_charge,
					c1_count.cust_minfc_balance_amt,
					c1_count.cust_minfc_invoice_amt,
					c1_count.cust_auto_rec_minrcpt_amt,
					c1_count.cust_min_stmt_amt,
					c1_count.cust_min_dunning_amt,
					c1_count.cust_min_dunning_inv_amt,
					c1_count.cust_trx_credit_limit ,
					c1_count.cust_overall_credit_limit);
	                  END IF ;

	                      INSERT INTO RA_CUSTOMER_PROFILES_INT_ALL
	                                (insert_update_flag,        --NULL     VARCHAR2(1)
	                                --validated_flag,           --NULL     VARCHAR2(1)
	                                orig_system_customer_ref,   --NOT NULL VARCHAR2(240)
	                                orig_system_address_ref,     --NULL     VARCHAR2(240)
	                                customer_profile_class_name,  --NULL     VARCHAR2(30)
	                                last_updated_by,            --NULL     VARCHAR2(15)
	                                last_update_date,           --DATE
	                                creation_date,              --DATE
	                                credit_hold,                --NOT NULL VARCHAR2(1)
	                                created_by,                 --NULL     VARCHAR2(15)
	                                currency_code,              --NULL VARCHAR2(15)
	                                org_id ,
	                                standard_term_name,
	                                collector_name,
	                                override_terms,
	                                discount_terms,
					statements ,
					credit_balance_statements ,
					statement_cycle_name      ,
					dunning_letters           ,
					dunning_letter_set_name,
					cons_inv_flag             ,
					cons_inv_type             ,
					interest_rate             ,
					max_interest_charge       ,
					min_fc_balance_amount     ,
					min_fc_invoice_amount     ,
					auto_rec_min_receipt_amount,
					min_statement_amount       ,
					min_dunning_amount         ,
					min_dunning_invoice_amount ,
					trx_credit_limit           ,
					overall_credit_limit )
	                        VALUES('I',
	                                --'Y',
	                                'OV-'||C1_COUNT.ADVERTISER_ID,
	                                'OV-'||C1_COUNT.ADVERTISER_ID||C1_COUNT.MP_INVOICE,
	                                c1_count.contact_invoice,
	                                0,
	                                sysdate,
	                                sysdate,
	                                'N',
	                                0,
	                                c1_count.site_currency_code,
	                                c1_count.Org_id,
	                                c1_count.site_terms_name,
	                                c1_count.site_collector_name,
	                                c1_count.site_override_terms,
					c1_count.site_discount_terms,
					c1_count.site_statements,
					c1_count.site_credit_balance_stmts,
					c1_count.site_stmt_cycle_name,
					c1_count.site_dunning_letters,
					c1_count.site_dunning_letters_set,
					c1_count.site_cons_inv_flag,
					c1_count.site_cons_inv_type,
					c1_count.site_interest_rate,
					c1_count.site_max_interest_charge,
					c1_count.site_minfc_balance_amt,
					c1_count.site_minfc_invoice_amt,
					c1_count.site_auto_rec_minrcpt_amt,
					c1_count.site_min_stmt_amt,
					c1_count.site_min_dunning_amt,
					c1_count.site_min_dunning_inv_amt,
					c1_count.site_trx_credit_limit ,
					c1_count.site_overall_credit_limit);

		   ELSE
			INSERT INTO RA_CUSTOMER_PROFILES_INT_ALL
					(insert_update_flag,        --NULL     VARCHAR2(1)
					--validated_flag,           --NULL     VARCHAR2(1)
					orig_system_customer_ref,   --NOT NULL VARCHAR2(240)
					orig_system_address_ref,     --NULL     VARCHAR2(240)
					customer_profile_class_name,  --NULL     VARCHAR2(30)
					last_updated_by,            --NULL     VARCHAR2(15)
					last_update_date,           --DATE
					creation_date,              --DATE
					credit_hold,                --NOT NULL VARCHAR2(1)
					created_by,                 --NULL     VARCHAR2(15)
					currency_code,              --NULL VARCHAR2(15)
	                                org_id ,
	                                standard_term_name,
	                                collector_name,
	                                override_terms,
	                                discount_terms,
					statements ,
					credit_balance_statements ,
					statement_cycle_name      ,
					dunning_letters           ,
					dunning_letter_set_name,
					cons_inv_flag             ,
					cons_inv_type             ,
					interest_rate             ,
					max_interest_charge       ,
					min_fc_balance_amount     ,
					min_fc_invoice_amount     ,
					auto_rec_min_receipt_amount,
					min_statement_amount       ,
					min_dunning_amount         ,
					min_dunning_invoice_amount ,
					trx_credit_limit           ,
					overall_credit_limit )
				VALUES('I',
					--'Y',
					'OV-'||C1_COUNT.ADVERTISER_ID,
					'OV-'||C1_COUNT.ADVERTISER_ID||C1_COUNT.MP_INVOICE,
					c1_count.contact_invoice,
					0, --1318,
					sysdate,
					sysdate,
					'N',
					0, --1318,
					c1_count.site_currency_code,
					c1_count.org_id ,
	                                c1_count.site_terms_name,
	                                c1_count.site_collector_name,
	                                c1_count.site_override_terms,
					c1_count.site_discount_terms,
					c1_count.site_statements,
					c1_count.site_credit_balance_stmts,
					c1_count.site_stmt_cycle_name,
					c1_count.site_dunning_letters,
					c1_count.site_dunning_letters_set,
					c1_count.site_cons_inv_flag,
					c1_count.site_cons_inv_type,
					c1_count.site_interest_rate,
					c1_count.site_max_interest_charge,
					c1_count.site_minfc_balance_amt,
					c1_count.site_minfc_invoice_amt,
					c1_count.site_auto_rec_minrcpt_amt,
					c1_count.site_min_stmt_amt,
					c1_count.site_min_dunning_amt,
					c1_count.site_min_dunning_inv_amt,
					c1_count.site_trx_credit_limit ,
					c1_count.site_overall_credit_limit) ;
		   END IF;

		  /* Added by Sai Prasad on 05/26/2005*/

		  END IF; --v_rec_exists = 'N'

		  /* Changes Ends*/


	           FND_FILE.put_line(FND_FILE.output,
	                   'Customer Number : ' || c1_count.advertiser_id ||
	                    ' Account        : ' || c1_count.mp_invoice ) ;

		   IF v_rec_exists = 'Y' and v_cont_exists = 'Y'
		   THEN
		   	  UPDATE  xxyh_customer_interface_temp
			      SET rec_status  = 'DUPLICATED'
		   	  Where Current of rec_cust;
		   ELSE
	           	UPDATE xxyh_customer_interface_temp
		   	SET REC_STATUS = 'TRANSFERED'
	           	Where Current of rec_cust;
			/*	WHERE ADVERTISER_ID = C1_COUNT.ADVERTISER_ID
				AND MP_INVOICE = C1_COUNT.MP_INVOICE ;*/
		  END IF;
		 Last_advid := c1_count.advertiser_id;
		 V_advertiser_id := NULL ;
		 V_mp_invoice    := NULL ;
		 V_CUST_TYPE     := NULL ;


		/*IF v_rec_cnt = 50000
		 THEN

		 	v_rec_cnt := 1;
		 	EXIT;


		ELSE
		        v_rec_cnt := v_rec_cnt + 1;
		END IF;   */


	       END LOOP;

	      -- IF v_cur_opened = 'Y'
	      -- THEN
	      /* x_req_id := fnd_request.submit_request(
	       			                  'AR',
	       			                  'RACUST',
	       			                  '',
	       			                  '',
	       			                  FALSE,
	       			                  'N');*/

	       COMMIT;
	       /* v_Request_Status_B 	:=	FND_CONCURRENT.WAIT_FOR_REQUEST
	       					(REQUEST_ID => x_Req_ID,
	       					 INTERVAL => 2,
	       					 MAX_WAIT => 0,
	       					 PHASE => v_Request_Phase,
	       					 STATUS => v_Request_Status,
	      					 DEV_PHASE => v_Dev_Request_Phase,
	       					 DEV_STATUS => v_Dev_Request_Status,
	       					 MESSAGE => v_Request_Message
	       					 );*/

	        fnd_file.put_line(fnd_file.log,'Near Label');
	      -- goto Exec_Cursor;
	      --  END IF;

	        --  Below added on Jul 13 to handle customer numbering change

	        --UPDATE  ra_customers_interface_all
	        --SET customer_number=orig_system_customer_ref
	        --WHERE interface_status is null;



	     FND_FILE.put_line(FND_FILE.output, '==============================') ;

	     FND_FILE.put_line(FND_FILE.output,
	                 ' Done With The Customer Insert Process     ' ||
	                 to_char(sysdate, 'DD-MON-YYYY HH24:MI:SS') ) ;

	     EXCEPTION

	      WHEN OTHERS THEN
	         --   arp_standard.debug(' EXCEPTION : goto_customer_insert' ) ;
	     --       ROLLBACK ;
	            errbuf := sqlerrm ;
	            retcode := sqlcode ;
	            fnd_file.put_line(FND_FILE.LOG,'Errored out for'||SQLERRM||'-'||v_client_id||'-'||v_acct_id);
	           -- RAISE_APPLICATION_ERROR(-20004, errbuf||
	           --     '  $Customer Insert  Failed    ' );


     END  xxyh_customer_insert_new;

     FUNCTION derive_gl (l_alter_company IN VARCHAR2,
                            l_coa           IN NUMBER,
                            l_gl_id         IN NUMBER)
           RETURN NUMBER
        IS
           v_segment1   VARCHAR2 (10) := NULL;
           v_segment2   VARCHAR2 (10) := NULL;
           v_segment3   VARCHAR2 (10) := NULL;
           v_segment4   VARCHAR2 (10) := NULL;
           v_segment5   VARCHAR2 (10) := NULL;
           v_segment6   VARCHAR2 (10) := NULL;
           v_segment7   VARCHAR2 (10) := NULL;
           l_result     NUMBER        := NULL;
        BEGIN
           SELECT segment1
                 ,segment2
                 ,segment3
                 ,segment4
                 ,segment5
                 ,segment6
                 ,segment7
             INTO v_segment1
                 ,v_segment2
                 ,v_segment3
                 ,v_segment4
                 ,v_segment5
                 ,v_segment6
                 ,v_segment7
             FROM gl_code_combinations
            WHERE code_combination_id  = l_gl_id ;

           SELECT code_combination_id
             INTO l_result
             FROM gl_code_combinations
            WHERE segment1 = l_alter_company
              AND segment2 = v_segment2
              AND segment3 = v_segment3
              AND segment4 = v_segment4
              AND segment5 = v_segment5
              AND segment6 = v_segment6
              AND NVL (segment7, 'x') = NVL (v_segment7, 'x')
              AND chart_of_accounts_id = l_coa ;

           RETURN (l_result);
        EXCEPTION
           WHEN OTHERS  THEN
            --  fnd_file.put_line(fnd_file.LOG,l_gl_id) ;
              RETURN NULL;
            --  raise ;
    END derive_gl;
 END XXYH_CUSTOMER_INTERFACE_PKG;
/

