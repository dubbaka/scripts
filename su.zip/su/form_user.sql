SELECT a.USER_NAME, K.PID, s.sid, s.serial#, s.machine, TO_CHAR(K.start_time,'DD-MON-YYYY HH24:MI:SS') Start_Time, TO_CHAR(S.logon_time,'DD-MON-YYYY HH24:MI:SS') Login
FROM APPS.FND_LOGINS K, GV$SESSION S,GV$PROCESS P, APPS.FND_USER A,
     (select max(start_time) start_time,pid
     from apps.fnd_logins group by pid) L
where k.PID = L.PID
and   k.start_time = l.start_time
and   p.pid = k.pid
and   s.paddr = p.addr
and   a.user_id = k.user_id
and k.end_time IS NULL
/
