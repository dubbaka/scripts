set lines 132
set pagesize 1000
column  	sid format 99999
column		event format a25 word_wrapped
column		module format a15 word_wrapped
column      username format a9 word_wrapped
column      seconds_in_wait format 999999 word_wrapped
select b.sid, b.event, substr(a.action,1,1)||'-'||a.module module , a.username ,
      b.p1, b.p2,b.p3 ,b.seconds_in_wait from v$session_wait b, v$session  a
where event not in ('SQL*Net message from client','rdbms ipc message',
'pmon timer','smon timer', 'pipe get')
  and a.sid  = b.sid
order by b.seconds_in_wait
/
