col Object format a36
col type format a10
col Locker format a10
SELECT
 SESSION_ID "SID",
 OWNER||'.'||OBJECT_NAME "Object",
  ORACLE_USERNAME "Locker",
-- mysessf(lockwait) "Wait",
lockwait "Wait",
  DECODE(LOCKED_MODE,
    2, 'ROW SHARE',
    3, 'ROW EXCLUSIVE',
    4, 'SHARE',
    5, 'SHARE ROW EXCLUSIVE',
    6, 'EXCLUSIVE',  'UNKNOWN') "Lockmode",
  OBJECT_TYPE "Type",
  c.ROW_WAIT_ROW#
 -- PROGRAM "Program"
FROM
  SYS.V_$LOCKED_OBJECT A,
  SYS.ALL_OBJECTS B,
  SYS.V_$SESSION c
WHERE
  A.OBJECT_ID = B.OBJECT_ID AND
  C.SID = A.SESSION_ID
--  and c.sid = '&sid'
ORDER BY 1 ASC, 5 Desc
/
