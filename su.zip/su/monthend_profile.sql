alter table xxyh.goto_month_end_profile move;
alter index xxyh.GOTO_MONTH_END_PROFILE_NN1 rebuild;
alter index xxyh.GOTO_MONTH_END_PROFILE_NN2 rebuild;
alter index xxyh.GOTO_MONTH_END_PROFILE_NN3 rebuild;
alter index xxyh.GOTO_MONTH_END_PROFILE_NN4 rebuild;
alter index xxyh.GOTO_MONTH_END_PROFILE_NN5 rebuild;
alter index xxyh.GOTO_MONTH_END_PROFILE_NN6 rebuild;
alter index xxyh.GOTO_MONTH_END_PROFILE_N7 rebuild;

analyze table xxyh.goto_month_end_profile compute statistics ;

analyze index xxyh.GOTO_MONTH_END_PROFILE_NN1 compute statistics ;
analyze index xxyh.GOTO_MONTH_END_PROFILE_NN2 compute statistics ;
analyze index xxyh.GOTO_MONTH_END_PROFILE_NN3 compute statistics ;
analyze index xxyh.GOTO_MONTH_END_PROFILE_NN4 compute statistics ;
analyze index xxyh.GOTO_MONTH_END_PROFILE_NN5 compute statistics ;
analyze index xxyh.GOTO_MONTH_END_PROFILE_NN6 compute statistics ;
analyze index xxyh.GOTO_MONTH_END_PROFILE_N7 compute statistics ;

