set head on
set lines 200
column program_description format a80 word_wrapped

SELECT b.request_id, b.program_description
FROM FND_CONCURRENT_QUEUES_VL a, FND_CONCURRENT_WORKER_REQUESTS b
WHERE a.enabled_flag='Y'
AND  a.concurrent_queue_id = b.concurrent_queue_id
AND  (b.Phase_Code = 'P' OR b.Phase_Code = 'R') AND b.hold_flag != 'Y'
AND  b.Requested_Start_Date <= SYSDATE
AND  1=1
and a.user_concurrent_queue_name like 'Inventory Manager'
--AND ('' IS NULL OR ('' = 'B' AND b.PHASE_CODE = 'R' AND b.STATUS_CODE IN ('I', 'Q')))
/
