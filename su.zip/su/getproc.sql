select spid from v$process where addr =
		(select paddr from v$session where sid =&sessionid)
/
