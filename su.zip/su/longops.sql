COLUMN sid FORMAT 99999
set lines 300
COLUMN serial# FORMAT 9999999
COLUMN machine FORMAT A40
COLUMN progress_pct FORMAT 99999999.00
COLUMN elapsed FORMAT A10
COLUMN remaining FORMAT A10

SELECT s.inst_id,s.sid,
       s.serial#,
       s.machine,
       ROUND(sl.elapsed_seconds/60) || ':' || MOD(sl.elapsed_seconds,60) elapsed,
       ROUND(sl.time_remaining/60) || ':' || MOD(sl.time_remaining,60) remaining,
       ROUND(sl.sofar/sl.totalwork*100, 2) progress_pct,
       s.event
FROM   gv$session s,
       gv$session_longops sl
WHERE  s.sid     = sl.sid
AND    s.serial# = sl.serial#
and    sl.time_remaining > 0
AND    S.EVENT NOT IN ('SQL*Net message from client','PL/SQL lock timer','rdbms ipc message');
