set echo on
SELECT MRP_AP_REFRESH_S.NEXTVAL FROM DUAL
/
truncate table MRP.MLOG$_MRP_FORECAST_DATES 
/
exec dbms_snapshot.refresh('MRP.MRP_FORECAST_DATES_SN','C')
/
