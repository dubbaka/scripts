create table core_user_list as
 SELECT  distinct user_name
 FROM
 applsys.fnd_user f,
 FND_USER_RESP_GROUPS x,
 fnd_application_tl y
 WHERE
 f.user_id = x.user_id and
 y.application_id = x.responsibility_application_id
 and f.PERSON_PARTY_ID >0
 and f.EMPLOYEE_ID is not null
 and (f.END_DATE is NULL or  f.end_date >= sysdate)
 and exists (select RESPONSIBILITY_ID,RESPONSIBILITY_name from fnd_RESPONSIBILITY_tl t where RESPONSIBILITY_name not like '%Internet%'
             and RESPONSIBILITY_name not like '%Workflow%' and RESPONSIBILITY_name not like '%Notifications%'  and RESPONSIBILITY_name not like '%Expense%'               and  RESPONSIBILITY_name not like '%iProcure'
             and RESPONSIBILITY_name not like '%Self%Serv%' and t.responsibility_id = x.responsibility_id)
/


create table all_user_list as
SELECT  distinct f.user_name
FROM
applsys.fnd_user f,
FND_USER_RESP_GROUPS x,
fnd_responsibility_tl r
WHERE
f.user_id = x.user_id and
r.responsibility_id  = x.responsibility_id
and f.EMPLOYEE_ID is not null
and (f.END_DATE is NULL or  f.end_date >= sysdate)
and (r.responsibility_name like '%Employee%Self%')
/


create table sswa_user_list as 
select user_name from all_user_list
minus
select user_name from core_user_list; 
