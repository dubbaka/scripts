update fnd_concurrent_Requests
set phase_Code='C' , status_code='X'
where request_id=&req_id;
