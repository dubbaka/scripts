column dt format a15
column  name format a20
SELECT to_char(sysdate,'DDMMYYYYHH24MISS') dt,l.latch#, n.name, h.pid,
            l.gets, l.misses,
             l.immediate_gets, l.immediate_misses, l.sleeps
     FROM    v$latchname n, v$latchholder h, v$latch l
     WHERE   l.latch# = n.latch#
     AND     l.addr = h.laddr(+)
/
 
