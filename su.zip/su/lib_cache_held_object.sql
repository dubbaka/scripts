select kglnaown "owner",kglnaobj "object" from x$kglob   where kglhdadr=(select p1raw from 
 v$session_wait where event='%library cache pin%');
