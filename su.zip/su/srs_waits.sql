select sid,event,seconds_in_wait from  v$session_wait where event not in ('SQL*Net message from client','rdbms ipc message','wakeup time manager','pmon timer');
