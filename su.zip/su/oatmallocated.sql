select tablespace_name,trunc(sum(bytes)/1024/1024/1024) from dba_data_files where TABLESPACE_NAME like 'APPS_TS%' or TABLESPACE_NAME like '%NEW' group by TABLESPACE_NAME
/
