set linesize 100
set pagesize 100
col user_name forma a10
col description forma a10
col stime forma a20
col sid_no forma 999999
col machine forma a10
col module forma a10
col program forma a10
select a.user_name user_name,
       a.description description,
       to_char(b.start_time,'DD-MON-YYYY HH24:MI') stime,
       s.sid sid_no, 
       s.machine machine,
       s.terminal terminal,
       s.module  module,
       s.program  program,
       login_type
from fnd_user a, fnd_logins b, v$session s
where a.user_id = b.user_id
and b.end_time is null
and b.start_time > trunc(sysdate) - 1
and s.process = b.spid
and s.sid = '&sid_id'
/
