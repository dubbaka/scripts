column ssid format 9999 heading SID
column opname format a15 Heading Operation
column target format a28 Heading Target
column es format 999.9 Heading "Time|Ran"
column tr Heading 9999.9 "Time|Left"
column pct format 990 Heading "PCT"
column RATE Heading "I/O |Rate/m" just right
select 
sid ssid, 
substr(OPNAME,1,15) opname,
target, 
trunc((sofar/totalwork)*100) pct, 
to_char(60*sofar*8192/(24*60*(last_update_time - start_time))/1024/1024/60, '9999.0')||'M' Rate,
elapsed_seconds/60 es,
time_remaining/60 tr
from v$session_longops 
where time_remaining > 0
order by start_time
/
