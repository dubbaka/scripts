set lines 200
col owner for a30
col object_name for a30
col object_type for a10
select owner,object_name,object_Type,to_char(start_date,'DD-MON-YYYY HH24:MI:SS'),TO_CHAR(END_DATE,'DD-MON-YYYY HH24:MI:SS') ,execution_mode,(end_date-start_date)*24*60*60 from apps.fnd_ts_mig_cmds WHERE MIGRATION_STATUS='SUCCESS' and object_type in ('INDEX','TABLE') and (end_date-start_date)*24*60*60 >= 0  and end_date is not null and end_date > '29-MAR-2013' ORDER BY 6,7
/
