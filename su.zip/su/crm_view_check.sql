select * from GOTO_CRM_PMT_SCHED_V where account like '1276259525'
select OF_ACCOUNT_ID from goto_of_account_id_v where ACCOUNT_ID='22866254887';
