set pages 1000
set lines 150
col sid format 99999
col event format a25
col module format a35 
col username format a15
col p1 format 99999999999
col p2 format 9999999999
col seconds_in_wait format 999999
 
select b.sid, b.event, a.action||'-'||a.module module , a.username ,
      b.p1, b.p2,b.p3 ,b.seconds_in_wait from gv$session_wait b, gv$session  a 
where b.event not in ('slave wait','SQL*Net message from client','rdbms ipc message', 'pmon timer','smon timer', 'pipe get')
  and a.sid  = b.sid
  and a.inst_id=b.inst_id
  order by b.seconds_in_wait
/
