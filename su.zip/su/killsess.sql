
set serveroutput on
--set heading off
DECLARE
CURSOR get_ps  IS
   SELECT distinct sid,serial# from v$session 
   where sid in (&1);

ps  get_ps%ROWTYPE;

sql_cmd       VARCHAR2(1000);
sql_cur       INTEGER;
sql_row_cnt   INTEGER;

BEGIN 
  
    sql_cur := dbms_sql.open_cursor;

    OPEN get_ps;
    LOOP

       FETCH get_ps INTO ps;
       EXIT WHEN get_ps%NOTFOUND;
       
         dbms_output.put_line ('Killing session '||ps.sid||','||ps.serial#);
         sql_cmd := 'ALTER SYSTEM KILL SESSION ' ||''''||ps.sid||','|| ps.serial#||'''';
        -- dbms_output.put_line ( sql_cmd ); 
         dbms_sql.parse ( sql_cur , sql_cmd , dbms_sql.v7 );
         sql_row_cnt := dbms_sql.execute ( sql_cur );
         dbms_output.put_line ( sql_cmd ); 

    END LOOP;

    EXCEPTION 
    
      WHEN NO_DATA_FOUND THEN
        dbms_sql.close_cursor ( sql_cur );

END; 
/
