set lines 200
col program for a40
col machine for a40
SELECT s.sid, s.serial#, s.username, s.osuser, p.spid, s.machine, p.terminal, s.program,s.process,to_char(logon_time,'DD-MON-YYYY HH24:MI'),LAST_CALL_ET,status FROM v$session s, v$process p WHERE s.paddr = p.addr and sid = &sid
/
