
select blocks  HWM,empty_blocks  Space_allocated_above_HWM from dba_tables where table_name='&tab_name' and owner='&tab_owner';

SELECT COUNT (DISTINCT SUBSTR(rowid,1,15)) "Actual used_blocks"  from "&tab_owner"."&tab_name" ;
