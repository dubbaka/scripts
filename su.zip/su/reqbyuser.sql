select r.request_id,phase_code,status_code,f.user_name
from fnd_concurrent_requests r, fnd_user f
where r.REQUESTED_BY=f.user_id
and r.phase_code in ('P','R')
and f.user_name='&i';
