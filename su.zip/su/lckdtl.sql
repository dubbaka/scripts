REM ==============================================================================================================================
REM This script will list the locking session details with wait event information
REM 
REM  Modified script of lck1.sql  by Abhay
REM
REM Sample output 
REM SESS           ID1       ID2      LMODE  REQ TYPE Module                         EVENT           SECONDS_IN_WAIT STATUS
REM -------- --------- --------- ---------- ---- ---- ------------------------------ --------------- --------------- ----------
REM 112        1769521    242897          6    0 TX   Proc-5392Serial 5230 SPID-     enqueue                 0       ACTIVE
REM                                                   5395 Mod-
REM 
REM -->2140    1769521    242897          0    6 TX   Proc-2580Serial 10189 SPID-    enqueue                 64      ACTIVE
REM                                                   2660 Mod-
REM 
REM 2018     #########         0          6    0 UL   Proc-17140Serial 6374 SPID-    SQL*Net                 13      INACTIVE
REM                                                   29789 Mod-                     message from
REM ===============================================================================================================================
set feedback on
set lines 132
column sess format a8 word_wrapped
column id1   format 99999999
column id2   format 99999999
column req	 format 999
column type  format a4
column event format a15 word_wrapped
column seconds_in_wait format 999999
column status format a10
column "Module" format a30 word_Wrapped
SELECT lpad('-->',DECODE(vl.request,0,0,5),' ')||vl.sid sess
       , vl.id1
       , vl.id2
       , vl.lmode
       ,  vl.request req, vl.type, sanj_sessf(vl.sid) "Module"
       , sw.event event, sw.seconds_in_wait, s.status
FROM V$LOCK vl, v$session_wait sw, v$session s
 WHERE vl.id1 IN (SELECT id1 FROM V$LOCK WHERE lmode = 0)
  and vl.sid = sw.sid
  and vl.sid = s.sid
 ORDER BY id1,request
/
