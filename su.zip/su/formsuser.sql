col action for a40
set lines 300
select to_char(logon_time,'DD-MON-YYYY HH24:MI:SS'),action,module,status,process,machine from v$session  where action like 'FRM%' and action like '%&USERNAME%' order by 1;
