set pagesize 132
col USER_CONCURRENT_QUEUE_NAME format a40
col MAX_PROCESSES format 99999
SELECT USER_CONCURRENT_QUEUE_NAME,MAX_PROCESSES,MANAGER_TYPE 
FROM FND_CONCURRENT_QUEUES_VL 
WHERE enabled_flag='Y'  
order by Decode(application_id, 0, Decode(concurrent_queue_id, 1, 1, 4, 2)), 
sign(max_processes) desc, concurrent_queue_name, application_id
/
