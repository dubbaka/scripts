set pau off
set feedback off
set term off
set lines 132 
set pages 400
set head on

col patch_name heading 'PATCH NUMBER' format a25
col CREATION_DATE heading 'CREATION_DATE' format 9999999.9
col DRIVER_FILE_NAME heading 'DRIVER_FILE_NAME' format a20
spool &1
break on report
select to_char(sysdate,'DD-MON-YYYY:HH:MI:SS') "Date" from dual;
select	PATCH_NAME,
      	a.CREATION_DATE,
      	b.DRIVER_FILE_NAME
from    apps.AD_APPLIED_PATCHES a ,
       	apps.AD_PATCH_DRIVERS b
where   a.APPLIED_PATCH_ID=b.APPLIED_PATCH_ID
and 	a.CREATION_DATE > sysdate - 91
   order by 2 desc


/
spool off
/
exit
/
