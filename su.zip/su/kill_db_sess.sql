set pagesize 9999
set heading off
set feedback off
spool /tmp/kds.sql
select 'alter system kill session '||''''||sid||','||serial#||''';' 
   from v$session
  where type='USER'
and floor(last_call_et/3600) > 12
and status = 'INACTIVE'
and username not in ('DBSNMP')
and action like 'Online%'  
order by last_call_et
/
spool off
