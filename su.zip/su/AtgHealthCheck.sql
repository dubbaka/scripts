undefine v_headerinfo
Define   v_headerinfo     =  '$Header:  AtgHealthCheck.sql 1.5 03-APR-04 support $'
undefine v_scriptlongname
Define   v_scriptlongname = 'R11.5 Accounting Health Check'
REM   
REM   ========================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM    Oracle Support Services.  All rights reserved.
REM   ========================================================
REM    PURPOSE:		  Display accounting data corruption.
REM    PRODUCT:           501 - Oracle Payables
REM    PRODUCT VERSIONS:  11.5
REM    PLATFORM:          Generic
REM    PARAMETERS:        Last Updated Date - Enter a date to exclude data created/updated before this date.
REM				  Problem Details - Enter Y if you want to display the detail line data for the problems.
REM                       Max Rows - Enter the number for the max number of rows to be returned.
REM
REM
REM

REM   =======================================================
REM   USAGE: 	This script should be run in SQLplus in APPS Schema
REM   EXAMPLE: 	in the SQL prompt execute :SQL>@c:\filepath\AtgHealthCheck.sql
REM   OUTPUT:     The output will be spooled to filename AtgHealthCheck_MMDD24HHMI.txt
REM   =======================================================

REM   =======================================================
REM   CHANGE HISTORY:
REM   DATE	Modifications (In order changes were made)
REM   20-JAN-04	Created
REM   01-FEB-04 Updated error messaging
REM   30-MAR-04 Updated date formatting
REM   03-APR-4  Fix some discrepancies in the detail and summary totals
REM   =======================================================

REM  ==============SQL PLUS Environment setup===================
set serveroutput on size 1000000
set autoprint off
set verify off
set echo off

REM ============== Define SQL Variables for input parameters =============
undefine v_last_updated
undefine v_prob_details
undefine v_max_rows
variable l_details varchar2(240);
variable l_prob_details varchar2(1);
variable l_last_updated varchar2(30);
variable p_continue varchar2(1);

Prompt
Prompt Show data created/updated on or after (DD-MON-YYYY)?: 
accept v_last_updated date Prompt 'Press Enter to show All>' default 01-JAN-1959
define v_last_updated = &v_last_updated
Prompt

Prompt
Prompt Display problem details (Y or N)?
accept v_prob_details Prompt 'Default=Y>' default Y
prompt

prompt
Prompt Max rows returned?
accept v_max_rows prompt 'Default = 250> ' default 250
prompt



REM ============ Spooling the output file====================

--Get the Date and Time

set term off

COLUMN TODAY NEW_VALUE v_date
SELECT TO_CHAR(SYSDATE, 'MMDDHH24MI') TODAY
from sys.dual;

set term on

Prompt
Prompt Running...
Prompt

define outputfilename = APAtgHealthCheck_&v_date..txt

spool  &outputfilename



REM =================Run the Pl/SQL api file ===================================

@@CoreApiTxtX.sql
begin  -- begin1

declare --declare 2

p_username varchar2(100);

p_respid number;

/* ------------------------ Declare Section -----------------------------*/

begin  --begin2

Show_Header('', 'AP Accounting Health Check');

/* -------------------- Execution secion ------------------------------- */

Declare  --declare 3

disp_lengths 	lengths;		
col_headers  	headers;

l_exception		exception;
l_error_msg		varchar2(500);
l_count 		NUMBER;
SqlTxt			varchar2(5000);
SqlTxt2			varchar2(5000);
l_cursor		integer;
l_max_rows		number := &v_max_rows;
l_counter	integer;
l_num1		number;
l_num2		number;
l_num3		number;
l_num4		number;
l_num5		number;
l_var1		varchar2(80);
l_var2		varchar2(80);
l_var3		varchar2(80);
l_var4		varchar2(80);
l_var5		varchar2(80);
l_ntest1	number;
l_ntest2	number;
l_ntest3	number;
l_ntest4	number;
l_ntest5	number;
l_vtest1	varchar2(80);
l_vtest2	varchar2(80);
l_vtest3	varchar2(80);
l_vtest4	varchar2(80);
l_vtest5	varchar2(80);
l_date1		date;
l_date2		date;
l_date3		date;
l_date4		date;
l_date5		date;
l_patch_level   varchar2(10);
l_last_updated  date;

Begin  --begin 3

:p_continue := 'N';

--Verify valid date

begin

l_last_updated := to_date('&v_last_updated', 'DD-MON-YYYY');

:p_continue := 'Y';

exception when others then

brprint;
errorPrint('Invalid date entered');
actionerrorprint('Please enter a valid date, DD-MON-YYYY');
brprint;


end;


if :p_continue <> 'Y' then

raise l_exception;

end if;


:l_prob_details := upper('&v_prob_details');

sqlTxt := 'select nvl(max(patch_level),''NA'') from fnd_product_installations where application_id = 200';

execute immediate sqltxt into l_patch_level;

brprint;
sectionprint('AP Patch Level: '||l_patch_level);

sectionprint('Parameter Information');
tab0print('Created/Updated On or After: '||l_last_updated);
tab0print('Show Details: '||:l_prob_details);
tab0print('Max Rows: '||l_max_rows);
brprint;


l_ntest1 := 0;


brprint;
SectionPrint('Accounting Event Status = ACCOUNTED and Posted Flag <> Y');
brprint;

sqltxt := 'select aea.org_id, aea.event_type_code, aea.event_status_code, count(*)'
||' from ap_accounting_events_all aea'
||' where aea.event_status_code like ''%ACCOUNTED%'''
||' and aea.last_update_date >='''||l_last_updated||''''
||' and exists'
||' (select 1'
||' from ap_invoice_distributions_all aid'
||' where aid.accounting_event_id = aea.accounting_event_id '
||' and aid.posted_flag <> ''Y'''
||' UNION'
||' select 1'
||' from ap_invoice_payments_all aip'
||' where aip.accounting_event_id = aea.accounting_event_id '
||' and aip.posted_flag <> ''Y'''
||' UNION'
||' select 1'
||' from ap_payment_history_all aph'
||' where aph.accounting_event_id = aea.accounting_event_id '
||' and aph.posted_flag <> ''Y'')'
||' group by aea.org_id, aea.event_type_code, aea.event_status_code'
||' order by 1,2';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 80);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 80);
	  dbms_sql.define_column(l_cursor, 4, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_num2);
	    
	    if l_counter = 1 then
	    tab0print(rpad('Org ID', 15)||rpad('Event Type', 25)
	    ||rpad('Event Status', 25)||rpad('Count', 15));
	    tab0print(rpad('--------------', 15)||rpad('--------------', 25)
	    ||rpad('--------------', 25)||rpad('--------------', 15));
	    end if;

		tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 25)
		||rpad(nvl(l_var2,' '), 25)||rpad(nvl(l_num2,0), 15));
	    
if l_num2 > 0 then
l_ntest1 := l_num2;
end if;

	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('This section reports on transactions that have posted_flag <> Y, but have accounting events');
tab0print('in ap_accounting_events_all with an ACCOUNTED status.  If an event exists with an ACCOUNTED status');
tab0print('the posted flag should be Y for the transactions lines referencing that event id.');
brprint;

if l_ntest1 > 0 then
brprint;
ErrorPrint('One or more orgs have an event with an Accounted status and corresponding transaction rows '||
'with posted flag <> Y.');
ErrorPrint('Possible causes: N/A');
ActionErrorPrint('Please log an iTar with support for further analysis.');

:l_details := :l_details||'A1';

	  brprint;
else
brprint;
tab0print('No problem rows found');
brprint;
end if;


brprint;
SectionPrint('Out of sync posted flags (Invoices)');
brprint;

l_ntest1 := 0;

sqltxt :=  'select aid.org_id,' 
||' aid.posted_flag, aid.accrual_posted_flag, aid.cash_posted_flag, aid.match_status_flag,'
||' decode(aid.accounting_event_id, null, ''NULL'', ''NOT NULL'') event_id, count(distinct invoice_distribution_id)'
||' from ap_invoice_distributions_all aid, ap_system_parameters_all asp'
||' where aid.posted_flag != decode(asp.accounting_method_option, ''Cash'',aid.cash_posted_flag,aid.accrual_posted_flag)'
||' and nvl(asp.org_id,-99) = nvl(aid.org_id,-99)'
||' and aid.last_update_date >='''||l_last_updated||''''
||' group by aid.org_id, aid.posted_flag, aid.accrual_posted_flag, aid.cash_posted_flag, aid.match_status_flag,'
||' decode(aid.accounting_event_id, null, ''NULL'', ''NOT NULL'')'
||' order by 1';



	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_var3, 15);
	  dbms_sql.define_column(l_cursor, 5, l_var4, 15);
	  dbms_sql.define_column(l_cursor, 6, l_var5, 15);
	  dbms_sql.define_column(l_cursor, 7, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_var3);
	    dbms_sql.column_value(l_cursor, 5, l_var4);
	    dbms_sql.column_value(l_cursor, 6, l_var5);
	    dbms_sql.column_value(l_cursor, 7, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Posted Flag', 15)||rpad('Accrual Flag', 15)||rpad('Cash Flag', 15)
	    ||rpad('Match Flag', 15)||rpad('Event Id', 15)||rpad('Count', 15));
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||rpad(nvl(l_var3,' '), 15)
||rpad(nvl(l_var4,' '), 15)||rpad(nvl(l_var5,' '), 15)||rpad(nvl(l_num2,0), 15));
	    
	    
	  if l_num2 > 0  then
	  l_ntest1 := l_num2;
	  end if;
	  
	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);
	
brprint;
tab0print('The posted_flags should be in sync with the accrual or cash posted flag depending on');
tab0print('use of cash or accrual basis accounting. If they are different some data corruption has occurred.');
brprint;
	
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have rows with out of sync posted flags i.e. posted_flag = N '||
	  'and accrual posted flag = Y.');
	  ErrorPrint('Possible causes: 3232467');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');

:l_details := :l_details||'B1';

else
brprint;
tab0print('No problem rows found');
brprint;
end if;


brprint;  
SectionPrint('Out of sync posted flags (Payments)');
brprint;

l_ntest1 := 0;

sqltxt := 'select aip.org_id,' 
||' aip.posted_flag, aip.accrual_posted_flag, aip.cash_posted_flag,'
||' decode(aip.accounting_event_id, null, ''NULL'', ''NOT NULL'') NULL_CHECK, count(distinct aip.invoice_payment_id)'
||' from ap_invoice_payments_all aip, ap_system_parameters_all asp'
||' where aip.posted_flag != decode(asp.accounting_method_option, ''Cash'',aip.cash_posted_flag,aip.accrual_posted_flag)'
||' and nvl(asp.org_id,-99) = nvl(aip.org_id,-99)'
||' and aip.last_update_date >='''||l_last_updated||''''
||' group by aip.org_id, aip.posted_flag, aip.accrual_posted_flag, aip.cash_posted_flag,'
||' decode(aip.accounting_event_id, null, ''NULL'', ''NOT NULL'')'
||' order by 1';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_var3, 15);
	  dbms_sql.define_column(l_cursor, 5, l_var4, 15);
	  dbms_sql.define_column(l_cursor, 6, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_var3);
	    dbms_sql.column_value(l_cursor, 5, l_var4);
	    dbms_sql.column_value(l_cursor, 6, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Posted Flag', 15)||rpad('Accrual Flag', 15)||rpad('Cash Flag', 15)
	    ||rpad('Event Id', 15)||rpad('Count', 15));
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||rpad(nvl(l_var3,' '), 15)
||rpad(nvl(l_var4,' '), 15)||rpad(nvl(l_num2,0), 15));
	    
	    
	  if l_num2 > 0  then
	  l_ntest1 := l_num2;
	  end if;
	  
	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('The posted_flags should be in sync with the accrual or cash posted flag depending on');
tab0print('use of cash or accrual basis accounting. If they are different some data corruption has occurred.');
brprint;
	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have rows with out of sync posted flags i.e. posted_flag = N '||
	  'and accrual posted flag = Y.');
	  ErrorPrint('Possible causes: 3232467');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;

:l_details := :l_details||'C1';

else
brprint;
tab0print('No problem rows found');
brprint;
end if;


brprint;
SectionPrint('Unaccounted Invoices in a Closed Period');
brprint;


l_ntest1 := 0;

sqltxt := 'select aid.org_id, gps.set_of_books_id,  to_char(aid.accounting_date, ''MON-YYYY'') atg_date, gps.period_name,'
||' aid.posted_flag, gps.start_date, gps.end_date, gps.closing_status, count(distinct aid.invoice_id)'
||' from ap_invoice_distributions_all aid,'
||' ap_system_parameters_all asp,'  --added
||' gl_period_statuses gps'
||' where gps.closing_status not in (''F'', ''O'')'
||' and gps.application_id = 200'
||' and aid.posted_flag != ''Y'''
||' and (aid.posted_flag = decode(asp.accounting_method_option, ''Cash'',aid.cash_posted_flag,aid.accrual_posted_flag)'
||'      or aid.posted_flag = ''S'')'
||' and nvl(asp.org_id,-99) = nvl(aid.org_id,-99)'  --added
||' and asp.set_of_books_id = gps.set_of_books_id'  --added
||' and aid.period_name = gps.period_name'
||' and aid.last_update_date >='''||l_last_updated||''''
||' group by aid.org_id, gps.set_of_books_id, to_char(aid.accounting_date, ''MON-YYYY''), gps.period_name,'
||' aid.posted_flag, gps.start_date, gps.end_date,gps.closing_status'
||' order by aid.org_id, gps.set_of_books_id';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_num2);
	  dbms_sql.define_column(l_cursor, 3, l_var4, 15);
	  dbms_sql.define_column(l_cursor, 4, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 5, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 6, l_date2);
	  dbms_sql.define_column(l_cursor, 7, l_date3);
	  dbms_sql.define_column(l_cursor, 8, l_var3, 15);
	  dbms_sql.define_column(l_cursor, 9, l_num3);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_num2);
	    dbms_sql.column_value(l_cursor, 3, l_var4);
	    dbms_sql.column_value(l_cursor, 4, l_var1);
	    dbms_sql.column_value(l_cursor, 5, l_var2);
	    dbms_sql.column_value(l_cursor, 6, l_date2);
	    dbms_sql.column_value(l_cursor, 7, l_date3);
	    dbms_sql.column_value(l_cursor, 8, l_var3);
	    dbms_sql.column_value(l_cursor, 9, l_num3);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('SOB ID', 15)||rpad('ATG Date', 15)||rpad('Period Name', 15)
	    ||rpad('Posted Flag', 15)||rpad('Start Date', 15)||rpad('End Date', 15)||rpad('Closing Status', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(to_char(l_num2),' '), 15)||rpad(nvl(l_var4,' '), 15)||
rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||rpad(nvl(to_char(l_date2),' '), 15)||rpad(nvl(to_char(l_date3),' '), 15)||
rpad(nvl(l_var3,' '), 15)||rpad(nvl(to_char(l_num3),' '), 15));
	    
	    
	  if l_num3 > 0 then
	  l_ntest1 := l_num3;
	  end if;
	  
	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('All transactions must be accounted before a period can be closed.  If there are unaccounted');
tab0print('transactions in a closed period, some data corruption has occurred.');
brprint;
	  
	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have unaccounted invoice rows in a closed period.');
	  ErrorPrint('Possible causes:  3257972,3257936');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;

:l_details := :l_details||'D1';

else
brprint;
tab0print('No problem rows found');
brprint;
end if;

brprint;
SectionPrint('Unaccounted Payments in a Closed Period');
brprint;

l_ntest1 := 0;

sqltxt := 'select aip.org_id, gps.set_of_books_id,  to_char(aip.accounting_date, ''MON-YYYY''), gps.period_name,'
||' aip.posted_flag, gps.start_date, gps.end_date, gps.closing_status, count(distinct aip.check_id)'
||' from ap_checks_all ac, ap_invoice_payments_all aip,'
||' ap_system_parameters_all asp,'  --added
||' gl_period_statuses gps'
||' where ac.check_id = aip.check_id'
||' and gps.closing_status not in (''F'', ''O'')'
||' and gps.application_id = 200'
||' and aip.posted_flag != ''Y'''
||' and (aip.posted_flag = decode(asp.accounting_method_option, ''Cash'',aip.cash_posted_flag,aip.accrual_posted_flag)'
||'     or aip.posted_flag = ''S'')'
||' and nvl(asp.org_id,-99) = nvl(aip.org_id,-99)'  --added
||' and asp.set_of_books_id = gps.set_of_books_id'  --added
||' and aip.period_name = gps.period_name'
||' and aip.last_update_date >='''||l_last_updated||''''
||' group by aip.org_id, gps.set_of_books_id, to_char(aip.accounting_date, ''MON-YYYY''), gps.period_name,'
||' aip.posted_flag,gps.start_date, gps.end_date, gps.closing_status'
||' order by 1,2';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_num2);
	  dbms_sql.define_column(l_cursor, 3, l_var4, 15);
	  dbms_sql.define_column(l_cursor, 4, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 5, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 6, l_date2);
	  dbms_sql.define_column(l_cursor, 7, l_date3);
	  dbms_sql.define_column(l_cursor, 8, l_var3, 15);
	  dbms_sql.define_column(l_cursor, 9, l_num3);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_num2);
	    dbms_sql.column_value(l_cursor, 3, l_var4);
	    dbms_sql.column_value(l_cursor, 4, l_var1);
	    dbms_sql.column_value(l_cursor, 5, l_var2);
	    dbms_sql.column_value(l_cursor, 6, l_date2);
	    dbms_sql.column_value(l_cursor, 7, l_date3);
	    dbms_sql.column_value(l_cursor, 8, l_var3);
	    dbms_sql.column_value(l_cursor, 9, l_num3);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('SOB ID', 15)||rpad('ATG Date', 15)||rpad('Period Name', 15)
	    ||rpad('Posted Flag', 15)||rpad('Start Date', 15)||rpad('End Date', 15)||rpad('Closing Status', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(to_char(l_num2),' '), 15)||rpad(nvl(l_var4,' '), 15)||
rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||rpad(nvl(to_char(l_date2),' '), 15)||rpad(nvl(to_char(l_date3),' '), 15)||
rpad(nvl(l_var3,' '), 15)||rpad(nvl(to_char(l_num3),' '), 15));
	    
	    
	  if l_num3 > 0 then
	  l_ntest1 := l_num3;
	  end if;
	  
	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);
	  
brprint;
tab0print('All transactions must be accounted before a period can be closed.  If there are unaccounted');
tab0print('transactions in a closed period, some data corruption has occurred.');
brprint;
	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have unaccounted payment rows in a closed period.');
	  ErrorPrint('Possible causes:  3257972, 3257936');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;

:l_details := :l_details||'E1';

else
brprint;
tab0print('No problem rows found');
brprint;
end if;


brprint;
SectionPrint('Unaccounted Clearing transactions in a Closed Period');
brprint;

l_ntest1 := 0;

sqltxt := 'select aph.org_id, gps.set_of_books_id, to_char(aph.accounting_date, ''MON-YYYY''), gps.period_name,'
||' aph.posted_flag, gps.start_date, gps.end_date, gps.closing_status, count(distinct payment_history_id)'
||' from ap_checks_all ac, ap_payment_history_all aph,'
||' ap_system_parameters_all asp,'  --added
||' gl_period_statuses gps'
||' where ac.check_id = aph.check_id'
||' and gps.closing_status not in (''F'', ''O'')'
||' and gps.application_id = 200'
||' and aph.posted_flag != ''Y'''
||' and nvl(asp.org_id,-99) = nvl(aph.org_id,-99)'  --added
||' and asp.set_of_books_id = gps.set_of_books_id'  --added
||' and aph.accounting_date between gps.start_date and gps.end_date'
||' and aph.last_update_date >='''||l_last_updated||''''
||' group by aph.org_id, gps.set_of_books_id, to_char(aph.accounting_date, ''MON-YYYY''), gps.period_name,'
||' aph.posted_flag, gps.start_date, gps.end_date, gps.closing_status'
||' order by 1,2';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_num2);
	  dbms_sql.define_column(l_cursor, 3, l_var4, 15);
	  dbms_sql.define_column(l_cursor, 4, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 5, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 6, l_date2);
	  dbms_sql.define_column(l_cursor, 7, l_date3);
	  dbms_sql.define_column(l_cursor, 8, l_var3, 15);
	  dbms_sql.define_column(l_cursor, 9, l_num3);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_num2);
	    dbms_sql.column_value(l_cursor, 3, l_var4);
	    dbms_sql.column_value(l_cursor, 4, l_var1);
	    dbms_sql.column_value(l_cursor, 5, l_var2);
	    dbms_sql.column_value(l_cursor, 6, l_date2);
	    dbms_sql.column_value(l_cursor, 7, l_date3);
	    dbms_sql.column_value(l_cursor, 8, l_var3);
	    dbms_sql.column_value(l_cursor, 9, l_num3);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('SOB ID', 15)||rpad('ATG Date', 15)||rpad('Period Name', 15)
	    ||rpad('Posted Flag', 15)||rpad('Start Date', 15)||rpad('End Date', 15)||rpad('Closing Status', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(to_char(l_num2),' '), 15)||rpad(nvl(l_var4,' '), 15)||
rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||rpad(nvl(to_char(l_date2),' '), 15)||rpad(nvl(to_char(l_date3),' '), 15)||
rpad(nvl(l_var3,' '), 15)||rpad(nvl(to_char(l_num3),' '), 15));

	  if l_num3 > 0 then
	  l_ntest1 := l_num3;
	  end if;
	  
	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);
	  
brprint;
tab0print('All transactions must be accounted before a period can be closed.  If there are unaccounted');
tab0print('transactions in a closed period, some data corruption has occurred.');
brprint;

	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have an unaccounted clearing row in a closed period.');
	  ErrorPrint('Possible causes:  3257972, 3257936');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;

:l_details := :l_details||'F1';

else
brprint;
tab0print('No problem rows found');
brprint;
end if;


if l_patch_level >= '11i.AP.K' then

brprint;
SectionPrint('Unaccounted Events in a Closed Period');
brprint;


l_ntest1 := 0;

sqltxt := 'select aea.org_id, gps.set_of_books_id, to_char(aea.accounting_date, ''MON-YYYY''), gps.period_name, '
||' aea.event_status_code, gps.start_date, gps.end_date, gps.closing_status, count(*)'
||' from ap_accounting_events_all aea,'
||' ap_system_parameters_all asp,'  --added
||' gl_period_statuses gps'
||' where gps.closing_status not in (''F'', ''O'')'
||' and gps.application_id = 200'
||' and aea.event_status_code not like ''%ACCOUNTED%'''
||' and nvl(asp.org_id,-99) = nvl(aea.org_id,-99)'  --added
||' and asp.set_of_books_id = gps.set_of_books_id'  --added
||' and aea.accounting_date between gps.start_date and gps.end_date'
||' and aea.last_update_date >='''||l_last_updated||''''
||' group by aea.org_id, gps.set_of_books_id, to_char(aea.accounting_date, ''MON-YYYY''), gps.period_name,'
||' aea.event_status_code, gps.start_date, gps.end_date, gps.closing_status'
||' order by 1,2';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_num2);
	  dbms_sql.define_column(l_cursor, 3, l_var4, 15);
	  dbms_sql.define_column(l_cursor, 4, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 5, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 6, l_date2);
	  dbms_sql.define_column(l_cursor, 7, l_date3);
	  dbms_sql.define_column(l_cursor, 8, l_var3, 15);
	  dbms_sql.define_column(l_cursor, 9, l_num3);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_num2);
	    dbms_sql.column_value(l_cursor, 3, l_var4);
	    dbms_sql.column_value(l_cursor, 4, l_var1);
	    dbms_sql.column_value(l_cursor, 5, l_var2);
	    dbms_sql.column_value(l_cursor, 6, l_date2);
	    dbms_sql.column_value(l_cursor, 7, l_date3);
	    dbms_sql.column_value(l_cursor, 8, l_var3);
	    dbms_sql.column_value(l_cursor, 9, l_num3);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('SOB ID', 15)||rpad('ATG Date', 15)||rpad('Period Name', 15)
	    ||rpad('Posted Flag', 15)||rpad('Start Date', 15)||rpad('End Date', 15)||rpad('Closing Status', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(to_char(l_num2),' '), 15)||rpad(nvl(l_var4,' '), 15)||
rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||rpad(nvl(to_char(l_date2),' '), 15)||rpad(nvl(to_char(l_date3),' '), 15)||
rpad(nvl(l_var3,' '), 15)||rpad(nvl(to_char(l_num3),' '), 15));
	    
	    
	  if l_num3 > 0 then
	  l_ntest1 := l_num3;
	  end if;
	  
	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('Accounting can only be created in open periods.  If events with unaccounted statuses exist in a closed period');
tab0print('some data corruption has occurred.');
brprint;
	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have an unaccounted event rows in a closed period.');
	  ErrorPrint('Possible causes:  3257972, 3257936');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;

:l_details := :l_details||'G1';

else
brprint;
tab0print('No problem rows found');
brprint;
end if;

end if;


brprint;
SectionPrint('Transactions with Accounting_event_ids and no event rows');
brprint;

l_ntest1 := 0;


sqltxt := 'select aid.org_id, ''Invoice'', to_char(aid.creation_date, ''MON-YYYY''), count(*) row_count'
||' from ap_invoice_distributions_all aid'
||' where aid.accounting_event_id is not null'
||' and aid.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aid.accounting_event_id)'
||' group by aid.org_id, to_char(aid.creation_date, ''MON-YYYY'')'
||' UNION'
||' select aip.org_id, ''Payment'', to_char(aip.creation_date, ''MON-YYYY''), count(*) row_count'
||' from ap_invoice_payments_all aip'
||' where aip.accounting_event_id is not null'
||' and aip.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aip.accounting_event_id)'
||' group by aip.org_id, to_char(aip.creation_date, ''MON-YYYY'')'
||' UNION'
||' select aph.org_id,''Clearing'', to_char(aph.creation_date, ''MON-YYYY''), count(*) row_count'
||' from ap_payment_history_all aph'
||' where aph.accounting_event_id is not null'
||' and aph.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aph.accounting_event_id)'
||' group by aph.org_id, to_char(aph.creation_date, ''MON-YYYY'')'
||' order by 1,2';




	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Trans Type', 15)||rpad('Creation Date', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||
rpad(nvl(to_char(l_num2),' '), 15));
	    
	    
	  if l_num3 > 0 then
	  l_ntest1 := l_num2;
	  end if;
	  
	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);
	  

brprint;
tab0print('All accounting_event_ids referenced by transaction rows should have an event row in ap_accounting_events_all');
tab0print('with a corresponding event id.  If a transaction row references an event id that does not exist in');
tab0print('accounting_events_all some data corruption has occurred.');
brprint;

	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have transaction rows referencing missing accounting events.');
	  ErrorPrint('Possible causes:  fix for bug#2691008');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;
	  
:l_details := :l_details||'H1';

else
brprint;
tab0print('No problem rows found');
brprint;
end if;

brprint;
SectionPrint('Transactions with Accounting_event_ids and no event rows, but headers exist');
brprint;

l_ntest1 := 0;


sqltxt := 'select aid.org_id, ''Invoice'', to_char(aid.creation_date, ''MON-YYYY''), count(*) row_count'
||' from ap_invoice_distributions_all aid'
||' where aid.accounting_event_id is not null'
||' and aid.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aid.accounting_event_id)'
||' and exists'
||' (select 1 from ap_ae_headers_all aeh'
||' where aeh.accounting_event_id = aid.accounting_event_id)'
||' group by aid.org_id, to_char(aid.creation_date, ''MON-YYYY'')'
||' UNION'
||' select aip.org_id, ''Payment'', to_char(aip.creation_date, ''MON-YYYY''), count(*) row_count'
||' from ap_invoice_payments_all aip'
||' where aip.accounting_event_id is not null'
||' and aip.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aip.accounting_event_id)'
||' and exists'
||' (select 1 from ap_ae_headers_all aeh'
||' where aeh.accounting_event_id = aip.accounting_event_id)'
||' group by aip.org_id, to_char(aip.creation_date, ''MON-YYYY'')'
||' UNION'
||' select aph.org_id,''Clearing'', to_char(aph.creation_date, ''MON-YYYY''), count(*) row_count'
||' from ap_payment_history_all aph'
||' where aph.accounting_event_id is not null'
||' and aph.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aph.accounting_event_id)'
||' and exists'
||' (select 1 from ap_ae_headers_all aeh'
||' where aeh.accounting_event_id = aph.accounting_event_id)'
||' group by aph.org_id, to_char(aph.creation_date, ''MON-YYYY'')'
||' order by 1,2';



	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Trans Type', 15)||rpad('Creation Date', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||
rpad(nvl(to_char(l_num2),' '), 15));
	    
	    
	  if l_num3 > 0 then
	  l_ntest1 := l_num2;
	  end if;
	  
	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);
	  

brprint;
tab0print('All accounting_event_ids referenced by transaction rows should have an event row in ap_accounting_events_all');
tab0print('with a corresponding event id.  If a transaction row references an event id that does not exist in');
tab0print('accounting_events_all, but does exist in ap_ae_headers_all, some data corruption has occurred.');
brprint;

	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have transaction rows referencing missing accounting events in ap_accounting_events_all.');
	  ErrorPrint('And the accounting event ids exists in ap_ae_headers_all.');
	  ErrorPrint('Possible causes:  Unknown');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;
	  
:l_details := :l_details||'T1';

else
brprint;
tab0print('No problem rows found');
brprint;
end if;


l_ntest1 := 0;
l_ntest2 := 0;


brprint;
sectionprint('Accounting event data');
brprint;

sqltxt := 'select aea.org_id, aea.event_status_code,'
||' decode(aeh.accounting_event_id, null, ''NOT EXISTS'', ''EXISTS'') headers, count(distinct aea.accounting_event_id) count'
||' from ap_ae_headers_all aeh, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aeh.accounting_event_id(+)'
||' and aea.last_update_date >='''||l_last_updated||''''
||' group by aea.org_id, aea.event_status_code, decode(aeh.accounting_event_id, null, ''NOT EXISTS'', ''EXISTS'')'
||' order by aea.org_id';

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Status', 15)||rpad('Headers', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||
rpad(nvl(to_char(l_num2),' '), 15));

	  if l_num2 > 0 and l_var2 = 'EXISTS' and l_var1 not like '%ACCOUNTED%' THEN
	  l_ntest1 := l_num2;
	  end if;
 	
 	 if l_num2 > 0 and l_var2 = 'NOT EXISTS' and l_var1 like '%ACCOUNTED%' THEN
		  l_ntest2 := l_num2;
		  end if;
 	
   end loop;
   DBMS_OUTPUT.PUT_LINE(chr(9));
   dbms_sql.close_cursor(l_cursor);
		    


brprint;
tab0print('Only accounting events with accounted statuses should have rows in ap_ae_headers_all');	    
brprint;
	    
  if l_ntest1 > 0 then

  brprint;
  ErrorPrint('One or more orgs have events with unaccounted status and an accounting header created.');
  ErrorPrint('Possible causes:  bug#3144056, 3004381');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;

:l_details := :l_details||'I1';

  else
  brprint;

  tab0print('No rows with unaccounted status have an accounting header created.');
  brprint;
  end if;   


brprint;
tab0print('All accounting events with an accounted status should have rows in ap_ae_headers_all.');
brprint;

if l_ntest2 > 0 then

brprint;
WarningPrint('One or more orgs have an event with an Accounted status and NO rows in AP_AE_HEADERS_ALL');
WarningPrint('Possible causes: N/A');
ActionWarningPrint('Please log an iTar with support for further analysis.');
brprint;

:l_details := :l_details||'I2';

else
brprint;
tab0print('No events with an Accounted status and NO rows in AP_AE_HEADERS_ALL found');
brprint;
end if;


l_ntest1 := 0;
l_ntest2 := 0;
l_ntest3 := 0;

brprint;
sectionprint('Invoice Distribution Accounting Event Data');
brprint;

sqltxt := 'select org_id, decode(accounting_event_id, null, ''NULL'', ''NOT NULL'') null_event,'
||' match_status_flag, posted_flag, count(*) count'
||' from ap_invoice_distributions_all'
||' where last_update_date >='''||l_last_updated||''''
||' group by org_id, decode(accounting_event_id, null, ''NULL'', ''NOT NULL''), match_status_flag,posted_flag'
||' order by org_id';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_var3, 15);
	  dbms_sql.define_column(l_cursor, 5, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_var3);
	    dbms_sql.column_value(l_cursor, 5, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Event ID', 15)||rpad('Match Flag', 15)||rpad('Posted Flag', 15)
	    ||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||rpad(nvl(l_var3,' '), 15)||
rpad(nvl(to_char(l_num2),' '), 15));


	  	  if l_num2 > 0 and l_var1 = 'NULL' and l_var3 = 'Y' then
	  	  l_ntest1 := l_num2;
	  	  end if;
 	
 	  	  if l_num2 > 0 and l_var1 = 'NOT NULL' and (l_var2 <> 'A' and l_var2 <> 'T') then
		  l_ntest2 := l_num2;
		  end if;
 	
 		  if l_num2 > 0 and l_var1 = 'NULL' and (l_var2 = 'A' or l_var2 = 'T') then
			  l_ntest3 := l_num2;
			  end if;
 	
 	
   end loop;
   DBMS_OUTPUT.PUT_LINE(chr(9));
   dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('All transaction rows with posted_flag = Y should have an accounting_event_id.');
brprint;

if l_ntest1 > 0 then
  brprint;
  ErrorPrint('One or more orgs have posted_flags = Y and NULL accounting_event_ids.');
  ErrorPrint('Possible causes:  NA');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;
  
:l_details := :l_details||'J1';

  else
  brprint;
  tab0print('No rows with posted_flag = Y and NULL accounting event id found.');
  brprint;
  end if;	    

if l_patch_level >= '11i.AP.K' then

brprint;
tab0print('In AP.K or higher only rows that have been validated should have an accounting event id.');
brprint;

  if l_ntest2 > 0 then
  brprint;
  ErrorPrint('One or more orgs have match status flag not equal to A or T and NOT NULL accounting_event_ids.');
  ErrorPrint('Possible causes:  NA');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;
  
:l_details := :l_details||'J2';

  else
  brprint;
  tab0print('No rows with match status flag not equal to A or T and NOT NULL accounting_events_ids');
  brprint;
  end if;	    

end if;

if l_patch_level >= '11i.AP.K' then

brprint;
tab0print('In AP.K or higher all validated invoice distribution lines should have an accounting event id.');
brprint;

  if l_ntest3 > 0 then
  brprint;
  ErrorPrint('One or more orgs have match status flag equal to A or T and NULL accounting_event_ids.');
  ErrorPrint('Possible causes:  NA');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;

:l_details := :l_details||'J3';

  else
  brprint;
  tab0print('No rows with match status flag equal to A or T and NULL accounting_event_ids.');
  brprint;
  end if;	    

end if;


l_ntest1 := 0;
l_ntest2 := 0;

brprint;
sectionprint('Payment Accounting Event data');
brprint;

sqltxt := 'select org_id,decode(accounting_event_id, null, ''NULL'', ''NOT NULL'') null_event,posted_flag, count(*)'
||' from ap_invoice_payments_all'
||' where last_update_date >='''||l_last_updated||''''
||' group by org_id, decode(accounting_event_id, null, ''NULL'', ''NOT NULL''), posted_flag'
||' order by org_id';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Event ID', 15)||rpad('Posted Flag', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||
rpad(nvl(to_char(l_num2),' '), 15));


	  	  if l_num2 > 0 and l_var1 = 'NULL' and l_var2 = 'Y' then
	  	  l_ntest1 := l_num2;
	  	  end if;
 	
	  	  if l_num2 > 0 and l_var1 = 'NULL' and l_var2 <> 'Y' then
	  	  l_ntest2 := l_num2;
	  	  end if;


   end loop;
   DBMS_OUTPUT.PUT_LINE(chr(9));
   dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('All transaction rows with posted_flag = Y should have an accounting_event_id.');
brprint;

  if l_ntest1 > 0 then
  brprint;
  ErrorPrint('One or more orgs have posted_flags = Y and NULL accounting_event_ids.');
  ErrorPrint('Possible causes:  NA');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;
  
:l_details := :l_details||'K1';

  else
  brprint;
  tab0print('No payment rows with posted_flags = Y and NULL accounting_event_ids.');
  brprint;
  end if;	    

if l_patch_level >= '11i.AP.K' then

brprint;
tab0print('In AP.K or higher all payment rows should have an accounting event id.');
brprint;

  if l_ntest2 > 0 then
  brprint;
  ErrorPrint('One or more orgs have payments with NULL accounting event ids');
  ErrorPrint('Possible causes:  NA');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;
  
:l_details := :l_details||'K2';

  else
  brprint;
  tab0print('No payment rows with NULL accounting event ids found.');
  brprint;
  end if;	    
  
end if;

l_ntest1 := 0;
l_ntest2 := 0;

brprint;
sectionprint('Payment History event data');
brprint;

sqltxt := 'select org_id, decode(accounting_event_id, null, ''NULL'', ''NOT NULL'') null_event,posted_flag, count(*)'
||' from ap_payment_history_all'
||' where last_update_date >='''||l_last_updated||''''
||' group by org_id, decode(accounting_event_id, null, ''NULL'', ''NOT NULL''), posted_flag'
||' order by org_id';

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Event ID', 15)||rpad('Posted Flag', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||
rpad(nvl(to_char(l_num2),' '), 15));


	  	  if l_num2 > 0 and l_var1 = 'NULL' and l_var2 = 'Y' then
	  	  l_ntest1 := l_num2;
	  	  end if;
 	
	  	if l_num2 > 0 and l_var1 = 'NULL' and l_var2 <> 'Y' then
			  	  l_ntest2 := l_num2;
			  	  end if;


   end loop;
   DBMS_OUTPUT.PUT_LINE(chr(9));
   dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('All transaction rows with posted_flag = Y should have an accounting_event_id.');
brprint;
		  		  
if l_ntest1 > 0 then
  brprint;
  ErrorPrint('One or more orgs have posted_flags = Y and NULL accounting_event_ids.');
  ErrorPrint('Possible causes:  NA');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;
  
:l_details := :l_details||'L1';

  else
  brprint;
  tab0print('No payment clearing rows with posted_flags = Y and NULL accounting_event_ids.');
  brprint;
  end if;	    

if l_patch_level >= '11i.AP.K' then

brprint;
tab0print('In AP.K or higher all payment clearing rows should have an accounting event id.');
brprint;
	    
  if l_ntest2 > 0 then
  brprint;
  ErrorPrint('One or more orgs have payment clearing rows with NULL accounting event ids');
  ErrorPrint('Possible causes:  NA');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;
  
:l_details := :l_details||'L2';

  else
  brprint;
  tab0print('No payment clearing rows with NULL accounting event ids found.');
  brprint;
  end if;	    

end if;


l_ntest1 := 0;

brprint;
sectionprint('Accounting for Payments with multiple invoices');
brprint;

sqltxt := 'select ap.org_id, count(distinct ap.check_id)'
||' from ap_invoice_payments_all ap '
||' where accounting_event_id is not null'
||' and ap.last_update_date >='''||l_last_updated||''''
||' and reversal_inv_pmt_id is null'
||' and exists '
||'      (select check_id from ap_invoice_payments_all aip'
||'       where accounting_event_id is null and '
||'       ap.check_id = aip.check_id)'
||' group by ap.org_id'
||' order by ap.org_id';



	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(to_char(l_num2),' '), 15));

	  	  if l_num2 > 0 then
		  l_ntest1 := l_num2;
		  end if;
		  	
		  	end loop;
		  	 DBMS_OUTPUT.PUT_LINE(chr(9));
		  		  	  	  dbms_sql.close_cursor(l_cursor);
		  		  
brprint;
tab0print('All rows associated with a payment for multiple invoices should have the same accounting event id.');
brprint;

  if l_ntest1 > 0 then
  brprint;
  ErrorPrint('One or more orgs have payments for multiple invoices with the accounting event id missing for one or more invoices on the payment.');
  ErrorPrint('Possible causes:  bug#2998717');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;

:l_details := :l_details||'M1';

  else
  brprint;
  tab0print('No rows for payments for multiple invoices missing accounting event ids for one or more invoices on the payment found.');
  brprint;
  end if;
		  		  	  
    
l_ntest1 := 0;


sqltxt := 'select aip.org_id, count(distinct aip.check_id)'
||' from ap_invoice_payments_all aip'
||' where aip.accounting_event_id is not null'
||' and aip.last_update_date >='''||l_last_updated||''''
||' and aip.posted_flag = ''Y'''
||' and exists'
||' (select 1 from ap_invoice_payments_all aip2'
||' where aip2.check_id = aip.check_Id'
||' and aip2.accounting_event_id is not null'
||' and aip2.accounting_event_id = aip.accounting_event_id'
||' and aip2.posted_flag != ''Y'')'
||' group by aip.org_id'
||' order by aip.org_id';

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(to_char(l_num2),' '), 15));

	  	  if l_num2 > 0 then
		  	  l_ntest1 := l_num2;
		  	  end if;
	
	end loop;
		  	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
		  	  	  dbms_sql.close_cursor(l_cursor);
		  
brprint;
tab0print('All rows associated with a payment for multiple invoices should have the same posted flag.');
brprint;

  if l_ntest1 > 0 then
  brprint;
  ErrorPrint('One or more orgs have payments for multiple invoices with status = Accounted and not all rows for the payment are accounted.');
  ErrorPrint('Possible causes:  Accounting was not undone before the datafix for bug#2998717 was applied.');
  ActionErrorPrint('Please log an iTar with support for further analysis.');
  brprint;
  
:l_details := :l_details||'M2';

  else
  brprint;
  tab0print('No payments for multiple invoices with Status = Accounted and unaccounted rows for the payment exist.');
  brprint;
  end if;
		   

l_ntest1 := 0;

brprint;
sectionprint('Out of Sync Accounting Dates');
brprint;

sqltxt := 'select aid.org_id, ''INVOICES'' TRANS_TYPE, count(distinct aea.accounting_event_id), count(distinct aid.invoice_distribution_id)'
||' from ap_invoice_distributions_all aid, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aid.accounting_event_id'
||' and aea.last_update_date >='''||l_last_updated||''''
||' and trunc(aea.accounting_date) <> trunc(aid.accounting_date)'
||' group by aid.org_id, ''INVOICES'''
||' UNION'
||' select aip.org_id, ''PAYMENTS'' TRANS_TYPE, count(distinct aea.accounting_event_id), count(distinct aip.invoice_payment_id)'
||' from ap_invoice_payments_all aip, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aip.accounting_event_id'
||' and aea.last_update_date >='''||l_last_updated||''''
||' and trunc(aea.accounting_date) <> trunc(aip.accounting_date)'
||' group by aip.org_id, ''PAYMENTS'''
||' UNION'
||' select aph.org_id, ''CLEARING'' TRANS_TYPE,count(distinct aea.accounting_event_id), count(distinct aph.payment_history_id)'
||' from ap_payment_history_all aph, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aph.accounting_event_id'
||' and aea.last_update_date >='''||l_last_updated||''''
||' and trunc(aea.accounting_date) <> trunc(aph.accounting_date)'
||' group by aph.org_id, ''CLEARING'''
||' ORDER BY 1,2';

 	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_num2);
	  dbms_sql.define_column(l_cursor, 4, l_num3);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_num2);
	    dbms_sql.column_value(l_cursor, 4, l_num3);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Trans Type', 15)||rpad('Count Event ID', 15)||rpad('Count Invoice ID', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(to_char(l_num2),' '), 15)||
rpad(nvl(to_char(l_num3),' '), 15));

	  	  if l_num2 > 0 or l_num3 > 0 then
		  	  l_ntest1 := l_num2 + l_num3;
		  	  end if;
	
	
	end loop;
		  	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
		  	  	  dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('The accounting date from the transaction tables should correspond with the accounting date from the');
tab0print('accounting events table.');
brprint;
		  	  		  	  
		  	  if l_ntest1 > 0 then

		  	  brprint;
		  	  ErrorPrint('One or more orgs have out of sync accounting dates.');
		  	  ErrorPrint('Possible causes: 3257972');
		  	  ActionErrorPrint('Please log an iTar with support for further analysis.');
		  	  brprint;
:l_details := :l_details||'N1';
		  	  else
		  	  brprint;
		  	  tab0print('No out of sync accounting dates found.');
		  	  brprint;
		  	  end if;
	  
l_ntest1 := 0;
l_ntest2 := 0;

brprint;
sectionprint('Out of Balance Headers');
brprint;

sqltxt := 'select aeh2.org_id, aeh2.period_name, aeh2.gl_transfer_flag, count(UNBAL.ACCT), COUNT(UNBAL.ENT)'
||' from ap_ae_headers_all aeh2,'
||' (select AEH.ORG_ID, aeh.ae_header_id, '
||' decode((nvl(sum(ael.accounted_dr),0) - nvl(sum(ael.accounted_cr),0)), 0,NULL, ''UNBALANCED'') ACCT,'
||' decode((nvl(sum(ael.entered_dr),0) - nvl(sum(ael.entered_cr),0)), 0,NULL, ''UNBALANCED'') ENT'
||'  from ap_ae_headers_all aeh, ap_ae_lines_all ael, ap_accounting_events_all aea'
||'  where ael.ae_header_id = aeh.ae_header_id'
||' and aeh.accounting_event_id = aea.accounting_event_id'
||' having '
||' nvl(sum(ael.accounted_dr),0) <> nvl(sum(ael.accounted_cr),0) '
||' or'
||' nvl(sum(ael.entered_dr),0) <> nvl(sum(ael.entered_cr),0)'
||' group by AEH.ORG_ID, aeh.period_name, aeh.org_id, aea.source_table, aea.source_id, aeh.accounting_event_id, aeh.ae_header_id,  aeh.gl_transfer_run_id, aeh.gl_transfer_flag) UNBAL'
||' where aeh2.ae_header_id = unbal.ae_header_id'
||' and aeh2.last_update_date >='''||l_last_updated||''''
||' group by aeh2.org_id, aeh2.period_name, aeh2.gl_transfer_flag';
	  

l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 15);
	  dbms_sql.define_column(l_cursor, 3, l_var2, 15);
	  dbms_sql.define_column(l_cursor, 4, l_num2);
	  dbms_sql.define_column(l_cursor, 5, l_num3);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_var2);
	    dbms_sql.column_value(l_cursor, 4, l_num2);
	    dbms_sql.column_value(l_cursor, 5, l_num3);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Period Name', 15)||rpad('Transfer Flag', 15)
	    ||rpad('Unbal Acct Count', 25)||rpad('Unbal Ent Count', 25));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15)||
	    rpad('--------------', 25)||rpad('--------------', 25));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(l_var2,' '), 15)||rpad(nvl(to_char(l_num2),' '), 25)||
rpad(nvl(to_char(l_num3),' '), 25));

	  	  if l_num2 > 0 then
		  	  l_ntest1 := l_num2;
		  	  end if;
	
	  	  if l_num3 > 0 then
			  	  l_ntest2 := l_num3;
			  	  end if;
	
	
	end loop;
		  	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
		  	  	  dbms_sql.close_cursor(l_cursor);
		  

brprint;
tab0print('Accounting entries accounted amounts should balance by header.');
brprint;
		   
		  	  
		  	  if l_ntest1 > 0 then
		  	  brprint;
		  	  ErrorPrint('One or more orgs have out of balance accounted amounts.');
		  	  ErrorPrint('Possible causes:  NA');
		  	  ActionErrorPrint('Please log an iTar with support for further analysis.');
		  	  brprint;
:l_details := :l_details||'O1';
		  	  else
		  	  brprint;
		  	  tab0print('No out of balance accounted amounts found');
		  	  brprint;
		  	  end if;

brprint;
tab0print('Accounted entries entered amounts should balance by header, unless accounting is for cross currency.');
brprint;

		  	  if l_ntest2 > 0 then
		  	  brprint;
		  	  WarningPrint('One or more orgs have out of balance entered amounts.');
		  	  WarningPrint('Possible causes:  NA');
		  	  ActionWarningPrint('Out of balance entered amounts may indicate a problem exists.');
		  	  ActionWarningPrint('In some accounting scenarios, unbalanced entered amounts are OK.');
		  	  ActionWarningPrint('Please log an iTar with support for further analysis.');
		  	  brprint;
:l_details := :l_details||'O2';
		  	  else
		  	  brprint;
		  	  tab0print('No out of balance entered amounts found');
		  	  brprint;
		  	  end if;


l_ntest1 := 0;
	  	
brprint;  
sectionprint('Large Rounding Lines');
brprint;

sqltxt := 'select org_id, count(*)'
||' from ap_ae_lines_all'
||' where ae_line_type_code = ''ROUNDING'''
||' and last_update_date >='''||l_last_updated||''''
||' and abs(nvl(accounted_dr, accounted_cr)) > .10'
||' group by org_id';

	  	  
	  l_cursor := dbms_sql.open_cursor; 
	  	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  	  dbms_sql.define_column(l_cursor, 2, l_num2);
	  	  l_counter := dbms_sql.execute(l_cursor); 
	  	  l_counter := 0;
	  	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	  	    l_counter := l_counter + 1;
	  	    dbms_sql.column_value(l_cursor, 1, l_num1);
	  	    dbms_sql.column_value(l_cursor, 2, l_num2);
	  	    
	  	    if l_counter = 1 then
	  	   
	  	    tab0print(rpad('Org ID', 15)||rpad('Count', 15));
	  	    
	  	    tab0print(rpad('--------------', 15)||rpad('--------------', 15));
	  	    
	  	    end if;
	   
	  tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(to_char(l_num2),' '), 15));
	  
	  	  	  if l_num2 > 0 then
	  		  	  l_ntest1 := l_num2;
	  		  	  end if;
	  	
	  	end loop;
	  		  	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  		  	  	  dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('Rounding lines should only be created for small rounding differences due to calculated amounts');
tab0print('used in accounting entries.');
brprint;
	  	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have ROUNDING lines greater then $.10');
	  ErrorPrint('Possible causes:  bug#2998717');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;
:l_details := :l_details||'P1';
	  else
	  brprint;
	  tab0print('No ROUNDING lines greater then $.10 found.');
	  brprint;
	  end if;
	  
l_ntest1 := 0;
	  	
brprint;  
sectionprint('Large Writeoff Lines');
brprint;

sqltxt := 'select org_id, count(*)'
||' from ap_ae_lines_all'
||' where ae_line_type_code = ''WRITEOFF'''
||' and last_update_date >='''||l_last_updated||''''
||' and abs(nvl(accounted_dr, accounted_cr)) > .10'
||' group by org_id';

	  	  
	  l_cursor := dbms_sql.open_cursor; 
	  	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  	  dbms_sql.define_column(l_cursor, 2, l_num2);
	  	  l_counter := dbms_sql.execute(l_cursor); 
	  	  l_counter := 0;
	  	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	  	    l_counter := l_counter + 1;
	  	    dbms_sql.column_value(l_cursor, 1, l_num1);
	  	    dbms_sql.column_value(l_cursor, 2, l_num2);
	  	    
	  	    if l_counter = 1 then
	  	   
	  	    tab0print(rpad('Org ID', 15)||rpad('Count', 15));
	  	    
	  	    tab0print(rpad('--------------', 15)||rpad('--------------', 15));
	  	    
	  	    end if;
	   
	  tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(to_char(l_num2),' '), 15));
	  
	  	  	  if l_num2 > 0 then
	  		  	  l_ntest1 := l_num2;
	  		  	  end if;
	  	
	  	end loop;
	  		  	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  		  	  	  dbms_sql.close_cursor(l_cursor);

brprint;
tab0print('Writeoff lines should only be created for small amounts needed to relieve liability balances');
tab0print('when an invoice is fully paid.');
brprint;
	  	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have WRITEOFF lines greater then $.10');
	  ErrorPrint('Possible causes:  N/A');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;
:l_details := :l_details||'Q1';
	  else
	  brprint;
	  tab0print('No WRITEOFF lines greater then $.10 found.');
	  brprint;
	  end if;



l_ntest1 := 0;
	  	
brprint;  
sectionprint('Bug#2691008 Type Orphans');
brprint;


sqltxt := 'select org_id,''AP_INVOICE_DISTRIBUTIONS_ALL'' Table1, count(*)'
||' from ap_invoice_distributions_all where posted_flag = ''Y'' and accounting_event_id is null'
||' and last_update_date >='''||l_last_updated||''''
||' group by org_id'
||' UNION'
||' select org_id,''AP_INVOICE_PAYMENTS_ALL'' Table1, count(*)'
||' from ap_invoice_payments_all where posted_flag = ''Y'' and accounting_event_id is null'
||' and last_update_date >='''||l_last_updated||''''
||' group by org_id'
||' UNION'
||' select org_id,''AP_PAYMENT_HISTORY_ALL'' Table1, count(*)'
||' from ap_payment_history_all where posted_flag = ''Y'' and accounting_event_id is null'
||' and last_update_date >='''||l_last_updated||''''
||' group by org_id'
||' order by org_id, Table1';
	  	  
	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 35);
	  dbms_sql.define_column(l_cursor, 3, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Table', 35)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 35)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 35)||rpad(nvl(to_char(l_num2),' '), 15));

	  if l_num2 > 0 then
	  l_ntest1 := l_num2;
	  end if;

	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);	  
 

brprint;	  
tab0print('This section will verify if any of the orphans are due to bug#2691008.');
tab0print('Transactions have posted flags = Y ,accounting_event_id is NULL.');
brprint;
	  
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have orphans accounting events possibly due to bug#2691008');
	  ErrorPrint('Possible causes:  bug#2691008 ');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;
:l_details := :l_details||'R1';
	  else
	  brprint;
	  tab0print('No problem rows found');
	  brprint;
	  end if;

l_ntest1 := 0;

brprint;
sectionprint('Type 1 - 6 Orphans');
brprint;

sqlTxt := 'select org_id, ''Type 1'' orphan_type, count(ael.ae_line_id)  '
 ||' from ap_ae_lines_all ael '
 ||' where not exists (select ''no parent row in aea'' from ap_ae_headers_all aeh '
 ||' where ael.ae_header_id = aeh.ae_header_id) '
 ||' and ael.last_update_date >='''||l_last_updated||''''
 ||' group by org_id '
 ||' UNION '
 ||' select org_id, ''Type 2'' orphan_type, count(aeh.accounting_event_id)  '
 ||' from ap_ae_headers_all aeh '
 ||' where exists (select ''rows in aeh'' from ap_ae_lines_all ael  '
 ||' where aeh.ae_header_id = ael.ae_header_id) '
 ||' and not exists (select ''no parent row in aea'' from ap_accounting_events_all aea '
 ||' where aea.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aeh.accounting_event_id) '
 ||' and aeh.last_update_date >='''||l_last_updated||''''
 ||' group by org_Id '
 ||' UNION '
 ||' select org_id, ''Type 3'' orphan_type, count(aeh.accounting_event_id)  '
 ||' from ap_ae_headers_all aeh '
 ||' where  '
 ||' not exists (select ''no parent row in aea'' from ap_accounting_events_all aea '
 ||' where aea.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists (select ''no parent row in aea'' from ap_ae_lines_all ael '
 ||' where aeh.ae_header_id = ael.ae_header_id) '
 ||' and not exists '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aeh.accounting_event_id) '
 ||' and aeh.last_update_date >='''||l_last_updated||''''
 ||' group by org_id '
 ||' UNION '
 ||' select org_id, ''Type 4'' orphan_type, count(aea.accounting_event_id)  '
 ||' from ap_accounting_events_all aea '
 ||' where  '
 ||' not exists  '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aeh'' from ap_ae_headers_all aeh where aeh.accounting_event_id = aea.accounting_event_id) '
 ||' and aea.last_update_date >='''||l_last_updated||''''
 ||' group by org_id '
 ||' UNION '
 ||' select org_id, ''Type 5'' orphan_type, count(aea.accounting_event_id)  '
 ||' from ap_accounting_events_all aea '
 ||' where not exists  '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aea.accounting_event_id) '
 ||' and exists '
 ||' (select ''rows in aeh'' from ap_ae_headers_all aeh where aeh.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''rows in ael and aeh'' from ap_ae_lines_all ael, ap_ae_headers_all aeh '
 ||' where ael.ae_header_id = aeh.ae_header_id  '
 ||' and aeh.accounting_event_id = aea.accounting_event_id) '
 ||' and aea.last_update_date >='''||l_last_updated||''''
 ||' group by org_id '
 ||' UNION '
 ||' select org_id, ''Type 6'' orphan_type, count(aea.accounting_event_id)  '
 ||' from ap_accounting_events_all aea '
 ||' where not exists  '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aea.accounting_event_id) '
 ||' and exists '
 ||' (select ''rows in ael and aeh'' from ap_ae_lines_all ael, ap_ae_headers_all aeh '
 ||' where ael.ae_header_id = aeh.ae_header_id  '
 ||' and aeh.accounting_event_id = aea.accounting_event_id) '
 ||' and aea.last_update_date >='''||l_last_updated||''''
 ||' group by org_id '
 ||' order by org_id ';

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_num1);
	  dbms_sql.define_column(l_cursor, 2, l_var1, 25);
	  dbms_sql.define_column(l_cursor, 3, l_num2);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_num1);
	    dbms_sql.column_value(l_cursor, 2, l_var1);
	    dbms_sql.column_value(l_cursor, 3, l_num2);
	    
	    if l_counter = 1 then
	   
	    tab0print(rpad('Org ID', 15)||rpad('Orphan Type', 15)||rpad('Count', 15));
	    
	    tab0print(rpad('--------------', 15)||rpad('--------------', 15)||rpad('--------------', 15));
	    
	    end if;
 
tab0print(rpad(nvl(to_char(l_num1),' '), 15)||rpad(nvl(l_var1,' '), 15)||rpad(nvl(to_char(l_num2),' '), 15));

          if l_num2 > 0 then
	  l_ntest1 := l_num2;
	  end if;

	  	  end loop;
	  	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  	  dbms_sql.close_cursor(l_cursor);


brprint;
tab0print('Type 1:  Exists in ap_ae_lines, but not in ap_ae_headers.');
tab0print('Type 2:  Exists in ap_ae_headers and ap_ae_lines, but not in ap_accounting_events,');
tab0print('ap_payment_history, ap_invoice_payments, or ap_invoice_distributions.');
tab0print('Type 3:  Exists in ap_ae_headers, but not in ap_accounting_events or ap_ae_lines,');
tab0print('ap_payment_history, ap_invoice_payments, or ap_invoice_distributions.');
tab0print('Type 4: Exists in ap_accounting_events, but their are no corresponding transaction rows in ');
tab0print('ap_payment_history, ap_invoice_payments, ap_invoice_distributions or child rows in ap_ae_headers.');
tab0print('Type 5: Exists in ap_accounting_events and ap_ae_headers, but their are no corresponding');
tab0print('transaction rows in ap_payment_history, ap_invoice_payments, ap_invoice_distributions');
tab0print('and no child records in ap_ae_lines.');
tab0print('Type 6: Exists in ap_accounting_events and ap_ae_headers, and ap_ae_lines, but their are no corresponding');
tab0print('transaction rows in ap_payment_history, ap_invoice_payments, ap_invoice_distributions.');
brprint;
 
	  if l_ntest1 > 0 then
	  brprint;
	  ErrorPrint('One or more orgs have orphans accounting events.');
	  ErrorPrint('Possible causes:  bug#''s 3181211, 3113023, 2992669, 1829255, 2322995, 2592312 ');
	  ActionErrorPrint('Please log an iTar with support for further analysis.');
	  brprint;
:l_details := :l_details||'S1';
	  else
	  brprint;
	  tab0print('No problem rows found');
	  brprint;
	  end if;

EXCEPTION

When l_exception then

tab0print('');


when others then --exception section3

  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in test');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('', '');
  BRPrint;

end; --end3



/* -------------------- Feedback ---------------------------- */

    BRPrint;
    Show_Footer('', '');

/* -------------------- Exception Section -------------------------- */

exception when others then --exception section 2

  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in test');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('', '');
  BRPrint;

end; --end2

exception when others then   --exceptions section 1

  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in test');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('', '');
  BRPrint;

end; -- end 1

/




REM  ==============SQL PLUS Environment setup===================

Spool off

set termout on

PROMPT 
prompt Output spooled to filename &outputfilename
prompt 

Prompt
Prompt Running Details...
Prompt

define outputfilename = APAtgHealthCheck_Details_&v_date..txt

spool  &outputfilename



REM =================Run the Pl/SQL api file ===================================

@@CoreApiTxtX.sql
begin  -- begin1

declare --declare 2

p_username varchar2(100);

p_respid number;

/* ------------------------ Declare Section -----------------------------*/

begin  --begin2

Show_Header('', 'AP Accounting Health Check');

/* -------------------- Execution secion ------------------------------- */

Declare  --declare 3

disp_lengths 	lengths;		
col_headers  	headers;

l_exception		exception;
l_error_msg		varchar2(500);
l_count 		NUMBER;
SqlTxt			varchar2(5000);
SqlTxt2			varchar2(5000);
l_cursor		integer;
l_max_rows		number := &v_max_rows;
l_counter	integer;
l_num1		number;
l_num2		number;
l_num3		number;
l_num4		number;
l_num5		number;
l_var1		varchar2(80);
l_var2		varchar2(80);
l_var3		varchar2(80);
l_var4		varchar2(80);
l_var5		varchar2(80);
l_ntest1	number;
l_ntest2	number;
l_ntest3	number;
l_ntest4	number;
l_ntest5	number;
l_vtest1	varchar2(80);
l_vtest2	varchar2(80);
l_vtest3	varchar2(80);
l_vtest4	varchar2(80);
l_vtest5	varchar2(80);
l_date1		date;
l_date2		date;
l_date3		date;
l_date4		date;
l_date5		date;
l_patch_level   varchar2(10);
l_last_updated  date;

Begin  --begin 3


if :l_prob_details = 'Y' and :p_continue = 'Y' then

l_last_updated := to_date('&v_last_updated', 'DD-MON-YYYY');

sqlTxt := 'select nvl(max(patch_level),''NA'') from fnd_product_installations where application_id = 200';

execute immediate sqltxt into l_patch_level;

brprint;
sectionprint('AP Patch Level: '||l_patch_level);

sectionprint('Parameter Information');
tab0print('Created/Updated On or After: '||l_last_updated);
tab0print('Show Details: '||:l_prob_details);
tab0print('Max Rows: '||l_max_rows);
brprint;


l_ntest1 := 0;

if :l_details like '%A1%' then

sqltxt := 'select distinct aea.org_id, aea.event_type_code, aea.event_status_code, aea.accounting_event_id, aea.source_table, aea.source_id'
||' from ap_accounting_events_all aea'
||' where aea.event_status_code like ''%ACCOUNTED%'''
||' and aea.last_update_date >='''||l_last_updated||''''
||' and exists'
||' (select 1'
||' from ap_invoice_distributions_all aid'
||' where aid.accounting_event_id = aea.accounting_event_id '
||' and aid.posted_flag <> ''Y'''
||' UNION'
||' select 1'
||' from ap_invoice_payments_all aip'
||' where aip.accounting_event_id = aea.accounting_event_id '
||' and aip.posted_flag <> ''Y'''
||' UNION'
||' select 1'
||' from ap_payment_history_all aph'
||' where aph.accounting_event_id = aea.accounting_event_id '
||' and aph.posted_flag <> ''Y'')'
||' order by 1,4';

disp_lengths := lengths(10,15,15,15,15,15);

RUN_SQL('Accounting Event Status = ACCOUNTED and Posted Flag <> Y', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%B1%' then

sqltxt :=  'select distinct aid.org_id, aid.invoice_id, aid.invoice_distribution_id, aid.accounting_event_id,'
||' aid.posted_flag, aid.accrual_posted_flag, aid.cash_posted_flag, aid.match_status_flag'
||' from ap_invoice_distributions_all aid, ap_system_parameters_all asp'
||' where aid.posted_flag != decode(asp.accounting_method_option, ''Cash'',aid.cash_posted_flag,aid.accrual_posted_flag)'
||' and nvl(asp.org_id,-99) = nvl(aid.org_id,-99)'
||' and aid.last_update_date >='''||l_last_updated||''''
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15,15,15,15);

RUN_SQL('Out of sync posted flags (Invoices)', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%C1%' then

sqltxt :=  'select distinct aip.org_id, aip.invoice_id, aip.accounting_event_id, aip.check_id, aip.invoice_payment_id,'
||' aip.posted_flag, aip.accrual_posted_flag, aip.cash_posted_flag'
||' from ap_invoice_payments_all aip, ap_system_parameters_all asp'
||' where aip.posted_flag != decode(asp.accounting_method_option, ''Cash'',aip.cash_posted_flag,aip.accrual_posted_flag)'
||' and nvl(asp.org_id,-99) = nvl(aip.org_id,-99)'
||' and aip.last_update_date >='''||l_last_updated||''''
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15,15,15,15);

RUN_SQL('Out of sync posted flags (Payments)', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%D1%' then

sqltxt := 'select distinct aid.org_id, aid.invoice_id, gps.set_of_books_id,  to_char(aid.accounting_date, ''MON-YYYY'') atg_date, gps.period_name,'
||' aid.posted_flag, gps.start_date, gps.end_date, gps.closing_status'
||' from ap_invoice_distributions_all aid,'
||' ap_system_parameters_all asp,'  --added
||' gl_period_statuses gps'
||' where gps.closing_status not in (''F'', ''O'')'
||' and gps.application_id = 200'
||' and aid.posted_flag != ''Y'''
||' and (aid.posted_flag = decode(asp.accounting_method_option, ''Cash'',aid.cash_posted_flag,aid.accrual_posted_flag)'
||'      or aid.posted_flag = ''S'')'
||' and nvl(asp.org_id,-99) = nvl(aid.org_id,-99)'  --added
||' and asp.set_of_books_id = gps.set_of_books_id'  --added
||' and aid.period_name = gps.period_name'
||' and aid.last_update_date >='''||l_last_updated||''''
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15,15,15,15,10);

RUN_SQL('Unaccounted Invoices in a Closed Period', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;


if :l_details like '%E1%' then

sqltxt := 'select distinct aip.org_id, aip.invoice_id, aip.check_id, gps.set_of_books_id,'
||' to_char(aip.accounting_date, ''MON-YYYY'') atg_date, gps.period_name,'
||' aip.posted_flag, gps.start_date, gps.end_date, gps.closing_status'
||' from ap_checks_all ac, ap_invoice_payments_all aip,'
||' ap_system_parameters_all asp,'  --added
||' gl_period_statuses gps'
||' where ac.check_id = aip.check_id'
||' and gps.closing_status not in (''F'', ''O'')'
||' and gps.application_id = 200'
||' and aip.posted_flag != ''Y'''
||' and (aip.posted_flag = decode(asp.accounting_method_option, ''Cash'',aip.cash_posted_flag,aip.accrual_posted_flag)'
||'     or aip.posted_flag = ''S'')'
||' and nvl(asp.org_id,-99) = nvl(aip.org_id,-99)'  --added
||' and asp.set_of_books_id = gps.set_of_books_id'  --added
||' and aip.period_name = gps.period_name'
||' and aip.last_update_date >='''||l_last_updated||''''
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15,15,15,15,15,10);

RUN_SQL('Unaccounted Payments in a Closed Period', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%F1%' then

sqltxt := 'select distinct aph.org_id, aph.check_id, aph.payment_history_id, gps.set_of_books_id,  to_char(aph.accounting_date, ''MON-YYYY'') atg_date, gps.period_name,'
||' aph.posted_flag, gps.start_date, gps.end_date, gps.closing_status'
||' from ap_checks_all ac, ap_payment_history_all aph,'
||' ap_system_parameters_all asp,'  --added
||' gl_period_statuses gps'
||' where ac.check_id = aph.check_id'
||' and gps.closing_status not in (''F'', ''O'')'
||' and gps.application_id = 200'
||' and aph.posted_flag != ''Y'''
||' and nvl(asp.org_id,-99) = nvl(aph.org_id,-99)'  --added
||' and asp.set_of_books_id = gps.set_of_books_id'  --added
||' and aph.accounting_date between gps.start_date and gps.end_date'
||' and aph.last_update_date >='''||l_last_updated||''''
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15,15,15,15,15,10);

RUN_SQL('Unaccounted Clearing transactions in a Closed Period', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;


if l_patch_level >= '11i.AP.K' then

if :l_details like '%G1%' then

sqltxt := 'select distinct aea.org_id, aea.accounting_event_id, gps.set_of_books_id,  to_char(aea.accounting_date, ''MON-YYYY'') atg_date, gps.period_name,'
||' gps.start_date, gps.end_date, gps.closing_status'
||' from ap_accounting_events_all aea,'
||' ap_system_parameters_all asp,'  --added
||' gl_period_statuses gps'
||' where gps.closing_status not in (''F'', ''O'')'
||' and gps.application_id = 200'
||' and aea.event_status_code not like ''%ACCOUNTED%'''
||' and nvl(asp.org_id,-99) = nvl(aea.org_id,-99)'  --added
||' and asp.set_of_books_id = gps.set_of_books_id'  --added
||' and aea.accounting_date between gps.start_date and gps.end_date'
||' and aea.last_update_date >='''||l_last_updated||''''
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15,15,15,10);

RUN_SQL('Unaccounted Events in a Closed Period', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

end if;

if :l_details like '%H1%' then

sqltxt := 'select distinct aid.org_id, substr(''Invoice'',1,15) trans_type, ''Invoice ID: ''||to_char(aid.invoice_id) trans_id, aid.accounting_event_id, aid.accounting_date'
||' from ap_invoice_distributions_all aid'
||' where aid.accounting_event_id is not null'
||' and aid.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aid.accounting_event_id)'
||' UNION'
||' select distinct aip.org_id, substr(''Payment'',1,15) trans_type, ''Invoice ID: ''||to_char(aip.invoice_id) trans_id, aip.accounting_event_id, aip.accounting_date'
||' from ap_invoice_payments_all aip'
||' where aip.accounting_event_id is not null'
||' and aip.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aip.accounting_event_id)'
||' UNION'
||' select distinct aph.org_id, substr(''Clearing'',1,15) trans_type, ''Check ID: ''||to_char(aph.check_id) trans_id, aph.accounting_event_id, aph.accounting_date'
||' from ap_payment_history_all aph'
||' where aph.accounting_event_id is not null'
||' and aph.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aph.accounting_event_id)'
||' order by 1,3';

disp_lengths := lengths(10,15,25,15,15);

RUN_SQL('Transactions with Accounting_event_ids and no event rows', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%T1%' then

l_ntest1 := 0;

sqltxt := 'select distinct aid.org_id, substr(''Invoice'',1,15) trans_type, ''Invoice ID: ''||to_char(aid.invoice_id) trans_id, aid.accounting_event_id, aid.accounting_date'
||' from ap_invoice_distributions_all aid'
||' where aid.accounting_event_id is not null'
||' and aid.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aid.accounting_event_id)'
||' and exists'
||' (select 1 from ap_ae_headers_all aeh'
||' where aeh.accounting_event_id = aid.accounting_event_id)'
||' UNION'
||' select distinct aip.org_id, substr(''Payment'',1,15) trans_type, ''Invoice ID: ''||to_char(aip.invoice_id) trans_id, aip.accounting_event_id, aip.accounting_date'
||' from ap_invoice_payments_all aip'
||' where aip.accounting_event_id is not null'
||' and aip.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aip.accounting_event_id)'
||' and exists'
||' (select 1 from ap_ae_headers_all aeh'
||' where aeh.accounting_event_id = aip.accounting_event_id)'
||' UNION'
||' select distinct aph.org_id, substr(''Clearing'',1,15) trans_type, ''Check ID: ''||to_char(aph.check_id) trans_id, aph.accounting_event_id, aph.accounting_date'
||' from ap_payment_history_all aph'
||' where aph.accounting_event_id is not null'
||' and aph.last_update_date >='''||l_last_updated||''''
||' and not exists'
||' (select 1 from ap_accounting_events_all aea'
||' where aea.accounting_event_id = aph.accounting_event_id)'
||' and exists'
||' (select 1 from ap_ae_headers_all aeh'
||' where aeh.accounting_event_id = aph.accounting_event_id)'
||' order by 1,2';

disp_lengths := lengths(10,15,25,15,15);

RUN_SQL('Transactions with Accounting_event_ids and no event rows, but headers exist', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%I1%' then


sqltxt := 'select aea.org_id, aea.accounting_event_id, aeh.ae_header_id, aea.event_status_code, aea.event_type_code, aea.source_table, aea.source_id'
||' from ap_ae_headers_all aeh, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aeh.accounting_event_id(+)'
||' and aea.event_status_code not like ''%ACCOUNTED%'''
||' and aeh.accounting_event_id is not null'
||' and aea.last_update_date >='''||l_last_updated||''''
||' order by 1,2';


disp_lengths := lengths(10,15,15,15,15,15,15);

RUN_SQL('Accounting event data - Unaccounted Events with Headers', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;
	  
if :l_details like '%I2%' then


sqltxt := 'select aea.org_id, aea.accounting_event_id, aeh.ae_header_id, aea.event_status_code, aea.event_type_code, aea.source_table, aea.source_id'
||' from ap_ae_headers_all aeh, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aeh.accounting_event_id(+)'
||' and aea.event_status_code like ''%ACCOUNTED%'''
||' and aeh.accounting_event_id is null'
||' and aea.last_update_date >='''||l_last_updated||''''
||' order by 1,2';


disp_lengths := lengths(10,15,15,15,15,15,15);

RUN_SQL('Accounting event data - Accounted Events with No Headers', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%J1%' then

sqltxt := 'select org_id, invoice_id, invoice_distribution_id, posted_flag, match_status_flag, accounting_event_id'
||' from ap_invoice_distributions_all'
||' where last_update_date >='''||l_last_updated||''''
||' and posted_flag = ''Y'''
||' and accounting_event_id is NULL'
||' order by org_id';



disp_lengths := lengths(10,15,15,15,15,15);

RUN_SQL('Invoice Distribution Accounting Event Data - Posted_flag = Y and Accounting_event_id is NULL', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;


if l_patch_level >= '11i.AP.K' then

if :l_details like '%J2%' then

sqltxt := 'select org_id, invoice_id, invoice_distribution_id, posted_flag, match_status_flag, accounting_event_id'
||' from ap_invoice_distributions_all'
||' where last_update_date >='''||l_last_updated||''''
||' and nvl(match_status_flag,''N'') not in (''A'', ''T'')'
||' and accounting_event_id is NOT NULL'
||' order by org_id';



disp_lengths := lengths(10,15,15,15,15,15);

RUN_SQL('Invoice Distribution Accounting Event Data - Match Status Flag not equal to A or T and NOT NULL accounting_event_ids', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

end if;

if l_patch_level >= '11i.AP.K' then

if :l_details like '%J3%' then

sqltxt := 'select org_id, invoice_id, invoice_distribution_id, posted_flag, match_status_flag, accounting_event_id'
||' from ap_invoice_distributions_all'
||' where last_update_date >='''||l_last_updated||''''
||' and nvl(match_status_flag,''N'') in (''A'', ''T'')'
||' and accounting_event_id is NULL'
||' order by org_id';



disp_lengths := lengths(10,15,15,15,15,15);

RUN_SQL('Invoice Distribution Accounting Event Data - Match Status Flag equal to A or T and NULL accounting_event_ids', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

end if;


if :l_details like '%K1%' then


sqltxt := 'select org_id, invoice_id, check_id, invoice_payment_id, posted_flag, accounting_event_id'
||' from ap_invoice_payments_all'
||' where last_update_date >='''||l_last_updated||''''
||' and posted_flag = ''Y'''
||' and accounting_event_id is NULL'
||' order by 1,3';

disp_lengths := lengths(10,15,15,15,15,15);

RUN_SQL('Payment Accounting Event data - Posted_flags = Y and NULL accounting_event_ids', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if l_patch_level >= '11i.AP.K' then

if :l_details like '%K2%' then

sqltxt := 'select org_id, invoice_id, check_id, invoice_payment_id, posted_flag, accounting_event_id'
||' from ap_invoice_payments_all'
||' where last_update_date >='''||l_last_updated||''''
||' and accounting_event_id is NULL'
||' order by 1,3';

disp_lengths := lengths(10,15,15,15,15,15);

RUN_SQL('Payment Accounting Event data - NULL accounting_event_ids', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

end if;


if :l_details like '%L1%' then


sqltxt := 'select org_id, check_id, payment_history_id, posted_flag, accounting_event_id'
||' from ap_payment_history_all'
||' where last_update_date >='''||l_last_updated||''''
||' and posted_flag = ''Y'''
||' and accounting_event_id is NULL'
||' order by org_id';

disp_lengths := lengths(10,15,15,15);

RUN_SQL('Payment History Event data - Posted_flags = Y and NULL accounting_event_ids', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;




if l_patch_level >= '11i.AP.K' then

if :l_details like '%L2%' then

sqltxt := 'select org_id, check_id, payment_history_id, posted_flag, accounting_event_id'
||' from ap_payment_history_all'
||' where last_update_date >='''||l_last_updated||''''
||' and accounting_event_id is NULL'
||' order by org_id';

disp_lengths := lengths(10,15,15,15);

RUN_SQL('Payment History Event data - NULL accounting_event_ids', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

end if;


if :l_details like '%M1%' then

sqltxt := 'select ap.org_id, ap.check_id, ap.invoice_id, ap.invoice_payment_id, ap.accounting_event_id, ap.posted_flag'
||' from ap_invoice_payments_all ap '
||' where accounting_event_id is not null'
||' and ap.last_update_date >='''||l_last_updated||''''
||' and reversal_inv_pmt_id is null'
||' and exists '
||'      (select check_id from ap_invoice_payments_all aip'
||'       where accounting_event_id is null and '
||'       ap.check_id = aip.check_id)'
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15,10);

RUN_SQL('Accounting for Payments with multiple invoices - Missing Accounting Event Ids', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%M2%' then

sqltxt := 'select ap.org_id, ap.check_id, ap.invoice_id, ap.invoice_payment_id, ap.accounting_event_id, ap.posted_flag'
||' from ap_invoice_payments_all aip'
||' where aip.accounting_event_id is not null'
||' and aip.last_update_date >='''||l_last_updated||''''
||' and aip.posted_flag = ''Y'''
||' and exists'
||' (select 1 from ap_invoice_payments_all aip2'
||' where aip2.check_id = aip.check_Id'
||' and aip2.accounting_event_id is not null'
||' and aip2.accounting_event_id = aip.accounting_event_id'
||' and aip2.posted_flag != ''Y'')'
||' group by aip.org_id'
||' order by aip.org_id';

disp_lengths := lengths(10,15,15,15,15,10);

RUN_SQL('Accounting for Payments with multiple invoices - Mismatched Posted Flags', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%N1%' then

sqltxt := 'select distinct aid.org_id , substr(''INVOICES'',1,15) TRANS_TYPE, ''Invoice ID: ''||to_char(aid.invoice_id) trans_id, aea.accounting_event_id,'
||' aid.accounting_date trans_atg_date, aea.accounting_date event_atg_date'
||' from ap_invoice_distributions_all aid, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aid.accounting_event_id'
||' and aea.last_update_date >='''||l_last_updated||''''
||' and trunc(aea.accounting_date) <> trunc(aid.accounting_date)'
||' UNION'
||' select distinct aip.org_id, substr(''PAYMENTS'',1,15) TRANS_TYPE, ''Check ID: ''||to_char(aip.check_id) trans_id, aea.accounting_event_id,'
||' aip.accounting_date trans_atg_date, aea.accounting_date event_atg_date'
||' from ap_invoice_payments_all aip, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aip.accounting_event_id'
||' and aea.last_update_date >='''||l_last_updated||''''
||' and trunc(aea.accounting_date) <> trunc(aip.accounting_date)'
||' UNION'
||' select distinct aph.org_id, substr(''CLEARING'',1,15) TRANS_TYPE, ''Check ID: ''||to_char(aph.check_id) trans_id, aea.accounting_event_id,' 
||' aph.accounting_date trans_atg_date, aea.accounting_date event_atg_date'
||' from ap_payment_history_all aph, ap_accounting_events_all aea'
||' where aea.accounting_event_id = aph.accounting_event_id'
||' and aea.last_update_date >='''||l_last_updated||''''
||' and trunc(aea.accounting_date) <> trunc(aph.accounting_date)'
||' ORDER BY 1,2,3';

disp_lengths := lengths(10,15,25,15,15,15);

RUN_SQL('Out of Sync Accounting Dates', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%O1%' then

sqltxt := 'select aeh2.org_id, aeh2.ae_header_id, aeh2.period_name, aeh2.gl_transfer_flag, aeh2.gl_transfer_run_id'
||' from ap_ae_headers_all aeh2,'
||' (select AEH.ORG_ID, aeh.ae_header_id, '
||' decode((nvl(sum(ael.accounted_dr),0) - nvl(sum(ael.accounted_cr),0)), 0,NULL, ''UNBALANCED'') ACCT,'
||' decode((nvl(sum(ael.entered_dr),0) - nvl(sum(ael.entered_cr),0)), 0,NULL, ''UNBALANCED'') ENT'
||'  from ap_ae_headers_all aeh, ap_ae_lines_all ael, ap_accounting_events_all aea'
||'  where ael.ae_header_id = aeh.ae_header_id'
||' and aeh.accounting_event_id = aea.accounting_event_id'
||' having '
||' nvl(sum(ael.accounted_dr),0) <> nvl(sum(ael.accounted_cr),0) '
||' group by AEH.ORG_ID, aeh.period_name, aeh.org_id, aea.source_table, aea.source_id, aeh.accounting_event_id, aeh.ae_header_id,  aeh.gl_transfer_run_id, aeh.gl_transfer_flag) UNBAL'
||' where aeh2.ae_header_id = unbal.ae_header_id'
||' and aeh2.last_update_date >='''||l_last_updated||''''
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15);

RUN_SQL('Out of Balance Headers - Accounted Amounts', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;
	  
if :l_details like '%O2%' then

sqltxt := 'select distinct aeh2.org_id, aeh2.ae_header_id, aeh2.period_name, aeh2.gl_transfer_flag, aeh2.gl_transfer_run_id'
||' from ap_ae_headers_all aeh2,'
||' (select AEH.ORG_ID, aeh.ae_header_id, '
||' decode((nvl(sum(ael.accounted_dr),0) - nvl(sum(ael.accounted_cr),0)), 0,NULL, ''UNBALANCED'') ACCT,'
||' decode((nvl(sum(ael.entered_dr),0) - nvl(sum(ael.entered_cr),0)), 0,NULL, ''UNBALANCED'') ENT'
||'  from ap_ae_headers_all aeh, ap_ae_lines_all ael, ap_accounting_events_all aea'
||'  where ael.ae_header_id = aeh.ae_header_id'
||' and aeh.accounting_event_id = aea.accounting_event_id'
||' having '
||' nvl(sum(ael.entered_dr),0) <> nvl(sum(ael.entered_cr),0)'
||' group by AEH.ORG_ID, aeh.period_name, aeh.org_id, aea.source_table, aea.source_id, aeh.accounting_event_id, aeh.ae_header_id,  aeh.gl_transfer_run_id, aeh.gl_transfer_flag) UNBAL'
||' where aeh2.ae_header_id = unbal.ae_header_id'
||' and aeh2.last_update_date >='''||l_last_updated||''''
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15);

RUN_SQL('Out of Balance Headers - Entered Amounts', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%P1%' then
	  	
sqltxt := 'select distinct org_id, ae_header_id, ae_line_id, accounted_dr, accounted_dr'
||' from ap_ae_lines_all'
||' where ae_line_type_code = ''ROUNDING'''
||' and last_update_date >='''||l_last_updated||''''
||' and abs(nvl(accounted_dr, accounted_cr)) > .10'
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15);

RUN_SQL('ROUNDING lines greater then $.10', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%Q1%' then

sqltxt := 'select distinct org_id, ae_header_id, ae_line_id, accounted_dr, accounted_cr'
||' from ap_ae_lines_all'
||' where ae_line_type_code = ''WRITEOFF'''
||' and last_update_date >='''||l_last_updated||''''
||' and abs(nvl(accounted_dr, accounted_cr)) > .10'
||' order by 1,2';

disp_lengths := lengths(10,15,15,15,15);

RUN_SQL('WRITEOFF lines greater then $.10', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%R1%' then
	  	
sqltxt := 'select distinct org_id,''AP_INVOICE_DISTRIBUTIONS_ALL'' Table1, ''Invoice ID: ''||to_char(invoice_id) trans_id, posted_flag'
||' from ap_invoice_distributions_all where posted_flag = ''Y'' and accounting_event_id is null'
||' and last_update_date >='''||l_last_updated||''''
||' UNION'
||' select distinct org_id,''AP_INVOICE_PAYMENTS_ALL'' Table1, ''Check ID: ''||to_char(check_id) trans_id, posted_flag'
||' from ap_invoice_payments_all where posted_flag = ''Y'' and accounting_event_id is null'
||' and last_update_date >='''||l_last_updated||''''
||' UNION'
||' select distinct org_id,''AP_PAYMENT_HISTORY_ALL'' Table1, ''Check ID: ''||to_char(check_id) trans_id, posted_flag'
||' from ap_payment_history_all where posted_flag = ''Y'' and accounting_event_id is null'
||' and last_update_date >='''||l_last_updated||''''
||' order by 1,2,3';
	  	  
disp_lengths := lengths(10,15,25,15);

RUN_SQL('Bug#2691008 Type Orphans', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;

if :l_details like '%S1%' then

sqlTxt := 'select distinct org_id, substr(''Type 1'',1,15) orphan_type, ''Header ID: ''||to_char(ael.ae_header_id) trans_id  '
 ||' from ap_ae_lines_all ael '
 ||' where not exists (select ''no parent row in aea'' from ap_ae_headers_all aeh '
 ||' where ael.ae_header_id = aeh.ae_header_id) '
 ||' and ael.last_update_date >='''||l_last_updated||''''
 ||' UNION '
 ||' select distinct org_id, substr(''Type 2'',1,15) orphan_type, ''Event ID: ''||to_char(aeh.accounting_event_id) trans_id '
 ||' from ap_ae_headers_all aeh '
 ||' where exists (select ''rows in aeh'' from ap_ae_lines_all ael  '
 ||' where aeh.ae_header_id = ael.ae_header_id) '
 ||' and not exists (select ''no parent row in aea'' from ap_accounting_events_all aea '
 ||' where aea.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aeh.accounting_event_id) '
 ||' and aeh.last_update_date >='''||l_last_updated||''''
 ||' UNION '
 ||' select distinct org_id, substr(''Type 3'',1,15) orphan_type, ''Event ID: ''||to_char(aeh.accounting_event_id) trans_id  '
 ||' from ap_ae_headers_all aeh '
 ||' where  '
 ||' not exists (select ''no parent row in aea'' from ap_accounting_events_all aea '
 ||' where aea.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists (select ''no parent row in aea'' from ap_ae_lines_all ael '
 ||' where aeh.ae_header_id = ael.ae_header_id) '
 ||' and not exists '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aeh.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aeh.accounting_event_id) '
 ||' and aeh.last_update_date >='''||l_last_updated||''''
 ||' UNION '
 ||' select distinct org_id, substr(''Type 4'',1,15) orphan_type, ''Event ID: ''||to_char(aea.accounting_event_id) trans_id  '
 ||' from ap_accounting_events_all aea '
 ||' where  '
 ||' not exists  '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aeh'' from ap_ae_headers_all aeh where aeh.accounting_event_id = aea.accounting_event_id) '
 ||' and aea.last_update_date >='''||l_last_updated||''''
 ||' UNION '
 ||' select distinct org_id, substr(''Type 5'',1,15) orphan_type, ''Event ID: ''||to_char(aea.accounting_event_id) trans_id '
 ||' from ap_accounting_events_all aea '
 ||' where not exists  '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aea.accounting_event_id) '
 ||' and exists '
 ||' (select ''rows in aeh'' from ap_ae_headers_all aeh where aeh.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''rows in ael and aeh'' from ap_ae_lines_all ael, ap_ae_headers_all aeh '
 ||' where ael.ae_header_id = aeh.ae_header_id  '
 ||' and aeh.accounting_event_id = aea.accounting_event_id) '
 ||' and aea.last_update_date >='''||l_last_updated||''''
 ||' UNION '
 ||' select distinct org_id, substr(''Type 6'',1,15) orphan_type, ''Event ID: ''||to_char(aea.accounting_event_id) trans_id  '
 ||' from ap_accounting_events_all aea '
 ||' where not exists  '
 ||' (SELECT ''no rows in aip'' FROM  ap_invoice_payments_all aip where aip.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aph'' from ap_payment_history_all aph where aph.accounting_event_id = aea.accounting_event_id) '
 ||' and not exists '
 ||' (select ''no rows in aid'' from ap_invoice_distributions_all aid where aid.accounting_event_id = aea.accounting_event_id) '
 ||' and exists '
 ||' (select ''rows in ael and aeh'' from ap_ae_lines_all ael, ap_ae_headers_all aeh '
 ||' where ael.ae_header_id = aeh.ae_header_id  '
 ||' and aeh.accounting_event_id = aea.accounting_event_id) '
 ||' and aea.last_update_date >='''||l_last_updated||''''
 ||' order by 1,2,3';

disp_lengths := lengths(10,15,25);

RUN_SQL('Type 1 - 6 Orphans', sqltxt,disp_lengths,col_headers,l_max_rows);

end if;



ELSE

brprint;
tab0print('Problem details not selected');
brprint;

END IF;

EXCEPTION

When l_exception then

tab0print('');

when others then --exception section3

  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in test');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('', '');
  BRPrint;

end; --end3



/* -------------------- Feedback ---------------------------- */

    BRPrint;
    Show_Footer('', '');

/* -------------------- Exception Section -------------------------- */

exception when others then --exception section 2

  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in test');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('', '');
  BRPrint;

end; --end2

exception when others then   --exceptions section 1

  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in test');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('', '');
  BRPrint;

end; -- end 1

/




REM  ==============SQL PLUS Environment setup===================

Spool off

set termout on

PROMPT 
prompt Output spooled to filename &outputfilename
prompt 



