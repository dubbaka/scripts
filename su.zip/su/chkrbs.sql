set heading on
set feed off
set linesize 132
Column space_used format 999D9999
select a.username,a.sid,r.name,b.start_time,a.module,a.action, (b.used_ublk * 8192)/(1024*1024*1024) space_used
from v$session a, v$transaction b,v$rollname r
where a.saddr=b.ses_addr
and b.xidusn = r.usn
and  (b.used_ublk * 8192)/(1024*1024*1024) > 2
order by 7;
set heading off
set feed on

