 SELECT  /*+ index(q, i_queue_name_priority) */ q.request_id, q.id,
         q.q_name, q.phase, q.priority, q.attempts, q.retry_time,
         q.create_time, q.submission_time, q.job_id FROM eps.eps_queue q WHERE
         q.q_name = :1  --and q.priority=:23
 and retry_time <= SYSDATE AND ROWNUM <= :2 AND phase = 1
