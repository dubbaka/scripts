rem Chak 07/16/02
rem This script shows all user sessions for a given apps login id
set linesize 120
set pagesize 100
col user_name forma a10
col description forma a10
col stime forma a20
col sid_no forma 999999
col machine forma a10
col module forma a10
col action forma a15
col process forma a20
select a.user_name user_name,
       a.description description,
       to_char(b.start_time,'DD-MON-YYYY HH24:MI') stime,
       s.sid sid_no, 
       s.inst_id inst,
       s.machine machine,
       s.module  module,
       s.action  action,
       s.process||' (C) '||p.spid||' (S)' Process
from fnd_user a, fnd_logins b, gv$session s, gv$process p
where a.user_id = b.user_id
and p.addr = s.paddr
and s.process = b.spid
and b.end_time is null
and b.start_time > trunc(sysdate) - 1
and a.user_name = '&login_id'
/
