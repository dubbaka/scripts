declare 

cursor c1 is
select owner||'.'||table_name tname,empty_blocks, blocks, avg_row_len
from dba_tables where table_name like 'MLOG$%'
and blocks>100;



begin

	for crec in c1
	loop

	dbms_output.put_line('drop table c_junk;');

	dbms_output.put_line('create table c_junk as select * from '||crec.tname||';');

	dbms_output.put_line('truncate table '||crec.tname||';');

	dbms_output.put_line('insert into '||crec.tname||' select * from c_junk;');

	dbms_output.put_line('commit;');

	dbms_output.put_line('analyze table '||crec.tname||' compute statistics;');

	end loop;

end;
/
