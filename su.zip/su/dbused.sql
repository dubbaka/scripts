select tablespace_name ,sum(bytes)/1024/1024/1024 GB from dba_data_files group by tablespace_name order by 2
/
