SQL> /

revoke INSERT on AR_CUSTOMER_CALL_TOPICS_ALL from xxyh_appsro ;                 
revoke INSERT on AR_NOTES from xxyh_appsro ;                                    
revoke INSERT on AR_CUSTOMER_CALLS_ALL from xxyh_appsro ;                       
revoke ALTER on XXYH_DEF_REV from xxyh_appsro ;                                 
revoke FLASHBACK on XXYH_DEF_REV from xxyh_appsro ;                             
revoke DEBUG on XXYH_DEF_REV from xxyh_appsro ;                                 
revoke QUERY REWRITE on XXYH_DEF_REV from xxyh_appsro ;                         
revoke ON COMMIT REFRESH on XXYH_DEF_REV from xxyh_appsro ;                     
revoke REFERENCES on XXYH_DEF_REV from xxyh_appsro ;                            
revoke UPDATE on XXYH_DEF_REV from xxyh_appsro ;                                
revoke INSERT on XXYH_DEF_REV from xxyh_appsro ;                                
revoke INDEX on XXYH_DEF_REV from xxyh_appsro ;                                 
revoke DELETE on XXYH_DEF_REV from xxyh_appsro ;                                

revoke UPDATE on GOTO_STREAMSERVE_ACT_LOG from xxyh_appsro ;                    
revoke INSERT on GOTO_STREAMSERVE_ACT_LOG from xxyh_appsro ;                    
revoke DELETE on GOTO_STREAMSERVE_ACT_LOG from xxyh_appsro ;                    
revoke UPDATE on GOTO_STREAMSERVE_LOG from xxyh_appsro ;                        
revoke INSERT on GOTO_STREAMSERVE_LOG from xxyh_appsro ;                        
revoke DELETE on GOTO_STREAMSERVE_LOG from xxyh_appsro ;                        
revoke EXECUTE on IS_NUMBER from xxyh_appsro ;                                  
revoke FLASHBACK on XXYH_SPN_CLIENT from xxyh_appsro ;                          
revoke DEBUG on XXYH_SPN_CLIENT from xxyh_appsro ;                              
revoke QUERY REWRITE on XXYH_SPN_CLIENT from xxyh_appsro ;                      
revoke ON COMMIT REFRESH on XXYH_SPN_CLIENT from xxyh_appsro ;                  
revoke REFERENCES on XXYH_SPN_CLIENT from xxyh_appsro ;                         
revoke UPDATE on XXYH_SPN_CLIENT from xxyh_appsro ;                             

revoke INSERT on XXYH_SPN_CLIENT from xxyh_appsro ;                             
revoke INDEX on XXYH_SPN_CLIENT from xxyh_appsro ;                              
revoke DELETE on XXYH_SPN_CLIENT from xxyh_appsro ;                             
revoke ALTER on XXYH_SPN_CLIENT from xxyh_appsro ;                              
revoke FLASHBACK on XXYH_SPN_ACCOUNT from xxyh_appsro ;                         
revoke DEBUG on XXYH_SPN_ACCOUNT from xxyh_appsro ;                             
revoke QUERY REWRITE on XXYH_SPN_ACCOUNT from xxyh_appsro ;                     
revoke ON COMMIT REFRESH on XXYH_SPN_ACCOUNT from xxyh_appsro ;                 
revoke REFERENCES on XXYH_SPN_ACCOUNT from xxyh_appsro ;                        
revoke UPDATE on XXYH_SPN_ACCOUNT from xxyh_appsro ;                            
revoke INSERT on XXYH_SPN_ACCOUNT from xxyh_appsro ;                            
revoke INDEX on XXYH_SPN_ACCOUNT from xxyh_appsro ;                             
revoke DELETE on XXYH_SPN_ACCOUNT from xxyh_appsro ;                            

revoke ALTER on XXYH_SPN_ACCOUNT from xxyh_appsro ;                             
revoke FLASHBACK on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;                 
revoke DEBUG on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;                     
revoke QUERY REWRITE on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;             
revoke ON COMMIT REFRESH on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;         
revoke REFERENCES on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;                
revoke UPDATE on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;                    
revoke INSERT on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;                    
revoke INDEX on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;                     
revoke DELETE on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;                    
revoke ALTER on XXYH_SPN_PRIMARY_CONTACT from xxyh_appsro ;                     
revoke FLASHBACK on XXYH_SPN_PAYMENTS from xxyh_appsro ;                        
revoke DEBUG on XXYH_SPN_PAYMENTS from xxyh_appsro ;                            

revoke QUERY REWRITE on XXYH_SPN_PAYMENTS from xxyh_appsro ;                    
revoke ON COMMIT REFRESH on XXYH_SPN_PAYMENTS from xxyh_appsro ;                
revoke REFERENCES on XXYH_SPN_PAYMENTS from xxyh_appsro ;                       
revoke UPDATE on XXYH_SPN_PAYMENTS from xxyh_appsro ;                           
revoke INSERT on XXYH_SPN_PAYMENTS from xxyh_appsro ;                           
revoke INDEX on XXYH_SPN_PAYMENTS from xxyh_appsro ;                            
revoke DELETE on XXYH_SPN_PAYMENTS from xxyh_appsro ;                           
revoke ALTER on XXYH_SPN_PAYMENTS from xxyh_appsro ;                            
revoke REFERENCES on XXYH_AR_CREDIT from xxyh_appsro ;                          
revoke UPDATE on XXYH_AR_CREDIT from xxyh_appsro ;                              
revoke INSERT on XXYH_AR_CREDIT from xxyh_appsro ;                              
revoke INDEX on XXYH_AR_CREDIT from xxyh_appsro ;                               
revoke DELETE on XXYH_AR_CREDIT from xxyh_appsro ;                              

revoke ALTER on XXYH_AR_CREDIT from xxyh_appsro ;                               
revoke REFERENCES on XXYH_RUBY_INT from xxyh_appsro ;                           
revoke UPDATE on XXYH_RUBY_INT from xxyh_appsro ;                               
revoke INSERT on XXYH_RUBY_INT from xxyh_appsro ;                               
revoke INDEX on XXYH_RUBY_INT from xxyh_appsro ;                                
revoke DELETE on XXYH_RUBY_INT from xxyh_appsro ;                               
revoke ALTER on XXYH_RUBY_INT from xxyh_appsro ;                                
revoke EXECUTE on XXYH_DISCO_PARAMS from xxyh_appsro ;                          
revoke FLASHBACK on XXYH_COLLECTORS from xxyh_appsro ;                          
revoke DEBUG on XXYH_COLLECTORS from xxyh_appsro ;                              
revoke QUERY REWRITE on XXYH_COLLECTORS from xxyh_appsro ;                      
revoke ON COMMIT REFRESH on XXYH_COLLECTORS from xxyh_appsro ;                  
revoke REFERENCES on XXYH_COLLECTORS from xxyh_appsro ;                         

revoke UPDATE on XXYH_COLLECTORS from xxyh_appsro ;                             
revoke INSERT on XXYH_COLLECTORS from xxyh_appsro ;                             
revoke ALTER on XXYH_COLLECTORS from xxyh_appsro ;                              
revoke INDEX on XXYH_COLLECTORS from xxyh_appsro ;                              
revoke DELETE on XXYH_COLLECTORS from xxyh_appsro ;                             
revoke FLASHBACK on XXYH_CHECKS from xxyh_appsro ;                              
revoke DEBUG on XXYH_CHECKS from xxyh_appsro ;                                  
revoke QUERY REWRITE on XXYH_CHECKS from xxyh_appsro ;                          
revoke ON COMMIT REFRESH on XXYH_CHECKS from xxyh_appsro ;                      
revoke REFERENCES on XXYH_CHECKS from xxyh_appsro ;                             
revoke UPDATE on XXYH_CHECKS from xxyh_appsro ;                                 
revoke INSERT on XXYH_CHECKS from xxyh_appsro ;                                 
revoke INDEX on XXYH_CHECKS from xxyh_appsro ;                                  

revoke DELETE on XXYH_CHECKS from xxyh_appsro ;                                 
revoke ALTER on XXYH_CHECKS from xxyh_appsro ;                                  
revoke FLASHBACK on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;                  
revoke DEBUG on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;                      
revoke QUERY REWRITE on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;              
revoke ON COMMIT REFRESH on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;          
revoke REFERENCES on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;                 
revoke UPDATE on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;                     
revoke INSERT on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;                     
revoke INDEX on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;                      
revoke DELETE on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;                     
revoke ALTER on XXYH_INTERFACE_TEMP_INV from xxyh_appsro ;                      
revoke FLASHBACK on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;                   

revoke DEBUG on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;                       
revoke QUERY REWRITE on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;               
revoke ON COMMIT REFRESH on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;           
revoke REFERENCES on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;                  
revoke UPDATE on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;                      
revoke INSERT on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;                      
revoke INDEX on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;                       
revoke DELETE on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;                      
revoke ALTER on XXYH_CUSTOMER_BALANCES from xxyh_appsro ;                       
revoke FLASHBACK on XXYH_CUSTOMER_BAL from xxyh_appsro ;                        
revoke DEBUG on XXYH_CUSTOMER_BAL from xxyh_appsro ;                            
revoke QUERY REWRITE on XXYH_CUSTOMER_BAL from xxyh_appsro ;                    
revoke ON COMMIT REFRESH on XXYH_CUSTOMER_BAL from xxyh_appsro ;                

revoke REFERENCES on XXYH_CUSTOMER_BAL from xxyh_appsro ;                       
revoke UPDATE on XXYH_CUSTOMER_BAL from xxyh_appsro ;                           
revoke INSERT on XXYH_CUSTOMER_BAL from xxyh_appsro ;                           
revoke INDEX on XXYH_CUSTOMER_BAL from xxyh_appsro ;                            
revoke DELETE on XXYH_CUSTOMER_BAL from xxyh_appsro ;                           
revoke ALTER on XXYH_CUSTOMER_BAL from xxyh_appsro ;                            

123 rows selected.

SQL> exit
