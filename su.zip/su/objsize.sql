SELECT owner,segment_type, tablespace_name,BYTES/1024/1024 FROM DBA_SEGMENTS WHERE segment_name='&segment_name'
/
