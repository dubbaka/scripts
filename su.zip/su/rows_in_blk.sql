PROMPT select dbms_rowid.rowid_relative_fno(rowid) "relative fno" ,
PROMPT dbms_rowid.rowid_block_number(rowid) "block" ,
PROMPT from &table_name where dbms_rowid.rowid_block_number(rowid)=&block_number; 
