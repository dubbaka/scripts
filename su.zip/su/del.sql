execute dbms_apply_adm.delete_all_errors();
