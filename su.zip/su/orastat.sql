
set pagesize 1000
set feedback off
set verify off

PROMPT *****************************************************
PROMPT          Database Statistics
PROMPT *****************************************************

PROMPT
PROMPT *****************************************************
PROMPT File Statistics
PROMPT*****************************************************
col substr(name,1,45) format a45 heading file_name
SELECT substr(name,1,45),phyrds,phywrts 
FROM v$filestat a , v$dbfile b
WHERE a.file# = b.file#
AND a.phyrds > 100 AND phywrts > 100
order by substr(name,1,10), phyrds+phywrts desc ;

PROMPT
PROMPT *****************************************************
PROMPT File Statistics - By File System
PROMPT*****************************************************
col substr(name,1,10) format a10 heading file_name
SELECT substr(name,1,10),sum(phyrds) tot_reads,sum(phywrts) tot_writes
FROM v$filestat a , v$dbfile b
WHERE a.file# = b.file#
AND a.phyrds > 100 AND phywrts > 100
group by substr(name,1,10) ;

PROMPT
PROMPT*****************************************************
PROMPT Tuning Shared_pool_size 
PROMPT*****************************************************
col ratio format 9.999 heading 'Ratio should be close to 0'
SELECT sum(gethits),sum(pins),sum(reloads),((sum(reloads)/sum(pins))* 100 ) ratio
FROM v$librarycache 
WHERE gethits > 0;

PROMPT
PROMPT*****************************************************
PROMPT Tuning Shared_pool_size  
PROMPT*****************************************************
col ratio format 999.999 heading 'Ratio less that 15%'
SELECT sum(gets),sum(getmisses),((sum(getmisses)/sum(gets))* 100 ) ratio
FROM v$rowcache; 


PROMPT
PROMPT*****************************************************
PROMPT Tuning DB_BUFFER Ratio should be close to 100% 
PROMPT*****************************************************

select * from hp_dba_hit_ratio; 

PROMPT
PROMPT********************************************************
PROMPT Tuning Dynamic space allocation. Increase allocation
PROMPT if recursive calls are high 
PROMPT*********************************************************
SELECT name, value FROM v$sysstat
WHERE name = 'recursive calls'; 

PROMPT
PROMPT********************************************************
PROMPT Tuning LOG_BUFFER if value is high 
PROMPT*********************************************************
SELECT name, value FROM v$sysstat
WHERE name = 'redo log space requests'; 


PROMPT
PROMPT********************************************************
PROMPT Tuning SORT_AREA if value is high 
PROMPT*********************************************************
SELECT name, value FROM v$sysstat
WHERE name like '%sort%'; 

PROMPT
PROMPT********************************************************
PROMPT Check Rollback contention. HITS should be more than 95%
PROMPT*********************************************************
PROMPT

SELECT name,gets,waits,round(((gets-waits)*100)/gets) hits
FROM v$rollstat s, v$rollname n
WHERE s.usn = n.usn;

PROMPT**********************************************************************
PROMPT Check  Latch waits. Hit should be close to 100%
PROMPT**********************************************************************
col name format a25
select name,gets,misses,round(((gets-misses)*100)/gets) hits from v$latch
where gets > 0
order by 1;

PROMPT**********************************************************************
PROMPT Check db_object_cache . If loads are high increase SHARED_POOL_SIZE 
PROMPT**********************************************************************
col name format a25
col namespace format a18 heading type
col sharable_mem format 9999999 heading memory
SELECT name,namespace,sharable_mem,loads,executions 
FROM v$db_object_cache
WHERE loads > 20;

--exit;

