select b.sid, b.event, substr(a.action,1,1)||'-'||a.module module , a.username ,
      b.p1, b.p2,b.p3 ,b.seconds_in_wait, p1raw from v$session_wait b, v$session  a, dba_blockers c
where event not in ('SQL*Net message from client','rdbms ipc message',
'pmon timer','smon timer', 'pipe get')
  and a.sid  = b.sid
  and c.holding_session = a.sid
order by b.seconds_in_wait
/
