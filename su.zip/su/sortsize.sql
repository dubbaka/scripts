col used format 999,999,999,999
col free format 999,999,999,999
col maxused format 999,999,999,999
col totalsize format 999,999,999,999

SELECT tablespace_name, (TOTAL_BLOCKS * 8192) "totalsize", 
(USED_BLOCKS * 8192 ) "used" , (FREE_BLOCKS * 8192) "free" , 
(MAX_USED_BLOCKS * 8192 ) "maxused"
FROM gv$sort_segment;

