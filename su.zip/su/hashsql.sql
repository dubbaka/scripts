break on hash_value
set pagesize 1000
set long 200000
select hash_value, sql_text
from v$sqltext_with_newlines
where hash_value  = '&hash'
order by piece
/
