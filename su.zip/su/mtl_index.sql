SQL> /
alter index INV.MTL_MATERIAL_TRANS_TEMP_N1 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_N2 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_N4 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_N5 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_N6 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_N8 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_U1 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_N3 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_N10 rebuild ;                           
alter index INV.MTL_MATERIAL_TRANS_TEMP_N11 rebuild ;                           
alter index INV.MTL_MATERIAL_TRANS_TEMP_N12 rebuild ;                           
alter index INV.MTL_MATERIAL_TRANS_TEMP_N13 rebuild ;                           
alter index INV.MTL_MATERIAL_TRANS_TEMP_N14 rebuild ;                           
alter index INV.MTL_MATERIAL_TRANS_TEMP_N9 rebuild ;                            
alter index INV.MTL_MATERIAL_TRANS_TEMP_N15 rebuild ;                           
alter index INV.MTL_MATERIAL_TRANS_TEMP_N16 rebuild ;                           
alter index XXATORCL.XXAT_PRICE_QUERY_LINE_DTLS_U1 rebuild ;                    
alter index XXATORCL.XXAT_PRICE_QUERY_LINE_DTLS_N1 rebuild ;                    
alter index XXATORCL.MTL_MATERIAL_TXN_TEMP_XXN1 rebuild ;                       

19 rows selected.

SQL> 
SQL> spool off
