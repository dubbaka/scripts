  SET heading OFF

  COLUMN "Profile" FORMAT A35 
  COLUMN "Value" FORMAT A30 
  COLUMN "Levl" FORMAT A4 
  COLUMN "Location" FORMAT A10

  BREAK ON "Profile" ON "Value" ON "Levl"

  ACCEPT v_profile PROMPT "Enter a PROFILE substring value to search (default 'ALL PROFILES') : " 
  ACCEPT v_username PROMPT "Enter a USER / LOCATION or substring to search (default 'ALL USERS') : "

  SELECT 'Querying ' || name || TO_CHAR( sysdate, '" on" dd-Mon-yyyy "for"') 
  || 'Profile like ''%' || UPPER( '&&v_profile') 
  || '%'' and User / Location like ''%' || UPPER( '&&v_username') 
  || '%''' 
  --Showing the query parameters 
  FROM v$database, 
  dual 
  /

  SET heading ON 
  --Now set the column headers on that we have specified above 
  SELECT b.user_profile_option_name "Profile" 
  , DECODE( a.profile_option_value 
  , '1', '1 (may be "Yes")' 
  , '2', '2 (may be "No")' 
  , a.profile_option_value) "Value" 
  , DECODE( a.level_id 
  , 10001, 'Site' 
  , 10002, 'Appl' 
  , 10003, 'Resp' 
  , 10004, 'User' 
  , '????') "Levl" 
  , DECODE( a.level_id 
  , 10002, e.application_name 
  , 10003, c.responsibility_name 
  , 10004, d.user_name 
  , '-') "Location" 
  FROM applsys.fnd_application e 
  , applsys.fnd_user d 
  , applsys.fnd_responsibility c 
  , applsys.fnd_profile_option_values a 
  , applsys.fnd_profile_options b 
  WHERE UPPER( b.user_profile_option_name) LIKE UPPER( '%&&v_profile%') 
  AND b.application_id = a.application_id (+) 
  AND b.profile_option_id = a.profile_option_id (+) 
  AND a.level_value = c.responsibility_id (+) 
  AND a.level_value = d.user_id (+) 
  AND a.level_value = e.application_id (+) 
  AND( UPPER( e.application_name) LIKE UPPER( '%&&v_username%') 
  OR UPPER( c.responsibility_name) LIKE UPPER( '%&&v_username%') 
  OR UPPER( d.user_name) LIKE UPPER( '%&&v_username%')) 
  ORDER BY "Profile", "Levl", "Location", "Value" 
  /

CLEAR COLUMN 
 
