Rem #---------------------------------------------------------------------------
Rem # Name:             dbfsmon.sql {spool file}
Rem # Purpose:          Tablespace freespace monitor
Rem # Usage:            sqlplus @dbfsmon.sql {spool file}
Rem # Modification:     1.0:24-Dec-2000:srinivas:creation
Rem # Version:          1.0:24-Dec-2000:srinivas
Rem #---------------------------------------------------------------------------
set feedback off
set linesize 200
set pagesize 500
spool &1
select TABLESPACE_NAME,
        max_size "total_extendable_space(MB)",
         current_size  "current_file_size(MB)",
        pct_bytes_free ,
        free_bytes "free_bytes(MB)" ,
        round(100*free_bytes/current_size,2) AS  pct_free,
        AUTOEXTENSIBLE
from (select TABLESPACE_NAME,
        round(sum(maxbytes)/1000000,1) max_size,
        round(sum(bytes)/1000000,1) AS current_size ,
        round(100*((sum(maxbytes)-sum(bytes))/sum(maxbytes)),1) pct_bytes_free,
        AUTOEXTENSIBLE
        from dba_data_files
       group by TABLESPACE_NAME,AUTOEXTENSIBLE),
      (select Tablespace_Name FS_TS_NAME,
        round(sum(bytes)/1000000,1) AS free_bytes
        from DBA_FREE_SPACE
        group by Tablespace_Name)
where TABLESPACE_NAME=FS_TS_NAME
order by pct_free
/


