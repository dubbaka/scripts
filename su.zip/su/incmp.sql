col R_Prog format a25
col user_concurrent_program_name format a40

select fcr.request_id
, fcp.user_concurrent_program_name
, fcr.phase_code phase
, fcr.status_code status
from fnd_concurrent_requests fcr
, fnd_concurrent_programs_tl fcp
where fcp.language = 'US'
and fcr.phase_code = 'R' 
and fcr.concurrent_program_id = fcp.concurrent_program_id
and fcr.concurrent_program_id in
(
select 
 fcps.to_run_concurrent_program_id
from fnd_concurrent_program_serial fcps
, fnd_concurrent_requests fcr
where fcps.running_concurrent_program_id = fcr.concurrent_program_id
and fcr.request_id = &req_id
)
/
