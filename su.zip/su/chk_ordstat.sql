col name format a30
select to_char(sysdate,'DD-MON-YYYY HH24:MI:SS') from dual
/
select count(*) , org_id,name  from oe_lines_iface_all a , hr_organization_units b 
where a.org_id=b.organization_id and error_flag is null group by  org_id, name 
union select count(*),1, 'Total' from oe_lines_iface_all
where error_flag is null
/
select count(*) , org_id,name  from oe_headers_iface_all a , hr_organization_units b 
where a.org_id=b.organization_id and error_flag is null group by  org_id,name 
union select count(*),1, 'Total' from oe_headers_iface_all
where error_flag is null
/
select to_char(sysdate,'DD-MON-YYYY HH24:MI:SS') from dual
/
