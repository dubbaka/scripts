set lines 200
col USER_CONCURRENT_PROGRAM_NAME for a90
SELECT USER_CONCURRENT_PROGRAM_NAME,request_id,round((sysdate-requested_start_date)*24*60,2) "WaitingforMts" FROM apps.fnd_concurrent_programs_vl a ,apps.fnd_concurrent_requests b  where a.concurrent_program_id=b.concurrent_program_id and phase_code='P' and status_code='I'
and requested_start_date < sysdate
/
