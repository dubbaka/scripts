SELECT /*+ PARALLEL 8 */SITE_USES.location JO_ID,
    CUST_ACCT.ACCOUNT_NUMBER ,
  acct_site.orig_system_reference,
  PARTY_SITE.PARTY_SITE_NUMBER,
  PARTY_SITE.orig_system_reference site_orig_system_reference,
  NVL (SUM (ps.amount_due_remaining), 0) invoice_balance
FROM apps.ra_cust_trx_types_all rtt,
  apps.ra_customer_trx_all rta,
  apps.ra_cust_trx_line_gl_dist_all rgld,
  apps.gl_code_combinations cc,
  apps.HZ_CUST_ACCOUNTS_ALL CUST_ACCT,
  apps.HZ_CUSTOMER_PROFILES HCP ,
  apps.HZ_CUST_PROFILE_CLASSES hpc,
  apps.ar_payment_schedules_all ps,
  apps.hz_cust_acct_sites_all acct_site,
  apps.hz_party_sites party_site,
  apps.hz_locations loc,
  apps.HZ_CUST_SITE_USES_ALL SITE_USES
WHERE 1=1 --TRUNC (ps.gl_date)       <= :p_as_of_date
--AND CUST_ACCT.ACCOUNT_NUMBER    ='1-1SATDWE'-- '1-1UEYR20'--:P_ACCOUNT_NUMBER
AND CUST_ACCT.cust_account_id =hcp.cust_account_id
AND HCP.PROFILE_CLASS_ID      =HPC.PROFILE_CLASS_ID
AND hpc.name                  ='PREPAYS'
AND ps.customer_id            = cust_acct.cust_account_id
AND PS.CUST_TRX_TYPE_ID       = RTT.CUST_TRX_TYPE_ID
  --AND ps.trx_date                <= :p_as_of_date
AND ps.CLASS NOT               IN ('CM', 'PMT')
AND site_uses.site_use_code     = 'BILL_TO'
AND acct_site.party_site_id     = party_site.party_site_id
AND loc.location_id             = party_site.location_id
AND NVL (site_uses.status, 'A') = 'A'
AND CUST_ACCT.CUST_ACCOUNT_ID   = ACCT_SITE.CUST_ACCOUNT_ID
AND acct_site.cust_acct_site_id = site_uses.cust_acct_site_id
AND ps.customer_id              = acct_site.cust_account_id
AND ps.customer_site_use_id     = site_uses.site_use_id
AND rta.customer_trx_id         = ps.customer_trx_id
AND rta.customer_trx_id         = rgld.customer_trx_id
AND RGLD.CODE_COMBINATION_ID    = CC.CODE_COMBINATION_ID
AND RGLD.ACCOUNT_CLASS          = 'REV'
GROUP BY CUST_ACCT.ACCOUNT_NUMBER,
  acct_site.orig_system_reference,
  PARTY_SITE.PARTY_SITE_NUMBER,
  PARTY_SITE.ORIG_SYSTEM_REFERENCE,
  SITE_USES.location ;

