set echo on
set serveroutput ON
alter PROCEDURE OBT_AA.GOTO_BILL_FULL_LOAD_NEW  compile;                                                                                              
alter PROCEDURE OBT_AA.GOTO_BILL_INC_LOAD_NEW  compile;                                                                                               
alter PROCEDURE OBT_AA.GOTO_PARALLEL_RECONCILED_BAL  compile;                                                                                         
alter PROCEDURE OBT_AA.XXYH_PARALLEL_RECONCILED_BAL  compile;                                                                                         
alter PROCEDURE OBT_AA.GOTO_BILL_MON_LOAD_NEW  compile;                                                                                               
alter PROCEDURE OBT_AA.XXYH_LOAD_EDGE  compile;                                                                                                       
alter PROCEDURE OBT_AA.XCEL_JOB_VALID_GRADES_INSERT  compile;                                                                                         
alter PROCEDURE OBT_AA.GOTO_ARDAILY_NEW  compile;                                                                                                     
alter PROCEDURE OBT_AA.GOTO_ARDAILY_YSM  compile;                                                                                                     
alter PROCEDURE OBT_AA.GOTO_ADV_STAT_TO_BO  compile;                                                                                                  
alter VIEW OBT_AA.GOTO_CRM_PMT_SCHED_V  compile;                                                                                                      
alter VIEW OBT_AA.XXYH_CRM_PMT_SCHED_V  compile;                                                                                                      
alter PROCEDURE OBT_AA.GOTO_RECONCILED_BALANCE_NEW  compile;                                                                                          
alter PROCEDURE OBT_AA.XXYH_LIGHT_RECONCILED_BAL  compile;                                                                                            
alter PROCEDURE OBT_AA.GOTO_LOAD_SALESCAP_MONTHLY  compile;                                                                                           
alter VIEW OBT_AA.ECE_POO_HEADERS_V  compile;                                                                                                         
alter VIEW OBT_AA.ECE_POCO_HEADERS_V  compile;                                                                                                        
alter VIEW OBT_AA.GMS_COMMITMENTS_OVERRIDE_V  compile;                                                                                                
alter PROCEDURE OBT_AA.XCEL_ADDRESS_INS  compile;                                                                                                     
alter PROCEDURE OBT_AA.XCEL_CONTACT_INSERT  compile;                                                                                                  
alter PROCEDURE OBT_AA.XCEL_GRADE_INSERT  compile;                                                                                                    
alter PROCEDURE OBT_AA.XCEL_JOB_INSERT  compile;                                                                                                      
alter PROCEDURE OBT_AA.XXYH_JOB_END_DATE  compile;                                                                                                    
alter package OBT_AA.XXYH_AR_ISSUES_FIX  compile BODY;                                                                                                
alter package OBT_AA.XXYH_CUSTOMER_CALLS_PKG  compile BODY;                                                                                           
alter package OBT_AA.XXYH_SS_ME_P2  compile BODY;                                                                                                     
alter package OBT_AA.XXYH_PAM_ACCT_DAILY_STATS  compile BODY;                                                                                         
alter package OBT_AA.HJ_AR_ADJ_CONV  compile BODY;                                                                                                    
alter package OBT_AA.XXYH_PAM_INT_PKG1  compile BODY;                                                                                                 
alter package OBT_AA.XXYH_PAM_TAG_MAP_PKG  compile BODY;                                                                                              
alter package OBT_AA.XXYH_RM_MAIN_CUSTOMER  compile BODY;                                                                                             
alter package OBT_AA.XXYH_REVREC_PKG  compile BODY;                                                                                                   
alter package OBT_AA.XXYH_CUSTOMER_MERGE  compile BODY;                                                                                               
alter package OBT_AA.XXYH_PAM_ADJ_LOAD_PKG  compile BODY;                                                                                             
select count(*)
from dba_objects
where status = 'INVALID'
and owner = 'OBT_AA'
/
