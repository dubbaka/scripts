set time on
set timing on
set echo on
spool prod_n1_s2.log
ALTER TABLE "AR"."AR_DISTRIBUTIONS_ALL" MOVE TABLESPACE APPS_TS_TX_DATA STORAGE (INITIAL 10485760 NEXT 10485760)    PARALLEL 16 NOLOGGING;                                                                 
ALTER TABLE "AR"."AR_DISTRIBUTIONS_ALL" LOGGING;                                                                                                                                                        
ALTER INDEX "AR"."AR_DISTRIBUTIONS_N1" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                                  
ALTER INDEX "AR"."AR_DISTRIBUTIONS_N1"  NOPARALLEL LOGGING;                                                                                                                                             
ALTER INDEX "AR"."AR_DISTRIBUTIONS_N2" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                                  
ALTER INDEX "AR"."AR_DISTRIBUTIONS_N2"  NOPARALLEL LOGGING;                                                                                                                                             
ALTER INDEX "AR"."AR_DISTRIBUTIONS_U2" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                                  
ALTER INDEX "AR"."AR_DISTRIBUTIONS_U2"  NOPARALLEL LOGGING;                                                                                                                                             
ALTER TABLE "AR"."AR_PAYMENT_SCHEDULES_ALL" MOVE TABLESPACE APPS_TS_TX_DATA STORAGE (INITIAL 10485760 NEXT 10485760)    PARALLEL 16 NOLOGGING;                                                             
ALTER TABLE "AR"."AR_PAYMENT_SCHEDULES_ALL" LOGGING;                                                                                                                                                    
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N17" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                             
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N17"  NOPARALLEL;                                                                                                                                                
ALTER INDEX "AR"."GOTO_AR_PAYMENT_SCHEDULES_N1" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                         
ALTER INDEX "AR"."GOTO_AR_PAYMENT_SCHEDULES_N1"  NOPARALLEL LOGGING;                                                                                                                                    
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N1" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N1"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N10" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                             
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N10"  NOPARALLEL LOGGING;                                                                                                                                        
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N11" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                             
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N11"  NOPARALLEL LOGGING;                                                                                                                                        
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N12" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                             
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N12"  NOPARALLEL LOGGING;                                                                                                                                        
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N13" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                             
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N13"  NOPARALLEL LOGGING;                                                                                                                                        
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N2" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N2"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N3" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N3"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N4" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N4"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N5" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N5"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N6" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N6"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N7" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N7"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_U1" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_U1"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_U2" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_U2"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_U3" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_U3"  NOPARALLEL LOGGING;                                                                                                                                         
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N14" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                             
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N14"  NOPARALLEL LOGGING;                                                                                                                                        
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N15" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                             
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N15"  NOPARALLEL LOGGING;                                                                                                                                        
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N16" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                             
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N16"  NOPARALLEL LOGGING;                                                                                                                                        
ALTER INDEX "APPS"."XXYH_AR_PAYMENT_SCHEDULES_N17" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                      
ALTER INDEX "APPS"."XXYH_AR_PAYMENT_SCHEDULES_N17"  NOPARALLEL LOGGING;                                                                                                                                 
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N9" REBUILD TABLESPACE APPS_TS_TX_IDX STORAGE (INITIAL 10485760 NEXT 10485760)  PARALLEL 16 NOLOGGING;                                                              
ALTER INDEX "AR"."AR_PAYMENT_SCHEDULES_N9"  NOPARALLEL LOGGING;                                                                                                                                         
spool off
