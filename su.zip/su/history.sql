set pages 66
set lines 132
set feedback on
set pagesize 1000
select request_id request,decode(status_code,'I','incomplete','R','Running','C','Complete','Q','Standby','G','Warning','E','Error','X','Terminated','Others') Status,
to_char(actual_start_date,'DD-MON-YYYY HH24:MI:SS') start_time,to_char(actual_completion_date,'DD-MON-YYYY HH24:MI:SS') complete_time,
trunc  ( ( (actual_completion_date - actual_start_date) *24 *60 *60 ) / 60 ) "time_taken(mins)" 
from fnd_concurrent_requests where concurrent_program_id  in (select CONCURRENT_PROGRAM_ID from fnd_concurrent_requests where
request_id='&concurrent_request_id')
order by 5 desc;
