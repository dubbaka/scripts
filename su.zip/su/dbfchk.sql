REM ======================================================================
REM Copyright Agilent Technologies
REM =====================================================================
REM Script to check incorrect file name in the database
REM It checks if the file name is duplicate, if the file name contains 
REM non standard characters e.g. '/var/opt/oracle//OPR1/abx_OPR1.dbf', 
REM if the file doesn't have dbf extension and lot more
REM
REM Usage
REM   sqlplus>@chkdbf.sql
REM Note
REM   The user must have access to dba_data_file, v$logfile and dba_temp_files 
REM   Better execute this script using system account
REM
REM History
REM   04-April-2003   Created by Abhay Shastri
REM
REM =======================================================================

set lines 132;
set feed on;
col file_name for a60;
set pages 20;
spool dbfilechk.log;

PROMPT =================================================================
PROMPT Checking for files having invalid character, or wrong extension
PROMPT =================================================================  
select file_name from dba_data_files 
 where (substr(file_name, -3) <> 'dbf'
    or instr(file_name, '//') > 0
    or instr(file_name, ' ') > 0
    or instr(file_name, '\\') > 0 
    or instr(file_name, '\%') > 0
    or instr(file_name, '\*') > 0
    or instr(file_name, '~') > 0
    or instr(file_name, '!') > 0
    or instr(file_name, '@') > 0
    or instr(file_name, '#') > 0
    or instr(file_name, '$') > 0
    or instr(file_name, '^') > 0
    or instr(file_name, '&') > 0
    or instr(file_name, '(') > 0
    or instr(file_name, ')') > 0
    or instr(file_name, '-') > 0
    or instr(file_name, '__') > 0
    or instr(file_name, '+') > 0
    or instr(file_name, '.') <= 0
    or instr(file_name, '=') > 0  
    or file_name like '%.%.%')
union all
select file_name from dba_temp_files 
 where (substr(file_name, -3) <> 'dbf' 
     or instr(file_name, '//') > 0
    or instr(file_name, ' ') > 0
    or instr(file_name, '\\') > 0 
    or instr(file_name, '\%') > 0
    or instr(file_name, '\*') > 0
    or instr(file_name, '~') > 0
    or instr(file_name, '!') > 0
    or instr(file_name, '@') > 0
    or instr(file_name, '#') > 0
    or instr(file_name, '$') > 0
    or instr(file_name, '^') > 0
    or instr(file_name, '&') > 0
    or instr(file_name, '(') > 0
    or instr(file_name, ')') > 0
    or instr(file_name, '-') > 0
    or instr(file_name, '__') > 0
    or instr(file_name, '+') > 0
    or instr(file_name, '.') <= 0
    or instr(file_name, '=') > 0 
    or file_name like '%.%.%')
union all
select member as file_name from v$logfile
 where (substr(member, -3) <> 'dbf'
     or instr(member, '//') > 0
    or instr(member, ' ') > 0
    or instr(member, '\\') > 0 
    or instr(member, '\%') > 0
    or instr(member, '\*') > 0
    or instr(member, '~') > 0
    or instr(member, '!') > 0
    or instr(member, '@') > 0
    or instr(member, '#') > 0
    or instr(member, '$') > 0
    or instr(member, '^') > 0
    or instr(member, '&') > 0
    or instr(member, '(') > 0
    or instr(member, ')') > 0
    or instr(member, '-') > 0
    or instr(member, '__') > 0
    or instr(member, '+') > 0
    or instr(member, '.') <= 0
    or instr(member, '=') > 0 
    or member like '%.%.%')
;

PROMPT ---- End ----

PROMPT =================================================================
PROMPT Checking for duplicate file names
PROMPT =================================================================

select file_name, count(*) from 
   (select upper(substr(file_name,instr(file_name, '/',-1)+1)) as file_name from dba_data_files
     union all
    select upper(substr(file_name,instr(file_name, '/',-1)+1)) as file_name from dba_temp_files
    union all
    select upper(substr(member,instr(member, '/',-1)+1)) as file_name from v$logfile
    ) all_files
    group by file_name having count(*) > 1 ;

PROMPT ---- End ----

spool off;
