select count(*),blocking_session
from gv$session
group by blocking_session
