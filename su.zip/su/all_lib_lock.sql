select sid,p1raw from v$session_wait 
where event like 'library cache pin%'
/
select sid Holder ,KGLNAOBJ obj,KGLPNUSE Sesion , KGLPNMOD Held, KGLPNREQ Req 
from x$kglpn a , v$session ,x$kglob c
where KGLPNHDL in (select p1raw from v$session_wait 
where wait_time=0 and event like 'library cache pin%') 
and KGLPNMOD <> 0 
and v$session.saddr=a.kglpnuse 
and c.KGLHDADR=a.KGLPNHDL
/ 
select sid,substr(event,1,30),wait_time 
from v$session_wait 
where sid in (select sid from x$kglpn , v$session 
where KGLPNHDL in (select p1raw from v$session_wait 
where wait_time=0 and event like 'library cache pin%') 
and KGLPNMOD <> 0 
and v$session.saddr=x$kglpn.kglpnuse ) 
/ 

