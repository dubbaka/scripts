set echo on
set time on
set timing on
ALTER INDEX APPS.GOTO_BILL_I1 REBUILD tablespace xxyhx parallel 8 nologging;
ALTER INDEX APPS.GOTO_RA_MONTHLY_BAL_YHOFA_N1 REBUILD tablespace xxyhx parallel 8 nologging;
ALTER INDEX APPS.IDX2 REBUILD tablespace xxyhx parallel 8 nologging;
ALTER INDEX APPS.XXYH_FX_NRML_CONC_REQUESTS_N2 REBUILD tablespace xxyhx parallel 8 nologging;
ALTER INDEX APPS.XXYH_GVA_UNBILLED_AMT_N1 REBUILD tablespace xxyhx parallel 8 nologging;
ALTER INDEX APPS.XXYH_ICAN_CRCTS_INT_LOAN_N1 REBUILD tablespace xxyhx parallel 8 nologging;
ALTER INDEX APPS.XXYH_ICAN_CRCTS_INT_LOAN_U1 REBUILD tablespace xxyhx parallel 8 nologging;
ALTER INDEX APPS.XXYH_ICAN_NETTING_SUMMARY_U1 REBUILD tablespace xxyhx parallel 8 nologging;
ALTER INDEX APPS.XXYH_PAM_APPROVAL_HIST_IND1 REBUILD tablespace XXYH_PAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_PAM_GL_ACCT_MAP_N1 REBUILD tablespace XXYH_PAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_PAM_GL_ACCT_MAP_U1 REBUILD tablespace XXYH_PAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_PAM_HISDT_DTL1 REBUILD tablespace XXYH_PAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_PAM_HIST_HDR1 REBUILD tablespace XXYH_PAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_PAM_HIST_HDR2 REBUILD tablespace XXYH_PAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_SAM_CUST_PERIOD_N1 REBUILD tablespace XXYH_SAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_SAM_INVCLIENT_SS_N1 REBUILD tablespace XXYH_SAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_SAM_PERIOD_N2 REBUILD tablespace XXYH_SAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_SAM_SS_LOG_LINUX_N1 REBUILD tablespace XXYH_SAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_SAM_SS_LOG_LINUX_N2 REBUILD tablespace XXYH_SAMX parallel 8 nologging;
ALTER INDEX APPS.XXYH_SAM_SS_LOG_LINUX_N3 REBUILD tablespace XXYH_SAMX parallel 8 nologging;
