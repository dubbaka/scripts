set pages 66
set line 132
spool progs1.lst
column  ProgName        format a40 word_wrapped
column  user_name         format a20 word_wrapped
column  requestId       format 99999999
column  oracle_process_id       format a8
column  os_process_id   format a8
column  StartDate       format a15 word_Wrapped
select
                fcp.user_concurrent_program_name                progName,
                substr(fusr.description,1,19) user_name ,
                to_char(actual_Start_date,'DD-MON HH24:MI:SS') StartDate,
                request_id                                                                                      RequestId,
                fcr.oracle_process_id,
                nvl(fcr.os_process_id,fcpp.os_process_id) os_process_id ,
                sess.sid,
                (sysdate - actual_start_date)*24*60*60 ElapseTime
 from   fnd_concurrent_requests fcr,
                fnd_concurrent_programs_tl  fcp,
        fnd_user fusr,
                v$session sess,
        fnd_concurrent_processes fcpp
where fcp.concurrent_program_id = fcr.concurrent_program_id
  and fcr.program_application_id        = fcp.application_id
  and fcp.language              = 'US'
  and fcr.requested_by = fusr.user_id
  and sess.process(+)=fcr.os_process_id
  and fcr.controlling_manager=fcpp.concurrent_process_id
and Request_Id = &1
 order by 3 DESC
/

