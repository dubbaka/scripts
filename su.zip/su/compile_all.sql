set pagesize 200
spool compile_all1.sql
select 'alter '||decode(object_type,'PACKAGE BODY','PACKAGE',object_type)||' '||
object_name||' compile'||decode(object_type,'PACKAGE BODY',' body;',';')
from user_objects where status='INVALID';
spool off
