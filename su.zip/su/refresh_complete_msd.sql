SELECT MRP_AP_REFRESH_S.NEXTVAL FROM DUAL
/
truncate table MRP.MLOG$_MRP_SCHEDULE_DATES
/
exec dbms_snapshot.refresh('MRP.MRP_SCHD_DATES_SN','C')
/
