######!/bin/sh
###### Pass Snap Value
#####ssh nacorpfin01.fin.corp.sk1.yahoo.com snap restore erpprddata $1
#####ssh nacorpfin01.fin.corp.sk1.yahoo.com snap restore erpprdindex $1
#####ssh nacorpfin01.fin.corp.sk1.yahoo.com snap restore erponlinelog $1
#####ssh nacorpfin01.fin.corp.sk1.yahoo.com snap restore erpprdtemp $1
#####ssh nacorpfin01.fin.corp.sk1.yahoo.com snap restore erpprdlog $1
#####ssh nacorpfin01.fin.corp.sk1.yahoo.com snap restore erpprdapp $1
