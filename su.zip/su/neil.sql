CREATE OR REPLACE VIEW GOTO_CRM_PMT_SCHED_NEIL_V ( ACCOUNT, 
ADVID, TRX_DATE, RECEIPT_NUMBER, PAYMENT_METHOD, 
PAYMENT_METHOD_CODE, TRANSACTION_CLASS, CC_NUMBER, CC_EXP_DATE, 
AMT_BILLED, ORIG_AMT, AMT_REMAINING, COMMENTS, 
OPERATOR_NAME, APPROVAL_CODE, RESPONSE_CODE, BATCH_ID, 
OF_TRANS_NUMBER, OPERATOR, OF_ACCOUNT_ID, PAYMENT_SCHEDULE_ID, 
BILLING_NUMBER, ORGANIZATION, AMT_NET_ORIG, AMT_VAT_ORIG, 
AMT_GROSS_ORIG, AMT_GROSS_REMAINING, PAYMENT_METHOD_NLS, INICIS_TRANSACTION_ID
 ) AS SELECT 
 e.location account, 
 y.customer_number advid, 
 a.trx_date trx_date, 
 b.receipt_number receipt_number, 
 DECODE(a.class, 'PMT', DECODE(SUBSTR(b.attribute3, 
INSTR(b.attribute3,'-') +2),NULL, 
'OF Manual Pymt', 
SUBSTR(b.attribute3,INSTR(b.attribute3,'-') +2) 
),f.attribute2) 
payment_method, 
 DECODE (a.class, 'PMT', 
DECODE(SUBSTR(b.attribute3,1, 
INSTR(b.attribute3,'-')-1),NULL,'32', 
SUBSTR(b.attribute3,1,INSTR(b.attribute3,'-')-1) 
), f.attribute1)  payment_method_code, 
 a.class transaction_class, 
 DECODE(a.class,'PMT','************'|| 
SUBSTR(b.receipt_number , INSTR(b.receipt_number,'-','1')-5, 4), NULL ) CC_number, 
 b.attribute6 cc_exp_date, 
 b.attribute7  amt_billed, 
-Amount_due_original orig_amt, 
-Amount_due_remaining amt_remaining, 
 NVL(c.attribute10, b.attribute14) comments, 
 NVL(c.attribute14, b.attribute15) operator_name, 
 b.attribute8 approval_code, 
 b.attribute9 response_code, 
 NVL(c.attribute4, b.attribute4) batch_id, 
 DECODE(a.class, 'PMT',DECODE(SUBSTR(b.receipt_number,1,INSTR(b.receipt_number,'-')-1), 
NULL,b.receipt_number, SUBSTR(a.trx_number, INSTR(a.trx_number, '-')+1)), 
SUBSTR(a.trx_number, INSTR(a.trx_number, '-')+1)) of_trans_number, 
 NVL(c.attribute11, b.attribute4) operator, 
                   a.customer_site_use_id of_account_id, 
        a.payment_schedule_id payment_schedule_id, 
  NULL billing_number, 
x.org_name organization, 
-(a.amount_due_original - NVL(tax_original,0)) amt_net_orig, 
-a.tax_original amt_vat_orig, 
-a.amount_due_original amt_gross_orig, 
-a.amount_due_remaining amt_gross_remaining , 
DECODE(a.class, 'PMT', DECODE(SUBSTR(b.attribute3, 
        INSTR(b.attribute3,'-') +2), NULL, 
        DECODE(x.org_name,'DE','Scheck','OF Manual Pymt'), 
        SUBSTR(b.attribute3,INSTR(b.attribute3,'-') +2) ) 
       ,DECODE(f.attribute6,'Y', DECODE(x.org_name,'DE','Anpassung', 'FR','Riglages','Adjustment'),'N', f.attribute7 )  ) 
   payment_method_nls, 
 b.attribute13 
FROM 
apps.Ar_payment_schedules_all a, 
apps.Ar_cash_receipts_all b, 
apps.Ra_customer_trx_all c, 
apps.Ra_site_uses_morg e, 
apps.Ra_cust_trx_types_all f, 
apps.goto_set_of_books_currency x, 
apps.ra_customers y 
WHERE 
y.customer_id=a.customer_id AND 
e.org_id=x.org_id AND 
a.cash_receipt_id=b.cash_receipt_id (+) AND 
a.Customer_trx_id=c.customer_trx_id(+) AND 
e.Site_use_id=a.customer_site_use_id AND 
e.status='A' AND 
a.cust_trx_type_id=f.cust_trx_type_id (+) AND 
a.org_id = f.org_id(+) 
UNION 
SELECT 
account_id account, 
customer_number advid, 
month trx_date, 
NULL receipt_number, 
'MTD ClickCharge' payment_method, 
NULL payment_method_code, 
'ClickCharge' transaction_class, 
NULL cc_number, 
NULL cc_exp_date, 
NULL amt_billed, 
-cost orig_amt, 
-cost amt_remaining, 
NULL comments, 
NULL operator_name, 
NULL approval_code, 
NULL response_code, 
NULL batch_id, 
NULL of_trans_number, 
NULL operator, 
site_use_id of_account_id, 
TO_NUMBER(NULL) payment_schedule_id, 
NULL billing_number, 
a.organization, 
- (a.line_amount + NVL(a.mgmnt_fee,0)- NVL(a.agency_disc_amt,0) )  amt_net_orig, 
-a.tax_amount amt_vat_orig, 
-a.cost amt_gross_orig, 
-a.cost amt_gross_remaining  , 
 DECODE(X.ORG_NAME,'DE','Monut Bis Dato Klickgebuhren', 
              'FR', 'Charges pour le mois courant', 
             'MTD ClickCharge') payment_method_nls, 
NULL 
FROM goto_ra_monthly_balance_v a, 
apps.ra_customers b, 
apps.ra_addresses_morg c, 
apps.ra_site_uses_morg d ,
apps.goto_set_of_books_currency x
WHERE a.account_id=d.location 
AND c.address_id=d.address_id 
AND b.customer_id=c.customer_id 
AND d.org_id = x.org_id
AND b.status='A' 
AND d.status='A' 
UNION 
SELECT 
acctid account, 
advid advid, 
datefundingevent trx_date, 
NULL receipt_number, 
meaning payment_method, 
trx_type_name payment_method_code, 
'PendingAdj' transaction_class, 
NULL cc_number, 
NULL cc_exp_date, 
TO_CHAR(amtbilled) amt_billed, 
amtrecvd orig_amt, 
amtrecvd amt_remaining, 
comments comments, 
operator_name operator_name, 
NULL approval_code, 
NULL response_code, 
NULL batch_id, 
NULL of_trans_number, 
batchby operator, 
site_use_id of_account_id, 
TO_NUMBER(NULL) payment_schedule_id, 
NULL billing_number, 
a.organization, 
a.amount_net_recvd amt_net_orig, 
a.amount_vat_recvd amt_vat_orig, 
a.amount_gross_recvd amt_gross_orig, 
a.amount_gross_recvd amt_gross_remaining   , 
meaning payment_method_nls, 
NULL 
FROM goto_payadj_temp a, 
apps.ar_lookups b, 
apps.ra_site_uses_morg c 
WHERE trx_type_name=b.lookup_code 
AND b.lookup_type='GOTO_REC_PYMT_ID' 
AND a.int_load_status IS NULL 
AND c.location=a.acctid 
UNION 
SELECT 
mp_invoice account, 
advertiser_id advid, 
funding_event_date trx_date, 
identification_info receipt_number, 
meaning payment_method, 
payment_method_id payment_method_code, 
'PendingReceipt' transaction_class, 
identification_info cc_number, 
NULL cc_exp_date, 
TO_CHAR(amount_billed) amt_billed, 
amount_received orig_amt, 
amount_received amt_remaining, 
comments comments, 
operator_name operator_name, 
approval_code approval_code, 
response_message response_code, 
TO_CHAR(batch_id) batch_id, 
NULL of_trans_number, 
TO_CHAR(batch_id) operator, 
site_use_id of_account_id, 
TO_NUMBER(NULL) payment_schedule_id, 
NULL billing_number, 
a.organization, 
a.amount_net_recvd amt_net_orig, 
a.amount_vat_recvd amt_tax_orig, 
a.amount_gross_recvd amt_gross_orig, 
a.amount_gross_recvd amt_gross_remaining, 
meaning       payment_method_nls, 
reference_number 
FROM goto_payment_transaction a, 
apps.ar_lookups b, 
apps.ra_site_uses_morg c 
WHERE payment_method_id=b.lookup_code 
AND b.lookup_type='GOTO_REC_PYMT_ID' 
AND a.status ='N' 
AND c.location=a.mp_invoice


