undefine sid 

col "Session Info" form A80
set verify off
accept sid      prompt 'Please enter the value for Sid if known            : '
accept terminal prompt 'Please enter the value for terminal if known       : '
accept machine  prompt 'Please enter the machine name if known             : '
accept process  prompt 'Please enter the value for Client Process if known : '
accept spid     prompt 'Please enter the value for Server Process if known : '
accept osuser   prompt 'Please enter the value for OS User if known        : '
accept username prompt 'Please enter the value for DB User if known        : '
select ' Sid, Serial#, Aud sid : '|| s.sid||' , '||s.serial#||' , '||
       s.audsid||chr(10)|| '     DB User / OS User : '||s.username||
       '   /   '||s.osuser||chr(10)|| '    Machine - Terminal : '||
       s.machine||'  -  '|| s.terminal||chr(10)||
       '        OS Process Ids : '||
       s.process||' (Client)  '||p.spid||' (Server)'|| chr(10)||
       '   Client Program Name : '||s.program||chr(10) "Session Info",
	   '   Action / Module     : '||s.action||'  / '||s.module||chr(10) ||'User Name : '||
      fu.description
  from v$process p,v$session s, apps.fnd_logins f, apps.fnd_user fu
 where p.addr = s.paddr
   and s.sid = nvl('&SID',s.sid)
   and nvl(s.terminal,' ') = nvl('&Terminal',nvl(s.terminal,' '))
   and nvl(s.process,-1) = nvl('&Process',nvl(s.process,-1))
   and p.spid = nvl('&spid',p.spid)
   and s.username = nvl('&username',s.username)
   and nvl(s.osuser,' ') = nvl('&OSUser',nvl(s.osuser,' '))
   and nvl(s.machine,' ') = nvl('&machine',nvl(s.machine,' '))
   and nvl('&SID',nvl('&TERMINAL',nvl('&PROCESS',nvl('&SPID',nvl('&USERNAME',
       nvl('&OSUSER',nvl('&MACHINE','NO VALUES'))))))) <> 'NO VALUES'
   and f.spid (+)  = nvl('&Process',s.process)
   and fu.user_id (+) = f.user_id
   and f.end_time(+) is null
/
undefine sid
/
column name format a30 word_wrapped
column vlu format 999,999,999,999
select b.name, a.value vlu
from v$sesstat a, v$statname b
where a.statistic# = b.statistic#
and sid =&sid
and a.value != 0
and b.name like '%row%'
/
break on hash on exec on buffgets
--col sql_text format a60 word_wrapped
col exec format 9999
col buffgets format 9999999
set line 132
set pagesize 1000
set long 200000
select a.hash_value hash,
       a.sql_text,
       executions exec,
       buffer_gets buffgets
from v$sqltext a, v$sqlarea b
where a.hash_value in
	(select sql_hash_value from
	v$session where sid = &sid)
and a.hash_value = b.hash_value
order by piece
/
undefine sid 
