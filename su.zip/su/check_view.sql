declare
          cursor my_cursor is
  select owner,
          view_name name,
         'V' type,
          text
      from   all_views
      union all
   select owner,
          name,
           'S' type,
            query text
    from all_snapshots;

           v_text  varchar2(32767); 
           v_name  varchar2(4000);
           v_type  varchar2(5);
           v_owner varchar2(4000);

           begin 

             open my_cursor; 
             loop 

               fetch my_cursor into v_owner,v_name,v_type,v_text;
               exit when my_cursor%notfound; 

               v_text := substr(v_text,1,4000); 

               insert /*+ APPEND */  into temp_t (v_owner,v_name,v_type,v_text) values(v_owner,v_name,v_type,v_text);
           end loop; 
           close my_cursor; 
          end;

/


