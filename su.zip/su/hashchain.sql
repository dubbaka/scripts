break   on report
compute avg of chainlength on report
select  a.hladdr, count(distinct a.hladdr) chainlength
from    x$bh    a
having  count(*) >= 1
group by  a.hladdr;

