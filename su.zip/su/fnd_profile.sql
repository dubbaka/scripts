SELECT SUBSTR(e.profile_option_name,1,25) PROFILE,a.PROFILE_OPTION_VALUE 
--DECODE(a.level_id,10001,'Site',10002,'Application',10003,'Resp',10004,'User') L,DECODE(a.level_id,10001,'Site',10002,c.application_short_name,10003,b.responsibility_name,10004,d.user_name) LValue,NVL(a.profile_option_value,'Is Null') Value,SUBSTR(a.last_update_date,1,25) UPDATED_DATE
FROM fnd_profile_option_values a, fnd_responsibility_tl b, fnd_application c,fnd_user d, fnd_profile_options e
WHERE 
--e.profile_option_name IN ('ASO_PRINT_METHOD','ASO_COMP_LOGO')
a.PROFILE_OPTION_VALUE like '%scd%'  and a.PROFILE_OPTION_VALUE like '%erpprod%'
AND e.profile_option_id = a.profile_option_id AND a.level_value = b.responsibility_id (+)
AND a.level_value = c.application_id (+) AND a.level_value = d.user_id (+)
ORDER BY profile_option_name;
