set lines 200
explain plan for 
SELECT  DISTINCT furg.responsibility_id,
  furg.responsibility_application_id,
  furg.security_group_id,
  furg.start_date,
  furg.end_date
FROM apps.fnd_user_resp_groups furg,
  apps.fnd_responsibility fr
WHERE furg.user_id                     = :1
AND furg.responsibility_id             = fr.responsibility_id
AND furg.responsibility_application_id = fr.application_id
AND furg.start_date                   <= sysdate
AND (furg.end_date                    IS NULL
OR furg.end_date                      >= sysdate)
AND fr.start_date                     <= sysdate
AND (fr.end_date                      IS NULL
OR fr.end_date                        >= sysdate)
ORDER BY furg.responsibility_id,
  furg.responsibility_application_id,
  furg.security_group_id
/
@?/rdbms/admin/utlxpls
