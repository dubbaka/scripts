set head on
set termout on
SELECT a.tablespace_name "TABLESPACE NAME",
       c.status "STATUS",
       b.size_mb"USED SIZE(M)",
       a.free_mb"FREE SIZE(M)",
       TRUNC((a.free_mb/b.size_mb) * 100) "FREE %"
FROM
   (SELECT tablespace_name,ROUND(SUM((bytes)/1024/1024),2) free_mb
     FROM   dba_free_space
        GROUP BY tablespace_name) a,
   (SELECT tablespace_name,ROUND(SUM((bytes)/1024/1024),2) size_mb
     FROM dba_data_files
        GROUP BY tablespace_name) b,
   (SELECT tablespace_name,status FROM dba_tablespaces) c
  WHERE
     a.tablespace_name = b.tablespace_name
 AND a.tablespace_name=c.tablespace_name
-- AND a.tablespace_name like 'TBS'
order by 1;
