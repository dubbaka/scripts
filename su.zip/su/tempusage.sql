select sum(blocks)*8192/(1024*1024) from v$sort_usage
/
