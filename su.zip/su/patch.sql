select bug_number,creation_date from apps.ad_bugs where bug_number='&patch_number';
