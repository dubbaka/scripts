column Owner format a10
 column Tablename format a26
 column Logname format a26
 column Youngest format a9
  column "Last Refreshed" format a10
  column "Last Refreshed" heading "Last|Refreshed"
  column "MView ID" format 9999
  column "MView ID" heading "Mview|ID"
  column Oldest_ROWID format a10
  column Oldest_PK format a10
column SNAPSITE format a18

select m.mowner Owner,
         m.master Tablename,
         m.log Logname,
         m.youngest Youngest,
         s.snapid "MView ID",
         r.SNAPSITE,
         to_char(s.snaptime,'DD-MON-YY HH24:MI:SS') "Last Refreshed",
         oldest Oldest_ROWID
  from sys.mlog$ m, sys.slog$ s, sys.reg_snap$ r
  WHERE s.mowner (+) = m.mowner
  and s.master (+) = m.master
  and s.mowner like '%&owner%'
  and s.snapid = r.snapshot_id
/
