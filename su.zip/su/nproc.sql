select spid,sid,module from v$process a, v$session b where spid in ( 18046,4294,11563)
and a.addr = b.paddr
/
