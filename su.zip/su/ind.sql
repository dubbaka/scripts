set pages 0
spool ind.lst
break on index_name skip 1
column index_name format a30
column column_name format a30
select index_name, column_name from dba_ind_columns
where table_name = UPPER('&tname')
and table_owner =upper('&owner')
order by index_name, column_position
/
spool off
