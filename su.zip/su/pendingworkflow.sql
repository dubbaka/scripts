SELECT Count(*)
FROM   apps.wf_notifications
WHERE  status='OPEN'
AND   message_type ='REQAPPRV'
AND   message_name = 'PO_REQ_APPROVE_SIMPLE_JRAD'
AND   Nvl(mail_status,'X') <>'SENT'
AND   begin_date > sysdate - 30 
AND NOT EXISTS (
   SELECT 'x' 
   FROM apps.wf_notifications a 
   WHERE  a.end_date >= SYSDATE - 1/4
   AND responder LIKE 'email%'
);

