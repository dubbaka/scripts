select    rct.customer_trx_id cust_trx_id   ,rct.trx_number
trx_number   ,rct.trx_date trx_date   ,rct.comments comments
,rct.interface_header_attribute1 order_number   ,rct.bill_to_contact_id
bill_to_contact_id   ,rct.ship_to_contact_id ship_to_contact_id
,rc_bill.customer_id bill_to_cust_id   ,rc_bill.customer_name
bill_to_cust_name   ,rc_bill.customer_number bill_to_cust_number
,rc_bill.tax_reference bill_to_cust_tax_ref   ,rs_bill.tax_reference
bill_to_site_tax_ref   ,ra_bill.address1 bill_to_addr1   ,ra_bill.address2
bill_to_addr2   ,ra_bill.address3 bill_to_addr3   ,ra_bill.address4
bill_to_addr4   ,ra_bill.city bill_to_city   ,ra_bill.postal_code
bill_to_postal_code   ,ra_bill.country bill_to_country_code
,ft_bill.territory_short_name bill_to_country   ,rc_ship.customer_id
ship_to_cust_id   ,rc_ship.customer_name ship_to_cust_name
,rc_ship.tax_reference ship_to_cust_tax_ref   ,rs_ship.tax_reference
ship_to_site_tax_ref   ,ra_ship.address1 ship_to_addr1   ,ra_ship.address2
ship_to_addr2   ,ra_ship.address3 ship_to_addr3   ,ra_ship.address4
ship_to_addr4   ,ra_ship.city ship_to_city   ,ra_ship.postal_code
ship_to_postal_code   ,ra_ship.country ship_to_country_code
,ft_ship.territory_short_name ship_to_country   ,ra_remit.address1
remit_to_addr1   ,ra_remit.address2 remit_to_addr2   ,ra_remit.address3
remit_to_addr3   ,ra_remit.address4 remit_to_addr4   ,ra_remit.city
remit_to_city   ,ra_remit.postal_code remit_to_postal_code
,ra_remit.country remit_to_country   ,rtt.name transaction_type
,rtt.type transaction_class   ,rct.exchange_rate exchange_rate
,fc.currency_code currency_code   ,fc.symbol currency_symbol
from    ra_cust_trx_types  rtt   ,ra_customer_trx  rct   ,fnd_currencies
fc   ,fnd_territories_tl  ft_bill   ,fnd_territories_tl  ft_ship
,ra_customers rc_bill   ,ra_customers rc_ship   ,ra_addresses
ra_bill   ,ra_addresses ra_ship   ,ra_addresses ra_remit   ,ra_site_uses
rs_bill   ,ra_site_uses rs_ship where       rct.cust_trx_type_id
= rtt.cust_trx_type_id   and rct.bill_to_site_use_id = rs_bill.site_use_id(+)
and rs_bill.address_id = ra_bill.address_id(+)   and ra_bill.country
= ft_bill.territory_code(+)   and rct.bill_to_customer_id =
rc_bill.customer_id   and rct.ship_to_site_use_id = rs_ship.site_use_id(+)
and rs_ship.address_id = ra_ship.address_id(+)   and ra_ship.country
= ft_ship.territory_code(+)   and rct.ship_to_customer_id =
rc_ship.customer_id(+)   and rct.remit_to_address_id = ra_remit.address_id(+)
and rct.invoice_currency_code = fc.currency_code   and rct.complete_flag
= 'Y'   and nvl(rct.printing_option,'X') <> 'NOT'   and rtt.type
= nvl(:p_cust_trx_class,rtt.type)   and rct.cust_trx_type_id
= nvl(:p_cust_trx_type_id,rct.cust_trx_type_id)   and rct.trx_number
>= nvl(:p_trx_number_low,rct.trx_number)   and rct.trx_number
<= nvl(:p_trx_number_high,rct.trx_number)   and rct.trx_date
>= nvl(:p_date_low,rct.trx_date)   and rct.trx_date <= nvl(:p_date_high,rct.trx_date)
and rc_bill.customer_id = nvl(:p_customer_id,rc_bill.customer_id)
order by   trx_number

