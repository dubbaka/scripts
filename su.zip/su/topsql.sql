set line 132
set pagesize 1000
set long 200000
col sql_text format a100 wrap
col per_exec format 99,999,999
col executions format 9,999,999
col rows_proc format 9,999,999,999
col buffer_gets format 9,999,999,999
col MB_per_disk format 9,999,999,999
col module format a10
spool topsql.out
select * from (
select module,
       hash_value,
       executions,
       buffer_gets/decode(nvl(executions,1),0,1,nvl(executions,1)) per_exec,
       buffer_gets,
       (disk_reads/decode(nvl(executions,1),0,1,nvl(executions,1)) ) * (8) MB_per_disk,
       disk_reads ,
       rows_processed rows_proc,
       OPTIMIZER_MODE, 
       sql_text ||chr(10)||'------------------------------------------------'
from v$sqlarea 
where (executions >= 55)
and disk_reads > 100000
and LAST_ACTIVE_TIME > sysdate - 6/24
order by disk_reads desc
) where rownum < &nbr_of_rows
/
spool  off

