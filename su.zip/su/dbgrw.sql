column OCT_2002 format 999999.99
column NOV_2002 format 999999.99
column DEC_2002 format 999999.99
column JAN_2003 format 999999.99
column FEB_2003 format 999999.99
column MAR_2003 format 999999.99
select ((sum(decode(to_char(dbs_date,'dd-MON-yy'),'31-OCT-02',used_bytes,0))/1024)/1024)/1024 OCT_2002,
       ((sum(decode(to_char(dbs_date,'dd-MON-yy'),'30-NOV-02',used_bytes,0))/1024)/1024)/1024 NOV_2002,
       ((sum(decode(to_char(dbs_date,'dd-MON-yy'),'31-DEC-02',used_bytes,0))/1024)/1024)/1024 DEC_2002,
       ((sum(decode(to_char(dbs_date,'dd-MON-yy'),'15-JAN-03',used_bytes,0))/1024)/1024)/1024 JAN_2003
 from dbs_tablespaces
/
