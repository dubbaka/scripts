set lines 150
set feedback on
set pagesize 1000
column  	sid format 99999
column		event format a25 
column		module format a25
column      username format a12
column      seconds_in_wait format 999999 
column      p1 format 999999999999

select b.sid, b.event, substr(a.action,1,1)||'-'||a.module module , a.username ,
      b.p1, b.seq# ,b.seconds_in_wait from v$session_wait b, v$session  a
where b.event in ('log file sync')
  and a.sid  = b.sid
/
