col module format A15
col action format A40
col status format A10
col sid format 9999
set pages 0
set linesize 200
set feedback off

prompt "----------------------------------------"
prompt "Inactive AR forms more than 1 hour old"
prompt "----------------------------------------"
select
sid,action, module,status, to_char(logon_time,'DD-MON-YYYY HH24:MI:SS')
from v$session
where
logon_time < sysdate - 1/24 and
status !='KILLED' and
action like 'FRM%' and module like 'AR%' 
order by action
/


prompt "----------------------------------------"
select
'ALTER SYSTEM KILL SESSION ' ||''''||sid||','|| serial#||''''||';'
from v$session
where
logon_time < sysdate -1/24
and status  !='KILLED'
and action like 'FRM%' and module like 'AR%' 
/

prompt "----------------------------------------"
prompt "Active AR forms more than 1 hour old"
prompt "----------------------------------------"

select
sid,action, module,status, to_char(logon_time,'DD-MON-YYYY HH24:MI:SS')
from v$session
where
logon_time < sysdate - 1/24 and
status ='ACTIVE' and
action like 'FRM%' and module like 'AR%' 
order by action
/

prompt "----------------------------------------"
select
'ALTER SYSTEM KILL SESSION ' ||''''||sid||','|| serial#||''''||';'
from v$session
where
logon_time < sysdate -1/24
and status  ='ACTIVE'
and action like 'FRM%' and module like 'AR%' 
/
