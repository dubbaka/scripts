    select TABLESPACE_NAME,
            round(sum(maxbytes)/1000000,1) max_size,
            round(sum(bytes)/1000000,1) AS current_size ,
            round(100*((sum(maxbytes)-sum(bytes))/sum(maxbytes)),0) pct_bytes_free,
            AUTOEXTENSIBLE
            from dba_data_files
where tablespace_name ='&1'
          group by TABLESPACE_NAME,AUTOEXTENSIBLE;
exit;
