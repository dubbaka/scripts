SQL> /

'ALTERVIEW'||OWNER||'.'||OBJECT_NAME||'COMPILE;'                                                                                                        
--------------------------------------------------------------------------------------------------------------------------------------------------------
alter VIEW SYSTEM.V_$DLM_RESS compile;                                                                                                                  
alter VIEW SYSTEM.V_$TARGETRBA compile;                                                                                                                 
alter VIEW APPS.FPA_AW_CALENDARS_V compile;                                                                                                             
alter VIEW APPS.FPA_AW_INV_CRITERIA_INFO_V compile;                                                                                                     
alter VIEW APPS.FPA_AW_INV_CRITERIA_V compile;                                                                                                          
alter VIEW APPS.FPA_AW_PCLASS_FIN_METRICS_V compile;                                                                                                    
alter VIEW APPS.FPA_AW_PCLASS_FUNDS_V compile;                                                                                                          
alter VIEW APPS.FPA_AW_PCLASS_STR_SCORES_V compile;                                                                                                     
alter VIEW APPS.FPA_AW_PCS_V compile;                                                                                                                   
alter VIEW APPS.FPA_AW_PC_DISC_FUNDS_V compile;                                                                                                         
alter VIEW APPS.FPA_AW_PC_FINANCIAL_TARGETS_V compile;                                                                                                  
alter VIEW APPS.FPA_AW_PC_INFO_V compile;                                                                                                               
alter VIEW APPS.FPA_AW_PC_INV_CRITERIA_V compile;                                                                                                       
alter VIEW APPS.FPA_AW_PC_INV_CRIT_SETUP_V compile;                                                                                                     
alter VIEW APPS.FPA_AW_PC_INV_MATRICES_V compile;                                                                                                       
alter VIEW APPS.FPA_AW_PC_PROJECTS_V compile;                                                                                                           
alter VIEW APPS.FPA_AW_PC_SCORE_INFO_V compile;                                                                                                         
alter VIEW APPS.FPA_AW_PERIOD_ATTS_V compile;                                                                                                           
alter VIEW APPS.FPA_AW_PORTFS_V compile;                                                                                                                
alter VIEW APPS.FPA_AW_PORTF_HEADERS_V compile;                                                                                                         
alter VIEW APPS.FPA_AW_PROJECT_SETS_V compile;                                                                                                          
alter VIEW APPS.FPA_AW_PROJS_V compile;                                                                                                                 
alter VIEW APPS.FPA_AW_PROJ_CASHFLOWS_V compile;                                                                                                        
alter VIEW APPS.FPA_AW_PROJ_FIN_METRICS_V compile;                                                                                                      
alter VIEW APPS.FPA_AW_PROJ_INFO_V compile;                                                                                                             
alter VIEW APPS.FPA_AW_PROJ_INV_CRITERIA_V compile;                                                                                                     
alter VIEW APPS.FPA_AW_PROJ_NPVS_V compile;                                                                                                             
alter VIEW APPS.FPA_AW_PROJ_STR_SCORES_V compile;                                                                                                       
alter VIEW APPS.FPA_AW_QUARTER_ATTS_V compile;                                                                                                          
alter VIEW APPS.FPA_AW_SCES_V compile;                                                                                                                  
alter VIEW APPS.FPA_AW_SCE_CASHFLOWS_V compile;                                                                                                         
alter VIEW APPS.FPA_AW_SCE_FIN_METRICS_V compile;                                                                                                       
alter VIEW APPS.FPA_AW_SCE_FUNDS_V compile;                                                                                                             
alter VIEW APPS.FPA_AW_SCE_INFO_V compile;                                                                                                              
alter VIEW APPS.FPA_AW_SCE_NPVS_V compile;                                                                                                              
alter VIEW APPS.FPA_AW_SCE_STR_SCORES_V compile;                                                                                                        
alter VIEW APPS.FPA_AW_YEAR_ATTS_V compile;                                                                                                             
alter VIEW APPS.FPA_INV_CRITERIA_VL compile;                                                                                                            
alter VIEW APPS.FPA_PCS_VL compile;                                                                                                                     
alter VIEW APPS.FPA_PORTFS_VL compile;                                                                                                                  
alter VIEW APPS.FPA_SCES_VL compile;                                                                                                                    
alter VIEW APPS.GOTO_CONTRACT_CONTRACT_V compile;                                                                                                       
alter VIEW APPS.GOTO_CONTRACT_PYMT_TERM_V compile;                                                                                                      
alter VIEW APPS.GOTO_PARTNER_ACCOUNT_DAILY_V compile;                                                                                                   
alter VIEW APPS.GOTO_PARTNER_ACCOUNT_MONTHLY_V compile;                                                                                                 
alter VIEW APPS.GOTO_PARTNER_ACCOUNT_MON_AUDIT compile;                                                                                                 
alter VIEW APPS.GOTO_PARTNER_ID_LOOKUP_NEW_V compile;                                                                                                   
alter VIEW APPS.GOTO_PARTNER_ID_LOOKUP_ONE_V compile;                                                                                                   
alter VIEW APPS.GOTO_PARTNER_ID_LOOKUP_SUM_V compile;                                                                                                   
alter VIEW APPS.GOTO_PARTNER_ID_LOOKUP_V compile;                                                                                                       
alter VIEW APPS.GOTO_SOURCE_BY_SEARCH_DAILY compile;                                                                                                    
alter VIEW APPS.GOTO_SOURCE_BY_SEARCH_DAILY_ID compile;                                                                                                 
alter VIEW APPS.JA_IN_WSH_DELIVERIES_V compile;                                                                                                         
alter VIEW APPS.OFA_RA_ADDRESSES_BKP compile;                                                                                                           
alter VIEW APPS.PAFG_BUDGET_LINES compile;                                                                                                              
alter VIEW APPS.PAM_SOURCE_BY_SEARCH_DAILY_ID compile;                                                                                                  
alter VIEW SHOE.QUEST_IM_ARCHIVED_LOG compile;                                                                                                          
alter VIEW SHOE.QUEST_IM_ARCHIVE_DEST compile;                                                                                                          
alter VIEW SHOE.QUEST_IM_BUFPOOLSTATS compile;                                                                                                          
alter VIEW SHOE.QUEST_IM_FILESTAT compile;                                                                                                              
alter VIEW SHOE.QUEST_IM_FULL_SGASTAT compile;                                                                                                          
alter VIEW SHOE.QUEST_IM_LATCH compile;                                                                                                                 
alter VIEW SHOE.QUEST_IM_PREV_SQLTEXT compile;                                                                                                          

'ALTERVIEW'||OWNER||'.'||OBJECT_NAME||'COMPILE;'                                                                                                        
--------------------------------------------------------------------------------------------------------------------------------------------------------
alter VIEW SHOE.QUEST_IM_SESSION_SQLTEXT compile;                                                                                                       
alter VIEW SHOE.QUEST_IM_SESS_OPEN_CURSOR compile;                                                                                                      
alter VIEW SHOE.QUEST_IM_SGASTAT compile;                                                                                                               
alter VIEW SHOE.QUEST_IM_SGAUTIL compile;                                                                                                               
alter VIEW SHOE.QUEST_IM_SP_STATUS compile;                                                                                                             
alter VIEW SHOE.QUEST_IM_SQL_FULL_TEXT compile;                                                                                                         
alter VIEW SHOE.QUEST_IM_SYSTEM_EVENT1 compile;                                                                                                         
alter VIEW SHOE.QUEST_IM_SYSTEM_EVENT_CAT compile;                                                                                                      
alter VIEW CSMIG.CSMV$COLUMNS compile;                                                                                                                  
alter VIEW CSMIG.CSMV$CONSTRAINTS compile;                                                                                                              
alter VIEW CSMIG.CSMV$ERRORS compile;                                                                                                                   
alter VIEW CSMIG.CSMV$INDEXES compile;                                                                                                                  
alter VIEW CSMIG.CSMV$TABLES compile;                                                                                                                   
alter VIEW CSMIG.CSMV$TRIGGERS compile;                                                                                                                 
alter VIEW NOETIX_SYS.AUPO_VENDORS compile;                                                                                                             
alter VIEW NOETIX_SYS.CAPO_PO_SHIPMENTS compile;                                                                                                        
alter VIEW NOETIX_SYS.CAPO_VENDORS compile;                                                                                                             
alter VIEW NOETIX_SYS.DEPO_PO_SHIPMENTS compile;                                                                                                        
alter VIEW NOETIX_SYS.DEPO_VENDORS compile;                                                                                                             
alter VIEW NOETIX_SYS.ESPO_PO_SHIPMENTS compile;                                                                                                        
alter VIEW NOETIX_SYS.ESPO_VENDORS compile;                                                                                                             
alter VIEW NOETIX_SYS.EUPO_PO_SHIPMENTS compile;                                                                                                        
alter VIEW NOETIX_SYS.EUPO_VENDORS compile;                                                                                                             
alter VIEW NOETIX_SYS.FNDAP_USER_RESPONSIBILITY compile;                                                                                                
alter VIEW NOETIX_SYS.FRPO_PO_SHIPMENTS compile;                                                                                                        
alter VIEW NOETIX_SYS.FRPO_VENDORS compile;                                                                                                             
alter VIEW NOETIX_SYS.ITPO_PO_SHIPMENTS compile;                                                                                                        
alter VIEW NOETIX_SYS.ITPO_VENDORS compile;                                                                                                             
alter VIEW NOETIX_SYS.NOETIX_SEARCHBY_CANDIDATES compile;                                                                                               
alter VIEW NOETIX_SYS.N_APPS_SECURITY_INFO_VL compile;                                                                                                  
alter VIEW NOETIX_SYS.N_FND_USER_RESPONSIBILITY_VL compile;                                                                                             
alter VIEW NOETIX_SYS.UKPO_PO_SHIPMENTS compile;                                                                                                        
alter VIEW NOETIX_SYS.UKPO_VENDORS compile;                                                                                                             
alter VIEW NOETIX_SYS.USPO_PO_SHIPMENTS compile;                                                                                                        
alter VIEW NOETIX_SYS.USPO_VENDORS compile;                                                                                                             

98 rows selected.

SQL> spool off
