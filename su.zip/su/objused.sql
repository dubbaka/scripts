select distinct kglnaobj 
from x$kgllk  where kgllkuse in 
(select saddr from v$session where sid = &&sid)
/
