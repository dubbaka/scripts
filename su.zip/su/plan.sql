SELECT LPAD(' ',2*(LEVEL-1))||operation||' '||options
||' '||object_name
||' '||DECODE(id, 0, 'Cost = '||position) "Query Plan"
FROM plan_table
START WITH id = 0  and statement_id = 'SURESH'
CONNECT BY PRIOR id = parent_id and prior statement_id = statement_id
/
