break on HASH_VALUE
set echo on;
set feedback on;
set pagesize 1000
set long 200000

column sql_text format a64;

SELECT C.SID, C.SERIAL#, B.REQUEST_ID, D.SQL_TEXT
FROM   V$PROCESS A, FND_CONCURRENT_REQUESTS B, 
       V$SESSION C, V$SQLTEXT D
WHERE  A.ADDR=C.PADDR
AND    A.SPID = 25404 
AND    D.HASH_VALUE = C.SQL_HASH_VALUE
AND    A.SPID = B.ORACLE_PROCESS_ID
order by piece
/

