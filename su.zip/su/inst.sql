set lines 132
set pages 2000

select inst_id,count(*) from gv$session group by inst_id;
