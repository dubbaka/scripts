select  ts#, name, count(*) 
from ( select a.ts#, b.name
from v$datafile a, v$tablespace b
where 
-- CREATION_TIME > to_date('30-JUN-02', 'dd-MON-yy')
--  and 
a.ts# = b.ts#
)
group by ts#,name  order by count(*)
/
