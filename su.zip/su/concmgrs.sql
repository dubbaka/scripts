COL c1  FORMAT 99999999       HEADING "Oracle|Process|ID #"
COL c2  FORMAT 99999999       HEADING "PPID"
COL c3  FORMAT 99999999       HEADING "Process|ID #"
COL c4  FORMAT 99999999       HEADING "Concurrent|ID #"
COL c5  FORMAT A8             HEADING "User Name"
COL c6  FORMAT A15            HEADING "Time|Started"
COL c7  FORMAT A7             HEADING "Time|Elapsed"
COL c8  FORMAT A30            HEADING "Short Name"

SPOOL UT_VCMGR.log

SELECT  DISTINCT
        fvp.pid c1
,       fvp.spid c2
,       vp.spid c3
,       fcr.request_id c4
,       SUBSTR(fu.user_name,0,8) c5
,       SUBSTR(TO_CHAR(actual_start_date,'DD-MON-YY HH24:MI'),0,15) c6
--REM ,       SUBSTR(TO_CHAR(TO_DATE(actual_start_date,'DD-MON-YY')||(SYSDATE - actual_start_date),'HH24:MI'),0,7) c7
,       SUBSTR(concurrent_program_name, 0, 30) c8
FROM    fnd_concurrent_requests fcr
,       fnd_concurrent_programs fcp
,       fnd_logins fl1
,       fnd_logins fl2
,       fnd_user fu
,       fnd_v$process fvp                                                     
,       v$process vp
WHERE   fl1.login_id = fcr.conc_login_id
AND     fcr.program_application_id = fcp.application_id
AND     fcr.concurrent_program_id = fcp.concurrent_program_id
AND     fl1.submitted_login_id = fl2.login_id
AND     fu.user_id = fl1.user_id
AND     fcr.phase_code = 'R'
AND     fvp.pid (+)  = fl2.pid
AND     vp.pid (+) = fl2.pid;
