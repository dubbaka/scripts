column name format a30 word_wrapped
column vlu format 999,999,999,999
select a.sid,c.module, a.value vlu
from v$sesstat a, v$statname b
, v$session c
where a.statistic# = b.statistic#
and a.sid = c.sid
and a.value != 0
and b.name = 'table scan rows gotten'
and a.value > 10000000
order by 2 desc
/
