col username for a12
col osuser for a12
col machine for a30
col terminal for a15
set lines 132
set feedback on
select distinct username, osuser, machine, terminal 
  from v$session 
where username in ('APPS','APPLSYS','SYSTEM','SYS')
/
