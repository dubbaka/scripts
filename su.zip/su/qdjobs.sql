set line 132
set pagesize 10000
col USER_CONCURRENT_PROGRAM_NAME format a43 wrap 
col StartDate format a20 wrap 
col REQUESTED_BY format 999999
col Queue format a30 wrap

SELECT 
  REQUEST_ID,
  PHASE_CODE,
  STATUS_CODE,
--  to_char(actual_Start_date,'DD-MON-YYYY HH24:MI:SS') StartDate,
  to_char(REQUESTED_START_DATE,'DD-MON-YYYY HH24:MI:SS') CREATION_DATE,
  REQUESTED_BY,
  FQ.USER_CONCURRENT_QUEUE_NAME Queue,
  fcp.user_concurrent_program_name USER_CONCURRENT_PROGRAM_NAME
FROM 
  FND_CONCURRENT_WORKER_REQUESTS FCWR,
  FND_CONCURRENT_PROGRAMS_TL FCP,
  FND_CONCURRENT_QUEUES_VL FQ
WHERE 
  (Phase_Code = 'P' OR Phase_Code = 'R') 
  AND hold_flag != 'Y' 
  AND Requested_Start_Date <= SYSDATE  
  AND ('' IS NULL OR ('' = 'B' AND  PHASE_CODE in ( 'R','P') AND  STATUS_CODE IN ('I', 'Q')))
  AND FCWR.CONCURRENT_QUEUE_ID = FQ.CONCURRENT_QUEUE_ID
  AND FQ.USER_CONCURRENT_QUEUE_NAME like '%&manager_name%' 
  AND FCP.CONCURRENT_PROGRAM_ID = FCWR.CONCURRENT_PROGRAM_ID  
  and fcp.language      = 'US'
ORDER BY STATUS_CODE,REQUESTED_START_DATE,--actual_Start_date,
fcp.user_concurrent_program_name,Priority, Priority_Request_ID, Request_ID     
/
