select sql_id from v$session where sid=&sid;
SET LONG 10000000
SET LONGCHUNKSIZE 10000000
SET LINESIZE 1000
SET PAGESIZE 5000
SELECT DBMS_SQLTUNE.REPORT_SQL_MONITOR(sql_id => '&sql_id',type => 'TEXT',report_level=>'ALL') AS report FROM dual;
