set pau off
set feedback off
set term off
set lines 132 
set pages 300
set head on

col username format a30
col created format 9999999
col account_status format a15
col privilege format a25


spool /usr/local/dba/tools/log/quarter_sox_audit.log

select 	du.username, 
	du.created, 
	du.account_status,
	dsp.privilege 
from 	dba_users du, dba_sys_privs dsp 
where 	du.created > sysdate - 91
and 	du.username=dsp.grantee
order by 2

/
spool off
/
exit
/
