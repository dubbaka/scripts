create or replace package yhbkp is

procedure backup_tbsp
(
  i_tbs_action  IN  VARCHAR2,
  i_tbs_name    IN  VARCHAR2
); 

function db_mode return varchar2;
function active_tbs return number;

end;
/

CREATE OR REPLACE PACKAGE BODY YHBKP IS

procedure backup_tbsp 
(
  i_tbs_action  IN  VARCHAR2,
  i_tbs_name    IN  VARCHAR2
) AS

CURSOR get_tbs_info (v_tbs_name IN varchar2) IS
   select distinct c.name tablespace_name ,a.status,b.status state 
   from v$backup a , v$datafile b , v$tablespace c
   where c.name like v_tbs_name 
   and c.ts# = b.ts#
   and b.file# = a.file#;

tbs_info      get_tbs_info%ROWTYPE;
v_input_tbs   dba_tablespaces.tablespace_name%TYPE;

sql_cmd       VARCHAR2(1000);
sql_cur       INTEGER;
sql_row_cnt   INTEGER;

BEGIN 
  
    IF i_tbs_name = 'ALL'
    THEN
        v_input_tbs := '%';
    ELSE
        v_input_tbs := i_tbs_name;
    END IF;

    dbms_output.put_line ('Enter LOOP ' || v_input_tbs);

    for tbs_info in get_tbs_info(v_input_tbs)
    loop

       dbms_output.put_line ('Enter LOOP ' || tbs_info.tablespace_name ||':'||tbs_info.state);

       IF tbs_info.state = 'ONLINE' OR tbs_info.state = 'SYSTEM'
       THEN
           IF i_tbs_action = 'B' 
           THEN
               IF tbs_info.status = 'NOT ACTIVE' 
               THEN
                  sql_cmd := 'ALTER TABLESPACE ' || tbs_info.tablespace_name || ' BEGIN BACKUP' ;
                  execute immediate sql_cmd;
                  dbms_output.put_line ( sql_cmd ); 
                ELSE
                   dbms_output.put_line ( 'Tablespace ' || tbs_info.tablespace_name || 
                                           ' is in backup mode' );
                END IF;
          
            END IF;

            IF i_tbs_action = 'E' 
            THEN

                 IF tbs_info.status = 'ACTIVE' 
                 THEN

                    sql_cmd := 'ALTER TABLESPACE ' || tbs_info.tablespace_name || ' END BACKUP ' ;
                    execute immediate sql_cmd;
                    dbms_output.put_line ( sql_cmd ); 

                 ELSE

                    dbms_output.put_line ( 'Tablespace ' || tbs_info.tablespace_name || 
                                            ' is not in backup mode' );

                 END IF;
          
             END IF;

       END IF; 

    END LOOP;

    EXCEPTION 
    
      WHEN NO_DATA_FOUND THEN
        dbms_output.put_line('Error encounterd ');

end ;


function db_mode
return varchar2 is
BEGIN

 for xx in ( select log_mode from v$database )
 loop
    return (xx.log_mode);
 end loop;

END db_mode;


function active_tbs 
return number is 
BEGIN

 for xx in ( select count(*) active_tbs from v$backup where status='ACTIVE'  )
 loop
      return (xx.active_tbs);
 end loop;

END active_tbs;

END yhbkp;  
/
