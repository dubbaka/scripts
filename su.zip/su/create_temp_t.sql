create global temporary table temp_t
(
 V_TEXT                                             VARCHAR2(4000),
 V_NAME                                             VARCHAR2(4000),
 V_TYPE                                             VARCHAR2(5),
 V_OWNER                                            VARCHAR2(4000)
);
