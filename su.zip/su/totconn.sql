col username format a50
select username,count(1) from v$session  group by username;
select count(1)||'-total connection'   from v$session ;

