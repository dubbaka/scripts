column cprog	format a20 word_wrapped
column uprog	format a50 word_wrapped

undefine svalue
undefine progname
set verify off

--Prompt Enter 1 for Form 2 for conc prog 
accept svalue Prompt "Enter 1 for Form 2 for conc prog  : "
--Prompt Enter Prog Name		
accept progname Prompt "Enter Prog Name : "

select a.concurrent_program_name cprog, b.user_concurrent_program_name uprog
  from fnd_concurrent_programs a, fnd_concurrent_programs_tl b
 where a.concurrent_program_id = b.concurrent_program_id
   and a.application_id        = b.application_id
   and a.concurrent_program_name = '&&progname'
   and b.language				 = 'US'
   and 2						 = &&svalue
union all
select a.form_name fname, b.user_form_name  ufname
  from FND_FORM a, FND_FORM_tl b
 where a.form_id 			= b.form_id
   and a.application_id 	= b.application_id
   and a.FORM_NAME 			= '&&progname'
   and b.language   		= 'US'
   and 1				 	= &&svalue
/
