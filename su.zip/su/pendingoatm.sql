select owner,segment_name,segment_type,tablespace_name,bytes/1024/1024 from dba_Segments where owner in ('APPS','AR','APPLSYS') AND TABLESPACE_NAME NOT LIKE 'APPS_%' and TABLESPACE_NAME NOT LIKE 'XXYH%' and TABLESPACE_NAME NOT LIKE 'OBT%' and  TABLESPACE_NAME NOT LIKE 'AMTO%' order by 5
/
