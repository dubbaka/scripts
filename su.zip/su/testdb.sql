select synonym_name,db_link from dba_synonyms where db_link like '%ADMN%'
/
