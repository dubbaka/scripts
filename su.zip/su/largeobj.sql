column segment_name heading 'Object ' format a30
column sz heading 'Allocated ' format 99,999.999
select  segment_name, bytes / (1024*1024) sz
from dba_segments 
where blocks > 50000
order by 2
/
