select inst_id c0,sid,program c1,ROW_WAIT_OBJ# object_no, ROW_WAIT_FILE# Rfile_no,
ROW_WAIT_BLOCK# Block_no ,ROW_WAIT_ROW# Row_no 
from gv$session 
where (inst_id,sid) in (select inst_id,sid from gv$session_wait where p1='&p1') 
/

PROMPT Please use the values returned by above 
PROMPT to find the exact rows 
PROMPT select * from cmpgn.TERM_YSM  where rowid like 
PROMPT DBMS_ROWID.ROWID_CREATE(1,102524,311, 1062574,1) 
PROMPT /  
