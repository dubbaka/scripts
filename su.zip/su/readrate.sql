select a.average_wait "SEQ READ", b.average_wait "SCAT READ",c.average_wait "DIRECT READ"
from sys.v_$system_event a, sys.v_$system_event b , sys.v_$system_event c
where a.event = 'db file sequential read'
and b.event = 'db file scattered read'
and c.event = 'direct path read';
