prompt this will show you the subpools used in shared pool

select a.ksppinm "Parameter",
b.ksppstvl "Session value",
c.ksppstvl "Instance value"
from
	sys.x$ksppi a ,
	sys.x$ksppcv b,
	sys.x$ksppsv c
Where
	a.indx=b.indx and
	a.indx=c.indx and 
	a.ksppinm like '%kghdsidx%';
