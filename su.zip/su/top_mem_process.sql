set lines 250
set feedback on
set pagesize 1000
column          sid format 99999
column          event format a30
column          module format a35
column      username format a12
column      seconds_in_wait format 999999
column      p1 format 999999999999

select sum(pga_used_mem)/(1024*1024),sum(pga_alloc_mem)/(1024*1024) from v$process;

select * from (select sid,s.action,module,sum(pga_used_mem)/(1024*1024),sum(pga_alloc_mem)/(1024*1024) from v$process , v$session s where addr=paddr and status not like 'KILLED' group by sid,s.action,module order by 4 desc)
where rownum <21
/

select * from (select module,sum(pga_used_mem)/(1024*1024),sum(pga_alloc_mem)/(1024*1024) from v$process , v$session where addr=paddr  and status not like 'KILLED' group by module order by 3 desc)
where rownum <21
/

--select * from (select sid,module,sum(pga_used_mem)/(1024*1024),sum(pga_alloc_mem)/(1024*1024) from v$process , v$session where addr=paddr and status not like 'KILLED'  and module like '&module' group by sid,module order by 4 desc)
--/
