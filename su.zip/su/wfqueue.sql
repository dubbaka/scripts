
select count(*), SUBSCRIBER_TYPE from applsys.aq$_wf_control_s group by subscriber_type
/
