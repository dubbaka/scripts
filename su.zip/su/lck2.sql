column sess format a8 word_wrapped
column id1   format 99999999
column id2   format 99999999
column req	 format 999
column type  format a4
column "Module" format a30 word_Wrapped
SELECT lpad('-->',DECODE(request,0,0,5),' ')||sid sess
       , id1
       , id2
       , lmode
      ,  request req, type, (sid) "Module"
FROM V$LOCK
 WHERE id1 IN (SELECT id1 FROM V$LOCK WHERE lmode = 0)
 ORDER BY id1,request
/
