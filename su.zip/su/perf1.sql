select
         a.client_value from eps.am_client_value a, eps.goto_account g where
         g.company_id = a.company_id and g.a_account_id = :3
