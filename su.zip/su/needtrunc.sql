set pagesize 1000
col owner format a10
select owner,table_name,NUM_ROWS,BLOCKS from dba_tables  where num_rows=0 
and blocks > 10 order by 4 
/
