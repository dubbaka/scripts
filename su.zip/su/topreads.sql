select c.sid,c.module,abs(a.value) val
from v$sesstat a, v$statname b, v$session c
where a.statistic# = b.statistic#
and a.value != 0
and b.name  like 'physical reads'
and c.sid = a.sid
and abs(a.value) > 500000
order by abs(a.value)
/
