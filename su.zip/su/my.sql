
set verify off termout on 
col segment_name for a22 
col partition_name for a22 

select dbarfil, dbablk, class, state, e.segment_name, e.partition_name, e.block_id, e.blocks 
from sys.x$bh bh , dba_extents e 
where BH.HLADDR = HEXTORAW('&P1') 
and bh. dbarfil = e.file_id 
and bh.dbablk >= e.block_id 
and bh.dbablk <= (e.block_id + e.blocks) 
/

