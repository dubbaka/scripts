set linesize 250
set pages 1000
col PROGRAM for a59
col COMPLETION_TEXT for a25
col ARGUMENT_TEXT for a75
col Mins for a6
select request_id,PROGRAM,COMPLETION_TEXT,ARGUMENT_TEXT,
to_char(ACTUAL_START_DATE,'dd-Mon-RR HH24:mi:ss') start_date,
to_char(ACTUAL_COMPLETION_DATE,'dd-Mon-RR HH24:mi:ss') compl_date,
to_char(round((actual_completion_date - actual_start_date) * 1440, 2))  Mins 
from FND_CONC_REQ_SUMMARY_V
where (PROGRAM) like '%&req_name%' 
and REQUESTED_START_DATE > (sysdate-20)
order by program, REQUESTED_START_DATE ;
