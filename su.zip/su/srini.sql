create table apps_backup.rbt_tmp as select /*+ parallel(5,v) */ *  FROM XXYH_PARALLEL_RBT_V v
