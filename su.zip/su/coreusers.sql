
SELECT distinct f.USER_NAME
FROM 
 applsys.fnd_logins c,applsys.fnd_user f
, applsys.fnd_login_resp_forms d, FND_USER_RESP_GROUPS x
WHERE 
 c.LOGIN_ID = d.LOGIN_ID
AND c.USER_ID = f.USER_ID 
and f.user_id = x.user_id
and f.PERSON_PARTY_ID >0
and x.RESPONSIBILITY_ID not in(52761,54202,54211)
and X.RESPONSIBILITY_ID in (select RESPONSIBILITY_ID from fnd_RESPONSIBILITY_tl where application_id=800)
and f.EMPLOYEE_ID is not null
and (f.END_DATE is NULL or  f.end_date >= sysdate)

/

