oradebug setospid &process_id 
oradebug unlimit
oradebug dump processstate 10
