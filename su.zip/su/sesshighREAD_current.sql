set serveroutput on
execute sys.top_reading_sessions.top(&interval);

