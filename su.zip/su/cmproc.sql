SELECT concurrent_queue_name manager,
concurrent_process_id pid,
process_status_code pscode,
fcq.node_name,
fcp.db_instance
from fnd_concurrent_queues fcq, fnd_concurrent_processes fcp
WHERE process_status_code NOT IN ('K','S') AND
fcq.concurrent_queue_id=fcp.concurrent_queue_id
AND fcq.application_id=fcp.queue_application_id
--AND concurrent_queue_name LIKE 'PO%'
/
