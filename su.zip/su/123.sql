select fcrs.request_id||';'||decode(fcrs.phase_code,'C','Completed',fcrs.phase_code)||';'||decode(fcrs.status_code,'E','Error',fcrs.status_code)||';'||fcrs.USER_CONCURRENT_PROGRAM_NAME||';'||fcrs.description 
from apps.fnd_conc_req_summary_v fcrs, xxyh.xxyh_critical_conc_monitor  xccm
where  fcrs.concurrent_program_id = xccm.concurrent_program_id
and fcrs.request_id='12360947'
union
select fcrs.request_id||';'||decode(fcrs.phase_code,'C','Completed',fcrs.phase_code)||';'||decode(fcrs.status_code,'E','Error',fcrs.status_code)||';'||fcrs.USER_CONCURRENT_PROGRAM_NAME||';'||fcrs.description
from apps.fnd_conc_req_summary_v fcrs
where  fcrs.requestor='YSMADMIN'
and fcrs.request_id='12360947'
union
select fcrs.request_id||';'||decode(fcrs.phase_code,'C','Completed',fcrs.phase_code)||';'||decode(fcrs.status_code,'E','Error',fcrs.status_code)||';'||fcrs.USER_CONCURRENT_PROGRAM_NAME||';'||fcrs.description
from apps.fnd_conc_req_summary_v fcrs, xxyh.xxyh_critical_conc_monitor  xccm
where  fcrs.concurrent_program_id = xccm.concurrent_program_id
and fcrs.request_id='12360947';


