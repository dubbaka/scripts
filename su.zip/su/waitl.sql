set lines 170
set pagesize 1000
column sid format 99999
column INST_ID format 99
column event format a25 word_wrapped
column module format a32 word_wrapped
column username format a9 word_wrapped
column seconds_in_wait format 999999 word_wrapped
col BLOCKER forma 99999
col osuser forma a10
select a.INST_ID INST, b.sid, b.event, PQ_STATUS, BLOCKING_SESSION Blocker, OSUSER,
substr(a.action,1,1)||'-'||substr(a.module,1,30) Module , a.username ,
      b.p1, b.p2,b.p3 ,b.seconds_in_wait wait_sec
--, to_char(logon_time, 'DD-MM-YY HH24:MI:SS') logon_time
from gv$session_wait b, gv$session a
where b.event not in ('SQL*Net message from client','rdbms ipc message',
'pmon timer','smon timer', 'pipe get','SQL*Net message to client', 'DIAG idle wait', 
'gcs remote message', 'ges remote message', 'Streams AQ: waiting for messages in the queue')
 and a.sid  = b.sid
 and a.module is not null and a.status='ACTIVE'
order by a.inst_id, b.seconds_in_wait
/
