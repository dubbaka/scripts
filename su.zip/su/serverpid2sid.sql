select sid from v$session where paddr in ( select addr from v$process where spid = &OS_server_process_id)
/
