set pagesize 1000; 
col tablespace_name format a12;
col file_name format a35;
col f_id  format 999;
select a.tablespace_name,b.file_name,b.file_id,a.bytes 
from dba_segments a , dba_data_files b
where segment_type='TEMPORARY'
and a.tablespace_name=b.tablespace_name
and b.file_id=a.header_file;

