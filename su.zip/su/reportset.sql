
SELECT * FROM FND_REQUEST_GROUPS
WHERE  request_group_id IN 
(  SELECT request_group_id  FROM FND_REQUEST_GROUP_UNITS WHERE request_unit_id IN 
	 ( SELECT concurrent_program_id FROM fnd_concurrent_programs_tl 
        WHERE upper(user_concurrent_program_name) LIKE upper('&full_report_name')))
/
