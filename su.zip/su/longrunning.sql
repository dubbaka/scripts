set echo on;
set feedback on;

select r.request_id,
       r.oracle_process_id,
       r.oracle_session_id,
       r.os_process_id,
       s.sid,
       s.serial#,
       s.paddr
  from fnd_concurrent_requests r,
       v$session s,
       v$process p
where s.paddr=p.addr
and p.spid=&unix_process_id
and r.oracle_session_id = s.audsid(+)
/
