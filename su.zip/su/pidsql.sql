break on hash_value
set pagesize 1000
set long 200000
select hash_value, sql_text
from v$sqltext
where hash_value =
        (select sql_hash_value from
                v$session where sid in (select sid from v$session where paddr
        = (select addr from v$process where spid = &syspid)))
order by piece
/
select sid from v$session where paddr
        = (select addr from v$process where spid = &syspid)
/

