
SELECT MRP_AP_REFRESH_S.NEXTVAL FROM DUAL;

--truncate table INV.MLOG$_MTL_MATERIAL_TRANSAC;

exec dbms_snapshot.refresh('INV.MTL_MTRX_TMP_SN','C');


