col module format a20
col osuser format a20
col machine format a30
set feedback off
set linesize 200
set pagesize 500
set echo off
set serveroutput off

#spool &1
prompt IMP!! . Please pay closer attention to event and seconds_in_wait value.
prompt These will be last 2 fields of every row in this output.
prompt If event=SQL*Net message from client and seconds_in_wait=7200 (lets assume),
prompt this means session has been doing NOTHING for past TWO hours (a no more than this is even more incriminating).
prompt Typically these sessions can be/should be cleaned up.
prompt The above criteria would better indicate 'dead/hung/inactive' sessions rather than STATUS column alone.
prompt Also, status would be invariably INACTIVE for these sessions.

SELECT s.SID,s.serial#,s.MODULE,s.MACHINE,s.osuser,P.SPID "Server Process ID",S.PROCESS "Client Process",TO_CHAR(s.LOGON_TIME,'DD-MON-YYYY HH24:MI:SS') "Login Time",s.Status,w.seconds_in_wait,w.event from gv$session s,gv$process p ,gv$session_wait w where p.addr = s.paddr and s.MODULE='Discoverer4' and s.logon_time <= sysdate-4/24 and s.sid=w.sid;
exit
