 SELECT sid, program, module FROM X$KGLLK LOCK_A , v$session a
 WHERE KGLLKREQ = 0
   AND EXISTS (SELECT LOCK_B.KGLLKHDL FROM X$KGLLK LOCK_B, v$session b
               WHERE KGLLKSES = b.saddr
               AND LOCK_A.KGLLKHDL = LOCK_B.KGLLKHDL
               AND KGLLKREQ > 0
			and b.sid = &sid)
	and a.saddr = lock_a.kgllkses
/
