SET ECHO OFF
REM   =========================================================================
REM   Copyright © 2005 Oracle Corporation Redwood Shores, California, USA
REM   Oracle Support Services.  All rights reserved.
REM   =========================================================================
REM
DEFINE          v_fileName = 'HRMS11i'
DEFINE        v_lastUpdate = '14-FEB-2012'
DEFINE          v_testDesc = 'Display HRMS 11i Details'
DEFINE    v_testNoteNumber = '418274.1'
DEFINE           v_product = 'Oracle HRMS'
DEFINE       v_legislation = 'All'
DEFINE          v_platform = 'Generic'
DEFINE v_validAppsVersions = '11.5'
DEFINE   v_inputParameters = 'None'
REM
REM   =========================================================================
REM   USAGE:   sqlplus apps/apps @HRMS11i
REM   =========================================================================
REM
REM   CHANGE HISTORY:
REM
REM    02-SEP-2005   jstyles    created
REM
REM    30-SEP-2006   jbressle   added HR_PF.K Rup1
REM
REM    05-MAR-2007   jbressle   added the following:
REM       added Salary Admin patches section 05-MAR-2007
REM       added AK   Common Modules patches 05-MAR-2007
REM       added ALR  Alerts patches 05-MAR-2007
REM       added ATG  patches 05-MAR-2007
REM       added CAC  Common Application Calendar patches 05-MAR-2007
REM       added EC   E-Commerce Gateway patches 05-MAR-2007
REM       added JTA  CRM Applications Foundation patches 05-MAR-2007
REM       added TXK  Techstack patches 05-MAR-2007
REM       added UMX  User Management patches 05-MAR-2007
REM       added XDO  XML Publisher patches 05-MAR-2007
REM
REM    06-MAR-2007   jbressle   added the following:
REM       added WHO Triggers for HR owned tables 06-MAR-2007
REM
REM    09-MAR-2007   jbressle   added the following:
REM       added People Management patches 09-MAR-2007
REM       added Multi Org flag 09-MAR-2007
REM
REM    20-MAR-2007   jbressle   added the following:
REM       added iRecruitment patches section 20-MAR-2007
REM       added AD   Application Object Library patches 20-MAR-2007
REM       added BNE  Application Desktop Integrator patches 20-MAR-2007
REM       added FIN  Financial Family Pack patches 20-MAR-2007
REM       added FND  Application Object Library patches 20-MAR-2007
REM       added HZ   Trading Community Architecture patches 20-MAR-2007
REM
REM    21-MAR-2007   jbressle   added the following:
REM       added Labor Distribution patches section 21-MAR-2007
REM
REM    03-APR-2007   jbressle   added the following:
REM       added Learning Management patches section 03-APR-2007
REM
REM    05-APR-2007   jbressle   added the following:
REM       added Talent Management patches section 05-APR-2007
REM
REM    12-JUN-2007   jbressle   added the following:
REM       added FRM  Report Manager patches 2-JUN-2007
REM       added 11i.ATG_PF.H RUP5 patch 5473858
REM
REM    03-AUG-2007   jbressle   added the following:
REM       added LD   11I.PSP.K.DELTA.2 patch 5917559 
REM
REM    08-AUG-2007   jbressle   added the following:
REM       added HR   11i released HRMS family packs section
REM
REM    10-AUG-2007   jbressle   added the following:
REM       added HXT  Oracle Time and Labor section
REM
REM    15-AUG-2007   jbressle   added the following:
REM       hardcoded spooled output file name as HRMS11i_output_file.txt 
REM       to accommodate appending !f60gen to this file 
REM       so as now to see the customer's FORMS VERSION in this output
REM       NOTE that reporting the customer's FORMS VERSION is now required 
REM       for new bugs
REM
REM    10-OCT-2007   jbressle  added the following:
REM       added AME  Approval Management Engine to OTHER current patching levels section
REM
REM
REM    21-DEC-2007   jbressle  added the following:
REM       added patch 6652016 SALARY ADMIN: FAMILY PACK K RUP1 - SUPPLEMENTAL PATCH III
REM
REM
REM    15-JUL-2008   jbressle  added the following:
REM       added 11.HR_PF.K RUP3   patch 6699770
REM       added 11i.ATG_PF.H.RUP6 patch 5903765  
REM       added Language Details section showing Installed Languages
REM       added GEOCODE section for Address Validation
REM       added Instance Creation Date following Instance Name
REM       changed output file naming convention to 
REM           HRMS12_<SID>_<SYSDATE>.txt
REM
REM
REM    06-OCT-2008  jbressle  added 11i.OTA.J.RUP2 patch 5550150
REM
REM    09-OCT-2008  jbressle  added ANNUAL GEOCODE/JIT UPDATE-2008 patch 7328291
REM
REM    14-NOV-2008  jbressle  added 11i.OTA.J.RUP3 patch 7446888
REM
REM    07-JAN-2009  jbressle  changed code OTL Oracle Time and Labor hxt for ORDER BY
REM
REM    20-APR-2009  jbressle  added 11i.HR_PF.K RUP4 patch 7666111 target release date of JULY 10, 2009
REM                           added OVN OBJECT_VERSION_NUMBER to HRMS11i output
REM                           added OVN triggers to HRMS11i output
REM                           added WHO triggers to HRMS11i output
REM
REM    15-JUN-2009  jbressle  added Pay Action Parameter detail section
REM
REM    17-JUN-2009  jbressle  added Business Group Details section just before Language Details section
REM
REM    29-JUN-2009  jbressle  added Business Group and sub-Organization Classification Details
REM                           added v$parameter section at end of report
REM
REM    25-JUL-2009  jbressle  added Employee Numbering Details section covering the following:
REM                                 Global Numbering Profile details 
REM                                 Business Group Info. Org Developer DF details 
REM                                 NEXT_VALUE ordered by BUSINESS_GROUP_ID details 
REM                           added 11i.ATG_PF.H.RUP7 patch 6241631
REM    
REM    28-SEP-2009  jbressle  added all OLM/OTA patching 
REM
REM    30-OCT-2009  jbressle  added 2009 GEOCODE for 11i
REM 
REM 
REM    09-FEB-2010  jbressle  added PROFILE settings section
REM                           added Legislation to Business Group Info. under Employee Numbering section
REM                           added Public Sector Budgeting to Application Install Status section
REM 
REM    02-MAR-2010  jbressle  added Oracle General Ledger & Oracle Payroll to Application Install Status section
REM                           added Profile 'DateTrack:Enabled' 
REM
REM    18-APR-2010  jbressle  added totals for Invalid Objects 
REM                           added HR_PF.K RUP5 patch 9062727 
REM
REM    06-MAY-2010  jbressle  added Spatial Indexes and indexes related to Spatial Index issues section
REM
REM    13-MAY-2010  jbressle  added iRec patches 
REM                           11i.IRC.E.delta.2  patch 6208000
REM                           11i.IRC.E.delta.3  patch 6964709
REM                           11i.IRC.E.delta.4  patch 8208171
REM                           11i.IRC.E.delta.5  patch 9213928
REM
REM    08-JUL-2010  jbressle  removed DateTrack query for 804 SSP
REM
REM    28-AUG-2010  jbressle  added ANNUAL GEOCODE UPDATE - 2010  patch 9879070
REM
REM    08-MAY-2011  jbressle  added 11i.HR_PF.K.delta.6 patch 10015566
REM
REM    16-AUG-2011  jbressle  added Geocode Upgrade Manager process section after GEOCODE patches section
REM                           added GEOCODE ANNUAL 2011 patch 12729894
REM                           fixed call for 11i.HR_PF.K.delta.6 patch 10015566
REM
REM    14-FEB-2012  jbressle  added HR SECURITY PROFILE settings section 
REM                           HR: Security Profile
REM                           HR: Include Terminated People in Search
REM                           HR: Access Non-Current Employee Data
REM                           list defined HR Security profiles
REM
REM    14-FEB-2012  jbressle  hrglobal.drv details section changes
REM
REM    14-FEB-2012  jbressle  under Employee Numbering Details section added profiles 
REM                           HR:Use Global Applicant Numbering
REM                           HR:Use Global Contingent Worker Numbering
REM                           HR:Use Global Employee Numbering
REM
REM
REM
REM
REM
REM
REM




REM
REM   =========================================================================

REM   =========================================================================
REM   Set SQL PLUS Environment Variables
REM   =========================================================================

      SET FEEDBACK OFF
      SET HEADING ON
      SET LINESIZE 100
      SET LONG 2000000000
      SET LONGCHUNKSIZE 32767
      SET PAGESIZE 50
      SET SERVEROUTPUT ON SIZE 1000000 FORMAT WRAP
      SET TERMOUT ON
      SET TIMING OFF
      SET TRIMOUT ON
      SET TRIMSPOOL ON
      SET VERIFY OFF

      ALTER SESSION SET NLS_DATE_FORMAT = 'DD-Mon-YYYY';      
    
REM   =========================================================================
REM   Define SQL Variables
REM   =========================================================================

      COLUMN userName new_value v_userName noprint
      select user userName from dual;

      COLUMN testDate new_value v_testDate noprint
      select substr('&v_testDesc',INSTR('&v_testDesc','(',1,1)+1,11) testDate from dual;
                 
      COLUMN sqlplusVersion new_value v_sqlplusVersion noprint
      SELECT NVL('&_SQLPLUS_RELEASE','Unknown') sqlplusVersion from dual;
      
      COLUMN server NEW_VALUE v_server NOPRINT
      SELECT HOST_NAME server FROM V$INSTANCE;
      
      COLUMN platform NEW_VALUE v_platform NOPRINT
      SELECT SUBSTR( REPLACE( REPLACE( pcv1.product,'TNS for '),':' )||pcv2.status,1,40 ) platform
      FROM product_component_version pcv1, product_component_version pcv2
      WHERE UPPER( pcv1.product ) LIKE '%TNS%' AND UPPER( pcv2.product ) LIKE '%ORACLE%' AND ROWNUM = 1;
      

      COLUMN ssdt NEW_VALUE v_ssdt NOPRINT
      SELECT SYSDATE ssdt FROM DUAL;

      COLUMN sid NEW_VALUE v_sid NOPRINT
      SELECT NAME sid FROM V$DATABASE;

      COLUMN crtddt NEW_VALUE v_crtddt NOPRINT
      SELECT CREATED crtddt FROM V$DATABASE;
      
      COLUMN dbVersion NEW_VALUE v_dbVer NOPRINT
      SELECT BANNER dbVersion FROM V$VERSION WHERE ROWNUM = 1;
      
      COLUMN dbComp NEW_VALUE v_dbComp NOPRINT      
      SELECT 'compatible = ' || p.value dbComp FROM v$parameter p WHERE p.name = 'compatible';
      
      COLUMN dbLang NEW_VALUE v_lang NOPRINT
      SELECT VALUE dbLang FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_LANGUAGE';
      
      COLUMN dbCharSet NEW_VALUE v_char NOPRINT
      SELECT VALUE dbCharSet FROM V$NLS_PARAMETERS WHERE parameter = 'NLS_CHARACTERSET';
      
      COLUMN appVer NEW_VALUE v_appVer NOPRINT
      SELECT RELEASE_NAME appVer FROM FND_PRODUCT_GROUPS;
       


REM   =========================================================================
REM   11i HRMS family packs
REM   =========================================================================

      COLUMN PFbugDate NEW_VALUE v_PFbugDate NOPRINT                    
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '2803988', 'HRMS_PF.E'
             , '2968701', 'HRMS_PF.F'
             , '3116666', 'HRMS_PF.G'
             , '3233333', 'HRMS_PF.H'
             , '3127777', 'HRMS_PF.I'
             , '3333633', 'HRMS_PF.J'
             , '3500000', 'HRMS_PF.K'
             , '5055050', 'HR_PF.K.RUP.1'
             , '5337777', 'HR_PF.K.RUP.2'
             , '6699770', 'HR_PF.K.RUP.3'
             , '7666111', 'HR_PF.K.RUP.4'
             , '9062727', 'HR_PF.K.RUP.5'
             , '10015566', 'HR_PF.K.RUP.6'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDate
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('2803988','2968701','3116666','3233333','3127777','3333633',
           '3500000','5055050','5337777','6699770','7666111','9062727','10015566')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;







      COLUMN PFbugDateE NEW_VALUE v_PFbugDateE NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '2803988', 'HRMS_PF.E'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateE
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('2803988')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;




      COLUMN PFbugDateF NEW_VALUE v_PFbugDateF NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '2968701', 'HRMS_PF.F'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateF
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('2968701')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;




      COLUMN PFbugDateG NEW_VALUE v_PFbugDateG NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3116666', 'HRMS_PF.G'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateG
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('3116666')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateH NEW_VALUE v_PFbugDateH NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3233333', 'HRMS_PF.H'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateH
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('3233333')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateI NEW_VALUE v_PFbugDateI NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3127777', 'HRMS_PF.I'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateI
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('3127777')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateJ NEW_VALUE v_PFbugDateJ NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3333633', 'HRMS_PF.J'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateJ
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('3333633')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateK NEW_VALUE v_PFbugDateK NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3500000', 'HRMS_PF.K'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateK
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('3500000')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateK1 NEW_VALUE v_PFbugDateK1 NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5055050', 'HR_PF.K.RUP.1'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateK1
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('5055050')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateK2 NEW_VALUE v_PFbugDateK2 NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5337777', 'HR_PF.K.RUP.2'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateK2
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('5337777')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateK3 NEW_VALUE v_PFbugDateK3 NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '6699770', 'HR_PF.K.RUP.3'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateK3
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('6699770')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateK4 NEW_VALUE v_PFbugDateK4 NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '7666111', 'HR_PF.K.RUP.4'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateK4
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('7666111')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateK5 NEW_VALUE v_PFbugDateK5 NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '9062727', 'HR_PF.K.RUP.5'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateK5
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('9062727')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;





      COLUMN PFbugDateK6 NEW_VALUE v_PFbugDateK6 NOPRINT 
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '10015566', 'HR_PF.K.RUP.6'
              )  
          || ' applied ' || LAST_UPDATE_DATE || ' '   PFbugDateK6
      FROM ad_bugs 
      WHERE BUG_NUMBER IN 
          ('10015566')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1;









REM   =========================================================================
REM   11i GEOCODE patches
REM   =========================================================================

      COLUMN GeocodeDate NEW_VALUE v_GeocodeDate NOPRINT                    
      SELECT * FROM (
      SELECT 'patch ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3944263', 'GEOCODE_ANNUAL_2004'
             , '4140070', 'GEOCODE_ANNUAL_2004.1'
             , '4225044', 'GEOCODE_ANNUAL_2005'
             , '5253339', 'GEOCODE_ANNUAL_2006'
             , '6117000', 'GEOCODE_ANNUAL_2007'
             , '7328291', 'GEOCODE_ANNUAL_2008'
             , '8977290', 'GEOCODE_ANNUAL_2009'
             , '9879070', 'GEOCODE_ANNUAL_2010')  
          || ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('3944263','4140070','4225044','5253339','6117000','7328291','8977290','9879070')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 



REM   =========================================================================
REM   All Geocodes Patches Installed 
REM   =========================================================================



      COLUMN GeocodeDate2011 NEW_VALUE v_GeocodeDate2011 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate2011
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('12729894')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 




      COLUMN GeocodeDate2010 NEW_VALUE v_GeocodeDate2010 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate2010
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('9879070')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 



      COLUMN GeocodeDate2009 NEW_VALUE v_GeocodeDate2009 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate2009
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('8977290')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 



      COLUMN GeocodeDate2008 NEW_VALUE v_GeocodeDate2008 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate2008
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('7328291')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 


      COLUMN GeocodeDate2007 NEW_VALUE v_GeocodeDate2007 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate2007
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('6117000')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 


      COLUMN GeocodeDate2006 NEW_VALUE v_GeocodeDate2006 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate2006
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('5253339')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 


      COLUMN GeocodeDate2005 NEW_VALUE v_GeocodeDate2005 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate2005
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('4225044')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 


      COLUMN GeocodeDate20041 NEW_VALUE v_GeocodeDate20041 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate20041
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('4140070')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 


      COLUMN GeocodeDate2004 NEW_VALUE v_GeocodeDate2004 NOPRINT                    
      SELECT * FROM (
      SELECT ' applied ' || LAST_UPDATE_DATE || ' '   GeocodeDate2004
      FROM ad_bugs 
      WHERE BUG_NUMBER IN   
          ('3944263')
      ORDER BY BUG_NUMBER desc
      ) WHERE ROWNUM = 1; 




REM   =========================================================================
REM   11i PER and PAY installed
REM   =========================================================================

      COLUMN HRStatus NEW_VALUE v_HRStatus NOPRINT
      SELECT L.MEANING  HRStatus
      FROM FND_APPLICATION_ALL_VIEW V, FND_PRODUCT_INSTALLATIONS I, FND_LOOKUPS L
      WHERE (V.APPLICATION_ID = I.APPLICATION_ID)
        AND (V.APPLICATION_ID = '800')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status);
        
      COLUMN PayStatus NEW_VALUE v_PayStatus NOPRINT
      SELECT L.MEANING  PayStatus
      FROM FND_APPLICATION_ALL_VIEW V, FND_PRODUCT_INSTALLATIONS I, FND_LOOKUPS L
      WHERE (V.APPLICATION_ID = I.APPLICATION_ID)
        AND (V.APPLICATION_ID = '801')
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status);       
        


REM   =========================================================================
REM   11i SSHR version
REM   =========================================================================

      COLUMN sshrVer NEW_VALUE v_sshrVersion NOPRINT
      SELECT decode(max(to_number(bug_number)),'2111325','SSHR 4.0','2214602','SSHR 4.0.1','2502761','SSHR 4.0.1'
      ,'2422334','SSHR 4.1','2499141','SSHR 4.1.1','2518941','SSHR 4.2','2633632','SSHR 4.2.1','2632500','SSHR 4.2.2','2803988','SSHR 4.2.2'
      ,'2968701','SSHR 5.0','3102567','SSHR 5.1','3116666','SSHR 5.1','3279989','SSHR 5.2'
      ,'Unknown') sshrVer
      FROM ad_bugs 
      WHERE bug_number in ('2111325','2214602','2502761','2422334','2499141','2518941','2633632','2632500','2803988','2968701','3102567','3116666','3279989');



REM   =========================================================================
REM   11i Workflow WF version
REM   =========================================================================

      COLUMN wfVer NEW_VALUE v_wfVersion NOPRINT
      SELECT 'WorkFlow' || ' ' || TEXT wfVer
      FROM WF_RESOURCES
      WHERE TYPE = 'WFTKN' 
        AND NAME = 'WF_VERSION'
        AND LANGUAGE = 'US';



REM   =========================================================================
REM   11i OA Framework version
REM   =========================================================================

      COLUMN OAFwkVer NEW_VALUE v_OAFwkVersion NOPRINT 
      SELECT decode(max(to_number(bug_number)),'2085104','OA Framework 5.5.2C','2227335','OA Framework 5.5.2E','2278688','OA Framework 5.6.0E'
      ,'2771817','OA Framework 5.7.0H','3262919','OA Framework 11.5.10','Unknown') OAFwkVer
      FROM ad_bugs 
      WHERE bug_number in ('2085104','2227335','2278688','2771817','3061106','3262919');



REM   =========================================================================
REM   11i Salary Admin patches I and II and III
REM   =========================================================================

      COLUMN SALadminDate NEW_VALUE v_SALadminDate NOPRINT                    
      SELECT * FROM (
             SELECT  ' ' || 'patch' || ' ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5362278', 'HR_PF.K-Rup1-SupAdmin-I')
             || ' applied ' || LAST_UPDATE_DATE || ' ' SALadminDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('5362278')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



      COLUMN SALadminDate NEW_VALUE v_SALadminDate2 NOPRINT                    
      SELECT * FROM (
             SELECT  ' ' || 'patch' || ' ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5748054', 'HR_PF.K-Rup1-SupAdmin-IIB'
             , '5664700', 'HR_PF.K-Rup1-SupAdmin-II')
             || ' applied ' || LAST_UPDATE_DATE || ' ' SALadminDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('5748054','5664700')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



      COLUMN SALadminDate NEW_VALUE v_SALadminDate3 NOPRINT                    
      SELECT * FROM (
             SELECT  ' ' || 'patch' || ' ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '6652016', 'HR_PF.K-Rup1-SupAdmin-III')
             || ' applied ' || LAST_UPDATE_DATE || ' ' SALadminDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('6652016')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;





REM   =========================================================================
REM   11i ATG patching for Salary Admin patches I and II
REM   =========================================================================

      COLUMN ATGbugDate NEW_VALUE v_ATGbugDate NOPRINT                    
      SELECT * FROM (
             SELECT 'ATG patch level       : ' || ' ' || 'patch' || ' ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3438354', '11i.ATG_PF.H'
             , '4017300', '11i.ATG_PF.H RUP1'
             , '4125550', '11i.ATG_PF.H RUP2'
             , '4334965', '11i.ATG_PF.H RUP3'
             , '4676589', '11i.ATG_PF.H RUP4'
             , '5473858', '11i.ATG_PF.H RUP5'
             , '5903765', '11i.ATG_PF.H RUP6'
             , '6241631', '11i.ATG_PF.H RUP7') 
             || ' applied ' || LAST_UPDATE_DATE || ' 'ATGbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
         ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631')
         ORDER BY BUG_NUMBER desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i iRec patching
REM   =========================================================================

      COLUMN IRCbugDate NEW_VALUE v_IRCbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'iRecruitment patch: ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '2385730', '11i.IRC.A'
             , '2982658', '11i.IRC.B'
             , '3197168', '11i.IRC.C'
             , '3469985', '11i.IRC.D'
             , '4428071', '11i.IRC.E'
             , '5061111', '11i.IRC.E.RUP1'
             , '5578701', '11i.IRC.E.RUP1.FIXUP'
             , '6208000', '11i.IRC.E.RUP2'
             , '6964709', '11i.IRC.E.RUP3'
             , '8208171', '11i.IRC.E.RUP4'
             , '9213928', '11i.IRC.E.RUP5')
             || ' applied ' || LAST_UPDATE_DATE || ' ' IRCbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('2385730','2982658','3197168','3469985','4428071','5061111','5578701',
              '6208000','6964709','8208171','9213928')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i OTL Oracle Time and Labor hxt patching
REM   =========================================================================


      COLUMN HXTbugDate NEW_VALUE v_HXTbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Time and Labor patch: ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1343155', '11i.HXT.A'
             , '1483168', '11i.HXT.B'
             , '1663255', '11i.HXT.C'
             , '2398780', '11i.HXT.D'
             , '2716711', '11i.HXT.E'
             , '3042947', '11i.HXT.F'
             , '3285055', '11i.HXT.G'
             , '3530830', '11i.HXT.H'
             , '4188854', '11i.HXT.I'
             , '4428056', '11i.HXT.J'
             , '4544879', '11i.HXT.J Rollup 1'
             , '5066320', '11i.HXT.J Rollup 2'
             , '9214252', '11i.HXT.J.rup.1'
             , '9214257', '11i.HXT.J.rup.2'
             , '9214258', '11i.HXT.J.rup.3'
             , '9214263', '11i.HXT.J.rup.4'
             , '9213930', '11i.HXT.J.rup.5')
             || ' applied ' || LAST_UPDATE_DATE || ' ' HXTbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1343155','1483168','1663255','2398780','2716711','3042947',
              '3285055','3530830','4188854','4428056','4544879','5066320',
              '9214252','9214257','9214258','9214263','9213930') 
      ORDER BY BUG_NUMBER desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Learning Management patching
REM   =========================================================================

REM COLUMN OLMbugDate NEW_VALUE v_OLMbugDate NOPRINT    
REM      SELECT * FROM (
REM             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
REM             DECODE(BUG_NUMBER
REM             , '1344139', '11i.OTA.A'
REM             , '1483058', '11i.OTA.B'
REM             , '1566806', '11i.OTA.C'
REM             , '1663230', '11i.OTA.D'
REM             , '2004082', '11i.OTA.E'
REM             , '2296468', '11i.OTA.F'
REM             , '2489786', '11i.OTA.G'
REM             , '2897819', '11i.OTA.H'
REM             , '3291795', '11i.OTA.I'
REM             , '4428068', '11i.OTA.J'
REM             , '5086157', '11i.OTA.J.RUP1'
REM             , '5592160', '11i.OTA.J.RUP1.D1'
--             , '5883989', '11i.OTA.J.RUP1.D2'
--             , '5550150', '11i.OTA.J.RUP2'
--             , '7446888', '11i.OTA.J.RUP3')
--             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
--         FROM ad_bugs 
--         WHERE BUG_NUMBER IN 
--             ('1344139','1483058','1566806','1663230','2004082','2296468',
--              '2489786','2897819','3291795','4428068','5086157','5592160',
--              '5883989','5550150','7446888')
--         ORDER BY LAST_UPDATE_DATE desc ) 
--      WHERE ROWNUM = 1;




COLUMN OLMbugDate NEW_VALUE v_OLMbugDate10 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '9213927', '11i.OTA.J.RUP5')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('9213927')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate9 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '8207995', '11i.OTA.J.RUP4')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('8207995')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate8 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '7446888', '11i.OTA.J.RUP3')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('7446888')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate7 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5550150', '11i.OTA.J.RUP2')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('5550150')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate6 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5883989', '11i.OTA.J.RUP1.D2')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('5883989')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate5 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5592160', '11i.OTA.J.RUP1.D1')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('5592160')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate4 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5086157', '11i.OTA.J.RUP1')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('5086157')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate3 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '4428068', '11i.OTA.J')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('4428068')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate2 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3291795', '11i.OTA.I')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('3291795')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;



COLUMN OLMbugDate NEW_VALUE v_OLMbugDate1 NOPRINT    
      SELECT * FROM (
             SELECT 'Learning Management:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '2897819', '11i.OTA.H')
             || ' applied ' || LAST_UPDATE_DATE || ' ' OLMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('2897819')
      ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;





REM   =========================================================================
REM   11i Labor Distribution psp patching
REM   =========================================================================

      COLUMN LDbugDate NEW_VALUE v_LDbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Labor Distribution patch: ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '4289880', '11i.PSP.K'
             , '5059556', '11i.PSP.K.RUP1'
             , '5917559', '11i.PSP.K.RUP2'
             , '6964762', '11i.PSP.K.RUP3'
             , '8207934', '11i.PSP.K.RUP4'
             , '9213918', '11i.PSP.K.RUP5')
             || ' applied ' || LAST_UPDATE_DATE || ' ' LDbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('4289880','5059556','5917559','6964762','8207934','9213918')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;






REM   =========================================================================
REM   11i People Management patching
REM   =========================================================================

      COLUMN PeopleMgmt NEW_VALUE v_PeopleMgmt NOPRINT
      SELECT * FROM (
             SELECT 'People Management:  ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3474680', 'Rollup patch MAR 2004'
             , '3500547', 'Rollup patch APR 2004'
             , '3599108', 'Rollup patch APR 2004'
             , '3580285', 'Rollup patch JUN 2004'
             , '3744976', 'Rollup patch AUG 2004'
             , '3891993', 'Rollup patch AUG 2004'
             , '3882557', 'Rollup patch OCT 2004'
             , '4043520', 'Rollup patch JAN 2005'
             , '4169732', 'Rollup patch JUN 2005'
             , '4601271', 'Rollup patch OCT 2005'
             , '4767339', 'Rollup patch DEC 2005'
             , '4889122', 'Rollup patch FEB 2006'
             , '5045004', 'Rollup patch JUN 2006'
             , '5337426', 'Rollup patch AUG 2006')
             || ' applied ' || LAST_UPDATE_DATE || ' ' PeopleMgmt
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('3474680','3500547','3599108','3580285','3744976',
              '3891993','3882557','4043520','4169732','4601271',
              '4767339','4889122','5045004','5337426')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Talent Management patching
REM   =========================================================================

      COLUMN TMadminDate NEW_VALUE v_TMadminDate NOPRINT                    
      SELECT * FROM (
             SELECT 'Talent Management:  ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '5310532', 'TM.FPKRUP1-Rollup-1'
             , '5534451', 'TM.FPKRUP1-Rollup-2'
             , '5666931', 'TM.FPKRUP1-Rollup-3'
             , '5841128', 'TM.FPKRUP1-Rollup-4')
             || ' applied ' || LAST_UPDATE_DATE || ' ' TMadminDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('5310532','5534451','5666931','5841128')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i MultiOrg flag
REM   =========================================================================

      COLUMN MultiORGflag NEW_VALUE v_MultiORGflag NOPRINT                    
      SELECT * FROM (
             SELECT 'Multi Org flag = ' || ' ' || MULTI_ORG_FLAG || '  - ' ||
             ' flag set ' || LAST_UPDATE_DATE || ' ' MultiORGflag
             FROM FND_PRODUCT_GROUPS)
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Techstack txk patching
REM   =========================================================================

      COLUMN TXKbugDate NEW_VALUE v_TXKbugDate NOPRINT                    
      SELECT * FROM (
             SELECT 'Techstack patch:                   ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '2668469', '11i.TXK.A'
             , '3219567', '11i.TXK.B'
             , '4018905', '11i.TXK.C') 
             || ' applied ' || LAST_UPDATE_DATE || ' ' TXKbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('2668469','3219567','4018905')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Alert alr patches
REM   =========================================================================

      COLUMN ALRbugDate NEW_VALUE v_ALRbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Alerts patch:                      ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1348277', '11i.ALR.A'
             , '1459186', '11i.ALR.B'
             , '1575525', '11i.ALR.C'
             , '1931404', '11i.ALR.D'
             , '2404398', '11i.ALR.E'
             , '2464368', '11i.ALR.F' 
             , '3261254', '11i.ALR.G')
             || ' applied ' || LAST_UPDATE_DATE || ' ' ALRbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1348277','1459186','1575525','1931404','2404398','2464368','3261254')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i XML Published xdo patches
REM   =========================================================================

      COLUMN XDObugDate NEW_VALUE v_XDObugDate NOPRINT                    
      SELECT * FROM (
             SELECT 'XML Publisher patch:               ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3263588', '11i.XDO.H') 
             || ' applied ' || LAST_UPDATE_DATE || ' ' XDObugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('3263588')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i User Management umx patches
REM   =========================================================================

      COLUMN UMXbugDate NEW_VALUE v_UMXbugDate NOPRINT                    
      SELECT * FROM (
             SELECT 'User Management patch:             ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3264818', '11i.UMX.H') 
             || ' applied ' || LAST_UPDATE_DATE || ' ' UMXbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('3264818')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Common Modules ak patches
REM   =========================================================================

      COLUMN AKbugDate NEW_VALUE v_AKbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'AK Common Modules patch:           ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1343449', '11i.AK.A'
             , '1455027', '11i.AK.B'
             , '1553747', '11i.AK.C'
             , '1931844', '11i.AK.D'
             , '2404795', '11i.AK.E'
             , '2657511', '11i.AK.F' 
             , '3263645', '11i.AK.G')
             || ' applied ' || LAST_UPDATE_DATE || ' ' AKbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1343449','1455027','1553747','1931844','2404795','2657511','3263645')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i ATG patching - for ATG2
REM   =========================================================================

      COLUMN ATG2bugDate NEW_VALUE v_ATG2bugDate NOPRINT                    
      SELECT * FROM (
             SELECT 'Applications Technology patch:     ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3438354', '11i.ATG_PF.H'
             , '4017300', '11i.ATG_PF.H RUP1'
             , '4125550', '11i.ATG_PF.H RUP2'
             , '4334965', '11i.ATG_PF.H RUP3'
             , '4676589', '11i.ATG_PF.H RUP4'
             , '5473858', '11i.ATG_PF.H RUP5'
             , '5903765', '11i.ATG_PF.H RUP6'
             , '6241631', '11i.ATG_PF.H RUP7') 
             || ' applied ' || LAST_UPDATE_DATE || ' 'ATG2bugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
         ('3438354','4017300','4125550','4334965','4676589','5473858','5903765','6241631')
         ORDER BY BUG_NUMBER desc ) 
      WHERE ROWNUM = 1;



REM   =========================================================================
REM   11i Common Application Calendar cac patching
REM   =========================================================================

      COLUMN CACbugDate NEW_VALUE v_CACbugDate NOPRINT                    
      SELECT * FROM (
             SELECT 'Common Application Calendar patch: ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3234006', '11i.CAC.A'
             , '3264822', '11i.CAC.B'
             , '3995315', '11i.CAC.C'
             , '4444880', '11i.CAC.C Rollup 1') 
             || ' applied ' || LAST_UPDATE_DATE || ' ' CACbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('3234006','3264822','3995315','4444880')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i CRM applications Foundation jta
REM   =========================================================================

      COLUMN JTAbugDate NEW_VALUE v_JTAbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'CRM Applications Foundation patch: ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1830830', '11i.JTA.A'
             , '2065484', '11i.JTA.B'
             , '2154180', '11i.JTA.C'
             , '2368042', '11i.JTA.D'
             , '2640247', '11i.JTA.E'
             , '3262486', '11i.JTA.F') 
             || ' applied ' || LAST_UPDATE_DATE || ' ' JTAbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1830830','2065484','2154180','2368042','2640247','3262486')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i E-Commerce Gateway ec patches
REM   =========================================================================

      COLUMN ECbugDate NEW_VALUE v_ECbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'E-Commerce Gateway patch:          ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1288209', '11i.EC.A'
             , '1352783', '11i.EC.B'
             , '1553933', '11i.EC.C'
             , '1931904', '11i.EC.D'
             , '2408170', '11i.EC.E'
             , '2662787', '11i.EC.F' 
             , '3261243', '11i.EC.G')
             || ' applied ' || LAST_UPDATE_DATE || ' ' ECbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1288209','1352783','1553933','1931904','2408170','2662787','3261243')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Application Object Library fnd patches
REM   =========================================================================

      COLUMN FNDbugDate NEW_VALUE v_FNDbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Application Object Library patch:  ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1344802', '11i.FND.A'
             , '1454466', '11i.FND.B'
             , '1553256', '11i.FND.C'
             , '1932070', '11i.FND.D'
             , '2154367', '11i.FND.E'
             , '2404698', '11i.FND.F' 
             , '2655277', '11i.FND.G'
             , '3262159', '11i.FND.H')
             || ' applied ' || LAST_UPDATE_DATE || ' ' FNDbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1344802','1454466','1553256','1932070','2154367','2404698','2655277','3262159')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Applications DBA ad patches
REM   =========================================================================

      COLUMN ADbugDate NEW_VALUE v_ADbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Application Object Library patch:  ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1344802', '11i.AD.A'
             , '1454466', '11i.AD.B'
             , '1553256', '11i.AD.C'
             , '1932070', '11i.AD.D'
             , '2154367', '11i.AD.E'
             , '2404698', '11i.AD.F' 
             , '2655277', '11i.AD.G'
             , '3262159', '11i.AD.H'
             , '2655277', '11i.AD.I'
             , '3262159', '11i.AD.I.1'
             , '4337683', '11i.AD.I.2' 
             , '4229931', '11i.AD.I.delta.2'
             , '4712847', '11i.AD.I.3'
             , '4502904', '11i.AD.I.delta.3'
             , '4712852', '11i.AD.I.4'
             , '4605654', '11i.AD.I.delta.4'
             , '5161676', '11i.AD.I.5'
             , '6502082', '11i.AD.I.6'
             , '7429248', '11i.AD.I.7')
             || ' applied ' || LAST_UPDATE_DATE || ' ' ADbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1351004','1460640','1475426','1627493','1945611',
              '2141471','2344175','2673262','3180816','4038964',
              '4337683','4229931','4712847','4502904','4712852',
              '4605654','5161676','6502082','7429248')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Report Manager frm patches
REM   =========================================================================

      COLUMN FRMbugDate NEW_VALUE v_FRMbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Report Manager patch:              ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1338967', '11i.FRM.A'
             , '1512530', '11i.FRM.B'
             , '1931773', '11i.FRM.C'
             , '2450020', '11i.FRM.D'
             , '2677848', '11i.FRM.E'
             , '2682790', '11i.FRM.F'
             , '3761838', '11i.FRM.G'
             , '4206794', '11i.FRM.H')
             || ' applied ' || LAST_UPDATE_DATE || ' ' FRMbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1338967','1512530','1931773','2450020','2677848',
              '2682790','3761838','4206794')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Trading Community Architecture hz patches
REM   =========================================================================

      COLUMN HZbugDate NEW_VALUE v_HZbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Trading Community patch:           ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1581138', '11i.HZ.A'
             , '1586130', '11i.HZ.B'
             , '1697181', '11i.HZ.C'
             , '1808048', '11i.HZ.D'
             , '1886227', '11i.HZ.E'
             , '1921951', '11i.HZ.F' 
             , '2111967', '11i.HZ.G'
             , '2116159', '11i.HZ.H'
             , '2239222', '11i.HZ.I'
             , '2488745', '11i.HZ.J'
             , '2790616', '11i.HZ.K' 
             , '3036401', '11i.HZ.L'
             , '3151672', '11i.HZ.M'
             , '3618299', '11i.HZ.N')
             || ' applied ' || LAST_UPDATE_DATE || ' ' HZbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1581138','1586130','1697181','1808048','1886227',
              '1921951','2111967','2116159','2239222','2488745',
              '2790616','3036401','3151672','3618299')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Financials fin_pf patches
REM   =========================================================================

      COLUMN FINbugDate NEW_VALUE v_FINbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Financials patch:                  ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '1807809', '11i.FIN_PF.A'
             , '2218339', '11i.FIN_PF.B'
             , '2380068', '11i.FIN_PF.C'
             , '3016445', '11i.FIN_PF.D.1'
             , '2842697', '11i.FIN_PF.E'
             , '3153675', '11i.FIN_PF.F' 
             , '3653484', '11i.FIN_PF.G')
             || ' applied ' || LAST_UPDATE_DATE || ' ' FINbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('1807809','2218339','2380068','3016445','2842697','3153675','3653484')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Web Applications Desktop Integrator bne patches
REM   =========================================================================

      COLUMN ADIbugDate NEW_VALUE v_ADIbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Web Application Desktop Integrator:' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '2443697', '11i.BNE.A'
             , '2677750', '11i.BNE.B'
             , '2819091', '11i.BNE.C'
             , '3218526', '11i.BNE.D')
             || ' applied ' || LAST_UPDATE_DATE || ' ' ADIbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('2443697','2677750','2819091','3218526')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i iRec patching - IRC2
REM   =========================================================================

      COLUMN IRC2bugDate NEW_VALUE v_IRC2bugDate NOPRINT    
      SELECT * FROM (
             SELECT 'iRecruitment patch:                ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '2385730', '11i.IRC.A'
             , '2982658', '11i.IRC.B'
             , '3197168', '11i.IRC.C'
             , '3469985', '11i.IRC.D'
             , '4428071', '11i.IRC.E'
             , '5061111', '11i.IRC.E.RUP1'
             , '5578701', '11i.IRC.E.RUP1.FIXUP'
             , '6208000', '11i.IRC.E.RUP2'
             , '6964709', '11i.IRC.E.RUP3'
             , '8208171', '11i.IRC.E.RUP4'
             , '9213928', '11i.IRC.E.RUP5')
             || ' applied ' || LAST_UPDATE_DATE || ' ' IRC2bugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('2385730','2982658','3197168','3469985','4428071','5061111','5578701',
              '6208000','6964709','8208171','9213928')
         ORDER BY LAST_UPDATE_DATE desc ) 
      WHERE ROWNUM = 1;




REM   =========================================================================
REM   11i Approval Management Engine ame patches
REM   =========================================================================


      COLUMN AMEbugDate NEW_VALUE v_AMEbugDate NOPRINT    
      SELECT * FROM (
             SELECT 'Approval Management Engine:        ' || '  ' || bug_number || ' ' ||
             DECODE(BUG_NUMBER
             , '3962268', '11i.AME.A'
             , '4433707', '11i.AME.A.RUP1'
             , '4428060', '11i.AME.B'
             , '4873179', '11i.AME.B.RUP1'
             , '5708576', '11i.AME.B.RUP2')
             || ' applied ' || LAST_UPDATE_DATE || ' ' AMEbugDate
         FROM ad_bugs 
         WHERE BUG_NUMBER IN 
             ('3962268','4433707','4428060','4873179','5708576')
         ORDER BY BUG_NUMBER desc ) 
      WHERE ROWNUM = 1;





REM   =========================================================================
REM   START SPOOLING old way
REM   =========================================================================


REM      COLUMN fileExt new_value v_fileExtension noprint

      select decode(substr('&v_sqlplusVersion',1,3),'800','txt','html') fileExt from dual; 

REM      COLUMN spoolfile new_value v_spoolFile noprint
REM      select '&v_fileName._&v_sid._diag.&v_fileExtension' spoolFile from dual;
      
REM      COLUMN setMarkupOff new_value v_setMarkupOff noprint
REM      select decode('&v_fileExtension','html','MARKUP html OFF SPOOL OFF','ECHO OFF') setMarkupOff from dual;   
      
REM      COLUMN setMarkupOn new_value v_setMarkupOn noprint
REM      select decode(lower('&v_fileExtension'),'html','MARKUP html ON SPOOL ON HEAD ''<TITLE>&v_spoolFile</TITLE> -
REM             <STYLE type="text/css"> - 
REM             BODY {font:10pt Arial,Helvetica,sans-serif; color:black; background:White;} 
REM             p {font:10pt Arial,Helvetica,sans-serif; color:black; background:White;} 
REM             table,tr,td {font:10pt Arial,Helvetica,sans-serif; color:Black; background:#f7f7e7; padding:0px 0px 0px 0px; 
REM             margin:0px 0px 0px 0px;} 
REM             th {font:bold 10pt Arial,Helvetica,sans-serif; color:#336699; background:#cccc99; padding:0px 0px 0px 0px;} 
REM             h1 {font:16pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; border-bottom:1px solid #cccc99; 
REM             margin-top:0pt; margin-bottom:0pt; padding:0px 0px 0px 0px;} 
REM             h2 {font:bold 10pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; margin-top:4pt; 
REM             margin-bottom:0pt;} 
REM             a {font:9pt Arial,Helvetica,sans-serif; color:#663300; background:#ffffff; margin-top:0pt; margin-bottom:0pt; 
REM             vertical-align:top;}</STYLE>''','ECHO OFF') setMarkupOn from dual; 


REM      select decode(lower('&v_fileExtension'),'html','ECHO OFF','ECHO OFF') setMarkupOn from dual; 


      COLUMN spoolfile new_value v_spoolFile noprint
      select '&v_fileName._&v_sid._&v_ssdt..txt' spoolFile from dual;





REM   =========================================================================
REM   END SPOOLING old way
REM   =========================================================================





REM   =========================================================================
REM   Prompt for Input Parameter(s)
REM   =========================================================================

      PROMPT
      PROMPT &v_fileName..sql - 'Last HRMS11i.sql Update Date ' &v_lastUpdate
      PROMPT =================================================================
      PROMPT &v_testDesc
      PROMPT
      PROMPT SQL*Plus User/Version = &v_userName / &v_sqlplusVersion      
      PROMPT NOTE: This Script must be run from SQL*Plus as user apps.
      PROMPT
      PROMPT

      COLUMN startTime new_value v_start noprint
      SELECT to_number(TO_CHAR(SYSDATE,'SSSSS')) startTime FROM DUAL;
      
REM   =========================================================================
REM   Start Spooling and Display Running Message
REM   =========================================================================

      PROMPT ======================================================================
      PROMPT Generating Details for &v_fileName.  This may take several minutes.
      PROMPT ======================================================================
      PROMPT
      PROMPT  Running.....
      PROMPT 
      
      SET TERMOUT OFF;
REM   SET &v_setMarkupOn
REM   SPOOL &v_spoolFile


REM   SPOOL HRMS11i_output_file.txt


      SPOOL &v_spoolFile



      PROMPT SQL*Plus User/Version = &v_userName / &v_sqlplusVersion
      PROMPT NOTE: This Script must be run from SQL*Plus as the 'apps' user.
      PROMPT
          

REM   =========================================================================
REM   Display Test Header Details
REM   =========================================================================



      PROMPT
      PROMPT
      PROMPT DATE HRMS11i was run: &v_ssdt
      PROMPT
      PROMPT
      PROMPT &v_fileName..sql - Script Last Update Date: &v_lastUpdate
      PROMPT =========================================================
      PROMPT &v_testDesc
      PROMPT 
      PROMPT
      PROMPT Review the following notes on www.MyOracleSupport.com
      PROMPT =========================================================
      PROMPT Note: 135266.1 - Oracle HRMS Product Family - Release 11i Information
      PROMPT Note: 145837.1 - Latest HRMS (HR Global) Legislative Data Patch available
      PROMPT Note: 164754.1 - Documentation for HRMS Minipacks Release 11i
      PROMPT Note: 174605.1 - bde_chk_cbo.sql - Current, required and rec. init.ora params  
      PROMPT Note: 226987.1 - Oracle HRMS and Benefits Tuning and System Health Check - 11i
      PROMPT Note: &v_testNoteNumber - Latest version of &v_fileName..sql
      PROMPT
      PROMPT
      PROMPT Instance details
      PROMPT ================
      PROMPT            Instance Name = &v_sid
      PROMPT   Instance Creation Date = &v_crtddt
      PROMPT          Server/Platform = &v_server - &v_platform
      PROMPT    Language/Characterset = &v_lang - &v_char
      PROMPT                 Database = &v_dbVer - &v_dbComp
      PROMPT             Applications = &v_appVer
      PROMPT  &v_sshrVersion | &v_wfVersion | &v_OAFwkVersion
      PROMPT  PER &v_HRStatus | PAY &v_PayStatus
      PROMPT
      PROMPT
      PROMPT
      PROMPT


      PROMPT 11i released HRMS family packs
      PROMPT =====================================================
      PROMPT  11i.HR_PF.K RUP6 patch 10015566 --  &v_PFbugDateK6
      PROMPT  11i.HR_PF.K RUP5 patch  9062727 --  &v_PFbugDateK5
      PROMPT  11i.HR_PF.K RUP4 patch  7666111 --  &v_PFbugDateK4
      PROMPT  11i.HR_PF.K RUP3 patch  6699770 --  &v_PFbugDateK3
      PROMPT  11i.HR_PF.K RUP2 patch  5337777 --  &v_PFbugDateK2
      PROMPT  11i.HR_PF.K RUP1 patch  5055050 --  &v_PFbugDateK1
      PROMPT  11i.HR_PF.K   patch 3500000 --  &v_PFbugDateK
      PROMPT  11i.HR_PF.J   patch 3333633 --  &v_PFbugDateJ
      PROMPT  11i.HR_PF.I   patch 3127777 --  &v_PFbugDateI
      PROMPT  11i.HR_PF.H   patch 3233333 --  &v_PFbugDateH
      PROMPT  11i.HR_PF.G   patch 3116666 --  &v_PFbugDateG
      PROMPT  11i.HR_PF.F   patch 2968701 --  &v_PFbugDateF
      PROMPT  11i.HR_PF.E   patch 2803988 --  &v_PFbugDateE
      PROMPT
      PROMPT


      PROMPT
      PROMPT
      PROMPT
      PROMPT
      PROMPT released GEOCODE patches 
      PROMPT ===========================
      PROMPT  GEOCODE_ANNUAL_2011    patch 12729894 &v_GeocodeDate2011
      PROMPT  GEOCODE_ANNUAL_2010    patch 9879070 &v_GeocodeDate2010
      PROMPT  GEOCODE_ANNUAL_2009    patch 8977290 &v_GeocodeDate2009
      PROMPT  GEOCODE_ANNUAL_2008    patch 7328291 &v_GeocodeDate2008
      PROMPT  GEOCODE_ANNUAL_2007    patch 6117000 &v_GeocodeDate2007
      PROMPT  GEOCODE_ANNUAL_2006    patch 5253339 &v_GeocodeDate2006
      PROMPT  GEOCODE_ANNUAL_2005    patch 4225044 &v_GeocodeDate2005
      PROMPT  GEOCODE_ANNUAL_2004.1  patch 4140070 &v_GeocodeDate20041
      PROMPT  GEOCODE_ANNUAL_2004    patch 3944263 &v_GeocodeDate2004


      PROMPT
      PROMPT
      PROMPT
      PROMPT
      PROMPT Geocode Upgrade Manager processes
      PROMPT ====================================
      PROMPT The Geocode Upgrade Manager process is an Oracle Payroll owned process. 
      PROMPT This process must be run after the customer has applied the GEOCODE patch 
      PROMPT IF the customer has Oracle Payroll fully installed. 
      PROMPT 
      PROMPT Customers who have Oracle Human Resources fully installed 
      PROMPT but do not have Oracle Payroll fully installed, 
      PROMPT are not to run the Geocode Upgrade Manager process. 
      PROMPT
      PROMPT
      PROMPT STATUS = 'C' = Complete
      PROMPT STATUS = 'P' = Processing
      PROMPT STATUS = 'E' = Error
      PROMPT

      COLUMN prog      format a40  heading 'PROGRAM'
      COLUMN startd    format a11  heading 'START'
      COLUMN finishd   format a11  heading 'FINISH'
      COLUMN stat      format a2   heading 'S|t|a|t|u|s'

      select PROGRAM prog, 
             REQUEST_ID, 
             ACTUAL_START_DATE startd,
             ACTUAL_COMPLETION_DATE finishd,
             STATUS_CODE stat
      from FND_CONC_REQ_SUMMARY_V 
      where PROGRAM = 'Geocode Upgrade Manager' 
      order by REQUEST_ID;



      PROMPT
      PROMPT
      PROMPT
      PROMPT
      PROMPT
      PROMPT Salary Admin post HR_PF.K RUP1 patches
      PROMPT ===========================
      PROMPT  Salary Admin patch III: &v_SALadminDate3
      PROMPT  Salary Admin patch  II: &v_SALadminDate2
      PROMPT  Salary Admin patch   I: &v_SALadminDate
      PROMPT  &v_ATGbugDate
      PROMPT
      PROMPT
      PROMPT Labor Distribution
      PROMPT ===========================
      PROMPT  &v_LDbugDate
      PROMPT
      PROMPT
      PROMPT Oracle Time and Labor details
      PROMPT ===========================
      PROMPT  &v_HXTbugDate
      PROMPT
      PROMPT
      PROMPT People Management details
      PROMPT ===========================
      PROMPT  &v_PeopleMgmt
      PROMPT
      PROMPT
      PROMPT Talent Management details
      PROMPT ===========================
      PROMPT  &v_TMadminDate
      PROMPT
      PROMPT
      PROMPT Learning Management details - patches applied
      PROMPT =========================================================
      PROMPT  &v_OLMbugDate10
      PROMPT  &v_OLMbugDate9
      PROMPT  &v_OLMbugDate8
      PROMPT  &v_OLMbugDate7
      PROMPT  &v_OLMbugDate6
      PROMPT  &v_OLMbugDate5
      PROMPT  &v_OLMbugDate4
      PROMPT  &v_OLMbugDate3
      PROMPT  &v_OLMbugDate2
      PROMPT  &v_OLMbugDate1
      PROMPT
      PROMPT
      PROMPT
      PROMPT
      PROMPT iRecruitment details
      PROMPT ===========================
      PROMPT  &v_IRCbugDate
      PROMPT
      PROMPT
      PROMPT Is this instance Multi Org
      PROMPT ===========================
      PROMPT  &v_MultiORGflag
      PROMPT
      PROMPT
      PROMPT Pay Action Parameter detail
      PROMPT ============================
      col PARAMETER_NAME     format a28
      col PARAMETER_VALUE    format a47
      select PARAMETER_NAME, PARAMETER_VALUE 
      from PAY_ACTION_PARAMETERS;

      PROMPT
      PROMPT
      PROMPT
      PROMPT
      PROMPT OTHER current patching levels
      PROMPT ==============================
      PROMPT  AD :  &v_ADbugDate
      PROMPT  AK :  &v_AKbugDate
      PROMPT  ALR:  &v_ALRbugDate
      PROMPT  AME:  &v_AMEbugDate
      PROMPT  ATG:  &v_ATG2bugDate
      PROMPT  BNE:  &v_ADIbugDate
      PROMPT  CAC:  &v_CACbugDate
      PROMPT  EC :  &v_ECbugDate
      PROMPT  FIN:  &v_FINbugDate
      PROMPT  FND:  &v_FNDbugDate
      PROMPT  FRM:  &v_FRMbugDate
      PROMPT  HZ :  &v_HZbugDate
      PROMPT  IRC:  &v_IRC2bugDate
      PROMPT  JTA:  &v_JTAbugDate
      PROMPT  TXK:  &v_TXKbugDate
      PROMPT  UMX:  &v_UMXbugDate
      PROMPT  XDO:  &v_XDObugDate
      PROMPT
      PROMPT
       
      COLUMN app        format a49 heading 'Application Install Status'
      COLUMN appId      format a4  heading 'Id'
      COLUMN appStatus  format a15 heading 'Status' 
      COLUMN patch      format a11 heading 'Patch Level|(?=unknown)'   
      
      SELECT V.APPLICATION_NAME        app
           , to_char(V.APPLICATION_ID) appId
           , L.MEANING                 appStatus
           , DECODE(I.PATCH_LEVEL, NULL, '11i.' || v.APPLICATION_SHORT_NAME || '.?', I.PATCH_LEVEL) patch
      FROM FND_APPLICATION_ALL_VIEW V, FND_PRODUCT_INSTALLATIONS I, FND_LOOKUPS L
      WHERE (V.APPLICATION_ID = I.APPLICATION_ID)
        AND (V.APPLICATION_ID IN 
            ('0', '50', '178', '231', '275', '453', '603', '800', '801', '802', '803', '804', '805', '808', '809', '810', 
             '8401', '8301', '8302', '8303', '8403','101','200'))
        AND (L.LOOKUP_TYPE = 'FND_PRODUCT_STATUS')
        AND (L.LOOKUP_CODE = I.Status )
      ORDER BY 1; 
 
REM   =========================================================================
REM   Display Test Details
REM   =========================================================================






REM   =========================================================================
REM   PROFILE settings
REM   =========================================================================


PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT =======================================================================================
PROMPT PROFILE settings (FND_PROFILE_OPTIONS FND_PROFILE_OPTIONS_TL FND_PROFILE_OPTION_VALUES)
PROMPT =======================================================================================
PROMPT This section lists PROFILE settings 
PROMPT 
PROMPT 
PROMPT LEVEL_ID values   
PROMPT ============================
PROMPT  
PROMPT value 10001 = SITE
PROMPT value 10002 = APPLICATION
PROMPT value 10003 = RESPONSIBILITY
PROMPT  
PROMPT  
PROMPT  
PROMPT LEVEL_VALUE values   
PROMPT ============================
PROMPT  
PROMPT  800 = PER  (Human Resources)
PROMPT  801 = PAY  (Payroll)
PROMPT  805 = BEN  (Oracle Advanced Benefits)
PROMPT  808 = OTM  (Time and Labor)
PROMPT  809 = OTL  (Time and Labor engine)
PROMPT  810 = OTA  (Learning Management)
PROMPT  833 = OTL  (Time and Labor)
PROMPT 8301 = GHR  (US Federal Human Resources)
PROMPT 8302 = PQH  (Public Sector Human Resources)
PROMPT 8303 = PQP  (Public Sector Payroll)
PROMPT 8401 = PSB  (Public Sector Budgeting)
PROMPT  
PROMPT  



REM   =========================================================================
REM   DateTrack:Enabled
REM   =========================================================================


COLUMN upon        format a40          heading 'User Profile Option Name'
COLUMN lid         format 999999999    heading 'Level ID'
COLUMN appid       format 99999        heading 'App ID'
COLUMN pov         format a5           heading 'Value'
COLUMN lv          format 99999        heading 'Level|Value'



select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
             fpo.APPLICATION_ID appid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
             fpov.PROFILE_OPTION_VALUE)) pov, 
             fpov.LEVEL_VALUE lv 
from FND_PROFILE_OPTIONS fpo, 
     FND_PROFILE_OPTIONS_TL fpotl, 
     FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpo.PROFILE_OPTION_NAME = 'DATETRACK:ENABLED' 
and   fpotl.PROFILE_OPTION_NAME = 'DATETRACK:ENABLED' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.PROFILE_OPTION_ID = 1208
and   fpov.LEVEL_ID IN (10001,10002) 
and   fpov.LEVEL_VALUE != '804'
order by 1,2,3,5;




PROMPT
PROMPT
PROMPT

REM   =========================================================================
REM   HR:Cross Business Group
REM   =========================================================================


COLUMN upon        format a45          heading 'User Profile Option Name' 
COLUMN lid         format 999999999    heading 'Level ID' 
COLUMN pov         format a27          heading 'Value'


select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
             fpov.PROFILE_OPTION_VALUE)) pov
from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'HR_CROSS_BUSINESS_GROUP' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001,10002);



SET PAGESIZE 0



REM   =========================================================================
REM   HR: Enable DTW4 defaulting
REM   =========================================================================


select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
             fpov.PROFILE_OPTION_VALUE)) pov
from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'PER_ENABLE_DTW4' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
and   fpov.LEVEL_ID IN (10001,10002) 
and   fpotl.LANGUAGE = 'US' 
and   fpo.APPLICATION_ID = 800;




REM   =========================================================================
REM   HR: Local or Global Name Format
REM   =========================================================================


select fpotl.USER_PROFILE_OPTION_NAME upon, 
       fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'G','Global Format',
DECODE(fpov.PROFILE_OPTION_VALUE,'L','Local Format',
       fpov.PROFILE_OPTION_VALUE)) pov
from FND_PROFILE_OPTIONS fpo, 
     FND_PROFILE_OPTIONS_TL fpotl, 
     FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'HR_LOCAL_OR_GLOBAL_NAME_FORMAT' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001);




REM   =========================================================================
REM   HR: National Identifier Validation
REM   =========================================================================


select fpotl.USER_PROFILE_OPTION_NAME upon, 
       fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'ERROR','Error on Fail',
DECODE(fpov.PROFILE_OPTION_VALUE,'NONE','No Validation',
DECODE(fpov.PROFILE_OPTION_VALUE,'WARN','Warning on Fail',
       fpov.PROFILE_OPTION_VALUE))) pov
from FND_PROFILE_OPTIONS fpo, 
     FND_PROFILE_OPTIONS_TL fpotl, 
     FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'PER_NATIONAL_IDENTIFIER_VALIDATION' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001);




REM   =========================================================================
REM   HR: Use Title in Person's Full Name
REM   =========================================================================


select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
             fpov.PROFILE_OPTION_VALUE)) pov
from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'PER_USE_TITLE_IN_FULL_NAME' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001,10002); 




REM   =========================================================================
REM   HR:User Type
REM   =========================================================================


select fpotl.USER_PROFILE_OPTION_NAME upon, 
       fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'INT','HR with Payroll User',
DECODE(fpov.PROFILE_OPTION_VALUE,'PAY','Payroll User',
DECODE(fpov.PROFILE_OPTION_VALUE,'PER','HR User',
       fpov.PROFILE_OPTION_VALUE))) pov
from FND_PROFILE_OPTIONS fpo, 
     FND_PROFILE_OPTIONS_TL fpotl, 
     FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'HR_USER_TYPE' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001);




REM   =========================================================================
REM   MO: Operating Unit
REM   =========================================================================



select fpotl.USER_PROFILE_OPTION_NAME upon,
             fpov.LEVEL_ID lid, 
             haou.NAME pov
from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov, 
           HR_ALL_ORGANIZATION_UNITS haou
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'ORG_ID' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpov.PROFILE_OPTION_VALUE = haou.ORGANIZATION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001,10002); 




SET PAGESIZE 50





PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT =======================================================================================
PROMPT HR SECURITY PROFILE settings 
PROMPT (FND_PROFILE_OPTIONS FND_PROFILE_OPTIONS_TL FND_PROFILE_OPTION_VALUES PER_SECURITY_PROFILES)
PROMPT =======================================================================================
PROMPT This section lists SECURITY PROFILE settings 
PROMPT 
PROMPT 
PROMPT 
PROMPT HR Security Related NOTES 
PROMPT ==========================
PROMPT Understanding and Using HRMS Security in Oracle HRMS (Doc ID 394083.1)
PROMPT Troubleshooting eBusiness Suite HRMS Security Issues (Doc ID 1266051.1)
PROMPT MO/HR SECURITY PROFILES NOT WORKING TO VIEW ORGANIZATIONS (Doc ID 1066243.1)
PROMPT Need Custom Security Profile To Restrict Based On Employees Organization (Doc ID 445142.1)
PROMPT Why You Cannot Find The 'HR: Ex-Employee Security' profile Profile In R12.1.2 Instance? (Doc ID 1068014.1)
PROMPT Security, MultiOrg, and Multi Org Access Control(MOAC) support in relation to Oracle Human Resources applications (Doc ID 1385633.1)
PROMPT 
PROMPT 
PROMPT 
PROMPT LEVEL_ID values   
PROMPT ============================
PROMPT  
PROMPT value 10001 = SITE
PROMPT value 10002 = APPLICATION
PROMPT value 10003 = RESPONSIBILITY
PROMPT 
PROMPT 


REM   =========================================================================
REM   HR: Security Profile
REM   =========================================================================


COLUMN upon        format a40                  heading 'Profile'
COLUMN lid         format 99999999             heading 'Level ID'
COLUMN spname      format a29                  heading 'Profile Value'



select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
             substr(psp.SECURITY_PROFILE_NAME,1,40) spname
from FND_PROFILE_OPTIONS fpo, 
     FND_PROFILE_OPTIONS_TL fpotl, 
     FND_PROFILE_OPTION_VALUES fpov,
     PER_SECURITY_PROFILES psp
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'PER_SECURITY_PROFILE_ID' 
and   fpov.PROFILE_OPTION_VALUE = psp.SECURITY_PROFILE_ID
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
and   fpov.LEVEL_ID IN (10001) 
and   fpotl.LANGUAGE = 'US' 
and   fpo.APPLICATION_ID = 800; 




SET PAGESIZE 0




REM   =========================================================================
REM   HR: Include Terminated People in Search
REM   =========================================================================


select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
             DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
             DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
                    fpov.PROFILE_OPTION_VALUE)) spname
from FND_PROFILE_OPTIONS fpo, 
     FND_PROFILE_OPTIONS_TL fpotl, 
     FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'HR_VIEW_TERM_PEOPLE_INSRCH' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
and   fpov.LEVEL_ID IN (10001,10002) 
and   fpotl.LANGUAGE = 'US' 
and   fpo.APPLICATION_ID = 800;





REM   =========================================================================
REM   HR: Access Non-Current Employee Data
REM   =========================================================================


select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
             DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
             DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
                    fpov.PROFILE_OPTION_VALUE)) spname
from FND_PROFILE_OPTIONS fpo, 
     FND_PROFILE_OPTIONS_TL fpotl, 
     FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'PER_EX_SECURITY_PROFILE' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID
and   fpov.LEVEL_ID IN (10001,10002) 
and   fpotl.LANGUAGE = 'US' 
and   fpo.APPLICATION_ID = 800;




SET PAGESIZE 500


PROMPT 
PROMPT 
PROMPT 
PROMPT 


PROMPT Security > 
PROMPT Profile > 
PROMPT Security Profile screen > 
PROMPT Security Profiles > 
PROMPT 
PROMPT 

COLUMN spid        format 999999999999         heading 'Security     |Profile      |ID           '
COLUMN spname      format a50                  heading 'Security Profile Name'

set pagesize 500

select SECURITY_PROFILE_ID spid, 
       SECURITY_PROFILE_NAME spname
from PER_SECURITY_PROFILES 
order by UPPER(SECURITY_PROFILE_NAME);






PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT =========================================================================
PROMPT Employee Numbering Details 
PROMPT =========================================================================
PROMPT
PROMPT =======================================================
PROMPT Global Numbering Profile 
PROMPT (FND_PROFILE_OPTIONS_VL and FND_PROFILE_OPTION_VALUES)
PROMPT =======================================================
PROMPT 
PROMPT 
PROMPT for Global Numbering please see the following note 
PROMPT 
PROMPT 
PROMPT NOTE : 259160.1
PROMPT Title: Step By Step Instructions For Implementing Global Sequencing 
PROMPT 
PROMPT 
PROMPT 
PROMPT VERY IMPORTANT: 
PROMPT ================
PROMPT Once a customer implements Global Numbering, 
PROMPT they cannot go backwards and revert back to Automatic or Manual Numbering via Business Group Info.
PROMPT 
PROMPT They must continue to use Global Numbering. 
PROMPT 


PROMPT
PROMPT
PROMPT

PROMPT LEVEL_ID values   
PROMPT ============================
PROMPT  
PROMPT value 10001 = SITE
PROMPT value 10002 = APPLICATION
PROMPT value 10003 = RESPONSIBILITY
PROMPT  
PROMPT 


COLUMN upon        format a45          heading 'Profile Name' 
COLUMN lid         format 999999999    heading 'Level ID' 
COLUMN pov         format a5           heading 'Value'


select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
             fpov.PROFILE_OPTION_VALUE)) pov
from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'PER_GLOBAL_APL_NUM' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001,10002);


set pagesize 0


select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
             fpov.PROFILE_OPTION_VALUE)) pov
from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'PER_GLOBAL_CWK_NUM' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001,10002);




select fpotl.USER_PROFILE_OPTION_NAME upon, 
             fpov.LEVEL_ID lid, 
DECODE(fpov.PROFILE_OPTION_VALUE,'Y','Yes',
DECODE(fpov.PROFILE_OPTION_VALUE,'N','No',
             fpov.PROFILE_OPTION_VALUE)) pov
from FND_PROFILE_OPTIONS fpo, 
           FND_PROFILE_OPTIONS_TL fpotl, 
           FND_PROFILE_OPTION_VALUES fpov
where fpotl.PROFILE_OPTION_NAME = fpo.PROFILE_OPTION_NAME 
and   fpotl.PROFILE_OPTION_NAME = 'PER_GLOBAL_EMP_NUM' 
and   fpo.PROFILE_OPTION_ID = fpov.PROFILE_OPTION_ID 
and   fpotl.LANGUAGE = 'US' 
and   fpov.LEVEL_ID IN (10001,10002);



set pagesize 50



PROMPT
PROMPT
PROMPT
PROMPT 
PROMPT ===========================================
PROMPT Custom Number Generation Using FastFormula 
PROMPT (ALL_SOURCE and FF_FUNCTIONS_V)
PROMPT ===========================================
PROMPT 
PROMPT for Custom Number Generation Using FastFormula please see 
PROMPT NOTE : 279458.1
PROMPT Title: How To Implement Custom Person Numbering Using FastFormula
PROMPT 
PROMPT DISCLAIMER: 
PROMPT While this functionality was released by Oracle HR Development with 11i.HR_PF.H patch 3233333 
PROMPT any implementation making use of this feature is purely a Customization. 
PROMPT 
PROMPT Oracle Support Services 'will not support' these FF Fast Formulas nor the associated Functions. 
PROMPT It is up to the customer to create and diagnose any code used to implement this functionality.
PROMPT 
PROMPT This section searches for Custom NUMBER_GENERATION Packages and FF Fast Formulas on customer 
PROMPT instances to determine their existance.
PROMPT 


PROMPT 
PROMPT 
PROMPT 
PROMPT DOES A CUSTOM NUMBER GENERATION PACKAGE EXIST? 
PROMPT 

       select OWNER, NAME, TEXT
       from   ALL_SOURCE
       where  UPPER(NAME) like UPPER('%NUMBER_GENERATION%')
       and    OWNER = 'APPS'
       and    TEXT like '%$Header%'
       order  by NAME;


PROMPT 
PROMPT
PROMPT
PROMPT DOES A CUSTOM NUMBER GENERATION FF FAST FORMULA EXIST?
PROMPT 

       select * from FF_FUNCTIONS_V 
       where UPPER(DATA_TYPE) = UPPER('number') 
       and UPPER(DEFINITION) like UPPER('%NUM%GEN%');



PROMPT
PROMPT
PROMPT
PROMPT ====================================================================
PROMPT Business Group Info. ('Org Developer DF' descriptive flexfield)
PROMPT Employee / Applicant / Contingent Worker Number Generation segments
PROMPT (HR_ORGANIZATION_INFORMATION and HR_ALL_ORGANIZATION_UNITS)
PROMPT ====================================================================
PROMPT 
PROMPT Organization > Business Group > Business Group Info. > settings for 
PROMPT Employee Number Generation
PROMPT Applicant Number Generation
PROMPT Contingent Worker Number Generation
PROMPT
PROMPT Values found under columns Employee/Applicant/ContingentWorker Number Generation can be 
PROMPT
PROMPT   A = Automatic
PROMPT   M = Manual
PROMPT   N = National Identifier
PROMPT



       COLUMN nam          format a35         heading 'Organization Name               '
       COLUMN orgid        format 999999999   heading 'Org id    '
       COLUMN lcode        format a6          heading 'Legis-|lation|Code  '
       COLUMN appnum       format a7          heading 'App    |Number |Gen    '
       COLUMN cwknum       format a7          heading 'Conting|Worker |Number |Gen    '
       COLUMN empnum       format a7          heading 'Emp    |Number |Gen    '


       SELECT haou.NAME              nam
            , hoi.ORGANIZATION_ID    orgid
            , pbg.LEGISLATION_CODE   lcode
            , hoi.ORG_INFORMATION3   appnum
            , hoi.ORG_INFORMATION16  cwknum
            , hoi.ORG_INFORMATION2   empnum
       FROM HR_ORGANIZATION_INFORMATION hoi, 
            HR_ALL_ORGANIZATION_UNITS haou, 
            PER_BUSINESS_GROUPS pbg
       WHERE hoi.ORGANIZATION_ID = haou.ORGANIZATION_ID 
       and   pbg.ORGANIZATION_ID  = haou.ORGANIZATION_ID
       and hoi.ORG_INFORMATION_CONTEXT  = 'Business Group Information' 
       order by 1;



PROMPT
PROMPT
PROMPT 
PROMPT ===========================================================
PROMPT NEXT_VALUE for EMP / APL / CWK sorted by BUSINESS_GROUP_ID 
PROMPT (PER_NUMBER_GENERATION_CONTROLS)
PROMPT ===========================================================
PROMPT

       COLUMN bgid2    format 999999999   heading 'BG ID'
       COLUMN typ      format a10         heading 'TYPE'

       BREAK ON bgid2

       SELECT BUSINESS_GROUP_ID bgid2, 
              TYPE typ, 
              NEXT_VALUE 
       FROM PER_NUMBER_GENERATION_CONTROLS
       WHERE TYPE IN ('EMP','APL', 'CWK')
       order by 1,2;



PROMPT
PROMPT
PROMPT 
PROMPT =======================================
PROMPT MAX values for EMP / APL / NPW numbers
PROMPT =======================================
PROMPT


       COLUMN empnum    format a20    heading 'MAX EMP Number    '
       COLUMN appnum    format a20    heading 'MAX APL Number    '
       COLUMN npwnum    format a20    heading 'MAX NPW Number    '

       SELECT 
       MAX(TO_CHAR(employee_number))  empnum,
       MAX(TO_CHAR(applicant_number)) appnum,
       MAX(TO_CHAR(npw_number))       npwnum
       FROM PER_ALL_PEOPLE_F;



PROMPT
PROMPT
PROMPT
PROMPT
PROMPT =========================================================================
PROMPT end Employee Numbering Details 
PROMPT =========================================================================
PROMPT
PROMPT




PROMPT
PROMPT
PROMPT
PROMPT =================
PROMPT Language Details
PROMPT =================
PROMPT
PROMPT Installed Languages
REM PROMPT

      column "Language Code"   format A13
      column "Installed Flag"  format A14
      column "NLS Language"    format A35

      SELECT LANGUAGE_CODE  "Language Code",  
             INSTALLED_FLAG "Installed Flag",
             NLS_LANGUAGE   "NLS Language"
      FROM FND_LANGUAGES 
      where INSTALLED_FLAG in ('B','I')
      order by LANGUAGE_CODE;


PROMPT
PROMPT
PROMPT
PROMPT ====================
PROMPT Legislation Details
PROMPT ====================
REM PROMPT
REM Installed legislations
      
      COLUMN legCode  format a29 heading 'Installed legislations|(Code)'
      COLUMN appName  format a25 heading 'Application'
      
      SELECT DECODE(legislation_code
                   ,null,'Global'
                   ,legislation_code)                legCode
           , DECODE(application_short_name
                   , 'PER', 'Human Resources'
                   , 'PAY', 'Payroll'
                   , 'GHR', 'Federal Human Resources'
                   , 'CM',  'College Data'
                   , application_short_name)          appName
      FROM hr_legislation_installations
      WHERE status = 'I'
      ORDER BY legislation_code;

REM      PROMPT
REM  New Legislation data installed during the last year - not all hrglobal patches deliver seed data.

      column date_of_import format a15 heading 'Date Imported'
      column PACKAGE_NAME   format a30 heading 'Package/Export Date'
      column legCode        format a15 heading 'Legislation'
      column status         format a10 heading 'Status'
 
      SELECT date_of_import
           , PACKAGE_NAME 
           , decode(legislation_code, NULL, 'Core', 'ZZ', 'Intl. Payroll',legislation_code) legCode
           , status
      FROM HR_STU_HISTORY
      WHERE TO_NUMBER(TO_CHAR(date_of_import, 'yyyy')) >= TO_NUMBER(TO_CHAR(SYSDATE, 'yyyy')) - 1
      ORDER BY 1 DESC;  
 


PROMPT
PROMPT
PROMPT
PROMPT ========================================================
PROMPT hrglobal.drv details - Review Metalink Note 145837.1 for latest hrglobal patch.
PROMPT ========================================================
PROMPT

REM    COLUMN patchName      format a80 heading 'Version of current hrglobal.drv'
          
REM    SELECT * FROM ( 
REM            SELECT  adv.VERSION || ' installed by patch:' || ap.patch_name  || ' on ' || ap.CREATION_DATE patchName
REM            FROM AD_FILES af
REM               , AD_FILE_VERSIONS adv
REM             , ad_applied_patches ap
REM             , ad_patch_drivers pd
REM             , ad_patch_runs pr
REM             , ad_patch_run_bugs prb
REM             , ad_patch_run_bug_actions prba   
REM          WHERE af.FILE_ID = adv.FILE_ID
REM            AND af.file_id                 = prba.file_id
REM            AND prba.PATCH_FILE_VERSION_ID = adv.FILE_VERSION_ID
REM            AND prba.patch_run_bug_id      = prb.patch_run_bug_id  
REM            AND prb.patch_run_id           = pr.patch_run_id
REM            AND pr.patch_driver_id         = pd.patch_driver_id
REM            AND pd.applied_patch_id        = ap.applied_patch_id
REM            AND af.FILENAME = 'hrglobal.drv'
REM          ORDER BY VERSION desc	
REM      ) WHERE ROWNUM = 1;




PROMPT
PROMPT If you need to see a customer's version of their hrglobal.drv file then have them run the following command 
PROMPT from within their database, anywhere within their database.
PROMPT
PROMPT strings -a $PER_TOP/patch/115/driver/hrglobal.drv | grep Header
PROMPT
PROMPT




      COLUMN LastSuccessfulRun  format a15 heading 'Date of last|Succesfull Run|of hrglobal.drv'
      COLUMN PatchOptions  format a13 heading 'adpatch|Options'

      SELECT pr.end_date             LastSuccessfulRun
           , pr.PATCH_ACTION_OPTIONS PatchOptions
      FROM ad_patch_runs pr
      WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
        AND pr.SUCCESS_FLAG = 'Y'
        AND pr.end_date =(
         SELECT MAX(pr.end_date)
         FROM ad_patch_runs pr
         WHERE pr.PATCH_TOP LIKE '%/per/11.5.0/patch/115/driver'
           AND pr.SUCCESS_FLAG = 'Y');
                                      


REM      PROMPT
REM DataInstaller - Legislations selected for Install

      COLUMN legCode  format a20 heading 'DataInstaller|Legisilations|Selected for Install'
      COLUMN asn      format a5  heading 'App'
      COLUMN action   format a10 heading 'Action'

      SELECT DECODE(hli.legislation_code
                   ,null,'Global'
                   ,hli.legislation_code)                legCode
           , hli.application_short_name                  asn
           , hli.action                                  action
      FROM user_views uv
         , hr_legislation_installations hli
      WHERE uv.view_name IN (SELECT view_name FROM hr_legislation_installations)
      AND uv.view_name = hli.view_name
      ORDER by legislation_code desc, application_short_name asc;
      


REM      PROMPT
REM Statutory Exceptions - To address rows listed here review Metalink Note:101351.1
     
      COLUMN table_name     format a25 heading 'Statutory Exceptions|on Table'
      COLUMN surrogate_id   format a10 heading 'Surrogate|ID'
      COLUMN true_key       format a10 heading 'True Key'
      COLUMN exception_text format a33 heading 'Exception Text|Review Note:101351.1'
      
      SELECT table_name
           , to_char(surrogate_id) surrogate_id
           , true_key
           , exception_text
      FROM hr_stu_exceptions;




PROMPT
PROMPT
PROMPT
PROMPT ====================
PROMPT JIT/GEOCODE details
PROMPT ====================
PROMPT
REM Last JIT Installed
      
      COLUMN patchName   format A40 heading 'Last JIT Installed'
      COLUMN appliedDate format A12 heading 'Date Applied' 
      
      SELECT 'Patch:' || to_char(patch_number)
             || ' - ' ||  patch_name            patchName
           , applied_date          appliedDate
      FROM pay_patch_status
      WHERE (patch_name LIKE '%JIT%')
        AND status = 'C'
        AND applied_date IN 
           (SELECT MAX(applied_date) 
            FROM pay_patch_status 
            WHERE (patch_name LIKE '%JIT%')
              AND status = 'C');



PROMPT
PROMPT
PROMPT
PROMPT All released Geocode Patches and Installed Geocode Patches
PROMPT ===================
PROMPT  GEOCODE_ANNUAL_2011    patch 12729894 &v_GeocodeDate2011
PROMPT  GEOCODE_ANNUAL_2010    patch 9879070 &v_GeocodeDate2010
PROMPT  GEOCODE_ANNUAL_2009    patch 8977290 &v_GeocodeDate2009
PROMPT  GEOCODE_ANNUAL_2008    patch 7328291 &v_GeocodeDate2008
PROMPT  GEOCODE_ANNUAL_2007    patch 6117000 &v_GeocodeDate2007
PROMPT  GEOCODE_ANNUAL_2006    patch 5253339 &v_GeocodeDate2006
PROMPT  GEOCODE_ANNUAL_2005    patch 4225044 &v_GeocodeDate2005
PROMPT  GEOCODE_ANNUAL_2004.1  patch 4140070 &v_GeocodeDate20041
PROMPT  GEOCODE_ANNUAL_2004    patch 3944263 &v_GeocodeDate2004




REM All Geocodes Installed
      
REM      COLUMN patchName   format A50 heading 'All Geocodes Installed'
REM      COLUMN geoUpdates  format 999999999 heading 'Geocodes|Updated'
REM      COLUMN appliedDate format A12 heading 'Date Applied' 

      
REM      SELECT 'Patch:' || decode(stat.patch_number, 99999999, 'Seeded', stat.patch_number)  
REM             || ' - ' || stat.patch_name             patchName
REM           , stat.applied_date           appliedDate
REM           , ( select count(mods.patch_name) from pay_us_modified_geocodes mods where mods.patch_name = stat.patch_name) GeoUpdates
REM      FROM pay_patch_status stat
REM      WHERE stat.patch_name LIKE '%GEO%'
REM        AND status = 'C'
REM      ORDER BY applied_date desc;




PROMPT
PROMPT
PROMPT
PROMPT ==============================
PROMPT Database Parameters 
PROMPT review Metalink Note 226987.1
PROMPT ==============================
PROMPT If currently experiencing performance problems run bde_chk_cbo.sql from Metalink Note 174605.1
PROMPT to verify that all Mandatory Parameters (MP) are set correctly.
REM PROMPT
      
      COLUMN pName    format a20 heading 'Database Parameters'
      COLUMN pValue   format a79 heading 'Value'
      
      SELECT p.name pName, p.value pValue FROM v$parameter p
      WHERE p.name IN ('max_dump_file_size','timed_statistics'
	  ,'user_dump_dest','compatible','optimizer_mode'
	  ,'sql_trace','oracle_trace_enable','core_dump_dest'
	  ,'utl_file_dir','timed_os_statistics')
      ORDER BY p.name;

REM Last Gather Schema/Table Concurrent Processes ran for HR or ALL
      
      COLUMN pReqId      format a10 heading 'Request|ID'       
      COLUMN pProg       format a15 heading 'Concurrent|Process'
      COLUMN parentReqId format a10 heading 'Parent'           
      COLUMN pStatus     format a10 heading 'Phase|Status'   
      COLUMN pParms      format a30 heading 'Parameters'       
      COLUMN pStartDate  format a6 heading 'Start|Date'       
      COLUMN pEndDate    format a6 heading 'End|Date'  
      COLUMN pMinutes    format a5 heading 'Dur.|(Min)'
            
      SELECT * FROM (
      SELECT TO_CHAR(request_id) pReqId
           , program pProg
	   , TO_CHAR(decode(fcrs.PARENT_REQUEST_ID,-1,null,fcrs.PARENT_REQUEST_ID)) parentReqId      
           , PHAS.MEANING || ' ' || STAT.MEANING pStatus 
           , fcrs.ARGUMENT_TEXT pParms
           ,REQUESTED_START_DATE pStartDate 
           ,ACTUAL_COMPLETION_DATE pEndDate
           , to_char(round((fcrs.ACTUAL_COMPLETION_DATE - fcrs.REQUESTED_START_DATE) * 1440)) pMinutes
      FROM FND_CONC_REQ_SUMMARY_V fcrs
         , FND_LOOKUPS STAT
         , FND_LOOKUPS PHAS
      WHERE STAT.LOOKUP_CODE = FCRS.STATUS_CODE
        AND STAT.LOOKUP_TYPE = 'CP_STATUS_CODE'
        AND PHAS.LOOKUP_CODE = FCRS.PHASE_CODE
        AND PHAS.LOOKUP_TYPE = 'CP_PHASE_CODE'
        AND UPPER(program) LIKE 'GATHER%'
        AND substr(UPPER(ARGUMENT_TEXT),1,3) in ('HR,','ALL')
      ORDER BY 1 desc)
      where rownum < 2;



PROMPT
PROMPT
PROMPT
PROMPT ==================================================================
PROMPT Spatial Indexes and indexes related to Spatial Index issues
PROMPT 
PROMPT ==================================================================
PROMPT



      COLUMN table_name format a26  heading 'Table Name'
      COLUMN index_name format a30  heading 'Index Name'

      select table_name, index_name, status, uniqueness
      from   dba_indexes
      where  index_name in 
      ('HR_LOCATIONS_N1','HR_LOCATIONS_SPT','PER_ADDRESSES_N1','PER_ADDRESSES_SPT','IRC_SEARCH_CRITERIA_CTX')
      order  by index_name;




PROMPT
PROMPT
PROMPT
PROMPT ==================================================================
PROMPT Invalid Objects and Disabled Triggers 
PROMPT Use adadmin to compile apps schema and to resolve invalid objects
PROMPT ==================================================================
PROMPT
      

PROMPT
PROMPT
PROMPT Total Invalid Objects = 
PROMPT

      select count(*) "COUNT"
      from dba_objects
      WHERE status != 'VALID'
      AND object_type != 'UNDEFINED';


PROMPT
PROMPT


      COLUMN owner          format a10 heading 'Owner'
      COLUMN object_type    format a25 heading 'Type'
      COLUMN object_name    format a35 heading 'Invalid Object'
      BREAK ON owner ON object_type

      SELECT owner, object_type,  object_name
      FROM dba_objects
      WHERE status != 'VALID'
      AND object_type != 'UNDEFINED'
      ORDER BY 1, 2, 3;
     
      COLUMN owner           format a10 heading 'Owner'
      COLUMN TABLE_NAME      format a30 heading 'Table'
      COLUMN trigger_name    format a35 heading 'Disabled Triggers'
      BREAK ON owner ON table_name

      SELECT OWNER, TABLE_NAME, TRIGGER_NAME 
      FROM dba_triggers
      WHERE status = 'DISABLED'
	  AND TABLE_OWNER IN ('HR','HXT','HXC','HRI','BEN')
      ORDER BY 1, 2, 3;



PROMPT
PROMPT
PROMPT
PROMPT  =========================================================================
PROMPT  CHECK FOR STATUS OF 'WHO' TRIGGERS for the following HR owned tables:
PROMPT  =========================================================================
PROMPT   'HR_ALL_ORGANIZATION_UNITS'
PROMPT   'HR_ALL_ORGANIZATION_UNITS_TL'
PROMPT   'HR_ALL_POSITIONS_F'
PROMPT   'HR_ALL_POSITIONS_F_TL'
PROMPT   'HR_LOCATIONS_ALL'
PROMPT   'HR_LOCATIONS_ALL_TL'
PROMPT   'PER_ADDRESSES'
PROMPT   'PER_ALL_ASSIGNMENTS_F'
PROMPT   'PER_ALL_PEOPLE_F'
PROMPT   'PER_ALL_POSITIONS'
PROMPT   'PER_JOBS'
PROMPT   'PER_JOBS_TL'
PROMPT   'PER_PERIODS_OF_SERVICE'
PROMPT

REM PROMPT
      COLUMN owner          format a8  heading 'Owner'
      COLUMN trigger_name   format a31 heading 'Trigger Name'
      COLUMN table_name     format a30 heading 'Table Name'
      COLUMN status         format a8  heading 'Status'
      BREAK ON owner ON table_name
      select OWNER, 
             TABLE_NAME,
             TRIGGER_NAME, 
             STATUS 
      from all_triggers 
      where UPPER(table_name) in 
         ( 'PER_ALL_PEOPLE_F'
         , 'PER_ALL_ASSIGNMENTS_F'
         , 'PER_PERIODS_OF_SERVICE'
         , 'PER_PERSON_TYPE_USAGES_F'
         , 'PER_ADDRESSES'
         , 'HR_LOCATIONS_ALL'
         , 'HR_LOCATIONS_ALL_TL'
         , 'HR_ALL_ORGANIZATION_UNITS'
         , 'HR_ALL_ORGANIZATION_UNITS_TL'
         , 'HR_ALL_POSITIONS_F'
         , 'HR_ALL_POSITIONS_F_TL'
         , 'PER_ALL_POSITIONS'
         , 'PER_JOBS'
         , 'PER_JOBS_TL')
      and TRIGGER_NAME like '%WHO%' 
      order by table_name, trigger_name;



PROMPT
PROMPT
PROMPT
PROMPT  =========================================================================
PROMPT  CHECK FOR STATUS OF 'OVN' TRIGGERS for all HR and PER owned tables:
PROMPT  =========================================================================
PROMPT  
PROMPT  
PROMPT  

REM PROMPT
      COLUMN owner          format a8  heading 'Owner'
      COLUMN trigger_name   format a31 heading 'Trigger Name'
      COLUMN table_name     format a30 heading 'Table Name'
      COLUMN status         format a8  heading 'Status'
      BREAK ON owner ON table_name
      select OWNER, 
             TABLE_NAME,
             TRIGGER_NAME, 
             STATUS 
      from all_triggers 
      where OWNER = 'APPS'
      and trigger_name like 'HR%OVN%' 
      or  trigger_name like 'PER%OVN%'
      order by owner, table_name;



PROMPT
PROMPT
PROMPT
PROMPT
PROMPT
PROMPT  =========================================================================
PROMPT  v$parameter settings for Instance Name = &v_sid
PROMPT  =========================================================================
PROMPT  


        COLUMN NAME       format a33    heading 'Name'
        COLUMN VALUE      format a42    heading 'Value'

        select NAME, VALUE 
        from   v$parameter
        order  by name;





REM   =========================================================================
REM   BUSINESS GROUP output
REM   =========================================================================

      PROMPT
      PROMPT
      PROMPT
      PROMPT
      PROMPT Business Group Details (HR_ALL_ORGANIZATION_UNITS )
      PROMPT ====================================================
      PROMPT This section lists the Business Group details for each owning Organization
      PROMPT


      COLUMN BUSINESS_GROUP_ID  format 999999      heading 'Bus|Grp|id '
      COLUMN ORGANIZATION_ID    format 999999      heading 'Org|id '
      COLUMN NAME               format a34         heading 'Organization Name'
      COLUMN LEGISLATION_CODE   format a6          heading 'Legis-|lation|Code  '
      COLUMN ENABLED_FLAG       format a4          heading 'Enab|-led|Flag'
      COLUMN DATE_FROM          format a11         heading 'Date From'
      COLUMN DATE_TO            format a11         heading 'Date To'



      select haou.BUSINESS_GROUP_ID, 
             haou.ORGANIZATION_ID, 
             haou.NAME, 
             pbg.LEGISLATION_CODE, 
             pbg.ENABLED_FLAG, 
             pbg.DATE_FROM, 
             pbg.DATE_TO
      from HR_ALL_ORGANIZATION_UNITS haou, 
           PER_BUSINESS_GROUPS pbg
      where haou.ORGANIZATION_ID = haou.BUSINESS_GROUP_ID 
      and   pbg.ORGANIZATION_ID  = haou.ORGANIZATION_ID
      order by haou.BUSINESS_GROUP_ID;





      PROMPT
      PROMPT
      PROMPT
      PROMPT
      PROMPT Business Group sub-Organizations and Classification Details 
      PROMPT      (HR_ALL_ORGANIZATION_UNITS and HR_ORGANIZATION_INFORMATION_V)
      PROMPT ===========================================================================
      PROMPT This section lists the Business Groups and the attached sub-Organizations 
      PROMPT and their Classifications and Statuses
      PROMPT


      COLUMN orgid        format 999999    heading 'OrgID'
      COLUMN bgid         format 999999    heading 'BG ID'
      COLUMN name1        format a29       heading 'Organization Name'
      COLUMN orginf1      format a28       heading 'Classifications'
      COLUMN orginf2      format a04       heading 'Enab|-led'


      BREAK ON bgid ON orgid ON name1


      select hou.BUSINESS_GROUP_ID bgid,
             hou.ORGANIZATION_ID orgid,
             hou.NAME name1,
             hoiv.ORG_INFORMATION1_MEANING orginf1,
             hoiv.ORG_INFORMATION2_MEANING orginf2
      from HR_ALL_ORGANIZATION_UNITS hou, 
           HR_ORGANIZATION_INFORMATION_V hoiv
      where hou.ORGANIZATION_ID = hoiv.ORGANIZATION_ID 
      and hoiv.ORG_INFORMATION1_MEANING IS NOT NULL 
      order by hou.BUSINESS_GROUP_ID, hou.ORGANIZATION_ID, hoiv.ORG_INFORMATION1_MEANING; 




PROMPT
PROMPT
PROMPT
PROMPT
REM   =========================================================================
REM   Display Test Footer
REM   =========================================================================

      COLUMN dateRun NEW_VALUE v_date NOPRINT
      SELECT TO_CHAR(SYSDATE,'DD-Mon-YYYY HH24:MI:SS') dateRun FROM DUAL;
      
      COLUMN elapsedTime NEW_VALUE v_time NOPRINT
      SELECT LTRIM(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE,'SSSSS')) - &v_start)) elapsedTime FROM DUAL;
      
      PROMPT Summary of &v_fileName
      PROMPT ======================================================================
      PROMPT Date         = &v_date
      PROMPT Elapsed Time = &v_time seconds
      PROMPT
      PROMPT
      PROMPT For support issues, please log an iTar (Service Request).
      PROMPT
      PROMPT ======================================================================
      PROMPT ======================================================================
      PROMPT
      PROMPT
      PROMPT ======================================================================
      PROMPT instance &v_sid FORMS VERSION
      PROMPT ======================================================================



REM   =========================================================================
REM   Stop Spooling and Display Review Spool file message
REM   =========================================================================

REM   SET &v_setMarkupOff

      SPOOL OFF
      SET TERMOUT ON;
      
      PROMPT
      PROMPT =============================================================================
      PROMPT Please review the output file: &v_spoolFile
      PROMPT
REM   PROMPT Please review the output file: HRMS11i_output_file.txt
      PROMPT 
      PROMPT =============================================================================
      PROMPT

REM   =========================================================================
REM   UNDEFINE Generic Test Variables used in all tests
REM   =========================================================================

      UNDEFINE            v_appVer
      UNDEFINE              v_char
      UNDEFINE            v_dbComp
      UNDEFINE             v_dbVer
      UNDEFINE          v_fileName
      UNDEFINE          v_HRStatus
      UNDEFINE   v_inputParameters
      UNDEFINE        v_lastUpdate
      UNDEFINE              v_lang
      UNDEFINE       v_legislation
      UNDEFINE      v_OAFwkVersion
      UNDEFINE         v_PayStatus
      UNDEFINE         v_PFbugDate
      UNDEFINE         v_PFbugDateE
      UNDEFINE         v_PFbugDateF
      UNDEFINE         v_PFbugDateG
      UNDEFINE         v_PFbugDateH
      UNDEFINE         v_PFbugDateI
      UNDEFINE         v_PFbugDateJ
      UNDEFINE         v_PFbugDateK
      UNDEFINE         v_PFbugDateK1
      UNDEFINE         v_PFbugDateK2
      UNDEFINE         v_PFbugDateK3
      UNDEFINE         v_PFbugDateK4
      UNDEFINE         v_PFbugDateK5
      UNDEFINE         v_PFbugDateK6
      UNDEFINE       v_GeocodeDate
      UNDEFINE          v_platform
      UNDEFINE           v_product
      UNDEFINE            v_server
REM   UNDEFINE      v_setMarkupOff
REM   UNDEFINE       v_setMarkupOn
      UNDEFINE       v_sshrVersion
      UNDEFINE              v_ssdt
      UNDEFINE               v_sid
      UNDEFINE            v_crtddt
REM   UNDEFINE         v_spoolFile
      UNDEFINE    v_sqlplusVersion
      UNDEFINE          v_testDate      
      UNDEFINE          v_testDesc
      UNDEFINE    v_testNoteNumber
      UNDEFINE          v_userName
      UNDEFINE v_validAppsVersions
      UNDEFINE         v_wfVersion
      UNDEFINE      v_SALadminDate
      UNDEFINE     v_SALadminDate2
      UNDEFINE     v_SALadminDate3
      UNDEFINE        v_ATGbugDate
      UNDEFINE        v_TXKbugDate
      UNDEFINE        v_ALRbugDate
      UNDEFINE        v_XDObugDate
      UNDEFINE        v_CACbugDate
      UNDEFINE        v_UMXbugDate
      UNDEFINE         v_AKbugDate
      UNDEFINE        v_JTAbugDate
      UNDEFINE         v_ECbugDate
      UNDEFINE        v_PeopleMgmt
      UNDEFINE      v_MultiORGflag
      UNDEFINE        v_FNDbugDate
      UNDEFINE       v_ATG2bugDate
      UNDEFINE         v_ADbugDate
      UNDEFINE         v_HZbugDate
      UNDEFINE        v_FINbugDate
      UNDEFINE        v_ADIbugDate
      UNDEFINE        v_IRCbugDate
      UNDEFINE       v_IRC2bugDate
      UNDEFINE         v_LDbugDate
REM   UNDEFINE        v_LDbugDate2
      UNDEFINE        v_OLMbugDate
      UNDEFINE       v_OLMbugDate10
      UNDEFINE       v_OLMbugDate9
      UNDEFINE       v_OLMbugDate8
      UNDEFINE       v_OLMbugDate7
      UNDEFINE       v_OLMbugDate6
      UNDEFINE       v_OLMbugDate5
      UNDEFINE       v_OLMbugDate4
      UNDEFINE       v_OLMbugDate3
      UNDEFINE       v_OLMbugDate2
      UNDEFINE       v_OLMbugDate1
      UNDEFINE       v_TMadminDate
      UNDEFINE        v_FRMbugDate
      UNDEFINE        v_HXTbugDate
      UNDEFINE        v_AMEbugDate
      UNDEFINE   v_GeocodeDate2011
      UNDEFINE   v_GeocodeDate2010
      UNDEFINE   v_GeocodeDate2009
      UNDEFINE   v_GeocodeDate2008
      UNDEFINE   v_GeocodeDate2007
      UNDEFINE   v_GeocodeDate2006
      UNDEFINE   v_GeocodeDate2005
      UNDEFINE  v_GeocodeDate20041
      UNDEFINE   v_GeocodeDate2004



REM   =========================================================================
REM   Reset SQL PLUS Environment Variables
REM   =========================================================================

      SET FEEDBACK ON
      SET VERIFY   ON
      SET TIMING   ON
      SET ECHO     ON



REM   =========================================================================
REM   append output to display instance FORMS VERSION 
REM   
REM   =========================================================================
REM


!f60gen \? | grep Forms | grep Version | awk '{print}' >> &v_spoolFile


      PROMPT
      PROMPT



EXIT

