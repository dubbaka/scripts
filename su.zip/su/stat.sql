 select num_rows, avg_row_len,blocks,empty_blocks from dba_tables where table_name = '&tname' and owner = '&owner'
/
