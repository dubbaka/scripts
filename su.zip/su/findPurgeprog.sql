
Column Application format  a10
 Column Concurrent_Program Format a20
 Column User_Concurrent_Program Format a40

 Select  Fa.Application_Short_Name Application ,
         Fc.Concurrent_Program_Name Concurrent_Program,
         Fcl.User_Concurrent_Program_Name User_Concurrent_Program
 From 
    Fnd_Application Fa,
    Fnd_Concurrent_Programs Fc,
    Fnd_Concurrent_Programs_TL Fcl
 Where
          Fa.Application_id=Fc.Application_id
      and Fc.Application_id=Fcl.Application_id
      and Fc.Concurrent_Program_id=Fcl.Concurrent_Program_id
      and Fcl.User_Concurrent_Program_name Like '%Purge%'
 group by Fa.Application_Short_Name,Fc.Concurrent_Program_Name,Fcl.User_Concurrent_Program_Name
 Order by Application
/
