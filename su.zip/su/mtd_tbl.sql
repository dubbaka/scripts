connect apps/g00gmiss;
create table xxyh.xxyh_adv_account_daily_new nologging as
  SELECT  /*+ parallel(a,8) */
                     datestamp, account_id, sum(cost) cost, sum(clicks) clicks,
                     sum(impressions) impressions, mrkt_id
                     FROM adv_account_daily_sage  a
                     WHERE 1=2
                 GROUP BY datestamp, account_id, mrkt_id;


