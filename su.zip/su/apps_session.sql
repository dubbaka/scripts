REM START OF SQL
set pagesize 132
set linesize 100
column inst_id format 9999
column machine format A15
column program format A25
column module format a35
column how_many format 99999999

spool list_sessions.txt

select to_char(sysdate, 'DD-MON-RR HH24:MM:SS') when_run from dual
/
select inst_id, machine, program, module, count(*) how_many from gv$session
group by inst_id, machine, program, module
/
select count(*) from v$session;
/
select count(*) from v$session where status='INACTIVE';
/
select count(*) from v$session where status='ACTIVE';
/
select machine, osuser, program, count(*) from v$session group by machine, osuser, program order by 4 desc;
/
select count(status) Count, status, machine, program from v$session where program like '%JDBC%' group by status, machine,
program;
/
select count(status) Count, status, machine, module from v$session where program = 'JDBC Thin Client' group by status,
machine, module;
/
select serial#, substr(program,1,20) program, status, to_char(logon_time,'DD-MON-YY HH24:SS') Login_Time,
to_char(sysdate-last_call_et/86400,'DD-MON-YY HH24:SS') Last_Activity
from v$session where program like 'JDBC%' order by 4;
/

spool off
REM END OF SQL
