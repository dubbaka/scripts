spool /tmp/kill.sql
select 'ALTER SYSTEM KILL SESSION ' ||''''||s.sid||','|| s.serial#||''''||';' from v$session   s
where seconds_in_wait >28800
and  program like 'JDBC Thin Client'
and  logon_time < sysdate -1/2
and status like 'INACTIVE'
and status not like 'KILLED'
and machine like 'orafinapp%'
/
spool off;

@ /tmp/kill.sql
