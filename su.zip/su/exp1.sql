set serveroutput on size 1000000
DECLARE

sqltext varchar2(2000);
display_text varchar2(2000);
xx v$sqltext.sql_text%TYPE;
space_cnt number;

BEGIN
	dbms_output.put_line('SQL_TEXT');
	dbms_output.put_line('--------------------------------------------------------------------------');
for xx in (select sql_text
from v$sqltext
where hash_value = 
   (select sql_hash_value from
           v$session where sid = &sid)
order by piece ) LOOP
	sqltext := sqltext || xx.sql_text;
END LOOP;
	

dbms_output.put_line(length(sqltext));

--  space_cnt := instr(sqltext,' ',60);
  
 -- dbms_output.put_line(space_cnt);
 
  while (length(sqltext) > 60)
  LOOP
     dbms_output.put_line(instr(sqltext,' ',1,length(sqltext)));
     display_text := substr(sqltext,0,instr(sqltext,' ',length(sqltext)));

--     dbms_output.put_line(substr(sqltext,0,space_cnt));
     dbms_output.put_line(display_text);
     sqltext := substr(sqltext,instr(sqltext,' ',length(sqltext)),length(sqltext));

  END LOOP;
  

END;
/

