REM Script to check which database files are growing

set lines 132;
set file_name for a55
set pages 50;

select a.FILE_NAME, b.timestamp, b.bytes, a.timestamp, a.bytes from XXATORCL.XXAT_DBA_FILEINFO a,
 (select file_name, timestamp, bytes ,tablespace_name from XXATORCL.XXAT_DBA_FILEINFO where trunc(TIMESTAMP) = to_date('25-OCT-02','DD-MON-YY')) b
where trunc(a.TIMESTAMP) = to_date('14-MAR-03', 'dd-MON-yy')
-- and a.tablespace_name=b.tablespace_name
and a.file_name = b.file_name
and a.bytes <> b.bytes
/
