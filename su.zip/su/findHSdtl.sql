
REM +=======================================================================+
REM |    Agilent Technologies, Colorado Springs                             |
REM |    All rights reserved.                                               |
REM |    $Header: findHSdtl.sql 01-Mar-03       Agilent Technologies    $  |
REM +=======================================================================+
REM   FILENAME
REM     findHSdtl.sql
REM
REM   PURPOSE
REM    This script will query the table xxat_dba_wait_event_t1
REM    and findout the hot segments, i.e. contention on the segment
REM
REM   Usage:
REM        sqlplus <dbsuser/pwd> @findHSdtl.sql
REM
REM   HISTORY
REM
REM   02-MAR-03   Abhay Shastri     Created
REM==========================================================================

set lines 132;
col SegName for a30;
col SegType for a15;
col EventName for a35 word_wrap;
col NoofWaits for 99999999;

spool FindHS.log;


select SegName, SegType, EventName, count(*) NoofWaits
from
( select b.segment_name SegName, b.segment_type SegType, c.Event EventName
    from dba_extents b,  xxat_dba_wait_event_t1 c
      --   ( select p1, p2,event 
      --      from XXAT_DBA_WAIT_EVENT_T1 
      --       group by p1,p2,event having count(*) > 3
      --   ) c
   where b.file_id = c.p1
     and event = 'buffer busy waits'
     and c.p2 between b.block_id and (b.block_id + b.blocks -1 )
)
group by SegName, SegType, EventName
order by NoofWaits
/

spool off;
