delete from GL_INTERFACE where (user_je_source_name, nvl(group_id, -1)) in
                ( ('Receivables', 2819497))  and status = 'PROCESSED'  and request_id =
                3468236 and rownum <= 1000 and (user_je_source_name, nvl(group_id, -1)) IN
                (SELECT src.user_je_source_name, nvl(group_id,-1)  FROM
                gl_interface_control ic,  gl_je_sources src  WHERE ic.je_source_name =
                src.je_source_name  AND   ic.interface_run_id = 151520 AND
                ic.set_of_books_id = 144 AND   ic.status = 'I'  AND
                nvl(ic.processed_table_code,'D') != 'S')
