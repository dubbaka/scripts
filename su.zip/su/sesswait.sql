select a.sid,a.state,b.status,a.event,a.wait_time,a.seconds_in_wait, a.p1raw,a.p1text,a.p2,a.p2raw,a.p2text from v$session_wait a, v$session b
where a.sid=&GIVE_SID_VAL and a.sid=b.sid;
