SELECT /*+ ordered index(su hz_cust_site_uses_all_pk)   use_hash(trx,dist)
*/ trx . invoice_currency_code C_CURRENCY , cy . precision C_PRECISION
, cy . minimum_accountable_unit C_MINIMUM_ACCOUNTABLE_UNIT ,
loc . state C_STATE , decode ( : p_detail_level , 'Detail State'
, 'X' , loc . county ) C_COUNTY , decode ( : p_detail_level
, 'Detail State' , 'X' , loc . city ) C_CITY , loc . postal_code
C_SHIP_TO_ZIP , DECODE ( : p_order_by , 'Invoice Date' , trx
. trx_date , null ) C_ORDER_BY_1 , RTRIM ( RPAD ( DECODE ( :
p_order_by , 'Invoice Number' , trx . trx_number , 'Transaction
Type' , decode ( types . type , 'INV' , '1' , 'DM' , '1' , '2'
) , 'Customer Number' , cust_acct . account_number , 'Customer
Name' , party . party_name , null ) , 30 ) ) C_ORDER_BY_2 ,
trx . trx_date C_ORDER_BY_3 , decode ( types . type , 'CM' ,
nvl ( ARP_TAX_STR_PKG . GET_CREDIT_MEMO_TRX_NUMBER ( trx . previous_customer_trx_id
) , : lp_onacct_lookup ) , trx . trx_number ) C_INV_NUMBER ,
types . type C_INV_TYPE , types . type C_INV_TYPE_CODE , decode
( types . type , 'INV' , 10 , 'DM' , 15 , 'CM' , 20 , 30 ) C_INV_TYPE_CODE_ORDER
, decode ( types . type , 'CM' , trx . trx_number , ARP_TAX_STR_PKG
. GET_CREDIT_MEMO_TRX_NUMBER ( trx . previous_customer_trx_id
) ) C_ADJ_NUMBER , to_number ( null ) C_ADJ_LINE_AMOUNT , to_number
( null ) C_ADJ_TAX_AMOUNT , to_number ( null ) C_ADJ_FREIGHT_AMOUNT
, null C_ADJ_TYPE , decode ( types . type , 'CM' , nvl ( ARP_TAX_STR_PKG
. GET_CREDIT_MEMO_TRX_DATE ( trx . previous_customer_trx_id
) , trx . trx_date ) , trx . trx_date ) C_INV_DATE , substrb
( party . party_name , 1 , 50 ) C_CUST_NAME , cust_acct . account_number
C_CUST_NUMBER , su . location C_LOCATION , nvl ( su . tax_code
, cust_acct . tax_code ) C_CUST_TAX_CODE , decode ( types .
type , 'INV' , 'INVOICE' , 'DM' , 'INVOICE' , 'CREDIT MEMO'
) C_TYPE_FLAG , decode ( types . type , 'CM' , nvl ( trx . previous_customer_trx_id
, - 1 * trx . customer_trx_id ) , trx . customer_trx_id ) C_INV_CUST_TRX_ID
, trx . customer_trx_id C_CUST_TRX_ID , trx . batch_source_id
C_BATCH_SOURCE_ID , - 1 C_ADJUSTMENT_ID , line . customer_trx_line_id
C_TRX_LINE_ID , line . line_number C_LINE_NUMBER , line . description
C_DESCRIPTION , line . extended_amount C_LINE_AMOUNT , tax .
line_number C_TAX_LINE_NUMBER , tax . customer_trx_line_id C_TAX_CUST_TRX_LINE_ID
, tax . tax_rate C_TAX_RATE , vat . tax_code C_VAT_CODE , tax
. tax_vendor_return_code C_TAX_VENDOR_RETURN_CODE , vat . tax_type
C_VAT_CODE_TYPE , nvl ( ex . customer_exemption_number , line
. tax_exempt_number ) C_EXEMPT_NUMBER , nvl ( ex . reason_code
, line . tax_exempt_reason_code ) C_EXEMPT_REASON , decode (
ex . reason_code , null , decode ( line . tax_exempt_reason_code
, null , null , 100 ) , ex . percent_exempt ) C_EXEMPT_PERCENT
, nvl ( tax . extended_amount , 0 ) C_TAX_AMOUNT , tax . item_exception_rate_id
C_TAX_EXCEPT_RATE_ID , loc_assign . loc_id C_TAX_AUTHORITY_ID
, loc . postal_code C_TAX_AUTHORITY_ZIP_CODE , tax . sales_tax_id
C_SALES_TAX_ID ,  'Y' C_GLTAX_INRANGE_FLAG , tax . global_attribute_category
C_GLOBAL_ATTRIBUTE_CATEGORY , tax . global_attribute1 C_VENDOR_LOCATION_QUALIFIER
, tax . global_attribute2 C_VENDOR_STATE_AMT , tax . global_attribute3
C_VENDOR_STATE_RATE , tax . global_attribute4 C_VENDOR_COUNTY_AMT
, tax . global_attribute5 C_VENDOR_COUNTY_RATE , tax . global_attribute6
C_VENDOR_CITY_AMT , tax . global_attribute7 C_VENDOR_CITY_RATE
, tax . global_attribute12 C_VENDOR_TAXABLE_AMTS , tax . global_attribute13
C_VENDOR_NON_TAXABLE_AMTS , tax . global_attribute14 C_VENDOR_EXEMPT_AMTS
FROM  ra_customer_trx_all trx, ra_cust_trx_line_gl_dist_all
dist, ra_cust_trx_types_all types , hz_cust_site_uses_all su
, hz_cust_acct_sites_all acct_site , hz_party_sites party_site
, hz_locations loc , hz_loc_assignments loc_assign , fnd_currencies
cy , hz_cust_accounts cust_acct , hz_parties party , ar_vat_tax_all
vat ,   ra_tax_exemptions_all ex , ra_customer_trx_lines_all
line , ra_customer_trx_lines_all tax , ra_cust_trx_line_gl_dist_all
taxdist   WHERE ( ( trx.ship_to_site_use_id IS NOT NULL AND
trx.ship_to_site_use_id = su.site_use_id ) OR ( trx.ship_to_site_use_id
IS NULL AND trx.bill_to_site_use_id = su.site_use_id ) ) AND
su.cust_acct_site_id = acct_site.cust_acct_site_id AND acct_site.party_site_id
= party_site.party_site_id AND loc.location_id = party_site.location_id
AND loc.location_id = loc_assign.location_id AND nvl ( acct_site.org_id
, - 99 ) = nvl ( Loc_assign.org_id , - 99 ) AND upper ( loc.state
) between : p_state_low and : p_state_high AND loc.country =
'US' AND trx.cust_trx_type_id = types.cust_trx_type_id AND types.type
in ( 'CM' , 'INV' , 'DM' ) AND cy.currency_code = trx.invoice_currency_code
AND cust_acct.cust_account_id = trx.bill_to_customer_id AND
party.party_id = cust_acct.party_id AND dist.customer_trx_id
= trx.customer_trx_id AND dist.account_class = 'REC' AND trx.customer_trx_id
= line.customer_trx_id AND line.customer_trx_line_id = tax.link_to_cust_trx_line_id
(+) AND line.line_type = 'LINE' AND tax.line_type (+) = 'TAX'
AND vat.vat_tax_id (+) = nvl ( tax.vat_tax_id , - 1 ) AND ex.tax_exemption_id
(+) = nvl ( tax.tax_exemption_id , - 1 ) AND ( trx.trx_date
between : p_trx_date_low and : p_trx_date_high AND 1 = 1 ) AND
dist.gl_date between to_date ( '01-MAY-2006' , 'DD-MON-YYYY'
) AND to_date ( '31-MAY-2006' , 'DD-MON-YYYY' ) AND dist.latest_rec_flag
= 'Y' and trx.complete_flag = 'Y' AND taxdist.customer_trx_line_id
(+) = tax.customer_trx_line_id AND dist.gl_posted_date is not
null and taxdist.gl_posted_date is not null AND trx.invoice_currency_code
between DECODE ( : p_currency_low , : p_all , trx.invoice_currency_code
, : p_currency_low ) AND DECODE ( : p_currency_high , : p_all
, trx.invoice_currency_code , : p_currency_high ) AND nvl (
ex.status , 'X' ) = DECODE ( : p_exemption_status , null , nvl
( ex.status , 'X' ) , : p_exemption_status ) AND 1 = 1 AND 1
= 1 AND NVL ( trx.ORG_ID , : p_reporting_entity_id ) = : p_reporting_entity_id
AND NVL ( vat.ORG_ID , : p_reporting_entity_id ) = : p_reporting_entity_id
AND NVL ( types.ORG_ID , : p_reporting_entity_id ) = : p_reporting_entity_id
AND NVL ( ex.ORG_ID , : p_reporting_entity_id ) = : p_reporting_entity_id
UNION ALL SELECT /*+ ordered index(adj AR_ADJUSTMENTS_N6)
*/ trx . invoice_currency_code C_CURRENCY , cy . precision
C_PRECISION , cy . minimum_accountable_unit C_MINIMUM_ACCOUNTABLE_UNIT
, loc . state C_STATE , decode ( : p_detail_level , 'Detail
State' , 'X' , loc . county ) C_COUNTY , decode ( : p_detail_level
, 'Detail State' , 'X' , loc . city ) C_CITY , loc . postal_code
C_SHIP_TO_ZIP , DECODE ( : p_order_by , 'Invoice Date' , adj
. apply_date , null ) C_ORDER_BY_1 , RTRIM ( RPAD ( DECODE (
: p_order_by , 'Invoice Number' , trx . trx_number , 'Transaction
Type' , '3' , 'Customer Number' , cust_acct . account_number
, 'Customer Name' , party . party_name , null ) , 30 ) ) C_ORDER_BY_2
, adj . apply_date C_ORDER_BY_3 , trx . trx_number C_INV_NUMBER
, : p_adjustment_display C_INV_TYPE , 'ADJ' C_INV_TYPE_CODE
, 30 C_INV_TYPE_CODE_ORDER , adj . adjustment_number C_ADJ_NUMBER
, adj . line_adjusted C_ADJ_LINE_AMOUNT , adj . tax_adjusted
C_ADJ_TAX_AMOUNT , adj . freight_adjusted C_ADJ_FREIGHT_AMOUNT
, adj . type C_ADJ_TYPE , adj . apply_date C_INV_DATE , substrb
( party . party_name , 1 , 50 ) C_CUST_NAME , cust_acct . account_number
C_CUST_NUMBER , su . location C_LOCATION , nvl ( su . tax_code
, cust_acct . tax_code ) C_CUST_TAX_CODE , 'ADJUSTMENT' C_TYPE_FLAG
, trx . customer_trx_id C_INV_CUST_TRX_ID , trx . customer_trx_id
C_CUST_TRX_ID , trx . batch_source_id C_BATCH_SOURCE_ID , adj
. adjustment_id C_ADJUSTMENT_ID , line . customer_trx_line_id
C_TRX_LINE_ID , line . line_number C_LINE_NUMBER , line . description
C_DESCRIPTION , line . extended_amount C_LINE_AMOUNT , tax .
line_number C_TAX_LINE_NUMBER , tax . customer_trx_line_id C_TAX_CUST_TRX_LINE_ID
, tax . tax_rate C_TAX_RATE , vat . tax_code C_VAT_CODE , tax
. tax_vendor_return_code C_TAX_VENDOR_RETURN_CODE , vat . tax_type
C_VAT_CODE_TYPE , nvl ( ex . customer_exemption_number , line
. tax_exempt_number ) C_EXEMPT_NUMBER , nvl ( ex . reason_code
, line . tax_exempt_reason_code ) C_EXEMPT_REASON , decode (
ex . reason_code , null , decode ( line . tax_exempt_reason_code
, null , null , 100 ) , ex . percent_exempt ) C_EXEMPT_PERCENT
, nvl ( tax . extended_amount , 0 ) C_TAX_AMOUNT , tax . item_exception_rate_id
C_TAX_EXCEPT_RATE_ID , loc_assign . loc_id C_TAX_AUTHORITY_ID
, loc . postal_code C_TAX_AUTHORITY_ZIP_CODE , tax . sales_tax_id
C_SALES_TAX_ID , 'Y' C_GLTAX_INRANGE_FLAG , tax . global_attribute_category
C_GLOBAL_ATTRIBUTE_CATEGORY , tax . global_attribute1 C_VENDOR_LOCATION_QUALIFIER
, tax . global_attribute2 C_VENDOR_STATE_AMT , tax . global_attribute3
C_VENDOR_STATE_RATE , tax . global_attribute4 C_VENDOR_COUNTY_AMT
, tax . global_attribute5 C_VENDOR_COUNTY_RATE , tax . global_attribute6
C_VENDOR_CITY_AMT , tax . global_attribute7 C_VENDOR_CITY_RATE
, tax . global_attribute12 C_VENDOR_TAXABLE_AMTS , tax . global_attribute13
C_VENDOR_NON_TAXABLE_AMTS , tax . global_attribute14 C_VENDOR_EXEMPT_AMTS
FROM   ra_customer_trx_all trx , hz_cust_site_uses_all su ,
hz_cust_acct_sites_all acct_site , hz_party_sites party_site
, hz_locations loc , hz_cust_accounts cust_acct , hz_parties
party , ar_vat_tax_all vat , ra_tax_exemptions_all ex , fnd_currencies
cy ,   ra_customer_trx_lines_all line , ra_customer_trx_lines_all
tax , hz_loc_assignments loc_assign  , ar_adjustments_all adj
WHERE trx.customer_trx_id = adj.customer_trx_id AND nvl (
trx.ship_to_site_use_id , trx.bill_to_site_use_id ) = su.site_use_id
AND upper ( loc.state ) between : p_state_low and : p_state_high
AND loc.country = 'US' AND su.cust_acct_site_id = acct_site.cust_acct_site_id
AND acct_site.party_site_id = party_site.party_site_id AND loc.location_id
= party_site.location_id AND loc.location_id = loc_assign.location_id
AND nvl ( acct_site.org_id , - 99 ) = nvl ( loc_assign.org_id
, - 99 ) AND cust_acct.cust_account_id = trx.bill_to_customer_id
AND cust_acct.party_id = party.party_id AND trx.customer_trx_id
= line.customer_trx_id AND line.customer_trx_line_id = tax.link_to_cust_trx_line_id
(+) AND cy.currency_code = trx.invoice_currency_code AND line.line_type
= 'LINE' AND tax.line_type (+) = 'TAX' AND vat.vat_tax_id (+)
= nvl ( tax.vat_tax_id , - 1 ) AND ex.tax_exemption_id (+) =
nvl ( tax.tax_exemption_id , - 1 ) AND adj.gl_date between to_date
( '01-MAY-2006' , 'DD-MON-YYYY' ) AND to_date ( '31-MAY-2006'
, 'DD-MON-YYYY' ) and adj.apply_date between : p_adj_date_low
and : p_adj_date_high AND adj.gl_posted_date is not null AND
trx.invoice_currency_code between DECODE ( : p_currency_low
, : p_all , trx.invoice_currency_code , : p_currency_low ) AND
DECODE ( : p_currency_high , : p_all , trx.invoice_currency_code
, : p_currency_high ) AND nvl ( ex.status , 'X' ) = DECODE (
: p_exemption_status , null , nvl ( ex.status , 'X' ) , : p_exemption_status
) and 1 = 1 and 1 = 1 and adj.chargeback_customer_trx_id is
null and adj.approved_by is not null and 1 = 1 AND NVL ( adj.ORG_ID
, : p_reporting_entity_id ) = : p_reporting_entity_id AND NVL
( trx.ORG_ID , : p_reporting_entity_id ) = : p_reporting_entity_id
AND NVL ( vat.ORG_ID , : p_reporting_entity_id ) = : p_reporting_entity_id
AND NVL ( ex.ORG_ID , : p_reporting_entity_id ) = : p_reporting_entity_id
ORDER BY 1 ASC,4 ASC,5 ASC,6 ASC,8 ASC,9 ASC,10 ASC,11 ASC,26
ASC,14 ASC,20 ASC,27 ASC,29 ASC,31 ASC,30 ASC,34 ASC,35 ASC,49
ASC,50 ASC,51 ASC,52 ASC,53 ASC,54 ASC,55 ASC,56 ASC,57 ASC,58
ASC,59 ASC
