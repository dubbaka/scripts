set line 132
set pagesize 0
column sql_statement heading 'sql statement' format a60 wrap
col reads format 999,999,999
col exec  format 999,999,999
col username format a10 wrap

 select substr(b.username,1,15) username,
         a.disk_reads reads,
         a.executions exec,
         a.sql_text sql_statement
 from   v$sqlarea a, dba_users b
 where  a.parsing_user_id = b.user_id
 and    a.disk_reads > 100000
 and    rownum < 10
 order by a.disk_reads desc
/
