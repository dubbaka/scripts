# !/bin/ksh -x
# db_size.sh 
# Purpose:
#  This script is written by Kiran Kulkarni for finding out db size of PRD database on deposit.fin server. 
# DECLARED VARIABLES

. /usr/local/dba/tools/scripts/systemwide.env


DB_SIZE="/usr/local/dba/tools/sql/tspdet.sql"
#SPOOL_TEMP="/staging/raghu/dbsize.spl"
ALERTEE="erp-dba@yahoo-inc.com"
#ALERTEE="raghug@yahoo-inc.com"

        sqlplus -s "/ as sysdba" @${DB_SIZE} $SPOOL_FILE
if [ -s ${SPOOL_FILE} ]
   then
        mailx -s "Database Size as of `date +%D-%k:%M` " -r DB-SIZE ${ALERTEE} < ${SPOOL_FILE}
	rm -f ${SPOOL_FILE}
fi
