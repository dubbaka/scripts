REM ===============================================================================
REM This script will show why the session is waiting and howlong it is waiting
REM Input : sid (session id)
REM
REM By Abhay
REM
REM ================================================================================

col event for a25 word_wrap;
select a.event event, a.seconds_in_wait, s.status 
  from v$session_wait a, v$session s
 where a.sid=s.sid
 and a.sid=&SID
/

