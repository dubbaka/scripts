. /home/oracle/ERPDBG_orafindevdb01.env
sqlplus dvowner/dvowner_123 <<EOF
spool /patches/suman/11gpatches/vault/fnddbvuser_obt_aa.txt
@/patches/suman/11gpatches/vault/fnddbvuser.sql ADD OBT_AA
EOF

sqlplus dvowner/dvowner_123 <<EOF
spool /patches/suman/11gpatches/vault/fnddbvuser_xxyh.txt
@/patches/suman/11gpatches/vault/fnddbvuser.sql ADD XXYH
EOF

sqlplus dvowner/dvowner_123 <<EOF
spool /patches/suman/11gpatches/vault/fnddbvuser_xxyh_eul.txt
@/patches/suman/11gpatches/vault/fnddbvuser.sql ADD XXYH_EUL_US
EOF

sqlplus dvowner/dvowner_123 <<EOF
spool /patches/suman/11gpatches/vault/fnddbvuser_hreul.txt
@/patches/suman/11gpatches/vault/fnddbvuser.sql ADD HREUL
EOF

cat /dev/null > /patches/suman/11gpatches/vault/vault.log
cd /patches/suman/11gpatches/vault
for file in `ls  /patches/suman/11gpatches/vault/*.txt`; do cat $file >> /patches/suman/11gpatches/vault/vault.log; done
mailx -s "vault script output from ERPDBG Refresh" sumanb@yahoo-inc.com kamit@yahoo-inc.com < /patches/suman/11gpatches/vault/vault.log
