set line 132
col LOG_OWNER format a10
col LOG_TABLE format a30
col LOG_MASTER format a28
col SNAPSITE format a15
col SOWNER format a12

select SOWNER,SNAPSITE,a.SNAPSHOT_ID,LOG_OWNER,LOG_TABLE,MASTER 
from all_snapshot_logs a, sys.reg_snap$ b
where LOG_OWNER like 'XXYH%'
and b.SNAPSHOT_ID = a.SNAPSHOT_ID
/
