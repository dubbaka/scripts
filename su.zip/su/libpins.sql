col Handle format a30
col Pin_addr format a30 
break on Handle 
select sid Waiter,
substr(rawtohex(p1),1,30) Handle,
substr(rawtohex(p2),1,30) Pin_addr
from v$session_wait where wait_time=0 and event like 'library cache pin%'
order by 2
/

