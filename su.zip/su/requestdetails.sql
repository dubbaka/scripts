set verify off
set linesize 300
col progName format a39
col user_name format a20
col RESPONSIBILITY_NAME for a30
col logfile_name format a41 word_wrap
col start format a18
col end format a18
col argument_text format a30
select request_id,user_name,p.user_concurrent_program_name progName,resp.RESPONSIBILITY_NAME,argument_text,  phase_code,status_code,r.logfile_name, to_char(actual_start_date,'DD-MON-YY HH24:MI:SS') "Start",to_char(actual_completion_date,'DD-MON-YY HH24:MI:SS') "End" from applsys.fnd_concurrent_requests r,apps.fnd_user u,apps.fnd_concurrent_programs_tl p, gv$session s,apps.fnd_responsibility_tl resp where  request_id = &reqid and p.concurrent_program_id = r.concurrent_program_id and r.requested_by=u.user_id and r.oracle_session_id = s.audsid(+) and r.RESPONSIBILITY_ID=resp.RESPONSIBILITY_ID
/

