accept v_inst_id prompt    'Inst_id (1)          : ' default 1

break on agg skip 1
compute sum of pga_used_mem on agg

col sess_id format a12
col state format a20
col username format a15
col pga_used_mb format 99,999
col pga_freeable format 999
col agg format 9
col sql_hash format a14
col avg_sec_idle format 999,999
col max_sec_idle format 999,999

select * from
        (
        select
                0 Agg,
                p.inst_id || '-' ||s.sid sess_id,
                case
                        when state like 'WAITING%' then 'WAITING' || ' (' ||s.wait_class || ')'
                        when state like 'WAITED%' then 'CPU'
                        else state
                end as state,
                to_char(s.sql_hash_value) sql_hash,
                s.username,
                p.pga_used_mem/1048576 pga_used_mb,
                p.pga_freeable_mem/1048576 pga_freeable,
                0 avg_sec_idle,
                0 max_sec_idle,
                machine,action
        from    gv$process p, gv$session s
        where
                p.inst_id=s.inst_id and
                p.addr=s.paddr and
                p.inst_id=&v_inst_id and
                s.wait_class  <> 'Idle'
        )
        union
        (
        select
                   1 Agg,
                   'users: ' || count(1) sess_id,
                   '* : ' || s.wait_class  state,
                   '*' sql_hash,
                   s.username,
                   sum(p.pga_used_mem)/1048576 pga_used_mb,
                   sum(p.pga_freeable_mem)/1048576 pga_freeable,
                   avg (seconds_in_wait)  avg_sec_idle,
                   max (seconds_in_wait)  max_sec_idle,
                   machine,action
        from    gv$process p, gv$session s
        where
                   p.inst_id=s.inst_id and
                   p.addr=s.paddr and
                   p.inst_id=&v_inst_id and
                s.wait_class  = 'Idle'
        group by
                 '*',
                 s.username, s.wait_class, machine, action
        )
order by 1,6 desc
;
