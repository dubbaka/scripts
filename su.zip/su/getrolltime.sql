
SELECT KTUXEUSN, KTUXESLT, KTUXESQN, /* Transaction ID */
KTUXESTA Status, KTUXECFL Flags
FROM x$ktuxe
WHERE ktuxesta !='INACTIVE'
AND ktuxeusn<100
AND KTUXECFL='DEAD'
/
select 'Enter Segment id from above' from dual
/
select segment_name, segment_id
from dba_rollback_segs
where segment_id in (&seg1,&seg2)
/
select 'alter system dump datafile &file_id block &blockid' from dual
/
