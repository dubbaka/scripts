set serveroutput on size 1000000
DECLARE
   -- declare the table type
   TYPE mysql_type IS TABLE OF
        v$sqltext.sql_text%TYPE
       INDEX BY BINARY_INTEGER;
   --declare a TABLE variable of this type
   mysql mysql_type;
i number :=0;
j number :=0;
str_len number;
space_count number := 0 ; 
currentrow  varchar2(5000);
printrow  varchar2(5000);
newrow  varchar2(5000);
   BEGIN
	dbms_output.put_line('SQL_TEXT');
	dbms_output.put_line('--------------------------------------------------------------------------');
for xx in (select hash_value, sql_text
from v$sqltext
where hash_value = 
   (select sql_hash_value from
           v$session where sid = &sid)
order by piece ) LOOP
	mysql(i) := xx.sql_text;
	i:=i+1;
		END LOOP;
	currentrow := mysql(0);
	for j in 1..i-1 LOOP
		newrow:= currentrow||mysql(j);
		select 	instr(newrow,' ',60), length(newrow)
		into 	space_count, str_len
		from 	dual;
if space_count = 0
then
	currentrow:= newrow;
else
	printrow:= rtrim(substr(newrow,1,space_count-1));
	currentrow:= substr(newrow,space_count+1, str_len-space_count+1);
dbms_output.put_line(printrow);
end if;
	
END LOOP;
	dbms_output.put_line(currentrow);
END;
/

