set lines 300
col host for a40
select owner,db_link,username,host from dba_db_links
