set echo on
update alr.alr_alerts
set enabled_flag = 'N'
where alert_id = 100021
/
update hr.per_pay_proposals set PROPOSED_SALARY_N=1000
/
update hr.per_all_people_f
set attribute4 = 0,
national_identifier ='111-11-1111',
date_of_birth = '02-JAN-1970'
/
update applsys.fnd_concurrent_requests set phase_code='C',status_code='C' where phase_code in ('P','R')
/
delete applsys.fnd_oam_context_files where path like '%raid%'
/
update applsys.fnd_profile_option_values set profile_option_value='Reporting Instance'
where profile_option_id =
(select profile_option_id from applsys.fnd_profile_options where profile_option_name='SITENAME' )
/
update applsys.fnd_profile_option_values
set profile_option_value=null
where application_id=178 and level_id=10002 and profile_option_id=3769
/
delete applsys.fnd_concurrent_queues where concurrent_queue_id in
( select concurrent_queue_id from applsys.fnd_concurrent_queues_tl where
  concurrent_queue_name like '%deposit%' or concurrent_queue_name like '%216.145.49.235%')
/
delete applsys.fnd_concurrent_queues_tl where concurrent_queue_name like '%deposit%'
 or concurrent_queue_name like '%216.145.49.235%'
/
delete applsys.fnd_nodes where node_name like '%DEPOSIT%'
 or node_name like '%216.145.49.235%'
/

