SELECT
 SESSION_ID "SID",
 OWNER||'.'||OBJECT_NAME "Object",
  ORACLE_USERNAME "Locker",
-- mysessf(lockwait) "Wait",
lockwait "Wait",
  DECODE(LOCKED_MODE,
    2, 'ROW SHARE',
    3, 'ROW EXCLUSIVE',
    4, 'SHARE',
    5, 'SHARE ROW EXCLUSIVE',
    6, 'EXCLUSIVE',  'UNKNOWN') "Lockmode",
  OBJECT_TYPE "Type",
  c.ROW_WAIT_ROW#
 -- PROGRAM "Program"
FROM
  GV$LOCKED_OBJECT A,
  dba_OBJECTS B,
  GV$SESSION c
WHERE
  A.OBJECT_ID = B.OBJECT_ID 
  AND C.SID = A.SESSION_ID
  and c.inst_id = a.inst_id
  and c.sid = '&sid'
  and c.inst_id='&inst_id'
ORDER BY 1 ASC, 5 Desc
/
