SELECT  count(distinct user_name)
FROM
applsys.fnd_user f,
FND_USER_RESP_GROUPS x,
fnd_application_tl y
WHERE
f.user_id = x.user_id and
y.application_id = x.responsibility_application_id
and f.PERSON_PARTY_ID >0
--and x.RESPONSIBILITY_ID not in(52761,54202,54211)
--and x.RESPONSIBILITY_ID not in (select RESPONSIBILITY_ID from fnd_RESPONSIBILITY_tl where application_id=800)
--and x.RESPONSIBILITY_ID  in (select RESPONSIBILITY_ID from fnd_RESPONSIBILITY_tl where application_id=200)
--and x.RESPONSIBILITY_ID in (select RESPONSIBILITY_ID from fnd_RESPONSIBILITY_tl where application_id in (200,201,222))
--and x.RESPONSIBILITY_ID in (select RESPONSIBILITY_ID from fnd_RESPONSIBILITY_tl where application_id in (201))
and f.EMPLOYEE_ID is not null
and (f.END_DATE is NULL or  f.end_date >= sysdate)
and exists (select RESPONSIBILITY_ID,RESPONSIBILITY_name from fnd_RESPONSIBILITY_tl t where RESPONSIBILITY_name not like '%Internet%'
and  RESPONSIBILITY_name not like '%Inquiry%'
and application_name not like '%Self%Serv%' and application_name not like '%GoTo%' and application_name not like '%Yahoo%Custom%'
and RESPONSIBILITY_name not like '%Workflow%' and RESPONSIBILITY_name not like '%Notifications%'  and RESPONSIBILITY_name not like '%Expense%'
and RESPONSIBILITY_name not like '%Self%Serv%' and t.responsibility_id = x.responsibility_id)
/

