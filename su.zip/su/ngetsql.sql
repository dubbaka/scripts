set linesize 64
set heading off

set feedback off
set trimspool off
set verify off
clear columns
clear breaks
select sql_text from v$sqltext
where hash_value in (
        select sql_hash_value from V$session
        where sid = &1
        union
        select prev_hash_value from v$session
        where sid=&&1
        )
order by hash_value,piece
/
