select fcrs.request_id||';'||decode(fcrs.phase_code,'C','Completed',fcrs.phase_code)||';'||decode(fcrs.status_code,'E','Error',fcrs.status_code)||';'||fcrs
.USER_CONCURRENT_PROGRAM_NAME
from apps.fnd_conc_req_summary_v fcrs
where fcrs.ACTUAL_COMPLETION_DATE between (sysdate-1/24) and sysdate
and phase_code in ('C')
and status_code in ('E')

