column module format a10
column descrip format a20
select s.module module,fu.description descrip,s.sid osid,s.action oaction,start_time stime
from
v$session s, fnd_logins f, fnd_user fu
where
s.process = f.spid 
and fu.user_id  = f.user_id
and s.action is not null
and fu.description like '%&1%'
and start_time > sysdate - 1
and end_time is not null
/
