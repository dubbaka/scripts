set echo off
-- ------------------------------------------------------------------------
-- E E _ D B _ I M P O R T _ C H E C K _ U S E R . S Q L
--
-- Performs a check of Equity Edge directory and Java policy configuration
-- for Equity Edge 5.0 import architecture.
-- This script will generate a output in same directory as this SQL directory 
-- named ee_db_import_check_user.lst
--
-- Modification Record (add latest to the top)
-- Date         User          Description
-- ----------   -----------   ---------------------------------
-- 09/24/2003   B.Cowden      Additional checks added.
-- 03/14/2003   B.Cowden      Initial version.
-- ------------------------------------------------------------------------

-- ------------------------------------------------------------------------
-- S E T   S C R I P T   S E T T I N G S
-- ------------------------------------------------------------------------
	set termout			off
	set feedback		10
	set verify			on
	set scan			on
	set trimspool		on
	set serveroutput	on
	set lines			200
	set pages			25
	set head			on
	clear				columns
	clear				buffer
	clear				sql
	col key				format 999
	col username		format a10
	col name			format a30
	col action			format a25
	col type_name		format a30
	col directory_name	format a30
	col directory_path	format a30
	col check_permission format a40
	col temp_user noprint new_value this_user 
	col ee_import_log noprint new_value ee_import_log
	col ee_import_dir noprint new_value ee_import_dir
	col today noprint new_value today
	col timestamp noprint new_value timestamp
	col os_file_sperator noprint new_value os_file_sperator 
	col readCommand noprint new_value readCommand 
	col listCommand noprint new_value listCommand 

	select
		DIRECTORY_PATH ee_import_dir , decode(instr(DIRECTORY_PATH,'/'),0,'\','/') os_file_sperator 
	from all_directories where directory_name = 'EEIMPORTDIRECTORY';

	select
		DIRECTORY_PATH ee_import_log 
	from all_directories
	where directory_name = 'EEIMPORTLOG';

	set verify			off
        select sysdate today from dual;
        select to_char(sysdate,'DD-MON-YYYY HH:MI:SS') timestamp from dual;
        select decode('&&os_file_sperator','/','cat ','type ') readCommand from dual;
        select decode('&&os_file_sperator','/','ls -l ','dir/p ') listCommand from dual;
	select user temp_user from dual
/
	set verify			on
	set termout			on

-- ------------------------------------------------------------------------
-- E E   I M P O R T   D I R E C T O R Y   C H E C K
-- ------------------------------------------------------------------------
	col DIR_CHECK	format a70 head "EE Import Directories created"
	select
		rpad('EEIMPORTDIRECTORY',length('EEIMPORTDIRECTORY')+1) ||' check in ALL_DIRECTORIES: '||decode(count(*),0,'ERROR-NOT FOUND','OK') DIR_CHECK
	from
		all_directories
	where
		directory_name = 'EEIMPORTDIRECTORY'
	union
	select
		rpad('EEIMPORTLOG',length('EEIMPORTDIRECTORY')+1) ||' check in ALL_DIRECTORIES: '||decode(count(*),0,'ERROR-NOT FOUND','OK') DIR_CHECK
	from
		all_directories
	where
		directory_name = 'EEIMPORTLOG'
/

	set termout			off
	set verify			off
	set feedback			off
	set head			off
        select 'The current values for EEIMPORTLOG  is '||'&&ee_import_log' from dual;
        select 'The current values for EEIMPORTDIRECTORY  is '||'&&ee_import_dir' from dual;
        --select 'The Opeating System File seperator defined in directories is '||'&&os_file_sperator' from dual;
        select 'The Opeating System File read Command  is '||'&&readCommand' from dual;
 
	host  echo "ee_import_dir" &timestamp > &ee_import_dir&os_file_sperator&today

	set termout			on

	select 'CHECKS FOR READ, WRITE PERMISSIONS ON EEIMPORTDIRECTORY &ee_import_dir' from dual;
	prompt Listing and Reading File '&today' for EEIMPORTDIRECTORY in directory '&ee_import_dir'

	host &listCommand &ee_import_dir&os_file_sperator&today
	host &listCommand &ee_import_dir&os_file_sperator&today 
	prompt Content of File '&today'
        
	host &readCommand &ee_import_dir&os_file_sperator&today 

	prompt If '&today' file is listed above and Today's Date and timestamp can be seen in that file. 
	prompt EEIMPORTDIRECTORY (&ee_import_dir) is readable and writable. 
	prompt If File is not found at EEIMPORTDIRECTORY location, Please check the following.
        prompt   - Please make sure Directory exists. Please check for case-sensitivity of the Path.
        prompt   - Please make sure Directory is not a mapped Drive on network (applicable for Windows NT). 
        prompt   - Please make sure you can read and write the directory. To check that you can create a small text file and save it.

	select 'CHECKS FOR READ, WRITE PERMISSIONS ON EEIMPORTLOG &ee_import_log' from dual;
	prompt Listing and Reading File '&today' for EEIMPORTLOG in directory '&ee_import_log'

	host  echo "ee_import_log " &timestamp > &ee_import_log&os_file_sperator&today
	host &listCommand &ee_import_log&os_file_sperator&today 
	prompt Content of File '&today'
        
	host &readCommand &ee_import_log&os_file_sperator&today 

	prompt If '&today' file is listed above and Today's Date and timestamp can be seen in that file. 
	prompt EEIMPORTLOG (&ee_import_log) is readable and writable. 
	prompt If File is not found at EEIMPORTLOG location, Please check the following.
        prompt   - Please make sure Directory exists. Please check for case-sensitivity of the Path.
        prompt   - Please make sure Directory is not a mapped Drive on network (applicable for Windows NT). 
        prompt   - Please make sure you can read and write the directory. To check that you can create a small text file and save it.

	set head			on
	set verify			on
	set feedback			on
-- ------------------------------------------------------------------------
-- E E   I M P O R T   D I R E C T O R Y   P E R M I S S I O N   C H E C K
-- ------------------------------------------------------------------------
	col DIR_CHECK	format a70 head "READ Permission granted on EE Import Directories"
	select
		rpad('EEIMPORTDIRECTORY',length('EEIMPORTDIRECTORY')+1) ||' READ permission granted to '||user||': '||decode(count(*),0,'ERROR-NOT GRANTED','OK') DIR_CHECK
	from
		user_tab_privs
	where
		table_name='EEIMPORTDIRECTORY'
		and grantor like 'SYS%'
	union
	select
		rpad('EEIMPORTLOG',length('EEIMPORTDIRECTORY')+1) ||' READ permission granted to '||user||': '||decode(count(*),0,'ERROR-NOT GRANTED','OK') DIR_CHECK
	from
		user_tab_privs
	where
		table_name='EEIMPORTLOG'
		and grantor like 'SYS%'
/

-- ------------------------------------------------------------------------
-- J A V A    P E R M I S S I O N   C H E C K
-- ------------------------------------------------------------------------
	prompt All Java permissions for &this_user
	select
		type_name
		,enabled
		,name
		,action
		,SEQ
	from
		user_java_policy
	where
		grantee_name	= user
/

-- ------------------------------------------------------------------------
-- J A V A    P E R M I S S I O N   C H E C K
-- ------------------------------------------------------------------------
	prompt Java permission check for EE Import directories
	select
		type_name
		,enabled
		,ujp.name
		,action
		,decode(paths.name
			,'ALLFILES', decode(action
				,'execute','OK'
				,'ERROR')
			,'EEIMPORTDIRECTORY', decode(action
				,'read,write','OK'
				,'ERROR')
			,'EEIMPORTLOG', decode(action
				,'read,write,delete','OK'
				,'ERROR')
			,'READFILE', decode(action
				,NULL,'OK'
				,'ERROR')
			,'WRITEFILE', decode(action
				,NULL,'OK'
				,'ERROR')
		) STATUS
	from
		user_java_policy ujp
		,(
			select directory_name NAME,directory_path||decode(instr(directory_path,'/'),0,'\*','/*') PATH from all_directories where directory_name in ('EEIMPORTDIRECTORY','EEIMPORTLOG')
			union
			select 'ALLFILES' NAME,'<<ALL FILES>>' PATH from dual
			union
			select 'READFILE' NAME,'readFileDescriptor' PATH from dual
			union
			select 'WRITEFILE' NAME,'writeFileDescriptor' PATH from dual
		) paths
	where
		ujp.grantee_name	= user
		and ujp.name		= paths.PATH
/

-- ------------------------------------------------------------------------
-- S Y S   O R   S Y S T E M   G R A N T E D   P E R M I S S I O N S
-- ------------------------------------------------------------------------
	prompt SYS-granted or SYSTEM-granted object privileges
	select
		grantee
		,table_name "PRIVILEGE/OBJECT"
		,privilege
	from
		user_tab_privs
	where
		grantor like 'SYS%'
	union
	select
		username GRANTEE	
		,privilege "PRIVILEGE/OBJECT"
		,'GRANTED' "PRIVILEGE"
	from
		user_sys_privs
/

exit

