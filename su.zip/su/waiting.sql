set lines 150
set feedback on
set pagesize 1000
column          sid format 99999
column          event format a25
column          module format a25
column      username format a12
column      seconds_in_wait format 999999
column      p1 format 999999999999

select b.sid, b.event, substr(a.action,1,1)||'-'||a.module module , a.username ,
      b.p1, b.p2,b.p3 ,b.seconds_in_wait from v$session_wait b, v$session  a
where b.event not in ('slave wait','SQL*Net message from client','rdbms ipc message',
'pmon timer','smon timer', 'pipe get','queue messages','wakeup time manager','jobq slave wait')
  and a.sid  = b.sid and b.wait_time=0 order by Last_call_ET;

