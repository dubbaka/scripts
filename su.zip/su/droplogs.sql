SQL> select 'alter table '||owner||'.'||table_name||' drop supplemental log group '||log_group_name||';' from all_log_groups;

'ALTERTABLE'||OWNER||'.'||TABLE_NAME||'DROPSUPPLEMENTALLOGGROUP'||LOG_GROUP_NAME||';'                                                                 
-------------------------------------------------------------------------------------------------------------------------------------                 
alter table AR.AR_CASH_RECEIPTS_ALL drop supplemental log group AR_CASH_RECEIPTS_ALL_LOG1;                                                            
alter table AR.AR_CASH_RECEIPTS_ALL drop supplemental log group AR_CASH_RECEIPTS_ALL_LOG2;                                                            
alter table AR.AR_CASH_RECEIPTS_ALL drop supplemental log group AR_CASH_RECEIPTS_ALL_LOG3;                                                            
alter table AR.AR_CASH_RECEIPTS_ALL drop supplemental log group AR_CASH_RECEIPTS_ALL_LOG4;                                                            
alter table AR.AR_PAYMENT_SCHEDULES_ALL drop supplemental log group AR_PAYMENT_SCHEDULES_ALL_LOG1;                                                    
alter table AR.AR_PAYMENT_SCHEDULES_ALL drop supplemental log group AR_PAYMENT_SCHEDULES_ALL_LOG2;                                                    
alter table AR.AR_PAYMENT_SCHEDULES_ALL drop supplemental log group AR_PAYMENT_SCHEDULES_ALL_LOG3;                                                    
alter table AR.AR_PAYMENT_SCHEDULES_ALL drop supplemental log group AR_PAYMENT_SCHEDULES_ALL_LOG4;                                                    
alter table AR.AR_PAYMENT_SCHEDULES_ALL drop supplemental log group AR_PAYMENT_SCHEDULES_ALL_LOG5;                                                    
alter table XXYH.GOTO_SALES_CAP_ALL drop supplemental log group GOTO_SALES_CAP_ALL_LOG1;                                                              
alter table XXYH.GOTO_SALES_CAP_ALL drop supplemental log group GOTO_SALES_CAP_ALL_LOG2;                                                              
alter table AR.RA_CUSTOMER_TRX_ALL drop supplemental log group RA_CUSTOMER_TRX_ALL_LOG2;                                                              
alter table AR.RA_CUSTOMER_TRX_ALL drop supplemental log group RA_CUSTOMER_TRX_ALL_LOG3;                                                              
alter table AR.RA_CUST_TRX_TYPES_ALL drop supplemental log group RA_CUST_TRX_TYPES_ALL_LOG3;                                                          
alter table XXYH.GOTO_BILL_TRANS_DETAILS drop supplemental log group GOTO_BILL_TRANS_DETAILS_LOG1;                                                    
alter table AR.RA_CUSTOMERS drop supplemental log group RA_CUSTOMERS_LOG1;                                                                            
alter table AR.RA_CUSTOMERS drop supplemental log group RA_CUSTOMERS_LOG2;                                                                            
alter table AR.RA_CUSTOMERS drop supplemental log group RA_CUSTOMERS_LOG3;                                                                            
alter table AR.RA_CUSTOMERS drop supplemental log group RA_CUSTOMERS_LOG4;                                                                            
alter table AR.RA_CUSTOMER_TRX_ALL drop supplemental log group RA_CUSTOMER_TRX_ALL_LOG1;                                                              
alter table AR.RA_CUSTOMER_TRX_ALL drop supplemental log group RA_CUSTOMER_TRX_ALL_LOG4;                                                              
alter table AR.RA_CUSTOMER_TRX_ALL drop supplemental log group RA_CUSTOMER_TRX_ALL_LOG5;                                                              
alter table AR.RA_CUSTOMER_TRX_ALL drop supplemental log group RA_CUSTOMER_TRX_ALL_LOG6;                                                              
alter table AR.RA_CUST_TRX_TYPES_ALL drop supplemental log group RA_CUST_TRX_TYPES_ALL_LOG1;                                                          
alter table AR.RA_CUST_TRX_TYPES_ALL drop supplemental log group RA_CUST_TRX_TYPES_ALL_LOG2;                                                          
alter table XXYH.GOTO_BILL_TRANS_TIMESTAMP drop supplemental log group GOTO_BILL_TRANS_TIMESTAMP_LOG1;                                                

26 rows selected.

SQL> spool off
