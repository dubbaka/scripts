set linesize 200
SELECT '! uuencode '||LOGFILE_NAME||' '||LOGFILE_NAME||' | mailx -s "'||request_id||'" ' from applsys.fnd_concurrent_requests WHERE request_id=&request_id;



