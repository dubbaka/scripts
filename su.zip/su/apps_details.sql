set pau off
set feedback off
set term off
set lines 132 
set pages 300
set head on

col Module_name format a11
col Application_name format a50
col Status format a15
col Patchset_level format a25


spool /usr/local/dba/tools/log/apps_details.log

select 	decode(nvl(a.APPLICATION_short_name,'Not Found'),
	'SQLAP','AP','SQLGL','GL','OFA','FA','Not Found','id '||to_char(fpi.application_id), a.APPLICATION_short_name) Module_name,
        fat.application_name Application_name,
        decode(fpi.status,'I','Installed','S','Shared',
               'N','Inactive',fpi.status) Status,
        nvl(fpi.patch_level,'-- Not Available --') Patchset_level
from 	apps.fnd_oracle_userid o, 
	apps.fnd_application a, 
	apps.fnd_product_installations fpi, 
	apps.fnd_application_tl fat
where 	fpi.application_id = a.application_id(+)
  and 	fpi.oracle_id = o.oracle_id(+)
  and 	a.application_id=fat.application_id
order by 2,1
/
spool off
/
exit
/
