set pages 66
spool userprog.lst
column	ProgName	format a20 word_wrapped
column  requestId	format 999999
column  StartDate	format a20 word_Wrapped
select  
		fcp.user_concurrent_program_name		progName,
		to_char(actual_Start_date,'DD-MON-YYYY HH24:MI:SS') StartDate,
		request_id											RequestId,
  		(actual_completion_date - actual_start_date)*24*60*60 ElapseTime
 from 	fnd_concurrent_requests fcr,
   		fnd_concurrent_programs_tl  fcp
where fcp.concurrent_program_id = fcr.concurrent_program_id
  and fcr.program_application_id	= fcp.application_id
  and fcp.language		= 'US'
  and fcr.phase_code	= 'C'
--  and fcp.user_concurrent_program_name like 'AutoCreate Final Assembly Orders%'
  and fcp.user_concurrent_program_name like 'Planning%Auto%'
--  and actual_start_date > sysdate - 1
-- where --concurrent_program_id = 42138
 order by &1 DESC
/
spool off
