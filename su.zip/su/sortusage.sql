-- Som - Script for sort usage .. will give total sort and per session sorts
set lines 200
set pages 150
col sid_serial form a12 trunc
col username form a10 trunc
col osuser form a10 trunc
col module form a50 trunc
col program form a50 trunc
col spid form a7 trunc
prompt "This is the total Sort Usage =====================>"
select a.tablespace_name, round(sum(a.bytes)/(1024*1024*1024),2) "Temp Size in GB", round(sum(b.blocks*8)/(1024*1024),2) "Temp Used in GB" from dba_temp_files a, v$sort_usage b
where a.tablespace_name=b.tablespace
group by a.tablespace_name ;
prompt "This is the Per Session Sort Usage(> 500 blocks) =====================>"
SELECT S.sid ||',' || S.serial# sid_serial, S.username, S.osuser, P.spid, S.module,
P.program, SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used, T.tablespace
FROM v$sort_usage T, v$session S, dba_tablespaces TBS, v$process P
WHERE T.session_addr = S.saddr
AND S.paddr = P.addr
AND T.tablespace = TBS.tablespace_name
GROUP BY S.sid, S.serial#, S.username, S.osuser, P.spid, S.module,P.program, TBS.block_size, T.tablespace
having sum(t.blocks) > 500
ORDER BY mb_used;
