select owner,tablespace_name,count(*),sum(bytes)/1024/1024/1024
from dba_segments where owner in (SELECT oracle_username FROM apps.fnd_oracle_userid 
WHERE read_only_flag IN ('E', 'A', 'U', 'M', 'K')
and segment_type !='SPACE HEADER' 
and oracle_username NOT IN ('SYS','SYSTEM')) 
and (tablespace_name not like 'APPS_%' or tablespace_name like '%_OATM')
and tablespace_name not in ('INTFD','INTFX','EXAMPLE','TOOLS','USER_DATA','USER_IDX','AMTO')
and (tablespace_name not like 'XX%' and tablespace_name not like 'OBT%' and tablespace_name not like 'EUL%' and tablespace_name not like '%CAT%' and tablespace_name not like 'TAX%' and tablespace_name not like 'GV%' and tablespace_name not like 'IND%' and tablespace_name not like 'CTX%' and tablespace_name not like 'DBS%' and tablespace_name not like 'XB%')
group by owner,tablespace_name
order by tablespace_name
/
