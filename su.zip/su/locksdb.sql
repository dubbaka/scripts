-- Added by Som to have a single scriopt showing locks in all nodes
set lines 180
set pages 200
spool /usr/local/dba/tools/logs/locks_monitor.lst
select  BLOCKING_INSTANCE,blocking_Session,SECONDS_IN_WAIT,inst_id,sid,serial#,event  from gv$session where blocking_Session is not null
-- and SECONDS_IN_WAIT > 300
order  by blocking_Session;
spool off;
--exit ;
