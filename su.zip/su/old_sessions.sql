set pages 0
select
--'ALTER SYSTEM KILL SESSION ' ||''''||sid||','|| serial#||''''||';'
action, module,status, to_char(logon_time,'DD-MON-YYYY HH24:MI:SS')  
from v$session 
where 
logon_time < sysdate -1  
 and action like 'FRM%' ;
-- and module like 'oracleADMN%';
--   and (module not like null or module not like '%JDBC%')
-- and (action like '%FRM%' or module like '%ADMN%');
