select s.inst_id,s.sid,s.serial#,a.value, s.username,s.machine
from gv$sesstat a, gv$statname b, gv$session s
where a.statistic# = b.statistic#  and s.sid=a.sid
and b.name = 'opened cursors current'
and a.value > 2000 order by 1;
