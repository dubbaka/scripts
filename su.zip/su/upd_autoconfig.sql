
-- If autoconfig is run on deposit (not on app01 and app02) then run following two updates after autoconfig and then copy dbc files from snapshots


update fnd_profile_option_values set profile_option_value=replace(profile_option_value,'erpprod.fin.corp.scd.yahoo.com','erpprod.fin.yahoo.com')
WHERE PROFILE_OPTION_VALUE like '%scd%'  and PROFILE_OPTION_VALUE like '%erpprod%';

UPDATE icx_parameters 
    SET    HOME_URL = 'https://erpprod.fin.yahoo.com:8000/OA_HTML/US/ICXINDEX_PRD_erpprod.htm';


--SELECT SUBSTR(e.profile_option_name,1,25) PROFILE,a.PROFILE_OPTION_VALUE ,replace(a.PROFILE_OPTION_VALUE,'erpprod.fin.corp.scd.yahoo.com','erpprod.fin.yahoo.com')
--FROM fnd_profile_option_values a, fnd_profile_options e
--WHERE 
--a.PROFILE_OPTION_VALUE like '%scd%'  and a.PROFILE_OPTION_VALUE like '%erpprod%'
--AND e.profile_option_id = a.profile_option_id 
--ORDER BY profile_option_name;

