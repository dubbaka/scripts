select /*+ index(I_EPS_ESL_PROCESS_SUBM_TIME */ e.production_id, e.raw_st, e.exact_canon_st,
         e.phrase_canon_st, e.url, nvl(u.site_lang_id, -345), e.title,
         e.description, e.tag, nvl(e.listing_lang_id, -345), e.listing_status,
         p.submission_item_id, p.submission_id, p.submission_action,
         p.submission_time, p.a_marketplace_id, p.a_account_id,
         p.created_by_source, p.created_by_system, p.work_type,
         p.bypass_ranking, p.force_manual, p.is_dup_immune, p.routing_type,
         p.approval_type, p.assigned_to, p.assigned_by, p.assigned_time,
         p.editorial_action, p.url_editorial_action, e.exact_bid,
         e.exact_bid_date, e.exact_status, e.phrase_status, e.broad_status,
         e.content_bid, e.content_bid_date, e.content_status, null, null,
         null, si.slr_id, slr.notes from eps_esl e, eps.eps_esl_process p,
         eps.eps_item_data_id i, eps.eps_url u, eps.eps_ui_slr_item si, eps.eps_ui_slr slr
         where e.submission_item_id = p.submission_item_id and
         e.submission_item_id = i.submission_item_id and i.data_id = u.data_id
         (+) and i.obj_type = 6 and e.submission_item_id =
         si.submission_item_id (+) and si.slr_id = slr.slr_id (+) and rownum
         <= :1 and (e.a_account_id = :2 and e.a_marketplace_id = :3 and
         p.submission_time >= :4)
