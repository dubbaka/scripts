create or replace function wait_sessf (p_sid NUMBER) return varchar2 
 IS 
    my_variab    VARCHAR2(2000); 
 BEGIN 
   select 'Proc-'||a.process||'Serial '||a.serial#||' SPID- '||b.spid||' Mod-'||module 
         into my_variab 
     from v$session a, 
          v$process b 
    where sid= p_sid 
      and a.paddr = b.addr; 
   return my_variab; 
 EXCEPTION 
 when no_data_found then 
 return null; 
 end; 
