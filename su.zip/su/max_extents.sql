set heading on; 
set pagesize 200; 
set feedback off; 
set term off; 
set linesize 132; 

spool /usr/local/dba/tools/log/max_extents.log


select  a.owner "Owner",
     	a.segment_name "Object",
    	a.tablespace_name "Tablespace",
     	a.segment_type  "Tab_Ind" ,
     	a.max_extents max_extents,
     	a.extents current_extent,
     	a.next_extent/1024 "Next_Extent_Size",
     	max_free_bytes/1024 free_bytes
  from  dba_segments a,
	(select tablespace_name,
        max(bytes) max_free_bytes
        from dba_free_space
        group by tablespace_name) b
        where b.max_free_bytes <= 2*(a.next_extent)
     	and a.max_extents - a.extents < = 50
 and    a.segment_type in ('TABLE','INDEX')
 and    a.tablespace_name = b.tablespace_name
/
spool off
/
exit
/
