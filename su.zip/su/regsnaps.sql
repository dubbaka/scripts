col name format a30
select owner,NAME,CAN_USE_LOG,REFRESH_METHOD,SNAPSHOT_ID from dba_registered_snapshots;
