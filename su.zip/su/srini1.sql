insert into gl_import_references (je_batch_id, je_header_id,
je_line_num, last_update_date, last_updated_by, creation_date,
created_by, last_update_login, reference_1, reference_2, reference_3,
reference_4, reference_5, reference_6, reference_7, reference_8,
reference_9, reference_10, gl_sl_link_id, gl_sl_link_table,
subledger_doc_sequence_id, subledger_doc_sequence_value) select
je_batch_id,je_header_id,je_line_num, sysdate, 0, sysdate, 0,
0, reference21,reference22,reference23, reference24, reference25,
reference26, reference27, reference28, reference29, reference30,
gl_sl_link_id, gl_sl_link_table, subledger_doc_sequence_id,
subledger_doc_sequence_value from GL_INTERFACE where user_je_source_name
= :p1 and   group_id = to_number(:p2) and   set_of_books_id
= :p3 and   request_id+0 = :p4 and   status = 'PROCESSED'
