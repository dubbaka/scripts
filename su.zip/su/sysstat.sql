select b.name, a.value
from v$sysstat a, v$statname b
where a.statistic# = b.statistic#
and a.value != 0
/
