exec dbms_sqltune.DROP_TUNING_TASK(task_name   => 'auditunmap');
set serveroutput on

declare
  l_sql_tune_task_id  varchar2(100);
begin
  l_sql_tune_task_id := dbms_sqltune.create_tuning_task (
                          sql_id      => 'bd6hgr4syck4v',
                          scope       => dbms_sqltune.scope_comprehensive,
                          time_limit  => 900,
                          task_name   => 'auditunmap',
                          description => 'bd6hgr4syck4v.');
  dbms_output.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);
end;
/

exec dbms_sqltune.execute_tuning_task(task_name => 'auditunmap');

SELECT SOFAR, TOTALWORK  FROM   V$ADVISOR_PROGRESS  WHERE   TASK_NAME = 'auditunmap';


set long 100000;
set longchunksize 1000
set pagesize 10000
set linesize 100
select dbms_sqltune.report_tuning_task('auditunmap') as recommendations from dual;

-***************************
--TO GET DETAILED INFORMATION
--***************************
SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK('auditunmap','TEXT','ALL','ALL') FROM DUAL;
