select module,executions, buffer_gets,sharable_mem, disk_reads, sql_text,rows_processed 
from v$sqlarea where hash_value = '&hash'
/
