 SELECT sid, serial#, substr(program,1,20) program, status,
        to_char(logon_time,'DD-MON-YY HH24:SS') Login_Time,
        to_char(sysdate-last_call_et/86400,'DD-MON-YY HH24:SS') Last_Activity
FROM v$session
WHERE program like 'JDBC%'
order by 5 desc
/
