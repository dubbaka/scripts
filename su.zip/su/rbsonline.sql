alter rollback segment &rbs_name online
/
