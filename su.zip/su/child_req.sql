select request_id,phase_code,status_code from fnd_concurrent_requests where parent_request_id=&paren_request_id ;
