select a.user_id, a.user_name, a.creation_date,a.start_date, a.end_date,
a.description,a.last_logon_date,a.EMPLOYEE_ID, a.EMAIL_ADDRESS , a.FAX , a.customer_id,a.supplier_id,
b.RESPONSIBILITY_ID, b.start_date , b.end_date, b.LAST_UPDATED_BY , b.LAST_UPDATE_DATE,
c.DESCRIPTION
from fnd_user a , fnd_user_resp_groups b , fnd_user c
where a.user_id = b.user_id (+)
and b.LAST_UPDATED_BY = c.USER_ID (+)
and b.responsibility_id = 20420
and b.end_date is null
and a.end_date is null
order by c.description
/
