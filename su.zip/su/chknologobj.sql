select file#,   '0x' || trim(to_char(unrecoverable_change#, '0xxxxxxxxxxx')) "UNRECOVERABLE_CHANGE#",  
unrecoverable_time  
from v$datafile 
