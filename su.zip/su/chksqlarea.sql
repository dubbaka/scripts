select substr(sql_text,1,50), count(*) from v$sqlarea
group by substr(sql_text,1,50) having count(*) >20
/
