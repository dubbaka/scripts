create or replace procedure lib_cache_hold_obj is
begin
 dbms_output.enable(1000000);
 for i in (SELECT distinct b.username,b.sid,decode(a.kglpnmod,0,'No pin /lock held',2,'share mode',3,'exclusive mode') kglpnmod, a.kglpnreq,
				  c.kglnaobj
           FROM SYS.x$kglpn a,v$session b,SYS.x$kglob c, v$session_wait d
           WHERE a.KGLPNUSE = b.saddr 
             and a.KGLPNHDL = c.KGLHDADR
			 and d.event like 'library cache pin%'
	         and d.sid = b.sid
) loop
  dbms_output.put_line('('||to_char(i.sid)||') - '||' '||i.kglpnmod||' '||i.kglpnreq||' '||i.username);
  dbms_output.put_line('SQL Statement '||i.kglnaobj);
  dbms_output.put_line('-------------------------------------');
 end loop;
end;
/
