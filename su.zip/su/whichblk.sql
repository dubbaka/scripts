col segment_name format a40 wrap
col segment_type format a30 wrap
SELECT owner,segment_name,segment_type 
FROM dba_extents 
WHERE file_id=&file 
AND &blockid BETWEEN block_id AND block_id + blocks 
/
