select MSG_STATE, to_char(min(enq_time), 'YYYY-MON-DD HH24:MI:SS'),    to_char(max(enq_time), 'YYYY-MON-DD HH24:MI:SS'), to_char(min(DEQ_TIME),   'YYYY-MON-DD HH24:MI:SS'), to_char(max(DEQ_TIME), 'YYYY-MON-DD HH24:MI:SS'),   count(*) 
from applsys.aq$wf_control
group by msg_state 
/
