alter tablespace APPS_TS_QUEUES add datafile '/erpoatm_oradata/ERPOATM/APPS_TS_QUEUES03.dbf' size 20g autoextend on maxsize 20g;
alter tablespace APPS_TS_QUEUES add datafile '/erpoatm_oradata/ERPOATM/APPS_TS_QUEUES04.dbf' size 20g autoextend on maxsize 20g;
alter tablespace APPS_TS_QUEUES add datafile '/erpoatm_oradata/ERPOATM/APPS_TS_QUEUES05.dbf' size 20g autoextend on maxsize 20g;
alter tablespace APPS_TS_QUEUES add datafile '/erpoatm_oradata/ERPOATM/APPS_TS_QUEUES06.dbf' size 20g autoextend on maxsize 20g;
alter tablespace APPS_TS_QUEUES add datafile '/erpoatm_oradata/ERPOATM/APPS_TS_QUEUES07.dbf' size 20g autoextend on maxsize 20g;
alter tablespace APPS_TS_QUEUES add datafile '/erpoatm_oradata/ERPOATM/APPS_TS_QUEUES08.dbf' size 20g autoextend on maxsize 20g;
alter tablespace APPS_TS_QUEUES add datafile '/erpoatm_oradata/ERPOATM/APPS_TS_QUEUES09.dbf' size 20g autoextend on maxsize 20g;
alter tablespace APPS_TS_QUEUES add datafile '/erpoatm_oradata/ERPOATM/APPS_TS_QUEUES10.dbf' size 20g autoextend on maxsize 20g;
