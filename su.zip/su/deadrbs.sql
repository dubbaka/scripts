select segment_name, segment_id
from dba_rollback_segs
where segment_id in (10,19)

