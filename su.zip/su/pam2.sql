declare
	l_COMPANY                                                                           VARCHAR2(25);
	 l_ACCOUNT                                                                           VARCHAR2(25);
	 l_SUB_ACCOUNT                                                                       VARCHAR2(25);
	 l_XXYH_PAM_BEGINNING                                                                NUMBER;
	 l_XXYH_PAM_BEGINNING_P                                                              NUMBER;
	 l_BEGINNING_BALALCE                                                                 NUMBER;
	 l_XXYH_PAM_CUR                                                                      NUMBER;
	 l_XXYH_PAM_CUR_P                                                                    NUMBER;
	 l_CURRENT_BALANCE                                                                   NUMBER;
	 l_ACCOUNT_NUMBER                                                           NUMBER;
	 l_PRODUCT                                                                  VARCHAR2(100);
	 l_PARTNER_NAME                                                                      VARCHAR2(100);
	 l_MARKET_PLACE                                                                      VARCHAR2(100);
	 l_ACCOUNT_ID                                                                        NUMBER;
	 l_CODE_COMBINATION_ID                                                               NUMBER(15);

begin

for i in ( SELECT z.company
     , z.ACCOUNT
     , z.sub_account
     , z.xxyh_pam_beginning
     , z.xxyh_pam_beginning_p
     , (NVL (z.xxyh_pam_beginning, 0) - NVL (z.xxyh_pam_beginning_p, 0))
                                                            beginning_balalce
     , z.xxyh_pam_cur
     , z.xxyh_pam_cur_p
     , (NVL (z.xxyh_pam_cur, 0) - NVL (z.xxyh_pam_cur_p, 0)) current_balance
     , z.account_number
     , z.product
     , z.partner_name
     , z.market_place
     , z.account_id
     , z.code_combination_id
   FROM (SELECT /*+ parallel(b,5) parallel(d,5) parallel(e,5) parallel(g,5) parallel(f,5) */  b.segment1 company
               , b.segment2 ACCOUNT
               , b.segment3 sub_account
               , nvl((SELECT SUM (NVL (a1.entered_cr, 0) - NVL (a1.entered_dr, 0))
                    FROM xxyh_pam_wb_gl_dists a1
                       , xxyh_pam_workbench c1
                       , xxyh_pam_accounts d1
                   WHERE a1.gl_ccid = b.code_combination_id
                     AND TO_DATE (a1.period, 'MON-RR') <
                            TO_DATE (apps.xxyh_disco_params.get_period
                                   , 'MON-RR'
                                    )
                     AND d1.account_id = d.account_id
                     AND c1.workbench_id = a1.workbench_id
                     AND c1.account_id = d1.account_id
                     AND c1.display_flag = 'Y'
                     AND c1.workbench_type = 'EXPENSE'),0) xxyh_pam_beginning
               , nvl((SELECT SUM (a1.acct_amount)
                    FROM xxyh_pam.xxyh_pam_wb_gl_dists a1
                       , xxyh_pam.xxyh_pam_workbench c1
                       , xxyh_pam.xxyh_pam_accounts d1
                       , ap.ap_invoices_all ai
                       , ap.ap_invoice_distributions_all b
                   WHERE a1.gl_ccid = b.code_combination_id
                     AND TO_DATE (b.period_name, 'MON-RR') <
                            TO_DATE (apps.xxyh_disco_params.get_period
                                   , 'MON-RR'
                                    )
                     AND d1.account_id = d.account_id
                     AND c1.workbench_id = a1.workbench_id
                     AND c1.account_id = d1.account_id
                     AND c1.display_flag = 'Y'
                     AND c1.generated_inv_num = ai.invoice_num
                     AND ai.invoice_id = b.invoice_id
                     AND c1.workbench_type = 'PAYMENT'),0) xxyh_pam_beginning_p
               , nvl((SELECT SUM (NVL (a1.entered_cr, 0) - NVL (a1.entered_dr, 0))
                    FROM xxyh_pam_wb_gl_dists a1
                       , xxyh_pam_workbench c1
                       , xxyh_pam_accounts d1
                   WHERE a1.gl_ccid = b.code_combination_id
                     AND a1.period =apps.xxyh_disco_params.get_period
                     AND d1.account_id = d.account_id
                     AND c1.workbench_id = a1.workbench_id
                     AND c1.account_id = d1.account_id
                     AND c1.display_flag = 'Y'
                     AND c1.workbench_type = 'EXPENSE'),0) xxyh_pam_cur
                   , nvl((SELECT SUM (nvl(a1.acct_amount,0))
                    FROM xxyh_pam_wb_gl_dists a1
                       , xxyh_pam_workbench c1
                       , xxyh_pam_accounts d1
                       , ap_invoices_all ai
                       , ap_invoice_distributions_all b
                   WHERE a1.gl_ccid = b.code_combination_id
                     AND b.period_name = apps.xxyh_disco_params.get_period
                     AND d1.account_id = d.account_id
                     AND c1.workbench_id = a1.workbench_id
                     AND c1.account_id = d1.account_id
                     AND c1.display_flag = 'Y'
                     AND c1.generated_inv_num = ai.invoice_num
                     AND ai.invoice_id = b.invoice_id
                     AND c1.workbench_type = 'PAYMENT'),0) xxyh_pam_cur_p
               , d.account_number
               , d.product
               , f.partner_name
               , g.market_place
               , b.code_combination_id
               , d.account_id
            FROM gl.gl_code_combinations b
               , xxyh_pam.xxyh_pam_accounts d
               , xxyh_pam.xxyh_pam_contracts e
               , xxyh_pam.xxyh_pam_partners f
               , xxyh_pam.xxyh_pam_market_places g
           WHERE e.partner_id = f.partner_id
             AND e.contract_id = d.contract_id
             AND d.market_id = g.market_id
             AND b.chart_of_accounts_id = 50388
             AND b.segment2 = 225600
             AND d.payer_org_id = 51
             AND EXISTS (SELECT NULL
                           FROM xxyh_pam.xxyh_pam_wb_gl_dists a
                          WHERE a.gl_ccid = b.code_combination_id)
        GROUP BY b.segment1
               , b.segment2
               , b.segment3
               , d.account_number
               , d.product
               , g.market_place
               , f.partner_name
               , d.market_id
               , b.code_combination_id
               , d.account_id) z ) loop 
 	l_COMPANY                     :=                    i.company;                          
	 l_ACCOUNT                    :=                    i.account;                            
	 l_SUB_ACCOUNT                :=                    i.sub_account;                               
	 l_XXYH_PAM_BEGINNING         :=                    i.XXYH_PAM_BEGINNING;                           
	 l_XXYH_PAM_BEGINNING_P       :=                    i.XXYH_PAM_BEGINNING_P;                          
	 l_BEGINNING_BALALCE          :=                    i.BEGINNING_BALALCE;                         
	 l_XXYH_PAM_CUR               :=                    i.XXYH_PAM_CUR;                           
	 l_XXYH_PAM_CUR_P             :=                    i.XXYH_PAM_CUR_P;                            
	 l_CURRENT_BALANCE            :=                    i.current_balance;                           
	 l_ACCOUNT_NUMBER             :=                    i.account_number;                         
	 l_PRODUCT                    :=                    i.product;                         
	 l_PARTNER_NAME               :=                    i.partner_name;                           
	 l_MARKET_PLACE               :=                    i.market_place;                             
	 l_ACCOUNT_ID                 :=                    i.account_id;                                
	 l_CODE_COMBINATION_ID        :=		    i.code_combination_id;

insert into apps.t1_tbd values ( l_company
     , l_ACCOUNT
     , l_sub_account
     , l_xxyh_pam_beginning
     , l_xxyh_pam_beginning_p
     , l_beginning_balalce
     , l_xxyh_pam_cur
     , l_xxyh_pam_cur_p
     , l_current_balance
     , l_account_number
     , l_product
     , l_partner_name
     , l_market_place
     , l_account_id
     , l_code_combination_id);
commit;
end loop;

end;

