SELECT t.* FROM v$session s, table(DBMS_XPLAN.DISPLAY_CURSOR(s.sql_id)) t WHERE sid=&SID;
