exec dbms_stats.SET_TABLE_STATS(ownname=>'&owner',TABNAME=>'&tablename',NUMROWS=>&numrows);

