 drop index applsys.WF_LOCAL_USER_ROLES_N7;
CREATE INDEX APPLSYS.WF_LOCAL_USER_ROLES_N7 ON APPLSYS.WF_LOCAL_USER_ROLES
(ROLE_ORIG_SYSTEM_ID, ROLE_ORIG_SYSTEM)
  INITRANS   11
  MAXTRANS   255
LOGGING
LOCAL (  
  PARTITION FND_USR
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_IDX
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             40K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION FND_RESP
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION POS
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             40K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION AMV_APPR
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_IDX
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION ENG_LIST
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION HZ_PARTY
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION GBX
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION PQH_ROLE
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION WF_LOCAL_ROLES
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION PER_ROLE
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION AMV_CHN
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION HZ_GROUP
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_IDX
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION HTB_SEC
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_DATA
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION UMX
    LOGGING
    NOCOMPRESS
    TABLESPACE APPS_TS_TX_IDX
    PCTFREE    10
    INITRANS   11
    MAXTRANS   255
    STORAGE    (
                INITIAL          40K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               )
)
NOPARALLEL;


