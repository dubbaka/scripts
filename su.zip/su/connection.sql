set heading on feedback on pages 66
column userinfo heading "ORACLE/OS User" format a19
column terminal heading "Term" format a6
column process heading "Parent|Process ID" format a10
column spid heading "Shadow|Process ID" format a10
column seq# heading "Wait|Sequence" format 99999990
select s.username||' '||s.osuser userinfo,s.terminal, s.sid, s.serial#,
p.spid,
s.process , w.seq#
from v$session s, v$process p
,v$session_wait w
where p.addr = s.paddr
and s.sid = w.sid
and w.event = 'SQL*Net message from client'
and s.status = 'INACTIVE'
order by s.osuser, s.terminal
