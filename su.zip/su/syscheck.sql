set feedback off
set linesize 200
set pagesize 500
set echo off
set serveroutput off
set heading off
select ' ************** TOTAL WAITS *********************************' from dual;
set heading on
select count(1) ,'total waits'
       from v$session_wait b, v$session  a
where event not in  ('queue messages','jobq slave wait','PX Deq: Table Q Normal','rdbms ipc message','smon timer','pmon timer', 
'SQL*Net message from client','lock manager wait for remote message', 'ges remote message', 'gcs remote message', 'gcs for action',
 'client message', 'pipe get', 'null event', 'PX Idle Wait', 'single-task message', 'PX Deq: Execution Msg', 
'KXFQ: kxfqdeq - normal deqeue', 'listen endpoint status','slave wait','wakeup time manager')
  and a.sid  = b.sid;

set heading off
select ' **********************WAITS********************************' from dual;
set heading on
column          sid format 99999
column          event format a25 word_wrapped
column          module format a15 word_wrapped
column      username format a9 word_wrapped
column      seconds_in_wait format 999999 word_wrapped
select b.sid, b.event, substr(a.action,1,1)||'-'||a.module module , a.username ,
      b.p1, b.p2,b.p3 ,b.seconds_in_wait 
from v$session_wait b, v$session  a
where event not in  ('queue messages','jobq slave wait','PX Deq: Table Q Normal','rdbms ipc message','smon timer','pmon timer',
'SQL*Net message from client','lock manager wait for remote message', 'ges remote message', 'gcs remote message', 'gcs for action',
 'client message', 'pipe get', 'null event', 'PX Idle Wait', 'single-task message', 'PX Deq: Execution Msg',
'KXFQ: kxfqdeq - normal deqeue', 'listen endpoint status','slave wait','wakeup time manager')
  and a.sid  = b.sid;


set heading off
select ' **********************GWAITS********************************' from dual;
set heading on



column state format a7 tru
column event format a25 tru
column last_sql format a90 tru
select  sw.sid,  sw.event, sw.seconds_in_wait seconds, sw.p1, sw.p2, sw.p3, sa.sql_text last_sql 
from gv$session_wait sw, gv$session s, gv$sqlarea sa 
where sw.event not in ('queue messages','jobq slave wait','PX Deq: Table Q Normal','rdbms ipc message','smon timer','pmon timer', 'SQL*Net message from client','lock manager wait for remote message', 'ges remote message', 'gcs remote message', 'gcs for action', 'client message', 'pipe get', 'null event', 'PX Idle Wait', 'single-task message', 'PX Deq: Execution Msg', 'KXFQ: kxfqdeq - normal deqeue', 'listen endpoint status','slave wait','wakeup time manager') 
and sw.seconds_in_wait > 0 and (sw.inst_id = s.inst_id and sw.sid = s.sid) and (s.inst_id = sa.inst_id and s.sql_address = sa.address) order by seconds desc;



set heading off
select ' **********************WAIT COUNT ***************************' from dual;
set heading on
select event,count(*) from v$session_wait --where event like '%TX%'
group by event;


set heading off
select ' **********************GLOCK*********************************' from dual;
set heading on
column state format a16 tru;
column event format a30 tru;
select dl.inst_id, s.sid, p.spid, dl.resource_name1, decode(substr(dl.grant_level,1,8),'KJUSERNL','Null','KJUSERCR','Row-S (SS)', 
'KJUSERCW','Row-X (SX)','KJUSERPR','Share','KJUSERPW','S/Row-X (SSX)',
'KJUSEREX','Exclusive',request_level) as grant_level, decode(substr(dl.request_level,1,8),
'KJUSERNL','Null','KJUSERCR','Row-S(SS)',
'KJUSERCW','Row-X (SX)','KJUSERPR','Share','KJUSERPW','S/Row-X (SSX)',
'KJUSEREX','Exclusive',request_level) as request_level, decode(substr(dl.state,1,8),'KJUSERGR','Granted','KJUSEROP','Opening',
'KJUSERCA','Canceling','KJUSERCV','Converting') as state, s.sid, sw.event, sw.seconds_in_wait sec 
from gv$ges_enqueue dl, gv$process p, gv$session s, gv$session_wait sw 
where blocker = 1 and (dl.inst_id = p.inst_id and dl.pid = p.spid) and (p.inst_id = s.inst_id and p.addr = s.paddr) and (s.inst_id = sw.inst_id and s.sid = sw.sid) order by sw.seconds_in_wait desc;


set heading off
select ' **********************HOLDING ENQUEUE***********************' from dual;
set heading on

column sess format a8 word_wrapped
column id1   format 99999999
column id2   format 99999999
column req       format 999
column type  format a4
column "Module" format a30 word_Wrapped
SELECT lpad('-->',DECODE(request,0,0,5),' ')||sid sess
       , id1
       , id2
       , lmode
      ,  request req, type, wait_sessf(sid) "Module"
FROM V$LOCK
 WHERE id1 IN (SELECT id1 FROM V$LOCK WHERE lmode = 0)
 ORDER BY id1,request




set heading off
select ' **********************LCK1***********************' from dual;
set heading on

column sess format a8 word_wrapped
column id1   format 99999999
column id2   format 99999999
column req       format 999
column type  format a4
column "Module" format a30 word_Wrapped
SELECT lpad('-->',DECODE(request,0,0,5),' ')||sid sess
       , id1
       , id2
       , lmode
      ,  request req, type, apps.wait_sessf(sid) "Module"
FROM V$LOCK
 WHERE id1 IN (SELECT id1 FROM V$LOCK WHERE lmode = 0)
 ORDER BY id1,request
/


set heading off
select ' **********************SORT**********************************' from dual;
set heading on

col module format a15
col username format a15
col tablespace format a15
col size format 999,999,999,999
SELECT s.sid,s.username,s.module,u.contents,segtype,TABLESPACE, sum((u.blocks * 8192)) "size"
FROM v$session s, v$sort_usage u
WHERE s.saddr=u.session_addr
and u.extents > 10
group by s.sid,s.username,s.module,u.contents,segtype,tablespace
order by 1,5;



set heading off
select ' **********************RBS**********************************' from dual;
set heading on
select a.sid, a.username, b.xidusn, b.used_urec, b.used_ublk
from v$session a, v$transaction b
where a.saddr=b.ses_addr;


set heading off
select ' **********************Jobs Running**********************************' from dual;
set heading on
column  user_name         format a20 word_wrapped
column  requestId       format 99999999
column  oracle_process_id       format a8
column  os_process_id   format a8
column  StartDate       format a15 word_Wrapped
select
                fcp.user_concurrent_program_name                progName,
                substr(fusr.description,1,19) user_name ,
                to_char(actual_Start_date,'DD-MON HH24:MI:SS') StartDate,
                request_id                                                                                      RequestId,
                fcr.oracle_process_id,
                nvl(fcr.os_process_id,fcpp.os_process_id) os_process_id ,
                sess.sid,
                (sysdate - actual_start_date)*24*60*60 ElapseTime
 from   apps.fnd_concurrent_requests fcr,
                apps.fnd_concurrent_programs_tl  fcp,
        apps.fnd_user fusr,
                v$session sess,
        apps.fnd_concurrent_processes fcpp
where fcp.concurrent_program_id = fcr.concurrent_program_id
  and fcr.program_application_id        = fcp.application_id
  and fcp.language              = 'US'
  and fcr.phase_code    in ('R')
  and fcr.status_code   in ('R','T')
  and fcr.requested_by = fusr.user_id
  and sess.process(+)=fcr.os_process_id
  and fcr.controlling_manager=fcpp.concurrent_process_id
 order by 3 DESC;

set heading off
select ' **********************total connections**********************************' from dual;
set heading on
col username format a50
select username,count(1) from v$session  group by username;
select count(1)||'-total connection'   from v$session ;


set heading off
select ' **********************Latch details added for latch free debug**********************************' from dual;

set echo on
set feedback on
set pages 10000
set linesize 200


-- Latch stats.
select name,gets,misses,sleeps
from v$latch
where name like 'library%';


-- Library cahche process id
select a.name,pid from v$latch a , V$latchholder b where a.addr=b.laddr
 and a.name = 'library cache%';


-- Number of waiters
select count(*) number_of_waiters
from v$session_wait w, v$latch l
where w.wait_time = 0
and  w.event     = 'latch free'
and  w.p2        = l.latch#
and  l.name      like 'library%';




--select * from v$session_wait
--where event != 'client message'
--and event not like '%NET%'
--and wait_time = 0
--and sid > 5;


-- Blocked / Blocker session
select n.name,b.sid "blocked", b.p1raw "want_address", c.sid "blocking", c.laddr "held_adddr"
from v$session_wait b, v$latchholder c ,v$latchname n
where b.event='latch free'
and  b.p2=n.latch#
and  b.p1raw=c.laddr
/


-- Process id  of latch for debugging.

select a.pid
from v$latchholder a,v$latch_children b
where a.laddr=b.addr
and b.latch# in (156,157);



set feedback on
set linesize 200
set echo off
set serveroutput on
set heading on

