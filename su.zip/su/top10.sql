set line 200
set pagesize 1000
set long 200000
col sql_text format a100 wrap
col per_exec format 99,999,999
col executions format 9,999,999
col rows_proc format 9,999,999,999
col buffer_gets format 9,999,999,999
col MB_per_disk format 9,999,999,999
col module format a50
spool top10sql.out
select * from (
select module,
       executions,
       (disk_reads/decode(nvl(executions,1),0,1,nvl(executions,1)) ) * (8) MB_per_disk,
       disk_reads ,
       sql_text ||chr(10)||'------------------------------------------------'
from v$sqlarea 
where (executions <= 10)
and disk_reads > 100000
and LAST_LOAD_TIME > sysdate-24
order by disk_reads desc
) where rownum < 11
/
spool off
