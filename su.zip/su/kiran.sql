select wu.name,hl.location_code,hl.description Loc_Descr
from    wf_users wu,
        per_all_assignments_f paf,
        hr_locations hl,
        fnd_user_resp_groups furg,
        fnd_responsibility_vl frv,
        fnd_application_tl fat,
        fnd_user fu
where   wu.orig_system_id = paf.person_id
and     trunc(sysdate) between paf.effective_Start_date and effective_end_date
and     paf.location_id = hl.location_id
and     furg.responsibility_id=frv.responsibility_id
and     fu.end_date is null
and     furg.responsibility_application_id != 178
and     fat.application_name not in ('Oracle Self-Service Web Applications')
and 1=2
group by        wu.name,hl.location_code,hl.description
order by 3,1
/
