set pagesize 9999;
set verify off;
set feedback off;
set linesize 180;

column uname         HEADING 'User Name'       FORMAT A12;
column description   HEADING 'Apps User'       FORMAT A12;
column shrtnam       HEADING 'Application'     FORMAT A08;
column respnam       HEADING 'Responsibility'  FORMAT A10;
column frmnam        HEADING 'Form'            FORMAT A10;
column sid           HEADING 'sid'             FORMAT 999999;
column serial#       HEADING 'Serial'          FORMAT 999999;
column spid          HEADING 'Server|Process'  FORMAT 999999;
column suser         HEADING 'Client|OS User'  FORMAT A8;
column process       HEADING 'Client|Process'  FORMAT A8;
column smach         HEADING 'Client|Machine'  FORMAT A8;
column sprog         HEADING 'Program'         FORMAT A10 WORD_WRAPPED;
column cli           HEADING 'Client Info'     FORMAT A10 WORD_WRAPPED;

select usr.user_name uname,
       usr.description apps_user, 
       vsess.sid sid,
       vsess.serial# serial,
       vproc.spid spid,
       vsess.osuser suser,
       vsess.machine smach,
       vsess.program sprog,
       frm.form_name frmnam
from   applsys.fnd_logins l,
       applsys.fnd_application app,
       applsys.fnd_login_responsibilities lresp,
       applsys.fnd_login_resp_forms lform,
       applsys.fnd_responsibility resp,
       applsys.fnd_form frm,
       applsys.fnd_user usr,
       v$process vproc,
       v$session vsess
where l.login_id = lresp.login_id (+)
  and l.login_id = lform.login_id (+)
  and app.application_id (+) = resp.application_id
  and l.user_id = usr.user_id
  and lresp.responsibility_id = resp.responsibility_id (+)
  and lresp.resp_appl_id = resp.application_id (+)
  and lform.form_id = frm.form_id (+)
  and lform.form_appl_id = frm.application_id (+)
  and l.end_time is NULL
  and lresp.end_time is NULL
  and lform.end_time is NULL
  and l.spid = vsess.process
  and l.login_name = vsess.osuser
  and vproc.addr = vsess.paddr (+)
  and upper(usr.user_name) like upper('%&username%')
  and upper(usr.description) like upper('%&AppsUsername%')
/
 
