select n.name,b.sid "blocked", b.p1raw "want_address", c.sid "blocking", c.laddr "held_adddr"
from v$session_wait b, v$latchholder c ,v$latchname n
where b.event like '%latch free%'
--and  b.p2=n.latch#
and  b.p2=&p2
and  b.p1raw=c.laddr
/
