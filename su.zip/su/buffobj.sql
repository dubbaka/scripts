
compute sum of blocks on report
column pool_name format a9
column object format a24
column sub_name format a24
column blocks format 999,999
break on pool_name
set pagesize 60
set newpage 0
spool /tmp/buff_obj
select
	/*+ ordered */
	bp.name				pool_name,
	ob.name				object, 
	ob.subname			sub_name, 
	sum(ct)				blocks
from
	(
	select
		set_ds,
		obj,
		count(*) ct
	from
		x$bh
	group by
		set_ds, 
		obj
	having count(*)/5 > (
			select max(set_count) 
			from v$buffer_pool
			)
	)			bh,
	obj$			ob,
	x$kcbwds		ws,
	v$buffer_pool		bp
where
	ob.dataobj# = bh.obj
and	ob.owner# > 0
and	bh.set_ds = ws.addr
and	ws.set_id between bp.lo_setid and bp.hi_setid
and	bp.buffers != 0		--  Eliminate any pools not in use
group by
	bp.name,
	ob.name,
	ob.subname
order by
	bp.name,
	ob.name,
	ob.subname
;
spool off

