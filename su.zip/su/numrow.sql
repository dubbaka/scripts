select count(1) from &schema..&table
/

