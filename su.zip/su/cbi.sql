create table Neil_cbi as 
SELECT
            CP.cust_account_id customer_id,
            site_uses.site_use_id  site_id,
            NVL(site_uses.payment_term_id,
		NVL(SP.standard_terms,
                    NVL(CP.standard_terms,T.term_id)))  term_id,
            acct_site.cust_acct_site_id,
            NVL(SP.cons_inv_type,
                NVL(CP.cons_inv_type,'SUMMARY'))    	cons_inv_type,
            TL1.due_day_of_month                    	day_due,
            TL1.due_months_forward                  	months_forward
     FROM
       	    HZ_CUST_PROFILE_CLASSES cpp,
	    HZ_CUST_PROFILE_CLASSES spp,
            hz_cust_accounts     cust_acct,
            hz_customer_profiles CP,
            hz_customer_profiles SP,
            hz_cust_site_uses    site_uses,
            hz_cust_acct_sites   acct_site,
            ra_terms             T,
            ra_terms_lines       TL1
     WHERE site_uses.site_use_code    = 'BILL_TO'
     AND cpp.name                = NVL(c_Profile_Name, cpp.name)
     AND spp.PROFILE_CLASS_ID(+) = sp.PROFILE_CLASS_ID
     AND cpp.PROFILE_CLASS_ID(+) = cp.PROFILE_CLASS_ID
     AND    ((C_term_id             IS NULL)
           OR
             ((C_term_id            IS NOT NULL) AND
              (C_term_id            =  NVL(site_uses.payment_term_id,
                                           NVL(SP.standard_terms,
                                               CP.standard_terms)))))
     AND    site_uses.site_use_id    = NVL(C_site_use_id, site_uses.site_use_id)
     AND    SP.site_use_id(+)      = site_uses.site_use_id
     AND    T.term_id		   = NVL(C_term_id, T.term_id)
     AND    T.term_id              = NVL(site_uses.payment_term_id,
				         NVL(SP.standard_terms,
		                             CP.standard_terms))
     AND    T.due_cutoff_day       = TO_DATE ('&C_cutoff_day','YYYY/MM/DD HH24:MI:SS')
     AND    TL1.term_id            = T.term_id
     AND    TL1.due_day_of_month   IS NOT NULL
     AND    TL1.due_months_forward IS NOT NULL
     AND    1                      = (SELECT COUNT(*)
                                        FROM ra_terms_lines TL2
                                       WHERE TL2.term_id = TL1.term_id)
     AND    acct_site.cust_acct_site_id = site_uses.cust_acct_site_id
     AND    cust_acct.cust_account_id         = acct_site.cust_account_id
     AND    cust_acct.account_number = NVL(P_customer_number,cust_acct.account_number)
     AND    CP.cust_account_id         = acct_site.cust_account_id
     AND    CP.site_use_id 	   IS NULL
--   AND    CP.cust_account_id         = nvl(P_customer_id, CP.cust_account_id) removed by sami
     AND    CP.cust_account_id    BETWEEN  &c_customer_id_fr AND &c_customer_id_to  --added by sami
     AND    NVL(SP.cons_inv_flag, CP.cons_inv_flag)  = 'Y'
     AND    NVL(SP.cons_inv_type,
                NVL(CP.cons_inv_type,
                    'SUMMARY'))    = '&C_detail_option'
     AND    NOT EXISTS
               (SELECT NULL
                FROM ar_cons_inv CI
                WHERE CI.site_use_id = site_uses.site_use_id
                AND CI.cut_off_date  = TO_DATE(C_cutoff_date)
                AND CI.currency_code = P_currency
                AND CI.status <> 'REJECTED');
