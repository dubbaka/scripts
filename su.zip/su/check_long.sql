
declare
         cursor my_cursor is
             select view_name,owner,text  
             from   all_views; 
          v_text varchar2(32767); 
          v_viewname varchar2(100);
          v_viewowner varchar2(100);

          begin 
            open my_cursor; 
            loop 
              fetch my_cursor into v_viewname,v_viewowner,v_text; 
              exit when my_cursor%notfound; 
              if v_text LIKE '%OFIN%'
              then
                 dbms_output.put_line('Info '||v_viewname||':'||v_viewowner||':'||v_text);
              else
 
                 dbms_output.put_line('No Match: '||v_viewname||':'||v_viewowner||':'||v_text);

              end if;
          end loop; 
          close my_cursor; 
          end; 
