col username format a20 
col machine format a40
col nbr_users format 99999 compute sum on nbr_users 
select username,machine,count(*) nbr_users from v$session group by username,machine
/
