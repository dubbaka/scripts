select request_id,user_name,p.user_concurrent_program_name progName,argument_text,  phase_code,status_code,to_char(actual_start_date,'DD-MON-YY HH24:MI:SS') "Start",to_char(actual_completion_date,'DD-MON-YY HH24:MI:SS') "End" from applsys.fnd_concurrent_requests r,apps.fnd_user u,apps.fnd_concurrent_programs_tl p, gv$session s where  actual_completion_date like '14-DEC-09'
/
