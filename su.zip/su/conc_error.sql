select b.user_concurrent_program_name NAME,c.user_name USER_NM,a.request_id,to_char(a.actual_completion_date,'DD-MON-YYYY HH24:MI:SS') from apps.fnd_concurrent_requests a, apps.fnd_concurrent_programs_tl b, apps.fnd_user c
where a.concurrent_program_id=b.concurrent_program_id
and trunc(a.actual_start_date) >= trunc(sysdate -1/4 )
and a.requested_by=c.user_id
and a.phase_code='C' and a.status_code='E'
order by to_char(a.actual_completion_date,'DD-MON-YYYY HH24:MI:SS')
/
