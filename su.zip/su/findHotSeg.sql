REM +=======================================================================+
REM |    Agilent Technologies, Colorado Springs                             |
REM |    All rights reserved.                                               |
REM |    $Header: findHotSeg.sql 01-Mar-03       Agilent Technologies    $  |
REM +=======================================================================+
REM   FILENAME
REM     findHotSeg.sql
REM
REM   PURPOSE
REM    This script will query the table xxat_dba_wait_event_t1
REM    and findout the hot segment, i.e. contention on the segment
REM
REM   Usage:
REM        sqlplus <dbsuser/pwd> @findHotSeg.sql
REM
REM   HISTORY
REM
REM   02-MAR-03   Abhay Shastri     Created
REM==========================================================================

set lines 132;
col segment_name for a30;
col segment_type for a20;
col EventName for a35 word_wrap;

select c.p1 file_id, c.p2 block_id, b.segment_name, b.segment_type, event EventName
  from dba_extents b,
       ( select p1, p2,event
          from XXAT_DBA_WAIT_EVENT_T1
         group by p1,p2,event having count(*) > 3
        ) c
 where b.file_id = c.p1
   and c.p2 between b.block_id and (b.block_id + b.blocks -1 )
/
