DECLARE
	v_started NUMBER;
BEGIN
	SELECT decode(status, 'ENABLED', 1, 0) INTO v_started
	FROM DBA_APPLY WHERE APPLY_NAME = 'STRMADMIN_APPLY';
	if (v_started = 0) then
	  DBMS_APPLY_ADM.START_APPLY(apply_name  => 'STRMADMIN_APPLY');
	end if;
END;
/
