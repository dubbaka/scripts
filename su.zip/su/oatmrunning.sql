select hash_value, sql_text from v$sqltext where hash_value = (select sql_hash_value from v$session where sid =191) order by piece
/
