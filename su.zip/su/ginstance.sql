select * from gv$instance
/
