set lines 180
set pages 200
col "Blocking Inst/Sid" form a20 trunc
col "Blocked Inst/Sid" form a20 trunc
col "Wait(Secs)" form 9999999999 trunc
col  blocking_action_module form a40 trunc
col blocked_action_module form a40 trunc
col action form a25 trunc
col module form a25 trunc
col BLOCKED_MC_TERMINAL form a50 trunc
col BLOCKING_PROGRAM form a60 trunc
col BLOCKING_MC_TERMINAL form a50 trunc
col BLOCKED_PROGRAM form a60 trunc
select  a.BLOCKing_INSTANCE||' - '||a.blocking_Session "Blocking Inst/Sid",b.action||' / '||b.module blocking_action_module, b.program Blocking_Program,
b.machine||' - '|| b.terminal Blocking_mc_terminal,
a.inst_id||' - '||a.sid "Blocked Inst/Sid",a.action||' / '||a.module  blocked_action_module, a.program Blocked_Program,
a.machine||' - '|| a.terminal Blocked_mc_terminal, a.event, a.SECONDS_IN_WAIT "Wait(Secs)"
  from gv$session a, gv$session b
where a.blocking_Session is not null and nvl(a.action,'a') not like '%FRM%'
and nvl(b.action,'a') not like '%FRM%'
and b.sid=a.blocking_session and b.inst_id=a.blocking_instance
and a.SECONDS_IN_WAIT > 300
order by a.BLOCKing_INSTANCE||' - '||a.blocking_Session;

