      column total_bytes format 9999999 heading 'Total|Bytes'
      column "OBJECT" format A25
      column type format A15

      select    'exec dbms_shared_pool.keep('''||owner || '.' || name ||''');'
      from      v$db_object_cache
      where     type in ('FUNCTION','PACKAGE','PACKAGE BODY','PROCEDURE')
      and       owner not in ('SYS','SYSTEM')
      and       kept = 'NO'
      --and       executions > 1000
      and       loads > 100 and executions < 500
      order by owner, name;


