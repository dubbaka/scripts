oradebug setorapid &Pid
oradebug suspend
