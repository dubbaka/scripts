set pages 100
set verify off
set echo off
set linesize 180
prompt Enter concurrent program name in full or part in correct case
prompt
accept prg_nm prompt 'PROGRAM_NAME->'
prompt
prompt Enter date of execution of the program
accept strt_dt prompt 'STARTING DATE OF EXECUTION->'
prompt
accept end_dt prompt 'ENDING DATE OF EXECUTION->'
prompt
column request_id format 99999999
column name format a30
break on NAME on USER_NM
--break on USER_NM skip 1
column ex_time format 999999.99
column user_nm format a10
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS'
/
select b.user_concurrent_program_name NAME,c.user_name USER_NM,a.request_id,(a.actual_completion_date-a.actual_start_date)*24*60 "EX_TIME",
       a.actual_start_date "START_DT",a.actual_completion_date "COMPLETION_DT"
from apps.fnd_concurrent_requests a, apps.fnd_concurrent_programs_tl b, apps.fnd_user c
where a.concurrent_program_id=b.concurrent_program_id
and upper(b.user_concurrent_program_name) like upper('%&prg_nm%')
--and b.language='US'
and trunc(a.actual_start_date) between '&strt_dt' and nvl('&end_dt','&strt_dt')
and a.requested_by=c.user_id
order by 1,2,5
/
