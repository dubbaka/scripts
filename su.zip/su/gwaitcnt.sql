select event,count(*) from gv$session_wait --where event like '%TX%' 
group by event
/
