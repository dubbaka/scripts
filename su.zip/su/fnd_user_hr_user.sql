select
p.full_name, u.user_name,user_id
from apps.fnd_user u, apps.per_all_people_f p
where u.employee_id=p.person_id
and trunc(sysdate) between u.start_date and nvl(u.end_date,sysdate+1)
and trunc(sysdate) between p.effective_start_date and p.effective_end_date
and Hr_Person_Type_Usage_Info.get_user_person_type(SYSDATE,p.PERSON_ID) like 'Ex%'
/
