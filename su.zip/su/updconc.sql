update apps.fnd_concurrent_requests 
SET phase_code= 'C' ,  status_code = 'E' where REQUEST_ID = &1
/

commit 
/


