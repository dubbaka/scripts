
create or replace function mysessf(p_addr raw)
  return number
IS
 my_variab number := -1;
BEGIN

  select sid into my_variab from v$lock
  where id1 = ( select id1
                from V$lock a
                where a.kADDR = p_addr)
  and lmode !=0
;

  return my_variab;

EXCEPTION
when no_data_found then
return -1;
end;
