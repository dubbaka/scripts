set line 132
set pagesize 1000
col username format a10 wrap
col name format a10 wrap
col action format a35 
col module format a10
col space_used format 9,999,999,999,999
select a.username,a.sid,r.name,b.start_time,a.module,a.action, (b.used_ublk * 8192) space_used
from v$session a, v$transaction b,v$rollname r
where a.saddr=b.ses_addr
and b.xidusn = r.usn
order by 4 desc 
/
