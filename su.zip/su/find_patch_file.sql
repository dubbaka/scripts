set lines 132
column patch_version format a15 heading 'Patch File Ver'
column onsite_file_version format a15 heading 'Onsite Ver'
column filename format a15
column bug_number format a10 heading 'Bug!'
column executed_flag format a6 heading 'EFlag!'
column application_short_name format a5 heading 'APPL'
column pdate format a12 heading 'Patch Date'
select f.bug_number , f.application_short_name,a.filename, c.version patch_version, d.version onsite_file_version,
	b.executed_flag, b.creation_date pdate
from ad_files a, ad_patch_run_bug_actions b, ad_file_versions c, ad_file_versions d ,
	ad_patch_run_bugs e, ad_bugs f
where a.filename ='&fname'
and a.file_id = b.file_id
and c.file_version_id = b.patch_file_version_id
and d.file_version_id = b.onsite_file_version_id
and e.bug_id = f.bug_id
and e.patch_run_bug_id = b.patch_run_bug_id
order by b.creation_date desc
/
