set pages 1000
set lines 120
col inst format 9999
col sid format 999999
col event format a29 trunc
col program format a20 trunc
col module format a20 
col username format A11 
col secs format 99999
select w.inst_id inst, w.sid, w.event,s.module,s.username,w.p1,w.p2,w.p3,w.seconds_in_wait Secs
from gv$session_wait w, gv$session s
where w.inst_id = s.inst_id and
      w.sid=s.sid and w.state='WAITING' and
      w.event not in ('pmon timer',
           'smon timer',
           'rdbms ipc message',
           'pipe get',
           'SQL*Net message from client',
           'SQL*Net message to client',
           'SQL*Net break/reset to client',
           'SQL*Net more data from client',
           'wakeup time manager',
           'slave wait',
           'SQL*Net more data to client') and w.event not like '%slave wait'
group by w.inst_id, w.sid,w.event,s.module,s.username,w.p1,w.p2,w.p3,w.seconds_in_wait
order by 1,3;
