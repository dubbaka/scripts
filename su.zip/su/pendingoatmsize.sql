col segment_name for a30
set lines 200
SELECT /*+ parallel 4 */ OWNER,SEGMENT_TYPE,round(sum(BYTES/1024/1024)),count(*) FROM DBA_SEGMENTS WHERE  owner in ('APPS','AR','APPLSYS') AND TABLESPACE_NAME NOT LIKE 'APPS_%' and TABLESPACE_NAME NOT LIKE 'XXYH%' and TABLESPACE_NAME NOT LIKE 'OBT%' group by owner,segment_type order by 3
/

