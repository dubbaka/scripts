set lines 100
column table_name format a30
column index_name format a30
column column_name format a30
break on table_name skip 1 on index_name skip 1
select table_name, index_name, column_name
from dba_ind_columns where index_name like '%XXAT%'
and table_name not like 'XXAT%'
order by table_name, index_name, column_position
/
