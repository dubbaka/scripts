select * from (select  sid,module, to_char(logon_time,'DD-MON-YYYY HH24:MI:SS') ,SECONDS_IN_WAIT/60,sum(pga_used_mem)/(1024*1024),sum(pga_alloc_mem)/(1024*1024) from v$process , v$session where addr=paddr and status not like 'KILLED'  and module like '&module' group by sid,module,LOGON_TIME,SECONDS_IN_WAIT order by 3 desc)
/
