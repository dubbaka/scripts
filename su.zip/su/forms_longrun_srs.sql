 select to_char(logon_time,'DD-MON-YYYY HH24:MI:SS'),action,module,status,process,machine from v$session  where action like 'FRM%' and  logon_time <= sysdate-16/24 order by machine
/

select 'ALTER SYSTEM KILL SESSION ' ||''''||sid||','|| serial#||''''||';' from v$session  where action like 'FRM%' and  logon_time <= sysdate-16/24
;

