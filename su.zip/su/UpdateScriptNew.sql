DECLARE 
  CURSOR C1 is
   SELECT org_id 
     FROM goto_set_of_books_currency ;

BEGIN

  FOR c1_count in c1 LOOP

    UPDATE /*+ PUSH_SBQ INDEX(pay idx4) */ 
        AR_PAYMENT_SCHEDULES_ALL pay 
        SET     ( CONS_INV_ID, 
                  CONS_INV_ID_REV )= 
                ( SELECT /*+ parallel (cash,8) INDEX(cash idx3) */  TO_NUMBER(attribute10),  
                         TO_NUMBER(attribute12) +  9000000 
       FROM AR_CASH_RECEIPTS_ALL  cash
      WHERE 
          cash.cash_receipt_id = pay.cash_receipt_id  
       AND cash.org_id = c1_count.org_id)  -- org_id for the new markets 
      WHERE 
         EXISTS ( SELECT /*+ parallel(cash,8) INDEX(cash idx3) */  'x'   FROM  AR_CASH_RECEIPTS_ALL  cash
                  WHERE
               cash.cash_receipt_id = pay.cash_receipt_id
        AND cash.org_id = c1_count.org_id ) AND
        pay.gl_date < '01-Dec-05'  ;


    
    UPDATE /*+ PUSH_SBQ INDEX(pay idx4) */ 
        AR_PAYMENT_SCHEDULES_ALL pay 
        SET     ( CONS_INV_ID, 
                  CONS_INV_ID_REV )= 
                ( SELECT cons.cons_inv_id , 
                         cons.cons_inv_id_rev+9000000 
       FROM xxyh_conv.xxyh_cons_id  cons,
            AR_CASH_RECEIPTS_ALL    CASH 
      WHERE 
          cash.cash_receipt_id        = pay.cash_receipt_id  
       AND TO_NUMBER(cash.attribute6) = cons.cash_receipt_id
       AND cash.org_id = c1_count.org_id)  -- org_id for the new markets 
      WHERE 
         EXISTS ( SELECT 'x' FROM  AR_CASH_RECEIPTS_ALL  cash
                  WHERE
               cash.cash_receipt_id = pay.cash_receipt_id
               AND cash.org_id      = c1_count.org_id)
      AND pay.gl_date >= '01-Dec-05'   ;

  END LOOP ;

END ;
/
