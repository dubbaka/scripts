Set pages 200
Set lines 200
Explain plan for 
select distinct furg.responsibility_id, furg.responsibility_application_id, furg.security_group_id, furg.start_date, furg.end_date from fnd_user_resp_groups furg, fnd_responsibility fr where furg.user_id = :1 and furg.responsibility_id = fr.responsibility_id and furg.responsibility_application_id = fr.application_id and furg.start_date <= sysdate and (furg.end_date is null or furg.end_date >= sysdate) and fr.start_date <= sysdate and  (fr.end_date is null or fr.end_date >= sysdate) order by furg.responsibility_id, furg.responsibility_application_id, furg.security_group_id;
@?/rdbms/admin/utlxpls
/
