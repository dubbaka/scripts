set linesize 200

SELECT '! uuencode '||OUTFILE_NAME||' '||OUTFILE_NAME||' | mailx -s "'||request_id||'" ' from applsys.fnd_concurrent_requests WHERE request_id=&request_id;

