create or replace view neil_test as
SELECT 
--/*+ index(GOTO_PAYMENT_TRANSACTION_N2,a) */
mp_invoice account, 
advertiser_id advid, 
funding_event_date trx_date, 
identification_info receipt_number, 
meaning payment_method, 
payment_method_id payment_method_code, 
'PendingReceipt' transaction_class, 
identification_info cc_number, 
NULL cc_exp_date, 
TO_CHAR(amount_billed) amt_billed, 
amount_received orig_amt, 
amount_received amt_remaining, 
comments comments, 
operator_name operator_name, 
approval_code approval_code, 
response_message response_code, 
TO_CHAR(batch_id) batch_id, 
NULL of_trans_number, 
TO_CHAR(batch_id) operator, 
site_use_id of_account_id, 
TO_NUMBER(NULL) payment_schedule_id, 
NULL billing_number, 
a.organization, 
a.amount_net_recvd amt_net_orig, 
a.amount_vat_recvd amt_tax_orig, 
a.amount_gross_recvd amt_gross_orig, 
a.amount_gross_recvd amt_gross_remaining, 
meaning       payment_method_nls, 
reference_number 
FROM goto_payment_transaction a, 
apps.ar_lookups b, 
apps.ra_site_uses_morg c 
WHERE payment_method_id=b.lookup_code 
AND b.lookup_type='GOTO_REC_PYMT_ID' 
AND a.status ='N' 
AND c.location=a.mp_invoice
