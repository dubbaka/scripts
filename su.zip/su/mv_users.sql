select count(markview_session_id), msl.user_id
from mv_session_log msl
where trunc(msl.logon_timestamp) = trunc(sysdate)
and msl.client_program = 'WEBCLIENT'
group by msl.user_id
order by count(markview_session_id)
/
