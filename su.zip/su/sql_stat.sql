select  n.name, s.value
from v$statname n ,  v$sesstat s
where s.sid = &sid
and   n.statistic# = s.statistic#
order by n.class, n.name


