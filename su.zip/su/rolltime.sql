SELECT * FROM v$fast_start_transactions
/
