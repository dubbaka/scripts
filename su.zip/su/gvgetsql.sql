break on hash_value
set pagesize 1000
set long 200000
col sql_text format a60
select hash_value, sql_text
from gv$sqlarea a, gv$session b
where a.hash_value = b.sql_hash_value 
and a.inst_id = b.inst_id 
and b.sid = &sid
and b.inst_id = &inst_id
--order by piece
/
