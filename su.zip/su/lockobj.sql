column owner format a10
column name format a30
column type format a20
column locks format 99999

select owner,name,type,locks from  V$DB_OBJECT_CACHE WHERE name=upper('&object_name')
/
