set serveroutput on
exec fnd_stats.verify_stats('&owner','&table')
/

