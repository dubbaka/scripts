ALTER INDEX XXYH.XXYH_AR_CONS_INV_ALL_N5 rebuild tablespace xxyhx_new parallel 4 nologging;
ALTER INDEX APPS.XXYH_AR_PAYMENT_SCHEDULES_N17 rebuild tablespace xxyhx_new parallel 4 nologging;
ALTER INDEX XXYH_CAM.XXYH_HZ_CUST_ACCTS_ATT5_N1 rebuild tablespace xxyhx_new parallel 4 nologging;
ALTER INDEX XXYH.XXYH_HZ_PARTIES_N18 rebuild tablespace xxyhx_new parallel 4 nologging;
ALTER INDEX XXYH.IDX_VURV_CANDIDATES_STAT rebuild tablespace xxyhx_new parallel 4 nologging;

