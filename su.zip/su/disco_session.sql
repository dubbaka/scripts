SELECT s.SID,s.serial#,s.MODULE,s.MACHINE,s.osuser,P.SPID "Server Process ID",S.PROCESS "Client Process",
TO_CHAR(s.LOGON_TIME,'DD-MON-YYYY HH24:MI:SS') "Login Time",
s.Status,w.seconds_in_wait,w.event 
from v$session s,v$process p ,v$session_wait w 
where p.addr = s.paddr and s.MODULE='Discoverer4' and s.sid=w.sid;
