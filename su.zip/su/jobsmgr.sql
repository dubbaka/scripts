set pages 66
set feed on
set line 132
spool progs1.lst
col     user_name       format a20 word_wrapped
column	ProgName	format a25 word_wrapped
column  requestId	format 9999999
column  StartDate	format a20 word_Wrapped
column  Manager     format a10
column  SERVER   format a6 
column  CLIENT   format a6 
column  ETime           format 99999 word_Wrapped 
col     sid             format 99999 word_Wrapped

select  sess.sid,
        fcr.oracle_process_id SERVER,
        fcr.os_process_id CLIENT,
        fusr.description user_name ,  
        fcq.concurrent_queue_name Manager,     
	fcp.user_concurrent_program_name		progName,
	to_char(actual_Start_date,'DD-MON-YYYY HH24:MI:SS') StartDate,
	request_id											RequestId,
  	(sysdate - actual_start_date)*24*60*60 ETime
from 	fnd_concurrent_requests fcr,
   	fnd_concurrent_programs_tl  fcp,
    fnd_concurrent_processes  fcpr,
    fnd_concurrent_queues fcq,
        fnd_user fusr,
        v$session sess
where fcp.concurrent_program_id = fcr.concurrent_program_id
  and fcr.program_application_id	= fcp.application_id
  and fcp.language		= 'US'
  and fcr.phase_code	= 'R'
  and fcr.status_code	= 'R'
  and fcr.requested_by = fusr.user_id
  and fcr.oracle_session_id = sess.audsid (+) 
  and fcr.oracle_session_id is not null
  and fcr.controlling_manager = fcpr.concurrent_process_id
  and fcpr.concurrent_queue_id = fcq.concurrent_queue_id
--  and p.addr = sess.paddr
UNION
select  sess.sid,
        proc.spid SERVER  ,
        fcpr.os_process_id CLIENT  ,
        fusr.description user_name ,  
        fcq.concurrent_queue_name Manager,     
	fcp.user_concurrent_program_name		progName,
	to_char(actual_Start_date,'DD-MON-YYYY HH24:MI:SS') StartDate,
	request_id											RequestId,
  	(sysdate - actual_start_date)*24*60*60 ETime
from 	fnd_concurrent_requests fcr,
   	fnd_concurrent_programs_tl  fcp,
    fnd_concurrent_processes fcpr,
    fnd_concurrent_queues fcq,
        fnd_user fusr,
        v$session sess,
        v$process proc
where fcp.concurrent_program_id = fcr.concurrent_program_id
  and fcr.program_application_id	= fcp.application_id
  and fcp.language		= 'US'
  and fcr.phase_code	= 'R'
  and fcr.status_code	= 'R'
  and fcr.requested_by = fusr.user_id
  and fcr.controlling_manager=fcpr.concurrent_process_id
  and fcpr.session_id = sess.audsid  
  and fcr.controlling_manager = fcpr.concurrent_process_id
  and fcpr.concurrent_queue_id = fcq.concurrent_queue_id
  and fcr.oracle_process_id is null
  and proc.addr=sess.paddr
--  and p.addr = sess.paddr
/
spool off
