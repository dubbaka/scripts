col USER_CONCURRENT_QUEUE_NAME for a40
set lines 200
select /*+ parallel 4 */ b.USER_CONCURRENT_QUEUE_NAME,to_char(actual_completion_date,'HH24'),count(*) from apps.fnd_concurrent_processes a,
apps.fnd_concurrent_queues_vl b, apps.fnd_concurrent_requests c
where  a.CONCURRENT_QUEUE_ID = b.CONCURRENT_QUEUE_ID
and    a.CONCURRENT_PROCESS_ID = c.controlling_manager
and trunc(actual_completion_date)='&Enter_date_to_analyze'
and b.USER_CONCURRENT_QUEUE_NAME='&Manager_Name'
group by b.USER_CONCURRENT_QUEUE_NAME,to_char(actual_completion_date,'HH24')
order by 2
/
