rem ********************************************************************
rem * Filename          : osproc.sql - Version 1.0
rem * Author            : Aru
rem * Original          : 02-FEB-2009
rem * Last Update       : 02-FEB-2009
rem * Description       : Query a session by OS process id or db SID
rem ********************************************************************

def aps_prog    = 'osproc.sql'
def aps_title   = 'OS Proc session information'

col "Process / Session Info" form A85
set verify off
accept sid      prompt 'Please enter the value for Sid if known            : '
accept spid     prompt 'Please enter the value for Server Process if known : '
select ' Sid, Serial#, Aud sid : '|| s.sid||' , '||s.serial#||' , '||
       s.audsid||chr(10)|| '     DB User / OS User : '||s.username||
       '   /   '||s.osuser||chr(10)|| '    Machine - Terminal : '||
       s.machine||'  -  '|| s.terminal||chr(10)||
       '        OS Process Ids : '||
       s.process||' (Client)  '||p.spid||' (Server)'|| ' (Since) '||to_char(s.logon_time,'DD-MON-YYYY HH24:MI:SS')||chr(10)||
       '   Client Program Name : '||s.program||chr(10) "Session Info",
           '   Action / Module     : '||s.action||'  / '||s.module||chr(10) ||'User Name : '
  from v$process p,v$session s
 where p.addr = s.paddr
   and s.sid = nvl('&SID',s.sid)
   and p.spid = nvl('&spid',p.spid)
/

REM prompt !ps -ef | grep &spid | grep -v grep
undefine sid
undefine spid

