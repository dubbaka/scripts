spool oradebug.lst

session 1 :
alter session set max_dump_file_size = unlimited;
alter session set events 'immediate trace name SYSTEMSTATE level 10'; 

session 2 :
-- same commands as in session 1 

session 3 :

oradebug setorapid &process_id
oradebug unlimit
oradebug dump errorstack 3
oradebug dump errorstack 3
oradebug dump errorstack 3
oradebug event 10046 trace name context forever, level 12
oradebug event 10390 trace name context forever, level 1166


- After debug is done do context off using.


--oradebug event 10046 trace name context off
--oradebug event 10390 trace name context off;
spool off;
