#!/bin/sh
#####################################################################################
#
# File name:    conc_req_error_report.sh
# Purpose:      Verify if there are any concurrent requests failed in last hour
#              
#
# Author:      Rajesh Gunda
# Usage:       $ conc_req_error_report.sh
#
# History:
#
# Date                  Who                     Vesion          Details
# ----------            --------                --------        -------------
# 2015/06/24            rajeshgunda             1.0             Initial draft
#
#####################################################################################
#set -x
Set_Env()
{
  GREP="/bin/grep"
  EGREP="/bin/egrep"
  AWK="/bin/awk"
  SED="/bin/sed"
  XARGS="/usr/bin/xargs"
  ECHO="/bin/echo"
  TR="/usr/bin/tr"
  HEAD="/usr/bin/head"
  CAT="/bin/cat"
  WC="/usr/bin/wc"
  TOUCH="/bin/touch"
  TSTMP=`date +%Y%m%d_%H%M%S`
  TAIL="/usr/bin/tail"
  SORT="/bin/sort"
  UNIQ="/usr/bin/uniq"
  PS="/bin/ps"
  HOSTNAME=`/bin/hostname | cut -d. -f1`
  BZIP2="/usr/bin/bzip2"
  BUNZIP2="/usr/bin/bunzip2"
  GZIP="/bin/gzip"
  GUNZIP="/bin/gunzip"
  HOME="/root/dba"
  SUDO="/usr/bin/sudo"
  FILE="/usr/bin/file"
  TEE="/usr/bin/tee"
  LS="/bin/ls"
  WORKDIR="/oraclesw/admin/scripts/Monitoring/FBCop"
  LOGDIR="$WORKDIR/log"
  statefile="$WORKDIR/config/${HOSTNAME}_conc_req_error_report.state"
  LOGFILE="$LOGDIR/${HOSTNAME}_conc_req_error_report_${TSTMP}.log"
  LOCKFILE="$LOGDIR/${HOSTNAME}_conc_req_error_report.lck"
  ERROR_LOG="$LOGDIR/${HOSTNAME}_conc_req_error_report_${TSTMP}.err"
  html_log="$LOGDIR/${HOSTNAME}_conc_req_error_report.html"
  SQLOUT="$LOGDIR/${HOSTNAME}_conc_req_error_report_sql.out"
  TSTMP="`date +%m%d%Y_%H%M`"
  NOTIFY2="it-omg-dba@fb.com"

$ECHO "`date`:$HOSTNAME:conc_req_error_report:[INFO]:Script started" | $TEE -a $LOGFILE
# Below condition is to make sure parallel run of same script is not executed
if [  -f $LOCKFILE ]
  then
    $ECHO "`date`:[conc_req_error_report]:[ERROR]:Lockfile $LOCKFILE found..., Hence exiting..." | $TEE -a $LOGFILE
    exit 1
  else
    $ECHO "`date`:[conc_req_error_report]:[INFO]:Lockfile is placed" | $TEE -a $LOGFILE
    $TOUCH $LOCKFILE
fi

. /usr/local/bin/dbenv OMSPRD1 1>/tmp/1.err 2>&1
if [ "${ORACLE_SID} " == " " ]
then
    $ECHO "`date`:[conc_req_error_report]:[ERROR]: Failed to source environment" | $TEE -a $LOGFILE
    exit 1
fi

export NLS_DATE_FORMAT="DD-MON-YY HH24:MI"
export DBNAME=`(sqlplus -s "/ as sysdba"<<EOF
set echo off verify off head off feed off pages0 trimspool on;
select trim(name) from v\\$database;
EOF
)`
}

concurrent_job_details()
{

NOTIFY="ap_jobs@fb.com"
cat /dev/null > $html_log
sqlplus -s "/ as sysdba"<<EOF
@$WORKDIR/ControlRoom/set_markup.sql
set pages 5000 linesize 1000 feed off
TTITLE CENTER '<h1>AP Job Failures in last 24 hours</h1>' -

spool $html_log
select  distinct program "Concurrent Program Name" , request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  "Run Time(Mins)", actual_completion_date, status_code "Status"
from apps.FND_CONC_REQUESTS_FORM_V
where actual_start_date > sysdate - 1
and status_code = 'E'
and program IN ('Bank Statement Import' || chr(38) || 'AutoReconciliation',
'Bank Statement Loader',
'Batches Available for Reconciliation',
'FB: Amex Corporate Card Request Extract Program',
'BPA Child Print Program - Non Emailed Invoices',
'FB Attachment Import',
'FB Transcepta Image Download',
'Invoice on Hold Report',
'Bursting FB Argentine Payables Withholding Certificate (XML Publisher Report Bursting Program)',
'Run SQL*Loader- BAI2',
'Build Payments',
'Create Accounting',
'FB AP Holds Mgmt. Create Case',
'FB AP Serengeti AP Invoice Import Request Set (Report Set)',
'FB IBY Bank File Encrypt Program',
'FB AP Update TCC on Invoice Lines (15) (Request Set Stage)',
'FB AP Update TCC on Invoice lines',
'FB AU Payments (Payment Process Request Program)',
'FB BE Payments (Payment Process Request Program)',
'FB CA EFT Payment (Payment Process Request Program)',
'FB DE Payments (Payment Process Request Program)',
'FB ES Payments (Payment Process Request Program)',
'FB FR Payments (Payment Process Request Program)',
'FB Generic AP Bank Acknowledgement Reader',
'FB IT PaymentsÃ‚  (Payment Process Request Program)',
'FB NZ Payments (Payment Process Request Program)',
'FB PL PaymentsÃ‚  (Payment Process Request Program)',
'FB Payments ACH Payments (Payment Process Request Program)',
'FB Send Separate Remittance Advices',
'FB Sup ACH Pay-And (Payment Process Request Program)',
'FB Sup ACH Pay-Ops (Payment Process Request Program)',
'FB Sup ACH Pay-Vit (Payment Process Request Program)',
'FB Supplier ACH Payment (Payment Process Request Program)',
'FB: Update Payment Logging Status',
'Facebook Invoice Validation request set (Request Set Facebook Invoice Validation request set)',
'Format Payment Instructions with Text Output',
'Import Transcepta invoices - Facebook Eurozone (Payables Open Interface Import)',
'Import Transcepta invoices - Facebook Japan Operating Unit (Payables Open Interface Import)',
'Import Transcepta invoices - Facebook US (Payables Open Interface Import)',
'Invoice Approval Workflow',
'Invoice Validation',
'Invoice Validation (20) (Request Set Stage)',
'Payment Process Request Program',
'Period Close Exceptions Report (XML)',
'Unaccounted Transactions Report (XML)',
'XXFB AP BofA Payment XML Upload by Payment Instruction',
'XXFB: AP Serengeti Invoices Validation Program',
'Serengeti Invoice Validation (Request Set Stage)',
'FB Global Transcepta Invoice Import Program',
'FB Colombian Payables Withholding Report',
'Accounting Program') and requestor in ('SCM_SCHEDULER','APPS_SCHEDULER','COMPAY_SCHEDULER','SF_SCHEDULER','SYSADMIN','APPSDBA')
order by program;
spool off
EOF
	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
	then
		sendmail $NOTIFY;
	fi

# No need added to Purchasing
#NOTIFY="demantra_jobs@fb.com"
#cat /dev/null > $html_log
#sqlplus -s "/ as sysdba"<<EOF
#@$WORKDIR/ControlRoom/set_markup.sql
#set pages 5000 linesize 1000 feed off
#TTITLE CENTER '<h1>Demantra Job Failures in last 24 hours</h1>' -
#
#spool $html_log
#select  distinct program "Concurrent Program Name", request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  "Run Time(Mins)", actual_completion_date, status_code "Status"
#from apps.FND_CONC_REQUESTS_FORM_V
#where actual_start_date > sysdate - 1
#and status_code = 'E'
#and program like 'XXFB PO Import- Demantra'
#order by program;
#spool off;
#EOF
#	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
#	then
#		sendmail $NOTIFY;
#	fi

NOTIFY="rtr_jobs@fb.com"
cat /dev/null > $html_log
sqlplus -s "/ as sysdba"<<EOF
@$WORKDIR/ControlRoom/set_markup.sql
set pages 5000 linesize 1000 feed off
TTITLE CENTER '<h1>RTR Job Failures in last 24 hours</h1>' -

spool $html_log
select  distinct program "Concurrent Program Name", request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)   "Run Time(Mins)", actual_completion_date, status_code  "Status"
from apps.FND_CONC_REQUESTS_FORM_V
where actual_start_date > sysdate - 1
and status_code = 'E'
and program IN (
'FB FA ADR and System Validation Program (Report Set)',
'FB FA Month End Process Automation Program',
'FB Update FA Locaition in Link Table',
'FB GAAP to STAT Book Mapping Report',	
'FB Populate GL JE Batch Approval History',
'Report Set: FB Import'  || chr(38) || 'Update GL Daily Rates from Bloomberg - Program Set',
'FB: Chart of Accounts Review Report',
'FB: Daily Rate Audit Report',
'FB: Elimination Set Review Report',
'FB: GL Consolidation Set Review Report',
'FB: Journal Entry Review Report',
'Program - Automatic Posting',
'FB FA Asset Detail Report System Validation Program',
'FB FA Asset Detail Report System Validation Program (20) (Request Set Stage)',
'FB FA Asset Detail Report System Validation Sub Program (FB FA Asset Detail Report System Validation Sub Program)',
'FB FA Buy Back Parent Asset Move',
'FB FA OAT Lease Info Sync',
'FB OAT FA Dashboard',
'FB: FCM Task Update Integration Program',
'FB Assets Detail Report (As of Period) for OBIEE',
'FB Assets Detail Report (As of Period) for OBIEE (10) (Request Set Stage)',
'FB Time Sheets-Approver Due Date Notifications',
'FB CIP Detail Report (PDF)',
'Interface Invoice Price Variance to Oracle Assets',
'Interface Move Transactions to Oracle Assets',
'Mass Additions Create (10) (Request Set Stage)',
'Post Mass Additions (Report Set)',
'XXFB Period Close Generate ARM Tasks Reconciliation Balances',
'XXFB Period Close Task Scheduler',
'Depreciation Run (Request Set Stage)',
'FB Cluster Decom Depreciation Schedule',
'FB GL Concur Expenses Load Program',
'Mass Additions Post (Request Set Stage)',
'Reverse Journals',
'Subledger Accounting Balances Update',
'Post Mass Retirements',
'Posting',
'Posting: Single Ledger',
'Mass Additions Post',
'Mass Additions Create',
'Translation',
'FB FA Check ETL Workflow Status',
'FB MonthEnd Automation Depreciation Run Request Set (Close Period) (Report Set)',
'XXFB Depreciation Run (Request Set Stage)',
'XXFB Depreciation Run')
and requestor in ('SCM_SCHEDULER','APPS_SCHEDULER','COMPAY_SCHEDULER','SF_SCHEDULER','SYSADMIN','APPSDBA')
and completion_text not like '%TTRN0001:%Cannot%find any valid balancing%'
and completion_text not like '%GLTTRN%'
order by program;
spool off
EOF
	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
	then
		sendmail $NOTIFY;
	fi

NOTIFY="inventory_jobs@fb.com"
cat /dev/null > $html_log
sqlplus -s "/ as sysdba"<<EOF
@$WORKDIR/ControlRoom/set_markup.sql
set pages 5000 linesize 1000 feed off
TTITLE CENTER '<h1>Inventory Job Failures in last 24 hours</h1>' -

spool $html_log
select distinct program, request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  running_for, actual_completion_date, status_code
from apps.FND_CONC_REQUESTS_FORM_V
where actual_start_date > sysdate - 1
and status_code = 'E'
and program IN ('FB Push Assets to Serf (Request Set Stage)',
'FB Push Assets to Serf',
'FB Shreq Claim Reset',
'Actual Cost Worker',
'Fb Process Virtual Receipts',
'FB Push Assets to Serf (Request Set Stage)',
'Close Period Control',
'FB Everest PO to Inventory allocation Program',
'Auto Pack Report (Auto-pack Report)',
'Auto Pack Report',
'Auto Ship Confirm Report (Auto Ship Confirm Report)',
'Auto Ship Confirm Report',
'FB Custom Complete IB Transactions',
'FB Period Control',
'XXFB Inventory Datafix for Marked Serial Numbers',
'XXFB Asset Value by Location and Item Sub Type',
'FB SERF OAT Discrepancy Report',
'XXFB delete errors in INV'  || chr(38) || 'RCV interface tables',
'FB Asset Move/Retirement - Acc. Dep. Report',
'XXFB Extract IT Asset data for Sort',
'Report Set: FB RMA Swap',
'FB: Omega Master Product List Review Report',
'FB: Omega Price List Review Report',
'FB OAT Dashboard Details',
'FB: reSORT Submit parts info to ITR System',
'Cost Manager',
'FB Vendor File Upload Process',
'Create Accounting - Cost Management',
'FB ASN File Process (FB ASN File Process)',
'FB Create Asset from OAT and Update Queue Status Request Set (Report Set)',
'FB DSR Project Details Sync Program',
'FB Get File From FB Files',
'FB INV Child Rack Transfer Program',
'FB Inventory Packing Slip (XML)',
'FB Load Vendor Delivery Updates',
'FB Modify Shipments Info',
'FB OAT to Serf Push Exceptions Report',
'FB Process Rack Componnets and Push OAT to SeRF (Request Set FB Process Rack Componnets and Push OAT to SeRF)',
'FB Pull Assets from Serf',
'FB Push Assets to Serf',
'FB Receive ASN Rack Components (Request Set Stage)',
'FB SCM Concurrent Program Monitor Alert',
'FB Update SeRF Changes in OAT',
'FB Update SeRF to OAT Changes (Request Set Stage)',
'FB Receive ASN Rack Components',
'Facebook Serf to OAT Exception Report',
'Import Items',
'Inventory transaction worker',
'Open Period Control',
'Resubmit Interface Process',
'XXFB Agile BOM Import Program',
'XXFB Agile BOM Import Program (20) (Request Set Stage)',
'XXFB Agile BPA Creation (40) (Request Set Stage)',
'XXFB Agile BPA Import Program',
'XXFB Agile Create Manufacturer Parts Program',
'XXFB Agile Create Manufacturer Parts Program (30) (Request Set Stage)',
'XXFB Agile Import Items Program',
'XXFB Agile Import Items Program (10) (Request Set Stage)',
'FB Push Assets to Serf (Request Set Stage)',
'XXFB Agile to Oracle Interface (Report Set)')
and requestor in ('SCM_SCHEDULER','APPS_SCHEDULER','COMPAY_SCHEDULER','SF_SCHEDULER','SYSADMIN','APPSDBA')
order by program;
spool off
EOF

	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
	then
		sendmail $NOTIFY;
	fi

NOTIFY="itc_jobs@fb.com"
cat /dev/null > $html_log
sqlplus -s "/ as sysdba"<<EOF
@$WORKDIR/ControlRoom/set_markup.sql
set pages 5000 linesize 1000 feed off
TTITLE CENTER '<h1>ITC Job Failures in last 24 hours</h1>' -

spool $html_log
select distinct program, request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  running_for, actual_completion_date, status_code
from apps.FND_CONC_REQUESTS_FORM_V
where actual_start_date > sysdate - 1
and status_code = 'E'
and program IN ('FB Initialize SOD Analysis',
'FB Poll GRC for Approvals',
'FB: User Transfers - Losing Manager Notify Program',	
'FB Contracts EchoSign Scheduler Job',
'XXFB Assign User Responsibility Group')
and requestor in ('SCM_SCHEDULER','APPS_SCHEDULER','COMPAY_SCHEDULER','SF_SCHEDULER','SYSADMIN','APPSDBA')
order by program;
spool off
EOF

	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
	then
		sendmail $NOTIFY;
	fi

# No need moved to sys_admin
#NOTIFY="noetix_jobs@fb.com"
#cat /dev/null > $html_log
#sqlplus -s "/ as sysdba"<<EOF
#@$WORKDIR/ControlRoom/set_markup.sql
#set pages 5000 linesize 1000 feed off
#TTITLE CENTER '<h1>NOETIX Job Failures in last 24 hours</h1>' -
#
#spool $html_log
#select distinct program, request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  running_for, actual_completion_date, status_code
#from apps.FND_CONC_REQUESTS_FORM_V
#where actual_start_date > sysdate - 1
#and status_code = 'E'
#and program IN ('N_KFF_Asset_Ct-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_Ctlg_Grp-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_GL_Acct-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_Item_Loc-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_Keywords-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_Location-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_MKTS-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_Mtl_Cat-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_Sys_Item-Incremental Refresh (NOETIX_SYS[UID-411])',
#'N_KFF_Terr-Incremental Refresh (NOETIX_SYS[UID-411])',
#'STG-411-DC-VALUE (Request Set Stage)')
#order by program;
#spool off;
#EOF
#	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
#	then
#		sendmail $NOTIFY;
#	fi

NOTIFY="purchasing_jobs@fb.com"
cat /dev/null > $html_log
sqlplus -s "/ as sysdba"<<EOF
@$WORKDIR/ControlRoom/set_markup.sql
set pages 5000 linesize 1000 feed off
TTITLE CENTER '<h1>Purchasing Job Failures in last 24 hours</h1>' -

spool $html_log
select distinct program, request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  running_for, actual_completion_date, status_code
from apps.FND_CONC_REQUESTS_FORM_V
where actual_start_date > sysdate - 1
and status_code = 'E'
and program IN ('FB PO Rebate Validate Data and Create Header Record',
'FB PO Supplier Registration D'  || chr(38) || 'B Service Call',
'FB POS Supplier Registration Auto-submit (Request Set Stage)',
'FB POS Supplier Registration Auto-submit Program',
'XXFB PO Receipts Oracle to Ariba Transfer',
'FB DSR Purchase Order Import Program',
'FB: Omega Supplier Review Report',
'FB POS Supplier Registration Auto-submit Set (Report Set)',
'Import Price Catalogs',
'PO Output for Communication',
'XXFB Check PO Fund Alert',
'XXFB Open POs Program',
'Purchase Order Detail Report (XML)',
'XXFB PO Import- Demantra')
and requestor in ('SCM_SCHEDULER','APPS_SCHEDULER','COMPAY_SCHEDULER','SF_SCHEDULER','SYSADMIN','APPSDBA')
order by program;
spool off
EOF
	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
	then
		sendmail $NOTIFY;
	fi

NOTIFY="o2c_jobs@fb.com"
cat /dev/null > $html_log
sqlplus -s "/ as sysdba"<<EOF
@$WORKDIR/ControlRoom/set_markup.sql
set pages 5000 linesize 1000 feed off
TTITLE CENTER '<h1>O2C Job Failures in last 24 hours</h1>' -

spool $html_log
select distinct program, request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  running_for, actual_completion_date, status_code
from apps.FND_CONC_REQUESTS_FORM_V
where actual_start_date > sysdate - 1
and status_code = 'E'
and program IN ('Bursting Facebook AR Customer Balance Statement Letter (Custom) (XML Publisher Report Bursting Program)',
'DQM Serial Sync Index Program (DQM Serial Sync Index Program)',
'FB AR Customer Balance Statement Letter (Facebook AR Customer Balance Statement Letter (Custom))',
'EN-US: (FB AR Invoice Print Program (BPA))',
'Receiving Approval',
'Fb Merge Invoice Boleto Files',
'FB SFDC Salesforce Integrations(Nexus)',
'FB SFDC Integration - Cash Receipts (Request Set Stage)',
'FB SFDC Integration - Cash Receipts',
'FB Attach BPA PDF to Invoice',
'FB Commerce Payout - Paypal Inbound',
'FB Commerce Payouts Inbound File Processing',
'XXFB AR Alert to Notify Atlas Customer with Missing Email',
'FB - RevStream - Load Datamart',
'FB SFDC Salesforce Integrations (Nexus)',
'Request Set XXFB Pull Deliveries from OmegaLight',
'XXFB: Pull Third Party Deliveries into Omegalight',
'XXFB: Credit Card Payment Load Process',
'XXFB ONT Notify DSO records with Invalid Ship to/Bill to',
'XXFB ONT Notify Unprocessed records in XXFB_ONT_IO_DELIVERIES',
'XXFB Update Latest Periodic Avg Rates in Opportunity Forecasts',
'XXFB Pull Third Party Deliveries',
'FB GC Payment Processing',
'FB SF Sync Ad Account',
'FB SF Ad Account Market Object Integration',
'FB ComPay Revenue by Developer',
'FB Atlas Integration Outbound',
'AR Customer Balance Statement Letter',
'Apply Payments and Create Payment Events (Request Set Stage)',
'FB Load Bank Balances',
'AR Customer Balance Statement Letter (AR Customer Balance Statement Letter)',
'FB SF Sync Ad Account',
'FB Com Pay ATP Details -LvrATPDetails-2015-06-09.csv_V1 (FB Commerce ATP Details Load)',
'FB Com Pay Holds -Holds-2015-06-09.csv_V1 (FB Commence Holds Load)',
'FB Commerce Payouts Outbound File Processing',
'FB Commerce Payouts Payment Status Processing',
'FB Customer Statement Generation Program',
'FB Customer Statement Generation Program - New',
'FB IE Copy CE Bank Statments to Receipts Interface',
'FB SF Order Import Program',
'FB SFDC Customers Sync (Report Set)',
'FB SFDC Inbound Processing',
'FB SFDC Salesforce Integration',
'Facebook Online Invoice Apply and Publish Payments (Report Set)',
'FB SFDC Salesforce Integration - UnRestricted',
'FB SFDC Salesforce to Oracle Ad Account Sync',
'FB SFDC Integration - Cash Receipts Sync Set (Report Set)',
'FB SFDC Integration - Cash Receipts',
'Account and Site Nbr Related Upload (Request Set Stage)',
'Facebook AR Invoice Pre-Processor',
'Facebook AR Invoice Pre-Processor(10) (Request Set Stage)',
'Facebook Autoinvoice Request Set (Report Set)',
'INBOX_BLACKHAWK_2015-06-12-FB GC File Fetch (FB GC File Fetch)',
'Inbound Processing (Request Set Stage)',
'Statement Generation Program',
'XXFB AD Omega Email Sync Program',
'XXFB Extract New Atlas Invoices',
'XXFB Publish IO To Omega Light Program',
'XXFB Receiving report submit',
'XXFB: Ad Delivery Load',
'FB AR Invoice Print Program (BPA) (Multiple Languages)',
'XXFB RevStream Revenue Load Process (Report Set)',
'XXFB: OSO Update Invoice Payment Status',
'Publish Payments (Request Set Stage)',
'FB - RevStream - Load Revenue to Workbench (20) (Reques Set)',
'FB - RevStream - Load Revenue to Workbench')
and requestor in ('SCM_SCHEDULER','APPS_SCHEDULER','COMPAY_SCHEDULER','SF_SCHEDULER','SYSADMIN','APPSDBA')
order by program;
spool off
EOF
	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
	then
		sendmail $NOTIFY;
	fi

NOTIFY="sys_admin_jobs@fb.com"
cat /dev/null > $html_log
sqlplus -s "/ as sysdba"<<EOF
@$WORKDIR/ControlRoom/set_markup.sql
set pages 5000 linesize 1000 feed off
TTITLE CENTER '<h1>SYSADMIN Job Failures in last 24 hours</h1>' -

spool $html_log
select distinct program, request_id, application_name, requestor, completion_text, argument_text,actual_start_date, round((NVL(actual_completion_date,SYSDATE)-actual_start_date)*24*60,2)  running_for, actual_completion_date, status_code
from apps.FND_CONC_REQUESTS_FORM_V
where actual_start_date > sysdate - 1
and status_code = 'E'
and program IN ('Flex Loader: FDFVGN(3,0,FND_COMMON_LOOKUPS) (Flexfield View Generator)',
'Flexfield View Generator',
'FB: Amex (IPM Full) Corporate Card Request Status Check Program',
'Gather Schema Statistics',
'Generic Loader',
'Purge Logs and Closed System Alerts',
'Purge Obsolete Workflow Runtime Data',
'Report Set:Synchronize Workflow LOCAL tables',
'Workflow Control Queue Cleanup',
'Workflow Agent Activity Statistics Concurrent Program',
'Workflow Mailer Statistics Concurrent Program',
'Periodic Alert Scheduler',
'Purge Concurrent Request and/or Manager Data',
'Synchronize Employees',
'INCREMENTAL_REFRESH-NOETIX_SYS[UID-411]) (Request Set INCREMENTAL_REFRESH-NOETIX_SYS[UID-411]))',
'N_KFF_Asset_Ct-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_Ctlg_Grp-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_GL_Acct-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_Item_Loc-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_Keywords-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_Location-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_MKTS-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_Mtl_Cat-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_Sys_Item-Incremental Refresh (NOETIX_SYS[UID-411])',
'N_KFF_Terr-Incremental Refresh (NOETIX_SYS[UID-411])',
'STG-411-DC-VALUE (Request Set Stage)',
'OAM Applications Dashboard Collection',
'Workflow Background Process',
'Workflow Work Items Statistics Concurrent Program',
'XXFB Maintain WF Roles',
'XXFB_VERTEX_FAILURE_ALERT_PRD',
'XXFB_VERTEX_FAILURE_ALERT_PRD_TWO',
'XXFB Credit Card Payment Load - OnDemand')
and requestor in ('SCM_SCHEDULER','APPS_SCHEDULER','COMPAY_SCHEDULER','SF_SCHEDULER','SYSADMIN','APPSDBA')
order by program;
spool off
EOF
	if [ -s $html_log ] && [ `egrep -ic "request_id|application_name" $html_log` -ne 0 ]
	then
		sendmail $NOTIFY;
	fi

}


sendmail()
{
NOTIFY=$1
(echo "Subject:[INFO]:[$TSTMP]:[$HOSTNAME]:FBCOP:OMEGA Concurrent requests failed in last 24 hours "
echo "To: $NOTIFY"
echo "Cc: it-omg-dba@fb.com"
echo "MIME-Version: 1.0"
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
cat $html_log
) | /usr/lib/sendmail -t -v > /dev/null

}


############# MAIN ################

Set_Env;
concurrent_job_details;
$ECHO "`date`:[conc_req_error_report]:[INFO]:Removing Lockfile" | $TEE -a $LOGFILE
rm -f $LOCKFILE

