set termout on;
set escape \ ;

accept 1 prompt 'Enter start date in format (dd-mon-rr) : '
prompt
accept 2 prompt 'Enter end date in format (dd-mon-rr) : '
prompt
accept wf prompt 'Collect Data for Weekend ? (y/n) : '
prompt
prompt Collect Data Based on Specific Hour Only ?
prompt If <Y> , specify the start_time and end_time in "HH" format
prompt else press enter for Default Value = N
prompt (Default peak hours of 00 PST - 23 PST will be chosen)
accept hf prompt '(Y/N) Press Enter for default  : '
set termout off ;
variable wd1        number;
variable wd2        number;
variable wst	varchar2(50) ;
declare
fl varchar2(1) := '&wf' ;
begin
if  upper(fl) = 'Y' then
	:wd1 := 1 ;
	:wd2 := 7 ;
	:wst := 'Data collected for weekend also';
else
        :wd1 := 2 ;
        :wd2 := 6 ;
	:wst := 'Data collected for weekdays only';
end if;
end;
/
set termout on;
accept start_time prompt 'Enter Start Time for Peak Hour/Off Hour (0-23) : '
accept end_time prompt 'Enter End Time for Peak Hour/Off Hour (0-23) : '
set termout off;
variable hd1        number;
variable hd2        number;
variable hd3        number;
variable hd4	    number;
variable cpu_arg1        char(2);
variable cpu_arg2        char(2);
declare
fl varchar2(1) := nvl('&hf','N') ;
begin
if  upper(fl) = 'N' then
        :hd1 := 0 ;
        :hd2 := 23 ;
	:hd3 := 23 ;
	:hd4 := 23 ;
        :cpu_arg1 := '00' ;
        :cpu_arg2 := '23' ;
else
	declare
		st_hr number := nvl('&start_time',0);
		end_hr number := nvl('&end_time',23);
	begin
		:hd1  := st_hr;
		:hd2  := end_hr;
		if st_hr < 10 then
		 	select lpad(st_hr,2,0) into :cpu_arg1 from dual;
		else
			:cpu_arg1 := st_hr;
		end if;
		if end_hr < 10 then
			select lpad(end_hr,2,0) into :cpu_arg2 from dual;
		else
			:cpu_arg2 := end_hr;
		end if;

		if end_hr < st_hr then
			:hd3 := 23;
			:hd4 := 00 ;
		else
			:hd3 := :hd2 ;
			:hd4 := 23 ;
		end if ;
	end;
end if;
end;
/
prompt
prompt Now Collecting the following information
prompt

column dcol new_value mydate noprint
select to_char(to_date('&1','dd-mon-yy'),'DDMon')||'_'||to_char(to_date('&2','dd-mon-yy'),'DDMon')||'_' dcol from dual;
column dbname new_value dname noprint
select substr(name,1)||'_' dbname from v$database;
spool /tmp/&dname.&mydate.Cap_Base_Coll.html
set heading off;
set feedback off;
set markup html on
set term off
prom
prom          =============================================================
set term on
prom	      Data collection options
set term off
prom          =============================================================
Select 'Data Collected From : '||to_char(to_date('&1','dd-mon-yy'),'DD-Mon-yy')||'  To  '||to_char(to_date('&2','dd-mon-yy'),'DD-Mon-yy') from dual;
Select 'Peak Time Selected for Workload : '||to_char(to_date(to_number(:hd1),'hh24'),'HH:MIAM')||'  To '||to_char(to_date(to_number(:hd2),'hh24'),'HH:MIAM')  from dual;
Select 'Peak Time Selected for Utilisation : '||to_char(to_date(to_number(:cpu_arg1),'hh24'),'HH:MIAM')||'  To '||to_char(to_date(to_number(:cpu_arg2),'hh24'),'HH:MIAM')  from dual;
Select 'Day Selected for Workload: '||decode(:wd1,1,'SUN','MON')||'  To  '||decode(:wd2,6,'FRI','SAT') from dual;
prom
prom          =============================================================
set term on
prom          Database Information
set term off
prom          =============================================================
set linesize 80
set heading off ;
select 'Data collected on :"'||substr(to_char(sysdate,'fmMonth DD,YYYY,HH:MI:SS P.M.'),1,35)||'"' from dual;
select 'Database Name:      "'||name||'"' from v$database;
select 'Instance Name:      "'||instance_name||'"' from v$instance;
select 'Host     Name:      "'||host_name||'"' from v$instance;
select 'Oracle Database Version:"'||version||'"' from v$instance;
set heading on
prom
prom

prom
prom          =============================================================
prom          Database Version
prom          =============================================================
select * from v$version;
prom
prom


prom
prom          =============================================================
prom          Application Version
prom          =============================================================
select release_name from apps.fnd_product_groups;
prom
prom


prom
prom          =============================================================
set term on
prom          Concurrent Manager Configuration
set term off
prom          =============================================================
set pagesize 9999
set linesize 200
col "Concurrent Manager Name" format a25
col "User Concurrent Manager Name" format a30
col "Res Con Grp" format a10
col "CM Server Name" format a15
col "Sleep" format 999
col "CS" format 999
col "Proc" format 999
select substr(fcq.CONCURRENT_QUEUE_NAME,1,20) "Concurrent Manager Name"
       ,fcqt.user_concurrent_queue_name "User Concurrent Manager Name"
       ,RESOURCE_CONSUMER_GROUP "Res Con Grp"
       ,fcq.target_node "CM Server Name"
       ,fcq.sleep_seconds "Sleep"
       ,fcq.cache_size "CS"
       ,fcq.RUNNING_PROCESSES "Proc"
from   fnd_concurrent_queues fcq,
       fnd_concurrent_queues_tl fcqt
where  fcq.APPLICATION_ID = fcqt.APPLICATION_ID
and    fcq.CONCURRENT_QUEUE_ID = fcqt.CONCURRENT_QUEUE_ID
and    enabled_flag='Y'
and    fcq.RUNNING_PROCESSES >0
and    language= 'US'
order by 7 desc,1;



prom
prom          ===================================================================
set term on
prom          Concurrent Manager Statistics
set term off
prom          ===================================================================
set pages 1000
set linesize 200
set show off
break on report
compute sum of cnt on report
compute sum of elapsed on report
compute sum of waited on report
column "Concurrent Manager Name" format a25;
column cnt                       format 999,999,999.99 heading 'Count';
column elapsed                   format 999,999,999.99 heading 'Total|Mins';
column average                   format 999,999,999.99 heading 'Avg|Mins';
column waited                    format 999,999,999.99 heading 'Waited|Mins';
select  q.concurrent_queue_name "Concurrent Manager Name",
        count(*) cnt,
        sum(r.actual_completion_date - r.actual_start_date) * 1440 elapsed,
        avg(r.actual_completion_date - r.actual_start_date) * 1440 average,
        sum(actual_start_date - greatest(r.requested_start_date,r.request_date)) * 1440 waited
from    apps.fnd_concurrent_programs p,
        apps.fnd_concurrent_requests r,
        apps.fnd_concurrent_queues q,
        apps.fnd_concurrent_processes p
where   r.program_application_id = p.application_id
and     r.concurrent_program_id = p.concurrent_program_id
and     r.phase_code='C' -- completed
and     r.status_code in ('C','G')  -- completed normal or with warning
and     r.controlling_manager=p.concurrent_process_id
and     q.concurrent_queue_id=p.concurrent_queue_id
and     r.concurrent_program_id=p.concurrent_program_id
and trunc(actual_start_date) between to_date('&1', 'dd-mon-yy') and to_date('&2', 'dd-mon-yy')
and ((to_number(to_char(actual_start_date,'hh24')) between :hd1 and :hd3 ) or (to_number(to_char(actual_start_date,'hh24')) between :hd4 and :hd2 ) )
and to_number(to_char(actual_start_date,'D')) between :wd1 and :wd2
group by  q.concurrent_queue_name
order by 4;
clear breaks


prom
prom          ===================================================================
set term on
set head off
select 'Heavy (Slow) Running Jobs During Peak Hour: '||to_char(to_date(to_number(:hd1),'hh24'),'HH24:MI')||' To '||to_char(to_date(to_number(:hd2),'hh24'),'HH24:MI') from dual;
set term off
set head on
prom          ===================================================================
set pages 1000
set linesize 200
set show off
column Min                     format 999999.99
column Max                     format 999999.99
column Avg                     format 999999.99
column Waited                  format 999999.99
column Queue                   format a15
column Cnt                     format 999999
column program_name            format A30
column concurrent_program_name format A30
column c_hours                 format 9999.99
select substr(d.concurrent_queue_name,1,15) Queue,
       substr(c.user_concurrent_program_name,1,30) program_name,
       b.concurrent_program_name,
       count(*) Cnt,
       Avg(( a.actual_completion_date - a.actual_start_date ) * 1440) Avg,
       Min(( a.actual_completion_date - a.actual_start_date ) * 1440) Min,
       Max(( a.actual_completion_date - a.actual_start_date ) * 1440) Max,
       sum(actual_start_date - greatest(requested_start_date,request_date))* 1440 Waited
from fnd_concurrent_requests A ,
     fnd_concurrent_programs B ,
     fnd_concurrent_programs_tl C,
     fnd_concurrent_queues D,
     fnd_concurrent_processes E,
     fnd_application F
where a.program_application_id = b.application_id
and a.program_application_id = c.application_id
and a.concurrent_program_id = b.concurrent_program_id
and a.concurrent_program_id = c.concurrent_program_id
and c.language = 'US'
and a.actual_completion_date is not null
and a.controlling_manager=e.concurrent_process_id
and e.QUEUE_APPLICATION_ID=d.APPLICATION_ID
and e.CONCURRENT_QUEUE_ID=d.CONCURRENT_QUEUE_ID
and b.application_id=f.application_id
and trunc(actual_start_date) between to_date('&1', 'dd-mon-yy') and to_date('&2', 'dd-mon-yy')
and ((to_number(to_char(actual_start_date,'hh24')) between :hd1 and :hd3 ) or (to_number(to_char(actual_start_date,'hh24')) between :hd4 and :hd2 ) )
and to_number(to_char(actual_start_date,'D')) between :wd1 and :wd2
and ((a.actual_completion_date - a.actual_start_date) * 1440) > 30
group by substr(d.concurrent_queue_name,1,15),f.application_short_name,
         substr(c.user_concurrent_program_name,1,30),
         b.concurrent_program_name
order by Max desc;


prom
prom          ===================================================================
set term on
set head off
select 'High Volume Jobs >1000 During Peak Hour: '||to_char(to_date(to_number(:hd1),'hh24'),'HH24:MI')||' To '||to_char(to_date(to_number(:hd2),'hh24'),'HH24:MI') from dual;
set term off
set head on
prom          ===================================================================
column Waited format 999999.99
column MIN format 999999.99
column MAX format 999999.99
column AVG format 999999.99
column Queue format a15
column Cnt format 999999
column program_name format A30
column concurrent_program_name format A30
column c_hours format 9999.99
select substr(d.concurrent_queue_name,1,15) Queue,
       substr(c.user_concurrent_program_name,1,30) program_name,
       b.concurrent_program_name,
       count(*) Cnt,
       Avg(( a.actual_completion_date - a.actual_start_date ) * 1440) Avg,
       Min(( a.actual_completion_date - a.actual_start_date ) * 1440) Min,
       Max(( a.actual_completion_date - a.actual_start_date ) * 1440) Max,
       sum(actual_start_date - greatest(requested_start_date,request_date))* 1440 Waited
from fnd_concurrent_requests A ,
     fnd_concurrent_programs B ,
     fnd_concurrent_programs_tl C,
     fnd_concurrent_queues D,
     fnd_concurrent_processes E,
     fnd_application F
where a.program_application_id = b.application_id
and a.program_application_id = c.application_id
and a.concurrent_program_id = b.concurrent_program_id
and a.concurrent_program_id = c.concurrent_program_id
and c.language = 'US'
and a.actual_completion_date is not null
and a.controlling_manager=e.concurrent_process_id
and e.QUEUE_APPLICATION_ID=d.APPLICATION_ID
and e.CONCURRENT_QUEUE_ID=d.CONCURRENT_QUEUE_ID
and b.application_id=f.application_id
and trunc(actual_start_date) between to_date('&1', 'dd-mon-yy') and to_date('&2', 'dd-mon-yy')
and ((to_number(to_char(actual_start_date,'hh24')) between :hd1 and :hd3 ) or (to_number(to_char(actual_start_date,'hh24')) between :hd4 and :hd2 ) )
and to_number(to_char(actual_start_date,'D')) between :wd1 and :wd2
and b.concurrent_program_id in (select distinct CONCURRENT_PROGRAM_ID
                from fnd_concurrent_requests
                having count(*) > 1000
                group by  trunc(REQUESTED_START_DATE),CONCURRENT_PROGRAM_ID)
group by substr(d.concurrent_queue_name,1,15),f.application_short_name,
         substr(c.user_concurrent_program_name,1,30),
         b.concurrent_program_name
order by Cnt desc;


prom
prom          ===================================================================
set term on
set head off
select 'Fast Running Jobs During Peak Hour: '||to_char(to_date(to_number(:hd1),'hh24'),'HH24:MI')||' To '||to_char(to_date(to_number(:hd2),'hh24'),'HH24:MI') from dual;
set term off
set head on
prom          ===================================================================
set pages 1000
set linesize 200
set show off
column Min                     format 999999.99
column Max                     format 999999.99
column Avg                     format 999999.99
column Waited                  format 999999.99
column Queue                   format a15
column Cnt                     format 999999
column program_name            format A30
column concurrent_program_name format A30
column c_hours                 format 9999.99
select substr(d.concurrent_queue_name,1,15) Queue,
       substr(c.user_concurrent_program_name,1,30) program_name,
       b.concurrent_program_name,
       count(*) Cnt,
       Avg(( a.actual_completion_date - a.actual_start_date ) * 1440) Avg,
       Min(( a.actual_completion_date - a.actual_start_date ) * 1440) Min,
       Max(( a.actual_completion_date - a.actual_start_date ) * 1440) Max,
       sum(actual_start_date - greatest(requested_start_date,request_date))* 1440 Waited
from fnd_concurrent_requests A ,
     fnd_concurrent_programs B ,
     fnd_concurrent_programs_tl C,
     fnd_concurrent_queues D,
     fnd_concurrent_processes E,
     fnd_application F
where a.program_application_id = b.application_id
and a.program_application_id = c.application_id
and a.concurrent_program_id = b.concurrent_program_id
and a.concurrent_program_id = c.concurrent_program_id
and c.language = 'US'
and a.actual_completion_date is not null
and a.controlling_manager=e.concurrent_process_id
and e.QUEUE_APPLICATION_ID=d.APPLICATION_ID
and e.CONCURRENT_QUEUE_ID=d.CONCURRENT_QUEUE_ID
and b.application_id=f.application_id
and trunc(actual_start_date) between to_date('&1', 'dd-mon-yy') and to_date('&2', 'dd-mon-yy')
and ((to_number(to_char(actual_start_date,'hh24')) between :hd1 and :hd3 ) or (to_number(to_char(actual_start_date,'hh24')) between :hd4 and :hd2 ) )
and to_number(to_char(actual_start_date,'D')) between :wd1 and :wd2
and ((a.actual_completion_date - a.actual_start_date) * 1440) < 2
group by substr(d.concurrent_queue_name,1,15),f.application_short_name,
         substr(c.user_concurrent_program_name,1,30),
         b.concurrent_program_name
order by Max desc;


prom
prom          ===================================================================
set term on
set head off
select 'Long Running Jobs During Peak Hour: '||to_char(to_date(to_number(:hd1),'hh24'),'HH24:MI')||' To '||to_char(to_date(to_number(:hd2),'hh24'),'HH24:MI') from dual;
set term off
set head on
prom          ===================================================================
set show off
set head on
column max_time format 99999.99
column concurrent_program_id format 999999
column STRT_DT format a16
column PROG_NM format a40
column TIME format a10
select PROG_NM, STRT_DT, max_time
from (select substr(CNAME.user_concurrent_program_name,1,40) Prog_nm
      ,to_char(EXEC_DT,'dd-mon-rr hh24:mi') STRT_DT
      ,CREQ.MAX_TIME MAX_TIME
      ,CASE WHEN (to_number(to_char(EXEC_DT,'hh24')) BETWEEN :hd1 AND :hd2) THEN 'PEAK HOUR'
       ELSE 'OFF HOUR'
       END TIME
      from (select concurrent_program_id,actual_start_date EXEC_DT
                   ,count(concurrent_program_id) OCCUR
                   ,max(actual_completion_date-actual_start_date)*24*60 MAX_TIME
            from apps.fnd_concurrent_requests
            where status_code='C'
            and phase_code='C'
            and trunc(actual_start_date) between to_date('&1', 'dd-mon-yy') and to_date('&2', 'dd-mon-yy')
            and ((to_number(to_char(actual_start_date,'hh24')) between :hd1 and :hd3) or (to_number(to_char(actual_start_date,'hh24')) between :hd4 and :hd2))
            and to_number(to_char(actual_start_date,'D')) between :wd1 and :wd2
            group by concurrent_program_id ,actual_start_date
            having max(actual_completion_date-actual_start_date)*24*60 >30) CREQ
           ,apps.fnd_concurrent_programs_tl CNAME
      where CREQ.concurrent_program_id=CNAME.concurrent_program_id
      and CNAME.language='US'
      and (substr(CNAME.user_concurrent_program_name,1,40), CREQ.MAX_TIME) in
    (select Prog_nm,max(MX)
    from
      (select substr(CNAME1.user_concurrent_program_name,1,40) Prog_nm,CREQ1.OCCUR OCR,CREQ1.MAX_TIME MX,CREQ1.AVG_TIME AV
       from (select concurrent_program_id,actual_start_date EXEC_DT
                    ,count(concurrent_program_id) OCCUR
                    ,min(actual_completion_date-actual_start_date)*24*60 MIN_TIME
                    ,max(actual_completion_date-actual_start_date)*24*60 MAX_TIME
                    ,avg(actual_completion_date-actual_start_date)*24*60 AVG_TIME
             from apps.fnd_concurrent_requests
             where status_code='C'
             and phase_code='C'
             and trunc(actual_start_date)>trunc(sysdate-60)
             group by concurrent_program_id ,actual_start_date
             having max(actual_completion_date-actual_start_date)*24*60 >30) CREQ1
      ,apps.fnd_concurrent_programs_tl CNAME1
      where CREQ1.concurrent_program_id=CNAME1.concurrent_program_id)
      group by Prog_nm)
      order by 3 desc)
where time='PEAK HOUR';

