username = 'weblogic'
password = ’test'
URL='t3://hostname:9001'
connect(username,password,URL)
domainRuntime()
cd('ServerRuntimes')
servers=domainRuntimeService.getServerRuntimes()
for server in servers:
  print  server.getName(), ':', server.getState(), ':', server.getListenAddress(), ':', server.getHealthState()
disconnect()
