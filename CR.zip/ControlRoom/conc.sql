SQL> set long 20000000
SQL> select dbms_metadata.get_ddl('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS') from dual;

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
                                                                                                                                                                                                        
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "APPS"."FND_CONCURRENT_WORKER_REQU                                                                                                                           
ESTS" ("REQUEST_ID", "LAST_UPDATE_DATE", "LAST_UPDAT                                                                                                                                                    
ED_BY", "REQUEST_DATE", "REQUESTED_BY", "PHASE_CODE"                                                                                                                                                    
, "STATUS_CODE", "PRIORITY_REQUEST_ID", "PRIORITY",                                                                                                                                                     
"REQUESTED_START_DATE", "HOLD_FLAG", "ENFORCE_SERIAL                                                                                                                                                    
ITY_FLAG", "SINGLE_THREAD_FLAG", "HAS_SUB_REQUEST",                                                                                                                                                     
"IS_SUB_REQUEST", "IMPLICIT_CODE", "UPDATE_PROTECTED                                                                                                                                                    
", "QUEUE_METHOD_CODE", "ARGUMENT_INPUT_METHOD_CODE"                                                                                                                                                    
, "ORACLE_ID", "PROGRAM_APPLICATION_ID", "CONCURRENT                                                                                                                                                    
_PROGRAM_ID", "RESPONSIBILITY_APPLICATION_ID", "RESP                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
ONSIBILITY_ID", "NUMBER_OF_ARGUMENTS", "NUMBER_OF_CO                                                                                                                                                    
PIES", "SAVE_OUTPUT_FLAG", "NLS_COMPLIANT", "LAST_UP                                                                                                                                                    
DATE_LOGIN", "NLS_LANGUAGE", "NLS_TERRITORY", "PRINT                                                                                                                                                    
ER", "PRINT_STYLE", "PRINT_GROUP", "REQUEST_CLASS_AP                                                                                                                                                    
PLICATION_ID", "CONCURRENT_REQUEST_CLASS_ID", "PAREN                                                                                                                                                    
T_REQUEST_ID", "CONC_LOGIN_ID", "LANGUAGE_ID", "DESC                                                                                                                                                    
RIPTION", "REQ_INFORMATION", "RESUBMIT_INTERVAL", "R                                                                                                                                                    
ESUBMIT_INTERVAL_UNIT_CODE", "RESUBMIT_INTERVAL_TYPE                                                                                                                                                    
_CODE", "RESUBMIT_TIME", "RESUBMIT_END_DATE", "RESUB                                                                                                                                                    
MITTED", "CONTROLLING_MANAGER", "ACTUAL_START_DATE",                                                                                                                                                    
 "ACTUAL_COMPLETION_DATE", "COMPLETION_TEXT", "OUTCO                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
ME_PRODUCT", "OUTCOME_CODE", "CPU_SECONDS", "LOGICAL                                                                                                                                                    
_IOS", "PHYSICAL_IOS", "LOGFILE_NAME", "LOGFILE_NODE                                                                                                                                                    
_NAME", "OUTFILE_NAME", "OUTFILE_NODE_NAME", "ARGUME                                                                                                                                                    
NT_TEXT", "ARGUMENT1", "ARGUMENT2", "ARGUMENT3", "AR                                                                                                                                                    
GUMENT4", "ARGUMENT5", "ARGUMENT6", "ARGUMENT7", "AR                                                                                                                                                    
GUMENT8", "ARGUMENT9", "ARGUMENT10", "ARGUMENT11", "                                                                                                                                                    
ARGUMENT12", "ARGUMENT13", "ARGUMENT14", "ARGUMENT15                                                                                                                                                    
", "ARGUMENT16", "ARGUMENT17", "ARGUMENT18", "ARGUME                                                                                                                                                    
NT19", "ARGUMENT20", "ARGUMENT21", "ARGUMENT22", "AR                                                                                                                                                    
GUMENT23", "ARGUMENT24", "ARGUMENT25", "CRM_THRSHLD"                                                                                                                                                    
, "CRM_TSTMP", "CRITICAL", "REQUEST_TYPE", "ORACLE_P                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
ROCESS_ID", "ORACLE_SESSION_ID", "OS_PROCESS_ID", "P                                                                                                                                                    
RINT_JOB_ID", "OUTPUT_FILE_TYPE", "RELEASE_CLASS_APP                                                                                                                                                    
_ID", "RELEASE_CLASS_ID", "STALE_DATE", "CANCEL_OR_H                                                                                                                                                    
OLD", "NOTIFY_ON_PP_ERROR", "CD_ID", "REQUEST_LIMIT"                                                                                                                                                    
, "CRM_RELEASE_DATE", "POST_REQUEST_STATUS", "COMPLE                                                                                                                                                    
TION_CODE", "INCREMENT_DATES", "RESTART", "ENABLE_TR                                                                                                                                                    
ACE", "RESUB_COUNT", "NLS_CODESET", "OFILE_SIZE", "L                                                                                                                                                    
FILE_SIZE", "STALE", "SECURITY_GROUP_ID", "RESOURCE_                                                                                                                                                    
CONSUMER_GROUP", "EXP_DATE", "QUEUE_APP_ID", "QUEUE_                                                                                                                                                    
ID", "OPS_INSTANCE", "INTERIM_STATUS_CODE", "ROOT_RE                                                                                                                                                    
QUEST_ID", "ORIGIN", "NLS_NUMERIC_CHARACTERS", "PP_S                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
TART_DATE", "PP_END_DATE", "ORG_ID", "RUN_NUMBER", "                                                                                                                                                    
NODE_NAME1", "NODE_NAME2", "CONNSTR1", "CONNSTR2", "                                                                                                                                                    
EDITION_NAME", "RECALC_PARAMETERS", "NLS_SORT", "QUE                                                                                                                                                    
UE_APPLICATION_ID", "CONCURRENT_QUEUE_ID", "CONCURRE                                                                                                                                                    
NT_QUEUE_NAME", "CONTROL_CODE", "PROCESSOR_APPLICATI                                                                                                                                                    
ON_ID", "CONCURRENT_PROCESSOR_ID", "RUNNING_PROCESSE                                                                                                                                                    
S", "MAX_PROCESSES", "CACHE_SIZE", "TARGET_NODE", "Q                                                                                                                                                    
UEUE_DESCRIPTION", "CONCURRENT_PROGRAM_NAME", "EXECU                                                                                                                                                    
TION_METHOD_CODE", "ARGUMENT_METHOD_CODE", "QUEUE_CO                                                                                                                                                    
NTROL_FLAG", "RUN_ALONE_FLAG", "ENABLED_FLAG", "PROG                                                                                                                                                    
RAM_DESCRIPTION", "USER_CONCURRENT_PROGRAM_NAME", "R                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
EQUEST_DESCRIPTION") AS                                                                                                                                                                                 
  Select R."REQUEST_ID",R."LAST_UPDATE_DATE",R."LAST_                                                                                                                                                   
UPDATED_BY",R."REQUEST_DATE",R."REQUESTED_BY",R."PHA                                                                                                                                                    
SE_CODE",R."STATUS_CODE",R."PRIORITY_REQUEST_ID",R."                                                                                                                                                    
PRIORITY",R."REQUESTED_START_DATE",R."HOLD_FLAG",R."                                                                                                                                                    
ENFORCE_SERIALITY_FLAG",R."SINGLE_THREAD_FLAG",R."HA                                                                                                                                                    
S_SUB_REQUEST",R."IS_SUB_REQUEST",R."IMPLICIT_CODE",                                                                                                                                                    
R."UPDATE_PROTECTED",R."QUEUE_METHOD_CODE",R."ARGUME                                                                                                                                                    
NT_INPUT_METHOD_CODE",R."ORACLE_ID",R."PROGRAM_APPLI                                                                                                                                                    
CATION_ID",R."CONCURRENT_PROGRAM_ID",R."RESPONSIBILI                                                                                                                                                    
TY_APPLICATION_ID",R."RESPONSIBILITY_ID",R."NUMBER_O                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
F_ARGUMENTS",R."NUMBER_OF_COPIES",R."SAVE_OUTPUT_FLA                                                                                                                                                    
G",R."NLS_COMPLIANT",R."LAST_UPDATE_LOGIN",R."NLS_LA                                                                                                                                                    
NGUAGE",R."NLS_TERRITORY",R."PRINTER",R."PRINT_STYLE                                                                                                                                                    
",R."PRINT_GROUP",R."REQUEST_CLASS_APPLICATION_ID",R                                                                                                                                                    
."CONCURRENT_REQUEST_CLASS_ID",R."PARENT_REQUEST_ID"                                                                                                                                                    
,R."CONC_LOGIN_ID",R."LANGUAGE_ID",R."DESCRIPTION",R                                                                                                                                                    
."REQ_INFORMATION",R."RESUBMIT_INTERVAL",R."RESUBMIT                                                                                                                                                    
_INTERVAL_UNIT_CODE",R."RESUBMIT_INTERVAL_TYPE_CODE"                                                                                                                                                    
,R."RESUBMIT_TIME",R."RESUBMIT_END_DATE",R."RESUBMIT                                                                                                                                                    
TED",R."CONTROLLING_MANAGER",R."ACTUAL_START_DATE",R                                                                                                                                                    
."ACTUAL_COMPLETION_DATE",R."COMPLETION_TEXT",R."OUT                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
COME_PRODUCT",R."OUTCOME_CODE",R."CPU_SECONDS",R."LO                                                                                                                                                    
GICAL_IOS",R."PHYSICAL_IOS",R."LOGFILE_NAME",R."LOGF                                                                                                                                                    
ILE_NODE_NAME",R."OUTFILE_NAME",R."OUTFILE_NODE_NAME                                                                                                                                                    
",R."ARGUMENT_TEXT",R."ARGUMENT1",R."ARGUMENT2",R."A                                                                                                                                                    
RGUMENT3",R."ARGUMENT4",R."ARGUMENT5",R."ARGUMENT6",                                                                                                                                                    
R."ARGUMENT7",R."ARGUMENT8",R."ARGUMENT9",R."ARGUMEN                                                                                                                                                    
T10",R."ARGUMENT11",R."ARGUMENT12",R."ARGUMENT13",R.                                                                                                                                                    
"ARGUMENT14",R."ARGUMENT15",R."ARGUMENT16",R."ARGUME                                                                                                                                                    
NT17",R."ARGUMENT18",R."ARGUMENT19",R."ARGUMENT20",R                                                                                                                                                    
."ARGUMENT21",R."ARGUMENT22",R."ARGUMENT23",R."ARGUM                                                                                                                                                    
ENT24",R."ARGUMENT25",R."CRM_THRSHLD",R."CRM_TSTMP",                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
R."CRITICAL",R."REQUEST_TYPE",R."ORACLE_PROCESS_ID",                                                                                                                                                    
R."ORACLE_SESSION_ID",R."OS_PROCESS_ID",R."PRINT_JOB                                                                                                                                                    
_ID",R."OUTPUT_FILE_TYPE",R."RELEASE_CLASS_APP_ID",R                                                                                                                                                    
."RELEASE_CLASS_ID",R."STALE_DATE",R."CANCEL_OR_HOLD                                                                                                                                                    
",R."NOTIFY_ON_PP_ERROR",R."CD_ID",R."REQUEST_LIMIT"                                                                                                                                                    
,R."CRM_RELEASE_DATE",R."POST_REQUEST_STATUS",R."COM                                                                                                                                                    
PLETION_CODE",R."INCREMENT_DATES",R."RESTART",R."ENA                                                                                                                                                    
BLE_TRACE",R."RESUB_COUNT",R."NLS_CODESET",R."OFILE_                                                                                                                                                    
SIZE",R."LFILE_SIZE",R."STALE",R."SECURITY_GROUP_ID"                                                                                                                                                    
,R."RESOURCE_CONSUMER_GROUP",R."EXP_DATE",R."QUEUE_A                                                                                                                                                    
PP_ID",R."QUEUE_ID",R."OPS_INSTANCE",R."INTERIM_STAT                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
US_CODE",R."ROOT_REQUEST_ID",R."ORIGIN",R."NLS_NUMER                                                                                                                                                    
IC_CHARACTERS",R."PP_START_DATE",R."PP_END_DATE",R."                                                                                                                                                    
ORG_ID",R."RUN_NUMBER",R."NODE_NAME1",R."NODE_NAME2"                                                                                                                                                    
,R."CONNSTR1",R."CONNSTR2",R."EDITION_NAME",R."RECAL                                                                                                                                                    
C_PARAMETERS",R."NLS_SORT", Q.Application_ID Queue_A                                                                                                                                                    
pplication_ID,                                                                                                                                                                                          
       Q.Concurrent_Queue_ID,Q.Concurrent_Queue_Name,Control_Co                                                                                                                                         
de,                                                                                                                                                                                                     
       Processor_Application_ID, Concurrent_Processor_ID,                                                                                                                                               
       Running_Processes, Max_Processes, Cache_Size,                                                                                                                                                    
       Target_Node,                                                                                                                                                                                     

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
       QT.Description Queue_Description,                                                                                                                                                                
       Concurrent_Program_Name, Execution_Method_Code,                                                                                                                                                  
       Argument_Method_Code, Queue_Control_Flag, Run_Al                                                                                                                                                 
one_Flag,                                                                                                                                                                                               
       P.Enabled_Flag, PT.Description Program_Description,                                                                                                                                              
       PT.User_Concurrent_Program_Name,                                                                                                                                                                 
       Decode(R.Description, NULL,                                                                                                                                                                      
        PT.User_Concurrent_Program_Name,                                                                                                                                                                
        R.Description||' ('||PT.User_Concurrent_Program_Name||')')                                                                                                                                      
       Request_Description                                                                                                                                                                              
from Fnd_Concurrent_Requests R,                                                                                                                                                                         

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
     Fnd_Concurrent_Queues Q, Fnd_Concurrent_Programs                                                                                                                                                   
 P,                                                                                                                                                                                                     
     Fnd_Concurrent_Queues_TL QT, Fnd_Concurrent_Programs_TL PT                                                                                                                                         
where                                                                                                                                                                                                   
    PT.Language=Userenv('lang')                                                                                                                                                                         
And PT.Concurrent_Program_ID=P.Concurrent_Program_ID                                                                                                                                                    
And PT.Application_ID=P.Application_ID                                                                                                                                                                  
And P.Application_ID=R.Program_Application_ID                                                                                                                                                           
And P.Concurrent_Program_ID=R.Concurrent_Program_ID                                                                                                                                                     
And QT.Language=Userenv('lang')                                                                                                                                                                         
And QT.Concurrent_Queue_ID=Q.Concurrent_Queue_ID                                                                                                                                                        

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
And QT.Application_ID=Q.Application_ID                                                                                                                                                                  
and R.Status_Code in ('R', 'T', 'Q', 'I')                                                                                                                                                               
and (                                                                                                                                                                                                   
     (R.Status_Code = 'R' OR R.Status_Code ='T')                                                                                                                                                        
     and exists                                                                                                                                                                                         
     ( select null from fnd_concurrent_processes                                                                                                                                                        
       where concurrent_process_id=controlling_manager                                                                                                                                                  
       and queue_application_id=Q.application_id                                                                                                                                                        
       and concurrent_queue_id=Q.concurrent_queue_id                                                                                                                                                    
     )                                                                                                                                                                                                  
     OR                                                                                                                                                                                                 

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
     (  P.Enabled_Flag='Y'                                                                                                                                                                              
        And R.Program_Application_Id=P.Application_Id                                                                                                                                                   
        And R.Concurrent_Program_Id=P.Concurrent_Prog                                                                                                                                                   
ram_Id                                                                                                                                                                                                  
        AND                                                                                                                                                                                             
        (                                                                                                                                                                                               
           ( Q.Application_ID=0 and Q.Concurrent_Queue_ID=1                                                                                                                                             
             and R.Queue_Method_Code='B' and R.Status_Code='Q'                                                                                                                                          
             and P.Queue_Control_Flag='Y'                                                                                                                                                               
           )                                                                                                                                                                                            
           OR                                                                                                                                                                                           

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
           ( Q.Application_ID=0 and Q.Concurrent_Queue_ID=4                                                                                                                                             
             and R.Queue_Method_Code='B' and R.Status_Cod                                                                                                                                               
e='Q'                                                                                                                                                                                                   
             and P.Queue_Control_Flag='N'                                                                                                                                                               
           )                                                                                                                                                                                            
           OR                                                                                                                                                                                           
           (                                                                                                                                                                                            
            (R.Status_Code = 'I' OR R.Status_Code = 'Q')                                                                                                                                                
            And P.Queue_Control_Flag='N'                                                                                                                                                                
            AND EXISTS                                                                                                                                                                                  
            (  Select Null From Fnd_Oracle_Userid O                                                                                                                                                     

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
              Where R.Oracle_Id=O.Oracle_Id                                                                                                                                                             
              AND EXISTS                                                                                                                                                                                
              ( Select Null From Fnd_Conflicts_Domain C                                                                                                                                                 
                Where P.Run_Alone_Flag=C.RunAlone_Flag                                                                                                                                                  
                And R.CD_Id = C.CD_Id                                                                                                                                                                   
              )                                                                                                                                                                                         
            )                                                                                                                                                                                           
           )                                                                                                                                                                                            
           And                                                                                                                                                                                          
           (                                                                                                                                                                                            
             ( Q.APPLICATION_ID=0 AND Q.CONCURRENT_QUEUE_ID=0                                                                                                                                           

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),(0,31                                                                                                                             
721),(0,31722),(0,31757))                                                                                                                                                                               
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) NOT IN ((0,43586                                                                                                                                    
),(140,20224),(140,40224),(140,481353),(200,37306),(                                                                                                                                                    
510,40112),(510,40113),(510,41497),(510,41498),(530,                                                                                                                                                    
41859),(530,41860),(535,41492),(535,41493),(535,4149                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
4),(20003,54331),(20003,149078),(20003,250342),(2000                                                                                                                                                    
3,254342),(20003,255342),(20003,297342),(20003,30535                                                                                                                                                    
2),(20003,325350),(20003,332352),(20003,346352),(200                                                                                                                                                    
03,348352),(20003,362352),(20003,366352),(20003,3703                                                                                                                                                    
52),(20003,373352),(20003,406352),(20003,410353),(20                                                                                                                                                    
003,411353),(20003,413353),(20003,432353),(20003,445                                                                                                                                                    
353),(20003,460353),(20003,469354),(20003,471353),(2                                                                                                                                                    
0003,472355),(20003,481354),(20003,681356),(20003,68                                                                                                                                                    
7357),(20063,317350)) AND ((R.REQUEST_CLASS_APPLICAT                                                                                                                                                    
ION_ID IS NULL AND R.CONCURRENT_REQUEST_CLASS_ID IS                                                                                                                                                     
NULL)  OR (R.REQUEST_CLASS_APPLICATION_ID,R.CONCURRE                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
NT_REQUEST_CLASS_ID) NOT IN ((20003,4),(20003,24),(2                                                                                                                                                    
0003,44))))                                                                                                                                                                                             
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=0 AND Q.CONCURRENT_QUEUE_ID=1                                                                                                                                           
063                                                                                                                                                                                                     
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,9                                                                                                                                             
8),(0,100),(0,31721),(0,31722),(0,31757))                                                                                                                                                               

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID)                                                                                                                                                     
IN ((0,42852),(0,44706)))                                                                                                                                                                               
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=0 AND Q.CONCURRENT_QUEUE_ID=26304                                                                                                                                       
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),                                                                                                                                  

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
(0,31721),(0,31722),(0,31757))                                                                                                                                                                          
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,4358                                                                                                                                         
6),(20003,373352)))                                                                                                                                                                                     
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=140 AND Q.CONCURRENT_                                                                                                                                                   
QUEUE_ID=31307                                                                                                                                                                                          
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),(0,3                                                                                                                              
1721),(0,31722),(0,31757))                                                                                                                                                                              
               )                                                                                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=275 AND Q.CONCURRENT_QU                                                                                                                                                 
EUE_ID=40                                                                                                                                                                                               
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN                                                                                                                                                   
 ((275,32738),(275,34041))                                                                                                                                                                              
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((275,32738)                                                                                                                                     
,(275,34041)))                                                                                                                                                                                          
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=385 AND Q.CONCURRENT_QUEUE                                                                                                                                              
_ID=1260                                                                                                                                                                                                
                     AND                                                                                                                                                                                

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN                                                                                                                                                   
((0,98),(0,100),(0,31721),(0,31722),(0,31757))                                                                                                                                                          
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((385,45107),(385,                                                                                                                               
45108),(385,45110),(385,45111)))                                                                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=401 AND Q.CONCURRENT_QUEUE_ID=10                                                                                                                                        

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((401,3231                                                                                                                                        
9),(401,32320),(401,32321),(702,31888),(702,31889),(                                                                                                                                                    
702,32763),(706,31915))                                                                                                                                                                                 
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((401,32237),(4                                                                                                                                  
01,32319),(401,32320),(401,32321),(702,31888),(702,3                                                                                                                                                    
1889),(702,32763),(706,31892),(706,31915)))                                                                                                                                                             

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=510 AND Q.CONCURRENT_QU                                                                                                                                                 
EUE_ID=1046                                                                                                                                                                                             
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),(0,3172                                                                                                                           
1),(0,31722),(0,31757))                                                                                                                                                                                 
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((510,40112),(5                                                                                                                                  
10,40113),(510,41497),(510,41498)))                                                                                                                                                                     
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=530 AND Q.CONCURRENT_QUEUE_ID=1                                                                                                                                         
258                                                                                                                                                                                                     
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,9                                                                                                                                             
8),(0,100),(0,31721),(0,31722),(0,31757))                                                                                                                                                               

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID)                                                                                                                                                     
IN ((530,41859),(530,41860)))                                                                                                                                                                           
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=535 AND Q.CONCURRENT_QUEUE_ID=1003                                                                                                                                      
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,                                                                                                                                       

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
100),(0,31721),(0,31722),(0,31757))                                                                                                                                                                     
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((5                                                                                                                                              
35,40117),(535,40118),(535,40119),(535,40120)) OR R.                                                                                                                                                    
PROGRAM_APPLICATION_ID IN (535))                                                                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=542 AND Q.CONCURRENT_QUEUE_ID=4330                                                                                                                                      
7                                                                                                                                                                                                       
                     AND                                                                                                                                                                                

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98)                                                                                                                                           
,(0,100),(0,31721),(0,31722),(0,31757))                                                                                                                                                                 
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN                                                                                                                                                  
 ((542,512403)))                                                                                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=695 AND Q.CONCURRENT_QUE                                                                                                                                                

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
UE_ID=1047                                                                                                                                                                                              
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) I                                                                                                                                                    
N ((0,98),(0,100),(0,31721),(0,31722),(0,31757))                                                                                                                                                        
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((695,42002),(69                                                                                                                                 
5,42003),(695,42004),(695,42005),(695,42006),(695,42                                                                                                                                                    
007),(695,42008)))                                                                                                                                                                                      

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=696 AND Q.CONCURRENT_Q                                                                                                                                                  
UEUE_ID=1024                                                                                                                                                                                            
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),(0,317                                                                                                                            
21),(0,31722),(0,31757))                                                                                                                                                                                
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((696,41822)))                                                                                                                                   
                                                                                                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=696 AND Q.CONCURRENT_QUEUE_ID=1025                                                                                                                                      
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100                                                                                                                                    
),(0,31721),(0,31722),(0,31757))                                                                                                                                                                        
               )                                                                                                                                                                                        

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((696,                                                                                                                                           
41823)))                                                                                                                                                                                                
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=704 AND Q.CONCURRENT_QUEUE_ID=39                                                                                                                                        
                                                                                                                                                                                                        
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((704,31                                                                                                                                          

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
556))                                                                                                                                                                                                   
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((704,3                                                                                                                                          
1556)))                                                                                                                                                                                                 
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=716 AND Q.CONCURRENT_QUEUE_ID=114                                                                                                                                       
1                                                                                                                                                                                                       
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98)                                                                                                                                           
,(0,100),(0,31721),(0,31722),(0,31757))                                                                                                                                                                 
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN                                                                                                                                                  
 ((716,43594)))                                                                                                                                                                                         
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=9010 AND Q.CONCURRENT_QUE                                                                                                                                               
UE_ID=37307                                                                                                                                                                                             

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),(0,3172                                                                                                                           
1),(0,31722),(0,31757))                                                                                                                                                                                 
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((9010,512399))                                                                                                                                  
)                                                                                                                                                                                                       
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
             ( Q.APPLICATION_ID=20003 AND Q.CONCURRENT_QUEUE_ID=15300                                                                                                                                   
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0                                                                                                                                        
,100),(0,31721),(0,31722),(0,31757))                                                                                                                                                                    
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
(((R.REQUEST_CLASS_APPLICATION_ID IS NULL AND R.CONCURREN                                                                                                                                               
T_REQUEST_CLASS_ID IS NULL)  OR (R.REQUEST_CLASS_APP                                                                                                                                                    
LICATION_ID,R.CONCURRENT_REQUEST_CLASS_ID) NOT IN ((                                                                                                                                                    

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
20003,24))) AND ((R.REQUEST_CLASS_APPLICATION_ID,R.C                                                                                                                                                    
ONCURRENT_REQUEST_CLASS_ID) IN ((20003,4))))                                                                                                                                                            
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=20003 AND Q.CONCURRENT                                                                                                                                                  
_QUEUE_ID=16300                                                                                                                                                                                         
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),(0,                                                                                                                               
31721),(0,31722),(0,31757))                                                                                                                                                                             

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
(((R.REQUEST_CLASS_APPLICATION_ID IS NULL AND R.CONCURRENT_REQUEST                                                                                                                                      
_CLASS_ID IS NULL)  OR (R.REQUEST_CLASS_APPLICATION_                                                                                                                                                    
ID,R.CONCURRENT_REQUEST_CLASS_ID) NOT IN ((20003,4))                                                                                                                                                    
) AND ((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRA                                                                                                                                                    
M_ID) IN ((0,43586),(20003,373352)) OR (R.REQUEST_CL                                                                                                                                                    
ASS_APPLICATION_ID,R.CONCURRENT_REQUEST_CLASS_ID) IN                                                                                                                                                    
 ((20003,24))))                                                                                                                                                                                         
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
             ( Q.APPLICATION_ID=20003 AND Q.CONCURRENT_QU                                                                                                                                               
EUE_ID=19304                                                                                                                                                                                            
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),(0,317                                                                                                                            
21),(0,31722),(0,31757))                                                                                                                                                                                
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.REQUEST_CLASS_APPLICATION_ID,R.CONCURRENT_REQUEST_CLASS_ID) IN ((                                                                                                                                   
20003,44)))                                                                                                                                                                                             

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=20003 AND Q.CONCURRENT_QUEUE_                                                                                                                                           
ID=32307                                                                                                                                                                                                
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN                                                                                                                                                   
((0,98),(0,100),(0,31721),(0,31722),(0,31757))                                                                                                                                                          
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((140,20224),(140,                                                                                                                               
40224),(140,481353),(20003,54331),(20003,149078),(20                                                                                                                                                    
003,250342),(20003,254342),(20003,255342),(20003,297                                                                                                                                                    
342),(20003,305352),(20003,325350),(20003,332352),(2                                                                                                                                                    
0003,346352),(20003,348352),(20003,362352),(20003,36                                                                                                                                                    
6352),(20003,370352),(20003,406352),(20003,410353),(                                                                                                                                                    
20003,411353),(20003,413353),(20003,432353),(20003,4                                                                                                                                                    
45353),(20003,460353),(20003,469354),(20003,471353),                                                                                                                                                    
(20003,472355),(20003,481354),(20003,626356)))                                                                                                                                                          
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
             ( Q.APPLICATION_ID=20003 AND Q.CONCURRE                                                                                                                                                    
NT_QUEUE_ID=41307                                                                                                                                                                                       
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,100),(                                                                                                                                 
0,31721),(0,31722),(0,31757))                                                                                                                                                                           
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((200,373                                                                                                                                        
06),(20003,681356),(20003,687357),(20003,687358)))                                                                                                                                                      

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
             )                                                                                                                                                                                          
             OR                                                                                                                                                                                         
             ( Q.APPLICATION_ID=20063 AND Q.CONCURRENT_QUEUE_ID=22304                                                                                                                                   
                     AND                                                                                                                                                                                
               ( P.Execution_Method_Code != 'S'                                                                                                                                                         
                 OR                                                                                                                                                                                     
(R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((0,98),(0,10                                                                                                                                     
0),(0,31721),(0,31722),(0,31757))                                                                                                                                                                       
               )                                                                                                                                                                                        
               AND                                                                                                                                                                                      
((R.PROGRAM_APPLICATION_ID,R.CONCURRENT_PROGRAM_ID) IN ((200                                                                                                                                            

DBMS_METADATA.GET_DDL('VIEW','FND_CONCURRENT_WORKER_REQUESTS','APPS')                                                                                                                                   
--------------------------------------------------------------------------------                                                                                                                        
63,317350)))                                                                                                                                                                                            
             )                                                                                                                                                                                          
           )                                                                                                                                                                                            
        )                                                                                                                                                                                               
     )                                                                                                                                                                                                  
    )                                                                                                                                                                                                   
                                                                                                                                                                                                        

SQL> spool off
