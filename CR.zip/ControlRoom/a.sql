set echo off verify off head off feed off pages0 trimspool on lines 200;
col request_id for 999999999999
col USER_CONCURRENT_PROGRAM_NAME for a45
col requestor for a15
spool abc.lst
select
--request_id||' |',USER_CONCURRENT_PROGRAM_NAME||' |',requestor||'|',status_code||'|', phase_code||'|',to_char(ACTUAL_COMPLETION_DATE,'DD-MON-YYYY HH24:MI') ||'|'
request_id||'|'||USER_CONCURRENT_PROGRAM_NAME||' |'||requestor||'|'||status_code||'|'|| phase_code||'|'||to_char(ACTUAL_COMPLETION_DATE,'DD-MON-YYYY HH24:MI') ||'|'
from apps.fnd_conc_req_summary_v
where requestor = 'SCM_SCHEDULER'
and status_code='E'
and ACTUAL_COMPLETION_DATE > sysdate-1;
spool off
