set pagesize 500
set linesize 200
set trimspool on
column "EXPIRE DATE" format a15

select username as "USER NAME", expiry_date as "EXPIRE DATE", account_status,trunc(sysdate-expiry_date),profile
from dba_users
where expiry_date < sysdate+7
and account_status IN ( 'OPEN', 'EXPIRED(GRACE)' )
order by account_status, expiry_date, username;
