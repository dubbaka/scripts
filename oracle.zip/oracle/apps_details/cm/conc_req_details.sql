set pagesize 24 linesize 200 echo off verify off wrap on
column reqid format 9999999999 heading "Request Id"
column sesid format a10 heading "Session"
column ospid format a10 heading "OS Pid"
column USER_CONCURRENT_PROGRAM_NAME format a45 heading "Program Name"
column user_name format a20 heading "Requestor"
column event format a30 heading "Wait event"
column user_concurrent_queue_name format a30 heading "Queue name"
select
   a.request_id reqid,a.status_code,a.phase_code,e.USER_CONCURRENT_PROGRAM_NAME,
   d.sid||','||d.serial# sesid,c.spid ospid,d.inst_id "Instance Id",d.sql_hash_value "hash value",g.event,to_char(actual_start_date, 'MM/DD/YY HH24:MI') start_time,q.user_concurrent_queue_name
from
   applsys.fnd_concurrent_requests a,
   applsys.fnd_concurrent_processes b,
   gv$process c, gv$session d,gv$session_wait g,
   apps.fnd_concurrent_programs_tl e,
   apps.fnd_user f,
   apps.fnd_concurrent_queues_tl q
where
   a.controlling_manager=b.concurrent_process_id
   and c.spid=a.oracle_process_id
   and c.addr=d.paddr
   and e.concurrent_program_id=a.concurrent_program_id
   and a.requested_by = f.user_id
   and b.QUEUE_APPLICATION_ID = q.application_id
   and b.CONCURRENT_QUEUE_ID = q.CONCURRENT_QUEUE_ID
   and d.sid=nvl('&sid',d.sid)
   and a.request_id=nvl('&request_id',a.request_id)
   and upper(d.module) like upper(nvl('%&module%',d.module))
   and upper(e.USER_CONCURRENT_PROGRAM_NAME) like upper(nvl('%&user_concurrent_program_name%',e.USER_CONCURRENT_PROGRAM_NAME))
   and upper(q.user_concurrent_queue_name) like upper(nvl('%&user_concurrent_queue_name%',q.user_concurrent_queue_name))
   and a.phase_code='R'
   and b.instance_number=d.inst_id
   and d.inst_id=g.inst_id
   and d.sid=g.sid
   and d.inst_id=nvl('&inst_id',d.inst_id)
   and e.language=USERENV('LANG')
   and q.language=USERENV('LANG')
order by d.inst_id;
exit;
