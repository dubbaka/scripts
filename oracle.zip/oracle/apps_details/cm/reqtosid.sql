set lines 200 verify off
col module for a25
col event for a30 trunc
SELECT d.inst_id,a.request_id, d.sid, d.serial#,c.spid,d.module,e.event,d.last_call_et/60
  FROM   apps.fnd_concurrent_requests a,
         apps.fnd_concurrent_processes b,
         gv$process c,
         gv$session d,
	 gv$session_wait e
  WHERE  a.controlling_manager = b.concurrent_process_id
  AND    c.spid = a.oracle_process_id
  AND    c.addr = d.paddr
  and    e.sid=d.sid
  and    b.instance_number=d.inst_id
  AND    a.request_id=nvl('&reqs',1)
  AND    a.status_code='R';
