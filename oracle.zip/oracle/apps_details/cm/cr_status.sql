set verify off
column "Req ID" format 99999999999
column "Status" format a12
column "Incompatible Program" format a55
column "Program" format a55
column "HIDE_ME" noprint
column "Conc Program Name" format a40
break on b.description

select
  request_id "Req ID",
  decode(status_code,'I','Priority '||priority,
    'Q','Priority '||priority,'R','Running','C','Completed',
    'T','Terminating','D','Deleted','???') "Status",
  p.USER_CONCURRENT_PROGRAM_NAME "Conc Program Name"
from
  apps.FND_CONCURRENT_PROGRAMS_tl p,
  apps.fnd_concurrent_requests r
where r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID
  and r.PROGRAM_APPLICATION_ID = p.APPLICATION_ID
  and p.language=USERENV('LANG')
  and request_id = &request_id
;
undefine request_id
exit
