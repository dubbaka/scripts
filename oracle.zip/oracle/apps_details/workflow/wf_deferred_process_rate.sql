set lines 200 pages 100 verify off
select a.etime " Date ",a.count "Enqueue Count",b.count "Dequeue Count"from 
(select /*+ parallel (x,8) */ to_char(enq_time,'DD-MON-YYYY HH24') etime,count(1) count from applsys.wf_deferred x where state=2 group by to_char(enq_time,'DD-MON-YYYY HH24')) a,
(select /*+ parallel (y,8) */ to_char(deq_time,'DD-MON-YYYY HH24') dtime,count(1) count from applsys.wf_deferred y where state=2 group by to_char(deq_time,'DD-MON-YYYY HH24')) b 
where a.etime=b.dtime 
order by 1;
exit;
