set lines 200 pages 100 verify off
prompt
prompt Notifications in Open Status
prompt
select /*+parallel(a,4)*/MAIL_STATUS,count(*) from apps.wf_notifications a where status='OPEN' and MAIL_STATUS='MAIL' group by mail_status order by 2 desc;
prompt
prompt Message Types with Open Status and Mail_Status as Mail(Pending to send mail)
prompt
select /*+parallel(a,4)*/MESSAGE_TYPE,count(*) from apps.wf_notifications a where status='OPEN' and mail_status='MAIL' group by MESSAGE_TYPE order by 2 desc;
exit;
