set feed off verify off
SELECT to_number(substr(to_char(rawtohex(p2raw)), 1, 8), 'XXXXXXXX') blocking_sid,sid waiting_sid
FROM v$session
WHERE event = 'cursor: pin S wait on X';
exit;
