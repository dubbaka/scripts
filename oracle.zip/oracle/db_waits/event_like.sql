column event format a40
set pagesize 80

select b.event,count(*),avg(b.wait_time)
from v$session a,v$session_wait b
where a.sid = b.sid
and a.type != 'BACKGROUND'
and b.wait_time=0
group by b.event 
order by 2;

set linesize 300 verify off
set pagesize 1000
col username for a12
col osuser for a12
col machine format a20
col p1text format a15
col p2text format a15
col program format a25
col event format a30
set head on
select 
       w.sid, 
       w.serial#,
       x.p1,
       x.p1text, 
       x.p2, 
       x.p2text,
       nvl(w.program, nvl(p.program, '<unknown program>')) program, 
       w.username,
       w.osuser,
       w.machine, 
       x.event,
       w.sql_hash_value 
from v$session w, v$session_wait x,
     v$process p
where w.sid = x.sid
and p.background is null
and w.paddr = p.addr (+)
and x.event like '%&pl_enter_the_event_name%'
order by machine;
exit;
