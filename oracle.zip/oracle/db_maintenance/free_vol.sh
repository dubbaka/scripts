#!/bin/ksh
if [ $# -lt 1 ];then
   echo " "
   echo "Usage: $0 <SID> "
   echo " "
   exit 1
fi

ORACLE_SID=$1;export ORACLE_SID
ORAENV_ASK=NO;export ORACLE_ASK
. /usr/local/bin/oraenv
CONFIG="/oraclesw/Monitoring/Standard/script/config/Add_Space_${ORACLE_SID}.Config"

instance=`ps -ef|grep smon|grep ${ORACLE_SID}|wc -l`

if (( $instance==0 )); then
   echo "`hostname`:${ORACLE_SID} is Unavailable"
#   mailx -s "`hostname`:${ORACLE_SID} is Unavailable" yowu < /dev/null
   exit;
fi

cnt1=`(sqlplus -s /<<EOF
set echo off verify off head off feed off pages0;
select count(name) from v\\$dbfile where name like '%.dbf%';
exit
EOF
)`
echo $cnt1
if (( $cnt1 > 0 )); then
   echo "============================================================================"
   echo "   ${ORACLE_SID} is a file system based database."
   echo "   This program is to get free volumes on raw/block volume based database."
   echo "============================================================================"
   exit;
fi

WDir=/oraclesw/Monitoring/Standard
logDir=${WDir}/log
mkdir -p ${WDir}/log
find ${logDir}/ -name "*.*" -mtime +1 -exec rm -f {} \;

volumeFiles=${logDir}/${ORACLE_SID}_volumeFiles_$$.txt
volumeList=${logDir}/${ORACLE_SID}_volumeList_$$.list
dbFiles=${logDir}/${ORACLE_SID}_dbFiles_$$.txt
dbFileList=${logDir}/${ORACLE_SID}_dbFileList_$$.list
freeVolumes=${logDir}/${ORACLE_SID}_freeVolumes_$$.list
sqlFile=${logDir}/${ORACLE_SID}_updateFreeVolumes_$$.sql
sqlLog=${logDir}/${ORACLE_SID}_updateFreeVolumes_$$.log
sqlQuery=${logDir}/${ORACLE_SID}_query_$$.sql
len=`echo "${ORACLE_SID}" | wc -c`
len=`expr $len - 2`

echo "
select /*+ rule */ 'ls '||substr(name,1,instr(name,'-',-1))||'*'
from v\$datafile
where name like '%-%'
and name not like '%10-%'
and name not like '%20-%'
and name not like '%25-%'
and name not like '%50-%'
and name not like '%50m-%'
and name not like '%100-%'
and name not like '%100m-%'
and name not like '%200m-%'
and name not like '%250-%'
union
select /*+ rule */ 'ls '||substr(name,1,instr(name,'-',-1))||'*'
from v\$tempfile
where name like '%-%'
union
select /*+ rule */ 'ls '||substr(name,1,instr(name,'_',-1))||'*'
from v\$datafile
where name like '%\_%' escape '\'
and name not like '%64_%'
and name not like '%100_%'
and name not like '%500_%'
and name not like '%512_%'
union
select /*+ rule */ 'ls '||substr(name,1,instr(name,'_',-1))||'*'
from v\$tempfile
where name like '%\_%' escape '\'
/" > ${sqlQuery}

if [ "${ORACLE_SID}" = "ODSDEV" -o "${ORACLE_SID}" = "ODSTEST" ]; then
   echo "
select 'ls '||name||'|grep -v log|grep -v 50-|sort'
from (
select distinct substr(name,1,instr(name,'${ORACLE_SID}')+$len)||'*/'||pat||'*' name from (
select distinct substr(name,0,instr(name,'/',-1)-1) name,
substr(name,instr(name,'/',-1)+1,2) pat from v\$dbfile
))
/" > ${sqlQuery}
fi

if [ "${ORACLE_SID}" = "SCEPROD" -o "${ORACLE_SID}" = "SCEDEV" -o "${ORACLE_SID}" = "SCETEST" -o "${ORACLE_SID}" = "SCEQA" -o "${ORACLE_SID}" = "KPRD" -o "${ORACLE_SID}" = "EDWPROD" -o "${ORACLE_SID}" = "EDWDEV" -o "${ORACLE_SID}" = "EDWTEST" -o "${ORACLE_SID}" = "WWCSPROD" -o "${ORACLE_SID}" = "WWCSDEV" -o "${ORACLE_SID}" = "ODSPROD" -o "${ORACLE_SID}" = "CTSPRD1" -o "${ORACLE_SID}" = "CTSPRD2" ]; then
   echo "
select 'ls '||name||'|grep -v log|grep -v tmp|grep -v 10-|grep -v 20-|grep -v 50-|
grep -v 100-|grep -v 500-|sort'
from (
select distinct rtrim(translate(name,'1234567890','*'),'*')||'*/'||pat||'*' name,pat
from (select distinct substr(name,0,instr(name,'/',-1)-1) name,
substr(name,instr(name,'/',-1)+1,2) pat from v\$dbfile
))
/" > ${sqlQuery}
fi

lowerSid=`echo ${ORACLE_SID}|tr "[A-Z]" "[a-z]"`

if [ "${ORACLE_SID}" = "B2BSPPRD" -o "${ORACLE_SID}" = "B2BSPDEV" -o  "${ORACLE_SID}" = "B2BSPSTG" ]; then
   echo "
select 'ls /dev/vg$lowerSid*/rlv$lowerSid*|grep -v 100_' from dual
/" > ${sqlQuery}
fi

HOST_NAME=`/bin/uname`
FNAME=`(sqlplus -s /<<EOF
set echo off verify off head off feed off pages0;
select name from v\\$datafile where creation_time = ( select max(creation_time) from v\\$datafile ) and rownum < 2;
exit
EOF
)`
DTYPE=`ls -al $FNAME | awk '{print $1}' | cut -c1,1`

if [ "$DTYPE " = "b " ]; then
   echo "
select 'ls /dev/mapper/ora'||name||'*p* |grep -v log ' from v\$database
/" > ${sqlQuery}
fi
if [ -f $CONFIG ] && [ `grep -c "^FILE_PATTERN" $CONFIG` -gt 0 ]
then
LOOK_FOR=`cat $CONFIG | grep -v "#" | grep FILE_PATTERN | awk -F"=" '{print $2}'`
echo "
select 'ls /dev/mapper/ora${LOOK_FOR}*p*|grep -v log ' from v\$database
/" > ${sqlQuery}
fi
$ORACLE_HOME/bin/sqlplus -s / <<EOF > ${volumeList}
set term off
set pages 0
set feed off
set trimspool on
set linesize 225
spool ${volumeList}
@${sqlQuery}
spool off
EOF

$ORACLE_HOME/bin/sqlplus -s / <<EOF  > /dev/null
set term off
set pages 0
set feed off
set trimspool on
column name format a120
spool ${dbFileList}
select /*+ rule */ name from v\$datafile 
union
select /*+ rule */ name from v\$tempfile
union
select /*+ rule */ member from v\$logfile
/
spool off
EOF

chmod +x ${volumeList}

FSNO=`grep "_" ${volumeList}|wc -l`
if [ $FSNO -gt 0 ]; then
   ${volumeList}|sort -u|awk -F/ '{print $NF" " $0}'|awk -F_ '{print $1 " " $2 " " $3 " " $0}'|sort -k 1,1 -k 2,2n|awk '{print $6}' > ${volumeFiles}
else
  if [ "${ORACLE_SID}" = "BVESRDEV" -o "${ORACLE_SID}" = "MCODEV" -o "${ORACLE_SID}" = "EPUBSTG" -o "${ORACLE_SID}" = "EPUBDEV" -o "${ORACLE_SID}" = "EHUBSPSG" -o "${ORACLE_SID}" = "EHUBSPDV" -o "${ORACLE_SID}" = "B2BSPPRD" -o "${ORACLE_SID}" = "B2BSPSTG" -o "${ORACLE_SID}" = "B2BSPDEV" -o "${ORACLE_SID}" = "EHUBPROD" -o "${ORACLE_SID}" = "EHUBPROV" -o "${ORACLE_SID}" = "MCOPROD" -o "${ORACLE_SID}" = "EENGPRD" -o "${ORACLE_SID}" = "EENGDEV" -o  "${ORACLE_SID}" = "EENGSTG" -o $HOST_NAME = "Linux" ]; then
     ${volumeList}|sort -u|awk -F/ '{print $NF" " $0}'|awk -F- '{print $1 " " $2 " " $0}'|sort -k 1,1 -k 2,2n|awk '{print $4}'|grep -v _v20_|grep -v _v64_|grep -v _v512_|grep -v arch0 > ${volumeFiles}
  else
     ${volumeList}|sort -u|awk -F/ '{print $NF" " $0}'|awk -F- '{print $1 " " $2 " " $0}'|sort -k 1,1 -k 2,2n|awk '{print $5}' > ${volumeFiles}
  fi
fi

sort -u ${dbFileList} > ${dbFiles}

echo "$ORACLE_SID FREE Volumes are : " >> ${freeVolumes}
echo "===============================" >> ${freeVolumes}
echo "============================================================="
echo "$ORACLE_SID FREE Volumes are : "

echo "truncate table free_volumes;" > ${sqlFile}

for i in `cat ${volumeFiles}`
do
   CNT=`grep $i ${dbFiles} |wc -l`
   if [ $CNT -eq 0 ]
    then
      echo $i
      echo $i >> ${freeVolumes}
      echo "insert into free_volumes(sid,file_name) select instance_name,'$i' from v\$instance;" >> ${sqlFile}
   fi
done

touch ${sqlLog}

#$ORACLE_HOME/bin/sqlplus -s / @${sqlFile} <<EOF > ${sqlLog}
#EOF

err=`grep ORA-00942 ${sqlLog} |wc -l|awk '{print $1}'`

if [[ $err > 0 ]]; then 
$ORACLE_HOME/bin/sqlplus -s / <<EOF >> ${sqlLog}
create table free_volumes(sid varchar2(16),file_name varchar2(62),updated_date date default sysdate)
/
@${sqlFile}
EOF
fi 

# vim: syntax=sh:expandtab:shiftwidth=2:softtabstop=2:tabstop=2
