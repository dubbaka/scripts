select file#,block#,blocks,decode(corruption_change#,0,'PHYSICAL','LOGICAL') "Physical vs Logical",corruption_change#, corruption_type from v$database_block_corruption;
exit;
