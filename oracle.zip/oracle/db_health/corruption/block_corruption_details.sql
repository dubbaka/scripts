set verify off
SELECT /*+ RULE */ tablespace_name, segment_type, owner, segment_name , partition_name
  FROM dba_extents
 WHERE file_id = &file_id
   AND &block_id between block_id AND block_id + blocks - 1 ;
exit;
