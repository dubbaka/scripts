#!/bin/bash
#############################################################################################################
# Owner: Rajesh Gunda
# Script Name: env_verify.sh
# Version :1.0: Base Version
# Description: Perform Environment Validation. 
#############################################################################################################
#set -x
Set_Env()
{
wdir="/oraclesw/automation/refresh"
logdir="$wdir/logs"
export PATH=$PATH:.
tstmp=`date +%Y%m%d_%H%M%S`
HOSTNAME=$(hostname|cut -d. -f1)
logfile="$logdir/${ORACLE_SID}_${HOSTNAME}_Env_Verification_report_${tstmp}.log"
SCRIPTLOGS="$logdir/${ORACLE_SID}_${HOSTNAME}_EnvVerify_logs_${tstmp}.log"
db_log="$logdir/${ORACLE_SID}_${HOSTNAME}_db_checks_${tstmp}.log"
erp_log="$logdir/${ORACLE_SID}_${HOSTNAME}_erp_checks_${tstmp}.log"
os_log="$logdir/${ORACLE_SID}_${HOSTNAME}_os_checks_${tstmp}.log"
HTMLOUT="$logdir/${ORACLE_SID}_Env_Verification_Report_${tstmp}.html"
ServerScript="$wdir/os_checks.sh"
DBScript="$wdir/db_checks.sh"
ERPScript="$wdir/erp_checks.sh"
  if [ -f /usr/local/bin/dbenv ]
  then
    source /usr/local/bin/dbenv ${ORACLE_SID} 1>/dev/null 2>&1;	   
  else
    export PATH=$PATH:/usr/local/bin
    export ORACLE_SID=${ORACLE_SID}
    export ORAENV_ASK=NO
    source /usr/local/bin/oraenv 2>/dev/null
  fi
}

Chk_DB_Status()
{
 if [ $(ps -ef | grep -i ora_smon_${ORACLE_SID} | grep -v grep | wc -l) -eq 0 ]
 then
   dbstatus="DOWN"
 else
   dbstatus="UP"
 fi
}

###### To know if it is RAC or not ######
Get_Rac_Info()
{
CINFO=$(sqlplus -s "/ as sysdba" <<EOF 2>/dev/null
set echo off verify off head off feed off pages0 trimspool on;
select trim(count(1)) from v\$active_instances;
EOF
)
if [ $(echo $CINFO | grep -ic "ORA-") -eq 0 ]
then
  if [ "$CINFO" -eq 0 ] || [ "$CINFO " = " " ]
  then
    export RAC_STATUS=NO;
    hostlist=`hostname`
  else
    export RAC_STATUS=YES;
hostlist=$(sqlplus -s "/ as sysdba" <<EOF 2>/dev/null
set echo off verify off head off feed off pages0 trimspool on;        
select trim(INST_NAME) from v\$active_instances; 
EOF
)
  fi
else
  echo "[ERROR]: Sql querying db for rac status failed" >> $logfile
fi
}

### ERP Verification ###
Chk_ERP()
{
ERP=$(sqlplus -s "/ as sysdba" <<EOF
set echo off verify off head off feed off pages0;
select 'YES' from applsys.fnd_product_groups where APPLICATIONS_SYSTEM_NAME=(select name from v\$database);
EOF
)

if [ $(echo $ERP | grep -ic "ORA-") -eq 0 ]
then
  if [ "$ERP" = "YES" ]
  then
     ${ERPScript} ${ORACLE_SID} ${apps_passwd} ${weblogic_passwd} 1>${erp_log} 2>&1 &
     ERP_PID=$!
  else
     echo "This is not a ERP Environment" >> $logfile
  fi
else
   echo "[ERROR]: Sql query failed to get ERP status" >> $logfile
fi
}


HTML_CODE()
{
echo  "<!DOCTYPE html>
<html>
<style>
body {font-family: \"Lato\", sans-serif;}

ul.tab {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #3b5998;
}

/* Float the list items side by side */
ul.tab li {float: left;}

/* Style the links inside the list items */
ul.tab li a {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of links on hover */
ul.tab li a:hover {
    background-color: #ddd;
}

/* Create an active/current tablink class */
ul.tab li a:focus, .active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}

.data ul li header{
	font-weight:bold;
	padding-top: 10px;
}

table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
    background-color: #eee;
}
th, td {
    padding: 5px;
    text-align: left;
    font-size: 14px;
    font-weight: normal;
}

th#t_header {
    padding: 5px;
    text-align: center;
    background-color: #8b9dc3;
    font-size: 16px;
    font-weight: bold;
}

th#sub_header {
    padding: 5px;
    text-align: center;
    background-color: #f7f7f7;
    font-size: 15px;
    font-weight: bold;
}

}
</style>
<body>

<h2 align=center>${ORACLE_SID} Environment Validation Report</h2>
" >> $HTMLOUT
}

if [ "X$NOTIFY" != "X" ]
then
sendmail()
{
(echo "Subject:${ORACLE_SID} - Environment Verification Report"
echo "To: $NOTIFY"
echo "MIME-Version: 1.0"
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
cat $HTMLOUT
) | /usr/lib/sendmail -t -v > /dev/null
}
fi

##### MAIN ######
script_name=$0
(( $# != 3 )) && { echo "Usage: $script_name <ORACLE_SID> <apps password> <weblogic password> <email_id>"; exit 1; }
ORACLE_SID=$1
apps_passwd=$2
weblogic_passwd=$3
NOTIFY=$4

if [ $( grep -ic ${ORACLE_SID} /etc/oratab ) -eq 0 ]
then
  echo "[CRITICAL]:${ORACLE_SID} is not found in /etc/oratab file"
  exit 1;
fi

Set_Env

Chk_DB_Status

Get_Rac_Info;

HTML_CODE;

let i=1;

for line in $(echo "$hostlist")
do
  hname=`echo $line | awk -F":" '{print $1}'`
  rsid=`echo $line | awk -F":" '{print $2}'`	
  if [ "$hname" != "$HOSTNAME" ]; then
      ssh -4nq $hname "$ServerScript" >$logdir/SS_${rsid}.log
      if [ -f "$logdir/SS_${rsid}.log" ]
      then
	cat $logdir/SS_${rsid}.log | grep "envverify" >> $SCRIPTLOGS 2>/dev/null;
      fi
      i=`expr $i + 1`
  else
      $ServerScript 1>${os_log} 2>&1
      if [ -f "${os_log}" ]
      then
	cat ${os_log} | grep "envverify" >> $SCRIPTLOGS 2>/dev/null;
      fi
      i=`expr $i + 1`
  fi
done

$DBScript ${ORACLE_SID} $TNAME 1>${db_log} 2>&1 &
DB_PID=$!

Chk_ERP;

proc=$(echo "$ServerScript|$DBScript|$ERPScript")

i=5
while true
do
  sleep 5;
  if [ `ps -ef | egrep "$ServerScript|$DBScript|$ERPScript" | grep -v grep | wc -l` -eq 0 ]
  then      
    break;
  else 
	i=`expr $i + 5`
	if [ $i -ge 180 ]
	then
	  break;
	fi
  fi
done

if [ -f "${db_log}" ]
then
  cat ${db_log} | grep "envverify" >> $SCRIPTLOGS 2>/dev/null;
fi

if [ -s "${erp_log}" ]
then
  cat ${erp_log} | grep "envverify" >> $SCRIPTLOGS 2>/dev/null;
fi

echo "<table style=width:100% border=1>
<tr>  
<th id=\"t_header\"> List of Checks </th>
<th id=\"t_header\"> Details </th>
</tr>" >> $HTMLOUT

cat $SCRIPTLOGS | grep status | while read line
do
   ctype=$( echo $line | awk -F":" '{print $1}' )
   clog=$( echo $line | awk -F":" '{print $2}' )
     if [[ "$ctype" =~ "database" ]]
     then
        echo "<tr><th id=\"sub_header\" colspan="2">Database Checks</th></tr>" >> $HTMLOUT
        cat $clog | while read logdata
        do 
           cname=$( echo $logdata | awk -F":" '{print $1}' )
           cvalue=$( echo $logdata | awk -F":" '{print $2}' )
           echo "<tr><td>$cname</td> <td>$cvalue</td> </tr>" >> $HTMLOUT
        done
     elif [[ "$ctype" =~ "server" ]]
     then
        echo "<tr><th id=\"sub_header\" colspan=\"2\">OS level checks</th></tr>" >> $HTMLOUT
        cat $clog | grep -v "^$" | while read logdata
        do 
           cname=$( echo $logdata | awk -F":" '{print $1}' )
           cvalue=$( echo $logdata | awk -F":" '{print $2}' )
           echo "<tr><td>$cname</td> <td>$cvalue</td> </tr>" >> $HTMLOUT
        done
     elif [[ "$ctype" =~ "erp" ]]
     then
        echo "<tr><th id=\"sub_header\" colspan="2">Application checks</th></tr>" >> $HTMLOUT
        cat $clog | while read logdata
        do 
           cname=$( echo $logdata | awk -F":" '{print $1}' )
           cvalue=$( echo $logdata | awk -F":" '{print $2}' )
           echo "<tr><td>$cname</td> <td>$cvalue</td> </tr>" >> $HTMLOUT
        done
     fi
done
echo "</table>" >> $HTMLOUT

echo "</body></html>" >> $HTMLOUT
cat $SCRIPTLOGS
echo "Html_Output=${HTMLOUT}"

sendmail

# vim: syntax=sh:expandtab:shiftwidth=2:softtabstop=2:tabstop=2
