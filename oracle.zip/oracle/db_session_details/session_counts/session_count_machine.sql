set pages 100 lines 100 verify off
accept machine char prompt 'Enter Machine : '
select inst_id,machine, status, count(*)
  from gv$session
 where machine = decode ('&machine',null,machine,'&machine')
 group by inst_id,machine, status
 order by 1,2,3;
exit;
