set pages 100
set lines 150
set feedback off
set verify off
col os_pid for 9999999
col sid for 9999999
col os_username for a15
col oracle_username for a25
col statistics_type for a30
col value for 99999999999
col status for a10
col running_in_hrs for 9999999999.99
--select * from v$statname;
accept sid char prompt 'Enter SID [blank for all sessions] :'
accept name char prompt 'Enter Statistics Type [read/write/cpu/blank for all statistics] :'
break on unix_pid on oracle_sid on os_username on oracle_username on status on running_in_hrs skip 1 on unix_pid
select p.spid unix_pid, s.sid oracle_sid , ss.osuser os_username, ss.username oracle_username, 
       ss.status , round(ss.last_call_et/3600,2) running_in_hrs,
       n.name statistics_type, s.value
  from v$statname n ,  v$sesstat s , v$session ss, v$process p
 where s.sid = decode('&sid', null,s.sid,'&sid') 
   and n.name = decode('&name','read','physical reads','write','physical writes','cpu','CPU used by this session',null,n.name,'&name')
   and n.statistic# = s.statistic# 
   and p.addr = ss.paddr
   and s.sid = ss.sid
   and s.value > 10000
 order by s.value desc
;

/*
-- Collect statistics at instance level
select  n.name, s.value 
  from v$statname n ,  v$sysstat s 
 where n.statistic# = s.statistic# 
 order by n.class, n.name 
; 
*/
set feedback on
set verify on
exit;
