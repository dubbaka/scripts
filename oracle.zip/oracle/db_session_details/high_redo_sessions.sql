set lines 200
set pages 100
set verify off
col username format a20
col program format a30
col module format a30
select s.sid,s.serial#,s.module,s.username,s.program,to_char(s.logon_time,'DD-MON-YY HH24:MI:SS') "Logon Time",round(a.value/1024/1024,2)||' M' "Redo in MB"
from v$session s, v$sesstat a, v$statname b
where a.statistic# = b.statistic#
and name='redo size'
and s.sid = a.sid
and round(a.value/1024/1024,2)>nvl('&redo_size_in_MB',0)
order by a.value desc
;
exit;
