set verify off lines 300 pages 300

col name format a30
SELECT V.sid, 
 P.SPID     "OS_PID", 
       P.USERNAME "OS_USERNAME", 
       U.USERNAME "USERNAME", 
       P.PROGRAM  "PROGRAM", 
       B.NAME, 
       round(V.VALUE/1024/1024,2) "Value in MB"
FROM V$SESSTAT V, V$STATNAME B, V$SESSION U, V$PROCESS P 
WHERE V.STATISTIC# = B.STATISTIC# 
AND   (B.NAME LIKE '%pga%' OR B.NAME LIKE '%uga%') 
and v.sid = u.sid
and p.addr = u.paddr
AND    UPPER(v.sid)         LIKE UPPER(NVL('&sid________', v.sid))
AND    UPPER(p.spid)        LIKE UPPER(NVL('&spid_______', p.spid))
order by v.sid
;
exit;
