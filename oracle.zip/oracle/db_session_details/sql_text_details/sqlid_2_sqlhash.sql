set pagesize 4
set verify off
select distinct hash_value
from v$sqlarea
where
sql_id=nvl('&sql_id',0);
exit;
