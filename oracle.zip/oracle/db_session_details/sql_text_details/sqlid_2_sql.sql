set pagesize 4000
set long 4000 verify off
select sql_text
from v$sqltext
where
sql_id=nvl('&sql_id',0)
order by piece;
exit;
