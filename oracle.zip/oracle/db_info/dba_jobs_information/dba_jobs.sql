set linesize 200
set pagesize 100 feed off verify off

accept brokenstatus char prompt 'Enter Broken Status(Y/N)[Default - ALL] : '
accept what char prompt 'Enter What details[Default - ALL] : '

col priv_user format a15
COL interval format a30
col What format a31

SELECT job, 
       broken,
       priv_user, 
       last_date,
       last_sec,
       next_date, 
       next_sec, 
       interval,
       failures,
       substr(what,1,30) "What"
FROM dba_jobs
WHERE 1=1 
and broken like upper('%&brokenstatus%')
and what like upper('%&what%')
;
accept job_number char prompt 'Enter Job Number For More Details[Default - 9999] : '
SELECT 
       'Job ID              :  ' ||job||chr(10)||
       'Broken Status       :  ' ||broken||chr(10)||
       'Priv User           :  ' ||priv_user||chr(10)||
       'Last Run Date       :  ' ||last_date||chr(10)||
       'Last Run Time       :  ' ||last_sec||chr(10)||
       'Next Run Date       :  ' ||next_date||chr(10)||
       'Next Run Time       :  ' ||next_sec||chr(10)||
       'Scheduled Interval  :  ' ||interval||chr(10)||
       'Failure Count       :  ' ||failures||chr(10)||
       'Details             :  ' || chr(10) || what||chr(10) "Job Details"
FROM dba_jobs
WHERE 1=1
and job=nvl('&job_number',9999)
;
exit;
