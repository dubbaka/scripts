set feedback off
set verify off
set pages 100
set lines 132
col name format a60
col tablespace_name for a20
col data_file_name for a60
accept no_days number prompt 'Enter No of days since the data files added :'
accept tablespace_name char prompt 'Enter Tablespace Name :'
ttitle center 'List of datafiles added  within last &no_days Days' skip 1 center '****************************************************************' skip 2
break on report
compute sum of size_in_mb on report
select /*+rule*/ b.name tablespace_name, a.name data_file_name, a.bytes/(1024*1024) size_in_MB, 
       to_char(a.creation_time,'MM/DD/YYYY HH24:MI:SS') add_time
  from v$datafile a, sys.ts$ b
where a.ts#=b.ts#
 and creation_time > sysdate - &no_days
 and b.name = decode('&tablespace_name',null, b.name,'&tablespace_name')
;

select /*+rule*/ b.name tablespace_name, sum(a.bytes/(1024*1024)) size_in_MB
  from v$datafile a, sys.ts$ b
where a.ts#=b.ts#
 and creation_time > sysdate - &no_days
 and b.name = decode('&tablespace_name',null, b.name,'&tablespace_name')
group by b.name
;

select /*+rule*/ b.name tablespace_name, trunc(creation_time) create_date, sum(a.bytes/(1024*1024)) size_in_MB
  from v$datafile a, sys.ts$ b
where a.ts#=b.ts#
 and creation_time > sysdate - &no_days
 and b.name = decode('&tablespace_name',null, b.name,'&tablespace_name')
group by b.name,  trunc(creation_time)
;
set feedback on
set verify on
exit;
