set lines 200 pages 100 verify off 
col FIRST_CHANGE# format 9999999999999999999
col member format a60
select a.thread#,a.act_cnt "Active Redos",b.tot_cnt "Total Redos" from
(select thread#,count(*) act_cnt from v$log where status='ACTIVE' group by thread#) a,
(select thread#,count(*) tot_cnt from v$log group by thread#) b
where a.thread#=b.thread#
order by thread#;
accept thread char prompt 'Enter thread#(instance number)(Default - All) :'
accept group char prompt 'Enter group#(Default - All) :'
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
select * from v$log where 
thread#=nvl('&thread',thread#)
and group#=nvl('&group',group#)
order by thread#,group#;
prompt
accept grp char prompt 'Enter Group# to get file info(Default - All):'
prompt
select * from v$logfile where group#=nvl('&grp',group#) order by group#;
exit;
