set lines 200 pages 10 verify off

PROMPT
PROMPT Temp Tablespace Details
PROMPT
select a.tablespace,b.tot "Total in GB",a.used "Used in GB"
from
(select tablespace,round(sum((blocks*8)/1024/1024),0) used from gv$sort_usage group by tablespace) a,
(select tablespace_name,round(sum(bytes/1024/1024/1024),0) tot from dba_temp_files group by tablespace_name) b
where a.tablespace=b.tablespace_name
order by 2 desc;
exit;
