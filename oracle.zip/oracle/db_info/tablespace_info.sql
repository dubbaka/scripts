CLEAR  COL BREAK COMPUTE
SET    PAGESIZE 500 VERIFY OFF PAUSE OFF FEEDBACK OFF LINES 200
COLUMN tablespace_name   FORMAT A20
COLUMN in_M              FORMAT 9999
COLUMN nx_M              FORMAT 9999
COLUMN pct               FORMAT 99       HEADING %I
COLUMN status            FORMAT A5       HEADING STATE      TRUNC
COLUMN contents          FORMAT A9
COLUMN logging           FORMAT A7                          TRUNC
COLUMN extent_management FORMAT A5       HEADING MANGMT     TRUNC
COLUMN allocation_type   FORMAT A7       HEADING ALLOCATION TRUNC
compute sum of TOTAL_SPACE_IN_MB FREE_SPACE_IN_MB chunk on report
break on report
accept tablespace_name char prompt 'Enter Tablespace Name [Just press Enter for all tablespaces]:'
select a.TABLESPACE_NAME,c.initial_extent/1024/1024 in_M ,c.next_extent/1024/1024    nx_M ,c.pct_increase pct,
       c.status, c.contents, c.logging, c.extent_management, c.allocation_type,
       round(a.bytes_used/(1024*1024),2) TOTAL_SPACE_IN_MB,
       round(b.bytes_free/(1024*1024),2) FREE_SPACE_IN_MB,
       round(b.largest/(1024*1024),2) max_chunk_in_MB,
       round(((a.bytes_used-b.bytes_free)/a.bytes_used)*100,2) percent_used
  from
  (
  select TABLESPACE_NAME, sum(bytes) bytes_used
    from dba_data_files
   group by TABLESPACE_NAME
  ) a,
  (
  select TABLESPACE_NAME, sum(BYTES) bytes_free, max(BYTES) largest
    from dba_free_space
   group by TABLESPACE_NAME
  ) b,
 dba_tablespaces c
 where a.TABLESPACE_NAME=b.TABLESPACE_NAME(+)
   and a.tablespace_name=c.tablespace_name
   and a.tablespace_name = decode('&tablespace_name',null,a.tablespace_name,'&tablespace_name')
 order by ((a.BYTES_used-b.BYTES_free)/a.BYTES_used) desc;

SET   VERIFY OFF FEEDBACK ON ECHO OFF PAGES 32 PAUSE OFF
exit;
