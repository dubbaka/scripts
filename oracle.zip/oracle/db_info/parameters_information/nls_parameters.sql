set pages 100
set lines 132
col parameter for a30
col value for a30
Rem ' Database Level NLS Parameters.......'
select * from nls_database_parameters;
prompt
prompt
Prompt ' Database Level NLS Parameters.......'
select * from nls_instance_parameters;
exit;
