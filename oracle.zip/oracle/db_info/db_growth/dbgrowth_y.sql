set lines 100 pages 100
select to_char(creation_time,'YYYY') "Year", round(sum(bytes)/1024/1024/1024,0) "Growth in GB"
from v$datafile
group by to_char(creation_time,'YYYY');
order by 1
exit;
