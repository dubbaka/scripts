set feed off echo off head off
prompt
prompt you might see ORA-00942 during this script run. Please ignore
prompt
drop table sidegeek_temp_dbf;
create table sidegeek_temp_dbf as select to_char(creation_time,'MON-YY') "MONYY",round(sum(bytes)/1024/1024/1024,0) "GRTHINGB" from v$datafile group by to_char(creation_time,'MON-YY');
update sidegeek_temp_dbf set MONYY=replace(MONYY,'JAN','Q2') where substr(MONYY,1,3)='JAN';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'FEB','Q3') where substr(MONYY,1,3)='FEB';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'MAR','Q3') where substr(MONYY,1,3)='MAR';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'APR','Q3') where substr(MONYY,1,3)='APR';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'MAY','Q4') where substr(MONYY,1,3)='MAY';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'JUN','Q4') where substr(MONYY,1,3)='JUN';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'JUL','Q4') where substr(MONYY,1,3)='JUL';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'AUG','Q1') where substr(MONYY,1,3)='AUG';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'SEP','Q1') where substr(MONYY,1,3)='SEP';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'OCT','Q1') where substr(MONYY,1,3)='OCT';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'NOV','Q2') where substr(MONYY,1,3)='NOV';
update sidegeek_temp_dbf set MONYY=replace(MONYY,'DEC','Q2') where substr(MONYY,1,3)='DEC';
commit;
set head on
select monyy "Quarter-Year",sum(GRTHINGB) "Growth in GB" from sidegeek_temp_dbf group by monyy order by 1;
drop table sidegeek_temp_dbf;
exit;
