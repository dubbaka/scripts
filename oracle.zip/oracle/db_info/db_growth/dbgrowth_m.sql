set lines 100 pages 100
select substr(creation_time, 4,6) "MON-YY", round(sum(bytes)/1024/1024/1024,0) "Growth in GB"
from v$datafile
group by substr(creation_time, 4,6)
order by 1;
exit;
