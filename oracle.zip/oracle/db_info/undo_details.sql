set echo on
set pages 100 lines 200

Prompt
Prompt Undo Generated per second
Prompt #########################
Prompt
select round((a.blks*b.value)/1024,0) "in KB"
from
(select(sum(undoblks))/sum((end_time-begin_time)*86400) blks from v$undostat) a,
(select value from v$parameter where name='db_block_size') b
;
/********************************************************************************************
-- Displays the UNDO statistics which includes the number of ORA-1555s, the longest query time, 
-- and (Un)Expired Steals (SC).  The "steal" values are the number of requests for steals, not
-- the actual number of blocks stolen (not reported in this query). 
-- When the UNExp SC is > 0, that indicates a UNDO space issue.
********************************************************************************************/
Prompt
Prompt Last 10 entries from Undostat
Prompt #############################
Prompt
select to_char(begin_time, 'mm/dd/yyyy hh24:mi') "Int. Start",
       ssolderrcnt "ORA-1555s", maxquerylen "Max Query",
       unxpstealcnt "UNExp SC", expstealcnt "Exp SC",
       NOSPACEERRCNT nospace
  from v$undostat where rownum<11
 order by begin_time asc 
;

Prompt
Prompt Undo Tablespace Details
Prompt #######################
Prompt 
col Undo_Retention format a10
select a.tablespace_name,a.tot "Total Size in GB",b.active "Active in GB",d.unexpired "Unexpired in GB",c.expired "Expired in GB",e.free "Free in GB",f.undo_ret Undo_Retention
from
(select tablespace_name, round(sum(bytes)/(1024*1024*1024),2) tot
  from dba_data_files where tablespace_name in (select value from gv$parameter where name='undo_tablespace')
 group by tablespace_name) a,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) active from dba_undo_extents where status='ACTIVE' group by tablespace_name) b,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) expired from dba_undo_extents where status='EXPIRED' group by tablespace_name) c,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) unexpired from dba_undo_extents where status='UNEXPIRED' group by tablespace_name) d,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) free
  from dba_free_space where tablespace_name in (select value from gv$parameter where name='undo_tablespace')
 group by tablespace_name) e,
(select y.value tablespace_name,x.value undo_ret from
(select inst_id,value from gv$parameter where name='undo_retention') x,
(select inst_id,value from gv$parameter where name='undo_tablespace') y
where x.inst_id=y.inst_id) f
where a.tablespace_name=b.tablespace_name(+)
and a.tablespace_name=c.tablespace_name(+)
and a.tablespace_name=d.tablespace_name(+)
and a.tablespace_name=e.tablespace_name(+)
and a.tablespace_name=f.tablespace_name(+)
;
exit;
