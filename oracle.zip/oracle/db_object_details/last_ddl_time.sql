set pagesize 100 lines 200 verify off
col object_name format a34
column owner format a15
select owner, object_name, object_type, to_char(last_ddl_time, 'DD-MON-RR HH24:MI:SS') lastddl,to_char(created, 'DD-MON-RR HH24:MI:SS') created
from dba_objects
where    last_ddl_time > sysdate-nvl('&days',1)
order by last_ddl_time
;
exit;
