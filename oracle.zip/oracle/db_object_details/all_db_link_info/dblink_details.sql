set verify off
set pages 1200
set lines 132
column owner format a20
column db_link format a30
column username format a30
column host format a20
accept link_name char Prompt 'Enter Database Link Name : '
select owner, db_link, username, host , to_char(created,'MM/DD/YYYY HH24:MI:SS') creation_date
  from dba_db_links 
 where upper(db_link) like '%'||upper('&&link_name')||'%'
 order by owner
;
exit;
