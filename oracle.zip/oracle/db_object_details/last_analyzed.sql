column owner format a15
set linesize 200 verify off pages 5000
accept hours char prompt 'Analyzed during last how many hours(Default - 1 Hr) :'

PROMPT  TABLES ANALYZED

select owner, table_name,  to_char(last_analyzed, 'DD-MON-YYYY HH24:MI:SS'), num_rows, sample_size
from dba_tables 
where 1 = 1
AND  last_analyzed>sysdate-(nvl('&hours',1))/24
order by 3 desc;

PROMPT  INDEXES ANALYZED

select owner, table_name, index_name, to_char(last_analyzed, 'DD-MON-YYYY HH24:MI:SS'), num_rows, sample_size
from dba_indexes
where 1 = 1
AND  last_analyzed>sysdate-(nvl('&hours',1))/24
order by 4 desc;

PROMPT  TABLE PARTITIONS ANALYZED

select 	table_owner, 
	table_name, 
	partition_name, 
	to_char(last_analyzed, 'DD-MON-YYYY HH24:MI:SS')
from 	dba_tab_partitions
where 	1 = 1 
AND  last_analyzed>sysdate-(nvl('&hours',1))/24
order by last_analyzed desc
;

PROMPT  INDEX PARTITIONS ANALYZED
select 	index_owner, 
	index_name, 
	partition_name, 
	to_char(last_analyzed, 'DD-MON-YYYY HH24:MI:SS')
from 	dba_ind_partitions
where 	1 = 1 
AND  last_analyzed>sysdate-(nvl('&hours',1))/24
order by last_analyzed desc;

PROMPT
exit;
