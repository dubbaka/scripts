set lines 200 verify off
col username format a15
SELECT u.name username, o.name table_name,o.subname partition_name, 
decode(o.type#, 2, 'TABLE', 19, 'TABLE PARTITION', 34, 'TABLE SUBPARTITION', 'UNDEFINED' ) object_type,
rowcnt num_rows, samplesize, case when rowcnt > 0 then round((samplesize/rowcnt)*100,2) else null end sample_pct, 
blkcnt blocks, avgrln avg_row_len, to_char(analyzetime,'DD-MON-YY HH24:MI:SS') last_analyzed, 
to_char(savtime,'DD-MON-YY HH24:MI:SS') stats_saved
FROM sys.user$ u, sys.obj$ o, sys.wri$_optstat_tab_history h
where  h.obj# = o.obj# and o.owner# = u.user# 
and u.name = '&owner' and o.name = '&table_name'  -- Change this to suit your condition
order by o.name, analyzetime;
exit;
