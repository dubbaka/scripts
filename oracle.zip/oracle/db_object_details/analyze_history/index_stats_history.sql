set lines 200
col username format a15
SELECT u.name username, o.name index_name, 
decode(o.type#, 1, 'INDEX', 20, 'INDEX PARTITION', 35, 'INDEX SUBPARTITION', 'UNDEFINED' ) object_type,
rowcnt num_rows, samplesize, case when rowcnt > 0 then round((samplesize/rowcnt)*100,2) else null end sample_pct, blevel, leafcnt leaf_blocks, distkey distinct_keys, lblkkey avg_leaf_blocks_per_key, dblkkey avg_data_blocks_per_key,clufac clustering_factor, to_char(analyzetime,'DD-MON-YY HH24:MI:SS') last_analyzed, to_char(savtime,'DD-MON-YY HH24:MI:SS') stats_saved
FROM sys.user$ u, sys.obj$ o, sys.wri$_optstat_ind_history h
where  h.obj# = o.obj# and o.owner# = u.user# 
and u.name = '&owner' and o.name = '&index_name' 
order by o.name, analyzetime;
exit;
