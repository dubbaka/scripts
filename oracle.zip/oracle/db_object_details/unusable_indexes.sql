column owner format a15
set linesize 200 verify off pages 100
accept hours char prompt 'Unusable indexes during last how many hours(Default - 1 Hr) :'

PROMPT
PROMPT  UNUSABLE INDEXES
PROMPT

select 
	a.owner,
	a.index_name,
	a.table_owner,
	a.table_name,
	a.status,
	to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time" 
from 
	dba_indexes a,
	dba_objects b
where 
	a.status='UNUSABLE'
	and a.owner=b.owner
	and a.index_name=b.object_name
	and b.object_type='INDEX'
	and b.last_ddl_time>sysdate-(nvl('&hours',1))/24
order by b.last_ddl_time;

PROMPT
PROMPT  UNUSABLE INDEX PARTITIONS
PROMPT

select 
	a.index_owner,
	a.index_name,
	a.partition_name,
	a.status,
	to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time" 
from 
	dba_ind_partitions a,
	dba_objects b
where 
	a.status='UNUSABLE'
	and a.index_owner=b.owner
	and a.index_name=b.object_name
	and a.partition_name=b.SUBOBJECT_NAME
	and b.object_type='INDEX PARTITION'
	and b.last_ddl_time>sysdate-(nvl('&hours',1))/24
order by b.last_ddl_time;

PROMPT
PROMPT  FAILED DOMAIN INDEXES
PROMPT

select
        a.owner,
        a.index_name,
        a.table_owner,
        a.table_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time"
from
        dba_indexes a,
        dba_objects b
where
	a.DOMIDX_OPSTATUS='FAILED'
        and a.owner=b.owner
        and a.index_name=b.object_name
        and b.object_type='INDEX'
        and b.last_ddl_time>sysdate-(nvl('&hours',1))/24
order by b.last_ddl_time;

PROMPT
PROMPT  FAILED DOMAIN INDEX PARTITIONS
PROMPT

select
        a.index_owner,
        a.index_name,
        a.partition_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time"
from
        dba_ind_partitions a,
        dba_objects b
where
	a.DOMIDX_OPSTATUS='FAILED'
        and a.index_owner=b.owner
        and a.index_name=b.object_name
        and a.partition_name=b.SUBOBJECT_NAME
        and b.object_type='INDEX PARTITION'
        and b.last_ddl_time>sysdate-(nvl('&hours',1))/24
order by b.last_ddl_time;
exit;
