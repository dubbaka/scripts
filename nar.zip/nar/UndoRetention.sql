-- @UndoRetention.sql

clear columns computes breaks

set pause on pages 40

col "UndoRetention(Mins)" for 999999.99
col "UndoRetention(Hrs)" for 999999.99

accept trgtid number default 0 prompt 'maxqueryid <ALL>: '

select INST_ID, max(maxquerylen) MaxLen, (max(maxquerylen)+300)/60 "UndoRetention(Mins)", (max(maxquerylen)+300)/3600 "UndoRetention(Hrs)"
from   gv$undostat
group  by INST_ID;
