-- @ash_9i.sql


clear columns breaks computes

col SAMPLE_TIME for a22
COl sid FOR 99999
COl serial# FOR 9999999
COl username FOR a20
COl "SQLhash" FOR 9999999999
COl event FOR a15
col WAIT_CLASS for a15
col "Status" for a18
col SESSION_TYPE head "Session|Type" for a10
COL P1TEXT for a30
COL P2TEXT for a30
COL P3TEXT for a30
--COl p1 FOR 999999999999999999
--COl p2 FOR 99999999999999
--COl p3 FOR 99999999999999

set pages 50 lines 400

select w.inst_id, to_char(sysdate,'dd-mon-yy hh24:mi:ss AM') SAMPLE_TIME, s.sid, s.serial#, s.username, w.state "Status", b.Class WAIT_CLASS
, substr(decode(w.wait_time, 0,w.event, 'OnCPU'),1,15) event, w.SECONDS_IN_WAIT, s.sql_hash_value "SQLhash", s.type SESSION_TYPE, w.wait_time
, w.P1TEXT, w.P1, w.P2TEXT, w.P2, w.P3TEXT, w.P3, w.event "EventFull"
from gv$session s, gv$session_wait w, my_DB_class b
where w.sid=s.sid and s.status='ACTIVE' and s.type='USER' and b.NAME(+) = w.event;
