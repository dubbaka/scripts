-- @TbsFragmentation.sql

-- TFSTSFRM.SQL -- Script to Detect Tablespace Fragmentation Note:1020182.6 28-JAN-2003

SET ECHO on
REM NAME:TFSTSFRM.SQL
REM PURPOSE: 
REM    The following is a script that will determine how many extents of contiguous free space you have in Oracle as well as the  
REM    total amount of free space you have in each tablespace. From these results you can detect how fragmented your tablespace is.  
REM   
REM    The ideal situation is to have one large free extent in your tablespace. The more extents of free space there are in the  
REM    tablespace, the more likely you  will run into fragmentation problems. The size of the free extents is also  very important.  
REM    If you have a lot of small extents (too small for any next extent size) but the total bytes of free space is large, then  
REM    you may want to consider defragmentation options.

clear computes breaks columns

break on report
comp sum of nfrags totsiz avasiz on report

col tsname  format         a30 heading 'Tablespace'
col nfrags  format 999,999,990 heading 'FreeFrags'
col mxfrag  format 999,999,990 heading 'LargestFrag(KB)'
col totsiz  format 999,999,990 heading 'Total|(KB)'
col avasiz  format 999,999,990 heading 'Available(KB)' 
col pctusd  format      990.99 heading 'PctUsed'

set pages 1000 lines 200

accept Tablespace prompt 'What is the Tablespace Name: '

REM #############################################################
REM Part1
REM #############################################################
spool spool\&Tablespace._TbsFragmentation1-&_MyDB1.
select total.tablespace_name tsname, count(free.bytes) nfrags, nvl(max(free.bytes)/1024,0) mxfrag
    ,  total.bytes/1024 totsiz, nvl(sum(free.bytes)/1024,0) avasiz, (1-nvl(sum(free.bytes),0)/total.bytes)*100 pctusd
from   dba_data_files  total,   dba_free_space free 
where  total.tablespace_name = upper('&Tablespace') 
and    total.tablespace_name = free.tablespace_name(+)
and    total.file_id=free.file_id(+)
group  by  total.tablespace_name,   total.bytes;
spool off

select  ts.name TableSpace, f.file#, tf.blocks, sum(f.length) free, count(1) frags, max(f.length) bigst, min(f.length) smllst,
        round(avg(f.length)) avg, sum(decode(sign(f.length-5), -1, f.length,0)) dead
from    sys.fet$ f, sys.file$ tf, sys.ts$ ts
where   ts.ts# = f.ts#
and     ts.ts# = tf.ts#
group   by ts.name, f.file#, tf.blocks;


REM #############################################################
REM Part2
REM #############################################################
create table XXBEL_DBA_SPACE_TEMP1(TABLESPACE_NAME CHAR(30), CONTIGUOUS_BYTES NUMBER) tablespace tools storage(initial 8K next 8k);
declare
  cursor query1 is select * from dba_free_space where tablespace_name = upper('&Tablespace') order by block_id;
  this_row        query1%rowtype;
  previous_row    query1%rowtype;
  total           number;
begin
  open query1;
  fetch query1 into this_row;
  previous_row := this_row;
  total := previous_row.bytes;
  loop
  fetch query1 into this_row;
     exit when query1%notfound;
     if this_row.block_id = previous_row.block_id + previous_row.blocks then
        total := total + this_row.bytes;
        insert into XXBEL_DBA_SPACE_TEMP1 (tablespace_name) values (previous_row.tablespace_name);
     else
        insert into XXBEL_DBA_SPACE_TEMP1 values (previous_row.tablespace_name, total);
        total := this_row.bytes;
     end if;
     previous_row := this_row;
  end loop;
  insert into XXBEL_DBA_SPACE_TEMP1 values (previous_row.tablespace_name, total);   
end;
/

set pagesize 60 echo off   

spool spool\&Tablespace._TbsFragmentation2_&_MyDB1.

column "CONTIGUOUS BYTES" for 999,999,999,999
column "COUNT"            for 999
column "TOTAL BYTES"      for 999,999,999,999
column "TODAY"   noprint new_value new_today for a1

select TABLESPACE_NAME  "TABLESPACE NAME", CONTIGUOUS_BYTES "CONTIGUOUS BYTES"
from   XXBEL_DBA_SPACE_TEMP1
where  CONTIGUOUS_BYTES is not null
order  by TABLESPACE_NAME, CONTIGUOUS_BYTES desc;

select tablespace_name, count(1) "# OF EXTENTS", sum(contiguous_bytes) "TOTAL BYTES"
from   XXBEL_DBA_SPACE_TEMP1
group  by tablespace_name;

spool off

drop table XXBEL_DBA_SPACE_TEMP1;
