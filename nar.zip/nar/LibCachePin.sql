-- @LibCachePin.sql


COL event FORMAT a20 TRUNC
COL owner format a8
COL object format a70
COL SID for 99999
COL SERIL# for 999999999

set lines 132

-- Who is waiting for Library Cache Pins
tti "Users Waiting for Library Cache Pins"
SELECT sid, event, p1raw, seconds_in_wait, wait_time
FROM   sys.v_$session_wait
WHERE  event = 'library cache pin'
AND    state = 'WAITING';

-- Get the object's owner and name
tti "Object that is Blocking"
SELECT kglnaown AS owner, kglnaobj as Object
FROM   sys.x$kglob
WHERE  kglhdadr='&P1RAW';

-- Identify the users that are waiting/blocking. "Mode Held" displays the blocker.
tti "Blocking/Waiting Users"
SELECT s.sid, s.serial#, kglpnmod "Mode Held", kglpnreq "Request"
FROM   sys.x$kglpn p, sys.v_$session s
WHERE  p.kglpnuse = s.saddr
AND    kglpnhdl   = '&P1RAW';
