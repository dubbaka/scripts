Select Profile_Option_Value
from applsys.Fnd_Profile_Option_Values
 Where
       Level_ID = 10001
   And Level_Value = 0
   And Application_ID = 0
   And Profile_Option_ID = ( Select Profile_Option_Id
                               From applsys.Fnd_Profile_Options
                              Where Profile_Option_Name = 'CONC_PMON_METHOD');
