col os_process_id format a8
col prstdte format a18 head "StartedOn"
select q.concurrent_queue_name, p.os_process_id, to_char(p.process_start_date,'mm/dd/yy hh24:mi:ss') prstdte
from applsys.fnd_concurrent_processes p, applsys.fnd_concurrent_queues q
where   p.queue_application_id = q.application_id
  and p.concurrent_queue_id = q.concurrent_queue_id 
and p.process_status_code = 'A'
order by 1 
/
