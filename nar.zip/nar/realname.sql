/* realname.sql
    show the Apps user name name stored in the Apps for a given real name
*/
set verify off
col description head "Name" format a40 trunc
col user_name head "Badge Number" format a15 trunc
col user_id head "Internal #"
accept srchusr char prompt 'What is the Apps user name : '
select user_id,user_name,description
from applsys.fnd_user
where description like upper('%&srchusr%');

