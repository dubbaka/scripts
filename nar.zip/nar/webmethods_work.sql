col sid format 9999
col machine format a15 trunc
col proginfo format a20 trunc
col osuser format a8 trunc
select * from (
select s.sid, 
         v0.value db_block_gets,
         v1.value cons_gets, 
         v2.value phys_reads,
	 v0.value + v1.value + v2.value tot_reads,
	 v3.value phys_writes,
	 v4.value redo_writes,
         s.osuser, s.machine ,
         nvl(s.module,s.program) proginfo
from v$sesstat v0, v$sesstat v1, v$sesstat v2, v$sesstat v3, v$sesstat v4, v$session s
where v0.statistic# = 38
and v0.sid = s.sid
and v1.statistic# = 39
and v1.sid = s.sid
and v2.statistic# = 40
and v2.sid = s.sid
and v3.statistic# = 44
and v3.sid = s.sid
and v4.statistic# = 105
and v4.sid = s.sid
and s.username = 'WEBMETHODS'
order by 5 desc)
where rownum < 11
/

