col column_name format a30 trunc
col owner format a15 trunc
col column_position format 999 head Order
set verify off
accept tabname char default NONE prompt 'What is the partitioned table name <NONE> : '
prompt Getting partitioning info for &tabname....
select t.owner,t.table_name,t.partitioning_type,t.SUBPARTITIONING_TYPE ,
       t.PARTITION_COUNT, k.column_name,k.column_position
  from dba_part_tables t, dba_part_key_columns k
  where t.table_name = upper('&tabname') 
  and upper('&tabname') != 'NONE'
  and k.name = t.table_name
 order by 1,2,7;

prompt Getting partioning info on indexes for &tabname....
select i.owner,i.index_name,i.partitioning_type,i.locality,i.SUBPARTITIONING_TYPE ,
       i.PARTITION_COUNT, k.column_name,k.column_position
  from dba_part_indexes i, dba_part_key_columns k
  where i.table_name = upper('&tabname') 
  and upper('&tabname') != 'NONE'
  and k.name = i.index_name
 order by 1,2,7;

