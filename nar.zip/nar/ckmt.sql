/* ckmt.sql
     check middle tiers
*/
col umachine format a20 trunc head UserSrvr
col totact format 999999 head ACTIVE
col totinact format 999999 head INACTIVE
col totsess format 999999 head TOTAL
col earliest_logon format a12 head Earliest
col latest_logon format a12 head Latest
col username for a22
break on report
compute sum of totact on report
compute sum of totinact on report
compute sum of totsess on report

select inst_id,
sum(decode(s.status,'ACTIVE',1,0)) totact,
sum(decode(s.status,'INACTIVE',1,0)) totinact,
 count(*) totsess,
min(to_char(s.logon_time,'mm/dd hh24:mi')) earliest_logon,
max(to_char(s.logon_time,'mm/dd hh24:mi')) latest_logon
from gv$session s
where s.type = 'USER'
group by inst_id
order by 1
/

select replace(s.machine,'ASIAPAC\',null) umachine,OSUSER,username,
sum(decode(s.status,'ACTIVE',1,0)) totact,
sum(decode(s.status,'INACTIVE',1,0)) totinact,
 count(*) totsess,
min(to_char(s.logon_time,'mm/dd hh24:mi')) earliest_logon,
max(to_char(s.logon_time,'mm/dd hh24:mi')) latest_logon
from gv$session s
where s.type = 'USER'
group by s.machine,osuser,username
order by 4,1,3
/

/* ckmt.sql
     check middle tiers
*/
col umachine format a20 trunc head UserSrvr
col totact format 999999 head ACTIVE
col totinact format 999999 head INACTIVE
col totsess format 999999 head TOTAL
col earliest_logon format a12 head Earliest
col latest_logon format a12 head Latest
col username for a22
break on report
compute sum of totact on report
compute sum of totinact on report
compute sum of totsess on report
select replace(s.machine,'ASIAPAC\',null) umachine,OSUSER,username,
sum(decode(s.status,'ACTIVE',1,0)) totact,
sum(decode(s.status,'INACTIVE',1,0)) totinact,
 count(*) totsess,
min(to_char(s.logon_time,'mm/dd hh24:mi')) earliest_logon,
max(to_char(s.logon_time,'mm/dd hh24:mi')) latest_logon
from gv$session s
where s.type = 'USER'
and s.machine like '%bze1oa%'
group by s.machine,osuser,username
order by 1
/