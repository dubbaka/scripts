-- @DBGrthRpt.sql

clear columns breaks computes

set pages 50000 lines 2000 feed off pau off timing on time off echo off trim on trimspool on colsep |

col "TimeNow"      for a18
col pHost for a10
col pSid for a10

col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;

prompt Get the Total DB Size excluding ctrl filescol PARAMETER for a50
col VALUE for a60
select * from nls_database_parameters;

prompt Get the uptime of the database
col "Uptime(secs)" new_value _TimeMS
col "Uptime(Mins)" for 99999.99
col "Uptime(Hrs)"  for 99999.99
col "TimeNow" for a18
col STARTUP_TIME for a18 head 'started@'
select inst_id, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') "TimeNow", to_char(STARTUP_TIME,'dd-Mon-yy hh24:mi:ss') STARTUP_TIME
, (sysdate-STARTUP_TIME)*86400*1000 "Uptime(ms)", (sysdate-STARTUP_TIME)*86400 "Uptime(Secs)"
, (sysdate-STARTUP_TIME)*1440 "Uptime(Mins)", (sysdate-STARTUP_TIME)*24 "Uptime(Hrs)"
from gv$instance;

prompt
prompt Get the Database details
col "DatabaseName" for a15
col DB_UNIQUE_NAME for a15
col INST_ID for 999999
col LOG_MODE for a12
col "DateCreated" for a18
col CONTROLFILE_TYPE for a10 head 'CtrlFile|Type'
col REMOTE_ARCHIVE for a10 head 'Remote|Acrhive?'
col FORCE_LOGGING for a7 head 'Force|Logging?'
col PLATFORM_NAME for a40 head 'Platform'
col FLASHBACK_ON for a7 head 'FlashBack|On?'
col SUPPLEMENTAL_LOG_DATA_FK for a7 head 'SuppLog|DataFK'
col SUPPLEMENTAL_LOG_DATA_ALL for a7 head 'SuppLog|DataAll'
select INST_ID, NAME "DatabaseName", DBID, DATABASE_ROLE, to_char(CREATED,'dd-Mon-yy hh24:mi') "DateCreated", LOG_MODE, OPEN_MODE, FORCE_LOGGING
, CONTROLFILE_TYPE, REMOTE_ARCHIVE, PROTECTION_MODE, PROTECTION_LEVEL
from gv$database
order by INST_ID;

prompt
prompt Get the Instance details
col INSTANCE_NUMBER for 99999999 head 'Instance|Number'
col HOST_NAME for a15
col VERSION for a12
col PARALLEL for a8
col ARCHIVER for a8
col LOG_SWITCH_WAIT for a8 head 'LogSwitch|Wait'
col SHUTDOWN_PENDING for a8 head 'Shutdown|Pending'
col ACTIVE_STATE for a8 head 'Active|State'
col DATABASE_STATUS for a8 head 'Database|Status'
col "DateStarted" for a15
select INST_ID, INSTANCE_NUMBER, THREAD#, INSTANCE_NAME, to_char(STARTUP_TIME,'dd-Mon-yy hh24:mi') "DateStarted", LOGINS, STATUS, SHUTDOWN_PENDING, DATABASE_STATUS
, ARCHIVER, VERSION, INSTANCE_ROLE, HOST_NAME, ACTIVE_STATE, PARALLEL, LOG_SWITCH_WAIT
from gv$instance
order by INST_ID;


prompt
prompt Get the Total DB Size excluding ctrl files
col "InstId" for a10
col "SizeGB" for 9999.99
select decode(INST_ID, 99,'Common', INST_ID) "InstId", sum("SizeGB") "SizeGB"
from (select 99 INST_ID, sum(bytes/(1073741824)) "SizeGB" from dba_data_files union
      select 99 INST_ID, sum(bytes/(1073741824)) "SizeGB" from dba_temp_files union
      select INST_ID, sum(bytes/(1073741824)) "SizeGB" from gv$log group by INST_ID
  ) group by INST_ID;


prompt 
prompt Get the 3 Primary DB Components Size excluding ctrl files
col "DBFSizeGB" for 9999999.99
col "TempSizeGB" for 9999999.99
col "RedoSizeGB" for 9999999.99
select sum(bytes/(1073741824)) "DBFSizeGB" from dba_data_files;
select sum(bytes/(1073741824)) "TempSizeGB" from dba_temp_files;
select INST_ID, sum(bytes/(1073741824)) "RedoSizeGB" from gv$log group by INST_ID;


prompt 
prompt Get the Total number of files including ctrl files
col "InstId" for a10
select decode(INST_ID, 99,'Common', INST_ID) "InstId", sum(cnt1) "Files in DB"
from ( select 99 INST_ID, count(1) as cnt1 from dba_data_files union
       select 99 INST_ID, count(1) as cnt1 from dba_temp_files union
       select 99 INST_ID, count(1) as cnt1 from v$controlfile union
       select INST_ID, count(1) as cnt1 from gv$logfile group by INST_ID)
group by INST_ID;

col "Ordr" new_value _Ordr noprint
col cnt1 for a20
select 1 "Ordr", 'DBFs= '||count(1) as cnt1 from dba_data_files
union
select 2 "Ordr", 'Tempfile= '||count(1) as cnt1 from dba_temp_files
union
select 3 "Ordr", 'Ctrlfiles= '||count(1) as cnt1 from v$controlfile
union
select 4 "Ordr", 'Redologs= '||count(1) as cnt1 from gv$logfile where TYPE != 'STANDBY'
order by "Ordr";


prompt 
prompt Display the Redolog files
col "RedoLogFile" for a60
select INST_ID, GROUP#, STATUS, TYPE, MEMBER "RedoLogFile"
from gv$logfile order by inst_id, group#;


prompt 
prompt Display the Control files
col "ControlFile" for a60
select INST_ID, STATUS, NAME "ControlFile"
from gv$controlfile order by inst_id;


prompt 
prompt Get the Total number of Rows in the database
col "TableRows" for 9999999999999999 head 'Number Of Table Rows'
col "NdxRows" for 9999999999999999 head 'Number Of Index Rows'
select sum(NUM_ROWS) "TableRows" from dba_tables;
select sum(NUM_ROWS) "NdxRows" from dba_indexes;


prompt 
prompt Database growth report
col "YEAR" new_value _MyYear noprint
col "Month" new_value _MyMth noprint
col "YEAR-MONTH" for a10
col "Created(MB)" for 9999999999999
col "GROWTH(MB)" for 9999999999999
select to_char(creation_time, 'RRRR') "YEAR"
  , decode(to_char(creation_time, 'Mon'), 'Jan',1, 'Feb',2, 'Mar',3, 'Apr',4, 'May',5, 'Jun',6, 'Jul',7, 'Aug',8, 'Sep',9, 'Oct',10, 'Nov',11, 'Dec',12) "Month"
  , to_char(creation_time, 'RRRR-Mon') "YEAR-MONTH", count(1) "DBFsContributing2Growth", sum(CREATE_BYTES)/(1024*1024) "Created(MB)", sum(bytes)/(1024*1024) "GROWTH(MB)"
from   v$datafile
group  by to_char(creation_time, 'RRRR'), to_char(creation_time, 'Mon'), to_char(creation_time, 'RRRR-Mon')
order  by "YEAR", "Month";

clear columns breaks computes

