col ssid form A10
col lmode form 999 heading "loc"
col request form 999 heading "req"
col name form A30
break on id1 on sid
select lpad(' ',decode(a.request,0,0,3))||a.sid ssid,a.id1
      ,a.lmode,a.request,d.osuser, c.name, d.status, d.program
 from v$session d, sys.obj$ c,v$lock b,v$lock a 
where a.id1 in ( select id1 from v$lock where lmode = 0 )
  and a.sid = b.sid
  and a.sid = d.sid
  and c.obj# = b.id1
  and b.type = 'TM'
order by a.id1,a.request,b.sid,c.name
