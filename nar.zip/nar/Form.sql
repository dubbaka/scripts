/* Form.sql   Find the name of the form found by using sid.sq or proc.sql */

clear columns breaks computes

col APPLICATION_SHORT_NAME head "ShortName" for a10
col APPLICATION_NAME head "Application" for a30
col FORM_NAME for a30
col USER_FORM_NAME head "Form" for a60

accept trgtFORM char default ALL prompt 'Form <ALL> : '

select ff.APPLICATION_ID, fa.APPLICATION_SHORT_NAME, fat.APPLICATION_NAME, ff.FORM_ID, ff.FORM_NAME, fft.USER_FORM_NAME
from   apps.fnd_form ff, apps.fnd_form_tl  fft, apps.fnd_application fa, apps.fnd_application_tl fat
where  fft.APPLICATION_ID  = ff.APPLICATION_ID
and    fft.FORM_ID         = ff.FORM_ID
and    fft.LANGUAGE        = 'US'
and    fa.APPLICATION_ID   = fft.APPLICATION_ID
and    fat.APPLICATION_ID  = fa.APPLICATION_ID
and    fat.LANGUAGE        = 'US'
and    ff.FORM_NAME        = upper('&trgtFORM')
order  by fa.APPLICATION_SHORT_NAME, ff.FORM_NAME;
