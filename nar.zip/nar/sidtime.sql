/* sidtime.sql
    check sid for last call et
*/
col osuser format a10 trunc
col LastCallET     format a11
col sid format 9999
col username format a10 trunc
col uprogram format a25 trunc
set linesize 132
set verify off
accept trgtsid number default 0 prompt 'What is the SID : '
select to_char(s.logon_time, 'mm/dd hh:mi:ssAM') loggedon,
  s.sid, s.status,
   floor(last_call_et/3600)||':'||
   floor(mod(last_call_et,3600)/60)||':'||
   mod(mod(last_call_et,3600),60) "LastCallET",
 s.username, s.osuser, 
 p.spid, s.module || ' - ' || s.program uprogram, s.sql_hash_value
from v$session s, v$process p
where p.addr = s.paddr
  and s.sid = &trgtsid
  and &trgtsid > 0;



