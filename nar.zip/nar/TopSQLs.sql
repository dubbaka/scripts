-- @TopSQLs.sql

clear columns breaks computes

set pages 50000 lines 2000 wrap off echo off feed off timing on time off veri off trimspool on colsep |

col inst_id for 99999 head 'InstId'
col HASH_VALUE for 999999999999
col "BufferGets" for 999999999999999999999
col "Executions" for 999999999999999999999
col "DiskReads" for 999999999999999999999
col "RowsProcessed" for 999999999999999999999
col "ParseCalls" for 999999999999999999999
col "CPUTime(s)" for 999999999999999999999
col "ElapsedTime(s)" for 999999999999999999999
col "Module" for a40
col "Action" for a30 trunc
col "SharableMem(b)" for 999999999999999999999
col "Fetches" for 999999999999999999999
col "Loads" for 999999999999999999999
col "Sorts" for 999999999999999999999
col "verCnt" for 999999999999999999999
col "LoadedVers" for 999999999999999999999
col "GetsPerExec" for 9999999999.99
col "ReadsPerExec" for 9999999999.99
col "RowsPerExec" for 9999999999.99
col "ParsePerExec" for 9999999999.99
col "CPUTimePerExec" for 9999999999.99
col "ElapTimePerExec" for 9999999999.99
col "FetchesPerExec" for 9999999999.99
col "TimeNow"      for a18
col pHost for a10
col pSid for a10


col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;

prompt 
prompt Top SQLs by Logical Gets
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.buffer_gets,0) "BufferGets", nvl(b.executions,0) "Executions", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.rows_processed,0) "RowsProcessed", nvl(b.parse_calls,0) "ParseCalls", nvl(b.sharable_mem,0) "SharableMem(b)"
          , decode(nvl(b.executions,0) ,0,0 ,nvl(b.buffer_gets,0)/decode(nvl(b.executions,0),0,0.001,b.executions)) "GetsPerExec"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.buffer_gets,0) desc)
where rownum < 51;

prompt 
prompt Top SQLs by Physical Reads
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.disk_reads,0) "DiskReads", nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets"
          , nvl(b.rows_processed,0) "RowsProcessed", nvl(b.parse_calls,0) "ParseCalls", nvl(b.sharable_mem,0) "SharableMem(b)"
          , decode(nvl(b.disk_reads,0) ,0,0 ,nvl(b.disk_reads,0)/decode(nvl(b.executions,0),0,0.001,b.executions)) "ReadsPerExec"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.disk_reads,0) desc)
where rownum < 51;


prompt 
prompt Top SQLs by Rows Processed
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.rows_processed,0) "RowsProcessed", nvl(b.disk_reads,0) "DiskReads", nvl(b.executions,0) "Executions"
          , nvl(b.buffer_gets,0) "BufferGets", nvl(b.parse_calls,0) "ParseCalls", nvl(b.sharable_mem,0) "SharableMem(b)"
          , decode(nvl(b.rows_processed,0) ,0,0 ,nvl(b.rows_processed,0)/decode(nvl(b.executions,0),0,0.001,b.executions)) "RowsPerExec"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.rows_processed,0) desc)
where rownum < 51;


prompt 
prompt Top SQLs by ParseCalls
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads", nvl(b.executions,0) "Executions"
          , nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed", nvl(b.sharable_mem,0) "SharableMem(b)"
          , decode(nvl(b.parse_calls,0) ,0,0 ,nvl(b.parse_calls,0)/decode(nvl(b.executions,0),0,0.001,b.executions)) "ParsePerExec"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.parse_calls,0) desc)
where rownum < 51;


prompt 
prompt Top SQLs by By Cpu Time
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed"
          , decode(nvl(b.sharable_mem,0) ,0,0 ,nvl(b.sharable_mem,0)/decode(nvl(b.executions,0),0,0.001,b.executions)) "CPUTimePerExec"
          , nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.cpu_time,0) desc)
where rownum < 51;


prompt 
prompt Top SQLs by By Elapsed Time
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)", nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed"
          , decode(nvl(b.sharable_mem,0) ,0,0 ,nvl(b.sharable_mem,0)/decode(nvl(b.executions,0),0,0.001,b.executions)) "ElapTimePerExec"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.elapsed_time,0) desc)
where rownum < 51;


prompt 
prompt Top 10 SQLs by SharableMemory
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.sharable_mem,0) "SharableMem(b)", nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.sharable_mem,0) desc)
where rownum < 51;


prompt 
prompt By Top SQLs by Fetches
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.FETCHES,0) "Fetches", nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed"
          , decode(nvl(b.FETCHES,0) ,0,0 ,nvl(b.FETCHES,0)/decode(nvl(b.executions,0),0,0.001,b.executions)) "FetchesPerExec"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.FETCHES,0) desc)
where rownum < 51;


prompt 
prompt Top SQLs by Loads
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.Loads,0) "Loads", nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.Loads,0) desc)
where rownum < 51;


prompt 
prompt Top SQLs by Version Count
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.VERSION_COUNT,0) "verCnt", nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)", nvl(b.LOADED_VERSIONS,0) "LoadVers"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.VERSION_COUNT,0) desc)
where rownum < 51;


prompt 
prompt Top SQLs by Loaded Versions
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.LOADED_VERSIONS,0) "LoadedVers", nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed", nvl(b.VERSION_COUNT,0) "verCnt"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.LOADED_VERSIONS,0) desc)
where rownum < 51;


prompt 
prompt Top SQLs by Sorts
select * from (
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", b.inst_id, nvl(b.Sorts,0) "Sorts", nvl(b.parse_calls,0) "ParseCalls", nvl(b.disk_reads,0) "DiskReads"
          , nvl(b.executions,0) "Executions", nvl(b.buffer_gets,0) "BufferGets", nvl(b.rows_processed,0) "RowsProcessed", nvl(b.VERSION_COUNT,0) "verCnt"
          , nvl(b.cpu_time,0)/1000000 "CPUTime(s)", nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
          , b.hash_value, decode(b.module, null,'null', b.module) "Module"
          , decode(b.action, null,'null', b.action) "Action"
          , b.sql_text sqltext
   from gv$sqlarea b
   where b.command_type != 47
   order by nvl(b.Sorts,0) desc)
where rownum < 51;

clear columns breaks computes
