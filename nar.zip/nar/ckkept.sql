col type format a15 trunc
select kept,type,count(*),sum(loads),sum(sharable_mem),sum(executions)
from v$db_object_cache
where type in ('SEQUENCE','PACKAGE','PACKAGE BODY','PROCEDURE','FUNCTION','TRIGGER')
group by kept,type
/

