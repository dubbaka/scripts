-- @FndProfile.sql

col "ProfileLevel" for a15
col "Non-Site Desc" for a50
col "UserName" for a15
col "ProfileOptionName" for a80
col "Value" for a100
col "LastUpdatedBy" for a15
col "LastUpdatedOn" for a22

set pages 1000 pau off lines 400

accept trgtProfLvl char default ALL prompt 'Profile Level --> Site , Responsibility , Application , User: <ALL>: '

SELECT DECODE(fpova.level_id, 10001, 'Site', 10002, 'Application', 10003, 'Responsibility', 10004, 'USER', fpova.level_id) "ProfileLevel"
     , fu.user_name                  "UserName"
     , fpov.user_profile_option_name "ProfileOptionName"
     , fpova.profile_option_value    "Value"
     , fu2.user_name                 "LastUpdatedBy"
     , to_char(fpova.LAST_UPDATE_DATE,'mm/dd/yy hh24:mi')       "LastUpdatedOn"
     , DECODE(fpova.level_id, 10001, NULL, 10002, fa.application_name, 10003, fr.responsibility_name, 10004, fu.user_name, fpova.level_id) "Non-Site Desc"
FROM   fnd_profile_options_vl fpov  , fnd_profile_option_values fpova , fnd_application_tl fa  -- table inclusion when looking at application joins
     , fnd_responsibility_tl fr  -- table inclusion when looking at responsibility joins
     , fnd_user fu  -- table inclusion when looking at user joins
     , fnd_user fu2
WHERE (fpova.level_id = DECODE(upper('&trgtProfLvl'),'SITE',10001,'APPLICATION',10002,'RESPONSIBILITY',10003,'USER',10004) or upper('&trgtProfLvl') = 'ALL')
AND    fpov.application_id = fpova.application_id
AND    fpov.profile_option_id = fpova.profile_option_id
AND    start_date_active <= SYSDATE
AND    NVL(end_date_active,SYSDATE) >= SYSDATE
AND   (site_enabled_flag = 'Y'   OR   app_enabled_flag = 'Y'   OR   resp_enabled_flag = 'Y'   OR   user_enabled_flag = 'Y')
AND    fpova.level_value = fa.application_id (+) -- join for application values
AND    fa.SOURCE_LANG(+) = 'US'
AND    fpova.level_value = fr.responsibility_id (+)  -- join for responsibility values
AND    fr.SOURCE_LANG(+) = 'US'
AND    fpova.level_value = fu.user_id (+) -- join for user values
AND    fpova.last_updated_by = fu2.user_id (+)  -- join for update by user values
AND    upper(fpov.user_profile_option_name) like upper('%&OptionName%')
AND    upper(fpova.profile_option_value) like upper('%&OptionValue%')
ORDER  BY fpova.level_id, fpov.user_profile_option_name, fpova.profile_option_value;
