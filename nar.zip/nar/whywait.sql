REM ===============================================================================
REM This script will show why the session is waiting and howlong it is waiting
REM Input : sid (session id)
REM
REM
REM ================================================================================

col event for a25 word_wrap;
select distinct s.inst_id,a.event event, a.seconds_in_wait, s.status
  from gv$session_wait a, gv$session s
 where a.sid=s.sid
 and a.sid=&SID;
/

