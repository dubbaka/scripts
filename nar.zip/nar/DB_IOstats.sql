-- @DB_IOstats.sql

clear columns breaks computes

set lines 2000 pages 3000 feed off head on echo off pau off timing on time off veri off trimspool on  colsep |

col TABLESPACE_NAME for a30 head 'Tablespace'
col FILE_NAME for a60 head 'FileName'
col FILE#        for 99999
col AVGIOTIM     for 9999999999999
col LSTIOTIM     for 9999999999999
col MINIOTIM     for 9999999999999
col MAXIORTM     for 9999999999999
col MAXIOWTM     for 9999999999999
col pyr          for 9999999999999 head 'PhysicalReads'  
col pw           for 9999999999999 head 'PhysicalWrites'  
col pbr          for 9999999999999 head 'PhysicalBlksRead'  
col pbw          for 9999999999999 head 'PhysicalBlksWrtn'  
col rdti         for 9999999999999 head 'ReadTime'  
col wrti         for 9999999999999 head 'WriteTime'
col sblkrds      for 9999999999999 head 'SINGLEBLKRDS'
col sblkrdtim    for 9999999999999 head 'SINGLEBLKRDTIM(ms)'
col "SizeMB"     for 999999999
col "Uptime(Mins)" for 99999.99
col "Uptime(Hrs)"  for 99999.99
col "TimeNow"      for a18
col "InstStarted"    for a18 head 'DBstarted@'



col "TimeNow"      for a18
col pHost for a10
col pSid for a10

col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;

prompt Top Database files by IO statistics ex: reads, writes, BufferWaits etc
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", a.FILE#, b.TABLESPACE_NAME, b.FILE_NAME, a.phyrds pyr, a.phywrts pw, a.phyblkrd pbr, a.phyblkwrt pbw, a.READTIM rdti
, a.WRITETIM wrti, a.SINGLEBLKRDS sblkrds, a.SINGLEBLKRDTIM sblkrdtim, a.AVGIOTIM, a.LSTIOTIM, a.MINIOTIM, a.MAXIORTM, a.MAXIOWTM
from v$filestat a, dba_data_files b
where a.FILE# = b.FILE_ID
union
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", fs.FILE#, df.TABLESPACE_NAME, df.FILE_NAME, fs.phyrds pyr, fs.phywrts pw, fs.phyblkrd pbr, fs.phyblkwrt pbw, fs.READTIM rdti
, fs.WRITETIM wrti, fs.SINGLEBLKRDS sblkrds, fs.SINGLEBLKRDTIM sblkrdtim , fs.AVGIOTIM, fs.LSTIOTIM, fs.MINIOTIM, fs.MAXIORTM, fs.MAXIOWTM
from v$tempstat fs, dba_temp_files df
where  df.file_id = fs.file#;

clear columns breaks computes
