rem #############################################################################
rem File 	: @ObjSize.sql
rem Author	: Ravi Peesapati
rem Run As	: SYSTEM (SELECT ANY TABLE)
rem Use		: List top 100 Tables/Indexes
rem Output	: 
rem ##############################################################################

clear columns breaks computes

set wrap on  verify off lines 500

col owner for a16
col segment_name for a30
col initial_extent head "Initial|Extent"
col next_extent head "Next|Extent"
col pct_increase head "Pct|Increase"
col "SizeMB" for 99999

select owner, segment_type, segment_name, round(bytes/1024/1024/1024,2) "SizeGB", bytes/(1024*1024) "SizeMB"
       , extents, max_extents, initial_extent, next_extent, blocks, pct_increase
from   dba_segments
where  segment_type in ('INDEX' , 'TABLE','TABLE PARTITION')
and    segment_name like upper('%&Segment%')
and    rownum <= 100
order  by bytes/(1024*1024) desc

spool spool\ObjSize_&_MyDB1..log
/
spool off