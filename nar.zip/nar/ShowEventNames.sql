-- @ShowEventNames.sql


clear columns breaks computes

set lines 200 pau on wrap on

col event#     for 999999
col parameter1 for a30
col parameter2 for a20
col parameter3 for a20

col "Class" for a15
select CASE '&_MyDbVer' WHEN '9i' THEN 'Class' ELSE wait_class END "Class", event#, name, parameter1, parameter2, parameter3
from   v$event_name
order  by "Class";

set pau off
