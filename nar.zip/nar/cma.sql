set verify off
set lines 200
set pages 120
set wrap on

col qname head "Activated Concurrent Queue" format a80
col Node for a15
col actual head "Actual" format 999999
col target head "Target" format 999999
col running head "Running" format 9999999
col pending head "Pending" format 9999999
col paused head "Paused" format 9999999
col influx head "InFlux" format 9999999
col avgqtime head "AvgQtime" format 99999.99

SELECT   
--user_concurrent_queue_name || ' - ' || concurrent_queue_name qname, 
         target_node Node, sum(max_processes ) target,sum(running_processes) actual
    FROM fnd_concurrent_queues_vl
   WHERE enabled_flag = 'Y'
group by 
--user_concurrent_queue_name || ' - ' || concurrent_queue_name,
target_node;
         