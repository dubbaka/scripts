-- @TopRowsNdxs.sql

clear columns breaks computes

set lines 2000 pages 3000 feed off head on echo off pau off timing on time off veri off trimspool on  colsep |

prompt Top Segments (Indexes/IndexPartitions, IOT,  LOBINDEX) containing more than 100 rows
col OWNER for a25 head 'IndexOwner'
col INDEX_NAME for a30 head 'Index'
col INDEX_TYPE for a30 head 'IndexType'
col UNIQUENESS for a10 head 'Uniqueness'
col BLEVEL for 999999
col LEAF_BLOCKS for 999999 head 'Leaf|Blocks'
col TABLE_TYPE for a30 head 'TableType'
col GENERATED for a10
col SECONDARY for a10

col "TimeNow"      for a18
col pHost for a10
col pSid for a10

col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;

select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", OWNER, INDEX_NAME, INDEX_TYPE, NUM_ROWS, nvl(TABLESPACE_NAME,'null') TABLESPACE_NAME, UNIQUENESS, PARTITIONED
, nvl(BLEVEL,0) BLEVEL, nvl(LEAF_BLOCKS,0) LEAF_BLOCKS, nvl(table_name,'null') Table_name, nvl(TABLE_TYPE,'null') TABLE_TYPE
, nvl(CLUSTERING_FACTOR,0) CLUSTERING_FACTOR, nvl(Compression,'null') Compression, TEMPORARY, GENERATED, SECONDARY, STATUS
, nvl(BUFFER_POOL,'null') BUFFER_POOL, nvl(LOGGING,'null') LOGGING, nvl(DISTINCT_KEYS,0) DISTINCT_KEYS
from dba_indexes
where num_rows is not null
and owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
and num_rows > 100;

clear columns breaks computes

