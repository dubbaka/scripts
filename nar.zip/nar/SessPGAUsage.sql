-- @SessPGAUsage.sql
-- Sessions using maximum PGA


clear computes breaks columns

col "PgaUsedMB" for 999,999,999.99
col "PgaAllocMB" for 999,999,999.99
col "PgaFreeableMB" for 999,999,999.99
col "PgaMaxMB" for 999,999,999.99
col username for a15
col sid for 99999

set pages 50 pau on

break on report
compute sum of count(1) on report

Prompt Total PGA usage
select sum(p.PGA_USED_MEM/(1024*1024)) "PgaUsedMB", sum(p.PGA_ALLOC_MEM/(1024*1024)) "PgaAllocMB", sum(p.PGA_FREEABLE_MEM/(1024*1024)) "PgaFreeableMB", sum(p.PGA_MAX_MEM/(1024*1024)) "PgaMaxMB"
from   v$process p;

Prompt Individual Session PGA usage
select s.sid, s.serial#, s.username, p.PGA_USED_MEM/(1024*1024) "PgaUsedMB"
     , p.PGA_ALLOC_MEM/(1024*1024) "PgaAllocMB", p.PGA_FREEABLE_MEM/(1024*1024) "PgaFreeableMB", p.PGA_MAX_MEM/(1024*1024) "PgaMaxMB"
from   v$session s , v$process p
where  p.addr = s.paddr
order  by p.PGA_USED_MEM desc;
