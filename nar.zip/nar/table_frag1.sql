REM NAME:   table_frag1.SQL
REM USAGE: tfsldtr table_owner table_name
REM ------------------------------------------------------------------------ 
REM REQUIREMENTS: ANALYZE on table, SELECT on DBA_TABLES, DBA_SEGMENTS, DBA_EXTENTS 
REM AUTHOR:  
REM    Craig A. Shallahamer, Oracle US      
REM PURPOSE: 
REM    Load the my_tfrag table with a given table's fragmentation stats. 
REM ------------------------------------------------------------------------ 
  
set feedback on time on timing on
  
def towner=&1  
def tname=&2
 
  
rem *******************************************************************  
rem * Goal: Analyze table to gather statistics
rem *******************************************************************  
rem Specifically we are looking for:  
rem    - blocks ABOVE the hwm, i.e. empty blocks (dba_tables.blocks)  
rem    - average row length (dba_tables.blocks)  
--prompt Running -- analyze table &towner..&tname estimate statistics sample 10 percentage;
--analyze table &towner..&tname estimate statistics sample 10 percent;

col val1 new_value blks_w_rows noprint  
col val2 new_value blks_above  noprint  
select blocks val1, empty_blocks val2  
from   dba_tables  
where  owner = upper('&towner')
and    table_name = upper('&tname');


rem *******************************************************************  
rem * Goal: Get the number of blocks allocated to the segment  
rem *******************************************************************
rem Specifically we are looking for: 
rem   - allocated blocks dba_segments.blocks  
col val1 new_value alloc_blocks noprint  
select blocks val1
from   dba_segments
where  owner        = upper('&towner')
and    segment_name = upper('&tname');

rem *******************************************************************  
rem * Goal: Calculate the HWM 
rem Specifically we are looking for:  
rem   - HWM = dba_segments.blocks - dba_tables.empty_blocks - 1  
rem   - HWM = allocated blocks - blocks above the hwn - 1
rem *******************************************************************  
col val1 new_value hwm noprint
select &alloc_blocks-&blks_above-1 val1
from   dual;  
  
rem *******************************************************************
rem * Goal: Get the Number of Fragmented Rows or Chained Frows (cr)  
rem *******************************************************************
col val1 new_value cr noprint
select chain_cnt val1   
from   dba_tables  
where  owner        = upper('&towner')
and    table_name   = upper('&tname');

rem ***********************************************************
rem * Goal :  Determine the Segment Fragmentation (sf)  
rem ***********************************************************
col val1 new_val sf noprint  
select count(1) val1  
from   dba_extents  
where  owner        = upper('&towner')
and    segment_name = upper('&tname');

rem ***********************************************************  
rem * Load the TFRAG table with the just gathered information.
rem ***********************************************************  
rem * Create the my_tfrag table if it does not exist.  
rem *  
drop table my_tfrag;

create table my_tfrag
(  
  owner				char(30),  
  name				char(30),  
  hwm				number,  
  blks_w_rows			number,  
  avg_row_size			number,
  possible_bytes_per_block	number,  
  no_frag_rows			number,  
  no_extents			number  
);
 
create unique index my_tfrag_u1 on my_tfrag (owner,name);

rem * Delete and insert the new stats.  
rem *  
delete from my_tfrag where  owner='&towner' and  name='&tname';
insert into my_tfrag values ('&towner', '&tname', &hwm, &blks_w_rows, 0 ,0, &cr, &sf);
commit;  

select owner towner, name tname, no_extents exts, (hwm - blks_w_rows)/(hwm + 0.0001) omega1, no_frag_rows chains
from my_tfrag
order by 1,2;


