Select  a.tablespace_name,  b.tot_space, a.free_space
From ( Select tablespace_name , sum ( bytes )  free_space
        From dba_free_space
         group by tablespace_name ) a,
      ( Select tablespace_name, sum ( bytes ) tot_space
         From dba_data_files
         group by tablespace_name ) b
where a.tablespace_name = b.tablespace_name
and ( a.free_space / b.tot_space ) * 100 < 10
/
