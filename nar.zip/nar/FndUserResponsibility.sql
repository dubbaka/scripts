-- @FndUserResponsibility.sql


clear columns breaks computes

set pages 100 lines 200 feed on

column application_name format a55
column responsibility_name format a55
column user_name format a15
column "Start" format a17
column "End" format a17

spool spool\FndUserResponsibility_&_MyDB1.

select fnduser.USER_NAME, appl.application_name, fndrespvl.RESPONSIBILITY_NAME
     , to_char(usergroup.start_date,'DD-MON-YYYY hh24:mi') "Start", to_char(usergroup.end_date,'DD-MON-YYYY hh24:mi') "End"
from   fnd_responsibility fndresp, fnd_responsibility_vl fndrespvl, fnd_user fnduser
     , fnd_user_resp_groups usergroup, fnd_application_vl appl
where  fndresp.RESPONSIBILITY_ID = fndrespvl.RESPONSIBILITY_ID
and    fndresp.RESPONSIBILITY_ID = usergroup.RESPONSIBILITY_ID
and    fnduser.USER_ID = usergroup.user_id
and    fndresp.application_id = appl.application_id
and    upper(user_name) like upper('%'||'&user_name'||'%')
and   (usergroup.end_date is null or usergroup.end_date > sysdate)
order  by user_name, application_name, responsibility_name;

spool off

set lines 2000 pau off
clear columns breaks computes
