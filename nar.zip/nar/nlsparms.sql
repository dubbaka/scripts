-- @initnlsparms.sql


select parameter , value
from nls_database_parameters
order by 1;
