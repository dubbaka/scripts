-- @TopIOSegments.sql

clear columns breaks computes

set pages 50000 lines 2000 feed on head on echo on pau off timing on time on veri off  trimspool on colsep |

col inst_id for 99999 head 'InstId'
col INSTANCE_NAME for a10 head "Instance"
col HOST_NAME for a15
col object_type for a30
col OBJECT_NAME for a30
col tablespace_name for a30 head "Tablespace"
col SUBOBJECT for a30
col VALUE for 999999999999999999999
col "TimeNow"      for a18
col pHost for a10
col pSid for a10

col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;

prompt 
prompt Top 50 Logical Reads per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'logical reads'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 Physical Reads per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'physical reads'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 Physical writes per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'physical writes'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 db block changes per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'db block changes'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 Buffer Busy waits per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'buffer busy waits'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 Row Lock waits per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'row lock waits'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 ITL waits per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'ITL waits'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 physical Reads direct per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'physical reads direct'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 Physical writes direct per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'physical writes direct'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 global cache cr blocks served per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'global cache cr blocks served'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

prompt 
prompt Top 30 global cache current blocks served per Segment
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", A.INST_ID, INSTANCE_NAME, HOST_NAME, OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE
   , nvl(SUBOBJECT_NAME,'null') SUBOBJECT
   from   gv$SEGMENT_STATISTICS A , gv$instance B
   where  STATISTIC_NAME = 'global cache current blocks served'
   and    B.INST_ID = A.INST_ID
   order  by VALUE desc)
where rownum < 51;

clear columns breaks computes
