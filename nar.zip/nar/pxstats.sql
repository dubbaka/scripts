select name,value from v$sysstat
where upper(name) like 'PARALLEL OPERATIONS%'
or upper(name) like 'PARALLELIZED%'
or upper(name) like 'PX%'
/
