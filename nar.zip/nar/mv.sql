--@mv.sql


set lines 400 trimspool on pau off pages 50

select OWNER, MVIEW_NAME, UPDATABLE, REFRESH_MODE, REFRESH_METHOD, STALENESS
from DBA_MVIEWS
where MVIEW_NAME = '&name';
