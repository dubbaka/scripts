/* modopensql.sql
      see all the open sql cursors held open by a module
	uses buffer gets per exec, disk reads per exec
*/
set verify off
set lines 132
break on report
compute sum of curscnt on report
col bgexec format 99999999.90
col drexec format 99999999.90
accept trgtmod char default NONE prompt 'What is the Module <NONE> : '
select a.hash_value,
	count(*) curscnt,
  	sum(a.executions) execs, 
	sum(a.buffer_gets)/decode(sum(executions),0,1,sum(executions)) bgexec,
	sum(a.disk_reads)/decode(sum(executions),0,1,sum(executions)) drexec, 
	sum(sorts) sortcnt ,
	c.sql_text
from gv$sqlarea a, gv$open_cursor c, gv$session s
where c.hash_value = a.hash_value
and a.inst_id=c.inst_id
and c.inst_id=s.inst_id
and s.sid = c.sid
and (s.module = upper('&trgtmod') and upper('&trgtmod') != 'NONE')
and executions > 0
group by a.hash_value, c.sql_text
order by 4,5;
clear breaks
clear computes

