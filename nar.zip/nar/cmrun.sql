-- @cmrun1.sql

rem ********************************************************************
rem * Description       : Information about jobs that ran
rem ********************************************************************

clear columns breaks compute

set feed off
col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDmonYY') "datenow" from dual;
set feed on pages 500 lines 300

set lines 1000 pages 30000

col os for A7 head AppProc
col spid for a6 head DBProc
col "ConcPgm" for a60
col time for 999,999.99 head 'Elapsed|(Mins)'
col "Req Id" for 9999999999
col "Parent" for a8
col "Prg Id" for 999999999
col qname head "Concurrent Manager Queue" for a40
col sid for 99999 head SID
--col completion_text for a50
col user_name for a15
col ARGUMENT_TEXT for a80

accept ReqID       number default 99          prompt 'Conc Request ID              <ALL> : '
accept ShrtConcPgm char   default ALL         prompt 'Conc Pgm ShortName           <ALL> : '
accept trgtqname   char   default ALL         prompt 'Conc Queue ShortName         <ALL> : '
accept FullConcPgm char   default ALL         prompt 'Conc Pgm LongName            <ALL> : '
accept RunDate     char   default ALL         prompt 'Run Date (DDmonYY)           <ALL> : '


select a.request_id "Req Id" , a.concurrent_program_id "Prg Id" , a.phase_code , a.status_code
,f.user_name 
,(nvl(actual_completion_date,sysdate)-actual_start_date)*1440 "Time"
,to_char(actual_start_date, 'DDMonYY HH24:MI:SS') "StartDate"
,to_char(actual_completion_date, 'DDMonYY HH24:MI:SS') "EndDate"
, a.ARGUMENT_TEXT, a.completion_text
from APPLSYS.fnd_Concurrent_requests a , APPLSYS.fnd_concurrent_processes b
,APPLSYS.fnd_concurrent_queues q , APPLSYS.fnd_concurrent_programs_tl c2
,APPLSYS.fnd_concurrent_programs c, fnd_user f
where (a.REQUEST_ID = &ReqID or &ReqID = 99)
and (q.concurrent_queue_name = upper('&trgtqname') or upper('&trgtqname') = 'ALL')
and (c.concurrent_program_name = upper('&ShrtConcPgm') or '&ShrtConcPgm' = 'ALL')
and (c2.user_concurrent_program_name like '&FullConcPgm%' or '&FullConcPgm' = 'ALL')
and (to_char(actual_start_date, 'DDmonYY') = '&RunDate' or '&RunDate' = 'ALL')
and a.controlling_manager = b.concurrent_process_id
and a.concurrent_program_id = c.concurrent_program_id
and a.program_application_id = c.application_id
and c2.concurrent_program_id = c.concurrent_program_id
and b.queue_application_id = q.application_id
and b.concurrent_queue_id = q.concurrent_queue_id
and c2.language = 'US'
and a.requested_by=f.user_id
order by actual_start_date;


prompt 1) For current running requests or status of a specific concurrent request use --> @cmrun2.sql
prompt 2) For further detailed analysis of a specific concurrent request use --> @cmAnalReq.sql
prompt 3) For getting Average run time analysis for a specifc concurrent program or all Concurrent programs (for today or for all days) use --> @cmAvgRunTime.sql
prompt 4) For displaying a specific or all Concurrent Manager que details (including work shifts) use --> @cms.sql
prompt 5) For individual or all Concurrent queue request analysis use --> @cmStats.sql
prompt 6) For displaying Concurrent requests that started between a given StartTime and EndTime use --> @cmbetween.sql
