/* jobhist.sql
	find the summary info for a specific program id
	use jobid.sql to find the program id
*/ 
col os form A6
col program form A45 trunc
set pages 38
col qname format a15 trunc
col "time(tot)" form 9999
col "time(avg)" form 9999.99
col "time(min)" form 9999.99
col "time(max)" form 9999.99
col "Req Id" form 9999999
col "Prg Id" form 999999
col "Jobs" form 9999
col lsm head Status format a10
col earlieststart head Earliest format a10
set recsep off
set verify off
break on qname nodup
accept cmprogid number prompt 'What is the program ID : '
select q.concurrent_queue_name qname,
       c.concurrent_program_name||' - '||
       ctl.user_concurrent_program_name "Program"
      ,to_char(min(actual_start_date),'mm/dd/rr') earlieststart
      ,sum(nvl(actual_completion_date-actual_start_date,0))*1440 "Time(tot)"
      ,avg(nvl(actual_completion_date-actual_start_date,0))*1440 "Time(avg)"
      ,min(nvl(actual_completion_date-actual_start_date,0))*1440 "Time(min)"
      ,max(nvl(actual_completion_date-actual_start_date,0))*1440 "Time(max)"
      ,count(*) "Jobs"
      ,ls.meaning lsm
from APPLSYS.fnd_Concurrent_requests a,APPLSYS.fnd_concurrent_programs c,
      APPLSYS.fnd_concurrent_programs_tl ctl,
      APPLSYS.fnd_lookup_values ls,
      APPLSYS.fnd_concurrent_processes b,
      applsys.fnd_concurrent_queues q      
where c.concurrent_program_id = &cmprogid
  and a.concurrent_program_id = c.concurrent_program_id
  and a.controlling_manager = b.concurrent_process_id
  and b.queue_application_id = q.application_id
  and b.concurrent_queue_id = q.concurrent_queue_id 
  and ctl.concurrent_program_id = c.concurrent_program_id
  and ctl.language = 'US'
  and a.program_application_id = c.application_id
  and ctl.application_id = c.application_id
  and ls.lookup_type = 'CP_STATUS_CODE'
  and ls.language = 'US'
  and ls.enabled_flag = 'Y'
  -- and (ls.start_date_active <= sysdate and ls.start_date_active is not null)
  and (ls.end_date_active > sysdate or ls.end_date_active is null)
  and a.status_code || '' = ls.lookup_code
  and a.phase_code || '' = 'C'
group by q.concurrent_queue_name, c.concurrent_program_name
        ,ctl.user_concurrent_program_name
        ,ls.meaning
order by 4 desc
/

