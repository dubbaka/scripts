-- @CMWorkShift.sql
-- Display workshift schedules for a Concurrent Manager


clear columns breaks computes
set verify off

col CONCURRENT_QUEUE_NAME heading "ConcQueName" for a30
col USER_CONCURRENT_QUEUE_NAME for a50
col CONCURRENT_TIME_PERIOD_ID heading 'Conc|Time|Period' for 9999
col MIN_PROCESSES heading 'Min|Procs' for 9999
col MAX_PROCESSES heading 'Max|Procs' for 9999
col SLEEP_SECONDS heading 'Sleep|Seconds' for 999999
col SERVICE_PARAMETERS for a200

accept trgtQue char default ALL prompt 'Conc Mgr Short Que Name <ALL> : '

select B.CONCURRENT_QUEUE_NAME, B.USER_CONCURRENT_QUEUE_NAME, B.ENABLED_FLAG, A.MIN_PROCESSES, A.MAX_PROCESSES, A.SLEEP_SECONDS, A.SERVICE_PARAMETERS
--, A.QUEUE_APPLICATION_ID, A.CONCURRENT_QUEUE_ID, A.PERIOD_APPLICATION_ID, A.CONCURRENT_TIME_PERIOD_ID
--, A.FAILOVER_MIN, A.FAILOVER_MAX
from   FND_CONCURRENT_QUEUE_SIZE A , apps.FND_CONCURRENT_QUEUES_VL B
where  A.QUEUE_APPLICATION_ID = B.APPLICATION_ID
and    A.CONCURRENT_QUEUE_ID  = B.CONCURRENT_QUEUE_ID
and    B.ENABLED_FLAG = 'Y'
and   (upper(B.CONCURRENT_QUEUE_NAME) like '%&trgtQue%'  or upper('&trgtQue')  = 'ALL');
