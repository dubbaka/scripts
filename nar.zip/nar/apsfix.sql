set feed on
spool apsfix.log
REM -- Truncate all MRP_AD_% tables.
   truncate table MRP.MRP_AD_BOMS reuse storage;
   truncate table MRP.MRP_AD_CTO_ORDER_DEMAND reuse storage;
   truncate table MRP.MRP_AD_DEMAND reuse storage;
   truncate table MRP.MRP_AD_DEPT_RESS reuse storage;
   truncate table MRP.MRP_AD_DSCR_JOBS reuse storage;
   truncate table MRP.MRP_AD_FLOW_SCHDS reuse storage;
   truncate table MRP.MRP_AD_FORECAST_DATES reuse storage;
   truncate table MRP.MRP_AD_FORECAST_DSGN reuse storage;
   truncate table MRP.MRP_AD_INV_COMPS reuse storage;
   truncate table MRP.MRP_AD_MTRX_TMP reuse storage;
   truncate table MRP.MRP_AD_OH_QTYS reuse storage;
   truncate table MRP.MRP_AD_OPERATION_COMPONENTS reuse storage;
   truncate table MRP.MRP_AD_OPR_NETWORKS reuse storage;
   truncate table MRP.MRP_AD_OPR_RESS reuse storage;
   truncate table MRP.MRP_AD_OPR_RTNS reuse storage;
   truncate table MRP.MRP_AD_OPR_SEQS reuse storage;
   truncate table MRP.MRP_AD_ORDER_LINES_ALL reuse storage;
   truncate table MRP.MRP_AD_PROCESS_EFFECTIVITY reuse storage;
   truncate table MRP.MRP_AD_REPT_ITEM_DEMANDS reuse storage;
   truncate table MRP.MRP_AD_REPT_ITEM_SUPPLIES reuse storage;
   truncate table MRP.MRP_AD_REPT_SCHDS reuse storage;
   truncate table MRP.MRP_AD_RESOURCE_REQUIREMENTS reuse storage;
   truncate table MRP.MRP_AD_RES_CHNGS reuse storage;
   truncate table MRP.MRP_AD_SCHD_DATES reuse storage;
   truncate table MRP.MRP_AD_SI_CAPA reuse storage;
   truncate table MRP.MRP_AD_SUB_OPR_RESS reuse storage;
   truncate table MRP.MRP_AD_SUPPLY reuse storage;
   truncate table MRP.MRP_AD_U_DEMAND reuse storage;
   truncate table MRP.MRP_AD_U_SUPPLY reuse storage;
   truncate table MRP.MRP_AD_WIP_COMP_DEMANDS reuse storage;
   truncate table MRP.MRP_AD_WIP_COMP_SUPPLIES reuse storage;
   truncate table MRP.MRP_AD_WLINES reuse storage;
   truncate table MRP.MRP_AD_WOPRS reuse storage;
   truncate table MRP.MRP_AD_WOPR_RESS reuse storage;
   truncate table MRP.MRP_AD_WREQ_OPRS reuse storage;
REM -- Purge all snapshot logs. 

    PROMPT OE_ORDER_LINES_ALL
    execute dbms_snapshot.purge_log('ONT.OE_ORDER_LINES_ALL',9999);

    PROMPT MTL_DEMAND
    execute dbms_snapshot.purge_log('INV.MTL_DEMAND',9999);
    PROMPT MTL_SUPPLY
    execute dbms_snapshot.purge_log('INV.MTL_SUPPLY',9999);

    PROMPT MTL_ONHAND_QUANTITIES
    execute dbms_snapshot.purge_log('INV.MTL_ONHAND_QUANTITIES',9999);
    PROMPT MTL_MATERIAL_TRANSACTIONS_TEMP
    execute dbms_snapshot.purge_log('INV.MTL_MATERIAL_TRANSACTIONS_TEMP',9999);
    PROMPT MTL_SYSTEM_ITEMS_B
    execute dbms_snapshot.purge_log('INV.MTL_SYSTEM_ITEMS_B',9999);
    PROMPT MTL_USER_SUPPLY
    execute dbms_snapshot.purge_log('INV.MTL_USER_SUPPLY',9999);
    PROMPT MTL_USER_DEMAND
    execute dbms_snapshot.purge_log('INV.MTL_USER_DEMAND',9999);

    PROMPT PO_SUPPLIER_ITEM_CAPACITY
    execute dbms_snapshot.purge_log('PO.PO_SUPPLIER_ITEM_CAPACITY',9999);

    PROMPT MRP_Schedule_Dates
    execute dbms_snapshot.purge_log('MRP.MRP_Schedule_Dates',9999);
    PROMPT MRP_FORECAST_DESIGNATORS
    execute dbms_snapshot.purge_log('MRP.MRP_FORECAST_DESIGNATORS',9999);
    PROMPT MRP_FORECAST_DATES
    execute dbms_snapshot.purge_log('MRP.MRP_FORECAST_DATES',9999);
    PROMPT MRP_FORECAST_ITEMS
    execute dbms_snapshot.purge_log('MRP.MRP_FORECAST_ITEMS',9999);

    PROMPT WIP_DISCRETE_JOBS
    execute dbms_snapshot.purge_log('WIP.WIP_DISCRETE_JOBS',9999);
    PROMPT WIP_Flow_Schedules
    execute dbms_snapshot.purge_log('WIP.WIP_Flow_Schedules',9999);
    PROMPT WIP_REQUIREMENT_OPERATIONS
    execute dbms_snapshot.purge_log('WIP.WIP_REQUIREMENT_OPERATIONS',9999);
    PROMPT WIP_Repetitive_Schedules
    execute dbms_snapshot.purge_log('WIP.WIP_Repetitive_Schedules',9999);
    PROMPT WIP_Operations
    execute dbms_snapshot.purge_log('WIP.WIP_Operations',9999);
    PROMPT WIP_Lines
    execute dbms_snapshot.purge_log('WIP.WIP_Lines',9999);
    PROMPT WIP_Repetitive_Items
    execute dbms_snapshot.purge_log('WIP.WIP_Repetitive_Items',9999);

    PROMPT BOM_RESOURCE_CHANGES
    execute dbms_snapshot.purge_log('BOM.BOM_RESOURCE_CHANGES',9999);
    PROMPT BOM_Bill_Of_Materials
    execute dbms_snapshot.purge_log('BOM.BOM_Bill_Of_Materials',9999);
    PROMPT BOM_Inventory_Components
    execute dbms_snapshot.purge_log('BOM.BOM_Inventory_Components',9999);
    PROMPT BOM_Operational_Routings
    execute dbms_snapshot.purge_log('BOM.BOM_Operational_Routings',9999);
    PROMPT BOM_Operation_Sequences
    execute dbms_snapshot.purge_log('BOM.BOM_Operation_Sequences',9999);
    PROMPT BOM_Operation_Resources
    execute dbms_snapshot.purge_log('BOM.BOM_Operation_Resources',9999');
    PROMPT BOM_SUB_Operation_Resources
    execute dbms_snapshot.purge_log('BOM.BOM_SUB_Operation_Resources',9999);
    PROMPT BOM_OPERATION_NETWORKS
    execute dbms_snapshot.purge_log('BOM.BOM_OPERATION_NETWORKS',9999);
    PROMPT BOM_CTO_ORDER_DEMAND
    execute dbms_snapshot.purge_log('BOM.BOM_CTO_ORDER_DEMAND',9999);

    PROMPT MSC_DESIGNATORS
    execute dbms_snapshot.purge_log('MSC.MSC_DESIGNATORS',9999);
REM -- Truncate the MLOG$ tables

truncate table WIP.MLOG$_WIP_OPERATIONS;
truncate table BOM.MLOG$_BOM_RESOURCE_CHANGES;
truncate table INV.MLOG$_MTL_SYSTEM_ITEMS_B;
truncate table WIP.MLOG$_WIP_DISCRETE_JOBS;
truncate table ONT.MLOG$_OE_ORDER_LINES_ALL;
truncate table MRP.MLOG$_MRP_FORECAST_DATES;
truncate table WIP.MLOG$_WIP_REQUIREMENT_OPER;
truncate table MRP.MLOG$_MRP_FORECAST_ITEMS;
truncate table BOM.MLOG$_BOM_OPERATIONAL_ROUT;
truncate table WIP.MLOG$_WIP_FLOW_SCHEDULES;
truncate table INV.MLOG$_MTL_DEMAND;
truncate table BOM.MLOG$_BOM_OPERATION_SEQUEN;
truncate table MRP.MLOG$_MRP_FORECAST_DESIGNA;
truncate table WIP.MLOG$_WIP_REPETITIVE_SCHED;
truncate table WIP.MLOG$_WIP_LINES;
truncate table BOM.MLOG$_BOM_OPERATION_RESOUR;
truncate table BOM.MLOG$_BOM_SUB_OPERATION_RE;
truncate table WIP.MLOG$_WIP_REPETITIVE_ITEMS;
truncate table BOM.MLOG$_BOM_OPERATION_NETWOR;
truncate table BOM.MLOG$_BOM_CTO_ORDER_DEMAND;
truncate table INV.MLOG$_MTL_SUPPLY;
truncate table INV.MLOG$_MTL_MATERIAL_TRANSAC;
truncate table INV.MLOG$_MTL_USER_SUPPLY;
truncate table INV.MLOG$_MTL_USER_DEMAND;
truncate table PO.MLOG$_PO_SUPPLIER_ITEM_CAP;
truncate table MRP.MLOG$_MRP_SCHEDULE_DATES;
truncate table BOM.MLOG$_BOM_BILL_OF_MATERIAL;
truncate table BOM.MLOG$_BOM_INVENTORY_COMPON;
truncate table INV.MLOG$_MTL_ONHAND_QUANTITIE1;

REM -- Refresh all snapshots

SELECT MRP_AP_REFRESH_S.NEXTVAL FROM DUAL;
exec dbms_snapshot.refresh('WIP.WIP_WOPRS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_RES_CHNGS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('INV.MTL_SYS_ITEMS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('WIP.WIP_DSCR_JOBS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('ONT.OE_ODR_LINES_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('MRP.MRP_FORECAST_DATES_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('WIP.WIP_WREQ_OPRS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('MRP.MRP_FORECAST_ITEMS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_OPR_RTNS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('WIP.WIP_FLOW_SCHDS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('INV.MTL_DEMAND_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_OPR_SEQS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('MRP.MRP_FORECAST_DSGN_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('WIP.WIP_REPT_SCHDS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('WIP.WIP_WLINES_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_OPR_RESS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_SUB_OPR_RESS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('WIP.WIP_REPT_ITEMS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_OPR_NETWORKS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_CTO_ORDER_DMD_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('INV.MTL_SUPPLY_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('INV.MTL_MTRX_TMP_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('INV.MTL_U_SUPPLY_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('INV.MTL_U_DEMAND_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('PO.PO_SI_CAPA_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('MRP.MRP_SCHD_DATES_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_BOMS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('BOM.BOM_INV_COMPS_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('MSC.MSC_ATP_PLAN_SN' , 'COMPLETE');
exec dbms_snapshot.refresh('INV.MTL_OH_QTYS_SN' , 'COMPLETE');
spool off
