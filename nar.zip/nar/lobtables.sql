-- @lobtables.sql


clear columns breaks computes

set pages 1000 pau off feed on lines 250

col owner for a10
col TABLE_NAME for a30
col COLUMN_NAME for a30

spool spool\lobtables_&_MyDB1.
select unique OWNER, TABLE_NAME, COLUMN_NAME, SEGMENT_NAME, INDEX_NAME
from   dba_lobs
where  owner in ('VRN' , 'ARADMIN' , 'ARCUSTOM' , 'XXSTAGE0' , 'BELTECH' , 'VRNBR' , 'XXBEL' , 'XXREJECT');
spool off

clear columns breaks computes
