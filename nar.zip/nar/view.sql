set long 10000

col owner for a20
col VIEW_NAME for a30

select OWNER, VIEW_NAME, TEXT
from   DBA_VIEWS
where  VIEW_NAME = upper('&viewname')
order  by 1,2;
