-- @init_hidden.ora.sql


col "Parameter" for a45
col "Session Value" for a20
col "Instance Value" for a20

set lines 132

select a.ksppinm  "Parameter", b.ksppstvl "Session Value", c.ksppstvl "Instance Value"
from   x$ksppi a, x$ksppcv b, x$ksppsv c
where  a.indx = b.indx
and    a.indx = c.indx
and    substr(ksppinm,1,1) = '_'
and    upper(ksppinm) like upper('%&1%')
order by a.ksppinm;
