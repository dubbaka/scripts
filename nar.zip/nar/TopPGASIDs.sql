-- @TopPGASIDs.sql
-- Sessions using maximum PGA

clear computes breaks columns

col "PgaUsedMB" for 999,999,999.99
col "PgaAllocMB" for 999,999,999.99
col "PgaFreeableMB" for 999,999,999.99
col "PgaMaxMB" for 999,999,999.99
col username for a15
col sid for 99999

set pages 50 pau on

break on report
compute sum of "PgaUsedMB" "PgaAllocMB" "PgaFreeableMB" "PgaMaxMB" on report

accept trgtRows number default 20 prompt 'Rows to display <20> : '

Prompt Individual Session PGA usage
select * from
(select s.inst_id, s.sid, s.serial#, s.username, p.PGA_USED_MEM/(1024*1024) "PgaUsedMB"
     , p.PGA_ALLOC_MEM/(1024*1024) "PgaAllocMB", p.PGA_FREEABLE_MEM/(1024*1024) "PgaFreeableMB", p.PGA_MAX_MEM/(1024*1024) "PgaMaxMB"
from   gv$session s, gv$process p
where  s.inst_id = p.inst_id
and    p.addr = s.paddr
order  by p.PGA_USED_MEM desc)
where rownum <= &trgtRows;

clear computes breaks

Prompt Total PGA usage
select sum(p.PGA_USED_MEM/(1024*1024)) "PgaUsedMB", sum(p.PGA_ALLOC_MEM/(1024*1024)) "PgaAllocMB", sum(p.PGA_FREEABLE_MEM/(1024*1024)) "PgaFreeableMB", sum(p.PGA_MAX_MEM/(1024*1024)) "PgaMaxMB"
from   gv$process p;
