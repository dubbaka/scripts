col PROFILE_OPTION_NAME for a50
col profile_option_value for a100
select a.PROFILE_OPTION_ID,a.PROFILE_OPTION_NAME,b.profile_option_value
from   fnd_profile_options a, fnd_profile_option_values b
where  a.APPLICATION_ID      = b.APPLICATION_ID
and    a.PROFILE_OPTION_ID   = b.PROFILE_OPTION_ID
and    b.profile_option_value like '%&M%';