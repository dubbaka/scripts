set linesize 150
set pages 999
set echo off
set trimspool on
set feedback on
set termout on

COLUMN request_id              HEADING 'Request Id' FORM 9999999999 TRUNC
COLUMN concurrent_program_id   HEADING 'CP ID'    FORM 99999999    TRUNC
COLUMN concurrent_program_name HEADING 'CP Name'  FORM a30      TRUNC
COLUMN pgm_name                HEADING 'Program Name'  FORM a60 TRUNC
COLUMN sid                     HEADing 'Sid'      FORM 9999  
COLUMN user_name               HEADING 'App User' FORM a18       TRUNC
COLUMN runtime                 HEADING 'Minutes '    FORM 99990.9  TRUNC
COLUMN concurrent_queue_name   HEADING 'Queue  '  FORM a25      TRUNC
COLUMN node                    HEADing 'INST|ID'     FORM 9        TRUNC
COLUMN oracle_process_id       HEADing 'Pid'      FORM a10  
column inst_name               Heading 'Inst Name' FORM A10
col argument_text for a60
col RESUBMIT_INTERVAL_UNIT_CODE for a10
col RESUBMIT_INTERVAL_UNIT_CODE Head 'RESUBMIT|INTERVAL|UNIT_CODE'
col requested_start_date head 'Requested|Start|Date'

set lines 300

accept ReqID       number default 99          prompt 'Conc Request ID              <ALL> : '
accept ShrtConcPgm char   default ALL         prompt 'Conc Pgm ShortName           <ALL> : '
accept FullConcPgm char   default ALL         prompt 'Conc Pgm LongName            <ALL> : '

SELECT 
a.request_id,
       t.USER_CONCURRENT_PROGRAM_NAME pgm_name,
       d.user_name,a.hold_flag,
       (sysdate-a.actual_start_date)*24*60 runtime,
       DECODE(a.status_code,
       'A', 'Waiting',
       'B', 'Resuming',
       'C', 'Normal',
       'D', 'Cancelled' ,
       'E', 'Error' , 
       'F', 'Scheduled',
       'G', 'Warning', 
       'H','On Hold' , 
       'I', 'Normal',
       'T', 'Terminating', 
       'M', 'No Manager' ,
       'Q', 'Standby', 
       'S', 'Suspended',
       'T', 'Terminating',
       'U', 'Disabled',
       'W', 'Paused',
       'X', 'Terminated',
       'Z', 'Waiting', 
        status_code) status_code,a.resubmit_interval,a.RESUBMIT_INTERVAL_UNIT_CODE,a.requested_start_date,a.argument_text
FROM   apps.fnd_concurrent_requests a,
       apps.fnd_concurrent_programs b,
       apps.fnd_concurrent_programs_tl t,
       apps.fnd_user d
WHERE  
(a.REQUEST_ID = &ReqID or &ReqID = 99)
  and (b.concurrent_program_name = upper('&ShrtConcPgm') or '&ShrtConcPgm' = 'ALL')
  and (t.user_concurrent_program_name like '&FullConcPgm%' or '&FullConcPgm' = 'ALL')
  and a.phase_code = 'P' and
--and status_code<>'F'
    a.concurrent_program_id = b.concurrent_program_id
  AND  a.program_application_id = b.application_id
  AND  a.concurrent_program_id = t.concurrent_program_id
  AND  a.program_application_id = t.application_id
      AND  d.user_id = a.requested_by
  AND  t.source_lang='US'
  and status_code not in ('F','H')
  group by a.request_id,a.concurrent_program_id,t.USER_CONCURRENT_PROGRAM_NAME,d.user_name,a.hold_flag,
      (sysdate-a.actual_start_date)*24*60,
       a.status_code,  a.phase_code,a.hold_flag,a.resubmit_interval,a.argument_text,a.RESUBMIT_INTERVAL_UNIT_CODE,a.requested_start_date
ORDER BY  (sysdate-a.actual_start_date)*24*60 desc
/

--start pending
--start running

--start apsclear

