
set echo off;
set pagesize 1000
set line 132
col command format a8
col "sid#" format a6
col "SER#" format a5
col "COMMAND" format a10
col PROGRAM format a15
col CLNT_PROCESS format a5
col OSUSER format  a8
col DBUSER format a8
col Login format a20
select  substr(v$session.username,1,6) "DBUSER"
       ,substr(v$session.osuser,1,8)  "OSUSER"
       ,substr(v$session.sid,1,4)      "SID#"
       ,substr(v$session.serial#,1,6)  "SER#"
       ,substr(v$session.process,1,5)  "CLNT_PROCESS"
       ,substr(v$process.spid,1,5)     "SVR_PROCESS"
       ,decode (v$session.command
	       , 1, 'CREATE TABLE'
               , 2, 'INSERT'
	       , 3, 'SELECT'
	       , 4, 'CREATE CLUSTER'
	       , 5, 'ALTER CLUSTER'
	       , 6, 'UPDATE'
	       , 7, 'DELETE'
	       , 8, 'DROP'
	       , 9, 'CREATE INDEX'
	       ,10, 'DROP INDEX'
	       ,11, 'ALTER INDEX'
	       ,12, 'DROP TABLE'
	       ,15, 'ALTER TABLE'
	       ,17, 'GRANT'
	       ,18, 'REVOKE'
	       ,19, 'CREATE SYNONYM'
	       ,20, 'DROP SYNONYM'
	       ,21, 'CREATE VIEW'
	       ,22, 'DROP VIEW'
	       ,26, 'LOCK TABLE'
	       ,27, 'NO OPERATION'
	       ,28, 'RENAME'
	       ,29, 'COMMENT'
	       ,30, 'AUDIT'
	       ,31, 'NOAUDIT'
	       ,32, 'CREATE EXT D/B'
	       ,33, 'DROP EXT D/B'
	       ,34, 'CREATE DATABASE'
	       ,35, 'ALTER DATABASE'
	       ,36, 'CREATE R/B SEG'
	       ,37, 'ALTER R/B SEG'
	       ,38, 'DROP R/B SEG'
	       ,39, 'CREATE TBLSPACE'
	       ,40, 'ALTER TBLSPACE'
	       ,41, 'DROP TBLSPACE'
	       ,42, 'ALTER SESSION'
	       ,43, 'ALTER USER'
	       ,44, 'COMMIT'
	       ,45, 'ROLLBACK'
	       ,46, 'SAVEPOINT'
	       ,    '?'
	       )               "COMMAND",
       substr( v$session.program,1,15) "PROGRAM",
--       v$session.status   "STATUS",
       to_char(LOGON_TIME,'DD-MON-YYYY HH24:MI:SS') Login
from  v$session,v$process 
where v$session.serial# > 1
and v$session.paddr = v$process.addr
--and v$session.program like '%JDBC%'
--and status = 'ACTIVE'
order by LOGON_TIME asc;
--exit;

