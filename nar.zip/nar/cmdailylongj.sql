spool /local/dba/audit/CMLongJ.lst
@/export/home/oraes/scripts/sredmond/perfmon/cmdailylong 300
spool off
exit
