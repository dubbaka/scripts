-- @TopCpuSids.sql


col SID for 99999
col USERNAME for a15
col PROGRAM for a60
col WAIT_CLASS for a15
col OSUSER for a25
col MACHINE for a35

set pages 60 pau off veri off lines 300

select * from (
select ss.value CPU, ss.sid, se.serial#, se.username, se.status, se.SQL_ID, se.WAIT_CLASS, se.WAIT_TIME, se.program, se.LOCKWAIT, se.OSUSER, se.MACHINE, se.ACTION
from v$sesstat ss, v$session se
where ss.statistic# in (select statistic# from v$statname where name = 'CPU used by this session')
and se.sid=ss.sid
and ss.sid>6 --disregard background processes
order by CPU desc)
where rownum <= 50;
