col segment_name format a30 trunc
select * from (
select /*+ ordered */
   e.segment_type stype,
   e.segment_name,
   l.gets,
   l.misses,
   l.sleeps,
   l.child# chl
from dba_extents e,
   sys.x$bh x,
   sys.v_$latch_children l
where x.file# = e.file_id
and x.dbablk = e.block_id+1
and x.hladdr = l.addr
order by sleeps desc)
where rownum < 11;
