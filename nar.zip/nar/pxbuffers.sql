select * from v$px_process_sysstat
where statistic like 'Buffers%'
/


