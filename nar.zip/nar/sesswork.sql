/* sesswork.sql
     show the work performed by a session
*/
accept trgtsid number prompt 'What is the SID : '
select n.name,s.value from v$sesstat s, v$statname n
where sid = &trgtsid
and s.statistic# = n.statistic#
and s.value > 0
and n.name not in ('session connect time','process last non-idle time')
order by 2;

prompt Specific Buffer Cache Hit ratio values.....
select n.name,s.value from v$sesstat s, v$statname n
where sid = &trgtsid
and s.statistic# = n.statistic#
and n.name in ('consistent gets','db block gets','physical reads');

prompt Specific Sorting values.....
select n.name,s.value from v$sesstat s, v$statname n
where sid = &trgtsid
and s.statistic# = n.statistic#
and n.name like '%sort%';


