REM
REM        START OF SQL
REM 
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 80
col PLATFORM_CODE form a5
col HOST form a20
col DOMAIN form a30
col WEBHOST form a30
col VIRTUAL_IP form a20
col status form a20
col ConcMgr form a8
col Forms form a8
col WebServer form a8
col Admin form a8
col Database form a8
col last_monitored form a40
--
select 
	NODE_NAME,
	to_char(CREATION_DATE, 'DD-MON-RR HH24:MI') creation_date,
	PLATFORM_CODE,
	decode(STATUS,'Y','ACTIVE','INACTIVE') Status,
	decode(SUPPORT_CP,'Y', 'ConcMgr','No') ConcMgr,
	decode(SUPPORT_FORMS,'Y','Forms', 'No') Forms,
	decode(SUPPORT_WEB,'Y','Web', 'No') WebServer,
	decode(SUPPORT_ADMIN, 'Y','Admin', 'No') Admin,
	decode(SUPPORT_DB, 'Y','Rdbms', 'No') Database,
	to_char(LAST_MONITORED_TIME, 'DD-MON-RR HH24:MI:SS') last_monitored,
	NODE_MODE,
	SERVER_ADDRESS,
	HOST,
	DOMAIN,
	WEBHOST,
	VIRTUAL_IP,
	SERVER_ID
from fnd_nodes
where node_name != 'AUTHENTICATION'
/
REM 
REM        END OF SQL
REM 


REM
REM        START OF SQL
REM
REM  eBiz releases : 11.5.10 and 12.x
REM 
set serveroutput on size 1000000
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 80
DECLARE
	TYPE p_patch_array_type is varray(30) of varchar2(10);
	p_patchlist	p_patch_array_type;
	p_appltop_name	varchar2(50);
	p_patch_status	varchar2(15);
	p_appl_top_id	number;
	gvAbstract varchar2(240) := NULL;
	CURSOR alist IS
	  	select appl_top_id, name from ad_appl_tops;
	procedure println(msg in varchar2)
	is
	begin
		dbms_output.enable(1000000);
		dbms_output.put_line(msg);
	end;
BEGIN
	open alist;
	p_patchlist:= p_patch_array_type('5639951','5455628','5468797','5473858','4334965','4676589','6047864');
	LOOP
	FETCH alist INTO p_appl_top_id,p_appltop_name;
	EXIT WHEN alist%NOTFOUND;
	IF p_appltop_name NOT IN ('GLOBAL','*PRESEEDED*')
	THEN
		println(p_appltop_name || ':');
		for i in 1..p_patchlist.count
		loop
			begin
				select ABSTRACT into gvAbstract
				from FND_UMS_BUGFIXES
				where BUG_NUMBER = p_patchlist(i);
			exception 
			 	when NO_DATA_FOUND then
					gvAbstract := NULL;
			end;
			p_patch_status := ad_patch.is_patch_applied('11i',p_appl_top_id,p_patchlist(i));
			println('..Patch ' || p_patchlist(i)|| ' ' || substr(gvAbstract,1,25) || ' was ' || p_patch_status);
		end loop;
	END if;
	println('.');
	END LOOP;
	close alist;
END;
/
REM 
REM        END OF SQL
REM 


REM
REM START OF SQL
REM
set echo on
set timing on
set feedback on
set long 10000
set linesize 120
set pagesize 132
column SHORT_NAME format A30
column NAME format A40
column LEVEL_SET format a15
column CONTEXT format a30
column VALUE format A60 wrap
  select p.profile_option_name SHORT_NAME, 
	 n.user_profile_option_name NAME, 
         decode(v.level_id, 
		10001, 'Site', 
		10002, 'Application',
		10003, 'Responsibility',
		10004, 'User',
		10005, 'Server',
		10007, 'SERVRESP',
	'UnDef') LEVEL_SET,
	decode(to_char(v.level_id),
		'10001', '',
	        '10002', app.application_short_name,
	        '10003', rsp.responsibility_key,
	        '10005', svr.node_name,
	        '10006', org.name,
	        '10004', usr.user_name,
	        '10007', 'Serv/resp',
                'UnDef') "CONTEXT",
	v.profile_option_value VALUE
  from fnd_profile_options p, 
     fnd_profile_option_values v, 
     fnd_profile_options_tl n,
     fnd_user usr,
     fnd_application app,
     fnd_responsibility rsp,
     fnd_nodes svr,
     hr_operating_units org
  where p.profile_option_id = v.profile_option_id (+)
  and p.profile_option_name = n.profile_option_name
  and p.profile_option_name in ('FND_CACHE_PORT_RANGE','JTF_DIST_CACHE_PORT','FLEXFIELDS:USE_JAVA_CACHE')
  and    usr.user_id (+) = v.level_value
  and    rsp.application_id (+) = v.level_value_application_id
  and    rsp.responsibility_id (+) = v.level_value
  and    app.application_id (+) = v.level_value
  and    svr.node_id (+) = v.level_value
  and    org.organization_id (+) = v.level_value
  order by short_name, level_set;
REM
REM END OF SQL
REM



REM
REM        START OF SQL
REM
set echo on
set timing on
set feedback on
set pagesize 132
set linesize 100
col name form a30
col queue_table form a30
col enqueue_enabled form a7
col dequeue_enabled form a7
col retention form a20
--
select name,
	queue_table,
	enqueue_enabled,
	dequeue_enabled,
	retention
from dba_queues
where owner = 'APPLSYS'
and queue_type = 'NORMAL_QUEUE'
order by 1
/
--
set pagesize 132
set linesize 90
col COMPONENT_NAME form a50
col COMPONENT_STATUS form a15
col COMPONENT_TYPE form a25
col STARTUP_MODE form a10
col CONTAINER_TYPE form a5
col INBOUND_AGENT_NAME form a20
col OUTBOUND_AGENT_NAME form a20
col CORRELATION_ID form a30
col MAX_IDLE_TIME form 9999999
rem
select
	COMPONENT_NAME,
	COMPONENT_STATUS,
	COMPONENT_TYPE,
	STARTUP_MODE,
	CONTAINER_TYPE,
	INBOUND_AGENT_NAME,
	OUTBOUND_AGENT_NAME,
	CORRELATION_ID,
	MAX_IDLE_TIME
from 	FND_SVC_COMPONENTS
order by COMPONENT_NAME
/
REM
REM        END OF SQL
REM



REM
REM START OF SQL
REM
REM List events related to Apps 11i Java Caching
REM
set echo on
set feedback on
set pagesize 132
set linesize 100
col name form a60
col stat form a8
col evt.licensed_flag form a1
col generate_function form a65
col ecl form a6
col sub_stat form a8
col sub_lic form a1
col sub_cl form a6
col rule_function form a45
col source_type form a8
--
select  evt.name,
        evt.type,
		evt.status stat,
		evt.licensed_flag,
		evt.generate_function,
        evt.java_generate_func,
		sub.STATUS sub_stat,
		sub.LICENSED_FLAG sub_lic,
		sub.SOURCE_TYPE source_type,
        sub.phase,
        sub.description,
        sub.rule_function rule_function,
        sub.java_rule_func
from wf_events evt, wf_event_subscriptions sub
where evt.guid = sub.event_filter_guid
and evt.name = 'oracle.apps.fnd.bes.control.group'
order by evt.name,evt.type, sub.source_type desc
/
--
-- check which events registered to bes.control.group
--
select name, status
from   wf_events
where  guid in (select member_guid
                from   wf_event_groups
                where  group_guid =
                   (select guid
                    from   wf_events
                    where name = 'oracle.apps.fnd.bes.control.group'))
order by 2,1
/
REM 
REM        END OF SQL
REM 



REM
REM        START OF SQL
REM
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 90
col APPLICATION_ID form 9999999
col COMP_NAME form a40
col COMPONENT_KEY form a40
col LOADER_CLASS_NAME form a60
col BUSINESS_EVENT_NAME form a80
col HOSTNAME form a50
REM
REM  Collect information about the registered nodes
SELECT B.HOSTNAME,
      decode(B.LOAD_PICK_UP_FLAG,'t','TRUE','FALSE') load_pickup_flag,
      decode(B.PREFAB_ENABLED_FLAG,'t','TRUE','FALSE') prefab_enabled_flag,
      B.CACHE_SIZE, 
      B.WSH_TYPE,
      T.DESCRIPTION,
      B.WEIGHT,
      to_char(B.LAST_UPDATE_DATE,'DD-MON-RR HH24:MI') last_update_date
from JTF_PREFAB_WSH_POES_TL T, JTF_PREFAB_WSH_POES_B B
WHERE B.WSH_PO_ID = T.WSH_PO_ID (+)
order by B.HOSTNAME
/
REM
REM Information about the cache component items
REM
select
 COMP_NAME,
 COMPONENT_KEY,
 LOADER_CLASS_NAME,
 decode(TIMEOUT_TYPE,'it','IdleTime','ttl','TimeToLive','unknown') timeout_type,
 TIMEOUT,
 TIMEOUT_UNIT,
 APPLICATION_ID,
 decode(SGID_ENABLED_FLAG,'t','TRUE','FALSE') SGID_ENABLED,
 decode(DISTRIBUTED_FLAG,'t','TRUE','FALSE') Distributed,
 BUSINESS_EVENT_NAME
from JTF_PREFAB_CA_COMPS_B
order by APPLICATION_ID,COMP_NAME
/
REM 
REM        END OF SQL
REM 



REM
REM        START OF SQL
REM
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 100
col CONCURRENT_QUEUE_NAME form a20
col USER_CONCURRENT_QUEUE_NAME form a35
col MIN_PROCESSES form 9999
col MAX_PROCESSES form 9999
col SLEEP_SECONDS form 9999
col SERVICE_PARAMETERS form a95
--
select
	FCQ.CONCURRENT_QUEUE_NAME,
	FCQ.USER_CONCURRENT_QUEUE_NAME,
	FCQS.MIN_PROCESSES,
	FCQS.MAX_PROCESSES,
	FCQS.SLEEP_SECONDS,
	FCQS.SERVICE_PARAMETERS
from FND_CONCURRENT_QUEUE_SIZE FCQS, FND_CONCURRENT_QUEUES_TL FCQ
where FCQS.CONCURRENT_QUEUE_ID = FCQ.CONCURRENT_QUEUE_ID
and FCQ.CONCURRENT_QUEUE_NAME like 'WF%'
order by 1
/
REM
set linesize 110
col COMPONENT_NAME form a40
col COMPONENT_STATUS form a8
col parameter_name form a30
col parameter_value form a25
--
select c.COMPONENT_NAME,
       c.COMPONENT_STATUS,
       p.parameter_name,
       v.parameter_value
from   FND_SVC_COMP_PARAM_VALS v,
       fnd_svc_comp_params_b p,
       fnd_svc_components c
where  v.component_id = c.component_id
and    v.parameter_id = p.parameter_id
and    upper(c.COMPONENT_NAME) like upper('Workflow Java Deferred Agent Listener')
order by 1,3
/
REM
REM        END OF SQL
REM



REM
REM        START OF SQL
REM
REM Check entries for WF_JAVA_DEFERRED, WF_JAVA_ERROR and WF_CONTROL queues
REM
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 105
col queue_name form a17
col state form a15
col how_many form 9999999999
--
select
'wf_java_deferred' queue_name,
decode(state,
	0,'0 (Ready)',
	1,'1 (Delayed)',
	2, '2 (Retained)',
	3, '3 (Exception)',
	to_char(state|| ' (Other)'))  state,
count(*) how_Many
from wf_java_deferred
group by state
UNION ALL
select
'wf_java_error' queue_name,
decode(state,
	0,'0 (Ready)',
	1,'1 (Delayed)',
	2, '2 (Retained)',
	3, '3 (Exception)',
	to_char(state|| ' (Other)'))  state,
count(*) how_Many
from wf_java_error
group by state
UNION ALL
select
'wf_control' queue_name,
decode(state,
	0,'0 (Ready)',
	1,'1 (Delayed)',
	2, '2 (Retained)',
	3, '3 (Exception)',
	to_char(state|| ' (Other)'))  state,
count(*) how_Many
from wf_control
group by state
/
REM
REM  Check the difference between enqueue and dequeue time.
REM 
REM This script queries the last 24 hours.   
REM 
col corr_id form a60
col retry_count form 999
col msg_state form a12
col enq_time form a18
col deq_time form a18
col Elapsed_Sec form 999999999
select  'wf_java_deferred' queue_name,
	retry_count retrys,
	msg_state,
	to_char (a.enq_time, 'DD-MON-RR HH24:MI:SS') enq_time,
	to_char (a.deq_time, 'DD-MON-RR HH24:MI:SS') deq_time,
	to_char ((nvl (a.deq_time, sysdate) - a.enq_time) * 24*60*60, '999999.99') Elapsed_Sec,
	corr_id
from applsys.aq$wf_java_deferred a
where a.enq_time >= sysdate - (24/24)  -- arbitrary 24 hours
UNION ALL
select  'wf_java_error' queue_name,
	retry_count retrys,
	msg_state,
	to_char (a.enq_time, 'DD-MON-RR HH24:MI:SS') enq_time,
	to_char (a.deq_time, 'DD-MON-RR HH24:MI:SS') deq_time,
	to_char ((nvl (a.deq_time, sysdate) - a.enq_time) * 24*60*60, '999999.99') Elapsed_Sec,
	corr_id
from applsys.aq$wf_java_error a
where a.enq_time >= sysdate - (24/24)  -- arbitrary 24 hours
UNION ALL
select  'wf_control' queue_name,
	retry_count retrys,
	msg_state,
	to_char (a.enq_time, 'DD-MON-RR HH24:MI:SS') enq_time,
	to_char (a.deq_time, 'DD-MON-RR HH24:MI:SS') deq_time,
	to_char ((nvl (a.deq_time, sysdate) - a.enq_time) * 24*60*60, '999999.99') Elapsed_Sec,
	corr_id	
from applsys.aq$wf_control a
where a.enq_time >= sysdate - (24/24)  -- arbitrary 24 hours
order by 5,6,7
/
REM
REM        END OF SQL
REM


REM
REM        START OF SQL
REM
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 100
col time_stamp form a17
col user_name form a12
col log_level form a10
col module form a57 wrap
col message_text form a98 wrap
col session_id form 999999999999
REM
REM Show all messages for the last 1 hour 
REM 
select  to_char(m.timestamp, 'DD-MM-RR HH24:MI:SS') time_stamp,
        u.user_name, 
        l.meaning log_level,
	m.module, 
	m.message_text
from fnd_log_messages m, fnd_user u, fnd_lookup_values l
where m.user_id = u.user_id
and l.lookup_type = 'AFLOG_LEVELS'
and l.lookup_code = m.log_level
and m.timestamp >= sysdate - (1/24) -- arbitary show all messages for last 1 hour
order by m.timestamp, m.log_sequence
/
REM 
REM        END OF SQL
REM

REM
REM        START OF SQL
REM
set echo on
set timing on
set feedback on
set long 10000
set pagesize 1000
set linesize 120
col CORR_ID form a45
col MSG_STATE form a13
col ENQ_TIME form a18
col DEQ_TIME form a18
col RETRY_COUNT form 99999
col EXPIRATION_REASON form a19
col USER_DATA form a10000
REM
select 
	CORR_ID,
	MSG_STATE,
	to_char(ENQ_TIME,'DD-MON-RR HH24:MI:SS') enq_time,
	to_char(DEQ_TIME,'DD-MON-RR HH24:MI:SS') deq_time,
	RETRY_COUNT,
	EXPIRATION_REASON,
	USER_DATA
from applsys.aq$wf_java_deferred 
order by ENQ_TIME, DEQ_TIME
/
REM 
REM        END OF SQL
REM
