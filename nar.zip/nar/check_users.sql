select username, count(*) from v$session where username in ('GEPSPEGARDB',
'GECS',
'Noetix_521',
'GEPS',
'GEPSREADONLY',
'GEPSWM',
'WEBMETHODS',
'GEPSO2S',
'NOETIX_51',
'GEPSREP',
'GEPSGL',
'GEPSGLPMO',
'GEPSHANDHELD')
group by username;
