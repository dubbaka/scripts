select tablespace_name,contents,extent_management,initial_extent,next_extent from dba_tablespaces where tablespace_name like 'TEMP%'
/
col file_name format a45 trunc
col mbavail format 99999.90
col mbused format 99999.90 
col db_block_size format a15 trunc
select a.file_name, 
	a.bytes/1024/1024 mbavail,
             ((nvl(b.blocks_used,1)*c.db_block_size) + c.db_block_size)/1024/1024 mbused,
             lpad(c.db_block_size,15)
        from dba_temp_files a, v$temp_space_header b,
             (select value db_block_size
                from v$parameter
               where name='db_block_size') c
       where a.tablespace_name = 'TEMP'
         and a.file_id = b.file_id(+)
       order by a.file_name;

