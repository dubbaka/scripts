/* cklibcache.sql
     check for high number of versions of a given statement (hash value)
*/
select hash_value,version_count from v$sqlarea where version_count > 500;

