spool Aug_scm1

prompt material_transactions

select count(1),to_char(transaction_date,'MON-yyyy') duration from apps.mtl_material_transactions where transaction_Date > sysdate-365 group by to_char(transaction_date,'MON-yyyy');

Prompt po_requisition_headers_all

select count(1),to_char(creation_date,'MON-yyyy') duration from apps.po_requisition_headers_all where creation_Date > sysdate-365 group by to_char(creation_date,'MON-yyyy');

prompt oe_order_headers_all

select count(1),to_char(creation_Date,'MON-yyyy') duration from apps.oe_order_headers_all where creation_Date > sysdate-365 group by to_char(creation_Date,'MON-yyyy');

prompt po_headers_all
select count(1),to_char(creation_date,'MON-yyyy') duration from apps.po_headers_all where creation_Date > sysdate-365 group by to_char(creation_date,'MON-yyyy');


spool off

