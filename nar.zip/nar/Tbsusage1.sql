-- @tbsusage.sql

clear breaks columns compute

col file_name format a50
col "File" for a60
col "Tablespace" format a12
col  TS# for 9999
col  FILE# for 9999
col  BLOCKS for 9,999,999
col  USER_BLOCKS for 9,999,999
col  "BlockSize" for a4 head "Blk|Size"
col  AUX_NAME for a30
col  AUTOEXTENSIBLE heading 'AUTO|Y/N' for a4
col "JustDir"  for a30
col "JustFile" for a20
col "MntPoint" for a8
col "Tablespace" for a15
col "CreatedOn" for a20
col "LastTime" for a16
col "CreatedSize(MB)" for 999,999 heading "Created|Size|(MB)" 
col "Bytes(MB)" for 9999,999
col "Used(MB)" for 9999,999
col "Free(MB)" for 999,999
col "MaxBytes(MB)" for 999,999
col "UserBytes(MB)" for 999,999
col "Required(MB)" for 999,999
col "AvlblGrowth(MB)" for 9,999,999 head "Can|GrowTo(MB)"
col "WillGrowTo(MB)" for 999,999 head "Will|Grow|To(MB)"
col "%Used" for 999.99
col "%Free" for 999.99
col INCREMENT_BY for 999,999,999
col INITIAL_EXTENT for 999,999,999 head "InitXtent"
col NEXT_EXTENT for 999,999,999 head "NextXtent"
col MIN_EXTENTS for 999 head "Min|Xtents"
col MAX_EXTENTS for 9,999,999,999 head "MaxXtents"
col INCREMENT_BY for 999,999 head "Increment|By"
col PCT_INCREASE head "Pct|Increase"
col EXTENT_MANAGEMENT head "Extent|Management"
col ALLOCATION_TYPE head "Allocation|Type"
col SEGMENT_SPACE_MANAGEMENT head "Segment|Space|Management"

break on report

set verify off lines 900 pau on pages 110

accept Tablespace char default NONE prompt 'Tablespace <ALL>: '

SELECT  dts.tablespace_name "Tablespace"
      , NVL(ddf.bytes/(1024*1024), 0) "Bytes(MB)"
      , NVL(ddf.bytes-NVL(dfs.bytes,0),0)/(1024*1024) "Used(MB)"
      , NVL(dfs.bytes/(1024*1024), 0) "Free(MB)"
      , (NVL(ddf.bytes,0)-NVL(dfs.bytes,0))/NVL(ddf.bytes,0)*100 "%Used"
      , NVL(dfs.bytes,0)/NVL(ddf.bytes,0)*100 "%Free"
      , decode(sign((NVL(ddf.bytes-NVL(dfs.bytes,0),0)/(1024*1024))/0.85-NVL(ddf.bytes/(1024*1024),0)),-1,0,(NVL(ddf.bytes-NVL(dfs.bytes,0),0)/(1024*1024))/0.85-NVL(ddf.bytes/(1024*1024),0)) "Required(MB)"
      , (BLOCK_SIZE/1024)||'K' "BlockSize", INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, STATUS, LOGGING, EXTENT_MANAGEMENT, ALLOCATION_TYPE, SEGMENT_SPACE_MANAGEMENT
FROM    dba_tablespaces dts, 
       (select tablespace_name, sum(bytes) bytes from dba_data_files group by tablespace_name) ddf, 
       (select tablespace_name, sum(bytes) bytes from dba_free_space group by tablespace_name) dfs 
WHERE  dts.tablespace_name = ddf.tablespace_name(+) 
AND    dts.tablespace_name = dfs.tablespace_name(+) 
and    dts.tablespace_name = upper('&Tablespace');


select TABLESPACE_NAME "Tablespace", sum(BYTES/(1024*1024)) "Bytes(MB)", sum(MAXBYTES/(1024*1024)) "MaxBytes(MB)"
     , (sum(MAXBYTES/(1024*1024))-sum(BYTES/(1024*1024))) "Free(MB)"
     , (sum(BYTES/(1024*1024))/sum(MAXBYTES/(1024*1024)))*100 "%Used"
     , (sum(MAXBYTES/(1024*1024))-sum(BYTES/(1024*1024)))*100/sum(MAXBYTES/(1024*1024)) "%Free"
from   dba_data_files
where  TABLESPACE_NAME = upper('&Tablespace')
group  by TABLESPACE_NAME;


compute sum of "Bytes(MB)" "Avlbl(MB)" "MaxBytes(MB)" "Free(MB)" "Used(MB)" "AvlblGrowth(MB)" "CreatedSize(MB)" on report
select b.inst_id, A.FILE_ID "FILE#"
--     , replace(substr(substr(FILE_NAME, instr(FILE_NAME,'/',2,1)+1, instr(FILE_NAME,'/',1,2)), 0, instr(substr(FILE_NAME, instr(FILE_NAME,'/',2,1)+1, instr(FILE_NAME,'/',1,2)),'/',-1)),'/','') "MntPoint"
     , substr(A.FILE_NAME, 1, instr(A.FILE_NAME,'/',1,2)-1) "MntPoint"
     , A.TABLESPACE_NAME "Tablespace" , A.FILE_NAME "File" , A.AUTOEXTENSIBLE
     , A.BYTES/(1024*1024) "Bytes(MB)", decode(A.MAXBYTES,0,A.BYTES,A.MAXBYTES)/(1024*1024) "MaxBytes(MB)"
     ,(decode(A.MAXBYTES,0,A.BYTES,A.MAXBYTES)/(1024*1024) - A.BYTES/(1024*1024)) "AvlblGrowth(MB)"
     ,(A.BYTES/decode(A.MAXBYTES,0,A.BYTES,A.MAXBYTES))*100 "%Used"
     ,(decode(A.MAXBYTES,0,A.BYTES,A.MAXBYTES)-A.BYTES)*100/decode(A.MAXBYTES,0,A.BYTES,A.MAXBYTES) "%Free"
     ,A.INCREMENT_BY
     ,to_char(B.CREATION_TIME,'dd-Mon-YYYY hh24:mi:ss') "CreatedOn", B.CREATE_BYTES/(1024*1024) "CreatedSize(MB)", A.STATUS, B.ENABLED
from   dba_data_files A , gV$DATAFILE B
where  A.TABLESPACE_NAME = upper('&Tablespace')
and    B.FILE# = A.FILE_ID
order  by A.FILE_NAME;
