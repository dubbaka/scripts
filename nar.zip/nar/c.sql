set linesize 260
set pages 999
set echo off
set trimspool on
set feedback on
set termout on

COLUMN request_id              HEADING 'Request Id' FORM 99999999 TRUNC
COLUMN concurrent_program_id   HEADING 'CP ID'    FORM 99999999    TRUNC
COLUMN concurrent_program_name HEADING 'CP Name'  FORM a40      TRUNC
COLUMN pgm_name                HEADING 'Program Name'  FORM a40 TRUNC
COLUMN sid                     HEADing 'Sid'      FORM 9999  
COLUMN user_name               HEADING 'App User' FORM a18       TRUNC
COLUMN runtime                 HEADING 'Minutes '    FORM 99990.9  TRUNC
COLUMN concurrent_queue_name   HEADING 'Queue  '  FORM a25      TRUNC
COLUMN node                    HEADing 'INST|ID'     FORM 9        TRUNC
COLUMN pid                     HEADing 'Pid'      FORM a8
COLUMN LOGFILE_NODE_NAME       HEADING 'Node' form a15
column oracle_process_id for 99999
def aps_prog    = 'c.sql'
def aps_title   = 'Concurrent Manager Process Information'

start apstitle

SELECT a.request_id,
       a.concurrent_program_id,
       t.USER_CONCURRENT_PROGRAM_NAME pgm_name,
       a.oracle_process_id pid,
       d.user_name,
       (sysdate-a.actual_start_date)*24*60 runtime,
       a.status_code,
       a.phase_code,
       a.LOGFILE_NODE_NAME
FROM   apps.fnd_concurrent_requests a,
       apps.fnd_concurrent_programs b,
       apps.fnd_concurrent_programs_tl t,
       apps.fnd_concurrent_processes c,
       apps.fnd_user d
WHERE  a.phase_code = 'R'
  AND  a.concurrent_program_id = b.concurrent_program_id
  AND  a.program_application_id = b.application_id
  AND  a.concurrent_program_id = t.concurrent_program_id
  AND  a.program_application_id = t.application_id
  AND  c.concurrent_process_id = a.controlling_manager
  AND  d.user_id = a.requested_by
  AND  t.source_lang='US'
group by a.request_id,a.concurrent_program_id,t.USER_CONCURRENT_PROGRAM_NAME,a.oracle_process_id,d.user_name,
      (sysdate-a.actual_start_date)*24*60,
       a.status_code,  a.phase_code,       a.LOGFILE_NODE_NAME
ORDER BY  (sysdate-a.actual_start_date)*24*60 desc
/

--start pending
--start running

start apsclear

