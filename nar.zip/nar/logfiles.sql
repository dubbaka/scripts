-- @logfiles.sql


col group# for 9999
col "redolog" for a60
col STATUS for a8
col "Bytes" for 9,999
col "SeqNum" for 999999
col archived head "Arch|ived" for a4
col FIRST_CHANGE# for 99999999999999
col "FirstTime" for a16

set lines 200

select log.group#, lf.member "redolog", log.STATUS, lf.TYPE, log.bytes/(1024*1024) "MBytes", log.sequence# "SeqNum"
     , log.archived "Archived", log.FIRST_CHANGE#, to_char(log.first_time, 'DDMonYY hh24:mi:ss') "FirstTime"
from   v$logfile lf , v$log log
where  lf.group# = log.group#
order  by lf.group#;
