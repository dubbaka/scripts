REM Script to determine "active users" for OACoreGroup
REM http://blogs.oracle.com/schan/newsItems/departments/optimizingPerformance/2006/08/01#a494

REM
REM SQL to count number of Apps 11i users
REM Run as APPS user
REM

select 'Number of user sessions : ' || count( distinct session_id) How_many_user_sessions
from    icx.icx_sessions icx
where   disabled_flag != 'Y'
and     PSEUDO_FLAG = 'N'
and    (last_connect + decode(FND_PROFILE.VALUE('ICX_SESSION_TIMEOUT'), NULL,limit_time, 0,limit_time,FND_PROFILE.VALUE('ICX_SESSION_TIMEOUT')/60)/24) > sysdate   
and     counter < limit_connects;

REM
REM END OF SQL
REM
