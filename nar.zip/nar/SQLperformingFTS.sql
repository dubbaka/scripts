-- @SQLperformingFTS.sql


clear columns breaks computes

set feed off
col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDMonYYYY') "datenow" from dual;
set feed on

set veri off lines 300 pages 1000

break on hash_value skip 1 dup
col child_number format 9999    heading 'CHILD'
col operation    format a75
col cost         format 99,999,999
col kbytes       format 9,999,999
col object       format a30

--spool spool\SQLperformingFTS_&_MyDateNow._&_MyDB1.

select hash_value, child_number, lpad(' ',2*depth)||operation||' '||options||decode(id, 0, substr(optimizer,1,6)||' Cost='||to_char(cost)) operation
     , object_name object, cost, cardinality, round(bytes/1024) kbytes
from   v$sql_plan vsp
where  vsp.hash_value in (select a.sql_hash_value from v$session a, v$session_wait b where a.sid = b.sid and b.event = 'db file scattered read')
order  by vsp.hash_value, vsp.child_number, vsp.id;

--spool off
