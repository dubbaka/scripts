set lines 132

col tablespace_name format a10 trunc
col segment_name format a30
col owner format a10 trunc
col spacedeficit format 9,999.0 head MB_Short
col maxccontig format 9,999.0 head MaxContig_MB
col nextextmb format 9,999.0 head NextExt_MB
col tstotfree format 99,999.0 head TSFree_MB
  select  seg.tablespace_name
          ,free.totfree/1024/1024 tstotfree
          ,(seg.next_extent - free.maxchunk)/1024/1024 spacedeficit
          ,free.maxchunk/1024/1024 maxcontig
          ,seg.owner
          ,seg.segment_name
          ,seg.segment_type
          ,seg.next_extent/1024/1024 nxtextmb
  from    dba_segments seg
          ,(select tablespace_name, max(bytes) maxchunk,
                   sum(bytes) totfree
            from   dba_free_space
            group  by tablespace_name) free
  where   seg.tablespace_name = free.tablespace_name
  and     seg.next_extent     > free.maxchunk
  and     seg.tablespace_name not like 'TEMP%'
  order   by tablespace_name,owner,segment_type,segment_name;


