-- @TopSessionStat.sql

REM time_waited is in centiseconds (1/100th of a second)
REM 1Hr = 60 mins = 3,600 secs = 3,60,000 centiseconds

clear columns breaks computes

col inst_id    for 9999 head "Inst|Id"
col SID        for 99999
col logontime  for a15
col LastCallET for a11 head "LastCallEt|(hh:mi:ss)"
col USERNAME   for a15 trunc
COL MACHINE    for a15 trunc
col module     for a15 trunc
col program    for a50 trunc
col wait_class for a15 trunc
col "WaitNameShrt"       for a30 trunc
col NAME       for a60

set verify off lines 350 pages 50

accept trgtRows number default 20 prompt 'Rows to display <20> : '
prompt Class = Administrative | Application | Cluster | Commit | Concurrency | Configuration | Idle | Network | Other | System | User
accept trgtClass char default ALL prompt 'WaitClass <ALL> : '
accept trgtsid   number default 0 prompt 'SID <ALL>   : '
accept trgtEvent char default ALL prompt 'Event <ALL> : '

PROMPT Please note that IDLE wait events are filtered out and will never be displayed by this SQL
select * from (
select a.inst_id, a.SID, a.value, s.wait_class, b.NAME "WaitNameShrt"
     , to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime, floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
     , s.SQL_ID, s.username, s.STATUS, s.MACHINE, s.module, s.program, B.NAME
from  gv$sesstat a, gV$STATNAME b, gv$session s
where s.wait_class != 'Idle'
and   a.inst_id = b.inst_id
and   a.inst_id = s.inst_id
and  (a.sid = &trgtsid or &trgtsid = 0)
and  (upper(s.WAIT_CLASS)  like upper('&trgtClass%') or '&trgtClass' = 'ALL')
and  (upper(b.NAME)  like upper('%&trgtEvent%') or '&trgtEvent' = 'ALL')
and   s.sid = a.sid
and   b.STATISTIC# = a.STATISTIC#
order by a.value desc)
where rownum <= &trgtRows;
