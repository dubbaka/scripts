-- @bug.sql     Check if an Oracle EBS patch is installed


clear columns breaks compute
set pau off lines 2000 trimspool on trim on

col PATCH_NAME for a10 head "Patch|Number"
col PATCH_TYPE for a10
col SOURCE_CODE for a6 head "Source|Code"
col "CreationDate" for a21 head "Patch Applied On"
col "LastModified" for a21
col RAPID_INSTALLED_FLAG for a6 head "Rapid|Install|Flag"
col DATA_MODEL_DONE_FLAG for a5 head "Data|Model|Done|Flag"
col MAINT_PACK_LEVEL for a16
col IMPORTED_FLAG for a8 head "Imported|Flag"
col APPLICATION_SHORT_NAME for a5 head "Appln|Short|Name"
col BUG_NUMBER for a9 head "Bug|Number"
col ARU_RELEASE_NAME for a5 head "ARU|Rls|Name"
col BUG_STATUS for a10
col SUCCESS_FLAG for a8 head "Success?"


select APPLIED_PATCH_ID, PATCH_NAME, to_char(CREATION_DATE, 'dd-Mon-yy hh:mi:ss AM') "CreationDate", CREATED_BY, 
       PATCH_TYPE, RAPID_INSTALLED_FLAG, MAINT_PACK_LEVEL, SOURCE_CODE, to_char(LAST_UPDATE_DATE, 'dd-Mon-yy hh:mi:ss AM') "LastModified", LAST_UPDATED_BY,
       IMPORTED_FLAG, IMPORTED_FROM_DB, IMPORTED_ID, to_char(MERGE_DATE, 'dd-Mon-yy hh:mi:ss AM') "MergeDate", DATA_MODEL_DONE_FLAG
from   ad_applied_patches
--where  PATCH_NAME = '&&PCHNUM';


undefine PCHNUM
clear columns breaks compute
