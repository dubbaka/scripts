/* iowaitsdf.sql
     see the top 10 current io waits by datafile */
col waitcnt format 9999 head Waits
col dprcnt format 9999 head DPRds
col fsmtpt format a6 head MtPt
col fname format a35 head FileName 
col dprcnt format 9999 head DPRds
col dprlob format 9999 head DPR-LOBs
col dpwcnt format 9999 head DPWrts
col dpwlob format 9999 head DPW-LOBs
col idxcnt format 9999 head IDXScans
col ftscnt format 9999 head FTScans
break on report
compute sum of waitcnt on report
compute sum of dprcnt on report
compute sum of dpwcnt on report
compute sum of dprlob on report
compute sum of dpwlob on report
compute sum of idxcnt on report
compute sum of ftscnt on report         
select * from (
select count(*) waitcnt,
substr(f.name,8,(instr(f.name,'/',9,1) -8)) fsmtpt,
substr(f.name,(instr(f.name,'/',-1,1)+1)) || ' (' || f.file# || ')' fname,  
sum(decode(w.event,'direct path read',1,0)) dprcnt,
sum(decode(w.event,'direct path write',1,0)) dpwcnt,
sum(decode(w.event,'direct path read (lob) ',1,0)) dprlob,
sum(decode(w.event,'direct path write (lob)',1,0)) dpwlob,
sum(decode(w.event,'db file sequential read',1,0)) idxcnt,
sum(decode(w.event,'db file scattered read',1,0)) ftscnt
from v$session_wait w, v$datafile f
 where w.event in ('direct path read','direct path write',
		    'direct path read (lob) ','direct path write (lob)',
                   'db file sequential read','db file scattered read')
and w.p1 = f.file#
and w.wait_time = 0
group by substr(f.name,8,(instr(f.name,'/',9,1) -8)),
         substr(f.name,(instr(f.name,'/',-1,1)+1)) || ' (' || f.file# || ')'
order by 1 desc)
where rownum < 11;


