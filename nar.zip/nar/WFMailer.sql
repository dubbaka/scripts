-- WFMailer.sql

clear columns breaks compute
set feed on echo off term on

col "Name" for a45
col COMPONENT_ID for 99999999 head 'Component|Id'
col COMPONENT_STATUS for a10 head 'Component|Status'
col COMPONENT_TYPE for a25
col STARTUP_MODE for a10 head 'Startup|Mode'
col CONTAINER_TYPE for a10 head 'CONTAINER|TYPE'
col CUSTOMIZATION_LEVEL for a4 head 'Cust|Levl'
col CORRELATION_ID for a40
col COMPONENT_STATUS_INFO for a30
col CONCURRENT_QUEUE_ID for 99999 head 'Concurrent|Queue|Id'
col INBOUND_AGENT_NAME for a25
col OUTBOUND_AGENT_NAME for a20

prompt  There should be 7 Workflow components running

select  count(*) "Running Items"
from    apps.FND_SVC_COMPONENTS SC
where   COMPONENT_NAME like 'Work%'
and     COMPONENT_STATUS ='RUNNING';

select  COMPONENT_ID, trim(COMPONENT_NAME) "Name", COMPONENT_STATUS, COMPONENT_TYPE, STARTUP_MODE, CONCURRENT_QUEUE_ID
      , INBOUND_AGENT_NAME, OUTBOUND_AGENT_NAME, CORRELATION_ID, MAX_IDLE_TIME, COMPONENT_STATUS_INFO
from    apps.FND_SVC_COMPONENTS SC 
where   SC.COMPONENT_NAME like 'Work%'
and     COMPONENT_STATUS ='RUNNING'
order   by 1;

clear columns breaks compute

col COMPONENT_NAME for a50
col PARAMETER_VALUE for a60
SELECT b.component_name, 
c.parameter_name, 
a.parameter_value 
FROM apps.fnd_svc_comp_param_vals a, 
apps.fnd_svc_components b, 
apps.fnd_svc_comp_params_b c 
WHERE b.component_id = a.component_id 
AND b.component_type = c.component_type 
AND c.parameter_id = a.parameter_id 
AND c.encrypted_flag = 'N' 
AND b.component_name like '%Mailer%' 
AND c.parameter_name in ('OUTBOUND_SERVER', 'REPLYTO') 
ORDER BY c.parameter_name;  