/* @TopHotObjects.sql
    show the hottest objects in the buffer cache based on the touch count (TCH) */

col owner format a20
col object_name format a30
col touches format 9,999,999

set lines 200 pages 40

accept trgtRows number default 20 prompt 'Rows to display <20> : '

select * 
from ( select o.name OBJECT_NAME, sum(tch) TOUCHES , count(*) Cnt, u.name OWNER
       from  x$bh x, obj$ o, user$ u
       where x.obj = o.obj#
       and   o.owner# = u.user#
       group by u.name, o.name
       order by 2 desc)
where rownum <= &trgtRows;
