select ((select sysdate from dual)),(select  'user sessions : ' || count( distinct session_id) How_many_user_sessions from icx_sessions icx 
where disabled_flag != 'Y' and PSEUDO_FLAG = 'N' and (last_connect + decode(FND_PROFILE.VALUE('ICX_SESSION_TIMEOUT'),NULL,limit_time, 0,limit_time,FND_PROFILE.VALUE('ICX_SESSION_TIMEOUT')/60)/24) > sysdate 
and counter < limit_connects) from dual;