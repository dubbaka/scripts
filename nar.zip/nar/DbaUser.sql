-- @DbaUser.sql



clear columns breaks computes

set pages 400 lines 250 verif off

col USERNAME for a20
col ACCOUNT_STATUS for a20
col "LockDate" for a15
col "DfltTablespace" for a17
col "ExpiryDate" for a17
col "TempTablespace" for a20
col EXTERNAL_NAME for a30
col INITIAL_RSRC_CONSUMER_GROUP for a30

spool spool\DbaUser-&_MyDB1.

select count(1) "No Of DB Users"
from   dba_users;

select USERNAME, USER_ID, CREATED, ACCOUNT_STATUS
    ,  to_char(LOCK_DATE, 'dd-Mon-YY hh24:mi') "LockDate", to_char(EXPIRY_DATE, 'dd-Mon-YY hh24:mi') "ExpiryDate"
    ,  DEFAULT_TABLESPACE "DfltTablespace", TEMPORARY_TABLESPACE "TempTablespace", PROFILE, INITIAL_RSRC_CONSUMER_GROUP, EXTERNAL_NAME
from   dba_users
where  USERNAME like upper('&Schema%')
order  by 1;

spool off

clear columns breaks computes
set pages 40 lines 1000 verif off
