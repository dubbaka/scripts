rem ********************************************************************
rem * Filename          : pending.sql - Version 1.0
rem * Author            : LWL
rem * Original          : 9-Oct-97
rem * Description       : List # of CM jobs pending
rem * Usage             : start pending.sql
rem ********************************************************************

set linesize 100


def aps_prog    = 'pending.sql'
def aps_title   = 'PENDING Concurrent Manager Processes'

--start apstitle

col user_concurrent_queue_name format a50
col Pending format 999999


select v.user_concurrent_queue_name,r.max_processes,COUNT(phase_code) Pending
   from  apps.fnd_concurrent_queues_vl v,
         apps.fnd_concurrent_worker_requests r
   where --r.queue_application_id = 0
      r.phase_code = 'P'
     and r.hold_flag != 'Y'
     and v.enabled_flag='Y'
     and r.requested_start_date <= SYSDATE
     and r.concurrent_queue_id=v.concurrent_queue_id
   group by v.user_concurrent_queue_name,r.max_processes;

--start apsclear

