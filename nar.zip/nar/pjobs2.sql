set pagesize 10000
set linesize 132
break on USER_CONCURRENT_QUEUE_NAME on MAX_PROCESSES
col USER_CONCURRENT_QUEUE_NAME format a40
SELECT a.USER_CONCURRENT_QUEUE_NAME,a.MAX_PROCESSES,
sum(decode(b.PHASE_CODE,'P',decode(b.STATUS_CODE,'Q',1,0),0)) Pending_Standby,
sum(decode(b.PHASE_CODE,'P',decode(b.STATUS_CODE,'I',1,0),0)) Pending_Normal,
sum(decode(b.PHASE_CODE,'R',decode(b.STATUS_CODE,'R',1,0),0)) Running_Normal
FROM APPS.FND_CONCURRENT_QUEUES_VL a, APPS.FND_CONCURRENT_WORKER_REQUESTS b
WHERE a.enabled_flag='Y'
AND  a.concurrent_queue_id = b.concurrent_queue_id
AND  (b.Phase_Code = 'P' OR b.Phase_Code = 'R') AND b.hold_flag != 'Y'
AND  b.Requested_Start_Date <= SYSDATE
AND  1=1
GROUP BY a.USER_CONCURRENT_QUEUE_NAME,a.MAX_PROCESSES
/
