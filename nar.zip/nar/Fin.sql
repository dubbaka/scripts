Spool Aug_fin
prompt "Customer Transactions"

select to_char(creation_date,'MON-YYYY') MONTH1,count(*)NO_OF_TRANSACTIONS from ra_customer_trx_all where creation_date > sysdate-360
group by to_char(creation_date,'MON-YYYY');

Prompt "AP invoices"

select to_char(creation_date,'MON-YYYY') MONTH1,count(*) from ap_invoices_all where creation_date > sysdate-360
group by to_char(creation_date,'MON-YYYY');

prompt "AR receipts"

select to_char(creation_date,'MON-YYYY') MONTH1,count(*) from ar_cash_receipts_all where creation_date > sysdate-360
group by to_char(creation_date,'MON-YYYY');

spool off