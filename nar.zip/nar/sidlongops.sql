set verify off
col opname format a15 trunc
col pctdone format 999
col mintogo format 9,999.90
col lostart format a15 trunc head Started
col loupd format a15 trunc head Updated
accept trgtsid number default 0 prompt 'Limit to which SID : '
select s.sid,o.opname,s.sql_hash_value,o.sofar,o.totalwork,
	to_char(o.start_time,'mm/dd hh24:mi:ss') lostart,
	to_char(o.last_update_time,'mm/dd hh24:mi:ss') loupd,
	o.elapsed_seconds,
	round(o.time_remaining/60,2) mintogo,
	round(o.sofar/o.totalwork * 100,0) pctdone, o.message 
from v$session_longops o, v$session s
where o.sid = s.sid
and (o.sid = &trgtsid and &trgtsid > 0)
/

