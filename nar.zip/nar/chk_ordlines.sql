select org_id,ORIG_SYS_DOCUMENT_REF,count(*) from oe_lines_iface_all where 
ORIG_SYS_DOCUMENT_REF in ( select ORIG_SYS_DOCUMENT_REF from oe_headers_iface_all where error_flag is null)
group by org_id,ORIG_SYS_DOCUMENT_REF order by 3 asc
/
