select 'Material Transcations',to_char(transaction_date,'MON-yyyy'),count(1) duration from apps.mtl_material_transactions
where trunc(transaction_Date) >='01-Jan-11'
and trunc(transaction_date) <= '31-Mar-11'
group by to_char(transaction_date,'MON-yyyy')
union
select 'Po_Requisitions',to_char(creation_date,'MON-yyyy'),count(1)
from apps.po_requisition_headers_all 
where trunc(creation_Date) >='01-Jan-11'
and trunc(creation_date) <= '31-Mar-11'
group by to_char(creation_date,'MON-yyyy')
union
select 'Order Entries',to_char(creation_date,'MON-yyyy'),count(1)
from apps.oe_order_headers_all 
where trunc(creation_Date) >='01-Jan-11'
and trunc(creation_date) <= '31-Mar-11'
group by to_char(creation_date,'MON-yyyy')
union
select 'Order Entries',to_char(creation_date,'MON-yyyy'),count(1)
from apps.po_headers_all 
where trunc(creation_Date) >='01-Jan-11'
and trunc(creation_date) <= '31-Mar-11'
group by to_char(creation_date,'MON-yyyy')
Union
select 'Customer Transactions',to_char(creation_date,'MON-YYYY') MONTH1,count(*)NO_OF_TRANSACTIONS from ra_customer_trx_all 
where trunc(creation_Date) >='01-Jan-11'
and trunc(creation_date) <= '31-Mar-11'
group by to_char(creation_date,'MON-YYYY')
union
select 'AP invoices',to_char(creation_date,'MON-YYYY') MONTH1,count(*) from ap_invoices_all 
where trunc(creation_Date) >='01-Jan-11'
and trunc(creation_date) <= '31-Mar-11'
group by to_char(creation_date,'MON-YYYY')
union
select 'AR receipts',to_char(creation_date,'MON-YYYY') MONTH1,count(*) from ar_cash_receipts_all 
where trunc(creation_Date) >='01-Jan-11'
and trunc(creation_date) <= '31-Mar-11'
group by to_char(creation_date,'MON-YYYY')
