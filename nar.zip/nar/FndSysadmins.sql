-- @FndSysadmins.sql

set pages 300 lines 300 trim on

clear columns breaks compute

col USER_NAME           for a15
col DESCRIPTION         for a62
col EMAIL_ADDRESS       for a30
col RESPONSIBILITY_NAME for a40
col "StartDate"         for a11

select to_char(sysdate, 'DD-Mon-YYYY hh24:mi') "Date" from dual;

select A.USER_NAME, to_char(A.START_DATE,'DD-Mon-YYYY') "StartDate", A.DESCRIPTION, C.RESPONSIBILITY_NAME
from   FND_USER A, FND_USER_RESP_GROUPS_DIRECT B, FND_RESPONSIBILITY_TL C
where   C.RESPONSIBILITY_NAME in ('System Administrator','System Administration','User Management','Belron User Account Maintenance','Belron User Password Maintenance')
and    B.USER_ID           = A.USER_ID
and    C.APPLICATION_ID    = B.RESPONSIBILITY_APPLICATION_ID
and    C.RESPONSIBILITY_ID = B.RESPONSIBILITY_ID
and    C.LANGUAGE          = 'US'
and    A.END_DATE is NULL
and    (B.END_DATE is NULL or B.END_DATE >=sysdate)
order  by A.START_DATE;


/*
select A.USER_NAME, to_char(A.START_DATE,'DD-Mon-YYYY') "StartDate", A.DESCRIPTION, C.RESPONSIBILITY_NAME
from   FND_USER A, FND_USER_RESP_GROUPS_DIRECT B, FND_RESPONSIBILITY_TL C
where  
--C.RESPONSIBILITY_NAME = 'System Administrator'and    
B.USER_ID           = A.USER_ID
and    C.APPLICATION_ID    = B.RESPONSIBILITY_APPLICATION_ID
and    C.RESPONSIBILITY_ID = B.RESPONSIBILITY_ID
and    C.LANGUAGE          = 'US'
and    A.END_DATE is NULL
and    B.END_DATE is NULL
order  by A.user_name;*/