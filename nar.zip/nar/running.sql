rem ********************************************************************
rem * Filename          : running.sql - Version 1.0
rem * Author            : LWL
rem * Original          : 9-Oct-97
rem * Description       : List # of CM jobs running
rem * Usage             : start running.sql
rem ********************************************************************

set linesize 80


def aps_prog    = 'running.sql'
def aps_title   = 'Running Concurrent Manager Processes'

start apstitle


SELECT to_char(sysdate,'MM/DD/YYYY HH24:MI:SS') System_Date,CONCURRENT_QUEUE_NAME Queue, COUNT(PHASE_CODE) Running
FROM APPS.FND_CONCURRENT_WORKER_REQUESTS
Where PHASE_CODE = 'R'
AND HOLD_FLAG != 'Y'
AND REQUESTED_START_DATE <= SYSDATE
group by CONCURRENT_QUEUE_NAME
/

start apsclear

