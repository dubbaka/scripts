-- @EBSWFStats.sql

clear breaks columns computes

prompt Display Workflow related statistics

set echo on feed on lines 2000 pages 10000 pau off trimspool on colsep |

select wi.item_type "ItemType", wit.persistence_type "Persistence", decode (wi.end_date, NULL, 'OPEN', 'CLOSED') "Status", count(1) "Count"
from   applsys.wf_items wi, applsys.wf_item_types wit
where  wit.name = wi.item_type
group by item_type, wit.persistence_type, WIT.PERSISTENCE_DAYS, decode (wi.end_date, NULL, 'OPEN', 'CLOSED');

select item_type "ItemType", count(1) "Count"
from   applsys.wf_item_attribute_values
group  by item_type;

select item_type "ItemType", activity_status "Activity", count(1) "Count"
from   applsys.wf_item_activity_statuses
group  by item_type,activity_status;

clear breaks columns computes
