rem #############################################################################
rem File 	: @ObjectSizeInaTablespace.sql
rem Author	: Ravi Peesapati
rem Run As	: SYSTEM (SELECT ANY TABLE)
rem Use		: List Tables and current Size information
rem Output	: 
rem ##############################################################################

clear columns breaks computes

col owner for a10
col Tablespace_name for a15
col Type for a30
col segment_name for a30
col Partition for a30
col Bytes for 999,999,999,999

set veri off lines 300 pau off pages 3000 feed on time on timing on

accept tgtTblsp char default USERS prompt 'Tablespace <USERS>: '

spool spool\&_MyDB1._ObjectSizeInTblsp_&tgtTblsp

select Tablespace_name, owner, replace(segment_type,' ','_') Type, segment_name, nvl(PARTITION_NAME,'N/A') Partition, bytes, extents, blocks, initial_extent, nvl(next_extent,0) nxt_xtent, nvl(pct_increase,0) pct_inc, min_extents, max_extents
from   dba_segments
WHERE  TABLESPACE_NAME = upper('&tgtTblsp')
;

spool off

set veri off lines 2000 pau off pages 45 feed on time on timing on
