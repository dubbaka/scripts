-- @cmscheduled.sql -- find scheduled jobs that are yet to run


clear break compute col

set pages 5000 pau off head on lines 2000

col  program for a60
col  phase_code for a1
col  statustxt head "Status" for a20
col  parent for a8
col  reqstart head "Request Start|Date(24hr fmt)" for a15
col  mintogo head "Starts|(Mins)" for 999,999.99
col  Hrstogo head "Starts|(Hrs)" for 9,999
col "Requestor" for a15
col "Description" head "Username" for a60
col  EMAIL_ADDRESS for a50
col "Schedule" for a15

accept ReqID number default 99 prompt 'What is the Request ID <ALL> : '
accept ConcPgm char default ALL prompt 'What is the Short Conc Name <ALL> : '
accept UserConcPgm char default ALL prompt 'What is the Full Conc Name <ALL> : '

select decode(a.parent_request_id,-1,NULL,a.parent_request_id) "Parent", a.request_id
     , to_char(a.requested_start_date,'DD-Mon-yy HH24:MI') reqstart
     ,(a.requested_start_date-sysdate)*1440 mintogo
     ,(a.requested_start_date-sysdate)*24 Hrstogo
     , a.RESUBMIT_INTERVAL||' '||a.RESUBMIT_INTERVAL_UNIT_CODE "Schedule"
     , a.concurrent_program_id "Prg Id", a.phase_code||a.status_code||'-'||l2.meaning||' '||l1.meaning statustxt
     , c.concurrent_program_name||' - '|| c2.user_concurrent_program_name "program"
     , u.user_name "Requestor", u.DESCRIPTION, u.EMAIL_ADDRESS
     , a.RESUBMIT_INTERVAL_TYPE_CODE
     , a.RESUBMIT_TIME, a.RESUBMIT_END_DATE
from   fnd_Concurrent_requests a, fnd_concurrent_programs_tl c2, fnd_concurrent_programs c, fnd_lookup_values l1, fnd_lookup_values l2, fnd_user u
where (a.REQUEST_ID = &ReqID or &ReqID = 99)
and   (upper(c.concurrent_program_name) like upper('&ConcPgm%') or '&ConcPgm' = 'ALL')
and   (upper(c2.user_concurrent_program_name) like upper('&UserConcPgm%') or '&UserConcPgm' = 'ALL')
and    a.requested_start_date > sysdate-1
and    a.concurrent_program_id  = c.concurrent_program_id
and    a.program_application_id = c.application_id
and    c2.concurrent_program_id = c.concurrent_program_id
and    c2.language              = 'US'
and    c2.application_id        = c.application_id
and    a.actual_start_date      is null
and    a.status_code            in ('P','Q','I')
and    a.phase_code             = 'P'
and    l1.lookup_type           = 'CP_STATUS_CODE'
and    l1.lookup_code           = a.status_code
and    l1.language              = 'US'
and    l1.enabled_flag          = 'Y'
and   (l1.start_date_active   <= sysdate and l1.start_date_active is not null)
and   (l1.end_date_active      > sysdate  or  l1.end_date_active is null)
and    l2.lookup_type           = 'CP_PHASE_CODE'
and    l2.lookup_code           = a.phase_code
and    l2.language              = 'US'
and    l2.enabled_flag          = 'Y'
and   (l2.start_date_active   <= sysdate and l2.start_date_active is not null)
and   (l2.end_date_active     > sysdate  or  l2.end_date_active is null)
and    a.requested_by           = u.user_id
order  by 4 asc;

set pages 2000 pau off
