/* @FndProducts.sql
    Displays the Installed EBS11i products
*/

clear columns breaks computes

col APPLICATION_SHORT_NAME head "ShortName" for a10
col APPLICATION_NAME  head "ApplicationName" format a51
col PATCH_LEVEL head "PatchLevel" format a12
col basepath head "Basepath" format a9
col DESCRIPTION for a51
col PRODUCT_VERSION for a10 head "Version"
col TABLESPACE for a10 head 'Data|Tablespace'
col INDEX_TABLESPACE for a10 head 'Index|Tablespace'
col TEMPORARY_TABLESPACE for a10 head 'Temp|Tablespace'
col INDUSTRY for a8
col DB_STATUS for a8 head "DbStatus"

set verify off pages 250 lines 250 trim on

accept trgtShortName char default ALL prompt 'ShortName        <ALL> : '
accept trgtAppName   char default ALL prompt 'ApplicationName  <ALL> : '
accept trgtDataTbs   char default ALL prompt 'Data Tablespace  <ALL> : '
accept trgtNdxTbs    char default ALL prompt 'Index Tablespace <ALL> : '

spool spool\FndProducts_&_MyDB1.

select decode(b.status,'I','Installed','S','Shared',b.status) "Status", count(1)
from   APPS.fnd_application_vl a, APPS.fnd_product_installations b 
where  a.application_id = b.application_id
and   (a.APPLICATION_SHORT_NAME = upper('&trgtShortName') or upper('&trgtShortName')  = 'ALL')
and   (a.APPLICATION_NAME like upper('%&trgtAppName%') or upper('&trgtAppName')  = 'ALL')
group by decode(b.status,'I','Installed','S','Shared',b.status);

select a.APPLICATION_SHORT_NAME, decode(b.status,'I','Installed','S','Shared',b.status) "Status"
     , PATCH_LEVEL, a.basepath, b.PRODUCT_VERSION, b.TABLESPACE, b.INDEX_TABLESPACE, b.TEMPORARY_TABLESPACE
     , a.APPLICATION_NAME, a.DESCRIPTION, b.INDUSTRY, b.DB_STATUS
from   APPS.fnd_application_vl a, APPS.fnd_product_installations b 
where  a.application_id = b.application_id
and   (a.APPLICATION_SHORT_NAME = upper('&trgtShortName') or upper('&trgtShortName')  = 'ALL')
and   (a.APPLICATION_NAME like upper('%&trgtAppName%')    or upper('&trgtAppName')    = 'ALL')
and   (b.TABLESPACE like upper('&trgtDataTbs%')          or upper('&trgtDataTbs')    = 'ALL')
and   (b.INDEX_TABLESPACE like upper('&trgtNdxTbs%')     or upper('&trgtNdxTbs')     = 'ALL')
order  by 2,1;

spool off
