-- @TopRowsTbls.sql

clear columns breaks computes

set lines 2000 pages 3000 feed off head on echo off pau off timing on time off veri off trimspool on  colsep |

prompt Top Segments (Tables, TablePartitions) containing more than 100 rows
col OWNER for a25 head 'TableOwner'
col TABLE_NAME for a30 head 'Table'
col NUM_ROWS for 9999999999999999 head 'Rows'
col TABLESPACE_NAME for a30 head 'Tablespace'
col PARTITIONED for a12
col BLOCKS for 99999999999
col EMPTY_BLOCKS for 99999999999
col CHAIN_CNT for 99999999999
Col IOT_TYPE for a30 head 'IotType'
col IOT_NAME for a30 head 'IotName'
col AVG_SPACE for 99999999999
col AVG_ROW_LEN for 99999999999
col AVG_SPACE_FREELIST_BLOCKS for 99999999999
col NUM_FREELIST_BLOCKS for 99999999999
col TEMPORARY for a10 head 'Temporary?'
col ROW_MOVEMENT for a10 head 'Row|Movement?'
col MONITORING for a12 head "Monitoring?"
col COMPRESSION for a12 head "Compression?"
col DROPPED for a8 head 'Dropped?'
col BUFFER_POOL for a12 head "BufferPool"
col LOGGING for a8 head 'Logging?'

col "TimeNow"      for a18
col pHost for a10
col pSid for a10

col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;

select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", OWNER, TABLE_NAME, NUM_ROWS, nvl(TABLESPACE_NAME,'null') TABLESPACE_NAME, nvl(PARTITIONED,'null') PARTITIONED, nvl(BLOCKS,0) BLOCKS
, nvl(EMPTY_BLOCKS,0) EMPTY_BLOCKS, nvl(CHAIN_CNT,0) CHAIN_CNT, nvl(IOT_TYPE, 'null') IOT_TYPE, nvl(IOT_NAME, 'null') IOT_NAME, nvl(AVG_SPACE,0) AVG_SPACE
, nvl(AVG_ROW_LEN,0) AVG_ROW_LEN, nvl(AVG_SPACE_FREELIST_BLOCKS,0) AVG_SPACE_FREELIST_BLOCKS, nvl(NUM_FREELIST_BLOCKS,0) NUM_FREELIST_BLOCKS, TEMPORARY
, nvl(ROW_MOVEMENT,'null') ROW_MOVEMENT, nvl(MONITORING,'null') MONITORING, nvl(COMPRESSION,'null') COMPRESSION
, nvl(BUFFER_POOL,'null') BUFFER_POOL, nvl(LOGGING,'null') LOGGING
from dba_tables
where num_rows is not null
and owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
and num_rows > 100;

clear columns breaks computes

