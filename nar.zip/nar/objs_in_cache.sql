/* objs_in_cache.sql
     see the objects in the buffer cache
     optionally limit by owner, object name
*/
set verify off
set lines 132
col filename format a35 trunc
col ownername format a10 head owner
col objname format a30 head object_name
col blksincache format 999,999 head footprint
accept trgtown char default ALL prompt 'Limit to owner <all> : '
accept trgtobj char default ALL prompt 'Limit to object name <all> : '
select u.name ownername,
       o.name objname,
       count(bc.block#) blksincache,
       bc.status,
       f.name filename
from sys.obj$ o, v$bh bc, v$datafile f, sys.user$ u
where o.obj# = bc.objd
and f.file# = bc.file#
and u.user# = o.owner#
and (u.name = upper('&trgtown') or upper('&trgtown') = 'ALL')
and (o.name = upper('&trgtobj') or upper('&trgtobj') = 'ALL')
group by u.name,o.name,bc.status,f.name
order by 3;
