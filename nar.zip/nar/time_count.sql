SELECT ELAPSED_TIME/60,EXECUTIONS FROM V$SQL WHERE SQL_TEXT=(SELECT a.SQL_TEXT from V$SQL a where a.hash_value = (select b.sql_hash_value from V$SESSION B WHERE B.SID=383));
