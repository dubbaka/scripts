set pages 100
set lines 2000 pages 0 feed off head on echo off pau off timing on time on veri off trim on trimspool on colsep |
col w.event for a35
select w.sid, w.event, s.module "ModShrt",s.action ,s.sql_hash_value "SQL_HASH", s.machine, to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime, s.USERNAME "DBSchema", p.USERNAME "DBNosuser", s.osuser "APNosuser", s.process, p.spid, s.module, s.program
from   v$session_wait w, v$session s, v$process p, v$px_session px
where s.sid = w.sid
and px.sid=s.sid
and px.DEGREE is null and px.REQ_DEGREE is null
and s.paddr = p.addr
and w.wait_time = 0
and w.event like 'PX Deq:%';
