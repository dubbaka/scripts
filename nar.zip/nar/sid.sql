-- @sid.sql
clear columns breaks compute

set verify off lines 800
set pages 200

col inst_id for 9999 head "Inst|Id"
col SID for 99999
col "SERIAL#" for 999999
col process head "OSpid|APnode" for a10
col SPID head "OSpid|DBnode" for a10
col username for a8 head "Schema"
col osuser for a10
col machine for a12 trunc
col module for a20
col sql_hash_value head "SQL_HASH" for 9999999999
col program for a25 trunc
col logontime for a15
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11

accept trgtsid number default 0 prompt 'What is the SID : '
accept trgtmodule char default ALL prompt 'Module <ALL>: '
accept trgtSqlId char default ALL prompt 'SqlHash <ALL> : '
accept trgtStatus char default ALL prompt 'Status <ALL> : '
accept trgtDBSchema char default ALL prompt 'DB Schema <ALL> : '

select s.inst_id, s.sid, s.serial#, s.process, p.spid, s.username, s.osuser, replace(s.machine,'ASIAPAC\',null) machine, s.module
      , to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime
      , floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
      , s.status, s.sql_hash_value
	  --, s.sql_id
	  , s.action
      , s.program, s.type, p.pid,p.PGA_USED_MEM, p.PGA_ALLOC_MEM, p.PGA_FREEABLE_MEM, p.PGA_MAX_MEM
from    gv$session s, gv$process p
where s.inst_id = p.inst_id
and  (s.sid = &trgtsid or &trgtsid = 0)
and  (upper(s.module)  like upper('%&trgtmodule%') or '&trgtmodule' = 'ALL')
and  p.addr = s.paddr
and  (upper(s.status) like upper('&trgtStatus') or '&trgtStatus' = 'ALL')
and  (upper(s.username) = upper('&trgtDBSchema') or '&trgtDBSchema' = 'ALL')
and s.serial#<>1
and s.type<>'BACKGROUND'
and  (s.sql_hash_value = '&trgtSqlId' or upper('&trgtSqlId') = 'ALL')
;

