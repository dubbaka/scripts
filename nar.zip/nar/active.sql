/* active.sql
    show info about user sessions */
col sid format 99999
col username format a5
col osuser format a10
col logged_on format a13 head LOGON_TIME
col umachine format a10
col program format a20
col proginfo format a15
col LastCallET format 99,999
col spid for 999999 head OSpid
col process for 9999999 head OraPID

set verify off
set wrap on
set lines 140

accept trgtSID number default 0 prompt 'Restrict to which SID <ALL> : '
accept trgtOSPID number default 0 prompt 'Restrict to which OSpid <ALL> : '
accept trgtmod char default ALL prompt 'Restrict to which module <ALL> : '
accept trgtmach char default ALL prompt 'Restrict to which originating server <ALL> : '
accept trgtstatus char default Y prompt 'Limit to active sessions only <Y> : '

select s.sid, s.status, s.username, s.osuser, replace(s.machine,'GEIPS-AMER\',NULL) umachine,
       s.sql_hash_value, s.command, s.process, p.spid, to_char(logon_time,'mm/dd hh:miAM') logged_on, 
       floor(last_call_et/60) "LastCallET", s.module proginfo
from v$session s, v$process p
where s.username is not null
and s.type = 'USER'
and s.paddr = p.addr
and (&trgtSID = 0  or s.sid = &trgtSID)
and (&trgtOSPID = 0  or p.spid = &trgtOSPID)
and ((s.status = 'ACTIVE' and upper('&trgtstatus') = 'Y') or upper('&trgtstatus') != 'Y')
and (upper(s.module) like upper('%&trgtmod%') or upper('&trgtmod') = 'ALL') 
and (upper(s.machine) like upper('%&trgtmach%') or upper('&trgtmach') = 'ALL') 
/

