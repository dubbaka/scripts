Select 'Mar' as Month, count(1) as Count, 
a.MNTPT, nvl(min(LIO),0) as MinLIO, 
nvl(round(avg(LIO),2),0) as AvgLIO, 
nvl(max(LIO),0) as maxLIO, 
nvl(min(PIO),0) as MinPIO, 
nvl(round(avg(PIO),2),0) as AvgPIO, 
nvl(max(PIO),0) as maxPIO, 
nvl(min(a.Collected_date),'01-JAN-00') as StartDate, 
nvl(max(a.Collected_date),'01-JAN-00') as EndDate, 
nvl((max(trunc(Collected_date))-min(trunc(Collected_date))+1),0) as CalDays, 
nvl(count(distinct trunc(a.Collected_date)),0) as UniqDays, 2010 as Year,
 'MonFriInclHol' as Day, 'BusinessHrs' as TimeOfDay 
 FROM XXPERFCAP.MY_MntPtIO_USAGE a 
 WHERE a.Host = 'bze1uo05' 
 and a.Year = 2010 
 and a.Month = 'Mar' 
 and trim(to_char(Collected_date, 'hh24:mi')) between '09:00' and '16:30' and a.Day not in ('Sat','Sun') 
 Group by a.MNTPT Order By MNTPT 