-- UserLogins.sql


clear columns computes breaks

ttitle '11i - User Sessions by Program'

col pid format 999 heading 'PID'
col spid format a6 heading 'SERVER|PID'
col sid format 9999 heading 'SID'
col serial# format 99999 heading 'SERIAL'
col process format a8 heading 'CLIENT|PID'
col audsid format b99999999 heading 'AUDIT|SESSION'
col program format a51 heading 'PROGRAM NAME'
col form_name format a10 heading 'FORM|NAME'
col user_name format a10 heading 'APPS USER|NAME'

break on osuser on username on logical on physical_reads on audsid on user_name

select s.process, p.spid, p.pid, s.sid, s.serial#, fu.user_name, ff.form_name
from   v$session s, v$sess_io i, v$process p, applsys.fnd_logins fl, applsys.fnd_login_responsibilities flr,
       applsys.fnd_login_resp_forms flrp, applsys.fnd_user fu, applsys.fnd_form ff, applsys.fnd_form_tl fft
where  s.program like 'f60runm%'
and    s.paddr = p.addr
and    s.sid = i.sid
and    s.osuser = fl.login_name
and    s.process = fl.spid
and    fl.start_time >= trunc(sysdate)
and    fl.end_time is null
and    fl.login_id = flr.login_id (+)
and    flr.start_time(+) >= trunc(sysdate)
and    flr.end_time(+) is null
and    flr.login_id = flrp.login_id (+)
and    flrp.start_time(+) >= trunc(sysdate)
and    flrp.end_time(+) is null
and    flrp.form_appl_id = ff.application_id(+)
and    flrp.form_id = ff.form_id(+)
and    ff.form_name != 'FNDSCSGN'
and    fl.user_id = fu.user_id
and    ff.application_id = fft.application_id
and    ff.form_id = fft.form_id
and    fft.language = userenv('lang')
order  by block_gets + consistent_gets desc;
