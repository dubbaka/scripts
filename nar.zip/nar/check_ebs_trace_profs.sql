set pagesize 9999set linesize 120
set verify off
col "Profile Option" for a25
col "Option Level" for a13
col "set for" for a20
col "Value" for a20
col "Set On" for a11
col "Blame" for a20

accept check_since default 7 Prompt 'Enter number of days <7>':

SELECT   tl.user_profile_option_name "Profile Option",
         DECODE (val.level_id,
                 10001, 'Site',
                 10002, 'Application',
                 10003, 'Responsibility',
                 10004, 'User',
                 10005, 'Server',
                 10006, 'Organization',
                 10007, 'Server+Resp',
                 'No idea, boss'
                ) "Option Level",
         DECODE (val.level_id,
                 10001, 'EVERYWHERE!',
                 10002, (SELECT application_name
                           FROM fnd_application_tl
                          WHERE application_id = val.level_value),
                 10003, (SELECT responsibility_name
                           FROM fnd_responsibility_tl
                          WHERE responsibility_id = val.level_value
                            AND application_id =
                                                val.level_value_application_id),
                 10004, (SELECT user_name
                           FROM fnd_user
                          WHERE user_id = val.level_value),
                 10005, (SELECT HOST || '.' || domain
                           FROM fnd_nodes
                          WHERE node_id = val.level_value),
                 10006, (SELECT NAME
                           FROM hr_all_organization_units
                          WHERE organization_id = val.level_value),
                 10007, 'Look it up',
                 '''Tis a mystery'
                ) "Set for",
         val.profile_option_value "Value", val.last_update_date "Set on",
         usr.user_name "Set By"
    FROM fnd_profile_options opt,
         fnd_profile_option_values val,
         fnd_profile_options_tl tl,
         fnd_user usr
   WHERE opt.profile_option_id = val.profile_option_id
     AND opt.profile_option_name = tl.profile_option_name
     AND REGEXP_LIKE (tl.user_profile_option_name,
                      '(trace|log|debug|audit|diag|sql)',
                      'i'
                     )
     AND NOT (REGEXP_LIKE (tl.user_profile_option_name,
                           '(catalog|file|login|utilities)',
                           'i'
                          )
             )
     AND usr.user_id = val.last_updated_by
     AND usr.user_name NOT IN ('AUTOINSTALL', 'INITIAL SETUP', 'ANONYMOUS')
     AND val.last_update_date > sysdate - &check_since
ORDER BY val.last_update_date DESC;