REM
REM        START OF SQL
REM
REM  Filename     : mzParameters.sql
REM  Author       : Mike Shaw
REM  Date Updated : 27 March 2007
REM  Purpose      : Script to list database parameters
REM 
set serveroutput on
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 80
col name format a35
col value format a55
col def_val format a6
--
-- spool instance_params.txt
--
select NAME, VALUE, ISDEFAULT def_val
from V$PARAMETER2
order by NAME
/
-- spool off
REM 
REM        END OF SQL
REM 
