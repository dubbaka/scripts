REM $Header: afcmcreq.sql 120.2 2005/08/19 20:41:44 ckclark ship $
REM +======================================================================+
REM |   Copyright (c) 1992 Oracle Corporation Belmont, California, USA     |
REM |                       All rights reserved.                           |
REM +======================================================================+
REM FILENAME
REM   afcrlog.sql
REM DESCRIPTION
REM   Prints the Log file names of the managers that can run a given request
REM NOTES
REM   Cpid : Is the Oracle ID for the Manager
REM   Osid : Is the System process ID for the Manager
REM  
REM            Ram Bhoopalam     Created
REM +======================================================================+
REM
REM  dbdrv:none
REM

Column OsId       Format A7
Column Oracle_Process_ID     Format 99999
Column Concurrent_Queue_Name Format A20
Column Log        Format A25
Column Started_At Format A20

Set Head Off
Set Verify Off
Set Echo Off

Select
      'The ' || Concurrent_Queue_Name ||
      ' concurrent manager ran your request from',
      to_char(Actual_Start_date, '     MON-DD-YY HH:MI:SS AM') || ' - to - ' ||
      to_char(Actual_COMPLETION_date, 'MON-DD-YY HH:MI:SS AM'),
      'The ' || Concurrent_Queue_Name ||
      ' concurrent manager log file is ' || P.Logfile_Name,
      'Request log file is ' || R.Logfile_Name
  From Fnd_Concurrent_Queues Q,
       Fnd_Concurrent_requests R,
       Fnd_Concurrent_Processes P
 Where  
       (P.Concurrent_Queue_ID = Q.Concurrent_Queue_ID And
        Queue_Application_ID  = Q.Application_ID )
   And  R.Controlling_Manager = P.Concurrent_Process_ID
   And  R.Phase_Code = 'C'
   And  Request_ID = &Request_ID
;

set head on
