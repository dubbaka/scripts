col member format a40 trunc
select to_char(l.first_time,'mm/dd hh24:mi'),l.group#, l.sequence#, l.bytes,l.status,l.archived,f.member
from v$log l, v$logfile f
where l.group# = f.group#
order by sequence#
/
