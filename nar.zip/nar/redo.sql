col member format a40 trunc
col logsize format 9999 head MBSize

select l.THREAD# ,f.group#,l.status,sum(l.bytes/1024/1024) logsize,f.member
from v$log l, v$logfile f
where f.group# = l.group#
group by l.THREAD# ,f.group#,l.status,f.member
order by 1,2
/

select l.THREAD# ,l.status,count(*)/2
from v$log l, v$logfile f
where f.group# = l.group#
group by l.THREAD#,l.status
order by 1,2
/

