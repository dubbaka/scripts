-- @cms.sql
-- Display Concurrent Manager que details


col CONCURRENT_QUEUE_NAME for a25
col CONCURRENT_QUEUE_ID head "CONC|QUEUE|ID" for 9999
col MIN_PROCESSES head "Min|Procs" for 9999
col MAX_PROCESSES head "Act|Procs" for 9999
col RUNNING_PROCESSES head "Rng|Procs" for 9999
col Target_PROCESSES head "Tgt|Procs" for 9999
col MANAGER_TYPE head "MGR|TYPE" for a4
col NODE_NAME for a15
col NODE_NAME2 for a15
col ENABLED_FLAG head "Enabled" for a7
col PCP_FLAG head "PCP|FLAG" for a4
col PMON_STAT head "PMON|STAT" for 9999
col SLEEP_SECONDS head "SLEEP|SECONDS" for 9999999
col DIAGNOSTIC_LEVEL head "DIAG|LEVEL" for a5
col OS_QUEUE for a15
col OS_QUEUE2 for a15
col TARGET_QUEUE for a15
col "OS Proc" for a15
col process_status_code for a10 head "Process|Status|Code"
col os_process_id for A7 head "OSpid|APnode"
col CONTROL_CODE for a15

set pages 100 lines 300

spool spool\cms_&_MyDateNow._&_MyDB1.

select concurrent_queue_name, concurrent_queue_id, MIN_PROCESSES, MAX_PROCESSES, RUNNING_PROCESSES, TARGET_PROCESSES
     , MANAGER_TYPE, NODE_NAME, NODE_NAME2, ENABLED_FLAG, PMON_STAT, PCP_FLAG, DIAGNOSTIC_LEVEL
     , OS_QUEUE, OS_QUEUE2, TARGET_QUEUE, SLEEP_SECONDS, RESTART_TYPE, RESTART_INTERVAL
     , to_char(WORK_START, 'DD-Mon-YYYY hh24:mi:ss') "WorkStart"
     , to_char(WORK_END, 'DD-Mon-YYYY hh24:mi:ss') "WorkEnd"
     , CONTROL_CODE
from   fnd_concurrent_queues 
where  ENABLED_FLAG = 'Y'
order  by 1;

prompt 
prompt If the ActProcs= TgtProcs above, that means the manager is UP. 
prompt 

spool off

prompt 1) For current running requests or status of a specific concurrent request use --> @cmrun2.sql
prompt 2) For historical analysis of a specific Concurrent Pgm use --> @cmrun1.sql
prompt 3) For further detailed analysis of a specific concurrent request use --> @cmAnalReq.sql
prompt 4) For getting Average run time analysis for a specifc concurrent program or all Concurrent programs (for today or for all days) use --> @cmAvgRunTime.sql
prompt 5) For individual or all Concurrent queue request analysis use --> @cmStats.sql
prompt 6) For displaying Concurrent requests that started between a given StartTime and EndTime use --> @cmbetween.sql
