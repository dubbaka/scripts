set lines 180
set pages 2000
col file_name format a50
select file_name, status, round(bytes/1024/1024) MB
from dba_data_files
where tablespace_name like '%&tablespace_name%'
order by substr(file_name,instr(file_name,'/',-1,1)+1,instr(file_name,'.'))
/
