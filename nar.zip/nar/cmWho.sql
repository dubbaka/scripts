-- @CMWho.sql
-- Who submitted a Conc Request

clear columns breaks computes

set pages 200

col "Conc Pgm"    for a50
col "User" for a30
col PARENT_REQUEST_ID head "Parent|RequestID"
col COMPLETION_TEXT for a50
col LOGFILE_NAME for a30
col LOGFILE_NODE_NAME for a20
col OUTFILE_NAME  for a30
col OUTFILE_NODE_NAME for a20
col OS_PROCESS_ID for a15
col EMAIL_ADDRESS for a30
col PHASE_CODE head "P|H|A|S|E" for a1
col STATUS_CODE head "S|T|A|T|U|S" for a1
col "REQUESTDATE" head "RequestDate" for a21
col "REQUESTEDSTARTDATE" head "RequestedStartDate" for a21
col "ACTUALSTARTDATE" head "ActualStartDate" for a21
col "ACTUALCOMPLETIONDATE" head "LAST|UPDATE|DATE" for a21
col "LASTUPDATEDATE" head "LastUpdateDate" for a21

accept tgtReqID number default 99 prompt 'Request ID <ALL> : '
accept tgtConcPgm char default ALL prompt 'Short Conc Name <ALL> : '
accept UserConcPgm char default ALL prompt 'Full Conc Name <ALL> : '
accept tgtUser char default ALL prompt 'User Short Name <ALL> : '
accept RunDate     char   default ALL         prompt 'Run Date (DDmonYY)           <ALL> : '

select fcr.PARENT_REQUEST_ID, fcr.REQUEST_ID , fcr.REQUESTED_BY
     , fu.USER_NAME||' --> '||fu.DESCRIPTION "User", fu.EMAIL_ADDRESS
     , fcr.PHASE_CODE , fcr.STATUS_CODE
     , to_char(fcr.REQUEST_DATE,'DDMonYY hh24:mi:ss') "REQUESTDATE"
     , to_char(fcr.REQUESTED_START_DATE,'DDMonYY hh24:mi:ss') "REQUESTEDSTARTDATE"
     , to_char(fcr.LAST_UPDATE_DATE,'DDMonYY hh24:mi:ss') "LASTUPDATEDATE"
     , to_char(fcr.ACTUAL_START_DATE,'DDMonYY hh24:mi:ss') "ACTUALSTARTDATE"
     , to_char(fcr.ACTUAL_COMPLETION_DATE,'DDMonYY hh24:mi:ss') "ACTUALCOMPLETIONDATE"
     , fcr.ORACLE_ID , fcr.ORACLE_PROCESS_ID , fcr.ORACLE_SESSION_ID, fcr.OS_PROCESS_ID 
     , fcr.CONCURRENT_PROGRAM_ID , fcr.CONC_LOGIN_ID
     , c.concurrent_program_name||' - '||c2.user_concurrent_program_name "ConcPgm"
from   fnd_concurrent_requests fcr , fnd_user fu, APPLSYS.fnd_concurrent_programs c, APPLSYS.fnd_concurrent_programs_tl c2
where (fcr.REQUEST_ID = &tgtReqID or &tgtReqID = 99)
and   (fu.USER_NAME like '&tgtUser%' or '&tgtUser' = 'ALL')
and   (c.concurrent_program_name like '&tgtConcPgm%' or '&tgtConcPgm' = 'ALL')
and    (c2.user_concurrent_program_name like '&UserConcPgm%' or '&UserConcPgm' = 'ALL')
and   (to_char(actual_start_date, 'DDmonYY') = '&RunDate' or '&RunDate' = 'ALL')
and    fu.user_id = fcr.REQUESTED_BY
and    c.concurrent_program_id = fcr.concurrent_program_id
and    c.application_id = fcr.program_application_id
and    c2.concurrent_program_id = c.concurrent_program_id
and    c2.language = 'US'
order by fcr.REQUESTED_START_DATE desc
