-- @UnsuppTypes.sql


/* Logical Standby database supported Datatypes

	Supported Datatypes
	===================
	CHAR
	NCHAR
	VARCHAR2
	VARCHAR
	NVARCHAR2
	NUMBER
	DATE
	TIMESTAMP
	TIMESTAMP WITH TIME ZONE
	TIMESTAMP WITH LOCAL TIME ZONE
	INTERVAL YEAR TO MONTH
	INTERVAL DAY TO SECOND
	RAW
	CLOB
	BLOB


	Unsupported Datatypes
	=====================
	NCLOB
	LONG
	LONG RAW
	BFILE
	ROWID
	UROWID
	user-defined types
	object types REFs
	varrays
	nested tables


	Unsupported Tables, Sequences, and Views
	========================================
	User-defined tables and sequences in the SYS schema
	Tables with unsupported datatypes
	Tables using data segment compression
	Index-organized tables

*/


clear columns breaks computes

set lines 80 pages 3000

col OWNER for a20
col TABLE_NAME for a30

spool spool\UnsuppTypes_&_MyDB1.

SELECT DISTINCT OWNER , TABLE_NAME
FROM   DBA_LOGSTDBY_UNSUPPORTED
ORDER  BY OWNER , TABLE_NAME;

spool off


-- To view the column names and datatypes for one of the tables listed in the previous
-- query, use a SELECT statement similar to the following:
-- SELECT COLUMN_NAME,DATA_TYPE FROM DBA_LOGSTDBY_UNSUPPORTED
-- WHERE OWNER=�OE� AND TABLE_NAME = �CUSTOMERS�;
