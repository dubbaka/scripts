set linesize 500
set pages 999
set echo off
set trimspool on
set feedback on
set termout on
col "Parent" for a8

COLUMN request_id              HEADING 'Request Id' FORM 9999999999 TRUNC
COLUMN concurrent_program_id   HEADING 'CP ID'    FORM 99999999    TRUNC
COLUMN concurrent_program_name HEADING 'CP Name'  FORM a50      TRUNC
COLUMN pgm_name                HEADING 'Program Name'  FORM a60 TRUNC
COLUMN sid                     HEADing 'Sid'      FORM 9999  
COLUMN user_name               HEADING 'App User' FORM a18       TRUNC
COLUMN runtime                 HEADING 'Minutes '    FORM 99990.9  TRUNC
COLUMN concurrent_queue_name   HEADING 'Queue  '  FORM a25      TRUNC
COLUMN node                    HEADing 'INST|ID'     FORM 9        TRUNC
COLUMN oracle_process_id       HEADing 'Pid'      FORM a10  
column inst_name               Heading 'Inst Name' FORM A10
column phase for a10
column status for a10

col argument_text  for a120
col hold_flag head "H|O|L|D"
col is_sub_request head "S|u|b|Request"
col user_concurrent_program_name for a30
col resubmit_interval head 'Resubmit|Interval'

select * from (
SELECT decode(r.parent_request_id, -1,NULL , r.parent_request_id) "Parent"
,r.request_id,
       DECODE (r.description,
               NULL, pt.user_concurrent_program_name,
               r.description || ' ( ' || pt.user_concurrent_program_name
               || ' ) '
              ) concurrent_program_name,
             fnd_amp_private.get_phase (r.phase_code,
                                  r.status_code,
                                  r.hold_flag,
                                  p.enabled_flag,
                                  r.requested_start_date,
                                  r.request_id
                                 ) phase,
       fnd_amp_private.get_status (r.phase_code,
                                   r.status_code,
                                   r.hold_flag,
                                   p.enabled_flag,
                                   r.requested_start_date,
                                   r.request_id
                                  ) STATUS,
       u.user_name,
       r.requested_start_date,
       r.request_date,              r.is_sub_request,
              r.hold_flag,
       p.enabled_flag,
             r.resubmit_interval,r.RESUBMIT_INTERVAL_UNIT_CODE,r.argument_text       
  FROM fnd_concurrent_programs_tl pt,
       fnd_responsibility_tl rt,
       fnd_application_tl AT,
       fnd_concurrent_programs_vl p,
       fnd_user u,
       fnd_concurrent_requests r
 WHERE r.program_application_id = p.application_id
   AND r.concurrent_program_id  = p.concurrent_program_id
   AND pt.concurrent_program_id = p.concurrent_program_id
   AND pt.application_id        = p.application_id
   AND pt.LANGUAGE = USERENV ('LANG')
   AND u.user_id                = r.requested_by
   AND rt.application_id        = r.responsibility_application_id
   AND rt.responsibility_id     = r.responsibility_id
   AND rt.LANGUAGE = USERENV ('LANG')
   AND AT.application_id        = r.program_application_id
   AND AT.LANGUAGE = USERENV ('LANG')
and r.phase_code = 'P' and
 r.status_code<>'F')
where status not in ('Scheduled','On Hold')
/



