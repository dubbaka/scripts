select * from table(dbms_xplan.display_cursor('&enter_sql_id',&cursor,'PEEKED_BINDS'));

