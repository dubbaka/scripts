-- @cmRunAlone.sql

clear columns breaks computes

set lines 200
col USER_CONCURRENT_PROGRAM_NAME for a60

select b.LANGUAGE, a.CONCURRENT_PROGRAM_NAME, b.USER_CONCURRENT_PROGRAM_NAME, a.CONCURRENT_PROGRAM_ID, a.CREATION_DATE, a.ENABLED_FLAG, a.RUN_ALONE_FLAG, a.ENABLE_TRACE, a.PROGRAM_TYPE
from   apps.fnd_concurrent_programs a , apps.fnd_concurrent_programs_tl b
where  a.RUN_ALONE_FLAG = 'Y'
and    b.CONCURRENT_PROGRAM_ID = a.CONCURRENT_PROGRAM_ID
order  by b.LANGUAGE;
