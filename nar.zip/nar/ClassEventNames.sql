-- @ClassEventNames.sql

clear columns breaks computes

set lines 200 pau on wrap on

col wait_class for a15
col event#     for 999999
col parameter1 for a30
col parameter2 for a20
col parameter3 for a20

select unique wait_class
from   gv$event_name
order  by wait_class;

select wait_class, event#, name, parameter1, parameter2, parameter3
from   gv$event_name
order  by wait_class, name;

set pau off
