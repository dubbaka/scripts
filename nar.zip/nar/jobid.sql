/* jobid.sql
      find out the concurrent job names and program id
*/
set verify off
col concurrent_program_id format 9999999 head ProgID
col concurrent_program_name format a15 trunc head "Short Name"
col user_concurrent_program_name format a45 trunc head "Full Name"
accept whichway char default S prompt 'Look up job via (S)hort name or (F)ull name <s> : '
accept givenval char default unknown prompt 'What is the name to search on : '
select c.concurrent_program_id,
       c.concurrent_program_name,
       ctl.user_concurrent_program_name
from applsys.fnd_concurrent_programs c,
     applsys.fnd_concurrent_programs_tl ctl
where ((upper(c.concurrent_program_name) like upper('&givenval%')
        and upper('&whichway') = 'S')
   or (upper(ctl.user_concurrent_program_name) like upper('&givenval%')
        and upper('&whichway') = 'F'))
  and ctl.concurrent_program_id = c.concurrent_program_id
  and ctl.application_id = c.application_id
  and ctl.language = 'US';                             

