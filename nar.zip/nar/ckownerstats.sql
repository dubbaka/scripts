col objtype format a8
col stats_status format a12
set verify off
accept trgtown char default ALL prompt 'Limit to which user <ALL> : '
select count(*),owner,'Tables' objtype,decode(last_analyzed,null,'No Stats','Stats') stats_status,
min(last_analyzed), max(last_analyzed)
from dba_tables
where owner not in ('SYS','SYSTEM')
and (owner = upper('&trgtown') or upper('&trgtown') = 'ALL')
group by owner,decode(last_analyzed,null,'No Stats','Stats')
union
select count(*),owner,'Indexes' objtype,decode(last_analyzed,null,'No Stats','Stats') stats_status,
min(last_analyzed), max(last_analyzed)
from dba_indexes
where owner not in ('SYS','SYSTEM')
and (owner = upper('&trgtown') or upper('&trgtown') = 'ALL')
group by owner,decode(last_analyzed,null,'No Stats','Stats')
order by 2,3,4
/
