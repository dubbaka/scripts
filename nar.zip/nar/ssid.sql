col sid format 9999
col username format a10
col osuser format a10
col program format a25
col process format 9999999
col spid format 999999
col logon_time format a13
col Action format a10
col sql_text for a80

set lines 150

set heading off
set verify off
set feedback off

undefine sid_number
undefine spid_number
rem accept sid_number number prompt "pl_enter_sid:"

col sid NEW_VALUE sid_number noprint
col spid NEW_VALUE spid_number noprint


         select  s.inst_id Inst,s.sid   sid,
                p.spid  spid
--              ,decode(count(*), 1,'null','No Session Found with this info') " "
         FROM gv$session s,
              gv$process p
         WHERE s.sid LIKE NVL('&sid', '%')
         AND p.spid LIKE NVL ('&OS_ProcessID', '%')
         AND s.process LIKE NVL('&Client_Process', '%')
         AND s.paddr = p.addr
--       group by s.sid, p.spid;

PROMPT Session and Process Information
PROMPT -------------------------------

col event for a30

select '    Instance ID                 : '||v.inst_id  || chr(10) ||
       '    SID                         : '||v.sid      || chr(10)||
       '    Serial Number               : '||v.serial#  || chr(10) ||
       '    Oracle User Name            : '||v.username         || chr(10) ||
       '    Client OS user name         : '||v.osuser   || chr(10) ||
       '    Client Process ID           : '||v.process  || chr(10) ||
       '    Client machine Name         : '||v.machine  || chr(10) ||
       '    Oracle PID                  : '||p.pid      || chr(10) ||
       '    OS Process ID(spid)         : '||p.spid     || chr(10) ||
       '    Session''s Status           : '||v.status   || chr(10) ||
       '    Logon Time                  : '||to_char(v.logon_time, 'MM/DD HH24:MIpm')   || chr(10) ||
       '    Program Name                : '||v.program  || chr(10) ||
       '    Action                      : '||v.action   || chr(10)
from gv$session v, gv$process p
where v.paddr = p.addr
and v.serial# > 1
and p.background is null
and p.username is not null
and sid = &sid_number
and v.inst_id=p.inst_id
order by logon_time, v.status, 1
/


PROMPT Sql Statement
PROMPT --------------

select gv$sqltext.inst_id,sql_text
from gv$sqltext , gv$session
where gv$sqltext.address = gv$session.sql_address
and sid = &sid_number
order by piece
/

PROMPT
PROMPT Event Wait Information
PROMPT ----------------------

select distinct  '   Instance Id                  : ' || x.inst_id || chr(10) ||
       '   SID '|| &sid_number ||' is waiting on event  : ' || x.event || chr(10) ||
       '   P1 Text                      : ' || x.p1text || chr(10) ||
       '   P1 Value                     : ' || x.p1 || chr(10) ||
       '   P2 Text                      : ' || x.p2text || chr(10) ||
       '   P2 Value                     : ' || x.p2 || chr(10) ||
       '   P3 Text                      : ' || x.p3text || chr(10) ||
       '   P3 Value                     : ' || x.p3
from gv$session_wait x
where x.sid= &sid_number
/


--PROMPT
--PROMPT Session Statistics
--PROMPT ------------------

--select        s.inst_id||'     '|| b.name  ||'             : '||decode(b.name, 'redo size', round(a.value/1024/1024,2)||' --M', a.value)
--from gv$session s, gv$sesstat a, gv$statname b
--where a.statistic# = b.statistic#
--and name in ('redo size', 'parse count (total)', 'parse count (hard)', 'user commits')
--and s.sid = &sid_number
--and a.sid = &sid_number
--order by b.name
--order by decode(b.name, 'redo size', 1, 2), b.name

/

PROMPT
PROMPT Sort Information
PROMPT ----------------

column username format a20
column user format a20
column tablespace format a20

SELECT distinct       '    Instance Id                                  : '||s.inst_id ||chr(10) ||
              '    Sid                                          : '||s.sid || chr(10) ||
              '    Sort Space Used(8k block size is asssumed    : '||u.blocks/1024*8 ||' M'             || chr(10) ||
              '    Sorting Tablespace                           : '||u.tablespace       || chr(10)||
              '    Sort Tablespace Type                 : '||u.contents || chr(10)||
              '    Total Extents Used for Sorting               : '||u.extents
FROM gv$session s, gv$sort_usage u
WHERE s.saddr = u.session_addr
AND s.sid = &sid_number
AND s.inst_id=u.inst_id
/


set heading on
set verify on

clear column

