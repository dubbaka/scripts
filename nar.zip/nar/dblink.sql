-- @dblink.sql



clear columns breaks computes

set lines 2000 pau off echo off trimspool on trim on
prompt Data from sys.link$
col name for a15
col userid for a15
col password for a10
col host for a80
select name, userid, password, host
from sys.link$
order by owner#;

prompt Data from dba_db_links
col DB_LINK for a15
col owner for a15
col USERNAME for a10
col host for a80
select owner, DB_LINK, USERNAME, HOST, CREATED
from dba_db_links
order by CREATED;


prompt Database link Creation statements
select 'create database link ' || rtrim(ltrim(name)) ||' '||'connect to '||rtrim(ltrim(userid)) || ' identified by ' || rtrim(ltrim(password)) ||' using ' || '''' || rtrim(ltrim(host)) ||'''' || ';' "DBLink"
from sys.link$
order by owner#; 
