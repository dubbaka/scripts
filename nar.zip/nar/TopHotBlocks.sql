/* @TopHotBlocks.sql
    show the hottest blocks in the buffer cache based on the touch count (TCH)
    Note: Should be run against sys schema
*/

clear columns computes breaks

col owner format a20
col object_name format a30
col touches format 9,999,999

set lines 200 pages 40

accept trgtRows number default 20 prompt 'Rows to display <20> : '

select *
from ( select o.name OBJECT_NAME, sum(tch) TOUCHES, file#, dbablk, u.name OWNER, count(*) Cnt
       from  x$bh x, obj$ o, user$ u
       where x.obj = o.obj#
       and   o.owner# = u.user#
       group by file#, dbablk, u.name, o.name
       order by 2 desc
     )
where rownum <= &trgtRows;
