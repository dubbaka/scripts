set verify off
set lines 1000
col opname format a25
col pctdone format 999
col mintogo format 9,999.90
accept trgtsid number default 0 prompt 'Limit to which SID : '
select s.sid,o.opname,s.sql_hash_value,o.sofar,o.totalwork,o.elapsed_seconds,
	round(o.time_remaining/60,2) mintogo,
	round(o.sofar/o.totalwork * 100,0) pctdone, o.message 
from v$session_longops o, v$session s
where o.sid = s.sid
and sofar < totalwork
and (o.sid = &trgtsid or &trgtsid = 0)
/

