select
   sid,name,value
from
   v$statname n,v$sesstat s
where
   n.STATISTIC# = s.STATISTIC# and
   name like 'session%memory%'
order by 3 asc;