set verify off
col proginfo format a25 trunc
col session_id format 99999 head SID
col status format a1 trunc
accept trgtobj char default ALL prompt 'Limit to which object <ALL> : '
select l.session_id, s.status, nvl(s.module,s.program) proginfo,
o.name, l.lock_type, l.mode_held, l.mode_requested, l.blocking_others
from dba_lock l, v$locked_object v, obj$ o, v$session s
where o.obj# = v.object_id
and v.session_id = l.session_id
and v.session_id = s.sid
and s.type != 'BACKGROUND'
and (o.name like upper('&trgtobj%') or upper('&trgtobj') = 'ALL')
order by 4,8;
