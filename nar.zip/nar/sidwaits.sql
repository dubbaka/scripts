/* sidwaits.sql
     see sesssions and what they are waiting on
	SDR-Oracle
*/
col event format a50 trunc
--col proginfo format a30
col umachine format a12 trunc
col sid format 999999
col p1p2p3txt format a30
col p2 format 9999999
col p3 format 9999999
col wait_sec format 999999
col process format a8
col spid for a8
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11
set lines 400

select w.inst_id,s.sid, floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET", 
w.event,w.SECONDS_IN_WAIT Wait_Sec,	w.p1 || ':' || w.p2 || ':' || w.p3 p1p2p3txt,
	s.sql_hash_value, s.process,p.spid, 
	s.machine umachine,
       nvl(s.module,'UNKnown') proginfo
from gv$session_wait w, gv$session s, gv$process p
 where 
w.inst_id=s.inst_id
and w.sid = s.sid
and s.inst_id=p.inst_id
and s.paddr = p.addr
and w.event not like 'SQL*Net%client'
and w.event not like '%timer%'
and w.event not like 'rdbms ipc%'
and w.event not like 'pipe get%'
and w.event not like '%manager%'
and w.event not like 'queue message%'
and w.event not like 'Streams%'
and w.event not in ('DIAG idle wait','gcs remote message','ges remote message')
--and w.wait_time = 0
order by w.inst_id,w.event,wait_sec desc
/

