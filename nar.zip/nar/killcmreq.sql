/* killcmreq.sql
     kill a concurrent manager request in the apps.
     note: this only flips the phase and status flags,
           it does NOT actually kill the o/s processes.
     this processs does not issue a commit.
     use the script cmreq.sql to view/verify the results.
*/
set verify off
set feedback on
accept reqid number default 0 prompt 'What is the concurrent request id <0> : '
update applsys.fnd_concurrent_requests
   set phase_code = 'C',
       status_code = 'X',
	actual_completion_date = sysdate
  where request_id = &reqid
   and phase_code in ('P','R')
   and status_code in ('W','R','A','Z','T')
   and &reqid > 0;

