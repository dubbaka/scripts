/* pxslave.sql 
     find the qc for a slave performning parallel query
*/
break on qcsid on qc_hash_value on qs_hash_value nodup
set verify off
col event format a25 trunc
col sid format 99999
col qcsid format 99999
accept trgtslave char default ALL prompt 'What is the Slave <ALL> : '
select s.qcsid, n1.sql_hash_value qc_sql_hash_value,
       p.sid,p.server_name,
       n2.sql_hash_value qs_sql_hash_value, w.event, w.p1, w.p2, w.p3
from v$session n1, v$session n2, v$px_session s, v$px_process p, v$session_wait w
where s.sid = p.sid
and n1.sid = s.qcsid
and n2.sid = p.sid
and ((p.server_name = upper('&trgtslave')) or upper('&trgtslave') = 'ALL')
and w.sid = s.sid
order by 1,4;


