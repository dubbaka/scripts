REM NAME:   @tablefrag.SQL
REM USAGE: tfsldtr table_owner table_name
REM ------------------------------------------------------------------------ 
REM REQUIREMENTS: ANALYZE on table, SELECT on DBA_TABLES, DBA_SEGMENTS, DBA_EXTENTS 
REM AUTHOR:  
REM    Craig A. Shallahamer, Oracle US      
REM PURPOSE: 
REM    Load the my_tfrag table with a given table's fragmentation stats. 
REM    This script displays summary table  fragmentation  information.  The  
REM    information is queried from the tfrag table which  is  loaded via the  
REM    ldtfrag script.  Once the ldtfrag script has been run for a given  
REM    table, this report displays the  following information:  
REM 
REM      - Table owner  
REM      - Table name  
REM      - Segment fragmentation (number of extents)  
REM      - Number of table rows  
REM      - Table block fragmentation (1.0 bad, 0.0 good)  
REM      - Row fragmentation (chains)  
REM ------------------------------------------------------------------------
REM EXAMPLE: 
REM                          Table Fragmentation Characteristics 
REM 
REM    Owner    Table Name                               Exts Omega1  Chains 
REM    -------- ---------------------------------------- ---- ------ -------
REM    scott    s_emp                                       1  0.000       0 
REM ------------------------------------------------------------------------

set feedback on time on timing on echo on
  
def towner=&1
def tname=&2
 
rem *******************************************************************  
rem * Goal: Create a temporary table to hold the data gathered
rem *******************************************************************  
--truncate table my_tfrag;
--drop table my_tfrag;
--create table my_tfrag (
--  owner			varchar2(30) not null,
--  name			varchar2(30) not null,
--  hwm				number,
--  allocated_blocks            number,
--  blks_w_rows			number,
--  empty_blocks		number,
--  num_rows			number,
--  chain_cnt			number,
--  extents			number,
--  avg_row_len			number,
--  avg_space			number,
--  tablespace			varchar2(30),
--  pcttfree			number,
--  pcttused			number,
--  initrans			number,
--  maxtrans			number,
--  initextent			number,
--  nextextent			number,
--  pctinc			number,
--  minextents			number,
--  maxxextents			number,
--  freelists			number,
--  freelistgrps		number,
--  avgspacefreelistblks	number,
--  numfreelistblks		number,
--  sbytes			number
--);
--create unique index my_tfrag_u1 on my_tfrag (owner,name);

rem *******************************************************************  
rem * Goal: Analyze table to gather statistics
rem *******************************************************************  
rem Specifically we are looking for:  
rem    - blocks ABOVE the hwm, i.e. empty blocks (dba_tables.blocks)  
rem    - average row length (dba_tables.blocks)  
--prompt Running -- analyze table &towner..&tname estimate statistics sample 10 percentage;
--analyze table &towner..&tname estimate statistics sample 10 percent;



rem *******************************************************************  
rem * Goal: Get the number of blocks used, blocks empty, number of rows and Chained Frows in the table
rem *******************************************************************
col val1 new_value blks_w_rows noprint
col val2 new_value blks_above  noprint
col val3 new_value numrows noprint
col val4 new_value cr noprint
col val5 new_value avglen noprint
col val6 new_value avgspace noprint
col val7 new_value tblsp noprint
col val8 new_value pctfree noprint
col val9 new_value pctused noprint
col val10 new_value initran noprint
col val11 new_value maxtran noprint
col val12 new_value inixtnt noprint
col val13 new_value nxtxtnt noprint
col val14 new_value pctinc noprint
col val15 new_value minxtnts noprint
col val16 new_value maxtnts noprint
col val17 new_value lists  noprint
col val18 new_value listgrps noprint
col val19 new_value avspflblks  noprint
col val20 new_value numflblks noprint
select nvl(blocks,0) val1, nvl(empty_blocks,0) val2, nvl(num_rows,0) val3, nvl(chain_cnt,0) val4, nvl(AVG_ROW_LEN,0) val5, nvl(AVG_SPACE,0) val6
, TABLESPACE_NAME val7, nvl(PCT_FREE,0) val8, nvl(PCT_USED,0) val9, nvl(INI_TRANS,0) val10, nvl(MAX_TRANS,0) val11, nvl(INITIAL_EXTENT,0) val12
, nvl(NEXT_EXTENT,0) val13, nvl(PCT_INCREASE,0) val14, nvl(MIN_EXTENTS,0) val15, nvl(MAX_EXTENTS,0) val16, nvl(FREELISTS,0) val17
, nvl(FREELIST_GROUPS,0) val18, nvl(AVG_SPACE_FREELIST_BLOCKS,0) val19, nvl(NUM_FREELIST_BLOCKS,0) val20
from   dba_tables  
where  owner = upper('&towner')
and    table_name = upper('&tname');


rem *******************************************************************  
rem * Goal: Get the number of blocks allocated to the segment  
rem *******************************************************************
rem Specifically we are looking for: 
rem   - allocated blocks dba_segments.blocks  
col val1 new_value alloc_blocks noprint
col val2 new_value xtnts noprint
col val3 new_value sizebytes noprint
select nvl(blocks,0) val1, nvl(extents,0) val2, nvl(bytes,0) val3
from   dba_segments
where  owner        = upper('&towner')
and    segment_name = upper('&tname');


rem *******************************************************************  
rem * Goal: Calculate the HWM 
rem Specifically we are looking for:  
rem   - HWM = dba_segments.blocks - dba_tables.empty_blocks - 1  
rem   - HWM = allocated blocks - blocks above the hwm - 1
rem *******************************************************************  
col val1 new_value hwm noprint
select &alloc_blocks-&blks_above-1 val1
from   dual;  


rem ***********************************************************
rem * Delete existing data for this segment
rem ***********************************************************
delete from my_tfrag where owner='&towner' and  name='&tname';


rem ***********************************************************  
rem * Load the TFRAG table with the information just gathered 
rem ***********************************************************
insert into my_tfrag
   (owner, name, hwm, allocated_blocks, blks_w_rows, empty_blocks, num_rows, chain_cnt
  , extents, avg_row_len, avg_space, tablespace, pcttfree, pcttused, initrans
  , maxtrans, initextent, nextextent, pctinc, minextents, maxxextents, freelists
  , freelistgrps, avgspacefreelistblks, numfreelistblks, sbytes)
   values
   ('&towner', '&tname', &hwm, &alloc_blocks, &blks_w_rows, &blks_above, &numrows, &cr
   , &xtnts, &avglen, &avgspace, '&tblsp', &pctfree, &pctused, &initran
   , &maxtran, &inixtnt, &nxtxtnt, &pctinc, &minxtnts, &maxtnts, &lists
   , &listgrps, &avspflblks, &numflblks, &sizebytes);
commit;


rem ***********************************************************  
rem * Display the information just gathered 
rem ***********************************************************  
clear columns breaks computes 
set lines 200 pages 2000 wrap off trim on
col owner heading 'Owner'      format a12
col name  heading 'Table Name' format a30
col exts   heading 'Exts'       format 999,999,999
col omega1 heading 'Omega1'     format 0.999
col "SizeMB" for 999,999.99
col chains heading 'Chains'     format 999,990
col num_rows for 999,999,999
spool spool\tf_05May08_fob
select owner, trim(name), (hwm - blks_w_rows)/(hwm + 0.0001) omega1, num_rows, sbytes/(1024*1024) "SizeMB", EXTENTS, CHAIN_CNT, tablespace
from   my_tfrag
order  by omega1 desc;
spool off

set echo off
