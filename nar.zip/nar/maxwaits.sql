col username format a10 trunc
col machine format a10 trunc
col module format a15 trunc
col program format a15 trunc
select * from (
select s.sid,e.max_wait,e.total_waits,e.time_waited,s.username, s.machine,s.module,
s.program
from v$session s , v$session_event e
where s.sid = e.sid
and e.event = 'db file sequential read'
and e.max_wait > 100
order by 2 desc)
where rownum < 11
/
