/* @cmlast10jobs.sql
	copied from jobhistdet.sql
      find the details of all jobs run for the given job id.
      use cmjobid.sql to find a ccmgr job id if you have either the regular or short name
*/

clear column break compute
set lines 2000 pages 40

col request_id head "Request ID"
col "REQUESTED_BY" for a30 trunc
col actstrtdte head "Started On" format a16
col actcmpldte head "Finished On" format a16
col "ElapsedMins" for 999,999.09
col printer for a10
col DESCRIPTION for a12 trunc
col CONTROLLING_MANAGER head "CONTROLLING|MANAGER" for 99999999
col COMPLETION_CODE head "COMPLETION|CODE" for a10
col COMPLETION_TEXT for a20
col LOGFILE_NAME for a30
col LOGFILE_NODE_NAME head "LOGFILE_NODE" for a15
col OUTFILE_NAME for a30
col OUTFILE_NODE_NAME head "OUTFILE_NODE" for a15
col EMAIL_ADDRESS head "Email" for a50
col argument_text head Arguments format a132
col PHASE_CODE head "Ph|Cd" for a2
col STATUS_CODE head "St|Cd" for a2

accept progid number default 0 prompt 'What is the program ID : '

select * from (
   select FCR.REQUEST_ID, FU.USER_NAME||FU.DESCRIPTION "REQUESTED_BY", FCR.PHASE_CODE, FCR.STATUS_CODE
        , to_char(FCR.actual_start_date,'ddMonyy hh24:mi:ss') actstrtdte
        , to_char(FCR.actual_completion_date,'ddMonyy hh24:mi:ss') actcmpldte, 
         (nvl(FCR.actual_completion_date,sysdate)-FCR.actual_start_date)*1440 "ElapsedMins", FCR.PRINTER,
          FCR.LOGFILE_NAME, FCR.LOGFILE_NODE_NAME, FCR.LFILE_SIZE, FCR.OUTFILE_NAME,
          FCR.OUTFILE_NODE_NAME, FCR.OFILE_SIZE, FU.EMAIL_ADDRESS, FCR.CONTROLLING_MANAGER, FCR.COMPLETION_CODE,
          FCR.COMPLETION_TEXT, FCR.PHYSICAL_IOS, FCR.CPU_SECONDS, FCR.LOGICAL_IOS, FCR.DESCRIPTION, FCR.ARGUMENT_TEXT
   from   applsys.fnd_concurrent_requests FCR, fnd_user FU
   where  FCR.concurrent_program_id = &progid
   and    FCR.actual_start_date is not null
   and    FCR.REQUESTED_BY = FU.user_id
   order  by actual_start_date desc)
where  rownum < 11
order  by 5;

clear column break compute
