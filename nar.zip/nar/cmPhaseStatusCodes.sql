-- @CMPhaseStatusCodes.sql


clear columns breaks computes

col "PhaseCode" for a9
col "Statuscode" for a10
col "Description" for a15

select B.lookup_code "PhaseCode", B.meaning "Description"
from   applsys.fnd_lookup_values B
where  B.lookup_type = 'CP_PHASE_CODE'
and    B.language = 'US'
and    B.enabled_flag = 'Y'
and   (B.start_date_active <= sysdate and B.start_date_active is not null)
and   (B.end_date_active > sysdate or B.end_date_active is null)
order by B.lookup_code;

select B.lookup_code "Statuscode", B.meaning "Description"
from   applsys.fnd_lookup_values B
where  B.lookup_type = 'CP_STATUS_CODE'
and    B.language = 'US'
and    B.enabled_flag = 'Y'
and   (B.start_date_active <= sysdate and B.start_date_active is not null)
and   (B.end_date_active > sysdate or B.end_date_active is null)
order by B.lookup_code;
