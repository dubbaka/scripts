-- @BadPlSql.sql

/* Value 47 for command_type identifies PL/SQL code; this helps you see how much they contribute to the total number of logical reads. 
   Any call to a PL/SQL anonymous block or stored procedure is recorded inside V$SQL, with its number of executions, its number of physical reads, 
   and, most importantly, the number of logical reads (buffer_gets) it required */

clear columns breaks computes
col inst_id for 99 head "Inst|Id"
col sql_text format a80

accept trgtRows number default 20 prompt 'Rows to display <20> : '

select * from (
select inst_id, buffer_gets, round(100 * buffer_gets / t.tot, 1) PCT, sql_text
from   gv$sql, (select sum(buffer_gets) tot from gv$sql where command_type != 47 and executions > 0) t
where  command_type = 47
and    executions > 0
and    round(100 * buffer_gets / t.tot, 1) > 1
order  by 2 desc)
where rownum <= &trgtRows;
