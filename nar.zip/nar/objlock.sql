set verify off
col OBJECT_NAME format a30
col proginfo format a25 trunc
col session_id format 99999 head SID
col status format a5 trunc
col mode_held format a15
col mode_requested format a15 
col blocking_others format a25
accept trgtobj char default ALL prompt 'Limit to which object <ALL> : '

select s.inst_id,v.session_id, s.status, nvl(s.module,s.program) proginfo,
o.object_name
from gv$locked_object v, dba_objects o, gv$session s
where o.object_id = v.object_id
and v.inst_id=s.inst_id
and v.session_id = s.sid
and s.type != 'BACKGROUND'
and (o.object_name like upper('&trgtobj%') or upper('&trgtobj') = 'ALL')
order by 1,2; 
