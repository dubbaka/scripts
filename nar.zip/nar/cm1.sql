set linesize 150
set pages 999
set echo off
set trimspool on
set feedback on
set termout on

COLUMN request_id              HEADING 'Request Id' FORM 9999999999 TRUNC
COLUMN concurrent_program_id   HEADING 'CP ID'    FORM 99999999    TRUNC
COLUMN concurrent_program_name HEADING 'CP Name'  FORM a30      TRUNC
COLUMN pgm_name                HEADING 'Program Name'  FORM a60 TRUNC
COLUMN sid                     HEADing 'Sid'      FORM 9999  
COLUMN user_name               HEADING 'App User' FORM a18       TRUNC
COLUMN runtime                 HEADING 'Minutes '    FORM 99990.9  TRUNC
COLUMN concurrent_queue_name   HEADING 'Queue  '  FORM a25      TRUNC
COLUMN node                    HEADing 'INST|ID'     FORM 9        TRUNC
COLUMN oracle_process_id       HEADing 'Pid'      FORM a10  
column inst_name               Heading 'Inst Name' FORM A10

def aps_prog    = 'cm.sql'
def aps_title   = 'Concurrent Manager Process Information'

start apstitle

SELECT 
a.request_id,
       t.USER_CONCURRENT_PROGRAM_NAME pgm_name,
       d.user_name,
       (sysdate-a.actual_start_date)*24*60 runtime,
       a.status_code,
       a.phase_code
FROM   apps.fnd_concurrent_requests a,
       apps.fnd_concurrent_programs b,
       apps.fnd_concurrent_programs_tl t,
       apps.fnd_concurrent_processes c,
       apps.fnd_user d
WHERE  
a.phase_code = 'R' and
--hold_flag='Y'
-- trunc(requested_start_date)=trunc(sys_date)
    a.concurrent_program_id = b.concurrent_program_id
  AND  a.program_application_id = b.application_id
  AND  a.concurrent_program_id = t.concurrent_program_id
  AND  a.program_application_id = t.application_id
  AND  c.concurrent_process_id = a.controlling_manager
    AND  d.user_id = a.requested_by
  AND  t.source_lang='US'
  group by a.request_id,a.concurrent_program_id,t.USER_CONCURRENT_PROGRAM_NAME,d.user_name,
      (sysdate-a.actual_start_date)*24*60,
       a.status_code,  a.phase_code
ORDER BY  (sysdate-a.actual_start_date)*24*60 desc
/

--start pending
--start running

--start apsclear

