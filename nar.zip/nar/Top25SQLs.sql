-- @tu_Top25SQLs.sql


/* Tuning the top 25 buffer get and top 25 physical get queries has yielded system performance gains of anywhere from 5 percent to 5000 percent.
   The SQL section of the statspack report tells you which queries to potentially tune first.
*/

clear columns breaks computes

set feed off echo off lines 1200 veri off echo off wrap on pages 40
col "DispDateNow" for a22
col sqltext for a1000
col USER_NAME for a15
col SID 99999

col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDMonYYYYhh24miss') "datenow" from dual;
set feed on

--spool spool\tu_Top25SQLs_&_MyDateNow._&_MyDB1.

select to_char(sysdate, 'dd-Mon-YYYY hh24:mi:ss') "DispDateNow" from dual;

prompt 
prompt Finding top25 problem queries with high buffer_gets or logical reads
select * from
   (select buffer_gets, HASH_VALUE, replace(sql_text,'  ','') sqltext from v$sqlarea where buffer_gets > 100000 order by buffer_gets desc)
where rownum <= 25;

-- Top 10 as % of All buffer_gets
prompt 
prompt   The top 10 percent of SQL statements should not be more than 10 percent of buffer gets or disk reads. */
select sum(pct_bufgets) percent
from   (select rank() over ( order by buffer_gets desc ) as rank_bufgets, to_char(100 * ratio_to_report(buffer_gets) over (), '999.99') pct_bufgets from v$sqlarea)
where rank_bufgets< 11;


prompt 
prompt Finding top25 problem queries with high disk_reads or physical reads
select * from
   (select disk_reads, HASH_VALUE, replace(sql_text,'  ','') sqltext from v$sqlarea where disk_reads > 100000 order by disk_reads desc)
where rownum <= 25;

prompt 
prompt Finding the top 25 largest amount of logical reads per user
select * from
(Select unique A.User_Name, B.Disk_Reads, B.Buffer_Gets, (B.Disk_Reads+B.Buffer_Gets) "LogicalReads", B.Rows_Processed, B.HASH_VALUE, replace(B.SQL_Text,'  ','') sqltext
From   V$Open_Cursor A, V$SQLArea B
Where  A.Address = B.Address
Order  By B.Buffer_Gets desc, A.User_Name)
where rownum <= 25;

prompt 
prompt Finding the top 25 largest amount of physical reads per user
select * from
(Select unique A.User_Name, B.Disk_Reads, B.Buffer_Gets, (B.Disk_Reads+B.Buffer_Gets) "LogicalReads", B.Rows_Processed, B.HASH_VALUE, replace(B.SQL_Text,'  ','') sqltext
From   V$Open_Cursor A, V$SQLArea B
Where  A.Address = B.Address
Order  By B.Disk_Reads desc, A.User_Name)
where rownum <= 25;

--spool off
