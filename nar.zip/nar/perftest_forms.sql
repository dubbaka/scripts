col application_short_name format a10 head AppName
col user_form_name format a45 head FormName
select application_short_name, user_form_name, to_char(start_time, 'HH24') HRS, count(*) NUM_RUNS
from applsys.fnd_login_resp_forms l, applsys.fnd_form_tl f, applsys.fnd_application a
where l.form_appl_id = f.application_id
and l.form_id = f.form_id
and f.application_id = a.application_id
and f.language = 'US'
and l.start_time > '30-APR-2002'
and to_char(l.start_time, 'DAY') NOT LIKE 'SUNDAY%'
AND to_char(l.start_time, 'DAY') NOT LIKE 'SATURDAY%'
and 	to_char(l.start_time, 'HH24') between '09' and '19'
group by application_short_name, user_form_name, to_char(start_time, 'HH24');
