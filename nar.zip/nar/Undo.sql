clear breaks computes columns

col TABLESPACE_NAME for a15 heading TABLESPACE
col FILE_NAME       for a60
col AUTOEXTENSIBLE for a9 heading "AUTO(Y/N)"
col "Bytes(MB)"    for 9,999,999
col "MaxBytes(MB)" for 9,999,999,999
col "%Used"        for 999.99
col "%Free"        for 999.99

set lines 132 veri off

select A.TABLESPACE_NAME, B.FILE_NAME, B.BYTES/(1024*1024) "Bytes(MB)", B.MAXBYTES/(1024*1024) "MaxBytes(MB)", B.AUTOEXTENSIBLE,
       (B.BYTES/nvl(B.MAXBYTES,0))*100 "%Used", (B.MAXBYTES-B.Bytes)*100/B.MAXBYTES "%Free"
from   dba_tablespaces A, dba_data_files B
where  
--A.CONTENTS = 'UNDO' and    
B.TABLESPACE_NAME like '%UNDO%'
and A.TABLESPACE_NAME=b.tablespace_name
order  by FILE_ID;
