-- @Top50TableHighRows.sql
-- It is assumed Gather Schema stats are run on a regular basis


clear columns computes breaks

set pages 100

col table_name for a30
col num_rows for 999,999,999,999
col EMPTY_BLOCKS for 999,999,999,999
col CHAIN_CNT for 999,999,999,999
col BUFFER_POOL for a12


select * from (
select table_name, num_rows, EMPTY_BLOCKS, CHAIN_CNT, BUFFER_POOL
from   dba_tables
where  num_rows > 50000
order  by num_rows desc)
where  rownum <= 50;
