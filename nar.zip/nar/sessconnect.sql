set echo off
set feed off
alter session set nls_date_format='DD-MON-YYYY:HH24:MI:SS'
/
set echo on
select sysdate "Run time(IN PST)" from dual
/
set echo on
select name "DB NAME" from v$database
/

select status,count(*) "TOTAL # of CONNECTIONS" from gv$session group by status
/

select inst_id INSTANCE_ID,status STATUS,count(*) TOTAL  from gv$session group by status,inst_id
order by status
/
select count(*) "TOTAL # of CONNECTIONS" from gv$session
/

select substr(machine,10,6) "Internal/External",count(*) "CONNECTIONS" from gv$session
where machine like 'p%zone%' group by substr(machine,10,6)
/

select machine "Internal/External",count(*) "CONNECTIONS" from gv$session
--where machine like 'p%zone%'
group by machine
/
select count(*) "ACTIVE-CONCURRENT FORMS/JAVA" from gv$session
where (action like 'FRM%' or action like '%_JAVA%') and status='ACTIVE'
/

select status,count(*) "TOTAL # of FORMS CONNECTIONS" from gv$session
where  action like 'FRM%' group by status
/
