/* pxprocs.sql 
     monitor which sessions are performning parallel query
*/
break on qcsid on qc_hash_value on qs_hash_value nodup
set verify off
col event format a25 trunc
col sid format 99999
col qcsid format 99999
col slave_numrows format 999999999 head SlvRows
accept trgtqcsid number default 0 prompt 'What is the QC SID : '
accept trgtevent char default ALL prompt 'What is the wait event <ALL> : '
select s.qcsid, n1.sql_hash_value qc_sql_hash_value,
       p.sid,p.server_name, 
       n2.sql_hash_value qs_sql_hash_value, w.event, w.p1, w.p2, w.p3
from v$session n1, v$session n2, v$px_session s, v$px_process p, v$session_wait w
where s.sid = p.sid
and n1.sid = s.qcsid
and n2.sid = p.sid
and ((s.qcsid = &trgtqcsid) or &trgtqcsid = 0)
and w.sid = s.sid
and (w.event like '&trgtevent' or '&trgtevent' = 'ALL')
order by 1,4;

