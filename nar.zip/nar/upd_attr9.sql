update OE_PRICE_ADJUSTMENTS opa1 set opa1.header_id = 798173
where opa1.price_adjustment_id in
( select opa.price_adjustment_id from OE_PRICE_ADJUSTMENTS opa, oe_order_lines_all ool,
oe_order_headers_all ooh where ooh.header_id = ool.header_id
and opa.line_id = ool.line_id
and opa.line_id in (2203666, 2203670, 2204023, 2204026, 2204238, 2325178)
and ooh.header_id = 798173 and ooh.header_id <> opa.header_id);
