/* cmlongReqsSelfGTx.sql
     monitor script to list the ccmgr jobs running longer than x minutes
       and exceeding the average historical runtime for this particular job
*/

clear col break compute

set pages 40 pau on

col qname head "Concurrent Manager Queue" for a40
col phase_code head "P|H|A|S|E" for a1
col status_code head "S|T|A|T|U|S" for a1
col "RunTimeMins" head "RunTime|(Mins)" for 999,999
col intprog for a30 head "Internal Name"
col program for A80 head "Program Full Name"

accept trgtMINs number default 10 prompt 'Requests that ran for more than minutes (10): '

prompt ccmgr jobs running longer than &trgtMINs minutes and exceeding the average historical runtime for this particular job

select q.concurrent_queue_name || ' - ' || target_node qname, a.request_id, a.phase_code, a.status_code
      ,(nvl(actual_completion_date,sysdate)-actual_start_date)*1440 "RunTimeMins"
      ,c.concurrent_program_name  intprog, c.concurrent_program_id "PgmId"
      ,ctl.user_concurrent_program_name "program"
from APPLSYS.fnd_Concurrent_requests a,
     APPLSYS.fnd_concurrent_processes b
    ,applsys.fnd_concurrent_queues q
    ,APPLSYS.fnd_concurrent_programs c
    ,APPLSYS.fnd_concurrent_programs_tl ctl
where a.controlling_manager = b.concurrent_process_id
  and a.concurrent_program_id = c.concurrent_program_id
  and a.program_application_id = c.application_id
  and a.phase_code in ('I','P','R','T')
  and b.queue_application_id = q.application_id
  and b.concurrent_queue_id = q.concurrent_queue_id
  and ctl.concurrent_program_id = c.concurrent_program_id   
  and ctl.language = 'US'
  and (nvl(actual_completion_date,sysdate)-actual_start_date)*1440 > &trgtMINs
  and (nvl(actual_completion_date,sysdate)-actual_start_date)*1440 > 
   ( select avg(nvl(a2.actual_completion_date-a2.actual_start_date,0))*1440
       from APPLSYS.fnd_Concurrent_requests a2,
	    APPLSYS.fnd_concurrent_programs c2
      where c2.concurrent_program_id = c.concurrent_program_id
        and a2.concurrent_program_id = c2.concurrent_program_id
        and a2.program_application_id = c2.application_id
        and a2.phase_code || '' = 'C'
   )
order by 5 asc;

set pages 2000 pau off
