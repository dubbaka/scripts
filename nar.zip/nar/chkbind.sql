rem * Description       : bla bla bla
rem * Usage             : start nobind.sql
rem ********************************************************************

def aps_prog    = 'nobind.sql'
def aps_title   = 'SQL Statements not using Bind Variables'
start apstitle
set pagesize 30
set linesize 100

col TEXT format a62
col executions  format 9,999
col Total_MEM   format 999,999,990

comp sum of executions Total_MEM on report
break on report

select substr(sql_text,0,80) "TEXT" , max(module), count(*) "executions", sum(sharable_mem+PERSISTENT_MEM+RUNTIME_MEM) "Total_MEM"
from v$sqlarea
where executions = 1
and loads = 1
group by substr(sql_text,0,80)
having count(*) > 2
order by 4  desc
/
