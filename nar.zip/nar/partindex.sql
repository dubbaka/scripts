-- @partindex.sql


clear columns breaks computes

break on report
compute sum of num_rows on report

set wrap on verify off lines 300

col owner for a10
col INDEX_OWNER for a10
col index_name for a30
col table_name for a30
col PARTITION_NAME for a30
col def_tablespace_name for a20 head 'Def Tablespace'
col TABLESPACE_NAME for a20 head 'Tablespace'
col PARTITION_POSITION for 999 head "Position"
col initial_extent heading "Initial|Extent"
col next_extent heading "Next|Extent"
col num_rows for 999,999,999

accept NdxName char default ALL prompt 'Index: <ALL>'
accept TblName char default ALL prompt 'Table: <ALL>'

select OWNER, INDEX_NAME, DEF_TABLESPACE_NAME, TABLE_NAME, PARTITIONING_TYPE, PARTITION_COUNT, SUBPARTITIONING_TYPE, SUBPARTITIONING_KEY_COUNT
from   DBA_PART_INDEXES
where  (upper(table_name) = upper('&TblName') or upper('&TblName') = 'ALL')
and    (upper(index_name) like upper('&NdxName%') or upper('&NdxName') = 'ALL')
order  by index_name;


prompt Displaying Partition Names for Index &NdxName
select INDEX_OWNER, INDEX_NAME, PARTITION_NAME, TABLESPACE_NAME, NUM_ROWS, PARTITION_POSITION, SUBPARTITION_COUNT, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENT, MAX_EXTENT, FREELISTS, FREELIST_GROUPS
from   DBA_IND_PARTITIONS
where  upper(index_name) like upper('&NdxName%')
order  by  INDEX_NAME, PARTITION_POSITION;


prompt Displaying sizes of indexes for index &NdxName
accept tgtEnter char prompt 'Press Enter to continue...'

select owner, segment_type, SEGMENT_SUBTYPE, segment_name, PARTITION_NAME, (bytes/1024) "SizeKB", bytes/(1024*1024) "SizeMB"
from   dba_segments
where  segment_name = upper('&NdxName'));
