/* whereami.sql
provides info on db instance, server etc for your session
*/
set pause off
set pages 24
set lines 132
col SERVER format a10 trunc
col program format a30 trunc
col username format a10 trunc
col sid format 9999
col serial# format 99999 head SRL#
col value format a6 head THREAD
col spid head OSProc
col thread# head THREAD format 999
col open_mode head DBSTAT
col startedon format a13 
select p.machine SERVER, d.name DBNAME, i.thread#, i.status ISTAT, 
       to_char(i.startup_time,'mm/dd hh:miAM') startedon,
       u.username, u.sid, u.serial#, u.program, o.spid
  from v$database d, v$instance i, v$session p, v$session u, v$process o
 where p.sid = 1
   and u.sid =  (select sid from v$mystat where rownum = 1)
   and o.addr = u.paddr;
clear columns


