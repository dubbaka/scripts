-- @CMLogfile.sql

clear columns breaks computes

col "CMLogFile" for a30

select '$APPLCSF/log/w'||CONTROLLING_MANAGER||'.mgr' "CMLogFile", request_id
from   fnd_concurrent_requests
where  request_id = &Request;