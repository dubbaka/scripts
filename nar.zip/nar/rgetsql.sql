break on sql_id
set lines 80
set trimspool on

select sql_id, sql_text
from gv$sqltext
where (sql_id,inst_id) in
        (select sql_id,inst_id from
                gv$session where sid = &sid and inst_id=&inst_id)
order by piece
/

