/* bbwfiles.sql
	see top 10 buffer busy waits by datafiles
*/
set verify off
col fname format a25 trunc head "FileName (#)"
col filesys format a5 head MTPT
col wtime format 99,999,999
col avgwtime format 999,999.990 head AvgWait
accept trgtmtpt char default ALL prompt 'Restrict to which mount point <ALL> : '
accept trgtfile char default ALL prompt 'Restrict to which filename <ALL> : '
prompt Note: wtime and avgwait are in seconds.....
select * from (
select w.indx,
	w.count,
	w.time/100 wtime,
	((w.time/100) / decode(w.count,0,1,w.count)) avgwtime,
	substr(f.name,8,(instr(f.name,'/',9,1) -8)) FILESYS,
	substr(f.name,(instr(f.name,'/',-1,1)+1)) || ' (' || f.file# || ')' fname
 from sys.x$kcbfwait w, v$datafile f
where w.indx + 1 = f.file#
  and (upper(substr(f.name,8,(instr(f.name,'/',9,1) -8))) = upper('&trgtmtpt') or upper('&trgtmtpt') = 'ALL')
  and (upper(substr(f.name,(instr(f.name,'/',-1,1)+1))) like upper('&trgtfile%') or upper('&trgtfile') = 'ALL')
 order by 3 desc)
where rownum < 11;

