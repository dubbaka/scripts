-- @db.sql



set wrap on feed off
clear columns breaks compute

col DB_UNIQUE_NAME for a15
col "CreatedOn" for a9
col CONTROLFILE_TYPE  head "CtrlFile|Type" for a12
col "CtrlFileCreated" head "CtrlFile|Created" for a9
col "RemoteArchive" for a13
col "Role" for a10
col NAME for a8
col PROTECTION_LEVEL for a20
col ARCHIVELOG_CHANGE# for 9999999999999
col CURRENT_SCN for 9999999999999
col PLATFORM_NAME for a30
col HOST_NAME for a15
col INSTANCE_NAME for a8 head "Instance"
col VERSIOn for a10
col PARALLEL for a3 head "Pll"
col "StartupTime" for a9 head "Startup|Time"
col ARCHIVER for a8
col SHUTDOWN_PENDING for a8 head "Shutdown|Pending"
col DATABASE_STATUS for a8 head "Database|Status"
col ACTIVE_STATE for a6 head "Active|State"
col BLOCKED for a7
col INSTANCE_NUMBER head "Inst#" for 9999
col LOG_SWITCH_WAIT for a15
col COMP_ID for a15
col COMP_NAME for a35
col VERSION for a10
col CONTROL for a8
col STATUS for a7
col SCHEMA for a10
col MODIFIED for a22
col PROCEDURE for a45
col "Character Set" for a15
col PARAMETER  for a64
col VALUE for a64
col OTHER_SCHEMAS for a60

spool spool\db_&_MyDB1.

select *
from   dba_registry;

select NAME, to_char(CREATED, 'DD-Mon-YY hh:mi:ss AM') "CreatedOn", DATABASE_ROLE "Role", LOG_MODE, OPEN_MODE
     , CONTROLFILE_TYPE, to_char(CONTROLFILE_CREATED, 'DD-Mon-YY hh:mi:ss AM') "CtrlFileCreated"
     , OPEN_RESETLOGS "OpenRstLogs", PROTECTION_MODE, PROTECTION_LEVEL, REMOTE_ARCHIVE "RemoteArchive"
     , ACTIVATION#, ARCHIVELOG_CHANGE#
-- , FLASHBACK_ON, PLATFORM_NAME, CURRENT_SCN, DB_UNIQUE_NAME
from   v$database;

select INSTANCE_NUMBER, INSTANCE_NAME, HOST_NAME, VERSION, to_char(STARTUP_TIME, 'DD-Mon-YY hh:mi:ss AM') "StartupTime"
     , STATUS, PARALLEL, THREAD#, ARCHIVER, LOGINS, SHUTDOWN_PENDING, DATABASE_STATUS, INSTANCE_ROLE
     , ACTIVE_STATE, LOG_SWITCH_WAIT
--, BLOCKED
from   v$instance;

col PROPERTY_NAME for a30
col PROPERTY_VALUE for a50
col DESCRIPTION for a75

select *
from   database_properties
where  property_name = 'DEFAULT_TEMP_TABLESPACE';

select username, temporary_tablespace
from   dba_users
where  temporary_tablespace = 'SYSTEM'
order  by username;

select value "Character Set"
from   V$NLS_PARAMETERS
where  parameter='NLS_CHARACTERSET';

select PARAMETER , VALUE
from   V$NLS_PARAMETERS; 

spool off
