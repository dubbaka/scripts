set verify off
prompt Note - times are expressed in decimal minutes
col qname head "Activated Concurrent Queue" format a26
col actual head "Actual" format 999999
col target head "Target" format 999999
col minr head MinRTime format 9999.99
col maxr head MaxRTime format 9999.99
col avgr head AvgRun format 9999.99
col avgq head AvgQTime format 9999.99
col totreq head "# Jobs" format 99999
col qname head "Queue Name" format a25 trunc
clear breaks
clear computes
accept trgtqname char default NONE prompt 'Limit to which ccmgr queue name <NONE> : '
accept trgtprog char default ALL prompt 'Limit to which ccmgr job name <ALL> : '
accept trgtdte char default TODAY prompt 'Limit to what date (dd-mon-yyyy) <today> : '
select  q.concurrent_queue_name || '(' || q.target_node || ')' qname,
	count(r.request_id) totreq,
       q.running_processes actual,
       q.max_processes target,
       avg((r.actual_start_date - r.requested_start_date)*1440)   avgq,
       min((r.actual_completion_date - r.actual_start_date)*1440) minr,
       max((r.actual_completion_date - r.actual_start_date)*1440) maxr,
       avg((r.actual_completion_date - r.actual_start_date)*1440) avgr
  from applsys.fnd_concurrent_requests r,
       applsys.fnd_concurrent_processes p,
       applsys.fnd_concurrent_programs g,
       applsys.fnd_concurrent_queues q
 where r.controlling_manager = p.concurrent_process_id
   and p.queue_application_id = q.application_id
   and p.concurrent_queue_id = q.concurrent_queue_id
   and trunc(r.requested_start_date) = decode(upper('&trgtdte'),'TODAY',trunc(sysdate),'&trgtdte')
   and (upper(q.concurrent_queue_name) like upper('%&trgtqname%') or upper('&trgtqname') = 'ALL')
   and (upper(g.concurrent_program_name) = upper('&trgtprog') or upper('&trgtprog') = 'ALL')
   and r.concurrent_program_id = g.concurrent_program_id
   and r.program_application_id = g.application_id
group by q.concurrent_queue_name || '(' || q.target_node || ')',
       q.running_processes, q.max_processes;

