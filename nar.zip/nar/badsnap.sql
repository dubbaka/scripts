set pagesize 1000
col mowner format a10
col master format a30
col Created format a18
col Refresh format a18

select mowner,master,to_char(snapshot,'MON-DD-YY HH:MM:SS') Created,
to_char(snaptime,'MON-DD-YY HH:MM:SS') Refresh from sys.slog$
--where snaptime < (sysdate - 1)
order by mowner,master
/
