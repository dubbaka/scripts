/* sidwaits.sql
     see sesssions and what they are waiting on
	SDR-Oracle
*/
col event format a40 trunc
col proginfo format a25 trunc
col umachine format a25 trunc
col sid format 999999
col p1p2p3txt format a30 trunc
col p2 format 9999999
col p3 format 9999999
col wait_sec format 99999
select a.*, t.sql_text from (
select w.sid,w.event,w.SECONDS_IN_WAIT Wait_Sec,
	w.p1 || ':' || w.p2 || ':' || w.p3 p1p2p3txt,
	s.sql_hash_value, s.process,p.spid, 
	replace(s.machine,'GEIPS-AMER\',null) umachine,
       nvl(s.module,'UNKnown') proginfo
from v$session_wait w, v$session s, v$process p
 where w.event not like 'SQL*Net%client'
and w.event not like '%timer%'
and w.event not like 'rdbms ipc%'
and w.event not like 'pipe get%'
and w.event not like '%manager%'
and w.event not like 'queue message%'
and s.sid = w.sid
and s.paddr = p.addr
and w.wait_time = 0) a, v$sqltext_with_newlines t
where t.hash_value(+)=a.sql_hash_value
and t.piece=0
order by wait_sec desc
/

