-- @ObjCnt.sql


spool spool\ObjCnt__&_MyDB1.
select count(1)
from   dba_objects;

select object_type, count(1)
from   dba_objects
group  by object_type;

select owner, count(1)
from   dba_objects
group  by owner;

spool off
