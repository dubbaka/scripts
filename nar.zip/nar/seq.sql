-- @seq.sql

clear columns breaks computes

col SEQUENCE_OWNER for a12 head Owner
col SEQUENCE_NAME for a30
col CYCLE_FLAG for a10
col ORDER_FLAG for a12


select SEQUENCE_OWNER, SEQUENCE_NAME, MIN_VALUE, MAX_VALUE      , INCREMENT_BY    , CYCLE_FLAG     , ORDER_FLAG     , CACHE_SIZE     , LAST_NUMBER    
from   dba_sequences
where  SEQUENCE_NAME like '&Sequence%';
