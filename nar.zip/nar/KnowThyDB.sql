-- @KnowThyDB.sql


col count(1) for 999,999,999,999
col owner format a18

@db.sql
@dbsize.sql
@dbrows.sql
@TbsDBFsCnt.sql
@sga
@SGAFreeMemory.sql
@ctlfiles.sql
@redo.sql
@temp.sql
@undo.sql
@UndoRetention.sql
@TxnRate.sql
@tu_cache.sql
@ObjCnt.sql
@DbaUser.sql
@SessProcCnt.sql
@tu_redostats.sql
@Top20TableHighChain.sql
@Top50TableHighRows.sql
@Top50TableIndexHighSize.sql
--@tu_dbSnapshot.sql
--@Top10ObjectsInBufferCache.sql
--@Top50HotObjects.sql
--@Top50HotBlocks.sql
@Tbs.sql
@dfile.sql
@TbsFragmentation.sql
@tu_DBFio.sql
@tu_fts.sql

prompt

prompt Init.ora paramaters
col NAME_COL_PLUS_SHOW_PARAM for a40
col TYPE for a15
col VALUE_COL_PLUS_SHOW_PARAM for a200
show parameter


