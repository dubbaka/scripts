-- name       : @LastAnalyzedTables.sql
-- date       : 6-Feb-2008


set pages 10000 feed off verify off linesize 132 echo off

spool spool\LastAnalyzedTables_&_MyDB1.

col table_name  head "Table Name"  for a30
col newest      head "Newest"      for date
col oldest      head "Oldest"      for date

select  to_char(max(last_analyzed), 'DD-MON-YYYY HH24:MI') newest , to_char(min(last_analyzed), 'DD-MON-YYYY HH24:MI') oldest
from    dba_tables
where   last_analyzed is not null 
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL');


select  table_name, to_char(max(last_analyzed), 'DD-MON-YYYY HH24:MI') newest , to_char(min(last_analyzed), 'DD-MON-YYYY HH24:MI') oldest
from    dba_tables
where   last_analyzed is not null 
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
group by table_name;

spool off
