-- @lsdbymon.sql


/*
A Brief Overview of SQL Apply
=============================
This section provides a brief overview of the SQL Apply architecture. For a more detailed explanation of SQL Apply, refer to Oracle9i Data Guard: SQL Apply 
Best Practices. SQL Apply consists of two distinct components:
   MINING engine and the APPLY engine:
      -- The mining engine uses LogMiner technology to read the archived redo logs, transform redo records into logical change records (LCRs), and 
      group together LCRs that belong to the same transaction for SQL Apply. LogMiner uses a collection of parallel execution servers and 
      background processes to apply changes from the primary database to the logical  standby database:
         - The READER process reads redo records from the archived redo log files and creates work units.
         - Multiple PREPARER processes convert the block changes into table changes, called logical change records (LCRs).
         - The BUILDER process groups individual LCRs into transactions, applies DDL to the LogMiner multiversioned data dictionary, handles 
         memory management, and performs special processing for chained rows and LOBs, etc.

      -- The apply engine consists of two kinds of processes:
         - An ANALYZER process computes dependencies between different transactions
         - Multiple APPLIER processes apply and commit the changes in the logical standby database.

   The COORDINATOR process (LSP0) process coordinates all the processes, assigns work to the APPLIER processes, and coordinates the order in which 
   transactions are committed in the logical standby database.
*/


What parameters are set for Logical Standby optimization
==========================================================
col name for a30
col value for a30
select * from DBA_LOGSTDBY_PARAMETERS;





Verify that SQL apply from redo logs is happening
==================================================
COLUMN NAME FORMAT A30
COLUMN VALUE FORMAT A30
SELECT NAME, VALUE
FROM V$LOGSTDBY_STATS
WHERE NAME LIKE 'coordinator%' or NAME LIKE 'transactions%';

         NAME                           VALUE
         ------------------------------ ---------
         coordinator state              APPLYING
         transactions ready             16422
         transactions applied           15447
         coordinator uptime             23







Check overall progress of log apply services
=============================================
Remarks --> if NEWEST_SCN and APPLIED_SCN are the same, them Logical Standby is 100% in sync with Production
   COLUMN APPLIED_SCN FORMAT 9999999999999
   COLUMN NEWEST_SCN  FORMAT 9999999999999
   COLUMN READ_SCN    FORMAT 9999999999999
   COLUMN NEWEST_TIME FORMAT a16
   COLUMN APPLIED_TIME FORMAT a16
   COLUMN READ_TIME   FORMAT a16
   SELECT NEWEST_SCN, to_char(NEWEST_TIME,'ddMonyy hh24:mi:ss') NEWEST_TIME
      , APPLIED_SCN, to_char(APPLIED_TIME,'ddMonyy hh24:mi:ss') APPLIED_TIME
      , READ_SCN, to_char(READ_TIME,'ddMonyy hh24:mi:ss') READ_TIME
   FROM DBA_LOGSTDBY_PROGRESS;


On primary do following:
   select thread#, sequence#, first_change#
   from v$archived_log
   where first_change# > &newest_scn_from_standby;

When the numbers in the APPLIED_SCN and NEWEST_SCN columns are equal (as shown in the query example), it means that all of the available data in 
the redo log was applied. These values can be compared to the values in the FIRST_CHANGE# column in the DBA_LOGSTDBY_LOG view to see how much log 
information has to be applied and how much remains.








Verify the current SQL apply work in progress
===============================================
COLUMN LOGSTDBY_ID for 99 head "Id"
COLUMN PID for a6
COLUMN STATUS FORMAT A100
COLUMN TYPE FORMAT A12
COLUMN HIGH_SCN FORMAT 9999999999999
COLUMN STATUS_CODE for 999999 head "Status|Code"
SELECT LOGSTDBY_ID, SERIAL#, PID, TYPE, HIGH_SCN, STATUS_CODE, STATUS FROM V$LOGSTDBY;

      LOGSTDBY_ID    SERIAL# PID          TYPE               HIGH_SCN STATUS_CODE STATUS
      ----------- ---------- ------------ ------------ -------------- ----------- --------------------------------------------------------------------
               -1         21 22919        COORDINATOR                       16116 ORA-16116: no work available
                0       2291 22921        READER                            16127 ORA-16127: stalled waiting for additional transactions to be applied
                1         38 22923        BUILDER       7281205589484       16116 ORA-16116: no work available
                2         10 22925        PREPARER      7281205591253       16116 ORA-16116: no work available
                3        144 22948        ANALYZER      7281205476966       16116 ORA-16116: no work available
                4         54 22950        APPLIER       7281205476003       16113 ORA-16113: applying change to table or sequence object number 38138
                5         31 22952        APPLIER       7281205476384       16117 ORA-16117: processing
                6        265 22954        APPLIER       7281205476222       16113 ORA-16113: applying change to table or sequence object number 38602
                7          7 22956        APPLIER       7281205476127       16113 ORA-16113: applying change to table or sequence object number 98659

Once the coordinator process begins applying redo data to the logical standby database, the V$LOGSTDBY view indicates this by showing
the APPLYING state.


select type, status_code, count(1) No_Of_Txns
from v$logstdby
group by type, status_code;








Verifying archived redo logs are being applied on the Logical Standby
======================================================================
col FILE_NAME for a50
COLUMN FIRST_CHANGE# FORMAT 9999999999999
COLUMN NEXT_CHANGE# FORMAT 9999999999999
col FIRST_TIME for a18
col "NEXT_TIME" for a18
col "Now" for a18
col first_change# for 99999999999999
col NEXT_CHANGE# for 99999999999999
col APPLIED_SCN   for 99999999999999
col NEWEST_SCN    for 99999999999999
col read_scn for 99999999999999
ALTER SESSION SET NLS_DATE_FORMAT  = 'DD-MON-YY HH24:MI:SS';

select * from (
SELECT L.SEQUENCE#, (CASE WHEN L.NEXT_CHANGE# < P.READ_SCN THEN 'YES' WHEN L.FIRST_CHANGE# < P.APPLIED_SCN THEN 'CURRENT' ELSE 'NO' END) APPLIED
, to_char(SYSDATE,'ddMonyy hh24:mi:ss') "Now"
, to_char(L.FIRST_TIME,'ddMonyy hh24:mi:ss') "FIRST_TIME", to_char(L.NEXT_TIME,'ddMonyy hh24:mi:ss') "NEXT_TIME"
, L.FIRST_CHANGE#, P.APPLIED_SCN, P.NEWEST_SCN, L.NEXT_CHANGE#, p.read_scn
FROM DBA_LOGSTDBY_LOG L, DBA_LOGSTDBY_PROGRESS P
ORDER BY SEQUENCE#)
where APPLIED in ('CURRENT','NO');

select * from (
SELECT FILE_NAME, SEQUENCE#, TIMESTAMP, FIRST_CHANGE#, FIRST_TIME, NEXT_CHANGE#, NEXT_TIME, DICT_BEGIN, DICT_END, THREAD#
FROM DBA_LOGSTDBY_LOG
ORDER BY SEQUENCE# desc
) where rownum <=25;


SELECT L.SEQUENCE#, (CASE WHEN L.NEXT_CHANGE# < P.READ_SCN THEN 'YES' WHEN L.FIRST_CHANGE# < P.APPLIED_SCN THEN 'CURRENT' ELSE 'NO' END) APPLIED
, to_char(SYSDATE,'ddMonyy hh24:mi:ss') "Now"
, to_char(L.FIRST_TIME,'ddMonyy hh24:mi:ss') "FIRST_TIME", to_char(L.NEXT_TIME,'ddMonyy hh24:mi:ss') "NEXT_TIME"
, L.FIRST_CHANGE#, P.APPLIED_SCN, P.NEWEST_SCN, L.NEXT_CHANGE#, p.read_scn
FROM DBA_LOGSTDBY_LOG L, DBA_LOGSTDBY_PROGRESS P
ORDER BY SEQUENCE#;



Compare Latest Archive Log generated in Production and Log applied in LSDBY
----------------------------------------------------------------------------
col "ProdlogSeq" head "Production|Archlog|Seq#"
col "RptlogSeq" head "Reporting|Archlog|Seq#"
col "ProdLogTime" for a18 head "Production|ArchLog|CreatedTime"
col "RptLogTime" for a18 head "Reporting|ArchLog|ReceivedTime"
col "ServerTime" for a18 head "Reporting|Server Time"
col "DaysBehind" for 999.99 head "Days|Behind"
col "HrsBehind" for 9,999.99 head "Hours|Behind"
col "MinsBehind" for 999,999 head "Minutes|Behind"
col "ProdLogStatus" head "Production|Archlog|Status"
col "RptLogStatus" head "Reporting|Archlog|Status"

create database link xxtmp_boprod connect to apps_ro identified by n01d9 using 'bobridge';
select 'MinsBehind='||(to_date(A."ProdLogTime",'DD-MON-YY HH24:MI:SS')-to_date(B."RptLogTime",'DD-MON-YY HH24:MI:SS'))*24*60 "MinsBehind"
from
   (
   select unique SEQUENCE# "ProdlogSeq", to_char(FIRST_TIME,'DD-MON-YY HH24:MI:SS') "ProdLogTime"
      , decode(ARCHIVED,'YES','Archived',ARCHIVED) "ProdLogStatus"
   from v$archived_log@xxtmp_boprod
   order by SEQUENCE# desc
   ) A,
   (
   SELECT L.SEQUENCE# "RptlogSeq", to_char(L.FIRST_TIME,'dd-MON-yy HH24:MI:SS') "RptLogTime"
      , (CASE WHEN L.NEXT_CHANGE# < P.READ_SCN THEN 'Applied' WHEN L.FIRST_CHANGE# < P.APPLIED_SCN THEN 'Current' ELSE 'NotApplied' END) "RptLogStatus"
   FROM DBA_LOGSTDBY_LOG L, DBA_LOGSTDBY_PROGRESS P WHERE L.FIRST_CHANGE# < P.APPLIED_SCN
   ORDER BY L.SEQUENCE# desc
   ) B
where rownum =1;

select to_char(SYSDATE,'dd-Mon-yy hh24:mi:ss') "ServerTime", A.*, B.*
      , (to_date(A."ProdLogTime",'DD-MON-YY HH24:MI:SS')-to_date(B."RptLogTime",'DD-MON-YY HH24:MI:SS')) "DaysBehind"
      , (to_date(A."ProdLogTime",'DD-MON-YY HH24:MI:SS')-to_date(B."RptLogTime",'DD-MON-YY HH24:MI:SS'))*24 "HrsBehind"
      , (to_date(A."ProdLogTime",'DD-MON-YY HH24:MI:SS')-to_date(B."RptLogTime",'DD-MON-YY HH24:MI:SS'))*24*60 "MinsBehind"
from
   (
   select unique SEQUENCE# "ProdlogSeq", to_char(FIRST_TIME,'DD-MON-YY HH24:MI:SS') "ProdLogTime"
      , decode(ARCHIVED,'YES','Archived',ARCHIVED) "ProdLogStatus"
   from v$archived_log@xxtmp_boprod
   order by SEQUENCE# desc
   ) A,
   (
   SELECT L.SEQUENCE# "RptlogSeq", to_char(L.FIRST_TIME,'dd-MON-yy HH24:MI:SS') "RptLogTime"
      , (CASE WHEN L.NEXT_CHANGE# < P.READ_SCN THEN 'Applied' WHEN L.FIRST_CHANGE# < P.APPLIED_SCN THEN 'Current' ELSE 'NotApplied' END) "RptLogStatus"
   FROM DBA_LOGSTDBY_LOG L, DBA_LOGSTDBY_PROGRESS P WHERE L.FIRST_CHANGE# < P.APPLIED_SCN
   ORDER BY L.SEQUENCE# desc
   ) B
where rownum =1;
drop database link xxtmp_boprod;



What archived redo log files are no longer required and can be purged
----------------------------------------------------------------------
col seq# for 99999999999999
col next_change# for 99999999999999
col read_scn for 99999999999999
alter session set nls_date_format='YY/MM/DD HH24:MI:SS';

select thread# thr#, max(log.next_change#) next_change#, max(prog.read_scn) read_scn, max(sequence#) seq#,
'All the Archived Redologs before this SEQ# are applied and are no longer required for SQL apply' Remarks
from dba_logstdby_log log , dba_logstdby_progress prog
where log.next_change# < prog.read_scn
group by thread#
order by thread#;

      THR#            SEQ#    NEXT_CHANGE#        READ_SCN
---------- --------------- --------------- ---------------
         1          167207   7281103619401   7281103659614

Above output indicates that the archived redo log files sequence# 167207 and below from thread #1 are no longer required by the SQL Apply engine and can 
therefore be safely deleted from the standby host.  All other archived redo logs should be in place when the logical apply engine is started.










Check currently running SQLs
=============================
col state for a25
col SQL_Text for a100
select ls.serial# "Apply Process" , sas.state "State" , sas.sid SID , s.sql_address "SQL Address" , s.sql_hash_value "SQL Hash Value" , sa.sql_text
from v$logstdby ls , v$streams_apply_server sas , v$session s , v$sqlarea sa
where ls.type = 'APPLIER' and sas.state != 'IDLE' and sas.serial# = ls.serial# and s.sid = sas.sid and sa.address(+) = s.sql_address
and sa.hash_value(+) = s.sql_hash_value;




Check for FTS operations
=========================
   col OPERATION for a30
   col OPTIONS   for a20
   col object_name for a30
   select operation, options, object_name, cost 
   from v$sql_plan, v$session, v$logstdby 
   where v$sql_plan.hash_value = v$session.sql_hash_value
   and v$session.serial# = v$logstdby.serial#
   and v$logstdby.status_code=16113;

What to do: If SQL apply is doing full table scans consider adding indexes to the affected tables.




Check running active transactions
=====================================
col SID for 99999
col "SERIAL#" for 999999
col process head "OSpid|APnode" for a6
col SPID head "OSpid|DBnode" for a6
col username for a10 head "Schema"
col osuser for a10
col machine for a20
col module for a20
col sql_hash_value head "SQL_HASH" for 9999999999
col PREV_HASH_VALUE head "PrevSQL_HASH" for 9999999999
col program for a80
col logontime for a15
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11

select sid, type, id1, id2, lmode, request
from v$lock
where type = 'TX';

select s.sid, s.serial#, s.process, p.spid, s.audsid, s.username, s.osuser, s.machine, s.module
   , to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime
   , floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
   , s.status, s.sql_hash_value, s.PREV_HASH_VALUE
   , s.program, s.type, p.pid, s.action, p.PGA_USED_MEM, p.PGA_ALLOC_MEM, p.PGA_FREEABLE_MEM, p.PGA_MAX_MEM, s.RESOURCE_CONSUMER_GROUP
from  v$session s, v$process p
where p.addr = s.paddr
and   s.status = 'ACTIVE';






Check the SQLs that are generating lot of IO:
=============================================
col "SQLTEXT" for a80
col "ReadPerExec" for 999999999999.99
select * from (
   SELECT DISK_READS/EXECUTIONS "ReadPerExec", DISK_READS, EXECUTIONS, ADDRESS, HASH_VALUE, SUBSTR(SQL_TEXT,1,80) "SQLTEXT"
   FROM V$SQLAREA
   WHERE EXECUTIONS > 0 and DISK_READS/GREATEST(EXECUTIONS,1) > 1
   ORDER BY DISK_READS/GREATEST(EXECUTIONS,1) DESC
) where rownum <=10;










Check events
=============
col STATUS for a60
select xidusn, xidslt, xidsqn, status_code, status  from dba_logstdby_events where event_time = (select max(event_time) from dba_logstdby_events);


col COMMIT_SCN for 99999999999999
select * from (
   SELECT EVENT_TIME, COMMIT_SCN, STATUS, EVENT FROM DBA_LOGSTDBY_EVENTS ORDER BY EVENT_TIME desc, COMMIT_SCN
) where rownum <=10;







Check wait events:
==================
@sidwaits.sql
@sidwait.sql
@longops.sql





How to skip "Alter Index"?
=========================
exec dbms_logstdby.skip('ALTER INDEX');




To stop and start log apply in future:
======================================
startup;
ALTER DATABASE guard standby;
ALTER DATABASE STOP LOGICAL STANDBY APPLY;
ALTER DATABASE START LOGICAL STANDBY APPLY;







Check for any paging
=====================
select value bytes from v$logstdby_stats where name = 'bytes paged out';




What to do when READ_SCN is not Increasing
===========================================
The READ_SCN will remain static if a long running transaction on the primary is not committed.  To advance the READ_SCN, restart logical apply 
and commit any uncommited long running transactions on the primary followed by a log switch.

In extreme cases you can force READ_SCN to a higher value by stopping logical apply and setting the following parameter:
   exec dbms_logstdby.apply_set('_MAX_LOG_LOOKBACK',1);

After restarting logical apply you should begin to see the READ_SCN increase.  You should unset _MAX_LOG_LOOKBACK once the READ_SCN value has 
returned to normal.







Get the list of tables in the skip list:
=========================================
col owner for a20
col STATEMENT_OPT for a15

select STATEMENT_OPT, count(1)
from DBA_LOGSTDBY_SKIP
group by STATEMENT_OPT
order by STATEMENT_OPT;

select OWNER, STATEMENT_OPT, count(1)
from DBA_LOGSTDBY_SKIP
group by OWNER, STATEMENT_OPT
having count(1) > 5
order by count(1) desc, OWNER, STATEMENT_OPT;

select OWNER, STATEMENT_OPT, count(1)
from DBA_LOGSTDBY_SKIP
group by OWNER, STATEMENT_OPT
order by OWNER, STATEMENT_OPT;





Getting the hidden columns for unsupported tables
===================================================
select name, obj#, col#, TYPE#, LENGTH, segcollength, PROPERTY from sys.col$
where obj# = (select object_id from dba_objects where object_name ='&tbl' and rownum=1)
and col#= 0;



Configuration and Maintenance
==============================

Controlling User Access to Tables in a Logical Standby Database
------------------------------------------------------------------
ALTER DATABASE GUARD ALL;        -- prevents all users other than SYS from making changes to any data in the logical standby database.
ALTER DATABASE GUARD STANDBY;    -- prevent all users other than SYS from making DML and DDL changes to any table or sequence being maintained through SQL apply operations.
ALTER DATABASE GUARD NONE;       -- Specify NONE if you want typical security for all data in the database.



Handling Triggers and Constraints on a Logical Standby Database
------------------------------------------------------------------
Triggers and constraints are enabled on the standby database but they are not executed. For triggers and constraints on tables maintained 
through SQL apply operations, constraints are evaluated on the primary database and do not need to be re-evaluated on the logical standby 
database. The effects of the triggers executed on the primary database are logged and applied on the standby database.

Triggers will be fired and constraints will be evaluated on tables not maintained through SQL apply operations.



Procedures to Skip applying archived redo logs to selected tables or entire schemas:
------------------------------------------------------------------------------------
DBMS_LOGSTDBY.SKIP
DBMS_LOGSTDBY.SKIP_ERROR
DBMS_LOGSTDBY.SKIP_TRANSACTION
DBMS_LOGSTDBY.UNSKIP
DBMS_LOGSTDBY.UNSKIP_ERROR
DBMS_LOGSTDBY.UNSKIP_TRANSACTION


Manage initialization parameters used by log apply services:
------------------------------------------------------------
DBMS_LOGSTDBY.APPLY_SET
DBMS_LOGSTDBY.APPLY_UNSET
DBMS_LOGSTDBY.GUARD_BYPASS_OFF
DBMS_LOGSTDBY.GUARD_BYPASS_ON
DBMS_LOGSTDBY.INSTANTIATE_TABLE


Modifying Tables maintained by SQL Apply
-----------------------------------------
ALTER DATABASE STOP LOGICAL STANDBY APPLY;
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_ON;
ALTER TABLE SCOTT.EMP ADD CONSTRAINT EMPID UNIQUE (EMPNO);
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_OFF;
ALTER DATABASE START LOGICAL STANDBY APPLY;


Modifying Tables That Are Not Maintained by SQL Apply:
-------------------------------------------------------
You can set up the database guard to allow reporting operations to modify data as long as the data is not being maintained through SQL apply 
operations. To do this, you must:
   1) Specify the set of tables on the logical standby database to which an application can write data by executing the DBMS_LOGSTDBY.SKIP 
   procedure. Skipped tables are not maintained through SQL apply operations.
   2) Set the database guard to protect only standby tables. This setting describes the list of tables that the logical standby database is 
   maintaining. The list cannot include the tables to which your application will be writing.
ALTER DATABASE STOP LOGICAL STANDBY APPLY;
EXECUTE DBMS_LOGSTDBY.SKIP('SCHEMA_DDL','MYSCHEMA','MYTABLES%');
EXECUTE DBMS_LOGSTDBY.SKIP('DML','MYSCHEMA','MYTABLES%');
ALTER DATABASE START LOGICAL STANDBY APPLY;

-- Verify above is applied
SELECT NAME FROM DBA_LOGSTDBY_PARAMETERS WHERE NAME = 'EVALUATE_SKIP';

-- When above SQL returns no rows, it means the Logical Standby database is updated. Now set to GUARD so that skipped tables can be updated by users.
ALTER DATABASE GUARD STANDBY;



Skipping a Table
-----------------
ALTER DATABASE STOP LOGICAL STANDBY APPLY;
EXECUTE DBMS_LOGSTDBY.SKIP('SCHEMA_DDL', 'SCOTT', 'EMP', NULL);
EXECUTE DBMS_LOGSTDBY.SKIP('DML', 'SCOTT', 'EMP', NULL);
ALTER DATABASE START LOGICAL STANDBY APPLY;



Skipping ALTER or CREATE TABLESPACE Statements
------------------------------------------------
EXEC DBMS_LOGSTDBY.SKIP(`CREATE TABLESPACE', NULL, NULL, NULL);
EXEC DBMS_LOGSTDBY.SKIP(`ALTER TABLESPACE', NULL, NULL, NULL);



Adding a Table to a Logical Standby Database
----------------------------------------------
ALTER DATABASE STOP LOGICAL STANDBY APPLY;
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_ON;
create public database link prod_dblink connect to system identified by g0l1v3 using 'bobridge';
EXECUTE DBMS_LOGSTDBY.UNSKIP('SCHEMA_DDL','SCOTT','EMP');
EXECUTE DBMS_LOGSTDBY.INSTANTIATE_TABLE('SCOTT','EMP','prod_dblink');
drop public database linke prod_dblink
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_OFF;
ALTER DATABASE START LOGICAL STANDBY APPLY;


Recovering from DDL statement failures
----------------------------------------
1) DDL Transactions Containing File Specifications
DDL statements are executed the same way on both the primary database and logical standby databases. If the underlying file structure is the 
same on both databases, the DDL will execute on the standby database as expected. However, if the structure of the file system on the standby 
system differs from the file system on the primary system, it is likely that an error might result because the DB_FILE_NAME_CONVERT will not 
convert the filenames of one or more sets of datafiles on the primary database to filenames on the standby database for a logical standby 
database. If an error was caused by a DDL transaction that contained a file specification that does not match in the logical standby database 
environment, perform the following steps to fix the problem:

ALTER DATABASE STOP LOGICAL STANDBY APPLY;
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_ON;
-- Execute the DDL statement, using the correct file specification, and then reenable the database guard. For example:
ALTER TABLESPACE t_table ADD DATAFILE 'dbs/t_db.f' SIZE 100M REUSE;
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_OFF;
-- Query the DBA_LOGSTDBY_EVENTS view to find the XIDUSN, XIDSLT, and XIDSQN values for the failed DDL, and provide the values to the 
-- DBMS_LOGSTDBY.SKIP_TRANSACTION procedure. The failed DDL statement will always be the last transaction. For example:
SELECT XIDUSN, XIDSLT, XIDSQN FROM DBA_LOGSTDBY_EVENTS 
WHERE EVENT_TIME = (SELECT MAX(EVENT_TIME) FROM DBA_LOGSTDBY_EVENTS);
EXECUTE DBMS_LOGSTDBY.SKIP_TRANSACTION( /*xidusn*/, /*xidslt*/, /*xidsqn*/);
ALTER DATABASE START LOGICAL STANDBY APPLY;

When log apply services restart, they will attempt to re-execute the transaction that failed. If you do not want to re-execute it, provide the 
values to the DBMS_LOGSTDBY.SKIP_TRANSACTION procedure (see step 3 for an example) to skip the transaction.

2) In some situations, the problem that caused the transaction to fail can be corrected and log apply services restarted without skipping the 
transaction. An example of this might be when available space is exhausted. The example shows log apply services stopping, how to correct the error,
and then restart log apply services. For example:
SELECT * FROM DBA_LOGSTDBY_EVENTS;
EVENT_TIM CURRENT_SCN COMMIT_SCN     XIDUSN     XIDSLT     XIDSQN EVENT                                                 STATUS_CODE STATUS
--------- ----------- ---------- ---------- ---------- ---------- ---------------------------------------------------   ----------- ---------------
30-JUL-02       16111                                             ORA-16111: log mining and apply setting up
30-JUL-02      200240     200243          1          2     2213   create table bar (x number, y number) tablespace foo 16204       ORA-16204: DDL successfully applied
30-JUL-02      200695     200735          1         11     2215   SCOTT.BAR (Oper=INSERT)                                1653       ORA-01653: unable to extend table SCOTT.BAR by %d in tablespace
30-JUL-02      200812     200864          1         11     2215   SCOTT.BAR (Oper=INSERT)                                1653       ORA-01653: unable to extend table SCOTT.BAR by %d in tablespace

In the example, the ORA-01653 message indicates that the tablespace was full and unable to extend itself. To correct the problem, add a new 
datafile to the tablespace. For example:

ALTER DATABASE STOP LOGICAL STANDBY APPLY;
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_ON;
ALTER TABLESPACE t_table ADD DATAFILE 'dbs/t_db.f' SIZE 60M;
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_OFF;
ALTER DATABASE START LOGICAL STANDBY APPLY;

When log apply services restart, the transaction that failed will be re-executed and applied to the logical standby database.





Refreshing Materialized Views
-----------------------------
Materialized views refreshed on the primary database are not automatically refreshed separately on a logical standby database. To refresh 
materialized views on the logical standby database, use the GUARD_BYPASS_ON and GUARD_BYPASS_OFF procedures of the DBMS_LOGSTDBY package.
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_ON;
EXECUTE DBMS_MVIEW.REFRESH ( 'BMVIEW', 'F', '',TRUE,FALSE,0,0,0,FALSE);
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_OFF;




Tuning Logical Standby Databases
---------------------------------
Take the following actions to increase system performance:
1) On the primary database, if a table does not have a primary key or a unique index, then create a primary key RELY constraint. On the 
logical standby database, create an index on the columns that make up the primary key. By creating an index on the following tables,
performance can be improved significantly.

-- The following query generates a list of tables with no index information that can be used by a logical standby database to apply to uniquely 
-- identify rows.:
SELECT OWNER, TABLE_NAME FROM DBA_TABLES  WHERE OWNER NOT IN('SYS','SYSTEM','OUTLN','DBSNMP') 
MINUS
SELECT DISTINCT TABLE_OWNER, TABLE_NAME FROM DBA_INDEXES WHERE INDEX_TYPE NOT LIKE ('FUNCTION-BASED%')
MINUS
SELECT OWNER, TABLE_NAME FROM DBA_LOGSTDBY_UNSUPPORTED;

The following example shows the creation of an index for the table EMP. This should be done for all the tables returned by the previous query:
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_ON;
CREATE INDEX EMPI ON EMP (EMPNO);
EXECUTE DBMS_LOGSTDBY.GUARD_BYPASS_OFF;

2) Gather statistics for the cost-based optimizer (CBO) periodically on the logical standby database for objects, where the statistics become 
stale over time because of changing data volumes or changes in column values. New statistics should be gathered after the data or structure 
of a schema object is modified in ways that make the previous statistics inaccurate.
For example, after inserting or deleting a significant number of rows into a table, collect new statistics on the number of rows.

Statistics should be gathered on the standby database because DML/DDL operations on the primary are executed as a function of the workload. 
While the standby database is logically equivalent to the primary, SQL apply operations might execute the workload in a different way. This is 
why using the DBMS_STATS package on the logical standby database and the V$SYSSTAT view can be useful in determining which tables are consuming 
the most resources and table scan operations.

3) Adjust the transaction consistency:
Use the TRANSACTION_CONSISTENCY parameter of the DBMS_LOGSTDBY.APPLY_SET procedure to control how transactions are applied to the logical standby 
database. The default setting is FULL, which applies transactions to the logical standby database in the same order in which they were committed 
on the primary database.

Specify one of the following values:
FULL --> Transactions are applied to the logical standby database in the exact order in which they were committed on the primary database. This 
         option results in the lowest performance. This is the default parameter setting.
READ_ONLY --> Transactions are applied out of order from how they were committed on the primary database. The READ_ONLY option provides better 
         performance than the FULL value, and SQL SELECT statements return read-consistent results. This is particularly beneficial when you 
         are using the logical standby database to generate reports.
NONE --> Transactions are applied out of order from how they were committed on the primary database, and no attempt is made to provide 
         read-consistent results. This results in the best performance of the three values. If applications that are reading the logical standby 
         database make no assumptions about transaction order, this option works well.
Note: The READ_ONLY and NONE options should only be used when ALTER DATABASE GUARD ALL is set.

4) Adjust the maximum number of parallel execution processes:
Use the PARALLEL_MAX_SERVERS initialization parameter to adjust the maximum number of parallel execution processes and parallel recovery processes 
for an instance. The default value for this parameter is derived from the values of the CPU_COUNT, PARALLEL_AUTOMATIC_TUNING, and 
PARALLEL_ADAPTIVE_MULTI_USER initialization parameters. This parameter must not be set to a value less than 5 on a logical standby database.

You can use the MAX_SERVERS parameter of the DBMS_LOGSTDBY.APPLY_SET procedure to limit the number of parallel servers used by log apply services.
The default value of this parameter is set equal to the value of the PARALLEL_MAX_SERVERS initialization parameter. If you set this parameter 
explicitly, do not set it to a value less than 5 or greater than the value of the PARALLEL_MAX_SERVERS initialization parameter.

Increasing the number of parallel execution processes and parallel recovery processes for an instance can speed up execution and recovery operations,
but this improvement must be balanced against the consumption of additional system resources by the processes.

5) Control memory usage on the logical standby database:
You can use the MAX_SGA parameter of the DBMS_LOGSTDBY.APPLY_SET procedure to set the maximum amount of shared pool space used by log apply 
services for redo cache. By default, log apply services will use up to one quarter of the shared pool. Generally speaking, increasing the size of 
the shared pool or the amount of shared pool space used by log apply services will improve the performance of a logical standby database.



Describe a set of operations that should not be applied to the logical standby database
------------------------------------------------------------



Avoid applying DML or DDL changes for temporary tables
------------------------------------------------------------


Avoid applying any CREATE, ALTER, or DROP INDEX operations
------------------------------------------------------------



Date: 20-Mar-09
B3692A GlancePlus C.04.50.00    08:08:14 bze2uo04 9000/800                                                                          Current  Avg  High
------------------------------------------------------------------------------------------------------------------------------------------------------
CPU  Util   SS                                                                                                                       |  2%   16%   41%
Disk Util   F   F                                                                                                                    |  4%   12%   19%
Mem  Util   S                     SU                                                  UB                      B                      | 81%   81%   81%
Swap Util   U           UR                                R                                                                          | 39%   39%   39%
------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                     PROCESS LIST                                                         Users=    6
                              User      CPU Util   Cum     Disk             Thd
Process Name  PID   PPID  Pri Name    ( 800% max)  CPU    IO Rate    RSS    Cnt
--------------------------------------------------------------------------------
vxfsd           55      0 134 root     10.7/ 4.3 28524.1  6.1/ 6.0   2.1mb   44
ora_p000_bo   9973      1 156 bolby     0.2/ 6.0  4660.4  0.0/ 0.0 357.0mb    1
swapper          0      0 127 root      0.0/ 0.0     7.8  3.6/10.5    32kb    1
oraclebolby   2294      1 154 bolby     0.0/ 0.0     0.1  0.0/ 0.0 335.4mb    1
oraclebolby  23064      1 154 bolby     0.0/ 0.0     7.5  0.0/ 0.0 358.2mb    1
ora_p003_bo  12234      1 156 bolby     0.0/ 1.4  1089.8  0.0/ 0.0 350.6mb    1
oraclebolby  23354      1 137 bolby     0.0/ 0.0     0.9  0.0/ 0.0 358.2mb    1
ora_p005_bo  12238      1 156 bolby     0.0/ 4.3  3331.8  0.0/ 3.0 388.8mb    1
oraclebolby   2239      1 154 bolby     0.0/ 0.0     0.6  0.0/ 0.0 337.2mb    1
oraclebolby   2291      1 154 bolby     0.0/ 0.0     0.1  0.0/ 0.0 335.4mb    1
oraclebolby   2264      1 154 bolby     0.0/ 0.0     0.3  0.0/ 0.0 349.3mb    1
oraclebolby   2262      1 154 bolby     0.0/ 0.0     0.1  0.0/ 0.0 349.5mb    1
oraclebolby   2266      1 154 bolby     0.0/ 0.0     0.2  0.0/ 0.0 349.3mb    1
oraclebolby  25380      1 154 bolby     0.0/ 0.0     1.0  0.0/ 0.0 358.2mb    1
ora_p002_bo   9977      1 156 bolby     0.0/11.7  9108.0  0.0/ 0.1 350.7mb    1
ora_lsp0_bo   9971      1 156 bolby     0.0/ 1.5  1136.2  0.0/ 0.0 350.3mb    1
ora_p007_bo  12242      1 156 bolby     0.0/ 3.4  2659.5  0.0/ 2.4 548.8mb    1
ora_p006_bo  12240      1 156 bolby     0.0/ 3.5  2680.7  0.0/ 2.6 396.8mb    1
ora_p004_bo  12236      1 156 bolby     0.0/ 3.5  2679.7  0.0/ 3.4 484.8mb    1
cimprovagt    1780   1765 168 root      0.0/ 0.0    43.2  0.0/ 0.0  21.8mb   10
midaemon      2053      1 -16 root      0.0/ 0.5  3073.7  0.0/ 0.0  44.2mb    2
scopeux       2065      1 127 root      0.0/ 0.1   387.2  0.0/ 0.1  36.0mb    1
ora_qmn0_bo  16822      1 156 bolby     0.0/ 0.8  1479.6  0.0/ 0.1 349.9mb    1
coda          2144   2096 168 root      0.0/ 0.4  2642.8  0.0/ 0.1  35.1mb    8
ora_cjq0_bo  16820      1 156 bolby     0.0/ 0.0     4.0  0.0/ 0.0 347.5mb    1
ora_lgwr_bo  16812      1 156 bolby     0.0/ 0.9  1659.5  9.6/80.4 361.8mb    1
ora_ckpt_bo  16814      1 156 bolby     0.0/ 0.1   186.9  1.3/ 1.7 362.0mb    1
ora_reco_bo  16818      1 156 bolby     0.0/ 0.0     0.1  0.0/ 0.0 335.5mb    1
ora_pmon_bo  16808      1 154 bolby     0.0/ 0.0    34.6  0.0/ 0.0 349.7mb    1
ora_qmn1_bo  16824      1 178 bolby     0.0/ 0.8  1471.4  0.0/ 0.0 351.7mb    1
ora_smon_bo  16816      1 156 bolby     0.0/ 0.0    43.5  0.0/ 0.6 351.7mb    1
ora_dbw0_bo  16810      1 156 bolby     0.0/ 0.4   780.7  0.0/72.3 362.0mb    1
vxsvc         3045      1 154 root      0.0/ 0.0    30.8  0.0/ 0.0  49.1mb   18
ora_p001_bo   9975      1 156 bolby     0.0/ 3.7  2857.0  0.0/ 0.0 355.8mb    1

