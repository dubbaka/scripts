-- @Locks_10g.sql



set pages 50 lines 250 serveroutput on size 1000000



col "BlkingSID" for 99999 head "Blking|SID"

col "WtgSID" for 99999

col serial# for 999999

col username for a15

col event for a30

col wait_class for a15

col "ModeHeld" for a25

col "ModeRequested" for a25

col "MinsWaiting" for 99999.99

col object_type for a15 trunc

col object_name for a30



prompt Blocking Sessions

prompt =================

select /*+ ordered */ a.INST_ID, a.sid "BlkingSID", a.serial#, a.username, to_char(a.logon_time,'ddMonyy hh24:mi:ss PM') "LoginTime"

, a.wait_class, a.event -- 10g specific

      , decode(b.type,'TM','TM - DML enqueue','TX','TX - Transaction enqueue','UL','UL - User supplied',b.type ) "Type"

      , decode(b.lmode,0,'None',1,'Null',2,'RowShare(RS)or(SS)',3,'RowExclusive(RX)or(SX)',4,'Share(S)',5,'ShareRowExclusive(RSX)',6,'Exclusive(X)') "ModeHeld"

      , b.ctime time_held, c.sid waiter_sid

      , decode(c.request,0,'None',1,'Null',2,'RowShare(RS)or(SS)',3,'RowExclusive(RX)or(SX)',4,'Share(S)',5,'ShareRowExclusive(RSX)',6,'Exclusive(X)') "ModeRequested"

      , c.ctime time_waited

from   gv$lock b, gv$enqueue_lock c, gv$session a

where  a.INST_ID = b.INST_ID and a.sid=b.sid and b.INST_ID = c.INST_ID(+) and b.id1=c.id1(+) and b.id2=c.id2(+) and c.type(+)='TX' and b.type='TX' and b.block=1

order  by time_held, time_waited desc;





prompt Waiting Sessions

prompt ================

select a.sid "WtgSID", b.serial#, b.username, to_char(b.logon_time,'ddMonyy hh24:mi:ss PM') "LoginTime"

, a.wait_class, a.event -- 10g specific

, a.WAIT_TIME, a.SECONDS_IN_WAIT

     , (a.SECONDS_IN_WAIT/60) "MinsWaiting", c.object_name, c.object_type, chr(bitand(a.P1,-16777216)/16777215)||chr(bitand(a.P1,16711680)/65535) type

     , decode(mod(a.p1,16),0,'None',1,'Null',2,'RowShare(RS)or(SS)',3,'RowExclusive(RX)or(SX)',4,'Share(S)',5,'ShareRowExclusive(RSX)',6,'Exclusive(X)') "Mode_Held"

from   gv$session_wait a, gv$session b, dba_objects c

where  a.event like 'enq%'

and    b.INST_ID = a.INST_ID

and    b.sid = a.sid

and    (c.object_id = b.row_wait_obj#  or  c.data_object_id = b.row_wait_obj#);







prompt Detailed Lock Tree

prompt ==================

DECLARE

   cursor c1 is select INST_ID, SID, ID1, ID2 from gv$lock where request != 0 order by INST_ID, id1, id2;

   wINST_ID        number := -999999;

   wid1            number := -999999;

   wid2            number := -999999;

   wholder_detail  varchar2(300);

   v_err_msg       varchar2(80);

   wsid            number(5);

   wstep           number(2);

   wtype           varchar2(10);

   wobject_name    varchar2(180);

   wobject_name1   varchar2(80);

   wlock_type      varchar2(50);

   w_lastcallet 	  varchar2(11);

   h_lastcallet	  varchar2(11);

BEGIN

   FOR c1_rec IN c1 LOOP

     if c1_rec.id1 = wid1 and c1_rec.id2 = wid2 then

        null;

     else

        wstep  := 10;

--dbms_output.put_line('c1_rec.INST_ID='||c1_rec.INST_ID);

--dbms_output.put_line('c1_rec.id1='||c1_rec.id1);

--dbms_output.put_line('c1_rec.id2='||c1_rec.id2);

        BEGIN

           select sid , type  into wsid, wtype  from gv$lock where INST_ID=c1_rec.INST_ID and id1=c1_rec.id1 and id2=c1_rec.id2 and request=0 and lmode!=4;

--and rownum = 1;

--dbms_output.put_line('INST_ID='||c1_rec.INST_ID);

--dbms_output.put_line('sid='||wsid);

--dbms_output.put_line('type='||wtype);

        EXCEPTION

           when NO_DATA_FOUND then

              v_err_msg := (sqlerrm ||'  '|| sqlcode||' step='||to_char(wstep));

              DBMS_OUTPUT.PUT_LINE(v_err_msg);

              goto Repeat1stLoop;

           when others then

              v_err_msg := (sqlerrm ||'  '|| sqlcode||' step='||to_char(wstep));

              DBMS_OUTPUT.PUT_LINE(v_err_msg);

        END;



        wstep  := 20;

        BEGIN

           select chr(10)||'Instid: '||s.inst_id||' Holder DBU: '||s.username ||' OSU: '||s.osuser ||' DBP:'||p.spid||' APP: '|| s.process || ' SID:' || s.sid || ' Status: ' || s.status  ||

          ' (' || floor(last_call_et/3600)||':'|| floor(mod(last_call_et,3600)/60)||':'|| mod(mod(last_call_et,3600),60) || ') Module:'|| module || ' AppSrvr: ' || machine

           into   wholder_detail

           from   gv$session s, gv$process p

           where  s.INST_ID = c1_rec.INST_ID

           and    s.INST_ID = p.INST_ID 

           and    s.sid= wsid

           and    s.paddr = p.addr;

           dbms_output.put_line(wholder_detail);

        BEGIN

	   select decode(wtype,'TX','Transaction', 'DL','DDL Lock', 'MR','MediaRecovery', 'RT','RedoThread','UN','UserName', 'TX','Transaction'

                           , 'TM','DML', 'UL','PL/SQLuserLock', 'DX','DistributedTxn', 'CF','ControlFile', 'IS','InstanceState'

                           , 'FS', 'FileSet', 'IR', 'InstanceRecovery', 'ST', 'DiskSpaceTransaction', 'TS','TempSegment', 'IV','LibraryCacheInvalidation'

                           , 'LS','LogStartOrSwitch', 'RW','RowWait', 'SQ','SequenceNumber', 'TE','ExtendTable', 'TT','TempTable', wtype)

	   into  wlock_type

	   from  dual;

           DECLARE

              cursor c3 is select object_id from gv$locked_object where INST_ID = c1_rec.INST_ID and session_id = wsid;

           BEGIN

              wobject_name := '';

              FOR c3_rec IN c3 LOOP

                select object_type||': '||owner||'.'||object_name 

                into   wobject_name

                from   dba_objects 

                where  object_id = c3_rec.object_id;

                wobject_name := wobject_name ||' '||wobject_name1;

              END LOOP;

            EXCEPTION

             when others then

                wobject_name := wobject_name ||' No Object Found';

            END;

                dbms_output.put_line('Lock Held: '||wlock_type||' for Object :'||wobject_name);

            EXCEPTION

               when no_data_found then

                  dbms_output.put_line('Lock Held: '||wlock_type||' No object found in DBA Objects');

            END;

         EXCEPTION

            when no_data_found then

               dbms_output.put_line('Lock Held: '||wlock_type||' No object found in DBA Objects');

         END;

     end if;



     wstep  := 30;

     select '....   Requestor DBU: '||s.username ||' OSU: '||s.osuser ||' DBP:'||p.spid||' APP: '|| s.process || ' SID:' || s.sid || ' Status: ' || s.status  ||

         ' (' || floor(last_call_et/3600)||':'|| floor(mod(last_call_et,3600)/60)||':'|| mod(mod(last_call_et,3600),60) ||') Module:'|| module || ' AppSrvr: ' || machine

     into wholder_detail

     from gv$session s, gv$process p

     where  s.INST_ID = c1_rec.INST_ID

     and    s.INST_ID = p.INST_ID 

     and    s.sid     = c1_rec.sid

     and   s.paddr    = p.addr;

     dbms_output.put_line(wholder_detail);

     wINST_ID := c1_rec.INST_ID;

     wid1  := c1_rec.id1;

     wid2  := c1_rec.id2;

<<Repeat1stLoop>>

     NULL;  -- an executable statement that does nothing is needed here, otherwise above label will cause PL/SQL engine to error out

  END LOOP;



  if wid1 = -999999 then

     wstep  := 40;

     dbms_output.put_line('No one requesting locks held by others');

  end if;



EXCEPTION

  when others then

      v_err_msg := (sqlerrm ||'  '|| sqlcode||' step='||to_char(wstep));

      DBMS_OUTPUT.PUT_LINE(v_err_msg);

END;

/


