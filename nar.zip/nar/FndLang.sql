-- @FndLang.sql

clear columns breaks computes

set pages 400 lines 80 pau off

col LANGUAGE_CODE for a10 head 'Lang Code'
col "Installed" for a20
col DESCRIPTION for a30 head Language

select LANGUAGE_CODE, decode(INSTALLED_FLAG, 'I','Installed', 'B','Base', 'D','NotInstalled', INSTALLED_FLAG) "Installed", DESCRIPTION
from   FND_LANGUAGES_VL
order  by 2,1;
