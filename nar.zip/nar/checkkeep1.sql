
REM buffer_pool to set_id 
select * from v$buffer_pool
/

REM where - in the buffer cache - are this object's blocks 

select b.owner#,b.name,a.obj,round((count(*)*8)/1024) "Size(MB)"
from sys.x$bh a ,
     sys.obj$ b ,
     (
SELECT  bp_name,min(START_BUF#) START_BUF ,max(END_BUF#) END_BUF
      FROM   sys.X$kcbwds ,
             sys.X$KCBWBPD
      WHERE  SET_ID between BP_LO_SID and BP_HI_SID
             AND BP_NAME='KEEP'
group by bp_name ) c
where a.buf# between c.START_BUF and c.END_BUF
and c.bp_name = 'KEEP'
and a.obj= b.obj#
group by b.owner#,b.name,a.obj
/
