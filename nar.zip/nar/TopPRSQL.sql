-- @TopPRSQLs.sql

/* Tuning the top physical read queries can yield system performance gains anywhere from 5 percent to 5000 percent.
   The SQL section of the statspack or AWR report tells you which queries to potentially tune first. */

clear columns breaks computes
col inst_id for 9999 head "Inst|Id"
col "DispDateNow" for a22
col sqltext for a1000
col USER_NAME for a15
col SID for 99999

set feed off lines 1200 veri off echo off pages 40


col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDMonYYYYhh24miss') "datenow" from dual;
set feed on

select to_char(sysdate, 'dd-Mon-YYYY hh24:mi:ss') "DispDateNow" from dual;

accept trgtRows number default 10 prompt 'Rows to display <10> : '

prompt 
prompt Finding the top 25 largest amount of physical reads per user
select * from
(Select unique A.INST_ID, A.User_Name, A.sid, B.Disk_Reads, B.Buffer_Gets, B.Rows_Processed, B.SQL_ID, B.VERSION_COUNT, B.LOADED_VERSIONS, B.KEPT_VERSIONS
      , B.CPU_TIME, B.ELAPSED_TIME, B.FETCHES, B.EXECUTIONS, B.LOADS, B.INVALIDATIONS, B.PARSE_CALLS, B.DIRECT_WRITES, B.OPTIMIZER_MODE, B.OPTIMIZER_COST
      , B.ACTION, replace(B.SQL_Text,'  ','') sqltext
From   gV$Open_Cursor A, gV$SQLArea B
Where  A.INST_ID = B.INST_ID
and    A.Address = B.Address
Order  By B.Disk_Reads desc, A.User_Name, a.sid)
where rownum <= &trgtRows;
