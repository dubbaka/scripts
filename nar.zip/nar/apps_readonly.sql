connect system/&systempwd
create user &&user identified by &&pass default tablespace APPS_TS_TOOLS temporary tablespace TEMP;
grant connect, resource, select any table, create synonym to &&user;

connect apps/&appspwd
spool /tmp/syn.sql
set pages 500
set lines 200
select 'create synonym '||synonym_name||' for '||table_owner||'.'||table_name||';'
from user_synonyms;
spool off
spool /tmp/syn2.sql
set pages 500
set lines 200
select 'create synonym '||view_name||' for APPS.'||view_name||';'
from user_views;
spool off
grant execute on apps.FND_CLIENT_INFO to &&user;
grant execute on apps.fnd_date to &&user;

--connect as custom(read only) user
connect &&user/&&pass
@/tmp/syn2.sql
@/tmp/syn.sql
create synonym FND_CLIENT_INFO for apps.FND_CLIENT_INFO;
create synonym FND_DATE for apps.FND_DATE;
