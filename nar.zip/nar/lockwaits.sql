set serveroutput on
declare cursor c1 is
 select * from gv$lock where request != 0 order by id1, id2;
 wid1            number := -999999;
 wid2            number := -999999;
 wholder_detail  varchar2(250);
 v_err_msg          varchar2(80);
 winst_id       number;
 wsid            number(5);
 wctime          NUMBER;
 wstep           number(2);
 wtype           varchar2(10);
 wobject_name    varchar2(180);
 wobject_name1   varchar2(80);
 wlock_type      varchar2(50);
 w_lastcallet     varchar2(11);
 h_lastcallet     varchar2(11);
   begin
     for c1_rec in c1 loop
       if c1_rec.id1 = wid1 and c1_rec.id2 = wid2 then
          null;
       else
          wstep  := 10;
          select inst_id ,sid, type,ctime into winst_id,wsid , wtype, wctime
            from gv$lock
            where id1  = c1_rec.id1
              and id2  = c1_rec.id2
              and request = 0
              and lmode != 4;
         dbms_output.put_line('  ');
          wstep  := 20;
        select 'Holder Instance:' || i.instance_name ||'  SID:' || s.sid || '  SERIAL:' || s.serial#||
                '  OSU:'||s.osuser ||'  DBP:'||p.spid||'  APP:'|| s.process ||'  AppSrv:' ||substr(machine,0,30)||
                '  Status:' || s.status  || ' (' ||         floor(last_call_et/3600)||':'||
                floor(mod(last_call_et,3600)/60)||':'||mod(mod(last_call_et,3600),60) ||') Holding_for:'||
                round(wctime/60) || 'min' ||'  Module:'|| module
             into wholder_detail
             from gv$session s, gv$process p, gv$instance i
             where s.inst_id=i.inst_id
               and i.inst_id=winst_id
               and s.sid= wsid
               and s.paddr = p.addr
               and s.INST_ID=p.INST_ID;
         dbms_output.put_line(wholder_detail);

         begin
      select decode(wtype,'TX', 'Transaction',
                               'DL', 'DDL Lock',
                               'MR', 'Media Recovery',
                               'RT', 'Redo Thread',
                               'UN', 'User Name',
                               'TX', 'Transaction',
                               'TM', 'DML',
                               'UL', 'PL/SQL User Lock',
                               'DX', 'Distributed Xaction',
                               'CF', 'Control File',
                               'IS', 'Instance State',
                               'FS', 'File Set',
                               'IR', 'Instance Recovery',
                               'ST', 'Disk Space Transaction',
                               'TS', 'Temp Segment',
                               'IV', 'Library Cache Invalida-tion',
                               'LS', 'Log Start or Switch',
                               'RW', 'Row Wait',
                               'SQ', 'Sequence Number',
                               'TE', 'Extend Table',
                               'TT', 'Temp Table',
                               'Un-Known Type of Lock')
              into wlock_type
              from dual;
           declare
             cursor c3 is
               select object_id from gv$locked_object
                 where session_id = wsid;
           begin
             wobject_name := '';
             for c3_rec in c3 loop
               select object_type||': '||owner||'.'||object_name
                into wobject_name
                from dba_objects
                where object_id = c3_rec.object_id;
              wobject_name := wobject_name ||' '||wobject_name1;
            end loop;
          exception
            when others then
              wobject_name := wobject_name ||' No Object Found';
          end;
          dbms_output.put_line('Lock Held: '||wlock_type||' for Object :'||wobject_name);
        exception
          when no_data_found then
            dbms_output.put_line('Lock Held: '||wlock_type||' No object found in DBA Objects');
        end;
      end if;
         wstep  := 30;
      select '....Requestor Instance:' || i.instance_name ||' SID:'|| s.sid ||' SERIAL:'||s.serial#||
        ' OSU:'||s.osuser ||' DBP:'||p.spid||' APP:'|| s.process || ' AppSrv:'||substr(machine,0,30) ||
        ' Status:' || s.status  || ' (' ||         floor(last_call_et/3600)||':'||
                                  floor(mod(last_call_et,3600)/60)||':'||
                                  mod(mod(last_call_et,3600),60) ||
                  ')  Waiting_for:' || round(c1_rec.ctime/60) || 'min'||' Module:'|| module
            into wholder_detail
            from gv$session s, gv$process p, gv$instance i
            where s.inst_id=i.inst_id
               and i.inst_id=c1_rec.inst_id
              and s.sid= c1_rec.sid
              and s.paddr = p.addr
              and s.INST_ID=p.INST_ID;
      dbms_output.put_line(wholder_detail);
      wid1  := c1_rec.id1;
      wid2  := c1_rec.id2;
    end loop;
    if wid1 = -999999 then
         wstep  := 40;
      dbms_output.put_line('No one requesting locks held by others');
    end if;
  exception
    when others then
           v_err_msg := (sqlerrm ||'  '|| sqlcode||' step='||to_char(wstep));
      DBMS_OUTPUT.PUT_LINE(v_err_msg);
 end;
/
