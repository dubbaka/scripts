-- @sga_used.sql

set feed off verify off linesize 200


col sga_size  head "SGA Size" for 99,999.99
col sga_used  head "Used" for 99,999.99
col sga_avail head "Available" for 99,999.99
col sga_pct   head "Pct Used" for 999.99

spool spool\sga_sizing.lis

select 	a.inst_id,max(b.value)/(1024*1024) sga_size, sum(a.bytes)/(1024*1024) sga_used, 
      	(max(b.value)/(1024*1024))-(sum(a.bytes)/(1024*1024)) sga_avail, (sum(a.bytes)/max(b.value))*100 sga_pct
from 	gv$sgastat a, gv$parameter b 
where 	a.name in ('reserved stopper','table definiti','dictionary cache', 'library cache','sql area','PL/SQL DIANA','SEQ S.O.') 
and	b.name='shared_pool_size'
group by a.inst_id;

spool off
