/* dbActive.sql -- show info about user sessions */



col sid 	format 99999
col username 	format a10    head User
col osuser 	format a10
col logged_on 	format a13    head LOGON_TIME
col spid        format 99999  head OSpid
col process     format 999999 head OraPID
col machine 	format a15
col LastCallET 	format 99,999
col module 	format a80
col program 	format a80

accept trgtSID    number default 0   prompt 'Restrict to which SID <ALL> : '
accept trgtOSPID  number default 0   prompt 'Restrict to which OSpid <ALL> : '
accept trgtmod    char   default ALL prompt 'Restrict to which module <ALL> : '
accept trgtmach   char   default ALL prompt 'Restrict to which originating server <ALL> : '
accept trgtstatus char   default Y   prompt 'Limit to active sessions only <Y> : '

select s.sid, to_char(logon_time,'mm/dd hh:miAM') logged_on, s.status, s.process, p.spid, s.username, s.osuser, 
       s.machine, s.sql_hash_value, floor(last_call_et/60) "LastCallET", s.module, s.program, s.command
from   v$session s, v$process p
where  s.username is not null
and    s.type = 'USER'
and    s.paddr = p.addr
and  (&trgtSID = 0  or s.sid = &trgtSID)
and  (&trgtOSPID = 0  or p.spid = &trgtOSPID)
and  ((s.status = 'ACTIVE' and upper('&trgtstatus') = 'Y') or upper('&trgtstatus') != 'Y')
and  (upper(s.module) like upper('%&trgtmod%') or upper('&trgtmod') = 'ALL')
and  (upper(s.machine) like upper('%&trgtmach%') or upper('&trgtmach') = 'ALL')
order by logged_on;
