-- @FNDCustomPgms.sql

clear breaks columns computes

set feed off veri off pages 1000 lines 500

undef CustomPrefix
accept CustomPrefix char default XX prompt 'Module <XX>: '

select count(1) "Custom Conc Pgms"
from   applsys.FND_CONCURRENT_PROGRAMS
where  CONCURRENT_PROGRAM_NAME like '&CustomPrefix%';

select count(1) "Custom Forms"
from   apps.FND_FORM_VL
where  FORM_NAME like '&CustomPrefix%';

set feed on

select fcp.CONCURRENT_PROGRAM_ID, fcp.CONCURRENT_PROGRAM_NAME, fcp.CREATION_DATE, fcp.LAST_UPDATE_DATE, fcp.ENABLED_FLAG
     , fcp.RUN_ALONE_FLAG, fcp.SRS_FLAG, fcp.EXECUTION_METHOD_CODE, fcp.ARGUMENT_METHOD_CODE, fcp.QUEUE_METHOD_CODE
     , fcp.RESTART, fcpl.USER_CONCURRENT_PROGRAM_NAME
     , fcp.ROLLBACK_SEGMENT, fcp.OPTIMIZER_MODE, fcp.PROGRAM_TYPE
from   applsys.FND_CONCURRENT_PROGRAMS fcp , applsys.FND_CONCURRENT_PROGRAMS_tl fcpl
where  fcp.CONCURRENT_PROGRAM_NAME like '&CustomPrefix%'
and    fcpl.APPLICATION_ID = fcp.APPLICATION_ID
and    fcpl.CONCURRENT_PROGRAM_ID = fcp.CONCURRENT_PROGRAM_ID
and    fcpl.LANGUAGE='US';

select FORM_ID, FORM_NAME, CREATION_DATE, LAST_UPDATE_DATE, AUDIT_ENABLED_FLAG, USER_FORM_NAME, DESCRIPTION
from   apps.FND_FORM_VL
where  FORM_NAME like '&CustomPrefix%';
