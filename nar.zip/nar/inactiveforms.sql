clear columns breaks compute

set verify off lines 800
set pages 500
col inst_id for 9999 head "Inst|Id"
col SID for 99999
col "SERIAL#" for 999999
col process head "OSpid|APnode" for a6
col SPID head "OSpid|DBnode" for a6
col username for a10 head "Schema"
col osuser for a10
col machine for a15
col module for a30
col sql_hash_value head "SQL_HASH" for 9999999999
col program for a30
col logontime for a15

select distinct b.inst_id,b.sid,b.serial# ,b.status,b.program,b.username,b.action,b.module,
to_char( b.logon_time, 'dd-MON-yyyy hh24:mi:ss' ) logon_time,
trunc( sysdate-b.logon_time ) "Dy",
trunc( mod( (sysdate-b.logon_time)*24, 24 ) ) "Hr",
trunc( mod( (sysdate-b.logon_time)*24*60, 60 ) ) "Mi",
trunc( mod( (sysdate-b.logon_time)*24*60*60, 60 ) ) "Sec"
from gv$session b, gv$process c
where c.inst_id=b.inst_id
and b.inst_id=c.inst_id
and b.paddr=c.addr
and b.status='INACTIVE'
and (b.action like '%FRM%' or b.action like '%frm%' or b.program like '%TOAD%' or b.program like '%toad%' or b.program like
'SQL%' or b.program like '%sql%' or b.program like '%FRM%'
or b.program like '%frm%' or b.action like 'SQL%' or b.action like 'sql%' or b.action like 'TOAD%' or b.action like 'toad%')
and (trunc( mod( (sysdate-b.logon_time)*24,24)) >=12 or trunc( sysdate-b.logon_time )>=1)
order by 1
/
