set lines 132
set pages 500
column module heading "Module Name" format a48;
column machine heading "Machine Name" format a25;
column process heading "Process ID" format a10;

prompt
prompt Connection Usage Per process and module
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

select count(*), machine, process, module from gv$session where program like '%JDBC%' group by machine, process, module order by 3 asc
;
