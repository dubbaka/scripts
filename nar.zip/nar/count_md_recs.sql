/* count_md_recs.sql - count the good,bad and total recs in mtl_demand */
set verify off
set timing on
spool count_md_recs.lst
prompt Finding max demand_id in mtl_demand....
select max(demand_id) from inv.mtl_demand;
prompt Counting all rows in mtl_demand....
select count(*) from inv.mtl_demand;
prompt Counting all bad rows in mtl_demand....
select count(*) from inv.mtl_demand
 where primary_uom_quantity <= completed_quantity;
prompt Counting all good rows in mtl_demand....
select count(*) from inv.mtl_demand
 where primary_uom_quantity > completed_quantity;
spool off 
exit

