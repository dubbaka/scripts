set veri off echo off termout on pau off

clear columns breaks computes

undef _MyDbVer _MyDB1 _MyDB2 _MySID

col dbver new_value _MyDbVer noprint
col val1 new_value _MyDB1 noprint
col val2 new_value _MyDB2 noprint
col mysid new_value _MySID noprint
set feed off
define_editor=notepad3
select INSTANCE_NAME "val1" from v$instance;
select user "val2" from dual;
-- select CASE substr(banner,17,3) WHEN '10g' THEN '10g' ELSE '9i' END "dbver" from v$version where rownum = 1;
select substr(banner,17,3) "dbver" from v$version where rownum = 1;
select trim(sid) "mysid" from v$mystat where rownum = 1;

set wrap on lines 300 pages 200 pau off time on timing on 
--termout on
set pau ...........

col NAME_COL_PLUS_SHOW_PARAM for a30
col VALUE_COL_PLUS_SHOW_PARAM for a80
set sqlprompt "&_MyDB1-&_MyDB2-&_MyDbVer-&_MySID> "
col NAME_COL_PLUS_SHOW_PARAM for a30
col VALUE_COL_PLUS_SHOW_PARAM for a50
set feed on
col val_3_datesp new_value ___dtsp noprint

select to_char(sysdate,'YYMMDDHHMISS') val_3_datesp  from dual ; 
spool  &_MyDB1&___dtsp..txt