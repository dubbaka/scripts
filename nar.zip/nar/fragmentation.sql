declare
v_total_blocks number;
v_total_bytes number;
v_unused_blocks number;
v_unused_bytes number;
v_last_used_extent_file_id number;
v_last_used_extent_block_id number;
v_last_used_block number;
v_free_blocks number;
begin
dbms_space.unused_space ('ONT','OE_LINES_IFACE_ALL','TABLE',v_total_blocks,
v_total_bytes, v_unused_blocks, v_unused_bytes,
v_last_used_extent_file_id, v_last_used_extent_block_id, v_last_used_block);

DBMS_SPACE.FREE_BLOCKS('ONT', 'OE_LINES_IFACE_ALL','TABLE',0,v_free_blocks);

dbms_output.put_line('total bytes = '||v_total_bytes);
dbms_output.put_line('unused bytes = '||v_unused_bytes);
dbms_output.put_line('total blocks = '||v_total_blocks);
dbms_output.put_line('unused blocks = '||v_unused_blocks);
dbms_output.put_line('last used extent fileid = '||v_last_used_extent_file_id);
dbms_output.put_line('last used extent blockid = '||v_last_used_extent_block_id);
dbms_output.put_line('last used block = '||v_last_used_block);

dbms_output.put_line('Nb of free blocks below the HWM = '||v_free_blocks);
end;
/

