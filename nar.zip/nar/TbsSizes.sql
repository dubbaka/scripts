-- @TbsSizes.sql

clear columns breaks computes

set lines 2000 pages 3000 feed off head on echo off pau off timing on time off veri off trimspool on  colsep |

col "SizeGB" for 9999999.99
col "UsedGB" for 9999999.99
col "FreeGB" for 9999999.99
col "%Used" for 999.99
col "%Free" for 999.99
col "BlockSize" for a9
col INITIAL_EXTENT for a10 head "InitExtent"
col NEXT_EXTENT for a10 head "NextExtent"
col MIN_EXTENTS for a10 head "MinExtents"
col MAX_EXTENTS for a10 head "MaxExtents"
col PCT_INCREASE for a4 head "%Inc"
col EXTENT_MANAGEMENT for a18 head "ExtentManagement"
col ALLOCATION_TYPE for a16 head "AllocationType"
col SEGMENT_SPACE_MANAGEMENT for a22 head "SegmentSpaceManagement"

col "TimeNow"      for a18
col pHost for a10
col pSid for a10

col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;

prompt Tablespace Sizes
select  '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", dts.tablespace_name, NVL(ddf.bytes/(1073741824), 0) "SizeGB", NVL(ddf.bytes-NVL(dfs.bytes,0),0)/(1073741824) "UsedGB"
, NVL(dfs.bytes/(1073741824), 0) "FreeGB", (NVL(ddf.bytes,0)-NVL(dfs.bytes,0))/NVL(ddf.bytes,1)*100 "%Used"
, NVL(dfs.bytes,0)/NVL(ddf.bytes,1)*100 "%Free"
, (BLOCK_SIZE/1024)||'K' "BlockSize", nvl(to_char(INITIAL_EXTENT),'null') INITIAL_EXTENT, nvl(to_char(NEXT_EXTENT),'null') NEXT_EXTENT
, nvl(to_char(MIN_EXTENTS),'null') MIN_EXTENTS, nvl(to_char(MAX_EXTENTS),'null') MAX_EXTENTS, nvl(to_char(PCT_INCREASE),'null') PCT_INCREASE, STATUS
, LOGGING, EXTENT_MANAGEMENT, ALLOCATION_TYPE, SEGMENT_SPACE_MANAGEMENT
from dba_tablespaces dts, (select tablespace_name, sum(bytes) bytes from dba_data_files group by tablespace_name) ddf,
    (select tablespace_name, sum(bytes) bytes from dba_free_space group by tablespace_name) dfs
where dts.tablespace_name = ddf.tablespace_name(+) 
and dts.tablespace_name = dfs.tablespace_name(+);

clear columns breaks computes

