-- @crt_logoff_trig.sql

drop trigger sys.my_logoff_trig;
CREATE or REPLACE trigger sys.my_logoff_trig BEFORE logoff ON DATABASE
DECLARE
   logoff_sid   pls_integer;
   login_user   varchar2(20);
   logoff_time  date        := sysdate;
BEGIN
   SELECT sid INTO logoff_sid FROM v$mystat WHERE rownum = 1;
   
   SELECT SYS_CONTEXT('USERENV', 'SESSION_USER') INTO login_user FROM DUAL;
   
   IF login_user not in ('SYS' , 'SYSMAN') THEN
      INSERT INTO system.my_session_event_history (sid, serial#, process, spid, username, osuser, machine, module, program, logon_time, last_call_et, type, sql_hash_value, action, average_wait, max_wait, event, total_waits, total_timeouts, time_waited, logoff_timestamp, WAIT_CLASS)
      SELECT s.sid, s.serial#, s.process, p.spid, s.username, s.osuser, s.machine, s.module, s.program, s.logon_time, s.last_call_et, s.type, s.sql_hash_value, s.action, a.average_wait, a.max_wait, a.event, a.total_waits, a.total_timeouts, a.time_waited, sysdate , a.WAIT_CLASS
      FROM   v$session_event a, v$session s, v$process p
      WHERE  a.sid      = s.sid
      AND    s.username = login_user
      AND    s.sid      = logoff_sid
      AND    p.addr = s.paddr;
   
      INSERT INTO system.my_sesstat_history (sid, serial#, process, spid, username, osuser, machine, module, program, logon_time, last_call_et, type, sql_hash_value, action, statistic#, name, value, logoff_timestamp, WAIT_CLASS)
      SELECT s.sid, s.serial#, s.process, p.spid, s.username, s.osuser, s.machine, s.module, s.program, s.logon_time, s.last_call_et, s.type, s.sql_hash_value, s.action, a.statistic#, b.name, a.value, sysdate, 'CPU Time'
      FROM   v$sesstat a, v$statname b, v$session s, v$process p
      WHERE  a.statistic# = b.statistic#
      AND    a.sid      = s.sid
      AND    b.name in ('CPU used when call started' , 'CPU used by this session' , 'recursive cpu usage' , 'parse time cpu')
      AND    s.sid      = logoff_sid
      AND    s.username = login_user
      AND    p.addr = s.paddr;
   END IF;
END;
/
