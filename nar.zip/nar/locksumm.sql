col mode_held head HOLDING format a10 trunc
col mode_requested head REQUESTING format a10 trunc
col blocking_others head BLOCKING format a15 trunc
select count(*),l.lock_type,l.mode_held,l.mode_requested,l.blocking_others
from dba_locks l
where l.session_id not in (select sid from v$session where type = 'BACKGROUND')
group by lock_type,blocking_others,mode_held,mode_requested
/
