/* tsbufhit.sql
   check the current i/o hit ratio for a period of 30 seconds
*/

set serveroutput on
set feedback off
prompt Gathering data...
declare
   bval number := 0;
   eval number := 0;
   bcon number := 0;
   econ number := 0;
   bphr number := 0;
   ephr number := 0;
   bphw number := 0;
   ephw number := 0;
   btim number := 0;
   etim number := 0;
   lctr number := 0;
   xctr number := 0;
   ttim number := 0;
   tval number := 0;
   tcon number := 0;
   tphr number := 0;
   tphw number := 0;
   rval number := 0;
   rtim number := 0;
   rhit number(3,2) := 0.00;
begin

/* -- get initial values -- */
select a.value, t.hsecs, b.value, c.value, d.value
  into bval, btim, bcon, bphr, bphw
from v$sysstat a, v$timer t, v$sysstat b, v$sysstat c, v$sysstat d
where a.statistic# = 38
  and b.statistic# = 39
  and c.statistic# = 40
  and d.statistic# = 73;

/* -- sleep a little while -- */
dbms_lock.sleep(30);

/* -- get finishing values -- */
select a.value, t.hsecs, b.value, c.value, d.value
  into eval, etim, econ, ephr, ephw
from v$sysstat a, v$timer t, v$sysstat b, v$sysstat c, v$sysstat d
where a.statistic# = 38
  and b.statistic# = 39
  and c.statistic# = 40
  and d.statistic# = 73;

/* -- perform the computations -- */
ttim := etim - btim;
tval := eval - bval;
tcon := econ - bcon;
tphr := ephr - bphr;
tphw := ephw - bphw;
rtim := ttim/100;
rval := (tval+tcon);
rhit := ((tval+tcon-tphr)/(tval+tcon));

/* -- report results -- */
dbms_output.put_line (' ');
-- dbms_output.put_line ('DBBlk Gets: ' || bval || ' '  || eval || ' ' || tval);
-- dbms_output.put_line ('Const Gets: ' || bcon || ' '  || econ || ' ' || tcon);
-- dbms_output.put_line ('Phys Reads: ' || bphr || ' '  || ephr || ' ' || tphr);
dbms_output.put_line ('Net DB I/O Stats over the  last ' || rtim || ' seconds:');
dbms_output.put_line (chr(9) || tcon || chr(9) || 'Consistent gets');
dbms_output.put_line (chr(9) || tval || chr(9) || 'DB Block gets');
dbms_output.put_line (chr(9) || tphr || chr(9) || 'Physical Reads');
dbms_output.put_line ('Buffer Cache Hit Ratio: ' || rhit);
end;
/


