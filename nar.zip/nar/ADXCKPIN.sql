REM dbdrv:none
REM $Header: ADXCKPIN.sql 115.1 2004/04/20 12:03:33 rupsingh ship $
REM +======================================================================+
REM | Copyright (c) 1994 Oracle Corporation Redwood Shores, California, USA|
REM |                       All rights reserved.                           |
REM +======================================================================+
REM
REM NAME
REM   ADXCKPIN.sql - Query the SGA to determine pinned PL/SQL objects
REM
REM DESCRIPTION
REM   Query the shared_pool area to determine space used by PL/SQL objects
REM   and whether they have been pinned.
REM
REM NOTES
REM   This script can be run at any time to determine what PL/SQL objects
REM   are in the SGA, and the total space consumed.  It should be run
REM   from the system user.
REM   PROCEDURES cannot be pinned.
REM +======================================================================+

set lines 79
column type format a12
column OBJECT format a36
column loads format 99990
column execs format 9999990
column kept format a4
column "TOTAL SPACE (K)" format a20

spool ADXCKPIN.lst

select owner || '.' || name OBJECT
	, type
	, to_char(sharable_mem/1024,'9,999.9') "SPACE(K)"
	, loads
	, executions execs
	, kept
from v$db_object_cache
where type in ('FUNCTION','PACKAGE','PACKAGE BODY','PROCEDURE')
  and owner not in ('SYS')
order by owner, name
/
select to_char(sum(sharable_mem)/1024,'9,999,999.9') "TOTAL SPACE (K)"
from v$db_object_cache
where type in ('FUNCTION','PACKAGE','PACKAGE BODY','PROCEDURE')
  and owner not in ('SYS')
/

spool off

