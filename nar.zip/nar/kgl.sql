/* kgl.sql
	get info on sessions that show library cache waits
*/
alter session set optimizer_mode = rule;
col holder_module format a20 trunc
col locked_object format a30 trunc
col holder_srvr format a15 trunc
col ktype format a6 trunc
col holder format 99999
col requestor format 99999
col holder_wait format a35 trunc
select s.sid holder, 
	decode(x.kgllkmod,2,'S',3,'X',1,'N') "mode" ,
      	x.KGLLKTYPE ktype ,
      	w.sid requestor, 
	decode(w.reqmode,2,'S',3,'X',1,'N') "req" ,
      	w.wtype, 
	o.KGLNAOWN||'.'||o.KGLNAOBJ locked_object ,
      	o.KGLOBTYP ,
	s.sql_hash_value holder_sql,
	s.module holder_module,
	s.machine holder_srvr,
	hw.event  || ' - ' || hw.wait_time holder_wait
  from dba_kgllock x, x$kglob o, v$session s, v$session_wait hw,
    (select sid, p1raw, trunc(p3/10) reqmode 
           ,decode(substr(event,15),'pin','Pin','lock','Lock') wtype 
       from v$session_Wait 
      where event like 'library cache %' ) w 
where x.kgllkHDL = w.p1raw 
  and x.kgllkMOD > 0 
  and x.kgllkuse = s.saddr 
  and x.kgllkHDL = o.kglhdadr 
  and x.KGLLKTYPE = wtype
  and s.sid = hw.sid
order by 7,3,5;
