set pagesize 500
set linesize 300
set trim on

col "tablespace" for a20
col "filename" for a60
col "Bytes(MB)" for 9,999,999
col "MaxBytes(MB)" for 9,999,999,999

spool ORACLE_FILE_USAGE.OUT
select df.tablespace_name "tablespace"
     , df.file_name       "filename"
     , df.bytes/(1024*1024)           "Bytes(MB)"
     , df.blocks          "blocks"
     , df.maxbytes/(1024*1024)        "MaxBytes(MB)"
     , df.maxblocks       "max_blocks"
     , sum(fr.bytes)      "free_bytes"
     , sum(fr.blocks)     "free_blocks"
     , count(fr.block_id) "free_spaces"
     , fs.phyrds          "reads"
     , fs.phywrts         "writes"
     , fs.phyblkrd        "block_reads"
     , fs.phyblkwrt       "block_writes"
     , fs.avgiotim        "avg_io_cs"
     , fs.miniotim        "min_io_cs"
     , fs.maxiowtm        "max_io_write_cs"
     , fs.maxiortm        "max_io_read_cs"
 from v$filestat fs
     , dba_data_files df
     , dba_free_space fr
 where df.file_id = fs.file#
   and fr.file_id(+) = df.file_id
 group by df.tablespace_name
        , df.file_name
        , df.bytes
        , df.blocks
        , df.maxbytes
        , df.maxblocks
        , fs.phyrds
        , fs.phywrts
        , fs.phyblkrd
        , fs.phyblkwrt
        , fs.avgiotim
        , fs.miniotim
        , fs.maxiowtm
        , fs.maxiortm
 order by df.tablespace_name, df.file_name;

select df.tablespace_name "tablespace"
     , df.file_name       "filename"
     , df.bytes           "bytes"
     , df.blocks          "blocks"
     , df.maxbytes        "max_bytes"
     , df.maxblocks       "max_blocks"
     , sum(fr.bytes)      "free_bytes"
     , sum(fr.blocks)     "free_blocks"
     , count(fr.block_id) "free_spaces"
     , fs.phyrds          "reads"
     , fs.phywrts         "writes"
     , fs.phyblkrd        "block_reads"
     , fs.phyblkwrt       "block_writes"
     , fs.avgiotim        "avg_io_cs"
     , fs.miniotim        "min_io_cs"
     , fs.maxiowtm        "max_io_write_cs"
     , fs.maxiortm        "max_io_read_cs"
 from v$tempstat fs
     , dba_temp_files df
     , dba_free_space fr
 where df.file_id = fs.file#
   and fr.file_id(+) = df.file_id
 group by df.tablespace_name
        , df.file_name
        , df.bytes
        , df.blocks
        , df.maxbytes
        , df.maxblocks
        , fs.phyrds
        , fs.phywrts
        , fs.phyblkrd
        , fs.phyblkwrt
        , fs.avgiotim
        , fs.miniotim
        , fs.maxiowtm
        , fs.maxiortm
 order by df.tablespace_name, df.file_name;

spool off
set lines 2000
set pages 40