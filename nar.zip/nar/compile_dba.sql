set pagesize 200
spool compile_dba1.sql
select 'alter '||decode(object_type,'PACKAGE BODY','PACKAGE',object_type)||' '||
owner||'.'||object_name||' compile'||decode(object_type,'PACKAGE BODY',' body;',';')
from dba_objects where status='INVALID';
spool off
