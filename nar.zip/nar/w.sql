/* sidwaits.sql
     see sesssions and what they are waiting on
	SDR-Oracle
*/
col event format a30
--col proginfo format a30
col umachine format a20 trunc
col sid format 999999
col p1p2p3txt format a30
col p2 format 9999999
col p3 format 9999999
col wait_sec format 99999
col action format a30 trunc
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11

select w.sid, floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET", 
w.event,w.SECONDS_IN_WAIT Wait_Sec,
	s.sql_hash_value, s.process,p.spid, 
	replace(s.machine,'GEIPS-AMER\',null) umachine,s.action,	w.p1 || ':' || w.p2 || ':' || w.p3 p1p2p3txt,
       nvl(s.module,'UNKnown') proginfo
from v$session_wait w, v$session s, v$process p
 where w.event not like 'SQL*Net%client'
and w.event not like '%timer%'
and w.event not like 'rdbms ipc%'
and w.event not like 'pipe get%'
and w.event not like '%manager%'
and w.event not like 'queue message%'
and s.sid = w.sid
and s.paddr = p.addr
and w.wait_time = 0
order by wait_sec desc
/

