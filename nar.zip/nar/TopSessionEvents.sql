-- @TopSessionEvents.sql

REM time_waited is in centiseconds (1/100th of a second)
REM 1Hr = 60 mins = 3,600 secs = 3,60,000 centiseconds = 3,6,000,000 milliseconds or microsecond

clear columns breaks computes

set lines 2000 pages 10000 veri off pau off trimspool on colsep |

col "EventShort" for a40 trunc
col total_waits for 9,999,999,999 head "Waits"
col total_timeouts for 9,999,999,999 head "TimeOuts"
col "TimeMins" for 999,999.99 head "TimeSpent|(Mins)"
col "TimeHrs" for 999,999.99 head "TimeSpent|(Hrs)"
col SID for 99999
col USERNAME for a10 trunc
col sql_id for a14 head "SqlID"
COL MACHINE for a10 trunc
col logontime for a15
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11
col module for a20 trunc
col program for a60 trunc
col WAIT_CLASS for a15 trunc
col action for a15 trunc


prompt 
prompt Get the uptime of the database
col "Uptime(secs)" new_value _TimeMS
col "Uptime(Mins)" for 99999.99
col "Uptime(Hrs)"  for 99999.99
col "TimeNow" for a18
col STARTUP_TIME for a18 head 'started@'
select to_char(sysdate,'dd-Mon-yy hh24:mi:ss') "TimeNow", to_char(STARTUP_TIME,'dd-Mon-yy hh24:mi:ss') STARTUP_TIME
, (sysdate-STARTUP_TIME)*86400*1000 "Uptime(ms)", (sysdate-STARTUP_TIME)*86400 "Uptime(Secs)"
, (sysdate-STARTUP_TIME)*1440 "Uptime(Mins)", (sysdate-STARTUP_TIME)*24 "Uptime(Hrs)"
from v$instance;


prompt 
prompt Top 50 Timed NonIdle Events
select * from (
select a.SID, to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime
, floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
, (a.time_waited/(100*60)) "TimeMins", (a.time_waited/(100*60*60)) "TimeHrs", s.SQL_HASH_VALUE, s.module, s.action, a.event "EventShort"
, s.username, s.STATUS, s.MACHINE, a.total_waits, a.total_timeouts, s.program
from v$session_event a , v$session s
where  s.sid = a.sid
order by a.time_waited desc)
where rownum <=51;
