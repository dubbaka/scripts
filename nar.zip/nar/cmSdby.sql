-- @CMSdby.sql
-- Display all Standby Requests

clear columns breaks computes

Select Fcr.Request_Id, Fcp.Concurrent_Program_Name||'-->'||Fcptl.user_concurrent_program_name "ConcurrentProgram"
       ,Fcp.Run_Alone_Flag "RunAlone?", to_char(REQUEST_DATE, 'DD-MON-YY HH:MI AM') "RequestDate"
       ,Fu.User_name||Fu.Description "SubmittedBy"
  from Fnd_Concurrent_Requests  Fcr, Fnd_Concurrent_Programs Fcp, Fnd_User Fu, Fnd_Concurrent_Programs_tl Fcptl
 where Fcr.Status_Code = 'Q'
   And Fcr.Concurrent_Program_Id  = Fcp.Concurrent_Program_Id
   And Fcr.Program_Application_Id = Fcp.Application_Id
   And Fcr.Requested_By           = Fu.User_Id
   And Fcptl.concurrent_program_id = Fcp.concurrent_program_id
order by REQUEST_DATE;
