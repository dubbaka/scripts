select * from (select a.host,trunc(a.Collected_date) as CollDate, count(1) as DataPoints, min(a.Day) as Day, 
min(a.Year) as Year, min(a.month) as Month, min(round(CPUUSER+CPUSYS+CPUWIO,2)) as MinCPU, round(avg(CPUUSER+CPUSYS+CPUWIO),2) as AvgCPU, 
max(CASE WHEN round(CPUUSER+CPUSYS+CPUWIO,2) >100 THEN 100 ELSE round(CPUUSER+CPUSYS+CPUWIO,2) END) as MaxCPU, 
'Limit=366' as Remarks 
FROM XXPERFCAP.MY_OS_CPU_USAGE a 
WHERE a.Host in ( 'bze1ua15',
'bze1ua14',
'bze1ua15',
'bze1ua10',
'bze1ua05',
'bze1ua06') and a.Year = '2009' and a.Month = 'Sep' 
and trim(to_char(Collected_date, 'hh24:mi')) between '09:00' and '16:30' 
Group By a.host trunc(a.Collected_date)) where rownum <= 366 )