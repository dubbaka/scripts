-- @TopSidsByCPU.sql

clear columns breaks computes

col inst_id for 9999 head "Inst|Id"
col sid for 99999
col SQL_HASH_VALUE head "SQL_HASH"
col username for a15 trunc
col SCHEMANAME for a15 head "Schema" trunc
col OSUSER for a10 trunc
col logontime for a15
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11
col MACHINE for a20 trunc
col MODULE for a20 trunc
col "CPU(mins)"  for 9,999.99

set lines 1000

accept trgtRows number default 20 prompt 'Rows to display <20> : '
accept trgtINST number default 0 prompt 'Instance ID : '
accept trgtStatus char default ACTIVE prompt 'Status [ACTIVE | INACTIVE | ALL] <ACTIVE> : '
accept trgtType char default USER prompt 'Process TYpe [BACKGROUND | USER | ALL] <USER> : '

prompt Top 15 Sessions by CPU usage

select * from (
select s.INST_ID, st.value/(100*60) "CPU(mins)", s.sid, s.serial#, s.SQL_HASH_VALUE, s.MODULE, s.type, s.username, s.STATUS
     , to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime
     , floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
     , s.ACTION, s.OSUSER, s.MACHINE, s.SERVER, s.SCHEMANAME, s.LOCKWAIT, s.CLIENT_IDENTIFIER, s.CLIENT_INFO
from   gv$session s, gv$sesstat st, gv$statname sn
where (s.INST_ID = &trgtINST or &trgtINST = 0)
and    s.sid = st.sid
and    sn.statistic# = st.statistic#
and    sn.name = 'CPU used by this session'
AND    NVL(s.username,'XX') NOT IN ('SYS', 'SYSTEM', 'XX')
and   (s.status = upper('&trgtStatus') or '&trgtStatus' = 'ALL')
and   (s.type   = upper('&trgtType')   or '&trgtType'   = 'ALL')
order  by st.value desc
)
where rownum <= &trgtRows;
