select * from v$sess_io where sid=&SID
/
