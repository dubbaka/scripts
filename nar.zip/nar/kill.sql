

set veri off feed on
alter system kill session '&sid.,&serial.';
