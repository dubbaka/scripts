/* @FndForm.sql
    find the Oracle Form based on short name or Long name or product short name or application name
*/


clear columns breaks computes

col APPLICATION_SHORT_NAME head "Product" for a7
col APPLICATION_NAME head "Application" for a50
col FORM_NAME for a20
col USER_FORM_NAME head "Form" for a40

accept trgtFORMShrt char default ALL prompt 'Form Short Name    <ALL> : '
accept trgtFormFull char default ALL prompt 'Form Full  Name    <ALL> : '
accept trgtProductShrt  char default ALL prompt 'Product Short Name <ALL> : '
accept trgtProductFull  char default ALL prompt 'Product Full Name <ALL> : '

spool spool\FndForm_&_MyDB1.

select ff.FORM_NAME, fft.USER_FORM_NAME, fa.APPLICATION_SHORT_NAME, fat.APPLICATION_NAME
--, ff.APPLICATION_ID, ff.FORM_ID
from   applsys.fnd_form ff, applsys.fnd_form_tl  fft, applsys.fnd_application fa, applsys.fnd_application_tl fat
where (upper(ff.form_name)       like upper('%&trgtFORMShrt%')      or upper('&trgtFORMShrt')     = 'ALL')
and   (upper(fft.user_form_name) like upper('%&trgtFormFull%')  or upper('&trgtFormFull') = 'ALL')
and   (upper(fa.APPLICATION_SHORT_NAME) = upper('&trgtProductShrt') or upper('&trgtProductShrt')  = 'ALL')
and   (upper(fat.APPLICATION_NAME) like upper('%&trgtProductFull%') or upper('&trgtProductFull')  = 'ALL')
and    fft.APPLICATION_ID  = ff.APPLICATION_ID
and    fft.FORM_ID         = ff.FORM_ID
and    fft.LANGUAGE        = 'US'
and    fa.APPLICATION_ID   = fft.APPLICATION_ID
and    fat.APPLICATION_ID  = fa.APPLICATION_ID
and    fat.LANGUAGE        = 'US'
order  by ff.FORM_NAME;

spool off
