-- @SIDMaxWaited.sql

REM time_waited is in centiseconds (1/100th of a second)
REM 1Hr = 60 mins = 3,600 secs = 3,60,000 centiseconds

clear columns computes breaks
col WAIT_CLASS for a15 trunc
col "Module" for a40 trunc

set verify off lines 325 pages 50

break on report

col inst_id for 9999 head "Inst|Id"
col SID           for 99999
col "TimeMins"    for 999,999.99      head "TimeSpent|(Mins)"
col "TimeHrs"     for 999,999.99      head "TimeSpent|(Hrs)"
col "LastCallET"  for a11             head "LastCallEt|(hh:mi:ss)" 
col Schema        for a10 trunc
col WAIT_CLASS    for a15

accept trgtRows number default 20 prompt 'Rows to display <20> : '

select * from (
select a.inst_id, a.WAIT_CLASS, a.sid, sum((a.time_waited/(100*60))) "TimeMins", sum((a.time_waited/(100*60*60))) "TimeHrs", min(to_char(s.logon_time,'Mon/dd hh24:mi:ss')) logontime
     , min(floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60)) "LastCallET", max(s.username) Schema, max(module) "Module"
from   gv$session_event a, gv$session s
where  a.inst_id = s.inst_id
and    s.sid = a.sid
and    a.time_waited > = 0
and    a.WAIT_CLASS not in 'Idle'
and    s.module is not null
and    s.module not in ('JDBC Thin Client' , 'WFMLRSVC' , 'WFWSSVC' , 'WFALSNRSVC')
group  by a.inst_id, a.WAIT_CLASS, a.sid
union all
select a.inst_id, s.WAIT_CLASS, a.sid, sum((a.value/(100*60))) "TimeMins", sum((a.value/(100*60*60))) "TimeHrs", min(to_char(s.logon_time,'Mon/dd hh24:mi:ss')) logontime
     , min(floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60)) "LastCallET", max(s.username) Username, max(module) "Module"
from   gv$sesstat a, gV$STATNAME b, gv$session s
where  a.inst_id = b.inst_id
and    a.inst_id = s.inst_id
and    s.sid = a.sid
and    b.name = 'CPU used when call started'
and    b.STATISTIC# = a.STATISTIC#
and    s.module is not null
and    s.module not in ('JDBC Thin Client' , 'WFMLRSVC' , 'WFWSSVC' , 'WFALSNRSVC')
group  by a.inst_id, s.WAIT_CLASS, a.sid
order by "TimeMins" desc
)
where rownum <= &trgtRows;
