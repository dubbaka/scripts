-- @IndexesInaTablespace.sql


undefine Tablespace

clear columns breaks compute

clear columns breaks compute

col owner for a15
col table_owner for a15
col table_name for a30
col tablespace_name for a15 head 'Tablespace'
col index_type for a15

set head on pages 45 pau on lines 1000

spool spool\IndexesInaTablespace_&_MyDB1.

select owner, index_type, index_name, num_rows, status, table_owner, table_name, table_type, uniqueness, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY
, AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, degree, tablespace_name, pct_free, initial_extent, next_extent, pct_increase, max_extents, partitioned, logging, buffer_pool
, ITYP_OWNER, ITYP_NAME, DOMIDX_STATUS, DOMIDX_OPSTATUS, FUNCIDX_STATUS, JOIN_INDEX
from   dba_indexes
where  tablespace_name = upper('&Tablespace');

spool off
