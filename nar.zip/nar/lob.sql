-- @lob.sql

clear columns breaks computes

set pages 40 pau off feed on lines 250

col owner for a10
col "tblowner" for a10
col TABLE_NAME for a30
col COLUMN_NAME for a30
col SEGMENT_NAME for a30
col segment_type for a12
col tblowner new_value _MyTblOwner
col "Bytes"  for 999,999,999,999
col "SizeKB" for 999,999,999
col "SizeMB" for 999,999.99
col "SizeGB" for 999.99

accept TblName char prompt 'Table : '
accept LOBname char prompt 'LOB   : '

select OWNER "tblowner", TABLE_NAME, COLUMN_NAME, SEGMENT_NAME, INDEX_NAME, CHUNK, PCTVERSION, RETENTION, FREEPOOLS, CACHE, LOGGING, IN_ROW
from   dba_lobs
where  (TABLE_NAME = upper('&TblName')  or  SEGMENT_NAME = '&LOBname'  or  INDEX_NAME = '&LOBname');

prompt 
accept junk1 char prompt "Press enter for LOB Size calcs.........."

select s.owner, s.segment_name, s.segment_type, sum(s.bytes) "Bytes", sum(s.bytes/1024) "SizeKB", sum(s.bytes)/(1024*1024) "SizeMB", sum(s.bytes)/(1024*1024*1024) "SizeGB"
--, s.extents, s.max_extents, s.initial_extent, s.next_extent, s.blocks, s.pct_increase
from   dba_lobs l, dba_segments s
where  s.segment_type = 'LOBSEGMENT'
and    (l.TABLE_NAME = upper('&TblName')  or  s.SEGMENT_NAME = '&LOBname'   or  l.INDEX_NAME = '&LOBname')
and    s.segment_name = l.segment_name
group  by s.owner, s.segment_name, s.segment_type;
