set verify off
col event format a35
col total_waits format 999999999
col time_waited format 999999.90
accept trgtsid number default 0 prompt 'What is the SID:'
prompt Note - time is in seconds
select event,
       e.total_waits,
       e.time_waited
from v$session_event e
where e.total_waits > 0
and (e.sid = &trgtsid and &trgtsid > 0)
and e.event not like '%time%'
and e.event not like 'SQL*Net%client'
and e.event not like 'pipe%'
and e.event not like '%ipc%'
/
