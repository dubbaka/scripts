set pagesize 0
set feedback off
set heading off
break on USER_CONCURRENT_QUEUE_NAME on MAX_PROCESSES
col USER_CONCURRENT_QUEUE_NAME format a40
SELECT a.USER_CONCURRENT_QUEUE_NAME,a.MAX_PROCESSES,b.PHASE_CODE,COUNT(b.PHASE_CODE) NUMCNT
FROM FND_CONCURRENT_QUEUES_VL a, FND_CONCURRENT_WORKER_REQUESTS b
WHERE a.enabled_flag='Y'
AND  a.concurrent_queue_id = b.concurrent_queue_id
AND  (b.Phase_Code = 'P') AND b.hold_flag != 'Y'
AND  b.Requested_Start_Date <= SYSDATE
AND a.USER_CONCURRENT_QUEUE_NAME NOT IN ('Conflict Resolution Manager')
HAVING COUNT(b.PHASE_CODE) > (a.MAX_PROCESSES * decode(a.USER_CONCURRENT_QUEUE_NAME,
                                                       'Agilent Common Manager',15,
                                                       'Inventory Manager',20,
                                                       'Agilent Long Running Manager',15,3))
GROUP BY a.USER_CONCURRENT_QUEUE_NAME,b.PHASE_CODE,a.MAX_PROCESSES
ORDER BY 1
/
