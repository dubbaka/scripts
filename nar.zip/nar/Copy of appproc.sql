/* appproc.sql
    find the Oracle session info for a given Oracle process id or OS process id
*/
col machine format a15
col program format a25
col LastCallET head "LastCallEt|(hh:mi:ss)" format a11
col module format a12
col PROCESS head "oraPID|APnode" for a6
col SPID head "OSpid|DBnode" for a6
col STATUS for a8

accept trgtOSproc char default ALL prompt 'What is the OS process id <ALL> : '
accept trgtOraproc char default ALL prompt 'What is the Oracle process id <ALL> : '
accept trgtSID number default 9999 prompt 'What is the Oracle SID <ALL> : '

select s.sid, s.serial#, s.status,
   floor(last_call_et/3600)||':'||floor(mod(last_call_et,3600)/60)||':'||mod(mod(last_call_et,3600),60) "LastCallET",
   s.sql_hash_value, s.machine, s.module, s.process, p.spid,
   p.PROGRAM "Process PGM", p.PID, p.USERNAME
from v$session s, v$process p
where s.paddr = p.addr
and (s.process = '&trgtOraproc' or upper('&trgtOraproc') = 'ALL') 
and (p.spid    = '&trgtOSproc'  or upper('&trgtOSproc') = 'ALL')
and (s.sid    = &trgtSID        or &trgtSID = 9999)
/

