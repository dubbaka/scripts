set verify off
set lines 132
break on index_name nodup on index_type nodup
col column_name format a30 trunc
col index_type format a10 trunc head TYPE
col uniqueness format a3 trunc head "U/N"
col lastanal format a15 head AnalyzeDate
col pctanal format 999 head PctAnalyzed
accept tabowner char prompt 'Who is the table owner : '
accept tabname char prompt 'What is the table name : '
select /*+ rule */ i.index_name,c.column_name,uniqueness,i.index_type, i.status,
	to_char(i.last_analyzed,'mm/dd/yy hh24:mi') lastanal,
        nvl(sample_size,0)/decode(nvl(num_rows,1),0,1,nvl(num_rows,1)) * 100 pctanal
from dba_ind_columns c, dba_indexes i
where i.table_name = upper('&tabname')
and i.table_owner = upper('&tabowner')
and i.table_owner = c.table_owner
and i.table_name = c.table_name
and i.index_name = c.index_name
order by index_name,column_position
/

