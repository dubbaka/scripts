REM
REM        START OF SQL
REM 
REM  Filename     : mzFndNodes.sql
REM  Author       : Mike Shaw
REM  Date Updated : 26 June 2006
REM  Purpose      : Script to extract the information about the nodes 
REM                 registered in Apps 11i
REM 
set serveroutput on
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 80
col PLATFORM_CODE form a5
col HOST form a20
col DOMAIN form a30
col WEBHOST form a30
col VIRTUAL_IP form a20
col status form a20
col ConcMgr form a8
col Forms form a8
col WebServer form a8
col Admin form a8
col Database form a8
col last_monitored form a40
--
REM spool mzFndNodes.txt
--
select 
	NODE_NAME,
	to_char(CREATION_DATE, 'DD-MON-RR HH24:MI') creation_date,
	PLATFORM_CODE,
	decode(STATUS,'Y','ACTIVE','INACTIVE') Status,
	decode(SUPPORT_CP,'Y', 'ConcMgr','No') ConcMgr,
	decode(SUPPORT_FORMS,'Y','Forms', 'No') Forms,
	decode(SUPPORT_WEB,'Y','Web', 'No') WebServer,
	decode(SUPPORT_ADMIN, 'Y','Admin', 'No') Admin,
	decode(SUPPORT_DB, 'Y','Rdbms', 'No') Database,
	to_char(LAST_MONITORED_TIME, 'DD-MON-RR HH24:MI:SS') last_monitored,
	NODE_MODE,
	SERVER_ADDRESS,
	HOST,
	DOMAIN,
	WEBHOST,
	VIRTUAL_IP,
	SERVER_ID
from fnd_nodes
where node_name != 'AUTHENTICATION'
/
REM 
REM        END OF SQL
REM 
