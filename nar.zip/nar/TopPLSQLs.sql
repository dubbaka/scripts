-- @TopPLSQLs.sql

prompt 
prompt Top 50 PL/SQL Code blocks
/* Value 47 for command_type identifies PL/SQL code; this helps you see how much they contribute to the total number of logical reads. 
Any call to a PL/SQL anonymous block or stored procedure is recorded inside v\$SQL, with its number of executions, its number of physical reads, 
and, most importantly, the number of logical reads (buffer_gets) it required */

clear columns breaks computes

set pages 50000 lines 2000 wrap off echo off feed off timing on time off veri off trimspool on colsep |

col inst_id for 99999 head 'InstId'
col "Module" for a40
col HASH_VALUE for 999999999999
col "BufferGets" for 999999999999999999999
col "Executions" for 999999999999999999999
col "RowsProcessed" for 999999999999999999999
col "DiskReads" for 999999999999999999999
col "Invalidations" for 999999999999999999999
col "Fetches" for 999999999999999999999
col "Loads" for 999999999999999999999
col "ParseCalls" for 999999999999999999999
col "Sorts" for 999999999999999999999
col "verCnt" for 999999999999999999999
col "LoadedVers" for 999999999999999999999
col "Action" for a30 trunc
col "CPUTime(s)" for 999999999999999999999
col "ElapsedTime(s)" for 999999999999999999999

col "TimeNow"      for a18
col pHost for a10
col pSid for a10

col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;


prompt 
prompt By Buffer Gets
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "BufferGets"  desc)
where rownum < 51;


prompt 
prompt By Executions
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "Executions" desc)
where rownum < 51;


prompt 
prompt By Disk Reads
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "DiskReads" desc)
where rownum < 51;


prompt 
prompt By Cpu Time
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "CPUTime(s)" desc)
where rownum < 51;


prompt 
prompt By Elapsed Time
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "ElapsedTime(s)" desc)
where rownum < 51;


prompt 
prompt By Rows Processed
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "RowsProcessed" desc)
where rownum < 51;


prompt 
prompt By Invalidations
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "Invalidations" desc)
where rownum < 51;


prompt 
prompt By Fetches
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "Fetches" desc)
where rownum < 51;


prompt 
prompt By Loads
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "Loads" desc)
where rownum < 51;


prompt 
prompt By Parse Calls
select * from (
   select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", inst_id, nvl(module,'null') "Module", HASH_VALUE, nvl(buffer_gets,0) "BufferGets", nvl(executions,0) "Executions"
   , nvl(rows_processed,0) "RowsProcessed", nvl(disk_reads,0) "DiskReads", nvl(INVALIDATIONS,0) "Invalidations", nvl(FETCHES,0) "Fetches"
   , nvl(LOADS,0) "Loads", nvl(PARSE_CALLS,0) "ParseCalls", nvl(SORTS,0) "Sorts", nvl(VERSION_COUNT,0) "verCnt", nvl(LOADED_VERSIONS,0) "LoadedVers"
   , NVL(ACTION,'null') "Action", nvl(cpu_time,0)/1000000 "CPUTime(s)", nvl(elapsed_time,0)/1000000 "ElapsedTime(s)"
   , sql_text sqltext
from gv$sqlarea
where command_type = 47
order by "ParseCalls" desc)
where rownum < 51;

clear columns breaks computes
