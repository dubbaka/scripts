
rem Script Description: This script lists all roles in the database and to whom (user or role) they were granted.  
rem                     This report is used to walk backwards along all access paths in the database to their start 
rem                     points (user names).  Used when researching the levels of security indirection in a database.
rem
rem      Column Legend: ROLE contains the role names in the database PWD indicates whether the role is password protected
rem                     GRANTED_TO contains the user or role to which the role was granted ADM is the Admin Option value 
rem                     from the grant statement DFLT indicates whether the role is a default role.
rem
rem
rem Output file:        rolelist.lis
rem
rem Prepared By:        TheOracleResourceStop Script Archive
rem                     www.orsweb.com
rem
rem Usage Information:  SQLPLUS SYS/pswd
rem                     @rolelist.sql

set pagesize 66 verify off termout off feedback off;

column role format A27;
column pwd format A9 Heading "Password|Protected";
column grantee format A15;
column adm format A6 Heading "Admin|Option";
column dflt format A7 Heading "Default|Role?";
ttitle left 'ROLELIST - List of all roles' skip 2;

spool rolelist.lst

SELECT r.role, r.password_required pwd, p.grantee, p.admin_option adm,
       p.default_role dflt
FROM dba_roles r, dba_role_privs p
WHERE r.role = p.granted_role(+)
ORDER BY 1, 3;

spool off
set termout on

