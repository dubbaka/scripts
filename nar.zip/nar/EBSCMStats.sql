-- @EBSCMStats.sql

clear columns breaks computes

set pages 50000 lines 2000 wrap off echo on feed on timing on time on veri off trimspool on colsep |

col "Requests" format 999999999
col "0000-0059"   for 9999999
col "0100-0159"   for 9999999
col "0200-0259"   for 9999999
col "0300-0359"   for 9999999
col "0400-0459"   for 9999999
col "0500-0559"   for 9999999
col "0600-0659"   for 9999999
col "0700-0759"   for 9999999
col "0800-0859"   for 9999999
col "0900-0959"   for 9999999
col "1000-1059"   for 9999999
col "1100-1159"   for 9999999
col "1200-1259"   for 9999999
col "1300-1359"   for 9999999
col "1400-1459"   for 9999999
col "1500-1559"   for 9999999
col "1600-1659"   for 9999999
col "1700-1759"   for 9999999
col "1800-1859"   for 9999999
col "1900-1959"   for 9999999
col "2000-2059"   for 9999999
col "2100-2159"   for 9999999
col "2200-2259"   for 9999999
col "2300-2359"   for 9999999
col "#OfRuns" format 999999999
col "FirstStartDate" for a22
col "LastStartDate" for a22
col "MinRun(Mins)" format 9999.999
col "AvgRun(Mins)" format 9999.999
col "MaxRun(Mins)" format 9999.999
col "ConcPgm" for a60
col "QueueName" format a30
col "Actual" format 99999
col "Target" format 99999
col "AvgDelay(Mins)" format 9999.999
col "Phase" for a5
col "Status" for a5
col "ReqStartDate" for a22
col "CompletedDate" for a22
col "ShortName" for a10
col "RunTime(Mins)" for 9999.99
col "RunTime(Hrs)" for 9999.99
col PROGRAM for a30
col ARGUMENT_TEXT for a50
col COMPLETION_TEXT for a30

prompt 
prompt Display Concurrent Requests run every day
select trunc(fcr.actual_start_date) Reqdate, count(1) "Requests"
from applsys.fnd_Concurrent_requests fcr
where fcr.actual_start_date is not null
group by trunc(fcr.actual_start_date);

prompt 
prompt Display Hourly COncurrent Pgms Requests startedand completed
select trunc(actual_start_date) Reqdate,
sum(decode(to_char(fcr.actual_start_date,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'23',1,0)) "2300-2359"
from applsys.fnd_Concurrent_requests fcr
where fcr.actual_start_date is not null
group by trunc(actual_start_date)
order by 1;

prompt Display all concurrent programs that took more than 30 mins
select fcp.CONCURRENT_PROGRAM_NAME "ShortName", count(1) "#OfRuns"
, to_char(min(fcr.actual_start_date),'dd-Mon-yyyy hh24:mi:ss') "FirstStartDate", to_char(max(fcr.actual_start_date),'dd-Mon-yyyy hh24:mi:ss') "LastStartDate"
, min((fcr.actual_completion_date-fcr.actual_start_date)*1440) "MinRun(Mins)", avg((fcr.actual_completion_date-fcr.actual_start_date)*1440) "AvgRun(Mins)"
, max((fcr.actual_completion_date-fcr.actual_start_date)*1440) "MaxRun(Mins)", fcpt.USER_CONCURRENT_PROGRAM_NAME "ConcPgm"
from applsys.fnd_Concurrent_requests fcr, applsys.fnd_concurrent_programs fcp, applsys.fnd_concurrent_programs_tl fcpt
where fcr.actual_start_date is not null
and fcr.actual_completion_date is not null
and fcr.phase_code = 'C'
and fcr.program_application_id = fcp.application_id
and fcr.concurrent_program_id = fcp.concurrent_program_id
and fcpt.APPLICATION_ID = fcp.application_id
and fcpt.CONCURRENT_PROGRAM_ID = fcp.concurrent_program_id
and fcpt.SOURCE_LANG = 'US'
and fcpt.LANGUAGE = 'US'
group by fcp.CONCURRENT_PROGRAM_NAME, fcpt.USER_CONCURRENT_PROGRAM_NAME, fcr.QUEUE_APP_ID, fcr.QUEUE_ID
having max((fcr.actual_completion_date-fcr.actual_start_date)*1440) > 30;


prompt 
prompt Getting queue statisticsfor the last 6 days. It may take a few mins. Please be patient....
select fcq.concurrent_queue_name "QueueName", fcq.target_node, count(fcr.request_id) "Requests", fcq.running_processes "Actual", fcq.max_processes "Target"
, avg((fcr.actual_start_date-fcr.requested_start_date)*1440) "AvgDelay(Mins)"
, min((fcr.actual_completion_date-fcr.actual_start_date)*1440) "MinRun(Mins)", avg((fcr.actual_completion_date-fcr.actual_start_date)*1440) "AvgRun(Mins)"
, max((fcr.actual_completion_date-fcr.actual_start_date)*1440) "MaxRun(Mins)"
from applsys.fnd_concurrent_requests fcr, applsys.fnd_concurrent_processes fcpr, applsys.fnd_concurrent_programs fcp, applsys.fnd_concurrent_queues fcq
where fcr.controlling_manager = fcpr.concurrent_process_id
and fcpr.queue_application_id = fcq.application_id
and fcpr.concurrent_queue_id = fcq.concurrent_queue_id
and trunc(fcr.actual_completion_date) between (SYSDATE-7) and (SYSDATE-1)
and fcr.concurrent_program_id = fcp.concurrent_program_id
and fcr.program_application_id = fcp.application_id
group by fcq.concurrent_queue_name, fcq.target_node, fcq.running_processes, fcq.max_processes;


prompt 
prompt Display Gather Schema Stats that ran in the last 7 days or scheduled to run in future
col "ConcPgm" for a30
select fcr.REQUEST_ID, decode(fcr.PHASE_CODE, 'R', 'Running', 'P', 'Scheduled', 'C', 'Completed', 'Raw:' ||fcr.PHASE_CODE) "Phase", fcr.STATUS_CODE "Status" 
, to_char(fcr.REQUESTED_START_DATE, 'DD-Mon-RRRR HH24:MI') "ReqStartDate", to_char(fcr.ACTUAL_COMPLETION_DATE, 'DD-Mon-RRRR HH24:MI') "CompletedDate"
, (fcr.ACTUAL_COMPLETION_DATE-fcr.REQUESTED_START_DATE)*1440 "RunTime(Mins)", (fcr.ACTUAL_COMPLETION_DATE-fcr.REQUESTED_START_DATE)*24 "RunTime(Hrs)"
, fcp.CONCURRENT_PROGRAM_NAME "ShortName"
, DECODE (fcr.DESCRIPTION, NULL, fcpt.USER_CONCURRENT_PROGRAM_NAME, fcr.DESCRIPTION||' ('||fcpt.USER_CONCURRENT_PROGRAM_NAME||')') "ConcPgm"
, fcr.ARGUMENT_TEXT, fcr.COMPLETION_TEXT
from applsys.FND_CONCURRENT_PROGRAMS_TL fcpt, applsys.FND_CONCURRENT_PROGRAMS fcp, applsys.FND_USER fU, applsys.fnd_Concurrent_requests fcr
where fcp.CONCURRENT_PROGRAM_ID = fcr.CONCURRENT_PROGRAM_ID 
and fcp.CONCURRENT_PROGRAM_ID = fcpt.CONCURRENT_PROGRAM_ID 
and fu.USER_ID = fcr.REQUESTED_BY 
and fcp.CONCURRENT_PROGRAM_NAME in ('FNDGACST','FNDGCLST','FNDGSCST','FNDGTST')
and fcr.REQUESTED_START_DATE >= (sysdate-7)
and fcpt.LANGUAGE = 'US'
order by fcr.PHASE_CODE, fcr.REQUESTED_START_DATE;

clear columns breaks computes
