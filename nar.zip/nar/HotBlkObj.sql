-- @HotBlkObj.sql

-- value for BLOCKNO is obtained by analyzing the p2 value for db_file_sequential_reqd/write

SELECT owner, segment_name, segment_type
FROM   dba_extents
WHERE  file_id = &AFN
AND   &BLOCKNO BETWEEN block_id AND (block_id + blocks-1);

