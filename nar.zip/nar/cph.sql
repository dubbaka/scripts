set pages 66
set feed on
set line 160
column  ProgName        format a40 word_wrapped
column  requestId       format 99999999999
column  StartDate       format a20 word_Wrapped
column  SERVER   format a6
column  CLIENT   format a6
column  ETime           format 99999 word_Wrapped
column  Arguments       format a20 word_wrapped
select distinct fcr.request_id, fcr.phase_code,fcr.status_code,fcp.USER_CONCURRENT_PROGRAM_NAME ProgName,fcr.ARGUMENT_TEXT Arguments,to_char(actual_Start_date,'DD-MON-YYYY HH24:MI:SS') StartDate,to_char(ACTUAL_COMPLETION_DATE,'DD-MON-YYYY HH24:MI:SS') CompleteDate 
from apps.fnd_concurrent_requests fcr,apps.fnd_concurrent_programs_tl  fcp where fcp.concurrent_program_id = fcr.concurrent_program_id and fcr.program_application_id = fcp.application_id and fcp.USER_CONCURRENT_PROGRAM_NAME like '%&ProgramName%';  
