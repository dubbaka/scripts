/* archlogs.sql
        find the number of archivelogs each hour of the day
*/
set pages 200
col logdate format a10
col MidN format 999
col 1AM format 999
col 2AM format 999
col 3AM format 999
col 4AM format 999
col 5AM format 999
col 6AM format 999
col 7AM format 999
col 8AM format 999
col 9AM format 999
col 10AM format 999
col 11AM format 999
col Noon format 999
col 1PM format 999
col 2PM format 999
col 3PM format 999
col 4PM format 999
col 5PM format 999
col 6PM format 999
col 7PM format 999
col 8PM format 999
col 9PM format 999
col 10PM format 999
col 11PM format 999

col "MidN GB" format 99.99
col "1AM GB" format 99.99
col "2AM GB" format 99.99
col "3AM GB" format 99.99
col "4AM GB" format 99.99
col "5AM GB" format 99.99
col "6AM GB" format 99.99
col "7AM GB" format 99.99
col "8AM GB" format 99.99
col "9AM GB" format 99.99
col "10AM GB" format 99.99
col "11AM GB" format 99.99
col "Noon GB" format 99.99
col "1PM GB" format 99.99
col "2PM GB" format 99.99
col "3PM GB" format 99.99
col "4PM GB" format 99.99
col "5PM GB" format 99.99
col "6PM GB" format 99.99
col "7PM GB" format 99.99
col "8PM GB" format 99.99
col "9PM GB" format 99.99
col "10PM GB" format 99.99
col "11PM GB" format 99.99

select to_char(first_time,'mm/dd/yy') logdate,count(*),
sum(decode(to_char(first_time,'hh24'),'00',1,0)) "MidN",
sum(decode(to_char(first_time,'hh24'),'01',1,0)) "1AM",
sum(decode(to_char(first_time,'hh24'),'02',1,0)) "2AM",
sum(decode(to_char(first_time,'hh24'),'03',1,0)) "3AM",
sum(decode(to_char(first_time,'hh24'),'04',1,0)) "4AM",
sum(decode(to_char(first_time,'hh24'),'05',1,0)) "5AM",
sum(decode(to_char(first_time,'hh24'),'06',1,0)) "6AM",
sum(decode(to_char(first_time,'hh24'),'07',1,0)) "7AM",
sum(decode(to_char(first_time,'hh24'),'08',1,0)) "8AM",
sum(decode(to_char(first_time,'hh24'),'09',1,0)) "9AM",
sum(decode(to_char(first_time,'hh24'),'10',1,0)) "10AM",
sum(decode(to_char(first_time,'hh24'),'11',1,0)) "11AM",
sum(decode(to_char(first_time,'hh24'),'12',1,0)) "Noon",
sum(decode(to_char(first_time,'hh24'),'13',1,0)) "1PM",
sum(decode(to_char(first_time,'hh24'),'14',1,0)) "2PM",
sum(decode(to_char(first_time,'hh24'),'15',1,0)) "3PM",
sum(decode(to_char(first_time,'hh24'),'16',1,0)) "4PM",
sum(decode(to_char(first_time,'hh24'),'17',1,0)) "5PM",
sum(decode(to_char(first_time,'hh24'),'18',1,0)) "6PM",
sum(decode(to_char(first_time,'hh24'),'19',1,0)) "7PM",
sum(decode(to_char(first_time,'hh24'),'20',1,0)) "8PM",
sum(decode(to_char(first_time,'hh24'),'21',1,0)) "9PM",
sum(decode(to_char(first_time,'hh24'),'22',1,0)) "10PM",
sum(decode(to_char(first_time,'hh24'),'23',1,0)) "11PM"
from v$log_history
group by to_char(first_time,'mm/dd/yy')
order by 1
/            

/* 
"Archive Log Generation Count per Hour"
*/

select to_char(first_time,'mm/dd/yy') logdate,round(sum(blocks*block_size)/1024/1024/1024) Size_GB,count(*),
sum(decode(to_char(first_time,'hh24'),'00',1,0)) "MidN",
sum(decode(to_char(first_time,'hh24'),'01',1,0)) "1AM",
sum(decode(to_char(first_time,'hh24'),'02',1,0)) "2AM",
sum(decode(to_char(first_time,'hh24'),'03',1,0)) "3AM",
sum(decode(to_char(first_time,'hh24'),'04',1,0)) "4AM",
sum(decode(to_char(first_time,'hh24'),'05',1,0)) "5AM",
sum(decode(to_char(first_time,'hh24'),'06',1,0)) "6AM",
sum(decode(to_char(first_time,'hh24'),'07',1,0)) "7AM",
sum(decode(to_char(first_time,'hh24'),'08',1,0)) "8AM",
sum(decode(to_char(first_time,'hh24'),'09',1,0)) "9AM",
sum(decode(to_char(first_time,'hh24'),'10',1,0)) "10AM",
sum(decode(to_char(first_time,'hh24'),'11',1,0)) "11AM",
sum(decode(to_char(first_time,'hh24'),'12',1,0)) "Noon",
sum(decode(to_char(first_time,'hh24'),'13',1,0)) "1PM",
sum(decode(to_char(first_time,'hh24'),'14',1,0)) "2PM",
sum(decode(to_char(first_time,'hh24'),'15',1,0)) "3PM",
sum(decode(to_char(first_time,'hh24'),'16',1,0)) "4PM",
sum(decode(to_char(first_time,'hh24'),'17',1,0)) "5PM",
sum(decode(to_char(first_time,'hh24'),'18',1,0)) "6PM",
sum(decode(to_char(first_time,'hh24'),'19',1,0)) "7PM",
sum(decode(to_char(first_time,'hh24'),'20',1,0)) "8PM",
sum(decode(to_char(first_time,'hh24'),'21',1,0)) "9PM",
sum(decode(to_char(first_time,'hh24'),'22',1,0)) "10PM",
sum(decode(to_char(first_time,'hh24'),'23',1,0)) "11PM"
from v$archived_log
where dest_id=1
group by to_char(first_time,'mm/dd/yy')
order by 1
/
/*
"Archive Generation Size per Hour"
*/
select to_char(first_time,'mm/dd/yy') logdate,round(sum(blocks*block_size)/1024/1024/1024) Size_GB,count(*),
sum(decode(to_char(first_time,'hh24'),'00',(blocks*block_size)/1024/1024/1024,0)) "MidN",
sum(decode(to_char(first_time,'hh24'),'01',(blocks*block_size)/1024/1024/1024,0)) "1AM GB",
sum(decode(to_char(first_time,'hh24'),'02',(blocks*block_size)/1024/1024/1024,0)) "2AM GB",
sum(decode(to_char(first_time,'hh24'),'03',(blocks*block_size)/1024/1024/1024,0)) "3AM GB",
sum(decode(to_char(first_time,'hh24'),'04',(blocks*block_size)/1024/1024/1024,0)) "4AM GB",
sum(decode(to_char(first_time,'hh24'),'05',(blocks*block_size)/1024/1024/1024,0)) "5AM GB",
sum(decode(to_char(first_time,'hh24'),'06',(blocks*block_size)/1024/1024/1024,0)) "6AM GB",
sum(decode(to_char(first_time,'hh24'),'07',(blocks*block_size)/1024/1024/1024,0)) "7AM GB",
sum(decode(to_char(first_time,'hh24'),'08',(blocks*block_size)/1024/1024/1024,0)) "8AM GB",
sum(decode(to_char(first_time,'hh24'),'09',(blocks*block_size)/1024/1024/1024,0)) "9AM GB",
sum(decode(to_char(first_time,'hh24'),'10',(blocks*block_size)/1024/1024/1024,0)) "10AM GB",
sum(decode(to_char(first_time,'hh24'),'11',(blocks*block_size)/1024/1024/1024,0)) "11AM GB",
sum(decode(to_char(first_time,'hh24'),'12',(blocks*block_size)/1024/1024/1024,0)) "Noon",
sum(decode(to_char(first_time,'hh24'),'13',(blocks*block_size)/1024/1024/1024,0)) "1PM GB",
sum(decode(to_char(first_time,'hh24'),'14',(blocks*block_size)/1024/1024/1024,0)) "2PM GB",
sum(decode(to_char(first_time,'hh24'),'15',(blocks*block_size)/1024/1024/1024,0)) "3PM GB",
sum(decode(to_char(first_time,'hh24'),'16',(blocks*block_size)/1024/1024/1024,0)) "4PM GB",
sum(decode(to_char(first_time,'hh24'),'17',(blocks*block_size)/1024/1024/1024,0)) "5PM GB",
sum(decode(to_char(first_time,'hh24'),'18',(blocks*block_size)/1024/1024/1024,0)) "6PM GB",
sum(decode(to_char(first_time,'hh24'),'19',(blocks*block_size)/1024/1024/1024,0)) "7PM GB",
sum(decode(to_char(first_time,'hh24'),'20',(blocks*block_size)/1024/1024/1024,0)) "8PM GB",
sum(decode(to_char(first_time,'hh24'),'21',(blocks*block_size)/1024/1024/1024,0)) "9PM GB",
sum(decode(to_char(first_time,'hh24'),'22',(blocks*block_size)/1024/1024/1024,0)) "10PM GB",
sum(decode(to_char(first_time,'hh24'),'23',(blocks*block_size)/1024/1024/1024,0)) "11PM GB"
from v$archived_log
where dest_id=1
group by to_char(first_time,'mm/dd/yy')
order by 1
/



