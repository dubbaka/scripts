column sid format 9999
column serial# format 999999
column program format a15
column module  format a15
column username format a10
column osuser format a10 
column machine format a15
column terminal format a15
column action   format a20
SELECT 
	sid,
	serial#,
	program,
	module,
        username,
        osuser,
        machine,
        terminal,
        action    
FROM   v$session 
WHERE  paddr=(SELECT addr 
              FROM v$process 
              WHERE spid=&OSPID)
/

