/* pf_bigtsobj.sql
	find the biggest objects in a specified tablespace
*/

accept trgtts char default NONE prompt 'What is the tablespace <NONE> : '

col owner format a10
col segment_name format a30
col sizemb format 99,999.90 head SizeMB

select * from (
   select owner, segment_name, segment_type, (bytes)/(1024*1024) sizemb, extents
   from   dba_segments
   where (tablespace_name = upper('&trgtts') and upper('&trgtts') != 'NONE') 
   order  by 4 desc)
where rownum < 21
/
