-- @wf_stats.sql


prompt Display Workflow related statistics

set echo on feed on lines 300 pages 2000

spool MonthlyRpt_WorkflowStats

select wi.item_type "ItemType", wit.persistence_type "Persistence", decode (wi.end_date, NULL, 'OPEN', 'CLOSED') "Status", count(1) "Count"
from   apps.wf_items wi, apps.wf_item_types wit
where  wit.name = wi.item_type
group by item_type, wit.persistence_type, WIT.PERSISTENCE_DAYS, decode (wi.end_date, NULL, 'OPEN', 'CLOSED');

select item_type "ItemType", count(1) "Count"
from   apps.wf_item_attribute_values
group  by item_type;

select item_type "ItemType", activity_status "Activity", count(1) "Count"
from   apps.wf_item_activity_statuses
group  by item_type,activity_status;

Select to_char(begin_date,'DD-MON-YYYY'),count(1) from applsys.WF_NOTIFICATIONS where status = 'OPEN' and mail_status = 'MAIL' group by to_char(begin_date,'DD-MON-YYYY');

select to_char(begin_date,'DD-MON-YYYY'),count(1),message_type from applsys.WF_NOTIFICATIONS where status = 'OPEN' and mail_status = 'MAIL' group by to_char(begin_date,'DD-MON-YYYY'),message_type;

spool off
