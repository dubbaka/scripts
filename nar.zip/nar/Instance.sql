col INSTANCE_NAME for a13
col HOST_NAME for a15
col VERSION for a10
col StartupTime for a18
col STATUS for a10
col PARALLEL for a8
col THREAD# for 9999999
col ARCHIVER for a9
col LOG_SWITCH_WAIT for a15
col SHUTDOWN_PENDING for a20
col ACTIVE_STATE for a15

Prompt " Instance Information"

select INSTANCE_NUMBER, INSTANCE_NAME, HOST_NAME, VERSION, to_char(STARTUP_TIME,'DDMonYYYY hh24:mi:ss') StartupTime
, STATUS, PARALLEL, THREAD#, ARCHIVER, LOG_SWITCH_WAIT, LOGINS, SHUTDOWN_PENDING, DATABASE_STATUS, INSTANCE_ROLE
, ACTIVE_STATE
from   gv$instance;

Prompt " Load Information"
select a.inst_id,b.instance_name, a.status,count(*) from gv$session a, gv$instance b
where a.inst_id=b.inst_id
group by a.inst_id,b.instance_name, a.status
order by 3,1;