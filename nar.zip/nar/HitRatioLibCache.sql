-- @HitRatioLibCache.sql

select sum(pins-reloads)/sum(pins)*100 "Library Cache Hit Ratio"
from   v$librarycache;
prompt No improvement possible if above "Library Cache Hit Ratio" is over 99.9+%



select sum(pins) "Executions", sum(reloads) "Misses", sum(reloads)/sum(pins)*100 "Reload Ratio%"
from   v$librarycache;
prompt Sahred Pool size needs to be increased if "Reload Ratio%" is > 1%
