-- @TbsFreespace.sql


clear computes breaks columns

col  fname  format         a50 justify c heading 'FileName'
col totsiz  format 999,999,990 justify c heading 'Total|(KB)' 
col avasiz  format 999,999,990 justify c heading 'Available|(KB)' 
col pctusd  format         990 justify c heading 'Pct|Used' 

comp sum of totsiz avasiz on report
break on report 

set verify off
accept Tablespace default ALL prompt 'What is the Tablespace Name: '

select dbf.file_name  fname, dbf.bytes/1024  totsiz, nvl(sum(free.bytes)/1024,0)  avasiz, 
      (1-nvl(sum(free.bytes),0)/dbf.bytes)*100  pctusd 
from  dba_data_files  dbf, dba_free_space  free 
where (dbf.tablespace_name like upper('%&Tablespace%') or '&Tablespace' = 'ALL')
and   dbf.tablespace_name = free.tablespace_name(+) 
and   dbf.file_id         = free.file_id(+)
group by dbf.tablespace_name, dbf.file_name, dbf.bytes;
