clear columns breaks compute

set verify off lines 800
set pages 200

col inst_id for 9999 head "Inst|Id"
col SID for 99999
col "SERIAL#" for 999999
col process head "OSpid|APnode" for a10
col SPID head "OSpid|DBnode" for a10
col username for a8 head "Schema"
col osuser for a15
col machine for a12 trunc
col module for a25 trunc
col sql_hash_value head "SQL_HASH" for 9999999999
col program for a25 trunc
col logontime for a15
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11

select s.inst_id, s.sid, s.serial#, s.process, p.spid, s.username, s.osuser, replace(s.machine,'ASIAPAC\',null) machine, s.module
      , to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime
      , floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
      , s.status, s.sql_hash_value
	  --, s.sql_id
	  , s.action
      , s.program, s.type, p.pid,p.PGA_USED_MEM, p.PGA_ALLOC_MEM, p.PGA_FREEABLE_MEM, p.PGA_MAX_MEM
from    gv$session s, gv$process p
where s.inst_id = p.inst_id
and  p.addr = s.paddr
and s.type<>'BACKGROUND'
and upper(MODULE) like '%TOAD%'
order by s.osuser
/
