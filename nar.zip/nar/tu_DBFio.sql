rem @DatafilesDisksIO.sql

      set pagesize 100
      set space 1  
     
      clear breaks
      clear computes
      clear columns

      column pbr       format 9999999999 heading 'Physical|Blk Read'  
      column pbw       format 9999999999 heading 'Physical|Blks Wrtn'  
      column pw        format 9999999999 heading 'Physical|Writes'  
      column pyr       format 9999999999 heading 'Physical|Reads'  
      column readtim   format 9999999999 heading 'Read|Time'  
      column name      format a40        heading 'DataFile Name'  
      column writetim  format 9999999999 heading 'Write|Time'  
 
      ttitle 'I/O per DISK FILE-phyrds to phyblkrd s/b 1 to many when' skip -
      left 'activity' skip

      ttitle center 'Tablespace Report' skip 2  
 
      compute sum of f.phyblkrd, f.phyblkwrt, f.phyrds, f.phywrts on report

      select   substr(fs.name,1,40) name,
               f.phyrds,
               f.phyblkrd pbr,
               f.phywrts pw,
               f.phyblkwrt pbw,
               f.avgiotim
      from   v$filestat f, v$datafile fs
      where  f.file#  =  fs.file#
      order  by fs.name

spool ..\lst\DatafilesDisksIO&pDatabaseServer..log
/
spool off
