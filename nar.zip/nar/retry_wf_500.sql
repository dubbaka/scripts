DECLARE
	cursor a is
	select c.notification_id
	     from apps.oe_order_headers_all a , 
		 	  apps.oe_order_lines_all b ,
			  applsys.wf_notifications c,
			  apps.FND_LOOKUP_VALUES          FLV,
			   APPS.OE_TRANSACTION_TYPES_ALL   OTTA
         where a.header_id = b.header_id 
	     and b.line_id = substr(c.subject, instr(c.subject,'OEOL/')+5,6) 
	     and c.status = 'OPEN' 
         AND c.ORIGINAL_RECIPIENT = 'SYSADMIN' 
         AND c.subject like '%OEOL/%recompilation%'
         AND c.MESSAGE_TYPE = 'WFERROR' 
		 AND A.flow_status_code    !=  'ENTERED'
      	 AND     FLV.lookup_type          = 'SHIPMENT_PRIORITY'
      	 AND     FLV.lookup_code          = A.shipment_priority_code
      	 AND     FLV.language             = 'US'
      	 AND     NVL(FLV.end_date_active,sysdate) >= sysdate
      	 AND     FLV.attribute1           = 'N'
      	 AND     OTTA.transaction_type_id = A.order_type_id
      	 AND     OTTA.attribute7          = 'N'  
	 AND    ROWNUM <501;

begin

fnd_global.apps_initialize(0,20420,1);


for i in a
loop

wf_notification.respond(i.notification_id, 'Closing from API', 'SYSADMIN');

end loop;

end;

