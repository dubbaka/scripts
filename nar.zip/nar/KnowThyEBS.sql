-- @knowthyebs.sql


select count(1) "ActiveEBSUsers" from applsys.fnd_user where END_DATE is null or END_DATE > sysdate;
select count(1) "ActiveResponsibilities" from apps.fnd_responsibility_vl where END_DATE is null or END_DATE > sysdate;
select count(1) "Menus" from applsys.fnd_menus_tl;
@FndNodes.sql
@fndlang.sql -- Installed languages
@FNDCustomPgms.sql -- It is assumed that custom pgms and forms start with XX
@fndprofiles.sql
@FndRunAwayForms.sql
@cmConcReq.sql -- 1) summarise last 30Days Concurrent Job activity and 2) hourly runs for last 24Hrs 
@cmConcSummary.sql
