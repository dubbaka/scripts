-- name       : dict_cache.sql
-- date       : 14-Nov-2001
-- Author     : Pentest Limited
-- Description: Show the dictionary cache hit ratio
-- limitation : needs access to v$rowcache
--
-- useage     : SQL> @dict_cache

set pages 50
set feed off
set verify off
set linesize 200

col gets head "Gets" for 999,999,999
col misses head "Misses" for 999,999,999
col hit_ratio head "HitRatio" for 99.99

spool dict_cache.lis

select 	sum(gets) gets,
       	sum(getmisses) misses,
       	round(((1-(sum(getmisses)/sum(gets)))*100),4) hit_ratio
from 	v$rowcache;

spool off

set pages 24
set feed on
set verify on
set lines 80
