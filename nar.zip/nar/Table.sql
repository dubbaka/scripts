rem #############################################################################
rem File 	: @Table.sql
rem Author	: Ravi Chandra
rem Run As	: SYSTEM (SELECT ANY TABLE)
rem Use		: List Table and current Size information
rem Output	: 
rem ##############################################################################

clear columns breaks computes

set wrap on veri off lines 1000 trim on

col owner for a10
col table_name for a30
col tablespace_name for a10 head 'Tablespace'
col segment_name for a30
col "InitXtntK" for 9,999,999
col "NextXtntK" for 9,999,999
col next_extent heading "Next|Extent"
col PCT_FREE head "Pct|Free" for 9999
col PCT_USED head "Pct|Used" for 9999
col pct_increase heading "Pct|Incr" for 9999
col "SizeMB" for 999,999
col num_rows for 9,999,999,999
col EMPTY_BLOCKS for 999,999 head 'Empty|Blocks'
col AVG_SPACE for 999,999
col CHAIN_CNT for 99,999 head 'Chain|Count'
col AVG_ROW_LEN for 99,999 head 'AvgRow|Length'
col "LastAnalyzed" for a15
col BUFFER_POOL for a8 head 'Buffer|Pool'
col ROW_MOVEMENT for a12
col MONITORING for a10
col COMPRESSION for a11
col FREELISTS head "Free|Lists" for 99999
col FREELIST_GROUPS head "FreeList|Groups" 
col NUM_FREELIST_BLOCKS head "FreeList|Blocks"
col AVG_SPACE_FREELIST_BLOCKS head "AvgSpace|FreeList|Blocks"
col ROW_MOVEMENT head "Row|Movement" for a9
col LOGGING for a7
col PARTITIONED for a11
col DEPENDENCIES for a12
col MIN_EXTENTS head "Min|Xtnts" for 99999
col "Degree" for a6
col CACHE for a5
col BACKED_UP head "Backed|Up" for a6
col CLUSTER_OWNER head "Cluster|Owner" for a10
col TEMPORARY for a9
col GLOBAL_STATS head "Global|Stats" for a6
col USER_STATS head "User|Stats" for a5
col "Instances" for a9

accept TblName char prompt 'Table: '

select owner, table_name, tablespace_name, num_rows, to_char(LAST_ANALYZED,'dd-Mon-yy hh24:mi') "LastAnalyzed", PCT_FREE, PCT_USED, PCT_INCREASE
     , INITIAL_EXTENT/1024 "InitXtntK", NEXT_EXTENT/1024 "NextXtntK", BLOCKS, EMPTY_BLOCKS, CHAIN_CNT, AVG_ROW_LEN, AVG_SPACE, FREELISTS, FREELIST_GROUPS
     , NUM_FREELIST_BLOCKS, AVG_SPACE_FREELIST_BLOCKS, MONITORING, BUFFER_POOL, ROW_MOVEMENT, COMPRESSION, LOGGING, trim(DEGREE) "Degree"
     , CACHE, trim(INSTANCES) "Instances", PARTITIONED, DEPENDENCIES, MIN_EXTENTS, MAX_EXTENTS, BACKED_UP, TEMPORARY, GLOBAL_STATS, USER_STATS
     , IOT_TYPE, IOT_NAME, CLUSTER_OWNER, CLUSTER_NAME, INI_TRANS, MAX_TRANS
from   dba_tables
where  table_name = upper('&TblName');

prompt 
accept junk1 char prompt "Press enter for Table Size calcs.........."
select owner, segment_name, extents, max_extents, (bytes/1024) "SizeKB", bytes/(1024*1024) "SizeMB", 
       initial_extent, next_extent, blocks, pct_increase
from   dba_segments
where  segment_type = 'TABLE'
and    segment_name = upper('&TblName');
