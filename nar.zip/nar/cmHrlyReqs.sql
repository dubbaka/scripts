/* @cmHrlyReqs.sql
        find the number of requests that ran every hour
*/

prompt Display Hourly COncurrent Pgms Requests started (may not have completed)

clear breaks computes col

col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'ddMonYY') "datenow" from dual;


col MidN format 99999
col 1AM format 99999
col 2AM format 99999
col 3AM format 99999
col 4AM format 99999
col 5AM format 99999
col 6AM format 99999
col 7AM format 99999
col 8AM format 99999
col 9AM format 99999
col 10AM format 99999
col 11AM format 99999
col Noon format 99999
col 1PM format 99999
col 2PM format 99999
col 3PM format 99999
col 4PM format 99999
col 5PM format 99999
col 6PM format 99999
col 7PM format 99999
col 8PM format 99999
col 9PM format 99999
col 10PM format 99999
col 11PM format 99999
spool spool\ConcReqHrly_&_MyDateNow._&_MyDB1.
select to_char(fcr.actual_start_date,'ddMonyy') Reqdate,
sum(decode(to_char(fcr.actual_start_date,'hh24'),'00',1,0)) "MidN",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'01',1,0)) "1AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'02',1,0)) "2AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'03',1,0)) "3AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'04',1,0)) "4AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'05',1,0)) "5AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'06',1,0)) "6AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'07',1,0)) "7AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'08',1,0)) "8AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'09',1,0)) "9AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'10',1,0)) "10AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'11',1,0)) "11AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'12',1,0)) "Noon",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'13',1,0)) "1PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'14',1,0)) "2PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'15',1,0)) "3PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'16',1,0)) "4PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'17',1,0)) "5PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'18',1,0)) "6PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'19',1,0)) "7PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'20',1,0)) "8PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'21',1,0)) "9PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'22',1,0)) "10PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'23',1,0)) "11PM"
from   APPLSYS.fnd_Concurrent_requests fcr
where  fcr.actual_start_date is not null
group by to_char(fcr.actual_start_date,'ddMonyy')
order by 1;
spool off
