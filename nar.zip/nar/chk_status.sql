spool chk_status
ttitle 'DATA DICTIONARY CACHE RATIO REPORT' skip

      column "Data Dict. Gets"   format 999,999,999  
      column "Data Dict. cache misses" format 999,999,999  
      column dictcache format 999.99 heading 'Dictionary Cache Ratio %'  
 
      select   sum(gets) "Data Dict. Gets",  
               sum(getmisses) "Data Dict. cache misses",  
               sum(getmisses) / (sum(gets)+0.00000000001) * 100 dictcache  
      from     v$rowcache;


      ttitle 'COMPUTE SUM OF VALUE kbval ON REPORT' skip

      column name     format a20 heading "SGA Segment"
      column value    format 99,999,990  heading "Size|(Bytes)"
      column kbval    format 99,990.9 heading "Size|(Kb)"
      break on report
      select  name,
              value,
              round(value/1024,1) kbval
      from    v$sga;


          col f1 format a55 heading 'Redo Log File Name'
          col f2 format 9999 heading 'Group'
          col f3 format a10 heading 'Status'

          ttitle  'Redo Log File Names Report' skip
          break on f2 skip

          select  GROUP# f2,
                  STATUS f3,
                  MEMBER f1
          from    v$logfile
          order by GROUP#,MEMBER;


      ttitle 'REDO CONTENTION REPORT' skip
      column value format 999,999,999  
      select substr(name,1,30) Name,  
             value  
      from   v$sysstat 
      where  name = 'redo log space requests';


      ttitle 'GET WAIT RATIO ROLLBACK REPORT'
      column "Ratio" format 999.99999999 
      column name format A15
      column "PERCENT" 
      select  name, 
              waits, 
              gets, 
              100-(waits/gets) "Ratio",
              (waits/gets)*100 "PERCENT"
      from    v$rollstat a, v$rollname b  
      where   a.usn = b.usn;  


      ttitle 'ROLLBACK GENERAL INFORMATION' skip 
      select   rssize,
               optsize,
               hwmsize,
               shrinks,
               wraps,  
               extends,
               aveactive  
      from   v$rollstat  
      order  by rownum;


      ttitle 'Sorts Disk/Memory' skip
 
      select  substr(name,1,30) "Statistic Name",
               value
      from    v$sysstat
      where   name in ('sorts (memory)','sorts (disk)');




      ttitle 'High water marks report' skip
      col event format a37 heading 'Event'  
      col total_waits format 99999999 heading 'Total|Waits'  
      col time_waited format 9999999999 heading 'Time Wait|In Hndrds'  
      col total_timeouts format 999999 heading 'Timeout'  
      col average_wait heading 'Average|Time' format 999999.999  
 
      select *  
      from   v$system_event;


      column pct heading "Hit Ratio (%)" format 999.9

      ttitle  'Buffer Cache Checks - Goal, above 95%' skip

      select  ((1- (sum(decode(a.name,'physical reads',value,0)))/
               (sum(decode(a.name,'db block gets',value,0)) +
                sum(decode(a.name,'consistent gets',value,0)))) * 100) "PERCENT"
      from    v$sysstat a;



      column sum_pins format 999,999,999  
      column sum_reloads format 999,999,999  
      column hit_ratio format 999.99999
      ttitle 'PINS and Library Cache' skip
       
      select 'PINS - # of times an item in the library cache was executed - '||
              sum(pins) sum_pins, 
              'RELOADS - # of library cache misses on execution steps - '||
              sum(reloads) sum_reloads,  
              'Pin hit ratio should be close to 1.0  - '||
              ROUND((sum(reloads)/sum(pins)),6) hit_ratio
      from   v$librarycache;  


      ttitle 'FREE MEMORY IN SHARED POOL REPORT' skip
      select name, 
              (bytes/1024/1024) "Free Memory in MB" 
      from   v$sgastat
      where  name = 'free memory';




      column name format A25
      ttitle 'OBJECTS IN CACHE REPORT' skip
      select name,
             sharable_mem
      from   v$db_object_cache 
      where sharable_mem > 10000
      and type in ('PACKAGE','PACKAGE BODY','FUNCTION','PROCEDURE');



      ttitle 'RELOADS-library cache misses' skip

      column libcache format 99.99 heading 'Library Cache Miss Ratio (%)'

      select  sum(pins) "Executions",
              sum(reloads) "Reloads While Executing",
              sum(reloads)/sum(pins) *100 libcache
      from    v$librarycache;


      column name heading "Latch Type" format a25
      column pct_miss heading "Misses/Gets (%)" format 999.99999
      column pct_immed heading "Immediate Misses/Gets (%)" format 999.99999

      ttitle  'Latch Contention Analysis Report' skip

      select  n.name,
               misses*100/(gets+1) pct_miss,
               immediate_misses*100/(immediate_gets+1) pct_immed
      from    v$latchname n,v$latch l
      where   n.latch# = l.latch#
      and     n.name in('%cache bugffer%','%protect%');


      ttitle 'Buffer Contention Specific - PARAMETERS PRINTED IF > 0' skip - 


      select  class,count
      from    v$waitstat
      where   class in ('data blocks','segment header',
                        'undo header','undo block');



      ttitle 'Packages in dba_object_size NOT owned by SYS or SYSTEM' skip
 
      column total_bytes format 9999999 heading 'Total|Bytes'
      column "OBJECT" format A25
      column type format A15

      select    owner || '.' || name OBJECT,
                 type, 
                 to_char(sharable_mem/1024,'9,999.9') "SPACE(K)",
                 loads, 
                 executions execs,
                 kept
      from      v$db_object_cache
      where     type in ('FUNCTION','PACKAGE','PACKAGE BODY','PROCEDURE')
      and       owner not in ('SYS','SYSTEM')
      and       kept = 'NO'
      and       sharable_mem > 100000
      order by owner, name;


spool off
