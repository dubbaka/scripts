declare
cursor prog_cur IS
SELECT  'Program User Name: '||   FCPT.USER_CONCURRENT_PROGRAM_NAME  prog_name
,       'Description:       '||   FCPT.DESCRIPTION                   description
,       'Executable Name:   '||   EXE.EXECUTABLE_NAME                exe_name
,       'Executable File:   '||   EXE.EXECUTION_FILE_NAME            exe_file_name
,       'Execution Type:    '||   decode(EXE.EXECUTION_METHOD_CODE, 'B', 'Request Set Stage Function',
 'Q', 'SQL*Plus', 'H', 'Host',
 'L', 'SQL*Loader', 'A', 'Spawned', 'I', 'PL/SQL Stored Procedure', 'P', 'Oracle Reports', 'S', 
'Immediate',EXE.EXECUTION_METHOD_CODE)  exe_method
,       'Style Req ?:       '||   FND.REQUIRED_STYLE     style_r
,       'Style Type:        '||   FND.OUTPUT_PRINT_STYLE style_p
,       'Printer Name:      '||   FND.PRINTER_NAME       printer_name
,       'Min WIDTH:         '||   FND.MINIMUM_WIDTH      min_w
,       'Max WIDTH:         '||   FND.MAXIMUM_WIDTH      max_w
,       'Min LENGHT:        '||   FND.MINIMUM_LENGTH     min_l
,       'Max LENGHT:        '||   FND.MAXIMUM_LENGTH     max_l ,fnd.concurrent_program_id
FROM  APPLSYS.FND_EXECUTABLES EXE, APPLSYS.FND_CONCURRENT_PROGRAMS FND
,     APPLSYS.FND_CONCURRENT_PROGRAMS_TL FCPT WHERE 
FCPT.USER_CONCURRENT_PROGRAM_NAME LIKE '&name'
AND   FND.CONCURRENT_PROGRAM_ID= FCPT.CONCURRENT_PROGRAM_ID
AND   FND.APPLICATION_ID = FCPT.APPLICATION_ID
AND   EXE.EXECUTABLE_ID= FND.EXECUTABLE_ID ORDER BY 1
;
