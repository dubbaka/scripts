For Generating the Explain plan:
=======================
SQL> explain plan set statement_id='xxx' for <SQL Satement>;   
Here the statement_id is unique. need to give different valus for each Query.


For Explain plan Output:
==================
SQL> SELECT lpad(' ',level-1)||operation||' '||options||' '||
       object_name "Plan"
  FROM plan_table
CONNECT BY prior id = parent_id
       AND prior statement_id = statement_id
 START WITH id = 0 AND statement_id = 'xxx'
 ORDER BY id;

