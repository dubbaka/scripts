REM NAME:   @indexfrag.sql
REM USAGE: tfsifrag schema_name.index_name
REM ------------------------------------------------------------------------ 
REM REQUIREMENTS: 
REM    SELECT on INDEX_STATS 
REM ------------------------------------------------------------------------ 
REM PURPOSE: 
REM    Reports index fragmentation statistics. To be used for calling from shell scripts
REM ------------------------------------------------------------------------ 
REM EXAMPLE: 
REM                     Index Fragmentation Statistic 
REM                 
REM    index name        INV.inv.MTL_RESERVATIONS_N2
REM    leaf rows deleted       20,974
REM    leaf rows in use        11,434
REM    index badness            0.647
REM  
REM ------------------------------------------------------------------------ 
REM Main text of script follows:

set verify off  lines 200 time on timing on

clear columns computes breaks

col name        head 'IndexName'
col lf_rows     head 'TotalLeafRows' for 999,999,990
col del_lf_rows head 'LeafRowsDeleted' for 999,999,990
col lf_blk_rows head 'LeafRowsInUse' for 999,999,990
col ibadness    head 'IndexBadness' for 999,990.999
col owner for a12
col SEGMENT_NAME for a30
col SEGMENT_TYPE for a15
col INDEX_TYPE for a15


undef tgtOwner
undef tgtIndexName

accept tgtOwner char prompt 'Index Owner: '
accept tgtIndexName char prompt 'Index Name : '

Prompt Before stats
select owner, segment_type, segment_name, (bytes/1024) "SizeKB", bytes/(1024*1024) "SizeMB", extents, max_extents, initial_extent, next_extent, blocks, pct_increase
from   dba_segments
where  segment_type = 'INDEX'
and    segment_name = upper('&tgtIndexName');

select OWNER, INDEX_NAME, NUM_ROWS, LAST_ANALYZED, INDEX_TYPE, TABLE_NAME, BLEVEL, LEAF_BLOCKS, STATUS, PCT_DIRECT_ACCESS
from   dba_indexes
where  index_name = upper('&tgtIndexName')
order  by 1,2;

prompt validate index &tgtOwner..&tgtIndexName
validate index &tgtOwner..&tgtIndexName;

select  name, lf_rows, del_lf_rows, (lf_rows-del_lf_rows) lf_blk_rows, del_lf_rows/(lf_rows+0.00001) ibadness
from    index_stats;

--prompt Hit CTRL-C to cancel the process now     or    Run the following command in a seperate window now and
prompt alter index &tgtOwner..&tgtIndexName rebuild parallel 6
accept tgtEnter char prompt 'Hit enter to continue ........'
alter index &tgtOwner..&tgtIndexName rebuild parallel 6;

Prompt After stats
select owner, segment_type, segment_name, (bytes/1024) "SizeKB", bytes/(1024*1024) "SizeMB", extents, max_extents, initial_extent, next_extent, blocks, pct_increase
from   dba_segments
where  segment_type = 'INDEX'
and    segment_name = upper('&tgtIndexName');

select OWNER, INDEX_NAME, NUM_ROWS, LAST_ANALYZED, INDEX_TYPE, TABLE_NAME, BLEVEL, LEAF_BLOCKS, STATUS, PCT_DIRECT_ACCESS
from   dba_indexes
where  index_name = upper('&tgtIndexName')
order  by 1,2;

select  name, lf_rows, del_lf_rows, (lf_rows-del_lf_rows) lf_blk_rows, del_lf_rows/(lf_rows+0.00001) ibadness
from    index_stats;
