/* osproc.sql 
    find the Oracle session info for a given OS process id
*/
col machine format a15 trunc
col program format a25 trunc
col LastCallET format a11
col status format a1 trunc
col module format a12 trunc
set verify off
accept trgtproc char default 0 prompt 'What is the OS process id : '
select s.sid,s.status,
   floor(last_call_et/3600)||':'||
   floor(mod(last_call_et,3600)/60)||':'||
   mod(mod(last_call_et,3600),60) "LastCallET",
s.machine,s.module,s.process,s.sql_hash_value
from v$session s, v$process p
where s.paddr = p.addr
and p.spid = '&trgtproc';

