-- @TopSidsByIO.sql

clear columns breaks computes

col username for a18
col sid for 99999
col physical_reads for 9,999,999,999
col consistent_gets for 999,999,999,999
col "Reads" for 99,999,999,999
col block_gets for 999,999,999
col block_changes for 999,999,999,999
col consistent_changes for 999,999,999,999
col SQL_HASH_VALUE head "SQL_HASH"
col SCHEMANAME for a18 head "Schema"
col OSUSER for a15
col logontime for a15
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11
col "IoPct" for 999.99
col MACHINE for a20 trunc
col MODULE for a40

set lines 1000

accept trgtRows number default 20 prompt 'Rows to display <20> : '
accept trgtINST number default 0 prompt 'Instance ID : '
accept trgtStatus char default ACTIVE prompt 'Status [ACTIVE | INACTIVE | ALL] <ACTIVE> : '
accept trgtType char default USER prompt 'Process TYpe [BACKGROUND | USER | ALL] <USER> : '

select * from (
SELECT a.INST_ID, a.sid, a.serial#, a.SQL_HASH_VALUE, a.MODULE, a.type, b.physical_reads+b.consistent_gets "Reads", b.block_gets
     , floor(a.last_call_et/3600)||':'||floor(mod(a.last_call_et,3600)/60)||':'||mod(mod(a.last_call_et,3600),60) "LastCallET"
     , to_char(a.logon_time,'Mon/dd hh24:mi:ss') logontime, b.physical_reads, b.consistent_gets
     , a.username, a.STATUS
     , b.block_changes, b.consistent_changes
     , a.ACTION, a.OSUSER, a.MACHINE, a.SERVER, a.SCHEMANAME, a.LOCKWAIT, a.CLIENT_IDENTIFIER, a.CLIENT_INFO
FROM   gv$session a, gv$sess_io b
where (a.INST_ID = &trgtINST or &trgtINST = 0)
and    a.sid = b.sid
and    a.module is not null
and    a.SQL_HASH_VALUE != 0
AND    NVL(a.username,'XX') NOT IN ('SYS', 'SYSTEM', 'XX')
and   (a.status = upper('&trgtStatus') or '&trgtStatus' = 'ALL')
and   (a.type   = upper('&trgtType')   or '&trgtType'   = 'ALL')
ORDER  BY b.physical_reads DESC
)
where rownum <= &trgtRows;


accept junk1 char prompt "Press enter for SID IO percentage details ....."

select * from (
select sid, username, type, round(100 * total_user_io/total_io,2) "IoPct"
from   (select b.sid sid, nvl(b.username,p.username) username, b.type, sum(value) total_user_io
        from   gv$statname c, gv$sesstat a, gv$session b, gv$process p
	where (b.INST_ID = &trgtINST or &trgtINST = 0)
        and    a.statistic# = c.statistic#
        and    p.addr(+)    = b.paddr
        and    b.sid        = a.sid
        and   (b.status     = upper('&trgtStatus') or '&trgtStatus' = 'ALL')
        and   (b.type       = upper('&trgtType')   or '&trgtType'   = 'ALL')
        and    c.name in ('physical reads', 'physical writes', 'physical writes direct', 'physical reads direct'
                         , 'physical writes direct (lob)', 'physical reads direct (lob)')
        group by b.sid, nvl(b.username,p.username), b.type),
       (select sum(value) total_io
        from   gv$statname c, gv$sesstat a, gv$session b
	where (b.INST_ID = &trgtINST or &trgtINST = 0)
        and    a.statistic# = c.statistic#
        and    b.sid        = a.sid
        and   (b.status     = upper('&trgtStatus') or '&trgtStatus' = 'ALL')
        and   (b.type       = upper('&trgtType')   or '&trgtType'   = 'ALL')
        and    c.name in ('physical reads','physical writes','physical writes direct','physical reads direct','physical writes direct (lob)','physical reads direct (lob)'))
order by 4 desc)
where rownum <= &trgtRows;
