set lines 300
col event format a40
select dl.inst_id, s.sid,s.SERIAL#, p.spid, obj.name,sw.event, sw.seconds_in_wait sec,'Blocker'
from gv$ges_enqueue dl, gv$process p, gv$session s, gv$session_wait sw,gv$locked_object lo,sys.obj$ obj
where blocker = 1
and (dl.inst_id = p.inst_id and dl.pid = p.spid)
and (p.inst_id = s.inst_id and p.addr = s.paddr)
and (s.inst_id = sw.inst_id and s.sid = sw.sid)
and (lo.inst_id = sw.inst_id and lo.session_id = sw.sid)
and (obj.obj#(+) = lo.OBJECT_ID)
UNION ALL
select dl.inst_id, s.sid,s.SERIAL#,p.spid,obj.NAME, sw.event, sw.seconds_in_wait sec,'Blocked'
from gv$ges_enqueue dl, gv$process p, gv$session s, gv$session_wait sw, sys.obj$ obj
where blocked = 1
and (dl.inst_id = p.inst_id and dl.pid = p.spid)
and (p.inst_id = s.inst_id and p.addr = s.paddr)
and (s.inst_id = sw.inst_id and s.sid = sw.sid)
and (obj.obj#(+) = s.ROW_WAIT_OBJ#)
and s.status='ACTIVE'
/
