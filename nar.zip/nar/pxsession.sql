select p.qcsid,p.sid,s.sql_hash_value
 from v$px_session p, v$session s
where p.sid = s.sid
/

