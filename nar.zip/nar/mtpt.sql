col file_name format a55
accept trgtmp char default u00 prompt 'What is the mount point : '
select t.tablespace_name,f.file_name
from dba_tablespaces t, dba_data_files f
where f.tablespace_name = t.tablespace_name
and f.file_name like '/&trgtmp/%'
order by 1,2
/

