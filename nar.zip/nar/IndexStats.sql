REM NAME:   indexstats.sql
REM USAGE:  tfsistat schema_name.index_name
REM ------------------------------------------------------------------------ 
REM REQUIREMENTS: 
REM    SELECT on INDEX_STATS 
REM ------------------------------------------------------------------------ 
REM PURPOSE: 
REM    Report index statistics. 
REM ------------------------------------------------------------------------ 
REM EXAMPLE: 
REM                                Index Statistics  
REM 
REM    S_EMP_USERID_UK  
REM    ----------------------------------------------------------  
REM    height                          1 
REM    blocks                          5 
REM    del_lf_rows                     0  
REM    del_lf_rows_len                 0 
REM    distinct_keys                  25 
REM    most_repeated_key               1  
REM    btree_space                 1,876 
REM    used_space                    447  
REM    pct_used                       24 
REM    rows_per_key                    1 
REM    blks_gets_per_access            2  
REM    lf_rows                        25            br_rows               0  
REM    lf_blks                         1            br_blks               0 
REM    lf_rows_len                   447            br_rows_len           0  
REM    lf_blk_len                  1,876            br_blk_len            0   
REM  
REM ------------------------------------------------------------------------ 
REM Main text of script follows: 

set verify off lines 100
clear computes breaks columns
  
col name
col headsep      
col height       
col blocks       
col lf_rows      
col lf_blks
col lf_rows_len  
col lf_blk_len   
col br_rows      
col br_blks      
col br_rows_len  
col br_blk_len   
col del_lf_rows  
col del_lf_rows_len
col distinct_keys
col most_repeated_key
col btree_space  
col used_space
col pct_used     
col rows_per_key 
col blks_gets_per_access

prompt validating index &&IndexName
validate index &&IndexName;
 
select 
  name, 
  '----------------------------------------------------------'    headsep, 
  'height               '||to_char(height,     '999,999,990')     height, 
  'blocks               '||to_char(blocks,     '999,999,990')     blocks, 
  'del_lf_rows          '||to_char(del_lf_rows,'999,999,990')     del_lf_rows, 
  'del_lf_rows_len      '||to_char(del_lf_rows_len,'999,999,990') del_lf_rows_len, 
  'distinct_keys        '||to_char(distinct_keys,'999,999,990')   distinct_keys, 
  'most_repeated_key    '||to_char(most_repeated_key,'999,999,990') most_repeated_key, 
  'btree_space          '||to_char(btree_space,'999,999,990')       btree_space, 
  'used_space           '||to_char(used_space,'999,999,990')        used_space, 
  'pct_used                     '||to_char(pct_used,'990')          pct_used, 
  'rows_per_key         '||to_char(rows_per_key,'999,999,990')      rows_per_key, 
  'blks_gets_per_access '||to_char(blks_gets_per_access,'999,999,990') blks_gets_per_access, 
  'lf_rows      '||to_char(lf_rows,    '999,999,990')||'        '||+ 
  'br_rows      '||to_char(br_rows,    '999,999,990')                  br_rows, 
  'lf_blks      '||to_char(lf_blks,    '999,999,990')||'        '||+ 
  'br_blks      '||to_char(br_blks,    '999,999,990')                  br_blks, 
  'lf_rows_len  '||to_char(lf_rows_len,'999,999,990')||'        '||+ 
  'br_rows_len  '||to_char(br_rows_len,'999,999,990')                  br_rows_len, 
  'lf_blk_len   '||to_char(lf_blk_len, '999,999,990')||'        '||+ 
  'br_blk_len   '||to_char(br_blk_len, '999,999,990')                br_blk_len 
from 
  index_stats 
/ 

undef name 

clear computes breaks columns
