/* mtptdf.sql
     see the top 10 io datafiles associated with a mount point */
col fsmtpt format a5 head MtPt
col fname format a35 head FileName 
set verify off
accept mtpt char default 'p010' prompt 'What is the mount point <p010> : '
select * from (
select substr(f.name,8,(instr(f.name,'/',9,1) -8))                    as fsmtpt,
       substr(f.name,(instr(f.name,'/',-1,1)+1)) || ' (' || f.file# || ')' fname,
       s.phyrds, s.phywrts,s.lstiotim,s.avgiotim
  from v$datafile f, v$filestat s
 where substr(f.name,8,(instr(f.name,'/',9,1) -8)) = '&mtpt'
   and f.file# = s.file#
order by 3 desc)
where rownum < 11;


