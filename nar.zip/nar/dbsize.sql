break on report on fsmtpt skip 1
compute sum of mtptgb on report
compute sum of nbrfiles on report
compute sum of mtptgb on fsmtpt
col fsmtpt format a30 
col mtptgb format 99999.90
col dftype format a15
col nbrfiles format 9999
select 'Data Files' dftype,count(*) nbrfiles,
substr(f.file_name,1,(instr(f.file_name,'/',-1,1) -1)) fsmtpt,
sum(bytes)/1024/1024/1024 mtptgb
from dba_data_files f
group by substr(f.file_name,1,(instr(f.file_name,'/',-1,1) -1))
union
select 'Temp Files' dftype,count(*) nbrfiles,
substr(t.file_name,1,(instr(t.file_name,'/',-1,1) -1)) fsmtpt,
sum(bytes)/1024/1024/1024 mtptgb
from dba_temp_files t
group by substr(t.file_name,1,(instr(t.file_name,'/',-1,1) -1))
union 
select 'Redo Logs' dftype, count(*) nbrfiles,
substr(lf.member,1,(instr(lf.member,'/',-1,1) -1)) fsmtpt,
sum(bytes)/1024/1024/1024 mtptgb
from v$log lg, v$logfile lf
where lf.group# = lg.group#
group by substr(lf.member,1,(instr(lf.member,'/',-1,1) -1))
union
select 'Control Files' dftype, count(*) nbrfiles,
substr(c.name,1,(instr(c.name,'/',-1,1) -1)) fsmtpt,
0 mtptgb
from v$controlfile c
group by substr(c.name,1,(instr(c.name,'/',-1,1) -1))
order by 3
/                       
