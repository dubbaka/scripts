/* @tu_redostats.sql
     see the critical stats for redo and archive logs
     SDR-Oracle
     Note: this script is the v8-compatible version
*/
set pages 0 lines 2000 pause off feedback off verify off

col dsnbr noprint

/* is the archiver falling behind, count should be 1 or 0 */
select decode(count(1),   0,'Archiver is current',    1,'Archiver is archiving ' || count(1) || ' log...',
		 'Archiver has fallen behind by ' || count(1) || ' logs!')
from   v$log 
where  status != 'CURRENT'
and    archived = 'NO';

/* what is the latest archived log LAL:<archlog name>:<seq #> */
select 'Latest Archived Log:' || chr(9) || h.name
       || chr(9) || 'Sequence #' || max(h.sequence#)
from   v$archived_log h
where  h.sequence# = (select max(l.sequence#) from v$log l where l.archived = 'YES' and l.status = 'INACTIVE')
group by 'Latest Archived Log:' || chr(9) || h.name

/* what is the current log  COL:<ufs mt pt>:<log name>:<seq #>:<# members> */
prompt Current Online Logs:
select chr(9) || f.member
       || chr(9) || 'Sequence #' || l.sequence#
from   v$logfile f, v$log l
where  l.group# = f.group#
and    l.status = 'CURRENT'
and    l.archived = 'NO';

/* what are the previous online logs */
prompt Previous Online Logs:
select lc_1.sequence# dsnbr,
        chr(9) || f.member
       || chr(9) || 'Sequence #' || lc_1.sequence#
from   v$log lc, v$log lc_1, v$logfile f
where  lc.sequence#   = (select max(l.sequence#) from v$log l)
and    lc_1.sequence# = lc.sequence# -1
and    f.group#       = lc_1.group#
union
select lc_2.sequence# dsnbr,
       chr(9) || f.member
       || chr(9) || 'Sequence #' || lc_2.sequence#
from   v$log lc, v$log lc_2, v$logfile f
where  lc.sequence#   = (select max(l.sequence#) from v$log l)
and    lc_2.sequence# = lc.sequence# -2
and    f.group#       = lc_2.group#
union
select lc_3.sequence# dsnbr,
       chr(9) || f.member
       || chr(9) || 'Sequence #' || lc_3.sequence#
from   v$log lc, v$log lc_3, v$logfile f
where  lc.sequence#   = (select max(l.sequence#) from v$log l)
and    lc_3.sequence# = lc.sequence# -3
and    f.group#       = lc_3.group#
union
select lc_4.sequence# dsnbr,
       chr(9) || f.member
       || chr(9) || 'Sequence #' || lc_4.sequence#
from   v$log lc, v$log lc_4, v$logfile f
where  lc.sequence#   = (select max(l.sequence#) from v$log l)
and    lc_4.sequence# = lc.sequence# -4
and    f.group#       = lc_4.group#
union
select lc_5.sequence# dsnbr,
       chr(9) || f.member
       || chr(9) || 'Sequence #' || lc_5.sequence#
from   v$log lc, v$log lc_5, v$logfile f
where  lc.sequence#   = (select max(l.sequence#) from v$log l)
and    lc_5.sequence# = lc.sequence# -5
and    f.group#       = lc_5.group#
union
select lc_6.sequence# dsnbr,
       chr(9) || f.member
       || chr(9) || 'Sequence #' || lc_6.sequence#
from   v$log lc, v$log lc_6, v$logfile f
where  lc.sequence#   = (select max(l.sequence#) from v$log l)
and    lc_6.sequence# = lc.sequence# -6
and    f.group#       = lc_6.group#
union
select lc_7.sequence# dsnbr,
       chr(9) || f.member
       || chr(9) || 'Sequence #' || lc_7.sequence#
from   v$log lc, v$log lc_7, v$logfile f
where  lc.sequence#   = (select max(l.sequence#) from v$log l)
and    lc_7.sequence# = lc.sequence# -7
and    f.group#       = lc_7.group#
order  by 1 desc;

/* how many minutes since the last log switch MSL:<elapsed minutes> */
select 'Elapsed Minutes Since Last Log Switch:' || chr(9) || trunc((sysdate-first_time)*24*60)
from    v$log
where   status = 'CURRENT'
and     sequence# = (select max(sequence#) + 1 from v$log_history);

/* what are the last 3 individual switch intervals L3I:<1>:<2>:<3> */
select 'Prior 3 Actual Switch Intervals (mins):' || chr(9) || '[' || 
        round((lc.first_time   - lc_1.first_time)*24*60,1) 
        || ']' || chr(9) || '[' ||
        round((lc_1.first_time - lc_2.first_time)*24*60,1)
        || ']' || chr(9) || '[' ||
        round((lc_2.first_time - lc_3.first_time)*24*60,1)
        || ']'
from    v$log lc, v$log_history lc_1, v$log_history lc_2, v$log_history lc_3
where   lc.sequence#   = (select max(l.sequence#) from v$log l)
and     lc_1.sequence# = lc.sequence# -1
and     lc_2.sequence# = lc.sequence# -2
and     lc_3.sequence# = lc.sequence# -3;

/* what is the avg interval for last 3 log switches L3S:<minutes> */
select 'Prior 3 Average Switch Interval (mins):' || chr(9) || 
        round( (
               round((lc.first_time - lc_1.first_time) * 24 * 60,2) +
               round((lc_1.first_time - lc_2.first_time) * 24 * 60,2) +
               round((lc_2.first_time - lc_3.first_time) * 24 * 60,2) ) / 3, 1)
from    v$log lc, v$log_history lc_1, v$log_history lc_2, v$log_history lc_3
where   lc.sequence#   = (select max(l.sequence#) from v$log l)
and     lc_1.sequence# = lc.sequence# -1
and     lc_2.sequence# = lc.sequence# -2
and     lc_3.sequence# = lc.sequence# -3;

set lines 2000
