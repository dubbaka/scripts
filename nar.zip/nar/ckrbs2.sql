-- @ck_rbs2.sql
prompt  -- checking Rollback segments for active transactions -->
prompt	--	Username, Sid, StartTime of Txn, UndoSegment, UndoUsedBlocks, Module, Action


clear columns breaks compute

set pages 40 pau on lines 200

col username for a15
col sid for 99999
col serial# for 99999
col spid head "DBProc" for 99999
col used_ublk for 999,999,999
col module for a40
col action for a35
col name head UndoSegement for a12
col StartTime for a17

accept trgtSCHEMA char default ALL prompt 'Schema <ALL> : '
accept trgtSID number default 9999 prompt 'SID <ALL> : '
accept trgtOSproc char default ALL prompt 'DB OS PID <ALL> : '
accept trgtRBS char default ALL prompt 'UndoSegment <ALL> : '
accept trgtMODULE char default ALL prompt 'Module <ALL> : '
accept trgtGTBlks number default 0 prompt 'GTBlks <ALL> : '

select s.username, s.sid, s.serial#, p.spid, t.start_time "StartTime", r.name, t.used_ublk, s.module, s.action
from   v$transaction t, v$session s, v$process p, v$rollname r
where  t.addr      = s.taddr
and    t.addr      = s.taddr
and    r.usn       = t.xidusn
and    s.paddr     = p.addr(+)
and   (upper(s.username) like upper('%&trgtSCHEMA%') or upper('&trgtSCHEMA') = 'ALL')
and   (s.sid  =  &trgtSID      or        &trgtSID       = 9999)
and   (p.spid = '&trgtOSproc'  or upper('&trgtOSproc')  = 'ALL')
and   (upper(r.name)     like upper('%&trgtRBS%')    or upper('&trgtRBS')    = 'ALL')
and   (upper(s.module)   like upper('%&trgtMODULE%') or upper('&trgtMODULE') = 'ALL')
and   (t.used_ublk > &trgtGTBlks)
order  by 5 desc;

