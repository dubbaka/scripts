-- @fopricing.sql
-- Relevant only for Belron Front Office Remedy application

clear columns breaks computes

set pages 50000 lines 2000 feed on head on echo on pau off timing on time on veri off  trimspool on colsep |

col func_name     for a15
col "ReqDate"     for a10
col "TotalCalls"  for 999,999
col "TimePoints"  for 999,999 head "Time"
col "Yellow"      for a6
col "Red"         for a3
col tot_time      for 999999.99
col min_time      for 999999.99
col average_time  for 999999.99
col "0000-0059"   for 99999
col "0100-0159"   for 99999
col "0200-0259"   for 99999
col "0300-0359"   for 99999
col "0400-0459"   for 99999
col "0500-0559"   for 99999
col "0600-0659"   for 99999
col "0700-0759"   for 99999
col "0800-0859"   for 99999
col "0900-0959"   for 99999
col "1000-1059"   for 99999
col "1100-1159"   for 99999
col "1200-1259"   for 99999
col "1300-1359"   for 99999
col "1400-1459"   for 99999
col "1500-1559"   for 99999
col "1600-1659"   for 99999
col "1700-1759"   for 99999
col "1800-1859"   for 99999
col "1900-1959"   for 99999
col "2000-2059"   for 99999
col "2100-2159"   for 99999
col "2200-2259"   for 99999
col "2300-2359"   for 99999


prompt
prompt Pricing Summary for this month
select func_name, trunc(request_date) "ReqDate", count(1) "TotalCalls", count(unique to_char(request_date, 'hh24:mi')) "TimePoints"
, round(sum(request_endtoendtime)/100, 2) tot_time, round(min(request_endtoendtime)/100, 2) min_time, round(avg(request_endtoendtime)/100, 2) average_time
, round(max(request_endtoendtime)/100, 2) max_time
from arcustom.cp_tst_profile_run
where func_name in ('PRICE JOB', 'STOCK ACTION', 'STOCK ENQUIRY')
group by func_name, trunc(request_date)
order by func_name, "ReqDate";


prompt
prompt Identify Yellows for this month
select func_name, trunc(request_date) "ReqDate", max('Yellow') "Yellow", count(1) "TotalCalls", count(unique to_char(request_date, 'hh24:mi')) "TimePoints"
, round(sum(request_endtoendtime)/100, 2) tot_time, round(min(request_endtoendtime)/100, 2) min_time, round(avg(request_endtoendtime)/100, 2) average_time
, round(max(request_endtoendtime)/100, 2) max_time
from arcustom.cp_tst_profile_run
where func_name in ('PRICE JOB', 'STOCK ACTION', 'STOCK ENQUIRY')
and round(request_endtoendtime/100, 2) between 4 and 7.99
group by func_name, trunc(request_date)
order by func_name, "ReqDate";


prompt
prompt Identify Reds for this month
select func_name, trunc(request_date) "ReqDate", max('Red') "Red", count(1) "TotalCalls", count(unique to_char(request_date, 'hh24:mi')) "TimePoints"
, round(sum(request_endtoendtime)/100, 2) tot_time, round(min(request_endtoendtime)/100, 2) min_time, round(avg(request_endtoendtime)/100, 2) average_time
, round(max(request_endtoendtime)/100, 2) max_time
from arcustom.cp_tst_profile_run
where func_name in ('PRICE JOB', 'STOCK ACTION', 'STOCK ENQUIRY')
and round(request_endtoendtime/100, 2) >= 8
group by func_name, trunc(request_date)
order by func_name, "ReqDate";


prompt
prompt Display Hourly Pricing Calls
select trunc(request_date) "ReqDate",
sum(decode(to_char(request_date,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(request_date,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(request_date,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(request_date,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(request_date,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(request_date,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(request_date,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(request_date,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(request_date,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(request_date,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(request_date,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(request_date,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(request_date,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(request_date,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(request_date,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(request_date,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(request_date,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(request_date,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(request_date,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(request_date,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(request_date,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(request_date,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(request_date,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(request_date,'hh24'),'23',1,0)) "2300-2359"
from arcustom.cp_tst_profile_run
where func_name in ('PRICE JOB', 'STOCK ACTION', 'STOCK ENQUIRY')
group by trunc(request_date)
order by "ReqDate";


prompt
prompt Hourly Yellow calls
select trunc(request_date) "ReqDate",
sum(decode(to_char(request_date,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(request_date,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(request_date,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(request_date,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(request_date,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(request_date,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(request_date,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(request_date,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(request_date,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(request_date,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(request_date,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(request_date,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(request_date,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(request_date,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(request_date,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(request_date,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(request_date,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(request_date,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(request_date,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(request_date,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(request_date,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(request_date,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(request_date,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(request_date,'hh24'),'23',1,0)) "2300-2359"
from arcustom.cp_tst_profile_run
where func_name in ('PRICE JOB', 'STOCK ACTION', 'STOCK ENQUIRY')
and round(request_endtoendtime/100, 2) between 4 and 7.99
group by trunc(request_date)
order by "ReqDate";


prompt
prompt Hourly Red calls
select trunc(request_date) "ReqDate",
sum(decode(to_char(request_date,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(request_date,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(request_date,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(request_date,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(request_date,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(request_date,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(request_date,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(request_date,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(request_date,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(request_date,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(request_date,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(request_date,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(request_date,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(request_date,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(request_date,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(request_date,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(request_date,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(request_date,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(request_date,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(request_date,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(request_date,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(request_date,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(request_date,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(request_date,'hh24'),'23',1,0)) "2300-2359"
from arcustom.cp_tst_profile_run
where func_name in ('PRICE JOB', 'STOCK ACTION', 'STOCK ENQUIRY')
and round(request_endtoendtime/100, 2) >= 8
group by trunc(request_date)
order by "ReqDate";

clear columns breaks computes
