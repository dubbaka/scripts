select * from (
select a.concurrent_program_id,a.request_id,
l2.meaning phasetxt
      ,l1.meaning statustxt
      ,(nvl(actual_completion_date,sysdate)-actual_start_date)*1440 "Time"
      ,to_char(a.actual_start_date,'mm/dd/yy  hh:mi:ssAM') "Started On"
      ,to_char(a.actual_completion_date,'mm/dd/yy  hh:mi:ssAM') "Finished On"
      ,u.user_name || ' - ' || u.description "Submitted By"
      ,a.argument_text
from APPLSYS.fnd_Concurrent_requests a
    ,applsys.fnd_user u
    ,applsys.fnd_lookup_values l1
    ,applsys.fnd_lookup_values l2
where u.user_id = a.requested_by
  and a.requested_by = 1467
  and l1.lookup_type = 'CP_STATUS_CODE'
  and l1.lookup_code = a.status_code
  and l1.language = 'US'
  and l1.enabled_flag = 'Y'
  -- and (l1.start_date_active <= sysdate and l1.start_date_active is not null)
  and (l1.end_date_active > sysdate or l1.end_date_active is null)
  and l2.lookup_type = 'CP_PHASE_CODE'
  and l2.lookup_code = a.phase_code
  and l2.language = 'US'
  and l2.enabled_flag = 'Y'
  -- and (l2.start_date_active <= sysdate and l2.start_date_active is not null)
  and (l2.end_date_active > sysdate or l2.end_date_active is null)
order by a.actual_start_date desc)
where rownum < 11
/
