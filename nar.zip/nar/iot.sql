-- @iot.sql


clear columns breaks computes

set pages 1000 pau off feed on lines 300

col owner for a15
col INDEX_TYPE for a15
col TABLESPACE_NAME for a20
col object_name for a30
col segment_name for a30
col SUBOBJECT_NAME for a30
col OBJECT_TYPE for a20

accept IOTName char default ALL prompt 'Table: <ALL>'


spool spool\iot_&_MyDB1.

SELECT table_name, num_rows, tablespace_name, iot_name, iot_type, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, FREELISTS, FREELIST_GROUPS
FROM   dba_tables                                         
where  table_name like upper('&IOTName%');

SELECT owner, index_name, num_rows, index_type, tablespace_name, table_name, table_type, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, FREELISTS, FREELIST_GROUPS
FROM   dba_indexes                                             
WHERE  table_name like upper('&IOTName%');

select owner, object_id, object_name, SUBOBJECT_NAME, OBJECT_TYPE
from   dba_objects
where  object_name like '%&IOTName%'
and    OBJECT_TYPE != 'SYNONYM'
order  by OBJECT_TYPE
--and    owner in ('VRN' , 'ARADMIN' , 'ARCUSTOM' , 'XXSTAGE0' , 'BELTECH' , 'VRNBR' , 'XXBEL' , 'XXREJECT');

SELECT segment_name, tablespace_name, segment_type       
FROM   dba_segments                                      
WHERE  segment_name like '%&ObjId%'; 

spool off
