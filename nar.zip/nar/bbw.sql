-- @bbw.sql

set lines 300

col event for a17 trunc
col username for a15
col osuser for a15
col p1 for 9999
col p3 for 999
col sid for 9999
col machine for a30
col program for a100
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11

select w.inst_id, w.wait_class, w.event, w.sid, s.username, floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
     , w.p1, w.p2, w.p3, s.sql_hash_value, s.status, p.spid, s.osuser, s.module || ' - ' || nvl(s.program, p.program) program
from   gv$session_wait w, gv$session s, gv$process p
where  w.event = 'buffer busy waits'
and    w.inst_id = s.inst_id
and    w.inst_id = p.inst_id
and    s.sid = w.sid
and    s.paddr = p.addr
and    w.wait_time = 0
order  by 1 desc;
