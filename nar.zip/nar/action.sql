col inst_id for 9999 head "Inst|Id"
col SID for 99999
col "SERIAL#" for 999999 
col process head "OSpid|APnode" for a6
col SPID head "OSpid|DBnode" for a6
col username for a10 head "Schema"
col osuser for a10 
col machine for a15
col module for a20
col sql_hash_value head "SQL_HASH" for 9999999999
col program for a80 
col logontime for a15
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11

select sid,serial#, inst_id, to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime
      , floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
, status, action 
from gv$session  s
where action like upper('%&login1%')
order by logontime
/
