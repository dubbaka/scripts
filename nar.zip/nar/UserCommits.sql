-- @UserCommits.sql

clear computes columns breaks

col inst_id for 9999 head "Inst|Id"
col name for a20
col sid for 99999

accept trgtRows number default 20 prompt 'Rows to display <20> : '

select n.inst_id, name, count(1)
from   gv$statname n, gv$sesstat s
where  n.inst_id = s.inst_id
and    name in ('user commits' , 'user rollback')
and    s.statistic# = n.statistic#
group  by n.inst_id, name;

Select * from
(
select n.inst_id, name, sid, value
from   gv$statname n, gv$sesstat s
where  n.inst_id = s.inst_id
and    name in ('user commits' , 'user rollback')
and    s.statistic# = n.statistic#
order  by value desc, sid
)
where rownum <= &trgtRows;
