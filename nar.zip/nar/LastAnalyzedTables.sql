-- @LastAnalyzedTables.sql


set pages 50 feed off verify off linesize 200

spool spool\LastAnalyzedTables_&_MyDB1.

col table_name head "Table Name" for a30
col column_name head "Column Name" for a30
col newest head "Newest" for date
col oldest head "Oldest" for date

select  table_name, column_name
      , to_char(max(last_analyzed), 'DD-MON-YYYY HH24:MI') newest
      , to_char(min(last_analyzed), 'DD-MON-YYYY HH24:MI') oldest
from    sys.dba_tab_columns  
where   last_analyzed is not null 
and	owner != 'SYS'
group by table_name, column_name;

spool off
