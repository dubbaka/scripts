-- @TopFreqAccPkgs.sql

clear columns breaks computes

set pages 50000 lines 2000 feed on head on echo on pau off timing on time on veri off  trimspool on colsep |

col inst_id for 99999 head 'InstId'
col INSTANCE_NAME for a10 head "Instance"
col HOST_NAME for a20
col OBJECT_NAME for a30
col type for a30
col owner for a25 head "Owner"
col sharable_mem for 999999999999999999999
col loads for 999999999999999999999
col executions for 999999999999999999999
col kept for 999999999999999999999
col locks for 999999999999999999999
col pins for 999999999999999999999


prompt 
prompt Top 50 frequently accessed Packages
prompt By Executions
select * from (
select A.INST_ID, INSTANCE_NAME, HOST_NAME, owner, name OBJECT_NAME, type, nvl(sharable_mem,0) sharable_mem, nvl(loads,0) loads
, nvl(executions,0) executions, nvl(kept,0) kept, nvl(locks,0) locks, nvl(Pins,0) pins
from gv$db_object_cache A , gv$instance B
where type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and executions >0
and B.INST_ID = A.INST_ID
order by executions desc)
where rownum < 51;

prompt 
prompt By Loads
select * from (
select A.INST_ID, INSTANCE_NAME, HOST_NAME, owner, name OBJECT_NAME, type, nvl(sharable_mem,0) sharable_mem, nvl(loads,0) loads
, nvl(executions,0) executions, nvl(kept,0) kept, nvl(locks,0) locks, nvl(Pins,0) pins
from gv$db_object_cache A , gv$instance B
where type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and loads >0
and B.INST_ID = A.INST_ID
order by loads desc)
where rownum < 51;

prompt 
prompt By Sharable Memory
select * from (
select A.INST_ID, INSTANCE_NAME, HOST_NAME, owner, name OBJECT_NAME, type, nvl(sharable_mem,0) sharable_mem, nvl(loads,0) loads
, nvl(executions,0) executions, nvl(kept,0) kept, nvl(locks,0) locks, nvl(Pins,0) pins
from gv$db_object_cache A , gv$instance B
where type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and sharable_mem >0
and B.INST_ID = A.INST_ID
order by sharable_mem desc)
where rownum < 51;

prompt By Locks
select * from (
select A.INST_ID, INSTANCE_NAME, HOST_NAME, owner, name OBJECT_NAME, type, nvl(sharable_mem,0) sharable_mem, nvl(loads,0) loads
, nvl(executions,0) executions, nvl(kept,0) kept, nvl(locks,0) locks, nvl(Pins,0) pins
from gv$db_object_cache A , gv$instance B
where type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and Locks >0
and B.INST_ID = A.INST_ID
order by Locks desc)
where rownum < 51;

prompt By Pins
select * from (
select A.INST_ID, INSTANCE_NAME, HOST_NAME, owner, name OBJECT_NAME, type, nvl(sharable_mem,0) sharable_mem, nvl(loads,0) loads
, nvl(executions,0) executions, nvl(kept,0) kept, nvl(locks,0) locks, nvl(Pins,0) pins
from gv$db_object_cache A , gv$instance B
where type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and Pins>0
and B.INST_ID = A.INST_ID
order by Pins desc)
where rownum < 51;

clear columns breaks computes
