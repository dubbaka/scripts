col sid	for 9999
col username for a10 trunc
col process for 99999999
col spid for 99999999
col program for a40 trunc
set verify off

select
	s.sid,
	s.serial#,
	s.username,
	s.process,
	p.spid,
	s.program,
	s.osuser,
	s.machine,
        to_char(s.logon_time,'dd-mon-yy hh24:mi') LogonTime
from
	v$session s,
	v$process p
where
	to_char(s.sid) like '&&1'
	and s.paddr=p.addr
union
select
	s.sid,
	s.serial#,
	s.username,
	s.process,
	p.spid,
	s.program,
	s.osuser,
	s.machine,
        to_char(s.logon_time,'dd-mon-yy hh24:mi') LogonTime
from
	v$session s,
	v$process p
where
	(to_char(p.spid) = '&&1' or s.process = '&&1' or s.osuser='&&1')
	and s.paddr=p.addr
order by
	1
/
undefine 1
set verify on

