-- @fndnodes.sql
set pagesize 50

col node_name format a15
col server_id format a80
col server_address format a15
col platform_code format a4
col webhost format a12 trunc
col domain format a20
col virtual_ip format a12

select node_id,  platform_code, node_name, 
decode(STATUS,'Y','ACTIVE','INACTIVE') Status,
decode(SUPPORT_CP,'Y', 'ConcMgr','No') ConcMgr,
decode(SUPPORT_FORMS,'Y','Forms', 'No') Forms,
decode(SUPPORT_WEB,'Y','Web', 'No') WebServer,
decode(SUPPORT_ADMIN, 'Y','Admin', 'No') Admin,
decode(SUPPORT_DB, 'Y','Rdbms', 'No') Database,
         server_address,  domain,  webhost,  virtual_ip, server_id
from   fnd_nodes
order  by node_name
/
