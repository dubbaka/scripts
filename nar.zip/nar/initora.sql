/* init73params.sql
     get all the parameters for v7.3
*/
set feedback off
set pause off
set pagesize 66
set linesize 132
col ksppinm format a30 heading Parameter trunc
col ksppdesc format a60 heading Description trunc
col ksppstvl format a30 heading SessionValue trunc
spool initoraparams.lst
select a.ksppinm,
       a.ksppdesc,
       b.ksppstvl 
  from sys.x$ksppi a, sys.x$ksppcv b, sys.x$ksppsv c
 where a.indx = b.indx
   and a.indx = c.indx
order by 1;
spool off



