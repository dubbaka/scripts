-- @type.sql


clear columns breaks computes

set lines 300

col owner for a12
col type_name for a30
col TYPECODE for a10
col SUPERTYPE_OWNER for a12 head "Supertype|Owner"


select owner, type_name, TYPECODE, ATTRIBUTES, METHODS, PREDEFINED, INCOMPLETE, FINAL, INSTANTIABLE, 
SUPERTYPE_OWNER, SUPERTYPE_NAME, LOCAL_ATTRIBUTES, LOCAL_METHODS
from  dba_types
where type_name = '&Name';
