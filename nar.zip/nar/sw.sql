/* sidwaits.sql   see sesssions and what they are waiting on Oracle */

clear columns breaks computes
set lines 600 pages 100 veri off

col inst_id        for 9999 head "Inst|Id"
col SID            for 99999
col "SERIAL#"      for 999999
col SPID           for a6 head "OSpid|DBnode"
col process        for a6 trunc head "oraPID|APnode"
col event          for a35 trunc
col sql_hash_value for 9999999999 head "SQL_HASH"
col process        for a10
col spid           for a6
col "p1:p2:p3"     for a30 trunc
col program        for a20
col machine        for a10 trunc
col "DBSchema"     for a12
col DBNosuser      for a9 trunc
col APNosuser      for a9 trunc
col LastCallET     for a11 head "LastCallEt|(hh:mi:ss)"
col logontime      for a15
col "TimeMins"     for 999,999.99  head "TimeSpent|(Mins)"
col Class          for a15
col "ModShrt"      for a20 trunc
col WAIT_CLASS     for a15
col ACTION         for a35


accept trgtRows number default 20 prompt 'Rows to display <20> : '
accept trgtClass char default ALL prompt 'WaitClass <ALL> : '
accept trgtsid number default 0 prompt 'What is the SID <ALL> : '
accept trgtSqlId char default ALL prompt 'SqlId <ALL> : '
accept trgtmodule char default ALL prompt 'Module <ALL>: '
accept trgtStatus char default ALL prompt 'Status <ALL> : '
select * from (
select 
--s.INST_ID, w.WAIT_CLASS, 
w.sid, w.event, w.SECONDS_IN_WAIT/60 "TimeMins", w.state, s.module "ModShrt", s.sql_hash_value "SQL_HASH"
--, s.SQL_ID
     , to_char(s.logon_time,'Mon/dd hh24:mi:ss') logontime, w.p1||'('||w.p1text||'):' || w.p2||'('||w.p2text||'):' || w.p3||'('||w.p1text||')' "p1:p2:p3"
     , floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET"
     , s.ACTION, s.machine, s.USERNAME "DBSchema", p.USERNAME "DBNosuser", s.osuser "APNosuser", s.process, p.spid, s.module, s.program
     , s.ROW_WAIT_OBJ#, s.ROW_WAIT_FILE#, s.ROW_WAIT_BLOCK#, s.ROW_WAIT_ROW#
from   gv$session_wait w, gv$session s, gv$process p
where (s.sid = &trgtsid or &trgtsid = 0)
and		w.event not like 'SQL*Net%client'
 and w.event not like '%timer%'
 and w.event not like 'rdbms ipc%'
 and w.event not like 'pipe get%'
 and w.event not like '%manager%'
 and w.event not like 'queue message%'
and    s.sid = w.sid
and    s.paddr = p.addr
and    w.wait_time = 0
--and    w.wait_class != 'Idle'
--and   (s.sql_id = '&trgtSqlId' or upper('&trgtSqlId') = 'ALL')
--and   (upper(w.WAIT_CLASS)  like upper('&trgtClass%') or '&trgtClass' = 'ALL')
and   (upper(s.module)  like upper('%&trgtmodule%') or '&trgtmodule' = 'ALL')
and   (upper(s.status) like upper('&trgtStatus') or '&trgtStatus' = 'ALL')
order  by w.SECONDS_IN_WAIT desc
)
where rownum <= &trgtRows;
