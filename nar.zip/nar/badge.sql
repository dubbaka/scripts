/* whois.sql
    show who is attached in the Apps to a given Apps user_name
*/
set verify off
col description head "Real Name" format a40 trunc
col user_name head "Apps Logon Name" format a15 trunc
col user_id head "Internal #"
accept srchusr char prompt 'What is the Apps logon username : '
select user_id,user_name,description
from applsys.fnd_user
where user_name like upper('%&srchusr%');

