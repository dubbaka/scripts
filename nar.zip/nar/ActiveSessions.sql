-- @ActiveSessions.sql


clear columns computes breaks

set feed off echo off pages 200 lines 1000

col SID for 99999
col USERNAME for a15
col SCHEMANAME for a15
col OSUSER for a15
col MACHINE for a30
col "LogonTime" for a20
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11
col "DispDateNow" for a22

col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDMonYYYYhh24miss') "datenow" from dual;
set feed on


spool spool\ActiveSessions_&_MyDateNow._&_MyDB1.

select to_char(sysdate, 'dd-Mon-YYYY hh24:mi:ss') "DispDateNow" from dual;

select SID, SERIAL#, PROCESS, USERNAME, to_char(LOGON_TIME, 'DD-Mon-YY hh24:mi:ss') "LogonTime"
      ,floor(last_call_et/3600)||':'||floor(mod(last_call_et,3600)/60)||':'||mod(mod(last_call_et,3600),60) "LastCallET"
      ,STATUS, SCHEMANAME, OSUSER, MACHINE, PROGRAM, SQL_HASH_VALUE, MODULE, SQL_ADDRESS, SERVER, ACTION, CLIENT_INFO, CLIENT_IDENTIFIER
from   v$session
where  STATUS = 'ACTIVE'
order  by LOGON_TIME asc;
spool off

clear columns computes breaks
