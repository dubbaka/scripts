-- @ObjectsNotAnalyzed.sql


spool spool\TablesNotAnalyzed
select owner, 'Table' ObjectType, table_name "Object"
from   dba_tables
where  last_analyzed is null
and    owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
union
select owner, 'Index' ObjectType, index_name "Object"
from   dba_indexes
where  last_analyzed is null
and    owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
order  by 1,2;
spool off
