-- @LockType.sql


clear columns breaks computes

set feed on pages 132 pau off

col sid for 99999
col event for a20
col p1 for 9999999999
col p1text for a10
col p2 for 9999999999
col p2text for a10
col p3 for 9999999999
col p3text for a10
col Mode for a10

SELECT sid, event, p1, p1text, p2, p2text, p3, p3text, chr(bitand(p1,-16777216)/16777215)||chr(bitand(p1, 16711680)/65535) "Lock", to_char( bitand(p1, 65535) ) "Mode"
FROM   v$session_wait
WHERE  event = 'enqueue';

clear columns breaks computes

prompt If the mode is mode is 6, the lock is an Exclusive lock.
prompt If the mode is 4, the lock is a Share lock.
prompt 
