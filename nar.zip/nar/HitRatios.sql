-- name       : @HitRatios.sql
-- Description: This script checks out various hit ratios and reports
--              on the SGA sizes and also checks out physical and 
--              memory sorts.

clear columns breaks computes

set pages 50 feed off verify off linesize 80

col name head "SGA Parameter" for a30
col value head "Value" for a30

select 	INST_ID, name, value
from	gv$parameter
where	name in ('db_block_buffers','db_block_size','shared_pool_size','sort_area_size');


--
-- buffer hit ratio should be > 95%, ora recomend 90% going from 95% to 99% can yeild performance gains
--
doc

	The buffer cache hit ratio should be greater than 95% and increasing to nearer 99% can result in performance gains.
#
col hit_ratio head "Buffer Cache Hit Ratio" for 99.99
select	INST_ID, (1-(sum(decode(name,'physical reads',value,0)) / (sum(decode(name,'db block gets',value,0))+ sum(decode(name,'consistent gets',value,0)))))*100 hit_ratio
from	gv$sysstat
group   by INST_ID;


--
-- should be above 95%
-- increasing the shared pool will move this up, but will be about 85% on database start up
--
doc

	The dictionary cache should have a hit ratio greater than 95%. Increasing the shared_pool_size will result in a higher hit ratio.
#
col hit_ratio head "Dictionary Cache" for 99.99
select	INST_ID, (1-(sum(getmisses)/sum(gets)))*100 hit_ratio
from	gv$rowcache
group   by INST_ID;



--
-- hit ratio should be over 95%, increasing the shared pool will
-- move this up, dont measure at startup
--
doc

	The library cache hit ratio should be greater than 95%. increasing the share_pool_size will improve this hit ratio.
#
col hit_ratio head "Library Cache Hit Ratio" for 99.99
select INST_ID, sum(pins) / (sum(pins) + sum(reloads))*100 hit_ratio
from	gv$librarycache
group   by INST_ID;


--
-- check the amount of free memory in the shared pool
--
doc

	This section checks out the shared pool size, the free memory in the shared pool and the percentage of free memory.
#

col value for 99,999,999 head "sizeM"
col bytes for 99,999,999 head "FreeBytesM"
col pct_free for 99.99 head "Pct Free"
-- 
-- this script assumes the sizes are in bytes and not say 50M
--
select	a.INST_ID, a.POOL, to_number(b.value)/(1024*1024) value, a.bytes/(1024*1024) bytes
from	gv$sgastat a, gv$parameter b
where	a.INST_ID = b.INST_ID
and	a.name='free memory'
and	b.name='shared_pool_size'
and     b.value != '0';


--
-- get disk reads and writes
--
doc

	This section shows the sort ratios and the amount of disk sorts and memory sorts.
#

select	a.INST_ID, a.value "disk sorts", b.value "memory sorts",
	(round(b.value)/decode((a.value+b.value),0,1,(a.value+b.value))*100) "pct memory sorts"
from	gv$sysstat a, gv$sysstat b
where	a.INST_ID = b.INST_ID
and	a.name='sorts (disk)'
and	b.name='sorts (memory)';
