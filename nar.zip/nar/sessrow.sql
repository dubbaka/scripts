column name format a30 word_wrapped
column vlu format 999,999,999,999
accept trgtsid number default 0 prompt 'What is the SID <ALL> : '

select distinct a.inst_id,b.name, a.value vlu
from gv$sesstat a, gv$statname b
where a.statistic# = b.statistic#
and sid =&trgtsid
and a.value != 0
and b.name like '%row%'
order by 1
/

