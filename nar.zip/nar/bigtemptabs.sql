col owner format a10
col segment_name format a30
select * from (
select owner,segment_name, bytes,extents
 from dba_segments
where segment_name like '%_TEMP'
and segment_type = 'TABLE'
order by 3 desc,4)
where rownum < 21
/
