-- @ArchLogStats.sql

clear columns breaks computes

set pages 50000 lines 2000 feed on head on echo on pau off timing on time on veri off trimspool on colsep |

col "0000-0059" for 999999
col "0100-0159" for 999999
col "0200-0259" for 999999
col "0300-0359" for 999999
col "0400-0459" for 999999
col "0500-0559" for 999999
col "0600-0659" for 999999
col "0700-0759" for 999999
col "0800-0859" for 999999
col "0900-0959" for 999999
col "1000-1059" for 999999
col "1100-1159" for 999999
col "1200-1259" for 999999
col "1300-1359" for 999999
col "1400-1459" for 999999
col "1500-1559" for 999999
col "1600-1659" for 999999
col "1700-1759" for 999999
col "1800-1859" for 999999
col "1900-1959" for 999999
col "2000-2059" for 999999
col "2100-2159" for 999999
col "2200-2259" for 999999
col "2300-2359" for 999999

col "s0000-0059" for 9999999
col "s0100-0159" for 9999999
col "s0200-0259" for 9999999
col "s0300-0359" for 9999999
col "s0400-0459" for 9999999
col "s0500-0559" for 9999999
col "s0600-0659" for 9999999
col "s0700-0759" for 9999999
col "s0800-0859" for 9999999
col "s0900-0959" for 9999999
col "s1000-1059" for 9999999
col "s1100-1159" for 9999999
col "s1200-1259" for 9999999
col "s1300-1359" for 9999999
col "s1400-1459" for 9999999
col "s1500-1559" for 9999999
col "s1600-1659" for 9999999
col "s1700-1759" for 9999999
col "s1800-1859" for 9999999
col "s1900-1959" for 9999999
col "s2000-2059" for 9999999
col "s2100-2159" for 9999999
col "s2200-2259" for 9999999
col "s2300-2359" for 9999999

col inst_id for 99999 head 'InstId'
col thread# for 99999 head 'Thread'
col dest_id for 99999 head 'DestID'
col STANDBY_DEST for a7 head 'Standby|Dest?'
col "DestName"    for a15
col "ArcDate"    for a10
col "ArchLogs"   for 99999999
col "AvgSizeMB"  for 9999999999999
col "MinSizeMB"  for 9999999999999
col "MaxSizeMB"  for 9999999999999
col "SizeGB"     for 999999.99

prompt 
prompt Archive logging stats
prompt Get the Archlogs dumped and size averages by day
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName"
, trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs", sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
, min(BLOCKS*BLOCK_SIZE/(1048576)) "MinSizeMB", avg(BLOCKS*BLOCK_SIZE/(1048576)) "AvgSizeMB", max(BLOCKS*BLOCK_SIZE/(1048576)) "MaxSizeMB"
from gv$ARCHIVED_LOG
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 100MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 100
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 200MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 200
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 300MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 300
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 400MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 400
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 500MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 500
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 600MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 600
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 700MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 700
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 800MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 800
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size <= 900MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) <= 900
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size > 900MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) > 900
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);

prompt Get the count of Archlogs dumped size > 999MB
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(COMPLETION_TIME) "ArcDate", count(1) "ArchLogs"
, sum(BLOCKS*BLOCK_SIZE/(1073741824)) "SizeGB"
from gv$ARCHIVED_LOG
where BLOCKS*BLOCK_SIZE/(1048576) > 999
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(COMPLETION_TIME)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", trunc(COMPLETION_TIME);


prompt Number of Archivelogs generated every hour
select inst_id, thread#, trunc(first_time) "ArcDate",
sum(decode(to_char(first_time,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(first_time,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(first_time,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(first_time,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(first_time,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(first_time,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(first_time,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(first_time,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(first_time,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(first_time,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(first_time,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(first_time,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(first_time,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(first_time,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(first_time,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(first_time,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(first_time,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(first_time,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(first_time,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(first_time,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(first_time,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(first_time,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(first_time,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(first_time,'hh24'),'23',1,0)) "2300-2359"
from gv$log_history
group by inst_id, thread#, trunc(first_time)
order by inst_id, thread#, "ArcDate";

prompt sizeMB of Archivelogs generated every hour
select inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15) "DestName", trunc(first_time) "ArcDate",
sum(decode(to_char(first_time,'hh24'),'00',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0000-0059",
sum(decode(to_char(first_time,'hh24'),'01',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0100-0159",
sum(decode(to_char(first_time,'hh24'),'02',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0200-0259",
sum(decode(to_char(first_time,'hh24'),'03',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0300-0359",
sum(decode(to_char(first_time,'hh24'),'04',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0400-0459",
sum(decode(to_char(first_time,'hh24'),'05',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0500-0559",
sum(decode(to_char(first_time,'hh24'),'06',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0600-0659",
sum(decode(to_char(first_time,'hh24'),'07',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0700-0759",
sum(decode(to_char(first_time,'hh24'),'08',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0800-0859",
sum(decode(to_char(first_time,'hh24'),'09',BLOCKS*BLOCK_SIZE/(1048576),0)) "s0900-0959",
sum(decode(to_char(first_time,'hh24'),'10',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1000-1059",
sum(decode(to_char(first_time,'hh24'),'11',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1100-1159",
sum(decode(to_char(first_time,'hh24'),'12',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1200-1259",
sum(decode(to_char(first_time,'hh24'),'13',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1300-1359",
sum(decode(to_char(first_time,'hh24'),'14',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1400-1459",
sum(decode(to_char(first_time,'hh24'),'15',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1500-1559",
sum(decode(to_char(first_time,'hh24'),'16',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1600-1659",
sum(decode(to_char(first_time,'hh24'),'17',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1700-1759",
sum(decode(to_char(first_time,'hh24'),'18',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1800-1859",
sum(decode(to_char(first_time,'hh24'),'19',BLOCKS*BLOCK_SIZE/(1048576),0)) "s1900-1959",
sum(decode(to_char(first_time,'hh24'),'20',BLOCKS*BLOCK_SIZE/(1048576),0)) "s2000-2059",
sum(decode(to_char(first_time,'hh24'),'21',BLOCKS*BLOCK_SIZE/(1048576),0)) "s2100-2159",
sum(decode(to_char(first_time,'hh24'),'22',BLOCKS*BLOCK_SIZE/(1048576),0)) "s2200-2259",
sum(decode(to_char(first_time,'hh24'),'23',BLOCKS*BLOCK_SIZE/(1048576),0)) "s2300-2359"
from gv$ARCHIVED_LOG
group by inst_id, thread#, dest_id, STANDBY_DEST, substr(name,1,15), trunc(first_time)
order by inst_id, thread#, dest_id, STANDBY_DEST, "DestName", "ArcDate";

clear columns breaks computes
