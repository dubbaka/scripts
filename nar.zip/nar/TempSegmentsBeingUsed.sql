-- @TempSegmentsBeingUsed.sql


col "Tablespace" for a10
col USER for a15
col USERNAME for a15
col SizeMB for 999,999,999.99

set pau off lines 500

spool spool\TempSegmentsBeingUsed-&_MyDB1.

select tablespace_name "Tablespace", CURRENT_USERS, total_blocks, used_blocks, free_blocks, TOTAL_EXTENTS, USED_EXTENTS, FREE_EXTENTS
      ,EXTENT_SIZE, ADDED_EXTENTS, SEGMENT_FILE, SEGMENT_BLOCK, EXTENT_HITS, FREED_EXTENTS, FREE_REQUESTS
      ,MAX_SIZE, MAX_BLOCKS, MAX_USED_SIZE, MAX_USED_BLOCKS, MAX_SORT_SIZE, MAX_SORT_BLOCKS, RELATIVE_FNO
from   v$sort_segment;

select USER, SEGTYPE, sum(BLOCKS*8192/(1024*1024)) SizeMB, sum(EXTENTS) TotalExtents
from   V$SORT_USAGE
group  by USER, SEGTYPE;

select USERNAME, SEGTYPE, count(*) "NumSegments", sum(BLOCKS*8192/(1024*1024)) SizeMB, sum(EXTENTS) TotalExtents
from   V$SORT_USAGE
group  by USERNAME, SEGTYPE;

select count(1) "Sessions Using Sort Space"
from   V$SORT_USAGE A, v$session B
where  B.USERNAME = A.USERNAME;

select count(1) "Active Sessions UsingSortSpace"
from   V$SORT_USAGE A, v$session B
where  B.USERNAME = A.USERNAME
and    B.STATUS = 'ACTIVE';

spool off

/*
select A.USERNAME, A.SEGTYPE, B.SID, B.SERIAL#, B.COMMAND, B.STATUS, B.SERVER, B.SCHEMANAME, B.OSUSER
     , B.PROCESS, B.MACHINE, B.TERMINAL, B.PROGRAM, B.SQL_HASH_VALUE , B.CLIENT_INFO
from   V$SORT_USAGE A, v$session B
where  B.USERNAME = A.USERNAME
and    B.STATUS = 'ACTIVE';

select A.USERNAME, B.SID, A.SEGTYPE, sum(BLOCKS*8192/(1024*1024)) SizeMB, sum(EXTENTS) TotalExtents
from   V$SORT_USAGE A, v$session B
where  A.USERNAME = '&SCHEMA'
and    B.USERNAME = A.USERNAME
group  by A.USERNAME, B.SID, A.SEGTYPE;
*/

