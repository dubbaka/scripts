select to_char(sysdate,'hh24:mi') from dual
/
