-- @fndextTables.sql


clear columns breaks computes

col ACCESS_PARAMETERS for a80
Select * 
From  dba_external_tables;


Select application_id 
From   fnd_tables 
Where  table_name in (select table_name From dba_external_tables);

