-- @adhoc.sql


clear columns breaks compute

set lines 400

col SID for 99999
col "SERIAL#" for 999999
col USER for a15
col "Schema" for a15
col "OS Login" for a15
col module format a30
col "ConnectTime" for a21
col "PROGRAM" for a60
col SCHEMANAME for a12
col "TERMINAL" for a20
col process head "oraPID|APnode" for a6 trunc
col SPID head "OSpid|DBnode" for a6
col LastCallET head "LastCallEt|(hh:mi:ss)" format a11
col "DBSchema" for a12
col machine format a30
col "Sort_xtents" for a12
col "Sort_Blocks" for a12


accept trgtsid number default 0 prompt 'SID <ALL>: '
accept trgtoslogin char default ALL prompt 'OS Login <ALL>: '
accept trgtmachine char default ALL prompt 'Machine <ALL>: '
accept trgtmodule char default ALL prompt 'Module <ALL>: '
accept trgtschema char default ALL prompt 'DBSchema <ALL>: '
accept trgtstatus char default ALL prompt 'Status <ALL>: '

select S.SID, S.SERIAL#, s.MODULE, s.process, p.spid, s.OSUSER "OS Login", s.USERNAME "DBSchema", s.MACHINE, s.STATUS
     , nvl(to_char(u.extents),'null') "Sort_xtents", nvl(to_char(u.blocks),'null') "Sort_Blocks"
     , floor(s.LAST_CALL_ET/3600)||':'||floor(mod(s.LAST_CALL_ET,3600)/60)||':'||mod(mod(s.LAST_CALL_ET,3600),60) "LastCallET"
     , to_char(s.LOGON_TIME,'dd-Mon-yy hh:mm:ss AM') "ConnectTime"
     , s.SCHEMANAME, nvl(s.TERMINAL,'null') "TERMINAL", nvl(s.PROGRAM,'null') "PROGRAM"
from   v$session s, v$process p, sys.v_$sort_usage u
where (s.username = 'TOADREADER'  or  s.username = 'APPS_RO'  or  s.username = 'FRANCE_RO'
         or  s.osuser in ('symantec','LBOUTTEL')
         or  s.MODULE in ('TOAD' , 'T.O.A.D', 'ORACLE.exe' , 'al_engine.exe' , 'httpd.exe')
         or  s.MODULE like 'TOAD%'  or  s.MODULE like '%SQL%'
         or  s.PROGRAM like 'TOAD%'  or  s.PROGRAM like '%SQL%' or  upper(s.PROGRAM) like upper('%jupiter%')
         or  upper(s.MACHINE) = upper('jupiter'))
and    s.paddr = p.addr
and    s.saddr = u.session_addr(+)
and    (s.sid = &trgtsid or &trgtsid = 0)
and    (upper(s.SCHEMANAME) like upper('%&trgtschema%') or '&trgtschema' = 'ALL')
and    (upper(s.module) like upper('%&trgtmodule%') or '&trgtmodule' = 'ALL')
and    (upper(s.STATUS) = upper('&trgtstatus') or '&trgtstatus' = 'ALL')
and    (s.MACHINE like upper('%&trgtmachine%') or '&trgtmachine' = 'ALL')
and    (upper(s.OSUSER) like upper('%&trgtoslogin%') or '&trgtoslogin' = 'ALL')
order  by s.MODULE desc;
