set lines 200
set pages 0
accept objowner char default APPS prompt 'Who is the object owner <APPS> : '
accept objname char prompt 'What is the object name : '
accept objtype char prompt 'What is the object type : '
accept spoolfile char default plsql.prev prompt 'What is the spool file name <plsql.prev> : '
set verify off
set feedback off
spool &spoolfile
select text from dba_source
where owner = upper('&objowner')
and name = upper('&objname')
and type = upper('&objtype')
order by line;
spool off
