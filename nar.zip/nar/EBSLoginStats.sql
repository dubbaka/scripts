-- @EBSLoginStats.sql

clear columns breaks computes

set pages 50000 lines 2000 feed on head on echo on pau off timing on time on veri off trimspool on colsep |

col "MinDate" for a10
col "MaxDate" for a10
col "FromDate" for a10
col "ToDate" for a10
col "FndUsers" for 99999999
col "Logins" for 9999999999
col "UniqueLogins" for 9999999999
col "Language" for a10
col "Node" for a15
col "EbsLogin" for a30 trunc
col "0000-0059" for 9999999
col "0100-0159" for 9999999
col "0200-0259" for 9999999
col "0300-0359" for 9999999
col "0400-0459" for 9999999
col "0500-0559" for 9999999
col "0600-0659" for 9999999
col "0700-0759" for 9999999
col "0800-0859" for 9999999
col "0900-0959" for 9999999
col "1000-1059" for 9999999
col "1100-1159" for 9999999
col "1200-1259" for 9999999
col "1300-1359" for 9999999
col "1400-1459" for 9999999
col "1500-1559" for 9999999
col "1600-1659" for 9999999
col "1700-1759" for 9999999
col "1800-1859" for 9999999
col "1900-1959" for 9999999
col "2000-2059" for 9999999
col "2100-2159" for 9999999
col "2200-2259" for 9999999
col "2300-2359" for 9999999


prompt
prompt Total Number of EBS11i Users Created (FND_USER)
select count(1) "FndUsers"
from applsys.fnd_user 
where user_name not in ('AUTOINSTALL', 'WIZARD', 'OP_SYSADMIN', 'APPSMGR', 'CONCURRENT MANAGER', 'INITIAL SETUP', 'GUEST', 'ANONYMOUS')
and user_name not like 'XX%';


prompt Data is available in icx_sessions from:
select unique MODE_CODE from icx.icx_sessions;
select min(creation_date) "MinDate", max(creation_date) "MaxDate" from icx.icx_sessions;


prompt Run Dates
select trunc(sysdate-7) "FromDate", trunc(sysdate-1) "ToDate" from dual;


prompt
prompt EBS11i Users Logged in this week
select trunc(s.creation_date) "LoginDate", count(s.user_id) "Logins", count(distinct s.user_id) "UniqueLogins"
from icx.icx_sessions s
where s.mode_code = '115P'
and trunc(s.creation_date) >= trunc(SYSDATE-7)
and trunc(s.creation_date) <= trunc(SYSDATE-1)
group by trunc(s.creation_date);


prompt
prompt EBS11i Users Logged in this Week
select trunc(s.creation_date) "LoginDate", fu.USER_NAME "EbsLogin", count(s.user_id) "Logins"
from icx.icx_sessions s, applsys.fnd_user fu
where s.mode_code = '115P' 
and trunc(s.creation_date) >= trunc(SYSDATE-7)
and trunc(s.creation_date) <= trunc(SYSDATE-1)
and fu.user_id = s.user_id
group by trunc(s.creation_date), fu.USER_NAME;


prompt
prompt Total Number of EBS11i Users Logged in this Week by Day breakup every 4 Hours
select trunc(s.creation_date) "LoginDate", count(user_id) "Logins",
sum(decode(to_char(s.creation_date,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(s.creation_date,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(s.creation_date,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(s.creation_date,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(s.creation_date,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(s.creation_date,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(s.creation_date,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(s.creation_date,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(s.creation_date,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(s.creation_date,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(s.creation_date,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(s.creation_date,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(s.creation_date,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(s.creation_date,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(s.creation_date,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(s.creation_date,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(s.creation_date,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(s.creation_date,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(s.creation_date,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(s.creation_date,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(s.creation_date,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(s.creation_date,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(s.creation_date,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(s.creation_date,'hh24'),'23',1,0)) "2300-2359"
from icx.icx_sessions s
where s.mode_code = '115P'
and trunc(s.creation_date) >= trunc(SYSDATE-7)
and trunc(s.creation_date) <= trunc(SYSDATE-1)
group by trunc(s.creation_date);


prompt
prompt Total Number of Distinct EBS11i Users Logged in this Week
select trunc(creation_date) "LoginDate", count(distinct(user_id)) "Logins"
from icx.icx_sessions s
where mode_code = '115P' 
and trunc(s.creation_date) >= trunc(SYSDATE-7)
and trunc(s.creation_date) <= trunc(SYSDATE-1)
group by trunc(creation_date);


prompt
prompt Total Number of EBS11i Users Logged in this Week by OrgId
select trunc(creation_date) "LoginDate", ORG_ID, count(user_id) "Logins",
sum(decode(to_char(s.creation_date,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(s.creation_date,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(s.creation_date,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(s.creation_date,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(s.creation_date,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(s.creation_date,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(s.creation_date,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(s.creation_date,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(s.creation_date,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(s.creation_date,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(s.creation_date,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(s.creation_date,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(s.creation_date,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(s.creation_date,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(s.creation_date,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(s.creation_date,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(s.creation_date,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(s.creation_date,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(s.creation_date,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(s.creation_date,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(s.creation_date,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(s.creation_date,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(s.creation_date,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(s.creation_date,'hh24'),'23',1,0)) "2300-2359"
from icx.icx_sessions s
where mode_code = '115P'
and trunc(s.creation_date) >= trunc(SYSDATE-7)
and trunc(s.creation_date) <= trunc(SYSDATE-1)
group by trunc(creation_date), ORG_ID;


prompt
prompt Total Number of EBS11i Users Logged in this Week by Language
select trunc(s.creation_date) "LoginDate", l.NLS_LANGUAGE "Language", count(s.user_id) "Logins",
sum(decode(to_char(s.creation_date,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(s.creation_date,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(s.creation_date,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(s.creation_date,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(s.creation_date,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(s.creation_date,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(s.creation_date,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(s.creation_date,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(s.creation_date,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(s.creation_date,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(s.creation_date,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(s.creation_date,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(s.creation_date,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(s.creation_date,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(s.creation_date,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(s.creation_date,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(s.creation_date,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(s.creation_date,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(s.creation_date,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(s.creation_date,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(s.creation_date,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(s.creation_date,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(s.creation_date,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(s.creation_date,'hh24'),'23',1,0)) "2300-2359"
from icx.icx_sessions s, applsys.fnd_languages l
where s.mode_code = '115P'
and trunc(s.creation_date) >= trunc(SYSDATE-7)
and trunc(s.creation_date) <= trunc(SYSDATE-1)
and s.LANGUAGE_CODE = l.LANGUAGE_CODE
group by trunc(s.creation_date), l.NLS_LANGUAGE;


prompt
prompt Total Number of Distinct EBS11i Users Logged overall by Node
select n.NODE_NAME "Node", count(distinct(s.user_id)) "Logins", min(s.creation_date) "StartDate", max(s.creation_date) "EndDate"
from icx.icx_sessions s, applsys.fnd_nodes n
where s.mode_code = '115P'
and s.NODE_ID = n.NODE_ID
group by n.NODE_NAME;


prompt
prompt Total Number of EBS11i Users Logged in this week by Node breakup every 4 Hours
select trunc(s.creation_date) "LoginDate", n.NODE_NAME, count(s.user_id) "Logins",
sum(decode(to_char(s.creation_date,'hh24'),'00',1,0)) "0000-0059",
sum(decode(to_char(s.creation_date,'hh24'),'01',1,0)) "0100-0159",
sum(decode(to_char(s.creation_date,'hh24'),'02',1,0)) "0200-0259",
sum(decode(to_char(s.creation_date,'hh24'),'03',1,0)) "0300-0359",
sum(decode(to_char(s.creation_date,'hh24'),'04',1,0)) "0400-0459",
sum(decode(to_char(s.creation_date,'hh24'),'05',1,0)) "0500-0559",
sum(decode(to_char(s.creation_date,'hh24'),'06',1,0)) "0600-0659",
sum(decode(to_char(s.creation_date,'hh24'),'07',1,0)) "0700-0759",
sum(decode(to_char(s.creation_date,'hh24'),'08',1,0)) "0800-0859",
sum(decode(to_char(s.creation_date,'hh24'),'09',1,0)) "0900-0959",
sum(decode(to_char(s.creation_date,'hh24'),'10',1,0)) "1000-1059",
sum(decode(to_char(s.creation_date,'hh24'),'11',1,0)) "1100-1159",
sum(decode(to_char(s.creation_date,'hh24'),'12',1,0)) "1200-1259",
sum(decode(to_char(s.creation_date,'hh24'),'13',1,0)) "1300-1359",
sum(decode(to_char(s.creation_date,'hh24'),'14',1,0)) "1400-1459",
sum(decode(to_char(s.creation_date,'hh24'),'15',1,0)) "1500-1559",
sum(decode(to_char(s.creation_date,'hh24'),'16',1,0)) "1600-1659",
sum(decode(to_char(s.creation_date,'hh24'),'17',1,0)) "1700-1759",
sum(decode(to_char(s.creation_date,'hh24'),'18',1,0)) "1800-1859",
sum(decode(to_char(s.creation_date,'hh24'),'19',1,0)) "1900-1959",
sum(decode(to_char(s.creation_date,'hh24'),'20',1,0)) "2000-2059",
sum(decode(to_char(s.creation_date,'hh24'),'21',1,0)) "2100-2159",
sum(decode(to_char(s.creation_date,'hh24'),'22',1,0)) "2200-2259",
sum(decode(to_char(s.creation_date,'hh24'),'23',1,0)) "2300-2359"
from icx.icx_sessions s, applsys.fnd_nodes n
where s.mode_code = '115P'
and trunc(s.creation_date) >= trunc(SYSDATE-7)
and trunc(s.creation_date) <= trunc(SYSDATE-1)
and s.NODE_ID = n.NODE_ID
group by trunc(s.creation_date), n.NODE_NAME;

clear columns breaks computes
