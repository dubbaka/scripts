/* sidsort.sql
     see all the temp sort segments for a sid
*/
col sid format 999999
col tablespace format a10
col username format a25
col noexts format 9999 head EXTS
col proginfo format a30 trunc
set verify off
accept trgtsid num default 0 prompt 'What is the SID : '
select s.sql_hash_value sesshash,u.SQLHASH sorthash, s.username,
   u.tablespace,(u.blocks*p.value/1024/1024) mbused ,
   u.extents, s.module || ' - ' || s.program proginfo
from v$sort_usage u, v$session s, v$parameter p
where u.session_addr = s.saddr
and (s.sid = &trgtsid and &trgtsid > 0)
and p.name = 'db_block_size'
order by 1,4
/

