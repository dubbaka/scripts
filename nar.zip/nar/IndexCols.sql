-- @IndexCols.sql

clear columns breaks computes

set lines 200 pau off pages 40

break on index_name skip 1

col TABLE_OWNER for a15
col column_name format a30
col index_type  format a25 head TYPE
col uniqueness  format a10
col lastanal    format a15 head 'Last|Analyzed Date'
col pctanal     format 999 head PctAnalyzed

accept ndxname  char prompt 'What is the index name : '
accept tabname  char prompt 'What is the table name : '

select i.table_owner, i.table_name, i.index_name, column_position "Pos", c.column_name, uniqueness, i.index_type, i.status,
	to_char(i.last_analyzed,'mm/dd/yy hh24:mi') lastanal,
        nvl(sample_size,0)/decode(nvl(num_rows,1),0,1,nvl(num_rows,1)) * 100 pctanal
from  dba_indexes i, dba_ind_columns c
where (upper(i.index_name)  like upper('%&ndxname%')  or '&ndxname'  = 'ALL')
and   (upper(i.table_name)  like upper('%&tabname%')  or '&tabname'  = 'ALL')
and   i.table_owner = c.table_owner
and   i.table_name  = c.table_name
and   i.index_name  = c.index_name
order by index_name, column_position;
