-- @InvObjs.sql

clear columns breaks computes

col OWNER for a18
col OBJECT_NAME for a30
col Type for a30

set pages 300 lines 200

col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDMonYYYYhh24mi') "datenow" from dual;

select to_char(SYSDATE, 'dd-Mon-yy hh:mi:ss AM') "SystemDate" from dual;
select NAME from gv$database;

select count(1)
from   DBA_OBJECTS
where  status='INVALID';

select owner, replace(object_type,' ','_') Type, OBJECT_NAME, TIMESTAMP, status, to_char(LAST_DDL_TIME, 'dd-mon-yy hh24:mi:ss') LastDdlTime
from   DBA_OBJECTS
where  status = 'INVALID'
order  by TIMESTAMP desc;

select OBJECT_TYPE, COUNT(1) "Invalids"
from   DBA_OBJECTS
where  STATUS = 'INVALID'
group  by OBJECT_TYPE;

select owner, COUNT(1) "Invalids"
from   DBA_OBJECTS
where  STATUS = 'INVALID'
group  by owner;

select count(1)
from   DBA_OBJECTS
where  status = 'INVALID';
