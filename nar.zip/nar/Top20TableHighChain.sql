-- @Top20TableHighChain.sql
-- It is assumed Gather Schema stats are run on a regular basis


clear columns computes breaks

col TABLE_NAME for a30
col NUM_ROWS for 999,999,999,999
col EMPTY_BLOCKS for 999,999,999,999
col CHAIN_CNT for 999,999,999,999
col BUFFER_POOL for a12

select * from (
select TABLE_NAME, NUM_ROWS, EMPTY_BLOCKS, CHAIN_CNT, BUFFER_POOL
from   dba_tables
where  CHAIN_CNT > 0
order  by CHAIN_CNT desc)
where  rownum <= 20;
