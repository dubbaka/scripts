/* lclholder.sql
     see info about holders of a latch or all latches
	SDR-Oracle
*/
col name format a30 trunc head HoldingLatch
col sid format 99999
col pid format 99999
col username format a20 trunc
col event format a30 trunc head WaitingOn
col seconds_in_wait format 9999 head Seconds
col status format a1 trunc
col p1p2p3txt format a20 trunc
accept trgtlname char default ALL prompt 'Limit to which latch <ALL> : '
set verify off
select l.sid, l.pid, s.status, l.laddr, l.name, vw.event, 
	vw.p1 || ':' || vw.p2 || ':' || vw.p3 p1p2p3txt, 
	vw.seconds_in_wait, s.sql_hash_value
from v$session_wait vw, v$session s, v$latchholder l
where s.sid=l.sid
  and vw.sid=s.sid
  and (l.name='&trgtlname' or upper('&trgtlname') = 'ALL')
order by l.name, vw.seconds_in_wait desc;

