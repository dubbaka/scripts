set feed on pages 500 lines 300

set lines 1000 pages 30000

col user_concurrent_queue_name for a50 
col user_concurrent_program_name for a70

accept QueueName char default ALL        prompt  'Queue/ Manager Name   <ALL>: '
accept FullConcPgm char default ALL      prompt  'Program Name          <ALL>: '

select a.user_concurrent_queue_name, b.user_concurrent_program_name, c.include_flag
from fnd_concurrent_queues_vl a, fnd_concurrent_programs_tl b, fnd_concurrent_queue_content c
where c.type_id = b.concurrent_program_id
and c.concurrent_queue_id = a.concurrent_queue_id
--and b.language='US'
and c.type_code='P'
and ( a.user_concurrent_queue_name Like '&QueueName%' or upper('&QueueName') = 'ALL')
and (b.user_concurrent_program_name like '&FullConcPgm%' or '&FullConcPgm' = 'ALL')
order by 1,3,2;

