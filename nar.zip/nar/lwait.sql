col name format a30 head LatchName
col machine format a10 trunc
col module format a15 trunc
set lines 132
select w.sid,w.p2,n.name,w.p3 , s.module,s.machine, s.sql_hash_value
from v$session_wait w,v$latchname n, v$session s
 where w.event = 'latch free'
and w.p2 = n.latch#
and w.sid = s.sid
and wait_time = 0
/
