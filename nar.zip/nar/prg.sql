-- @ConcPgm.sql


clear columns breaks compute

col "ConcPgm" for a90

accept ShrtConcPgm char default ALL prompt 'What is the ShortName of ConcPgm <ALL> : '
accept FullConcPgm char default ALL prompt 'What is the Longname  of ConcPgm <ALL> : '

select c.concurrent_program_name, c2.user_concurrent_program_name "ConcPgm"
from   APPLSYS.fnd_concurrent_programs c , APPLSYS.fnd_concurrent_programs_tl c2
where (c.concurrent_program_name = '&ShrtConcPgm' or '&ShrtConcPgm' = 'ALL')
and   (c2.user_concurrent_program_name like '%&FullConcPgm%' or '&FullConcPgm' = 'ALL')
and    c2.concurrent_program_id = c.concurrent_program_id
and    c2.language = 'US';

clear columns breaks compute



