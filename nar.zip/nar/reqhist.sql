accept FullConcPgm char   default ALL         prompt 'Conc Pgm LongName    : '

select run_date, sum(run_count), min(min_run_time), avg(avg_run_time), max(max_run_time)
from cm_request_stats
where sysdate - run_date < 30
and REQUEST_NAME like '&FullConcPgm%'
group by run_date
/