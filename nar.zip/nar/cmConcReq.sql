-- @cmConcReq.sql
-- Script to summarise Concurrent Job activity

clear columns breaks compute

set feed off
col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDMonYY') "datenow" from dual;

set time on timing on feedback on pagesize 1000 linesize 100

col "RunDate" for a12
col num_req for 999,999,999 head "Requests"

spool spool\mzConcReq_&_MyDB1.


prompt PART 1 : List last 7days Conc Job summary by day
select to_char(actual_start_date, 'DD-MON-RR') "RunDate", count(1) num_req
from   fnd_concurrent_requests
where  trunc(actual_start_date) >= trunc(sysdate - 7)
group  by cube(to_char(actual_start_date, 'DD-MON-RR'));


prompt PART 2 : List last 7days job summary by hour
select to_char(actual_start_date, 'DD-MON-RR HH24') "RunDate", count(1) num_req
from   fnd_concurrent_requests
where  trunc(actual_start_date) >= trunc(sysdate - 7)
group  by cube(to_char(actual_start_date, 'DD-MON-RR HH24'));


prompt PART 3 : List last 24 hours jobs summary by hour
select to_char(actual_start_date, 'DD-MON-RR HH24') "RunDate", count(1) num_req
from   fnd_concurrent_requests
where  trunc(actual_start_date) >= trunc(sysdate - 1)
group  by cube(to_char(actual_start_date, 'DD-MON-RR HH24'));


accept tgtDate char default &_MyDateNow prompt 'Date DDmonyy <&_MyDateNow>: '

prompt PART 4 : List jobs summary by hour for a specific date
select to_char(actual_start_date, 'DD-MON-RR HH24') "RunDate", count(1) num_req
from   fnd_concurrent_requests
where  to_char(actual_start_date, 'ddmonyy') = '&tgtDate'
group  by cube(to_char(actual_start_date, 'DD-MON-RR HH24'));


prompt PART 5 : List Conc Job summary for a specific date
select to_char(actual_start_date, 'DD-MON-RR') "RunDate", count(1) num_req
from   fnd_concurrent_requests
where  to_char(actual_start_date, 'ddmonyy') = '&tgtDate'
group  by cube(to_char(actual_start_date, 'DD-MON-RR'));


spool off
