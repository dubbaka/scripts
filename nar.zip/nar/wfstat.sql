set linesize 140
col CONTAINER_NAME for a28
col PROCID for 999999
col PROCID for a10
col TARGET for a6
col TARGET for 999
col ACTUAL for a6
col ACTUAL for 999
col ENABLED for a7
col COMPONENT_NAME for a30
col STARTUP_MODE for a12
col COMPONENT_STATUS for a17
select fcq.USER_CONCURRENT_QUEUE_NAME Container_Name,
DECODE(fcp.OS_PROCESS_ID,NULL,'Not Running',fcp.OS_PROCESS_ID) PROCID, fcq.MAX_PROCESSES TARGET,
fcq.RUNNING_PROCESSES ACTUAL,fcq.ENABLED_FLAG ENABLED,fsc.COMPONENT_NAME,fsc.STARTUP_MODE,
fsc.COMPONENT_STATUS from APPS.FND_CONCURRENT_QUEUES_VL fcq, APPS.FND_CP_SERVICES fcs, APPS.FND_CONCURRENT_PROCESSES fcp,
apps.fnd_svc_components fsc where fcq.MANAGER_TYPE = fcs.SERVICE_ID and fcs.SERVICE_HANDLE = 'FNDCPGSC'
and fsc.concurrent_queue_id = fcq.concurrent_queue_id(+) and fcq.concurrent_queue_id = fcp.concurrent_queue_id(+)
and fcq.application_id = fcp.queue_application_id(+) and fcp.process_status_code(+) = 'A'
and fcq.USER_CONCURRENT_QUEUE_NAME like '%Mail%' order by fcp.OS_PROCESS_ID, fsc.STARTUP_MODE
/

