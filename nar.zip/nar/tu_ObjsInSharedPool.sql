/* ObjsInSharedPool.sql
    List of all objects that are kept in the shared pool
*/

clear columns breaks computes

col owner for a10
col name for a30
col type for a20
col kept for a4
col "ObjectName" for a40

set verify off

--select owner, name, namespace, type, sharable_mem, loads, executions, locks, pins, kept, invalidations
--from   v$db_object_cache where kept='YES';

select substr(owner,1,10)||'.'||substr(name,1,35) "ObjectName", type, sharable_mem, loads, executions, kept
from   v$db_object_cache
where  type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and    executions >0
order  by executions desc, loads desc, sharable_mem desc;
