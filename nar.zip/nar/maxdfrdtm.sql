/* maxdfrdtm.sql
     show the top 10 max read time file stats by datafile
*/
set lines 132
col name head "File Name" format a40
col ufsmt noprint
col mbratio head RdRatio format 999.90
col avgrdtim format 9,999.90 
set verify off
clear breaks
rem accept trgtfs char default ALL prompt 'What filesystem mount point <all> : '
select * from (
 select substr(d.name,1,4) ufsmt,
        d.name,
        f.phyrds,
        f.phyblkrd,
        f.phyblkrd / decode(f.phyrds,0,1,f.phyrds) mbratio,
        f.readtim / decode(f.phyrds,0,1,f.phyrds) avgrdtim,
        f.maxiortm,
        f.phywrts,
        f.phyblkwrt,
        f.lstiotim
 from v$filestat f, v$datafile d
 where f.file# = d.file#
 order by 7 desc)
where rownum < 11;


