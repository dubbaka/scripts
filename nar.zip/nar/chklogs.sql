select GROUP#,SEQUENCE#,ARCHIVED,STATUS from v$log order by 2;

