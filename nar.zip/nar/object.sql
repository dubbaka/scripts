col owner format a15 trunc
col segment_name format a30 trunc
col tablespace_name format a15 trunc
select /*+ rule */ owner,segment_name,segment_type,tablespace_name
from dba_extents
where file_id = &fileid
and &blockid between block_id and (block_id + blocks -1)
/

