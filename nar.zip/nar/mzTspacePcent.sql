REM
REM        START OF SQL
REM
REM  Filename     : mzTspacePcent.sql
REM  Author       : Mike Shaw
REM  Date Updated : 27 March 2007
REM  Purpose      : Script to show tablespace usage summary
REM
set serveroutput on
set echo on
set timing on
set feedback on
set long 10000
set pagesize 132
set linesize 80
column tspace_name format a21
column Pcent_Free format 99.9
column MB_Free format 999,999
column MB_Total format 999,999
--
-- spool tspace.txt
--
select z.tablespace_name tspace_name, 
(select sum(b.bytes)/(1024*1024) from dba_free_space b where b.tablespace_name = z.tablespace_name) MB_Free,
(select sum(a.bytes)/(1024*1024) from dba_data_files a where a.tablespace_name = z.tablespace_name) MB_Total,
((select sum(b.bytes)/(1024*1024) from dba_free_space b where b.tablespace_name = z.tablespace_name)/(select sum(a.bytes)/(1024*1024) from dba_data_files a where a.tablespace_name = z.tablespace_name)*100) Pcent_Free
from dba_tablespaces z
order by z.tablespace_name
/
-- spool off
REM 
REM        END OF SQL
REM 
