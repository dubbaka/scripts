/*$Header: bde_wf_process_tree.sql 11.5.1                         03-Nov-2003 */

/*
 TITLE bde_wf_process_tree.sql
 
 DESCRIPTION

	This Script will prompt for an Item Type (value 1) and and Item Key (value 2)
	It will recursively find the ROOT Item Type and Item Key and then display all
	the Child Processes in a tree-structured output to easily identify
	where each process is called.  The Begin and End dates are included.
  
  	This will help explain WHY an item type is not being purged.                                                 */
  	All processes must have an END_DATE in order to be available for PURGE.                                           */

 EXECUTION

	Run the script from a SQL*Plus session logged in as the APPS user.  
	The script accepts an ITEM_TYPE and ITEM KEY.  
	The output spools to a file called bde_wf_process_tree.lst in the current directory. 

 NOTES

 	The output can be FTP'd to a PC and then loaded into wordpad.  
 	Go to Page Setup and select Landscape as the Paper Size.
 	Modify all 4 Margins to "0.5" inches.
 	Select all your document (Ctrl-A) and use Format Font to change the current
 	font to Courier or New Courier 8.  
 	With all your document selected (Ctrl-A) use Format Parragraph to set both
 	Before and After Spacing to 0.  It comes with null causing a one line 
 	spacing between lines.

 IMPORTANT
	 Please read Notes 144806.1 and 132254.1 for more information on WF_PURGE.

 DISCLAIMER 
 
 This script is provided for educational purposes only.  It is not supported 
 by Oracle World Wide Technical Support.  The script has been tested and 
 appears to works as intended.  However, you should always test any script 
 before relying on it. 
 
 Proofread this script prior to running it!  Due to differences in the way text 
 editors, email packages and operating systems handle text formatting (spaces, 
 tabs and carriage returns), this script may not be in an executable state 
 when you first receive it.  Check over the script to ensure that errors of 
 this type are corrected. 

 This script can be given to customers.  Do not remove disclaimer paragraph.

 HISTORY 
 
 Created by Bill Burbage and Gustavo Jimenez, Nov 3, 2003.

*/

set serveroutput on
set define on

spool bde_wf_process_tree.lst

declare


        /* Declaration of variables */
        cr_lf varchar2(2) :='
'; /* line broken intentionally */
        procname varchar2(200) := 'main';
        
        /* Set this variable to True if you want a debug output */
        debug_flag boolean := false;

        /* This type will hold the item_type/item_key pair */
        type item is record (
        
                item_type       wf_items.item_type%TYPE,
                item_key        wf_items.item_key%TYPE
        
        );

        /* variable definition for the main program */
        tmp_item item;
        root_parent item;
        my_item item;


        /* wrapper for dbms_output.put_line */
        procedure print (x varchar2) is
        
        begin
        
                dbms_output.put_line(x);
                
        end print;

        /* to build a string in the format <item_type>:<item_key> */    
        function encodeItem(i item) return varchar2 is
        begin   
                return(i.item_type || ':' || i.item_key);
                
        end encodeItem; 

        /* output of an item */
        procedure showItem(i item) is   
        begin   
                print(encodeItem(i));
                
        end showItem;   

        /* to determine if a given item has children items */
        function hasChildren(i item) return boolean is
        
                totalChildren number;
                procname varchar2(200) := 'hasChildren';
        begin   

                if (debug_flag) then
                        print('entering ' || procname);
                end if;
                
                select count(*) into totalChildren
                from WF_ITEMS
                where parent_item_type = i.item_type
                and parent_item_key = i.item_key;
                
                if totalChildren > 0 then
                        if (debug_flag) then
                                print('exiting(true) ' || procname);
                        end if;         
                        return true;                    
                else
                        if (debug_flag) then
                                print('exiting(false) ' || procname);
                        end if;
                        return false;
                        
                end if;

        end hasChildren;        

        /* used to determine if a given item has a parent item */       
        function hasParent(i item) return boolean is
        
                ParentCount number;
                procname varchar2(200) := 'hasParent';
        begin   

                if (debug_flag) then
                        print('entering ' || procname);
                end if;
                select count(*) into parentCount
                from WF_ITEMS
                where   item_type = i.item_type
                and     item_key= i.item_key
                and parent_item_type is not null
                and parent_item_key is not null;
                
                if parentCount > 0 then
                        if (debug_flag) then
                                print('exiting(true) ' || procname);
                        end if;
                        return true;
                        
                else
                        if (debug_flag) then
                                print('exiting(false) ' || procname);
                        end if;         
                        return false;
                        
                end if;

        end hasParent;


        /* used to get the item parent of an item */    
        function getParent(i item) return item is 

                procname varchar2(200) := 'getParent';          
                itk item;
                tmpbuff varchar2(200); 

        begin

                if (debug_flag) then
                        print('entering ' || procname);
                end if;         

                if hasParent(i) then            

                        select  PARENT_ITEM_TYPE, PARENT_ITEM_KEY
                        into itk
                        from    WF_ITEMS
                        where   ITEM_TYPE = i.item_type
                        AND     ITEM_KEY  = i.item_key;

                else

                        itk.item_type := i.item_type;
                        itk.item_key := i.item_key;
                end if;

                return itk;

                if (debug_flag) then
                        print('exiting() ' || procname);
                end if;         

        
        end getParent;  

        /* used to print out the Super item */
        procedure printRootProcess(itk item) is
                
                div varchar2(3) := ' | ';
                procname varchar2(200) := 'printRootProcess';

                cursor getData(i item) is
                        select 
                             ITM.ITEM_TYPE                      ITEM_TYPE 
                            ,ITM.ITEM_KEY                       ITEM_KEY  
                            ,nvl(to_char(ITM.BEGIN_DATE,'DD-MON-RR HH24:MI:SS'), 'N/A') BEGIN_DATE 
                            ,nvl(to_char(ITM.END_DATE,'DD-MON-RR HH24:MI:SS'),'N/A')  END_DATE 
                        from 
                            WF_ITEMS               ITM 
                        where 
                                ITM.ITEM_TYPE = i.item_type
                            AND ITM.ITEM_KEY  = i.item_key;
        
        begin
        
                if (debug_flag) then
                        print('Inside ' || procname);
                end if; 
        
                for x in getData(itk) loop
                        dbms_output.put_line('> + ' ||x.ITEM_TYPE|| ':' || x.ITEM_KEY|| div || 'Root Process' || div || 'SD:' || x.BEGIN_DATE || div || 'ED:' ||x.END_DATE);
                end loop;
                
                if (debug_flag) then
                        print('Exiting ' || procname);
                end if;

        
        end printRootProcess;


        /* used to get the super parent of an item */
        function getSuperParentProcess(itk item) return item is
        
                tmp_item item;
                root_parent item;
                procname varchar2(200) := 'getProcessSuperParent';
        
        begin
                if (debug_flag) then
                        print('entering ' || procname);
                end if;
                tmp_item.item_type := '';
                tmp_item.item_key := '';
                root_parent := itk;             
                
                if hasParent(root_parent) then
                
                        loop

                                /* get the parent it/ik for the current it/ik */

                                tmp_item := getParent(root_parent);
                                if(debug_flag) then
                                        showItem(tmp_item);
                                end if;
                                if ((tmp_item.item_type = root_parent.item_type) and (tmp_item.item_key = root_parent.item_key))then
                                        exit;
                                end if;
                                
                                root_parent := tmp_item;
                                /* 
                                if (root_parent.item_type=tmp_item.item_type and root_parent.item_key=tmp_item.item_key) then 
                                        exit;
                                end if;
                                */

                                --counter := counter + 1;
                                --tmpstr := tmpbuff;

                                -- root_parent.item_type := tmp_item.item_type;
                                -- root_parent.item_key := tmp_item.item_key;
                                -- dbms_output.put_line(root_parent.item_type || ':' || root_parent.item_key);

                        end loop;
                        if (debug_flag) then
                                print('exiting() ' || procname);
                        end if;                         
                        return tmp_item;
                        
                else                    
                        if (debug_flag) then
                                showItem(itk);
                                print('exiting() ' || procname);
                        end if;
                        return itk;
                        
                end if;         

                if (debug_flag) then
                        print('exiting ' || procname);
                end if;         

        end getSuperParentProcess;

        /* used to get and print out all the children items of an item */       
        procedure getAllChildren(StartItem item, indent varchar2 default null) is
        
                procname varchar2(200) := 'getAllChildren';
                div varchar2(3) := ' | ';
                total_indent varchar2(200);
                current_item item;
                
                cursor getChildren(myItem item) is
                select 
                     ITM.ITEM_TYPE                      ITEM_TYPE 
                    ,ITM.ITEM_KEY                       ITEM_KEY 
                    ,ITM.PARENT_ITEM_TYPE               PRNT_TYPE 
                    ,ITM.PARENT_ITEM_KEY                PRNT_KEY 
                    ,nvl(to_char(ITM.BEGIN_DATE,'DD-MON-RR HH24:MI:SS'), 'N/A') BEGIN_DATE 
                    ,NVL(to_char(ITM.END_DATE,'DD-MON-RR HH24:MI:SS'),'N/A') END_DATE 
                from 
                    WF_ITEMS               ITM 
                where 
                        ITM.PARENT_ITEM_TYPE = myItem.item_type
                    AND ITM.PARENT_ITEM_KEY  = myItem.item_key;
            
        begin

                if (debug_flag) then
                        print('entering ' || procname);
                end if; 
                
                /* indentation for different levels */
                if (indent is null) then
                        total_indent := '|---+ ';
                else
                        total_indent := '|   ' || indent;
                end if;
                
                for x in getChildren(StartItem) loop

                        --dbms_output.put_line('Getting Children');
                        dbms_output.put_line('> ' || total_indent || 
                                                x.ITEM_TYPE|| ':' || x.ITEM_KEY|| div || 
                                                'Parent:' || x.PRNT_TYPE|| ':' || x.PRNT_KEY || 
                                                div || 'BD:' || 
                                                x.BEGIN_DATE || div || 'ED:'||x.END_DATE);
                        current_item.item_type := x.item_type;
                        current_item.item_key := x.item_key;
                        if hasChildren(current_item) then
                                getAllChildren(current_item, total_indent);
                        end if;

                end loop;
                if (debug_flag) then
                        print('exiting ' || procname);
                end if;         

        end getAllChildren;

        /* Used to determine if an item type/item key combination is a valid item */    
        function isProcess(i item) return boolean is
        
                procname varchar2(200) := 'getAllChildren';
                result boolean; 
                numberOfProcesses number;
        begin
                if (debug_flag) then
                        print('entering ' || procname);
                end if;         
                select count(*)
                into numberOfProcesses
                from wf_items
                where item_type = i.item_type
                and item_key = i.item_key;
                
                if (numberOfProcesses = 0) then
                        if (debug_flag) then
                                print('exiting(false) ' || procname);
                        end if; 
                        return false;
                else 
                        if (debug_flag) then
                                print('exiting(true) ' || procname);
                        end if; 
                        return true;
                end if;
                
        end isProcess;
                

begin

        /* Start of the main block */

        /* Enable the output for a large output */

        if (debug_flag) then
                print('entering ' || procname);
        end if;         
        
        dbms_output.enable(2000000);
        print(cr_lf);
        print('-----------------');
        print('Starting analysis');
        print('-----------------');


        /* Get the item_type/item_key from the user */  
        my_item.item_type := upper('&Item_Type');
        my_item.item_key := upper('&Item_Key');

        /* Does the process exist ? */  
        if (isProcess(my_item)) then
        
                /* Yes, the process exists */

                /* We have to get the Super Parent Process first */
                root_parent := getSuperParentProcess(my_item);

                /* if the root_parent ends up being the same item I entered, then a superparent process was entered */
                if ((my_item.item_type = root_parent.item_type) and (my_item.item_key = root_parent.item_key)) then
                
                        print('Process ' || encodeItem(root_parent) || ' has no known parents or it has been orphaned');
                        
                end if; 


                /* let everybody know who the parent is */
                print(cr_lf || 'Root parent activity : ' || encodeItem(root_parent) || cr_lf || cr_lf);

                /* display the rootProcess */
                printRootProcess(root_parent);
                
                /* let's grab all the children and print them out */
                getAllChildren(root_parent);
                print(cr_lf);
                
        else 
        
                /* Hmmm... there is no such item */
                
                print('Process : ' || encodeItem(my_item) || ' does not exist.');
                
        end if;

        print('Done.');

        if (debug_flag) then
                print('exiting ' || procname);
        end if; 

end;
/


spool off
