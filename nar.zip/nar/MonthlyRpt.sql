-- @MonthlyRpt.sql


col phase_code               for a1
col parent                   for a8
col "BlockSize"              for a9
col PARTITIONED              for a12
col module                   for a15
col "Requestor"              for a15
col "Schedule"               for a15
col reqstart                 for a15 head "RequestStart|Date(24hr fmt)"
col actstart                 for a15 head "ActualStart|Date(24hr fmt)"
col EXTENT_MANAGEMENT        for a20 head "ExtentManagement"
col ALLOCATION_TYPE          for a20 head "AllocationType"
col  statustxt               for a20 head "Status"
col "LastAnalyzed"           for a22
col oldestDate               for a22
col newestDate               for a22
col SEGMENT_SPACE_MANAGEMENT for a22 head "SegmentSpaceManagement"
col owner                    for a25 head "Owner"
col table_owner              for a25 head "TableOwner"
col name                     for a30 head "Name"
col table_name               for a30 head "Table"
col index_name               for a30 head "Index"
col object_type              for a30
col object_name              for a30 head "Object"
col SUBOBJECT_NAME           for a30
col iot_name                 for a30 head "IOT"
col tablespace_name          for a30 head "Tablespace"
col segment_type             for a30 head "SegmentType"
col segment_name             for a30 head "SegmentName"
col event                    for a40 head "Event"
col EMAIL_ADDRESS            for a50
col FILENAME                 for a60 head "FileName"
col FILE_NAME                for a60 head "FileName"
col program                  for a60
col "Description"            for a60 head "Username"
col omega1                   for 0.999          heading 'Omega1'
col MIN_EXTENTS              for 999            head "MinExtents"
col PCT_INCREASE             for 999.9          head "%Inc"
col txwaits                  for 9999.0         head 'Waits/txn';
col "%Used"                  for 999.99
col "%Free"                  for 999.99
col pctavailblks             for 999.90         head "% of Avail"
col wt                       for 99,990         head 'Avgwait(ms)'
col kount                    for 99,999         head 'Chunks'  
col chains                   for 999,990        head 'Chains'
col blkcnt                   for 999,999 
col "Created(MB)"            for 999,999
col "GROWTH(MB)"             for 999,999
col "AvgGrowthGB/Mth"        for 999.99
col "Growth(MB)"             for 9,999,999.99
col "Size(GB)"               for 9,999,999.99
col "Used(GB)"               for 9,999,999.99
col "Free(GB)"               for 9,999,999.99
col touches                  for 9,999,999
col INITIAL_EXTENT           for 999,999,999    head "InitExtent"
col NEXT_EXTENT              for 999,999,999    head "NextExtent"
col min_extlen               for 999,999,999
col extents                  for 999,999,999
col mxfrag                   for 999,999,990    head 'LargestFrag(KB)'
col totsiz                   for 999,999,990    head 'Total(KB)'
col avasiz                   for 999,999,990    head 'Available(KB)' 
col nfrags                   for 999,999,990    head 'FreeFrags'
col exts                     for 999,999,999    head 'Exts'
col time                     for 9,999,999,990  head "TotalWaitTime(s)"
col MAX_EXTENTS              for 9,999,999,999  head "MaxExtents"
col waits                    for 9,999,999,990
col timeouts                 for 9,999,999,990
col num_rows                 for 9,999,999,999
col "Blocks"                 for 99,999,999,999
col pyr                      for 99,999,999,999 head 'PhysicalReads'  
col pw                       for 99,999,999,999 head 'PhysicalWrites'  
col pbr                      for 99,999,999,999 head 'PhysicalBlksRead'  
col pbw                      for 99,999,999,999 head 'PhysicalBlksWrtn'  
col rdti                     for 99,999,999,999 head 'ReadTime'  
col writ                     for 99,999,999,999 head 'WriteTime'
col bwts                     for 99,999,999,999 head 'BufferWaits'
col bwtim                    for 99,999,999,999 head 'BufferWaitTime(ms)'
col tbytes                   for 99,999,999,999 head 'TotalBytes'  
col fbytes                   for 99,999,999,999 head 'FreeBytes'  
col "CREATED_DATE"           for a20 head "Created Date"
col "LastDDLTime"            for a20 head "Last Modified"

set pages 50000 lines 800 pau off

col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDMonYYYYhh24miss') "datenow" from dual;

prompt Summary Stats
@dbsize
@sga
select count(1) from dba_tablespaces;
@dbrows
@ObjCnt

-- Operating Units = select count(1) from hr_operating_units;
-- Set of Books = select num_rows from dba_tables where table_name = upper('gl_sets_of_books');
-- AR invoices = select num_rows from dba_tables where table_name = upper(ra_customer_trx_all');
-- AR invoice lines = select num_rows from dba_tables where table_name = upper(ra_customer_trx_lines_All');
-- AP invoices = select num_rows from dba_tables where table_name = upper(ap_invoices_all');
-- GL Lines = select num_rows from dba_tables where table_name = upper(gl_je_lines');
-- Sales Orders = select num_rows from dba_tables where table_name = upper(oe_order_headers_all');
-- Sales Order Lines = select num_rows from dba_tables where table_name = upper(oe_order_lines_all');
-- WF Items = select num_rows from dba_tables where table_name = 'WF_ITEMS';
-- WF Notifications = select num_rows from dba_tables where table_name = 'WF_NOTIFICATIONS';
-- WF Item Attributes = select num_rows from dba_tables where table_name = 'WF_ITEM_ATTRIBUTE_VALUES';
-- WF Item Activity Status = select num_rows from dba_tables where table_name = 'WF_ITEM_ACTIVITY_STATUSES';
-- WF Deferred = select num_rows from dba_tables where table_name = 'WF_DEFERRED';


prompt Database Growth report
col "YEAR" new_value _MyYear noprint
col "Month" new_value _MyMth noprint
col "YEAR-MONTH" for a10
spool spool\MonthlyRpt_DBGrowth_&_MyDateNow._&_MyDB1.
select to_char(creation_time, 'RRRR') "YEAR", sum(bytes)/(1024*1024*1024)/count(unique to_char(creation_time, 'Mon')) "AvgGrowthGB/Mth"
from   sys.v_$datafile
where  to_char(creation_time, 'RRRR') = '&year'
group  by to_char(creation_time, 'RRRR');

select to_char(creation_time, 'RRRR') "YEAR"
     , decode(to_char(creation_time, 'Mon'), 'Jan',1, 'Feb',2, 'Mar',3, 'Apr',4, 'May',5, 'Jun',6, 'Jul',7, 'Aug',8, 'Sep',9, 'Oct',10, 'Nov',11, 'Dec',12) "Month"
     , to_char(creation_time, 'RRRR-Mon') "YEAR-MONTH", count(1) "DBFsContributing2Growth", sum(CREATE_BYTES)/(1024*1024) "Created(MB)", sum(bytes)/(1024*1024) "GROWTH(MB)"
, sum(bytes)/(1024*1024*1024)/count(unique to_char(creation_time, 'Mon')) "AvgGrowthGB/Mth"
from   sys.v_$datafile
group  by to_char(creation_time, 'RRRR') , to_char(creation_time, 'Mon') , to_char(creation_time, 'RRRR-Mon')
order  by "YEAR", "Month";
spool off


col "DB Size in GB" for 9,999,999.99

-- Get the Total number of files
select sum(cnt1) "Total Files in DB"
from (
select count(1) as cnt1 from dba_data_files 
union
select count(1) as cnt1 from dba_temp_files 
union
select count(1) as cnt1 from v$logfile 
union
select count(1) as cnt1 from v$controlfile);

col "Ordr" new_value _Ordr noprint
   select 1 "Ordr", 'DBFs='||count(1) as cnt1    from dba_data_files
   union
   select 2 "Ordr", 'Tempfile='||count(1) as cnt1    from dba_temp_files
   union
   select 3 "Ordr", 'Redologs='||count(1) as cnt1    from v$logfile    where TYPE != 'STANDBY'
   union
   select 4 "Ordr", 'Ctrlfiles='||count(1) as cnt1    from v$controlfile
   order  by "Ordr";


-- Get the DB Size excluding ctrl files
select sum("SizeGB") "DB Size in GB"
from (
select sum(bytes/(1048576*1024)) "SizeGB" from dba_data_files 
union
select sum(bytes/(1048576*1024)) "SizeGB" from dba_temp_files 
union
select sum(bytes/(1048576*1024)) "SizeGB" from v$log          
union
select sum((record_size * records_total)/(1048576*1024)) "SizeGB" from v$controlfile_record_section
     );


prompt
prompt Object Wise count stats in the database
spool spool\MonthlyRpt_ObjsByOwner_&_MyDateNow._&_MyDB1.
prompt Total Objects in the database
select count(1) from dba_objects;
prompt Object count by Owner
select owner, count(1) from dba_objects group by owner;
prompt Object Type counts
select object_type, count(1) from dba_objects group by object_type;
select owner, object_type, count(1) from dba_objects group by owner, object_type;
spool off

spool spool\MonthlyRpt_Objects_&_MyDateNow._&_MyDB1.
select owner, object_type, object_name, nvl(SUBOBJECT_NAME,'null'), to_char(CREATED,'dd-Mon-yy hh24:mi:ss') "CREATED_DATE"
     , nvl(to_char(LAST_DDL_TIME,'dd-Mon-yy hh24:mi:ss'),'null') "LastDDLTime", nvl(TIMESTAMP,'null'), STATUS, TEMPORARY, GENERATED, SECONDARY
from   dba_objects
where  owner not in ('SYS' , 'PUBLIC' , 'SYSTEM')
and    object_type not in ('JAVA CLASS' , 'JAVA SOURCE' , 'SYNONYM', 'TYPE');
spool off

prompt Archive Log Generation Report
@archsum_bob.sql
@archsum_fob.sql


prompt Top 5 Timed Events
prompt Cumulative System Wait events report by total_waits
spool spool\MonthlyRpt_TopWaitEvents_&_MyDateNow._&_MyDB1.
select b.event , b.total_waits waits , b.total_timeouts timeouts
     , nvl(b.time_waited_micro,0)/1000000 time
     , decode (nvl(b.total_waits, 0), 0, to_number(NULL), nvl(b.time_waited_micro,0)/1000) / nvl(b.total_waits,0) wt
     , decode(i.event, null, 0, 99) idle
from   v$system_event b , perfstat.stats$idle_event   i
where  b.event    not in ('smon timer','pmon timer','dispatcher timer','dispatcher listen timer')
and    b.event    not like 'rdbms ipc%'
and    i.event(+) = b.event
order  by b.total_waits;
spool off


prompt Tablespace Growth report
spool spool\MonthlyRpt_TBSGrowth_&_MyDateNow._&_MyDB1.
select A.name tablespace_name, count(1) "DBFsContributing2Growth", sum(B.bytes)/1048576 "Growth(MB)"
from   v$tablespace A, sys.v_$datafile B
where  A.TS# = B.TS#
group  by A.name;
spool off


prompt Top Tablespaces of Size greater than 50MB
spool spool\MonthlyRpt_TBSGT5MB_&_MyDateNow._&_MyDB1.
SELECT  dts.tablespace_name, NVL(ddf.bytes/(1073741824), 0) "Size(GB)", NVL(ddf.bytes-NVL(dfs.bytes,0),0)/(1073741824) "Used(GB)"
      , NVL(dfs.bytes/(1073741824), 0) "Free(GB)", (NVL(ddf.bytes,0)-NVL(dfs.bytes,0))/NVL(ddf.bytes,1)*100 "%Used"
      , NVL(dfs.bytes,0)/NVL(ddf.bytes,1)*100 "%Free"
      , (BLOCK_SIZE/1024)||'K' "BlockSize", INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, STATUS
      , LOGGING, EXTENT_MANAGEMENT, ALLOCATION_TYPE, SEGMENT_SPACE_MANAGEMENT
FROM    sys.dba_tablespaces dts, 
       (select tablespace_name, sum(bytes) bytes from dba_data_files group by tablespace_name) ddf, 
       (select tablespace_name, sum(bytes) bytes from dba_free_space group by tablespace_name) dfs 
WHERE  dts.tablespace_name = ddf.tablespace_name(+) 
AND    dts.tablespace_name = dfs.tablespace_name(+)
AND    NVL(ddf.bytes/(1024*1024), 0) >= 50;
spool off


prompt Object by Tablespace
spool spool\MonthlyRpt_ObjByTbs_&_MyDateNow._&_MyDB1.
col "Segments" for 999999999
select TABLESPACE_NAME, OWNER, SEGMENT_TYPE, count(1) "NumSegments", sum(BYTES/(1024*1024)) "MB"
from   DBA_SEGMENTS
group  by TABLESPACE_NAME, OWNER, SEGMENT_TYPE
order  by TABLESPACE_NAME, OWNER, SEGMENT_TYPE;

select TABLESPACE_NAME, OWNER, SEGMENT_TYPE, SEGMENT_NAME, BYTES/(1024*1024) "MB", PARTITION_NAME
from   DBA_SEGMENTS
order  by TABLESPACE_NAME, OWNER, SEGMENT_TYPE, SEGMENT_NAME;
spool off


prompt Top Tablespaces by IO statistics ex: reads, writes, BufferWaits etc
spool spool\MonthlyRpt_TBSIO_&_MyDateNow._&_MyDB1.
select tsname TABLESPACE_NAME, sum(phyrds) pyr, sum(phywrts) pw, sum(phyblkrd) pbr
     , sum(phyblkwrt) pbw, sum(READTIM) rdti, sum(WRITETIM) writ, sum(wait_count) bwts, sum(TIME) bwtim
from   v$filestatxs
group  by tsname;
spool off


prompt Tablespace Fragmentation report
REM    The following is a script that will determine how many extents of contiguous free space you have in Oracle as well as the  
REM    total amount of free space you have in each tablespace. From these results you can detect how fragmented your tablespace is.  
REM    The ideal situation is to have one large free extent in your tablespace. The more extents of free space there are in the  
REM    tablespace, the more likely you  will run into fragmentation problems. The size of the free extents is also  very important.  
REM    If you have a lot of small extents (too small for any next extent size) but the total bytes of free space is large, then  
REM    you may want to consider defragmentation options.
spool spool\MonthlyRpt_TbsFragmentation_&_MyDateNow._&_MyDB1.
prompt This looks at Tablespace Sizing - Total bytes and free bytes  
prompt A large number of Free Chunks indicates that the tablespace may need  
prompt to be defragmented and compressed.  
prompt  
select a.tablespace_name, a.bytes tbytes, sum(b.bytes) fbytes, count(1) kount
from   dba_data_files a,  dba_free_space b
where  a.file_id  =  b.file_id
group  by a.tablespace_name, a.bytes;

select total.tablespace_name, count(free.bytes) nfrags, nvl(max(free.bytes)/1024,0) mxfrag
    ,  total.bytes/1024 totsiz, nvl(sum(free.bytes)/1024,0) avasiz, (1-nvl(sum(free.bytes),0)/total.bytes)*100 "%Used"
from   dba_data_files  total,   dba_free_space free 
where  total.tablespace_name = free.tablespace_name(+)
and    total.file_id=free.file_id(+)
group  by  total.tablespace_name, total.bytes;
spool off


prompt Top Database files by IO statistics ex: reads, writes, BufferWaits etc
spool spool\MonthlyRpt_DBFsIO_&_MyDateNow._&_MyDB1.
select df.TABLESPACE_NAME, sum(fs.phyrds) pyr, sum(fs.phywrts) pw, sum(fs.phyblkrd) pbr, sum(fs.phyblkwrt) pbw, sum(fs.READTIM) rdti, sum(fs.WRITETIM) writ, sum(fs.SINGLEBLKRDS), sum(fs.SINGLEBLKRDTIM), min(fs.MINIOTIM), avg(fs.AVGIOTIM), max(fs.MAXIORTM), max(fs.MAXIOWTM)
from   v$filestat fs, dba_data_files df
where  df.FILE_ID = fs.file#
group  by df.TABLESPACE_NAME;

select df.TABLESPACE_NAME, df.FILE_NAME, fs.phyrds pyr, fs.phywrts pw, fs.phyblkrd pbr, fs.phyblkwrt pbw, fs.READTIM rdti, fs.WRITETIM writ, fs.SINGLEBLKRDS, fs.SINGLEBLKRDTIM, fs.AVGIOTIM, fs.LSTIOTIM, fs.MINIOTIM, fs.MAXIORTM, fs.MAXIOWTM
from   v$filestat fs, dba_data_files df
where  df.FILE_ID = fs.file#
group  by df.TABLESPACE_NAME;
spool off

spool spool\MonthlyRpt_TEMPIO_&_MyDateNow._&_MyDB1.
select df.tablespace_name, df.file_name, fs.phyrds pyr, fs.phywrts pw, fs.phyblkrd pbr, fs.phyblkwrt pbw, fs.READTIM rdti, fs.WRITETIM writ, df.bytes
from   v$tempstat fs , dba_temp_files df
where  df.file_id = fs.file#;
spool off

prompt Tables last analyzed stats
set pages 20000
spool spool\LastAnalyzedTables_&_MyDB1.
select  to_char(last_analyzed, 'DD-MON-YYYY') "LastAnalyzed", count(1)
from    dba_tables
where   last_analyzed is not null 
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
group   by to_char(last_analyzed, 'DD-MON-YYYY');

select  to_char(last_analyzed, 'DD-MON-YYYY') "LastAnalyzed", owner, count(1)
from    dba_tables
where   last_analyzed is not null 
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
group   by to_char(last_analyzed, 'DD-MON-YYYY'), owner;

select  owner, table_name, to_char(last_analyzed, 'DD-MON-YYYY') "LastAnalyzed"
from    dba_tables
where   last_analyzed is not null
and     trunc(last_analyzed) < to_date('09-Feb-2008', 'DD-Mon-YYYY')
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL');
spool off

spool spool\NotAnalyzedTables_&_MyDB1.
select  count(1)
from    dba_tables
where   last_analyzed is null 
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL');

select  owner, table_name
from    dba_tables
where   last_analyzed is null
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL');
spool off


prompt Indexes last analyzed stats
set pages 40000
spool spool\LastAnalyzedIndexes_&_MyDB1.
select  to_char(last_analyzed, 'DD-MON-YYYY') "LastAnalyzed", count(1)
from    dba_indexes
where   last_analyzed is not null 
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
group   by to_char(last_analyzed, 'DD-MON-YYYY');

select  to_char(last_analyzed, 'DD-MON-YYYY') "LastAnalyzed", owner, count(1)
from    dba_indexes
where   last_analyzed is not null 
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
group   by to_char(last_analyzed, 'DD-MON-YYYY'), owner;

select  owner, index_name, table_owner, table_name, to_char(last_analyzed, 'DD-MON-YYYY') "LastAnalyzed"
from    dba_indexes
where   last_analyzed is not null
and     trunc(last_analyzed) < to_date('09-Feb-2008', 'DD-Mon-YYYY')
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL');
spool off

spool spool\NotAnalyzedIndexes_&_MyDB1.
select  count(1)
from    dba_indexes
where   last_analyzed is null 
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL');

select  owner, index_name, table_owner, table_name
from    dba_indexes
where   last_analyzed is null
and	owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL');
spool off


prompt show the hottest objects in the buffer cache based on the touch count (TCH)
set pages 1000 lines 132
col OWNER for a12
col OBJECT_NAME for a30
col "Buffers" for 999999999999
col TOUCHES   for 999999999999
spool HotObjs
select * from (
  select u.name OWNER, o.name OBJECT_NAME, count(1) "Buffers", sum(tch) TOUCHES
    from sys.x$bh x, sys.obj$ o, sys.user$ u
   where x.obj = o.obj#
     and o.owner# = u.user#
   group by u.name, o.name
   order by 4 desc)
where rownum < 301;
spool off


prompt show the hottest blocks in the buffer cache based on the touch count (TCH)
set pages 1000 lines 132 wrap off trim on
spool HotBlks
select * from (
  select u.name OWNER, o.name OBJECT_NAME, file#, dbablk, count(1) "Buffers", sum(tch) TOUCHES
  from   sys.x$bh x, sys.obj$ o, sys.user$ u
  where  x.obj = o.obj#
  and    o.owner# = u.user#
  group  by u.name, o.name, file#, dbablk
  order  by 6 desc)
where rownum < 301;
spool off


prompt Top objects with the biggest overall footprint in the buffer cache
spool TopObjsInBufferCache
select * from
   (
   select o.owner, o.object_name, o.object_type, round(((count(v.block#) / a.availblks) * 100),2) pctavailblks, count(v.block#) blkcnt
   from dba_objects o, v$bh v,
       (select file#, dbablk, count(1)
        from  sys.x$bh x
        where x.file# > 0
        and   x.hladdr in (select c.addr 
                           from   v$latch_children c, v$latchname n
                           where  c.latch# = n.latch#
                           and    n.name like 'cache buffers chain%')
        group by file#, dbablk
--having count(1) > 3
        order by 2 desc
       ) h,
       (select count(1) availblks 
        from   sys.x$bh
        where  file# > 0
       ) a
   where v.file# = h.file#
   and   v.block# = h.dbablk
   and   v.objd = o.object_id
   group by o.owner, o.object_name, a.availblks, o.object_type
   order by 5 desc
   )
where rownum < 301;
spool off



prompt Top Segments (Tables, TablePartitions, Indexes/IndexPartitions, IOT, LOBINDEX) of Size greater than 5MB
set pages 50000 lines 300 pau off
spool spool\MonthlyRpt_SegmentsGT5MB_&_MyDateNow._&_MyDB1.
select owner, segment_type, segment_name, max(nvl(TABLESPACE_NAME,'null')) "Tablespace", sum(bytes)/1048576 "SizeMB", max(EXTENTS) "Extents"
     , max(nvl(FREELISTS,0)) "Freelists", max(nvl(FREELIST_GROUPS,0)) "FreelistGroups", max(nvl(PARTITION_NAME,'null')) "Partition"
from   dba_segments
where  owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
group  by owner, segment_type, segment_name
having sum(bytes/(1024*1024)) >= 5;
spool off


prompt Top Segments (Tables, TablePartitions) containing more than 100 rows
spool spool\MonthlyRpt_TablesWithGT100Rows_&_MyDateNow._&_MyDB1.
select owner, table_name, num_rows, tablespace_name, PARTITIONED, BLOCKS, nvl(EMPTY_BLOCKS,0), nvl(CHAIN_CNT,0), nvl(IOT_TYPE, 'null'), nvl(IOT_NAME, 'null'), AVG_SPACE, AVG_ROW_LEN, AVG_SPACE_FREELIST_BLOCKS, NUM_FREELIST_BLOCKS, TEMPORARY, ROW_MOVEMENT, MONITORING
from   dba_tables
where  num_rows is not null
and    owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
and    num_rows > 100;
spool off


prompt Top Segments (Indexes/IndexPartitions, IOT,  LOBINDEX) containing more than 100 rows
spool spool\MonthlyRpt_IndexesWithGT100Rows_&_MyDateNow._&_MyDB1.
select owner, INDEX_NAME, nvl(INDEX_TYPE,'null'), num_rows, nvl(tablespace_name,'null'), PARTITIONED, BLEVEL, LEAF_BLOCKS, table_name, nvl(TABLE_TYPE,'null'), CLUSTERING_FACTOR, TEMPORARY, GENERATED, SECONDARY, STATUS
from   dba_indexes
where  num_rows is not null
and    owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
and    num_rows > 100;
spool off


prompt Top 150 Tables containing Chained Rows
spool spool\MonthlyRpt_Top150TableHighChain_&_MyDateNow._&_MyDB1.
select *
from  (select table_name, CHAIN_CNT, num_rows, BLOCKS, EMPTY_BLOCKS, (BLOCKS*8)/1024 "Mb", (EMPTY_BLOCKS*8)/1024 "EmptyMB"
       from   dba_tables
       where CHAIN_CNT > 0
       order  by CHAIN_CNT desc)
where rownum < 151;
spool off


prompt Top high Omega (bad tables) factor tables
--Create Table my_OwnerTable
--(owner varchar2(20) , tablename varchar2(40));
--sqlldr userid=system/oracle control=OwnerTable.ctl log=OwnerTable.log direct=true
--set pages 0 trim on feed off echo off lines 65
--spool tf.txt
--select unique owner||','||tablename from my_OwnerTable;
--spool off

spool spool\OwnerTbl_&_MyDateNow._&_MyDB1.
select owner, count(1)
from   dba_tables
where  owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL')
group  by owner;
select owner, table_name
from   dba_tables
where  owner not in ('SYS' , 'SYSTEM' , 'PERFSTAT' , 'SYMANTEC_I3_ORCL');
spool off

Edit and save abot lst file as a CSV file and name it tf.txt and ftp to server /home/bobridge/ravi/ or /home/fobridge/ravi/
tf.ksh > tf.log 2>&1 &
tail -f tf.log
REM 1) Before this sql can be run use a comma delimited tf.txt containing owner and tablename
REM 2) Then run the tf.ksh which in turn uses tablefrag.sql present in /home/bobridge/ravi
REM 3) This will gather data and insert rows into my_tfrag
REM 4) Now execute the following SQL to get the required data
set lines 200 pages 2000 wrap off trim on
col owner heading 'Owner'      format a12
col name  heading 'Table Name' format a30
col exts   heading 'Exts'       format 999,999,999
col omega1 heading 'Omega1'     format 0.999
col "SizeMB" for 999,999.99
col chains heading 'Chains'     format 999,990
col num_rows for 999,999,999
spool spool\MonthlyRpt_tf_&_MyDateNow._&_MyDB1.
select owner, trim(name), (hwm - blks_w_rows)/(hwm + 0.0001) omega1, num_rows, sbytes/(1024*1024) "SizeMB", EXTENTS, CHAIN_CNT
from   my_tfrag
order  by omega1 desc;
spool off


spool spool\MonthlyRpt_Top10ObjectsByStats_&_MyDateNow._&_MyDB1.
prompt Top 10 Logical Reads per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'logical reads'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 Physical Reads per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'physical reads'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 physical Reads direct per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'physical reads direct'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 Physical writes per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'physical writes'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 Physical writes direct per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'physical writes direct'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 db block changes per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'db block changes'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 Buffer Busy waits per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'buffer busy waits'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 Row Lock waits per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'row lock waits'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 ITL waits per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'ITL waits'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 global cache cr blocks served per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'global cache cr blocks served'
   order  by VALUE desc)
where rownum < 11;

prompt Top 10 global cache current blocks served per Segment
select * from (
   select OWNER, OBJECT_TYPE, OBJECT_NAME, TABLESPACE_NAME, VALUE, SUBOBJECT_NAME
   from   V$SEGMENT_STATISTICS
   where  STATISTIC_NAME = 'global cache current blocks served'
   order  by VALUE desc)
where rownum < 11;
spool off


prompt Top 10 frequently accessed Packages
col kept for a4
col sharable_mem for 999,999,999 head "Bytes"
spool spool\tu_ObjsInSharedPool_&_MyDateNow._&_MyDB1.
prompt By Executions
select * from (
select owner, name, type, sharable_mem, loads, executions, kept
from   v$db_object_cache
where  type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and    executions > 0
order  by executions desc)
where rownum < 51;

prompt 
prompt By Loads
select * from (
select owner, name, type, sharable_mem, loads, executions, kept
from   v$db_object_cache
where  type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and    executions >0
order  by loads desc)
where rownum < 51;

prompt 
prompt By Sharable Memory
select * from (
select owner, name, type, sharable_mem, loads, executions, kept
from   v$db_object_cache
where  type in ('TRIGGER','PROCEDURE','PACKAGE BODY','PACKAGE')
and    executions >0
order  by sharable_mem desc)
where rownum < 51;
spool off


prompt Top 10 SQLs by Logical Gets
set pages 3000
col "Module" for a40
spool spool\MonthlyRpt_Top10SQLGets_&_MyDateNow._&_MyDB1.
select *
from  ( select nvl(b.buffer_gets,0) "BufferGets"
              , nvl(b.executions,0) "Executions"
              , decode(nvl(b.executions,0) ,0,0 ,nvl(b.buffer_gets,0)/nvl(b.executions,0)) "GetsPerExec"
              , nvl(b.cpu_time,0)/1000000 "CPUTime(s)"
              , nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
              , b.hash_value, decode(b.module, null,'null', b.module) "Module", st.sql_text
         from   v$sql b , v$sqltext st
         where  b.hash_value  = st.hash_value
         order  by nvl(b.buffer_gets,0) desc, b.hash_value, st.piece
      )
where rownum < 500;
spool off


prompt Top 10 SQLs by Physical Reads
spool spool\MonthlyRpt_Top10SQLReads_&_MyDateNow._&_MyDB1.
select *
from  ( select  nvl(b.disk_reads,0) "DiskReads"
              , nvl(b.executions,0) "Executions"
              , decode(nvl(b.executions,0) ,0,0 ,nvl(b.disk_reads,0)/nvl(b.executions,0))  "ReadsPerExec"
              , nvl(b.cpu_time,0)/1000000 "CPUTime(s)"
              , nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
              , b.hash_value, decode(b.module, null,'null', b.module) "Module", st.sql_text
         from   v$sql b , v$sqltext st
         where  b.hash_value  = st.hash_value
         order  by nvl(b.disk_reads,0) desc, b.hash_value, st.piece
      )
where rownum < 500;
spool off


prompt Top 10 SQLs by Rows Processed
spool spool\MonthlyRpt_Top10SQLExecutions_&_MyDateNow._&_MyDB1.
select *
from  ( select  nvl(b.executions,0) "Executions"
              , nvl(b.rows_processed,0) "RowsProcessed"
              , decode(nvl(b.executions,0) ,0,0 ,nvl(b.rows_processed,0)/nvl(b.executions,0))  "RowsPerExec"
              , nvl(b.cpu_time,0)/1000000 "CPUTime(s)"
              , nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
              , b.hash_value, decode(b.module, null,'null', b.module) "Module", st.sql_text
         from   v$sql b , v$sqltext st
         where  b.hash_value  = st.hash_value
         order  by nvl(b.rows_processed,0) desc, b.hash_value, st.piece
      )
where rownum < 500;
spool off


prompt Top 10 SQLs by ParseCalls
spool spool\MonthlyRpt_Top10SQLParseCalls_&_MyDateNow._&_MyDB1.
select *
from  ( select  nvl(b.executions,0) "Executions"
              , nvl(b.parse_calls,0) "ParseCalls"
              , nvl(b.cpu_time,0)/1000000 "CPUTime(s)"
              , nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
              , b.hash_value, decode(b.module, null,'null', b.module) "Module", st.sql_text
         from   v$sql b , v$sqltext st
         where  b.hash_value  = st.hash_value
         order  by nvl(b.parse_calls,0) desc, b.hash_value, st.piece
      )
where rownum < 500;
spool off


prompt Top 10 SQLs by SharableMemory
spool spool\MonthlyRpt_Top10SQLSharableMemory_&_MyDateNow._&_MyDB1.
select *
from  ( select  nvl(b.executions,0) "Executions"
              , nvl(b.sharable_mem,0) "SharableMem(b)"
              , nvl(b.elapsed_time,0)/1000000 "ElapsedTime(s)"
              , b.hash_value, decode(b.module, null,'null', b.module) "Module", st.sql_text
         from   v$sql b , v$sqltext st
         where  b.hash_value  = st.hash_value
         order  by nvl(b.sharable_mem,0) desc, b.hash_value, st.piece
      )
where rownum < 500;
spool off


prompt Top PL/SQL Code blocks
/* Value 47 for command_type identifies PL/SQL code; this helps you see how much they contribute to the total number of logical reads. 
   Any call to a PL/SQL anonymous block or stored procedure is recorded inside V$SQL, with its number of executions, its number of physical reads, 
   and, most importantly, the number of logical reads (buffer_gets) it required */
set lines 1500
col sql_text for a1000
col module for a50
col buffer_gets for 999,999,999,999
col EXECUTIONS for 999,999,999,999
col INVALIDATIONS for 999,999,999,999
col FETCHES for 999,999,999,999
col LOADS for 999,999,999,999
col PARSE_CALLS for 999,999,999,999
col DISK_READS for 999,999,999,999
col ROWS_PROCESSED for 999,999,999,999
col CPU_TIME for 999,999,999,999
col ELAPSED_TIME for 999,999,999,999,999

spool spool\tu_badplsql_&_MyDateNow._&_MyDB1.
Prompt By Buffer Gets
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * buffer_gets / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
   from   v$sql, (select sum(buffer_gets) tot from v$sql where command_type != 47 and buffer_gets > 1000) t
   where  command_type = 47
   and    buffer_gets > 1000
   order  by buffer_gets desc)
where rownum < 51;

Prompt By Executions
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * EXECUTIONS / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
   from   v$sql, (select sum(EXECUTIONS) tot from v$sql where command_type != 47 and executions > 0) t
   where  command_type = 47
   and    executions > 0
   order  by EXECUTIONS desc)
where rownum < 51;

Prompt 
Prompt By Invalidations
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * INVALIDATIONS / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
from   v$sql, (select sum(INVALIDATIONS) tot from v$sql where command_type != 47 and INVALIDATIONS > 1) t
where  command_type = 47
and    INVALIDATIONS > 1
order  by INVALIDATIONS desc)
where rownum < 51;

Prompt 
Prompt By FETCHES
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * FETCHES / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
from   v$sql, (select sum(FETCHES) tot from v$sql where command_type != 47 and FETCHES > 1) t
where  command_type = 47
and    FETCHES > 1
order  by FETCHES desc)
where rownum < 51;

Prompt 
Prompt By LOADS
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * LOADS / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
from   v$sql, (select sum(LOADS) tot from v$sql where command_type != 47 and LOADS > 1) t
where  command_type = 47
and    LOADS > 1
order  by LOADS desc)
where rownum < 51;

Prompt 
Prompt By PARSE_CALLS
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * PARSE_CALLS / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
from   v$sql, (select sum(PARSE_CALLS) tot from v$sql where command_type != 47 and PARSE_CALLS > 1) t
where  command_type = 47
and    PARSE_CALLS > 1
order  by PARSE_CALLS desc)
where rownum < 51;

Prompt 
Prompt By DISK_READS
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * DISK_READS / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
from   v$sql, (select sum(DISK_READS) tot from v$sql where command_type != 47 and DISK_READS > 1) t
where  command_type = 47
and    DISK_READS > 1
order  by DISK_READS desc)
where rownum < 51;

Prompt 
Prompt By ROWS_PROCESSED
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * ROWS_PROCESSED / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
from   v$sql, (select sum(ROWS_PROCESSED) tot from v$sql where command_type != 47 and ROWS_PROCESSED > 1) t
where  command_type = 47
and    ROWS_PROCESSED > 1
order  by ROWS_PROCESSED desc)
where rownum < 51;

Prompt 
Prompt By CPU_TIME
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * CPU_TIME / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
from   v$sql, (select sum(CPU_TIME) tot from v$sql where command_type != 47 and CPU_TIME > 1) t
where  command_type = 47
and    CPU_TIME > 1
order  by CPU_TIME desc)
where rownum < 51;

Prompt 
Prompt By ELAPSED_TIME
select * from (
   select MODULE, HASH_VALUE, buffer_gets, EXECUTIONS, round(100 * ELAPSED_TIME / t.tot, 1) PCT, INVALIDATIONS, FETCHES, LOADS, PARSE_CALLS, DISK_READS
        , ROWS_PROCESSED, ACTION, CPU_TIME, ELAPSED_TIME, sql_text
from   v$sql, (select sum(ELAPSED_TIME) tot from v$sql where command_type != 47 and ELAPSED_TIME > 1) t
where  command_type = 47
and    ELAPSED_TIME > 1
order  by ELAPSED_TIME desc)
where rownum < 51;
spool off


prompt Cumulative Instance Efficiency Percentages report
prompt Shared Pool Statistics, Shared Pool Advisory report
prompt Buffer Pool Statistics, Buffer Pool Advisory, Buffer wait Statistics report
prompt Dictionary Cache and Library Cache Activity stats report
prompt Enqueue activity report
prompt Undo Segment Stats report
prompt Server performance reports (Load, CPU, Memory, IO, Network)


prompt Oracle EBS related stats

prompt Logins with Sysadmin responsibility
col USER_NAME           for a15
col DESCRIPTION         for a62
col EMAIL_ADDRESS       for a30
col RESPONSIBILITY_NAME for a23
col "StartDate"         for a11
spool spool\FndSysadmins_&_MyDateNow._&_MyDB1.
select A.USER_NAME, to_char(A.START_DATE,'DD-Mon-YYYY') "StartDate", A.DESCRIPTION, C.RESPONSIBILITY_NAME
from   FND_USER A, FND_USER_RESP_GROUPS_DIRECT B, FND_RESPONSIBILITY_TL C
where  C.RESPONSIBILITY_NAME = 'System Administrator'
and    B.USER_ID           = A.USER_ID
and    C.APPLICATION_ID    = B.RESPONSIBILITY_APPLICATION_ID
and    C.RESPONSIBILITY_ID = B.RESPONSIBILITY_ID
and    C.LANGUAGE          = 'US'
and    A.END_DATE is NULL
and    B.END_DATE is NULL
order  by A.START_DATE;
spool off


prompt Concurrent Manager Load Stats

prompt Display Concurrent Manager Definitions
@cms.sql


-- From cmConcReq.sql
prompt Concurrent Requests Statistics
spool spool\cmConcReq_&_MyDateNow._&_MyDB1.
col "RunDate" for a12
prompt PART 1 : List last 7days Conc Job summary by day
select to_char(actual_start_date, 'DD-MON-RR') "RunDate", count(1) "Requests"
from   fnd_concurrent_requests
where  trunc(actual_start_date) >= trunc(sysdate - 7)
group  by cube(to_char(actual_start_date, 'DD-MON-RR'));
prompt PART 2 : List last 7days job summary by hour
select to_char(actual_start_date, 'DD-MON-RR HH24') "RunDate", count(1) "Requests"
from   fnd_concurrent_requests
where  trunc(actual_start_date) >= trunc(sysdate - 7)
group  by cube(to_char(actual_start_date, 'DD-MON-RR HH24'));
spool off


@cmStats.sql

-- 
column user_concurrent_program_name format a55
spool spool\MonthlyRpt_ScheduledConcPgms_&_MyDateNow._&_MyDB1.
select a.user_concurrent_program_name, count(*)
from   fnd_concurrent_programs_tl a, fnd_concurrent_requests b
where  a.concurrent_program_id=b.concurrent_program_id 
and    phase_code = 'C'
group  by user_concurrent_program_name;
spool off


prompt Run alone Concurrent programs report
select RUN_ALONE_FLAG, count(1)
from   fnd_concurrent_programs
group by RUN_ALONE_FLAG;
select c.CONCURRENT_PROGRAM_NAME, c2.language, c.RUN_ALONE_FLAG, c.ENABLED_FLAG, c.SRS_FLAG, c2.user_concurrent_program_name "program"
from   fnd_concurrent_programs_tl c2, fnd_concurrent_programs c
where  c.RUN_ALONE_FLAG = 'Y'
and    c2.concurrent_program_id = c.concurrent_program_id
and    c2.application_id        = c.application_id
--and    c2.language              = 'US'
order  by 1,2;
select a.request_id, to_char(a.actual_start_date,'DD-Mon-yy HH24:MI') actstart
     , c.CONCURRENT_PROGRAM_NAME, c2.language, c.RUN_ALONE_FLAG, c.ENABLED_FLAG, c.SRS_FLAG, c2.user_concurrent_program_name "program"
     , a.RESUBMIT_INTERVAL_TYPE_CODE, a.RESUBMIT_TIME, a.RESUBMIT_END_DATE
from   fnd_concurrent_programs_tl c2, fnd_concurrent_programs c, fnd_Concurrent_requests a
where  c.RUN_ALONE_FLAG = 'Y'
and    c2.concurrent_program_id = c.concurrent_program_id
and    c2.application_id        = c.application_id
and    c2.language              = 'US'
and    a.concurrent_program_id  = c.concurrent_program_id
and    a.program_application_id = c.application_id
order  by 2;


prompt Displaying all concurrent programs Scheduled yesterday
set pages 50000
col "Parent" for a10
col request_id for 999999999
col "Schedule" for a20
col statustxt for a60
col program for a100
col Requestor for a30
spool spool\MonthlyRpt_ScheduledConcPgms_&_MyDateNow._&_MyDB1.
select /* FIRST_ROWS */
       decode(a.parent_request_id,-1,NULL,a.parent_request_id) "Parent", a.request_id
     , to_char(a.requested_start_date,'DD-Mon-yy HH24:MI') reqstart
     , to_char(a.actual_start_date,'DD-Mon-yy HH24:MI') actstart
     , a.RESUBMIT_INTERVAL||' '||a.RESUBMIT_INTERVAL_UNIT_CODE "Schedule"
     , a.concurrent_program_id "Prg Id", a.phase_code||a.status_code||'-'||l2.meaning||' '||l1.meaning statustxt
     , c.concurrent_program_name||' - '|| c2.user_concurrent_program_name "program"
     , u.user_name "Requestor", u.DESCRIPTION, u.EMAIL_ADDRESS
     , a.RESUBMIT_INTERVAL_TYPE_CODE, a.RESUBMIT_TIME, a.RESUBMIT_END_DATE
from   fnd_Concurrent_requests a, fnd_concurrent_programs_tl c2, fnd_concurrent_programs c, fnd_lookup_values l1, fnd_lookup_values l2, fnd_user u
where  trunc(a.actual_start_date) = trunc(sysdate-1)
and    a.RESUBMIT_INTERVAL is not null
and    a.concurrent_program_id  = c.concurrent_program_id
and    a.program_application_id = c.application_id
and    c2.concurrent_program_id = c.concurrent_program_id
and    c2.language              = 'US'
and    c2.application_id        = c.application_id
and    a.actual_start_date      is not null
and    a.phase_code             in ('C' , 'R')
and    l1.lookup_type           = 'CP_STATUS_CODE'
and    l1.lookup_code           = a.status_code
and    l1.language              = 'US'
and    l1.enabled_flag          = 'Y'
and   (l1.start_date_active   <= sysdate and l1.start_date_active is not null)
and   (l1.end_date_active      > sysdate  or  l1.end_date_active is null)
and    l2.lookup_type           = 'CP_PHASE_CODE'
and    l2.lookup_code           = a.phase_code
and    l2.language              = 'US'
and    l2.enabled_flag          = 'Y'
and   (l2.start_date_active   <= sysdate and l2.start_date_active is not null)
and   (l2.end_date_active     > sysdate  or  l2.end_date_active is null)
and    a.requested_by           = u.user_id;
spool off

prompt Display Concurrent Requests run every day
select to_char(fcr.actual_start_date,'mm/dd/yy') Reqdate, count(1)
from   APPLSYS.fnd_Concurrent_requests fcr
where  fcr.actual_start_date is not null
group by to_char(fcr.actual_start_date,'mm/dd/yy');


prompt Display Hourly COncurrent Pgms Requests started and completed
col MidN format 99999
col 1AM format 99999
col 2AM format 99999
col 3AM format 99999
col 4AM format 99999
col 5AM format 99999
col 6AM format 99999
col 7AM format 99999
col 8AM format 99999
col 9AM format 99999
col 10AM format 99999
col 11AM format 99999
col Noon format 99999
col 1PM format 99999
col 2PM format 99999
col 3PM format 99999
col 4PM format 99999
col 5PM format 99999
col 6PM format 99999
col 7PM format 99999
col 8PM format 99999
col 9PM format 99999
col 10PM format 99999
col 11PM format 99999
spool spool\MonthlyRpt_ConcReqHrly_&_MyDateNow._&_MyDB1.
select to_char(fcr.actual_start_date,'ddMonyy') Reqdate,
sum(decode(to_char(fcr.actual_start_date,'hh24'),'00',1,0)) "MidN",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'01',1,0)) "1AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'02',1,0)) "2AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'03',1,0)) "3AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'04',1,0)) "4AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'05',1,0)) "5AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'06',1,0)) "6AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'07',1,0)) "7AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'08',1,0)) "8AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'09',1,0)) "9AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'10',1,0)) "10AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'11',1,0)) "11AM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'12',1,0)) "Noon",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'13',1,0)) "1PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'14',1,0)) "2PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'15',1,0)) "3PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'16',1,0)) "4PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'17',1,0)) "5PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'18',1,0)) "6PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'19',1,0)) "7PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'20',1,0)) "8PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'21',1,0)) "9PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'22',1,0)) "10PM",
sum(decode(to_char(fcr.actual_start_date,'hh24'),'23',1,0)) "11PM"
from   APPLSYS.fnd_Concurrent_requests fcr
where  fcr.actual_start_date is not null
group by to_char(fcr.actual_start_date,'ddMonyy')
order by 1;
spool off


prompt Display all concurrent programs that took more than 30 mins
select fcp.CONCURRENT_PROGRAM_NAME
     , count(1) "#OfRuns"
     , to_char(min(fcr.actual_start_date),'dd-Mon-yyyy hh24:mi:ss') "FirstStartDate"
     , to_char(max(fcr.actual_start_date),'dd-Mon-yyyy hh24:mi:ss') "LastStartDate"
     , min((fcr.actual_completion_date-fcr.actual_start_date)*1440) "MinRun(Mins)"
     , avg((fcr.actual_completion_date-fcr.actual_start_date)*1440) "AvgRun(Mins)"
     , max((fcr.actual_completion_date-fcr.actual_start_date)*1440) "MaxRun(Mins)"
     , fcpt.USER_CONCURRENT_PROGRAM_NAME
from   APPLSYS.fnd_Concurrent_requests fcr, APPLSYS.fnd_concurrent_programs fcp, APPLSYS.fnd_concurrent_programs_tl fcpt
where  fcr.phase_code = 'C'
and    fcr.actual_completion_date is not null
and    fcr.program_application_id = fcp.application_id
and    fcr.concurrent_program_id  = fcp.concurrent_program_id
and    fcpt.APPLICATION_ID        = fcp.application_id
and    fcpt.CONCURRENT_PROGRAM_ID = fcp.concurrent_program_id
and    fcpt.SOURCE_LANG           = 'US'
and    fcpt.LANGUAGE              = 'US'
group  by fcp.CONCURRENT_PROGRAM_NAME, fcpt.USER_CONCURRENT_PROGRAM_NAME, fcr.QUEUE_APP_ID, fcr.QUEUE_ID
having max((fcr.actual_completion_date-fcr.actual_start_date)*1440) > 30;

prompt Getting queue statistics for the last 6 days. It may take a few mins. Please be patient....
col "QueueName" format a30
col "Actual"  format 99,999
col "Target"  format 99,999
col "MinRun(Mins)" format 9999.999
col "MaxRun(Mins)" format 9999.999
col "AvgRun(Mins)" format 9999.999
col  avgq head "AvgQTime(Mins)" format 9999.999
col "Requests" format 99999
spool spool\MonthlyRpt_ConcQueStats_&_MyDateNow._&_MyDB1.
select q.concurrent_queue_name "QueueName", q.target_node, count(r.request_id) "Requests"
     , q.running_processes "Actual", q.max_processes "Target"
     , avg((r.actual_start_date - r.requested_start_date)*1440)   avgq
     , min((r.actual_completion_date - r.actual_start_date)*1440) "MinRun(Mins)"
     , avg((r.actual_completion_date - r.actual_start_date)*1440) "AvgRun(Mins)"
     , max((r.actual_completion_date - r.actual_start_date)*1440) "MaxRun(Mins)"
     , sum((r.actual_completion_date - r.actual_start_date)*1440) "TotalTime(Mins)"
from   applsys.fnd_concurrent_requests r, applsys.fnd_concurrent_processes p, applsys.fnd_concurrent_programs g, applsys.fnd_concurrent_queues q
where  r.controlling_manager = p.concurrent_process_id
and    p.queue_application_id = q.application_id
and    p.concurrent_queue_id = q.concurrent_queue_id
and    trunc(r.actual_completion_date) between (SYSDATE-7) and (SYSDATE-1)
and    r.concurrent_program_id = g.concurrent_program_id
and    r.program_application_id = g.application_id
group  by q.concurrent_queue_name, q.target_node, q.running_processes, q.max_processes;
spool off


prompt Display Gather Schema Stats that ran in the last 7 days or scheduled to run in future
col PROGRAM for a30
col ARGUMENT_TEXT for a50
col COMPLETION_TEXT for a30
col REQ_START_DATE for a20
col ACT_COMPLETED_DATE for a20
col PROGRAM_SHORT_NAME for a10 head "ShortName"
col "RunTime(Mins)" for 999.99
col "RunTime(Hrs)" for 99.99
col "Day" for a10
set trim on wrap off
spool spool\MonthlyRpt_GatherStats_&_MyDateNow._&_MyDB1.
SELECT  R.REQUEST_ID, 
	decode(R.PHASE_CODE, 'R', 'Running', 'P', 'Scheduled', 'C', 'Completed', 'Raw:' ||R.PHASE_CODE) phase, R.STATUS_CODE STATUS_CODE, 
        to_char(R.REQUESTED_START_DATE, 'DAY') "Day",
	to_char(R.REQUESTED_START_DATE, 'DD-MON-RRRR HH24:MI') req_start_date, 
	to_char(R.ACTUAL_COMPLETION_DATE, 'DD-MON-RRRR HH24:MI') act_completed_date,
       (R.ACTUAL_COMPLETION_DATE - R.REQUESTED_START_DATE) * 24 * 60 "RunTime(Mins)",
       (R.ACTUAL_COMPLETION_DATE - R.REQUESTED_START_DATE) * 24 "RunTime(Hrs)",
	PB.CONCURRENT_PROGRAM_NAME PROGRAM_SHORT_NAME , 
	DECODE (R.DESCRIPTION, NULL, PT.USER_CONCURRENT_PROGRAM_NAME, R.DESCRIPTION||' ('||PT.USER_CONCURRENT_PROGRAM_NAME||')') PROGRAM,
	R.ARGUMENT_TEXT, R.COMPLETION_TEXT
FROM 	FND_CONCURRENT_PROGRAMS_TL PT, FND_CONCURRENT_PROGRAMS PB, FND_USER U, FND_CONCURRENT_REQUESTS R
WHERE   PB.CONCURRENT_PROGRAM_ID = R.CONCURRENT_PROGRAM_ID 
AND     PB.CONCURRENT_PROGRAM_ID = PT.CONCURRENT_PROGRAM_ID 
AND     U.USER_ID = R.REQUESTED_BY
and     PB.CONCURRENT_PROGRAM_NAME in ('FNDGACST','FNDGCLST','FNDGSCST','FNDGTST')
and     R.REQUESTED_START_DATE >= sysdate-7
and     PT.LANGUAGE = 'US'
order   by R.PHASE_CODE, R.REQUESTED_START_DATE;
spool off


prompt Display Workflow related statistics
spool spool\MonthlyRpt_WorkflowStats_&_MyDateNow._&_MyDB1.
select item_type "ItemType", activity_status "Activity", count(1) "Count"
from   wf_item_activity_statuses
group  by item_type,activity_status;

select item_type "ItemType", count(1) "Count"
from   wf_item_attribute_values
group  by item_type;

select wi.item_type "ItemType", wit.persistence_type "Persistence", decode (wi.end_date, NULL, 'OPEN', 'CLOSED') "Status", count(1) "Count"
from   wf_items wi, wf_item_types wit
where  wit.name = wi.item_type
group by item_type, wit.persistence_type, WIT.PERSISTENCE_DAYS, decode (wi.end_date, NULL, 'OPEN', 'CLOSED');
spool off



-- Buffer Busy waits by segements
col owner for a10
col OBJECT_NAME for a30
col SUBOBJECT_NAME for a10
col TABLESPACE_NAME for a20
col STATISTIC_NAME for a18
spool spool\bbsegs
select * from (
select *
from   v$segment_statistics
where  statistic_name = 'buffer busy waits'
order  by value desc)
where rownum <= 500;
spool off

SQL> desc X$KSOLSFTS
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 ADDR                                               RAW(8)
 INDX                                               NUMBER
 INST_ID                                            NUMBER
 FTS_OBJD                                           NUMBER
 FTS_TSN                                            NUMBER
 FTS_OBJN                                           NUMBER
 FTS_STATID                                         NUMBER
 FTS_STATNAM                                        VARCHAR2(64)
 FTS_INTE                                           NUMBER
 FTS_STMP                                           DATE
 FTS_STAVAL                                         NUMBER

select *
from   X$KSOLSFTS A
where  A.FTS_STATNAM = 'buffer busy waits'
order  by A.FTS_STAVAL desc;

col FTS_STATNAM for a18
col "TimeStamp" for a21
col OBJECT_NAME for a30
select unique Z."obj1" , Z."Obj2" from
(
select C.OBJECT_NAME , D.OBJECT_NAME , A.FTS_STAVAL, B.NAME, A.FTS_STATNAM, to_char(A.FTS_STMP, 'dd-mon-yyyy hh24:mi:ss') "TimeStamp"
from   X$KSOLSFTS A, v$tablespace B, dba_objects C, dba_objects D
where  A.FTS_STATNAM = 'buffer busy waits'
and    A.FTS_TSN     = B.TS#
and    C.OBJECT_ID   = A.FTS_OBJD
and    D.OBJECT_ID   = A.FTS_OBJN
order  by A.FTS_STAVAL desc
) Z;





select * from 
(
select *
from   X$KSOLSFTS A
where  A.FTS_STATNAM = 'buffer busy waits'
order  by A.FTS_STAVAL desc
);



----
create table my_TbsRows (Tablespace varchar2(30), num_rows number, blocks number);
sqlldr userid=system/oracle control=book1.ctl log=book1.log direct=true
spool  spool\TbsRows
select tablespace, sum(num_rows) "Rows", sum(blocks) "Blocks"
from   my_TbsRows
group  by tablespace;
spool off
