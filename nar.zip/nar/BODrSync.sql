Select DB_Name,max(instance1) Instance1,max(instance2) Instance2,max(instance3) Instance3
from (
select '1-EBSPRD' DB_Name,decode(THREAD#,1,max(SEQUENCE#),0) Instance1,
decode(THREAD#,2,max(SEQUENCE#),0) Instance2
,decode(THREAD#,3,max(SEQUENCE#),0) Instance3
from v$archived_log
where dest_id=1
group by THREAD#
union
select '3-EBADG' DB_Name,decode(THREAD#,1,max(SEQUENCE#),0) Instance1,
decode(THREAD#,2,max(SEQUENCE#),0) Instance2
,decode(THREAD#,3,max(SEQUENCE#),0) Instance3 from v$archived_log@EBSADG
where dest_id=3
and applied='YES'
group by THREAD#
union
select '2-EBSDR1' DB_Name,decode(THREAD#,1,max(SEQUENCE#),0) Instance1,
decode(THREAD#,2,max(SEQUENCE#),0) Instance2
,decode(THREAD#,3,max(SEQUENCE#),0) Instance3 from v$archived_log@ebsdr1
where dest_id=2
and applied='YES'
group by THREAD#
union
select '4-EBSDR2' DB_Name,decode(THREAD#,1,max(SEQUENCE#),0) Instance1,
decode(THREAD#,2,max(SEQUENCE#),0) Instance2
,decode(THREAD#,3,max(SEQUENCE#),0) Instance3 from v$archived_log@EBSDR2
where dest_id=4
and applied='YES'
group by THREAD#
order by 2 desc
)
group by DB_Name
order by 1;