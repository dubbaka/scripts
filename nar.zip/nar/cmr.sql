-- @cmrun2.sql

rem ********************************************************************
rem * Description       : Information about jobs currently running on the system
rem ********************************************************************

clear columns breaks compute
set lines 1000 pages 200 feed on

col "Parent" for a8
col request_id for 999999999 head  "Req Id"
col concurrent_program_id for 99999999 head "Pgm Id"
col phase_code head "P|H|A|S|E"
col status_code head "S|T|A|T|U|S"
col sid for 99999 head SID
col os_process_id for a7 head "OSpid|APnode"
col spid for a6 head "OSpid|DBnode"
col time for 99,999.99 head 'Elapsed|(Mins)'
col qname for a25 trunc head "Concurrent Manager Queue"
col "ConcPgm" for a65 head "Concurrent Program" TRUNC
col user_name for a15
select target_node  || ' - ' || q.concurrent_queue_name qname,
      decode(a.parent_request_id, -1,NULL , a.parent_request_id) "Parent"
      ,a.request_id, c.concurrent_program_name||' - '||c2.user_concurrent_program_name "ConcPgm",a.phase_code , a.status_code
      ,vs.sid, fu.user_name
      ,(nvl(actual_completion_date,sysdate)-actual_start_date)*1440 "Time"
      ,to_char(actual_start_date, 'DDMonYY HH24:MI:SS') "StartDate",a.concurrent_program_id,a.argument_text
from APPLSYS.fnd_Concurrent_requests a , APPLSYS.fnd_concurrent_processes   b
    ,APPLSYS.fnd_concurrent_queues   q , APPLSYS.fnd_concurrent_programs_tl c2
    ,APPLSYS.fnd_concurrent_programs c , gv$session vs, gv$process vp,
    apps.fnd_user fu
where 
	a.controlling_manager = b.concurrent_process_id
  and a.concurrent_program_id = c.concurrent_program_id
  and a.program_application_id = c.application_id
  and c2.concurrent_program_id = c.concurrent_program_id
  and a.phase_code in ('I','P','R','T')
  and b.queue_application_id = q.application_id
  and b.concurrent_queue_id = q.concurrent_queue_id
  and c2.language = 'US'
  and fu.user_id=a.requested_by
  --and vs.process (+) = b.os_process_id
  and vs.paddr = vp.addr (+)
  and a.ORACLE_SESSION_ID=vs.audsid
  and vs.inst_id = vp.inst_id
order by "Time" desc;
