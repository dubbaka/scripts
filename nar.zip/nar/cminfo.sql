set linesize 80
set verify off

accept req_id prompt 'What is the Request ID? '

TTITLE CENTER ' Specific Concurrent Request Information ' SKIP 3

COLUMN INFO                    HEADING 'Details' FORM A80

SELECT '         Request ID: '||a.request_id||chr(10)||
       '   Conc. Program ID: '||a.concurrent_program_id||chr(10)||
       ' Conc. Program Name: '||b.concurrent_program_name||chr(10)||
       '  User Program Name: '||t.USER_CONCURRENT_PROGRAM_NAME||chr(10)||
       '         Parameters: '||argument1||chr(10)||
       '        Instance   : '||s.inst_id||chr(10)||
       '                SID: '||s.sid||chr(10)||
       '  Server Process ID: '||p.spid||chr(10)||
       '     O/S Process ID: '||c.os_process_id||chr(10)||
       '          Requestor: '||d.user_name||chr(10)||
       'Minutes Since Start: '||to_number(sysdate-a.actual_start_date)*60*24||chr(10)||
       '  Processing Status: '||decode(phase_code,'C','Complete','R','Running','E', 'Errors',phase_code)||chr(10)||
       '  Completion Status: '||decode(status_code,'E', 'Error','C','Complete','R','Running',status_code) INFO
FROM   apps.fnd_concurrent_requests a,
       apps.fnd_concurrent_programs b,
       apps.fnd_concurrent_programs_tl t,
       apps.fnd_concurrent_processes c,
       apps.fnd_user d,
       gv$session s,
       gv$process p
WHERE  a.request_id = '&Req_id'
  AND  a.concurrent_program_id = b.concurrent_program_id
  AND  a.program_application_id = b.application_id
  AND  a.concurrent_program_id = t.concurrent_program_id
  AND  a.program_application_id = t.application_id
  AND  c.concurrent_process_id = a.controlling_manager
  AND  b.concurrent_program_id=t.concurrent_program_id
  AND  b.application_id=t.application_id
  AND  d.user_id = a.requested_by
  AND  c.oracle_process_id = p.pid
  AND  p.addr = s.paddr
  and  s.inst_id=p.inst_id
ORDER BY a.request_id DESC
/

