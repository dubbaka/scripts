set term off;

-- This script will find all worklist items that are open but are tied
-- to errant activities that are no longer in an ERROR state.  It will
-- retry them to close them out.

-- 02-14-02 Updated script to accept item type, output summary information
--          and handle the situation where the item has been purged already
--          by changing the select statement to add a UNION..not exists.
-- RNMERCER
-- 09-13-02 Updated to exclude WFERROR where the notification is currently ERRORed.

-- Use this script only on the advice of Oracle Support or Development.
set term on;
set echo off;
set verify off;
set linesize 250;
set pagesize 500;
set serveroutput on;

spool bde_wf_clean_worklist;

select organization_id, 
       name 
from   hr_operating_units;

accept op_unit prompt 'Please enter the Operating Unit (organization_id): '

execute fnd_client_info.set_org_context('&op_unit');

accept itemtype prompt 'Please enter an item type (OEOL, Default=%): '

column item_type format a10;
column item_key  format a10;
column errant_item_type format a20;
column errant_item_key format a20;
select distinct 
     itm.item_type item_type, 
     itm.item_key  item_key,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') errant_item_type,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') errant_item_key
from 
     wf_items                  itm,
     wf_item_activity_statuses sta,
     wf_item_activity_statuses errsta,
     wf_process_activities     pra
where itm.item_type = 'WFERROR'
  and itm.end_date is null
  and to_number(WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ACTIVITY_ID')) 
        = sta.process_activity
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        = sta.item_type(+)
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') 
        = sta.item_key(+)
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        like  '&itemtype'||'%'
  and sta.activity_status(+) <> 'ERROR'
  and errsta.item_type   = itm.item_type
  and errsta.item_key    = itm.item_key
  and errsta.end_date    is null
  and errsta.activity_status = 'NOTIFIED'
  and errsta.notification_id is not null
  and errsta.process_activity = pra.instance_id
UNION
select distinct 
     itm.item_type item_type, 
     itm.item_key  item_key,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') errant_item_type,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') errant_item_key
from 
     wf_items                  itm,
     wf_item_activity_statuses errsta,
     wf_process_activities     pra
where itm.item_type = 'WFERROR'
  and itm.end_date is null
  and errsta.item_type   = itm.item_type
  and errsta.item_key    = itm.item_key
  and errsta.end_date    is null
  and errsta.notification_id is not null
  and errsta.process_activity = pra.instance_id
  and errsta.activity_status = 'NOTIFIED'
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        like  '&itemtype'||'%'
  and not exists 
  (select 1 from wf_item_activity_statuses sta 
   where to_number(WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ACTIVITY_ID')) 
        = sta.process_activity
   and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        = sta.item_type(+)
   and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') 
        = sta.item_key(+)
  );

declare

 i number;
 root varchar2(200);
 item_exists number;

/*
 cursor err_items(errant_process_activity varchar) is
   select att.item_type                  ITEM_TYPE
         ,att.item_key                   ITEM_KEY
         ,PRA.PROCESS_NAME ||':'||
             PRA.INSTANCE_LABEL       ERROR_PROCESS_ACTIVITY_LABEL
         ,wf_engine.GETITEMATTRTEXT(att.item_type, att.item_key, 'ERROR_ITEM_TYPE', NULL) ERRANT_ITEM_TYPE
         ,wf_engine.GETITEMATTRTEXT(att.item_type, att.item_key, 'ERROR_ITEM_KEY', NULL) ERRANT_ITEM_KEY
   from wf_item_attribute_values  att
      , wf_item_activity_statuses sta
      , wf_process_activities     pra
   where att.item_type = 'WFERROR'
     and att.name = 'ERROR_ACTIVITY_LABEL'
     and att.text_value = errant_process_activity
     and sta.item_type = 'WFERROR'
     and sta.item_key  = att.item_key
     and sta.end_date is null 
     and sta.notification_id is not null
     and STA.PROCESS_ACTIVITY   = PRA.INSTANCE_ID;
*/

cursor err_items is
select distinct 
     itm.item_type item_type, 
     itm.item_key  item_key,
     PRA.PROCESS_NAME ||':'||
         PRA.INSTANCE_LABEL       ERROR_PROCESS_ACTIVITY_LABEL,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') errant_item_type,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') errant_item_key
from 
     wf_items                  itm,
     wf_item_activity_statuses sta,
     wf_item_activity_statuses errsta,
     wf_process_activities     pra
where itm.item_type = 'WFERROR'
  and itm.end_date is null
  and to_number(WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ACTIVITY_ID')) 
        = sta.process_activity
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        = sta.item_type(+)
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') 
        = sta.item_key(+)
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        like  '&itemtype'||'%'
  and sta.activity_status(+) <> 'ERROR'
  and errsta.item_type   = itm.item_type
  and errsta.item_key    = itm.item_key
  and errsta.end_date    is null
  and errsta.activity_status = 'NOTIFIED'
  and errsta.notification_id is not null
  and errsta.process_activity = pra.instance_id
UNION
select distinct /* handles those that are closed and purged */ 
     itm.item_type item_type, 
     itm.item_key  item_key,
     PRA.PROCESS_NAME ||':'||
         PRA.INSTANCE_LABEL       ERROR_PROCESS_ACTIVITY_LABEL,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') errant_item_type,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') errant_item_key
from 
     wf_items                  itm,
     wf_item_activity_statuses errsta,
     wf_process_activities     pra
where itm.item_type = 'WFERROR'
  and itm.end_date is null
  and errsta.item_type   = itm.item_type
  and errsta.item_key    = itm.item_key
  and errsta.end_date    is null
  and errsta.notification_id is not null
  and errsta.process_activity = pra.instance_id
  and errsta.activity_status = 'NOTIFIED'
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        like  '&itemtype'||'%'
  and not exists 
  (select 1 from wf_item_activity_statuses sta 
   where to_number(WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ACTIVITY_ID')) 
        = sta.process_activity
   and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        = sta.item_type(+)
   and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') 
        = sta.item_key(+)
  );


begin

    i:= 0;
    for e1 in err_items loop

      --dbms_output.put_line('Processing Item Type: ' || e1.ITEM_TYPE || ' Item Key: ' || e1.ITEM_KEY || 
      --           ' to retry ' || e1.ERRANT_ITEM_TYPE ||'/'||e1.ERRANT_ITEM_KEY);
     
      item_exists := 0;

      -- Check to make sure that there is an item that exists for the retry.
      -- If there is not we still want to retry the error to clear the worklist item, 
      -- but we do not want to execute the selector function.
      select count('1') 
      into item_exists
      from wf_items
      where item_type = e1.ERRANT_ITEM_TYPE
       and  item_key  = e1.ERRANT_ITEM_KEY;
 
      if item_exists > 0 then
        root := Wf_Engine_Util.Execute_Selector_Function(e1.ERRANT_ITEM_TYPE, e1.ERRANT_ITEM_KEY,'SET_CTX');
      end if;

      wf_engine.completeactivity(e1.ITEM_TYPE,e1.ITEM_KEY,e1.ERROR_PROCESS_ACTIVITY_LABEL,'RETRY');

      -- Commit after processing 20 records
      i:= i+1;
      if i = 20 then
        commit;
        i := 0;
      end if;

    end loop;

   commit;
end;
/
column item_type format a10;
column item_key  format a10;
column errant_item_type format a20;
column errant_item_key format a20;
select distinct 
     itm.item_type item_type, 
     itm.item_key  item_key,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') errant_item_type,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') errant_item_key
from 
     wf_items                  itm,
     wf_item_activity_statuses sta,
     wf_item_activity_statuses errsta,
     wf_process_activities     pra
where itm.item_type = 'WFERROR'
  and itm.end_date is null
  and to_number(WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ACTIVITY_ID')) 
        = sta.process_activity
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        = sta.item_type(+)
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') 
        = sta.item_key(+)
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        like  '&itemtype'||'%'
  and sta.activity_status(+) <> 'ERROR'
  and errsta.item_type   = itm.item_type
  and errsta.item_key    = itm.item_key
  and errsta.end_date    is null
  and errsta.activity_status = 'NOTIFIED'
  and errsta.notification_id is not null
  and errsta.process_activity = pra.instance_id
UNION
select distinct 
     itm.item_type item_type, 
     itm.item_key  item_key,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') errant_item_type,
     WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') errant_item_key
from 
     wf_items                  itm,
     wf_item_activity_statuses errsta,
     wf_process_activities     pra
where itm.item_type = 'WFERROR'
  and itm.end_date is null
  and errsta.item_type   = itm.item_type
  and errsta.item_key    = itm.item_key
  and errsta.end_date    is null
  and errsta.notification_id is not null
  and errsta.activity_status = 'NOTIFIED'
  and errsta.process_activity = pra.instance_id
  and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        like  '&itemtype'||'%'
  and not exists 
  (select 1 from wf_item_activity_statuses sta 
   where to_number(WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ACTIVITY_ID')) 
        = sta.process_activity
   and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_TYPE') 
        = sta.item_type(+)
   and WF_ENGINE.GetItemAttrText('WFERROR',itm.item_key,'ERROR_ITEM_KEY') 
        = sta.item_key(+)
  );

spool off;


