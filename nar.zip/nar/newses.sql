/* newses.sql
    show the new user sessions based on logon time < 30 secs ago
*/
col LastCallET     format a10
col sid format 9999
col sessprog format a25 trunc head PROGRAM
col username format a10 trunc
col osuser format a10 trunc
col lcet_hrs noprint
col lcet_min noprint
col lcet_sec noprint
set linesize 132
set verify off
col machine format a15 trunc
select 
   to_number(floor(last_call_et/3600)) lcet_hrs,
   to_number(floor(mod(last_call_et,3600)/60)) lcet_min,
   to_number(mod(mod(last_call_et,3600),60)) lcet_sec,
  to_char(s.logon_time, 'mm/dd hh:mi:ssAM') loggedon,
  s.sid, s.status,
   floor(last_call_et/3600)||':'||
   floor(mod(last_call_et,3600)/60)||':'||
   mod(mod(last_call_et,3600),60) "LastCallET",
 s.machine, s.osuser, 
 p.spid, nvl(s.module,p.program) sessprog,
  s.sql_hash_value
from v$session s, v$process p
where p.addr = s.paddr
  and type = 'USER'
  and logon_time > (sysdate - 1/2880)
  and nvl(s.username,'AQADMIN') != 'AQADMIN'
order by 1,2,3;
