-- @TablesInaTablespace.sql


undefine Tablespace

clear columns breaks compute

col owner for a15
col table_name for a30
col tablespace_name for a15 head 'Tablespace'

set head on pages 45 pau on lines 1000

spool spool\TablesInaTablespace_&_MyDB1.

select owner, table_name, num_rows, blocks, empty_blocks, avg_space, chain_cnt, row_movement, monitoring, avg_row_len, degree, cache, tablespace_name, pct_free, pct_used, initial_extent, next_extent, pct_increase, max_extents, cluster_name, iot_type, iot_name, partitioned, logging
from   dba_tables
where  tablespace_name = upper('&Tablespace');

spool off
