-- @Temp.sql

clear breaks computes columns

column "Init" format 999,999,999
column "Next" format 999,999,999
column "min/max" format a10
column pct format 999 heading "Pct|Inc"  
column tablespace_name format a10 heading "Tablespace"
column "SizeMB" for 999,999,999.99
column "SizeGB" for 999,999.99
column FILE_NAME for a50
col "SpaceMgmt" for a9
col AUTOEXTENSIBLE for a15

select  tablespace_name, initial_extent "Init", next_extent "Next", min_extents||'/'||max_extents "Min/Max", pct_increase pct_inc, status
      , contents, logging, extent_management "XtntMgmt", allocation_type "AllocType", SEGMENT_SPACE_MANAGEMENT "SpaceMgmt"
from    dba_tablespaces
where   contents = 'TEMPORARY';

select TABLESPACE_NAME, FILE_NAME, bytes/(1024*1024*1024) "SizeGB", STATUS, AUTOEXTENSIBLE, MAXBYTES/(1024*1024*1024) "MaxGB"
from   dba_temp_files;
