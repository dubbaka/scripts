col hobc noprint
col secnt head stmtexec
set verify off
set feedback off

accept spoolname char default spexec prompt 'Enter spool file name : '

alter session set sort_area_size = 102400000;

spool &spoolname

select * from v$sgastat;

prompt Getting shared pool info......

select 1 hobc,'>100000' secnt, 
  count(*),sum(sharable_mem)/1024/1024,sum(executions)
from v$sqlarea
where executions > 100000
union
select 2 hobc,'>10000' secnt,
  count(*),sum(sharable_mem)/1024/1024,sum(executions)
from v$sqlarea
where executions > 10000 and executions <= 100000
union
select 3 hobc,'>1000' secnt,
  count(*),sum(sharable_mem)/1024/1024,sum(executions)
from v$sqlarea
where executions > 1000 and executions <= 10000
union
select 4 hobc,'>100' secnt,
  count(*),sum(sharable_mem)/1024/1024,sum(executions)
from v$sqlarea
where executions > 100 and executions <= 1000
union
select 5 hobc,'> 10' secnt,
  count(*),sum(sharable_mem)/1024/1024,sum(executions)
from v$sqlarea
where executions > 10 and executions <= 100
union
select 6 hobc,'> 5' secnt,
  count(*),sum(sharable_mem)/1024/1024,sum(executions)
from v$sqlarea
where executions > 5 and executions <= 10
union
select 7 hobc,'> 2' secnt,
  count(*),sum(sharable_mem)/1024/1024,sum(executions)
from v$sqlarea
where executions > 2 and executions <= 5 
union
select 8 hobc,'<= 2' secnt,
  count(*),sum(sharable_mem)/1024/1024,sum(executions)
from v$sqlarea
where executions <= 2
order by 1 desc;

spool off

