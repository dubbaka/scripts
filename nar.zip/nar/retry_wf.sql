set serveroutput on
cursor a is

SELECT  NOTIFICATION_ID
FROM 
applsys.wf_notifications 
WHERE status = 'OPEN' 
  AND ORIGINAL_RECIPIENT = 'SYSADMIN' 
  AND subject like '%recompilation%'
  AND MESSAGE_TYPE = 'WFERROR'

begin

fnd_global.apps_initialize(0,20420,1);


for i in a
loop

wf_notification.respond(i.notification_id, 'Closing from API', 'SYSADMIN');

end loop;

end;

