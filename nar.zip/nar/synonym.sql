col owner for a20
col TABLE_OWNER for a20
col SYNONYM_NAME for a30
col TABLE_NAME for a30

select *
from   dba_synonyms
where  SYNONYM_NAME = upper('&Synonym');
