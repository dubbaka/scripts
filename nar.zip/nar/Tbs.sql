-- @tbs.sql

clear columns breaks computes

col tablespace_name for a30
col BIGFILE for a7
col "SpaceMgmt" for a9
col FORCE_LOGGING for a8 head "Force|Logging"
col "XtntMgmt" for a8
col PLUGGED_IN for a8 head "Plugged|In"
col DEF_TAB_COMPRESSION head "Compression"

set lines 250 veri off

accept vTABLESPACE_NAME char default ALL prompt 'Tablespace <ALL> : '
accept vCONTENTS char default ALL prompt 'Contents [PERMANENT | TEMPORARY | UNDO] <ALL> : '
accept vSpaceMgmt char default ALL prompt 'Segment Space Management [AUTO | MANUAL] <ALL> : '
accept vLOGGING char default ALL prompt 'Segment Space Management [LOGGING | NOLOGGING] <ALL> : '
accept vAllctnTyp char default ALL prompt 'Allocation Type [SYSTEM | UNIFORM] <ALL> : '


select TABLESPACE_NAME, CONTENTS, SEGMENT_SPACE_MANAGEMENT "SpaceMgmt", BLOCK_SIZE, STATUS, LOGGING, 
       EXTENT_MANAGEMENT "XtntMgmt", ALLOCATION_TYPE "AllctnType", BIGFILE, FORCE_LOGGING, PLUGGED_IN, DEF_TAB_COMPRESSION
     , initial_extent, next_extent, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE
from   dba_tablespaces
where  (TABLESPACE_NAME like upper('&vTABLESPACE_NAME') or upper('&vTABLESPACE_NAME') = 'ALL') 
and    (CONTENTS like upper('&vCONTENTS') or upper('&vCONTENTS') = 'ALL') 
and    (SEGMENT_SPACE_MANAGEMENT like upper('&vSpaceMgmt') or upper('&vSpaceMgmt') = 'ALL') 
and    (LOGGING like upper('&vLOGGING') or upper('&vLOGGING') = 'ALL') 
and    (ALLOCATION_TYPE like upper('&vAllctnTyp') or upper('&vAllctnTyp') = 'ALL') 
order  by TABLESPACE_NAME;


select TABLESPACE_NAME,
round(sum(BYTES)/(1024*1024)) as current_size,
sum( MAXBYTES)/(1024*1024) as max_size,
round(((sum(bytes)/sum( MAXBYTES)))*100,2) as percentage
from dba_data_files
where (TABLESPACE_NAME like upper('&vTABLESPACE_NAME') or upper('&vTABLESPACE_NAME') = 'ALL')  and MAXBYTES>0
and tablespace_name not like 'APPS_UNDOTS%'
group by TABLESPACE_NAME
order by 4
/
