-- @TbsDBFs.sql


select count(1) "Tablespaces" from dba_tablespaces;
select count(1) "DatabaseFiles" from dba_data_files;
select EXTENT_MANAGEMENT, count(1) from dba_tablespaces group by EXTENT_MANAGEMENT;
select ALLOCATION_TYPE, count(1) from dba_tablespaces group by ALLOCATION_TYPE;
select SEGMENT_SPACE_MANAGEMENT, count(1) from dba_tablespaces group by SEGMENT_SPACE_MANAGEMENT;
