rem #############################################################################
rem File 	: TblSize.sql
rem Author	: Ravi Peesapati
rem Run As	: SYSTEM (SELECT ANY TABLE)
rem Use		: List Tables/Indexes greater than a specified Size or Number of Extents.
rem Output	: 
rem ##############################################################################

clear columns breaks computes

set wrap on  verify off lines 180

col owner for a10
col segment_name for a30
col initial_extent heading "Initial|Extent"
col next_extent heading "Next|Extent"
col pct_increase heading "Pct|Increase"
col "SizeMB" for 99999

select owner, segment_name, extents, max_extents, (bytes/1024) "SizeKB", bytes/(1024*1024) "SizeMB", 
       initial_extent, next_extent, blocks, pct_increase
from   dba_segments
where  segment_type = 'INDEX'
and    segment_name = upper('&Segment');
