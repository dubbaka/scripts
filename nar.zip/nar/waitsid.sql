select waiting_Session, holding_Session from dba_waiters
