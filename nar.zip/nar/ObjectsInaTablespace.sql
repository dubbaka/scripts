-- @ObjectsInaTablespace.sql


clear columns breaks compute

col TABLESPACE_NAME for a20
col OWNER for a12
col SEGMENT_TYPE for a20
col SEGMENT_NAME for a30
col "MB" for 999,999,999

set veri off lines 132 pages 5000

break on report
compute sum of "NoOfObjects" "MB" on report

accept tgtTbs char default ALL prompt 'Tablespace : '
accept tgtOwner char default ALL prompt 'Owner <ALL> : '

spool spool\ObjectsInaTablespace_&tgtTbs._&tgtOwner._&_MyDB1.

select TABLESPACE_NAME, OWNER, SEGMENT_TYPE, count(1) "NoOfObjects", sum(BYTES)/(1024*1024) "MB"
from   DBA_SEGMENTS
where (TABLESPACE_NAME = upper('&tgtTbs') or upper('&tgtTbs') = 'ALL')
and   (OWNER = upper('&tgtOwner') or upper('&tgtOwner') = 'ALL')
group  by TABLESPACE_NAME, OWNER, SEGMENT_TYPE;

select TABLESPACE_NAME, OWNER, SEGMENT_TYPE, SEGMENT_NAME, BYTES/(1024*1024) "MB", PARTITION_NAME
from   DBA_SEGMENTS
where (TABLESPACE_NAME = upper('&tgtTbs') or upper('&tgtTbs') = 'ALL')
and   (OWNER = upper('&tgtOwner') or upper('&tgtOwner') = 'ALL')
order  by OWNER, SEGMENT_TYPE, SEGMENT_NAME;

spool off

clear columns breaks compute
