-- @cmbetween.sql
-- Displays Concurrent requests that started between a given StartTime and EndTime

clear columns breaks computes

set feed off
col datenow new_value _MyDateNow noprint
select to_char(sysdate, 'DDmonYY') "datenow" from dual;
set feed on

set pages 50000 pau off lines 500

col user_concurrent_program_name head "ProgramName" for a50
col "Start Time" for a21
col "End Time" for  a21
col "Requestor" for a15
col "Description" head "Username" for a80
col EMAIL_ADDRESS for a50
col "RequestsRun" for 99,999,999
col phase_code for a3
col status_code for a3
col "FirstStartDate" for a24
col "LastStartDate" for a24
col phase_code head "P|H|A|S|E"
col status_code head "S|T|A|T|U|S"

accept tgtStartTime char default "&_MyDateNow 00:00:01" prompt 'Starting at <DDmonYY HH24:MI:SS> : &_MyDateNow 00:00:01 = '
accept tgtEndTime   char default "&_MyDateNow 23:59:59" prompt 'Ending   at <DDmonYY HH24:MI:SS> : &_MyDateNow 23:59:59 = '

spool spool\cmbetween_&_MyDateNow._&_MyDB1.

prompt Displays Concurrent Programs started between the dates   &tgtStartTime   and   &tgtEndTime   (irrespective of completion time)

select count(1) "RequestsRun"
     , min(to_char(r.actual_start_date,'DD-Mon-YYYY HH24:MI:SS')) "FirstStartDate"
     , max(to_char(r.actual_start_date,'DD-Mon-YYYY HH24:MI:SS')) "LastStartDate"
from   apps.fnd_concurrent_requests r
where  r.actual_start_date is not null
and    to_date(to_char(r.actual_start_date,'DDmonYY HH24:MI:SS'),'DDmonYY HH24:MI:SS') between to_date('&tgtStartTime','DDmonYY HH24:MI:SS') and to_date('&tgtEndTime'  ,'DDmonYY HH24:MI:SS');


accept Enter char prompt 'Press Enter for very detailed Request wise output or CTRL-C to cancel'


select r.request_id "Request Id", phase_code, status_code, p.user_concurrent_program_name,
       to_char(actual_start_date,'DD-Mon-yyyy HH24:MI:SS') "Start Time",
       to_char(actual_completion_date,'DD-Mon-yyyy HH24:MI:SS') "End Time",
       u.user_name "Requestor", u.DESCRIPTION, u.EMAIL_ADDRESS
from   apps.fnd_concurrent_requests r, apps.fnd_concurrent_programs_vl p,apps.fnd_application f, apps.fnd_user u
where  r.program_application_id = p.application_id
and    r.concurrent_program_id  = p.concurrent_program_id
and    p.application_id         = f.application_id
and    r.program_application_id = f.application_id
and    r.requested_by           = u.user_id
and    r.actual_start_date is not null
and    to_date(to_char(r.actual_start_date,'DDmonYY HH24:MI:SS'),'DDmonYY HH24:MI:SS') between to_date('&tgtStartTime','DDmonYY HH24:MI:SS') and to_date('&tgtEndTime'  ,'DDmonYY HH24:MI:SS')
order  by r.actual_start_date;

spool off

prompt 1) For current running requests or status of a specific concurrent request use --> @cmrun2.sql
prompt 2) For historical analysis of a specific Concurrent Pgm use --> @cmrun1.sql
prompt 3) For further detailed analysis of a specific concurrent request use --> @cmAnalReq.sql
prompt 4) For getting Average run time analysis for a specifc concurrent program or all Concurrent programs (for today or for all days) use --> @cmAvgRunTime.sql
prompt 5) For individual or all Concurrent queue request analysis use --> @cmStats.sql
prompt 6) For displaying a specific or all Concurrent Manager que details (including work shifts) use --> @cms.sql
