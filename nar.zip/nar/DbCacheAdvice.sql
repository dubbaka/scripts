-- @DbCacheAdvice.sql

clear columns breaks computes

col size_for_estimate head "Cache Size (Mb)" for 999,999,999
col buffers_for_estimate head "Buffers" for 999,999,999
col estd_physical_read_factor head "Read Factor" for 999,999,999.999
col estd_physical_reads head "Estimated Reads" for 999,999,999,999

break on inst_id skip 1

select INST_ID, size_for_estimate , buffers_for_estimate , estd_physical_read_factor , estd_physical_reads
from   gv$db_cache_advice
order  by buffers_for_estimate;

clear columns breaks computes
