/* last10jobs.sql
	copied from jobhistdet.sql
      find the details of all jobs run for the given job id
      use jobid.sql to find a ccmgr job id if you have either
	 the regular or short name
*/
set lines 132
col request_id head "Request ID"
col actstrtdte head "Started On" format a9
col actcmpldte head "Finished On" format a9
col Time format 9,999.09
col argument_text head Arguments format a60
accept progid number default 0 prompt 'What is the program ID : '
select * from (
select request_id,phase_code,status_code, 
       to_char(actual_start_date,'mm/dd/yy hh24:mi:ss') actstrtdte, 
       to_char(actual_completion_date,'mm/dd/yy hh24:mi:ss') actcmpldte, 
       (nvl(actual_completion_date,sysdate)-actual_start_date)*1440 "Time",
       argument_text
from applsys.fnd_concurrent_requests
where concurrent_program_id = &progid
and actual_start_date is not null
order by actual_start_date desc)
where rownum < 100
and phase_code = 'C'
and status_code = 'C';

