col owner format a15
col name format a30
col exec2load format 99,999,999
set lines 132
set pause off
set feedback off
select owner, name, type, loads, executions, 
	executions/loads exec2load,
	sharable_mem
from v$db_object_cache
where type in ('SEQUENCE','PROCEDURE','PACKAGE','PACKAGE BODY','FUNCTION','TRIGGER')
and kept = 'NO'
and loads > 1
order by loads, owner, type;



