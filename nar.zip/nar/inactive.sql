/* inactive.sql
    shows the inactive user sessions
	where lastcallet > 90 minutes
	and session is a user session
  SDR-Oracle 6/21/02 - sourced from my top10inactive.sql
  SDR-Oracle 7/9/02 - added app process to ouput
*/
set serveroutput on size 100000
set verify off
set feedback off
declare
	v_sidctr number := 0;
	v_spidctr number := 0;

	v_inact_threshold number := 90;
	v_uctr number:= 0;
	v_trgtsid number := 0;
 	v_shortname varchar(30);
	v_longname varchar(45);
	v_prevspid varchar(9) := '0';
	v_usertype varchar(8);
	v_umachine varchar(10);
 	v_lastcallet number;
	v_loggedon varchar(16);

	-- cursor for all inactive users over the threshold
	cursor aiu is 
	select 'TOAD' usertype,
  		s.sid, 
  		floor(last_call_et/60) lastcallet,
  		p.spid, 
  		s.module uprogram,
  		substr(replace(s.machine,'GEIPS-AMER\',null),1,10) umachine,
  		s.osuser,
		s.username,
		to_char(s.logon_time, 'mm/dd hh:mi:ssAM') loggedon,
		s.process appproc
	   from v$session s, v$process p
	  where p.addr = s.paddr
  		and s.type = 'USER'
  		and module is not null
  		and s.status = 'INACTIVE'
  		and floor(last_call_et/60) > v_inact_threshold
  		and (machine not like 'gps%' and upper(module) like 'T%O%A%D%')
	union 
	select 'FORMS' usertype,
  		s.sid,
  		floor(last_call_et/60) lastcallet,
  		p.spid, 
  		nvl(s.module,'UNKnown') uprogram,
  		s.machine umachine,
  		s.osuser,
		s.username,
                to_char(s.logon_time, 'mm/dd hh:mi:ssAM') loggedon,
		s.process appproc
	   from v$session s, v$process p
	  where p.addr = s.paddr
  	  	and s.type = 'USER'
  		and s.status = 'INACTIVE'
  		and floor(last_call_et/60) > v_inact_threshold
  		and machine in ('gpsd011','gpsd012')
  		and nvl(module,'UNKnown') not like '%JAVA%'
	union 
	select 'SQLPLUS' usertype,
  		s.sid,
  		floor(last_call_et/60) lastcallet,
  		p.spid,
  		s.module uprogram,
  		substr(replace(s.machine,'GEIPS-AMER\',null),1,10) umachine,
  		s.osuser,
		s.username,
                to_char(s.logon_time, 'mm/dd hh:mi:ssAM') loggedon,
		s.process appproc
	   from v$session s, v$process p
          where p.addr = s.paddr
		and s.type = 'USER'
  		and module is not null
  		and s.status = 'INACTIVE'
  		and floor(last_call_et/60) > v_inact_threshold
  		and upper(module) like 'SQL%'
  		and ((s.machine = 'gpsd002a' and s.username != 'APPS') or (s.machine like 'GE%'))
	order by 4,3 desc;

begin
	-- do it
	<<each_sid>>
	for eu in aiu
	loop
		v_usertype := eu.usertype;
		v_umachine := eu.umachine;
		v_lastcallet := eu.lastcallet;
		v_loggedon := eu.loggedon;

		if v_prevspid != eu.spid then
			dbms_output.put_line('OSProc:' || eu.spid || chr(9) || v_usertype || ' user from ' || v_umachine ||
						' (' || eu.appproc || ') logged on at ' || v_loggedon);
			v_prevspid := eu.spid;
			v_spidctr := v_spidctr + 1;

			begin
			-- determine the apps forms user
			if eu.usertype = 'FORMS' then
				v_trgtsid := eu.sid;
				select count(*),
       					u.user_name, u.description
			  	into v_uctr,
  					v_shortname, v_longname
		  	  	from applsys.fnd_logins l,
       					applsys.fnd_user u,
       					v$process p,
       					v$session s
 			  	where s.sid = v_trgtsid
   			    	  and s.paddr = p.addr
   			          and p.pid = l.pid
   			          and l.end_time is null
   			          and l.spid = s.process
   			          and l.start_time is not null
   			          and l.user_id = u.user_id
   			          and l.start_time = (select max(l2.start_time)
                         			  from applsys.fnd_logins l2
                        			 where l2.pid = l.pid)
			      group by u.user_name, u.description;

			else v_shortname := eu.username;

		       end if;		-- end of if a forms user

		       exception
			when others then 
				v_shortname := 'UNKnown';
				v_longname := null;
		       end;

		end if; 	-- end of if a new spid

		-- provide the individual SID info
		dbms_output.put_line(chr(9) || 'SID:' || eu.sid || ', User ' || v_shortname || ' - ' || eu.uprogram ||
					' ' || v_lastcallet || ' minutes inactive');
		v_sidctr := v_sidctr + 1;

	end loop each_sid;

	dbms_output.put_line(v_spidctr || ' total OSProcs to kill');
	dbms_output.put_line(v_sidctr || ' total SIDs affected');
end;
/

