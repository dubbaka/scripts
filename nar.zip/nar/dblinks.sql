-- @dblinks.sql



-- grant select on sys.link$ to system;
-- grant select on sys.link$ to apps;

clear columns breaks computes

set lines 300

col owner for a18
col DB_LINK for a25
col USERNAME for a10
col HOST for a132
col "Created" for a18

-- PUBLIC DATABASE links
select a.OWNER, a.DB_LINK, a.USERNAME, to_char(a.CREATED, 'dd-Mon-yy hh24:mi') "Created", a.HOST
from   dba_db_links A
order  by 1,2;

-- PRIVATE DATABASE links
