/* ckfsstat.sql
     show the file stats for a given filesystem
*/
set lines 132
col name head "File Name" format a45
col ufsmt noprint
col mbratio head RdRatio format 999.90
col avgrdtim format 9,999.90 
set verify off
break on ufsmt skip 1
accept trgtfs char default ALL prompt 'What filesystem mount point <all> : '
select substr(d.name,8,(instr(d.name,'/',9,1) -8)) ufsmt,
       d.name,
       f.phyrds,
       f.phyblkrd,
       f.phyblkrd / decode(f.phyrds,0,1,f.phyrds) mbratio,
       f.readtim / decode(f.phyrds,0,1,f.phyrds) avgrdtim,
       f.maxiortm,
       f.phywrts,
       f.phyblkwrt,
       f.lstiotim
from v$filestat f, v$datafile d
where f.file# = d.file#
and (substr(d.name,8,(instr(d.name,'/',9,1) -8)) = '&trgtfs' or upper('&trgtfs') = 'ALL')
order by 1,5,2;


