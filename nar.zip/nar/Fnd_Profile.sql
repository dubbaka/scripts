-- @FndProfile.sql


col "Profile Level" for a12
col "Non-Site Desc" for a30
col "User Name" for a10
col "Profile Option Name" for a50
col "Value" for a100
col "last updated by" for a15
col "last updated on" for a22

SELECT DECODE(level_id,10001,'Site',10002,'Application',10003,'Responsibility',10004,'USER') "Profile Level"
           , DECODE(level_id,10001,NULL,10002,fa.application_name,10003,fr.responsibility_name,10004,fu.user_name) "Non-Site Desc"
                , fu.user_name                  "User Name"
                , fpov.user_profile_option_name "Profile Option Name"
                , fpova.profile_option_value    "Value"
                , fu2.user_name                 "last updated by"
                , to_char(fpova.LAST_UPDATE_DATE,'mm/dd/yy hh24:mi')       "last updated on"
FROM   fnd_profile_options_vl fpov  , fnd_profile_option_values fpova , fnd_application_tl fa  -- table inclusion when looking at application joins
        , fnd_responsibility_tl fr  -- table inclusion when looking at responsibility joins
        , fnd_user fu  -- table inclusion when looking at user joins
        , fnd_user fu2
WHERE  fpov.application_id = fpova.application_id
AND    fpov.profile_option_id = fpova.profile_option_id
AND    start_date_active <= SYSDATE
AND    NVL(end_date_active,SYSDATE) >= SYSDATE
AND   (site_enabled_flag = 'Y' OR app_enabled_flag = 'Y' OR resp_enabled_flag = 'Y' OR user_enabled_flag = 'Y')
AND    fpova.level_value = fa.application_id (+) -- join for application values
AND    fpova.level_value = fr.responsibility_id (+)  -- join for responsibility values
AND    fpova.level_value = fu.user_id (+) -- join for user values
AND    fpova.last_updated_by = fu2.user_id (+)  -- join for update by user values
AND    fpova.profile_option_value like '%&Val%'
ORDER  BY "Profile Option Name", "Profile Level"
/
