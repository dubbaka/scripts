-- @cmWhatPgm.sql


clear columns breaks compute

col os for A7 head AppProc
col spid for a6 head DBProc
col "ConcPgm" for a100
col time for 999,999.99 head 'Elapsed|(Mins)'
col "Req Id" for 99999999
col "Parent" for a8
col "Prg Id" for 999999999
col qname head "Concurrent Manager Queue" for a40
col sid for 99999 head SID

accept ReqID number default 99 prompt 'What is the Request ID <ALL> : '
accept ShrtConcPgm char default ALL prompt 'What is the ShortName of ConcPgm <ALL> : '
accept FullConcPgm char default ALL prompt 'What is the UserName of ConcPgm <ALL> : '

select a.request_id "Req Id" ,q.concurrent_queue_name || ' - ' || target_node qname 
      ,c.concurrent_program_name||' - '||c2.user_concurrent_program_name "ConcPgm"
from APPLSYS.fnd_Concurrent_requests a , APPLSYS.fnd_concurrent_processes   b
    ,applsys.fnd_concurrent_queues   q , APPLSYS.fnd_concurrent_programs_tl c2
    ,APPLSYS.fnd_concurrent_programs c
where (a.REQUEST_ID = &ReqID or &ReqID = 99)
  and (c.concurrent_program_name = '&ShrtConcPgm' or '&ShrtConcPgm' = 'ALL')
  and (c2.user_concurrent_program_name like '&FullConcPgm%' or '&FullConcPgm' = 'ALL')
  and a.concurrent_program_id = c.concurrent_program_id
  and a.program_application_id = c.application_id
  and c2.concurrent_program_id = c.concurrent_program_id
  and b.queue_application_id = q.application_id
  and b.concurrent_queue_id = q.concurrent_queue_id
  and c2.language = 'US'
  and rownum < 2;

