-- @crt_logoff_tbls.sql

drop table system.my_session_event_history;
create table system.my_session_event_history tablespace users
storage (FREELISTS 6 FREELIST GROUPS 6) initrans 6 as
select s.sid, s.serial#, s.process, p.spid, s.username, s.osuser, s.machine, s.module, s.program, s.logon_time, s.last_call_et, s.type, s.sql_hash_value, s.action
     , a.average_wait, a.max_wait, a.event, a.total_waits, a.total_timeouts, a.time_waited, sysdate as logoff_timestamp, a.WAIT_CLASS
from   v$session_event a, v$session s, v$process p
where  1 = 2;

drop table system.my_sesstat_history;
create table system.my_sesstat_history tablespace users
storage (FREELISTS 6 FREELIST GROUPS 6) initrans 6 as
select s.sid, s.serial#, s.process, p.spid, s.username, s.osuser, s.machine, s.module, s.program, s.logon_time, s.last_call_et, s.type, s.sql_hash_value, s.action
     , a.statistic#, b.name, a.value, sysdate as logoff_timestamp, 'Event class is what I want to store here' WAIT_CLASS
from   v$sesstat a, v$statname b, v$session s, v$process p
where  1 = 2;
