-- @TopSystemEvents.sql

clear columns breaks computes

set lines 2000 numwidth 18 pages 10000 pau off trimspool on colsep |

col "EventShort"      for a30 trunc
col "TimeSpent(Mins)" for 9,999,999,999.99
col "TimeSpent(Hrs)"  for 99,999.99
col total_waits       for 999,999,999,999
col total_timeouts    for 999,999,999,999
col time_waited       for 999,999,999,999
col "StartupTime"     for a15


select event "EventShort", (time_waited/(100*60*60)) "TimeSpent(Hrs)", total_waits, total_timeouts, to_char(b.startup_time, 'dd-Mon-yy hh24:mi') "StartupTime", event
from   v$system_event a, v$instance b
where event not in (
'Null event'
,'client message'
,'KXPK: Execution Message Dequeue - Slave'
,'PX Deq: Table Q Normal'
,'Wait for credit - send blocked'
,'PX Deq: Credit: send blkd'
,'Wait for credit: need buffer to send'
,'PX Deq: Credit: need buffer'
,'Wait for credit: free buffer'
,'PX Deq: Credit: free buffer'
,'parallel query dequeue wait'
,'PX Deque wait'
,'Parallel Query Idle Wait - Slaves'
,'PX Idle Wait'
,'slave wait'
,'dispatcher timer'
,'virtual circuit status'
,'pipe get'
,'rdbms ipc message'
,'rdbms ipc reply'
,'pmon timer'
,'smon timer'
,'PL/SQL lock timer'
,'SQL*Net message from client'
,'WMON goes to sleep'
,'Streams AQ: qmn slave idle wait'
,'Streams AQ: qmn coordinator idle wait'
,'Streams AQ: waiting for time management or cleanup tasks'
,'jobq slave wait'
,'class slave wait'
,'os thread startup'
,'Streams AQ: qmn coordinator waiting for slave to start'
,'PX Deq: Par Recov Execute'
,'Streams AQ: waiting for messages in the queue'
,'PX Deq: Par Recov Reply'
,'PX Deq: Test for msg'
,'PX Deq: Par Recov Change Vector'
,'PX Deq: Signal ACK'
,'reliable message'
,'SQL*Net message to client'
,'PX Deq Credit: send blkd'
,'PX Deq: Join ACK'
)
order by a.time_waited desc;
