/* sorttypes.sql
    see the total sort segment types
*/
break on report
compute sum of mbused on report
col noexts format 9999 head EXTS
col mbused format 999,999.90
set verify off
accept trgtuser char default ALL prompt 'What is the user <all> : '
select count(*),
   u.tablespace,
   sum(u.blocks*p.value/1024/1024) mbused ,
   sum(u.extents) noexts, 
   u.segtype
from v$sort_usage u, v$session s, v$parameter p
where u.session_addr = s.saddr
and (s.username = upper('&trgtuser') or upper('&trgtuser') = 'ALL')
and p.name = 'db_block_size'
group by tablespace, u.segtype
order by 1
/

