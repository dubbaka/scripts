-- user.sql


clear columns breaks computes

set pages 40 pau on

column application_name format a20
column responsibility_name format a40
column user_name format a15
column start format a10
column end format a10

break on user_name skip page

select USER_NAME, substr(application_name,1,20) application_name, RESPONSIBILITY_NAME
     , to_char(usergroup.start_date,'DD-MON-YY') "start", to_char(usergroup.end_date,'DD-MON-YY') "end"
from   fnd_responsibility fndresp, fnd_responsibility_vl fndrespvl, fnd_user fnduser
     , fnd_user_resp_groups usergroup, fnd_application_vl appl
where  fndresp.RESPONSIBILITY_ID = fndrespvl.RESPONSIBILITY_ID
and    fndresp.RESPONSIBILITY_ID = usergroup.RESPONSIBILITY_ID
and    fnduser.USER_ID = usergroup.user_id
and    fndresp.application_id = appl.application_id
and    user_name like '%'||'&user_name'||'%'
and   (usergroup.end_date is null or usergroup.end_date > sysdate)
order  by user_name, application_name, responsibility_name;

set pages 2000 pau off
