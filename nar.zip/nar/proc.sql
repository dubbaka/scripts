-- @proc.sql

clear columns breaks compute

col SID       for 99999
col "SERIAL#" for 999999
col PROCESS head "OSpid|APnode" for a9
col SPID head "OSpid|DBnode" for a6
col STATUS    for a8
col LastCallET head "LastCallEt|(hh:mi:ss)" for a11
col machine   for a15
col module    for a30
col "Process PGM" for a30
col username  for a8
col osuser    for a8
col schemaname head "Schema" for a8
col "Logged In At" for a20
col PQ_STATUS head "PQStatus"
col EVENT for a40 trunc
col SERVICE_NAME for a15
col CLIENT_INFO for a10
col SQL_TRACE head "SQL|Trace" for a8
col SQL_TRACE_WAITS head "SQL|Waits" for a5
col SQL_TRACE_BINDS head "SQL|Binds" for a5
col "p1:p2:p3" for a100

set verify off trim on

accept trgtOSproc char default ALL prompt 'DB OS PID <ALL> : '
accept trgtOraproc char default ALL prompt 'APP PID <ALL> : '
accept trgtSID number default 9999 prompt 'SID <ALL> : '
accept trgtSqlId char default ALL prompt 'SqlId <ALL> : '
accept trgtModule char default ALL prompt 'Module <ALL> : '

select s.inst_id, s.sid, s.serial#, s.process, p.spid, s.status,
       floor(s.last_call_et/3600)||':'||floor(mod(s.last_call_et,3600)/60)||':'||mod(mod(s.last_call_et,3600),60) "LastCallET",
       to_char(s.LOGON_TIME,'DDMonYY HH:MI:SS AM') "Logged In At",
       s.sql_hash_value, s.machine, s.module, s.server,
       p.PROGRAM "Process PGM", p.PID, p.USERNAME, s.osuser, s.CLIENT_INFO,
       s.action, s.lockwait, s.schemaname, s.program, s.type, s.ROW_WAIT_FILE#, s.ROW_WAIT_BLOCK#, s.ROW_WAIT_ROW#,
       s.PQ_STATUS, s.action
from   gv$session s, gv$process p
where s.inst_id = p.inst_id
and   s.paddr   = p.addr
and   (s.sid     =  &trgtSID      or &trgtSID = 9999)
and   (p.spid    = '&trgtOSproc'  or upper('&trgtOSproc')  = 'ALL')
and   (s.process = '&trgtOraproc' or upper('&trgtOraproc') = 'ALL')
and   (s.module  = '&trgtModule'  or upper('&trgtModule')  = 'ALL')
and   (s.sql_id  = '&trgtSqlId'   or upper('&trgtSqlId')   = 'ALL');
