break on sid skip 1
select b.sid, sql_text
from v$sqltext a, v$session b, v$session_wait c
where a.hash_value = b.sql_hash_value
and c.event not in ('SQL*Net message from client','rdbms ipc message',
'pmon timer','smon timer', 'pipe get')
and b.sid = c.sid
and b.program like 'JDBC%'
order by b.sid,hash_value,piece
/
