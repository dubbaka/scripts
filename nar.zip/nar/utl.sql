select value from v$parameter2 where name like '%utl%';
