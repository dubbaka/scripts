col application_short_name format a5 head App
col user_form_name format a35 trunc head FormName
col num_runs format 99999 head Total
col users format 99999
col days format 9999
col users format 99999
col 7AM format 9999
col 8AM format 9999
col 9AM format 9999
col 10AM format 9999
col 11AM format 9999
col Noon format 9999
col 1PM format 9999
col 2PM format 9999
col 3PM format 9999
col 4PM format 9999
col 5PM format 9999
col 6PM format 9999
col 7PM format 9999

select application_short_name, user_form_name,
count(distinct(log.user_id)) users,
count(distinct(trunc(l.start_time))) days,
sum(decode(to_char(l.start_time, 'HH24'),'07',1,0)) "7AM", 
sum(decode(to_char(l.start_time, 'HH24'),'08',1,0)) "8AM", 
sum(decode(to_char(l.start_time, 'HH24'),'09',1,0)) "9AM", 
sum(decode(to_char(l.start_time, 'HH24'),'10',1,0)) "10AM", 
sum(decode(to_char(l.start_time, 'HH24'),'11',1,0)) "11AM", 
sum(decode(to_char(l.start_time, 'HH24'),'12',1,0)) "Noon", 
sum(decode(to_char(l.start_time, 'HH24'),'13',1,0)) "1PM", 
sum(decode(to_char(l.start_time, 'HH24'),'14',1,0)) "2PM", 
sum(decode(to_char(l.start_time, 'HH24'),'15',1,0)) "3PM", 
sum(decode(to_char(l.start_time, 'HH24'),'16',1,0)) "4PM", 
sum(decode(to_char(l.start_time, 'HH24'),'17',1,0)) "5PM", 
sum(decode(to_char(l.start_time, 'HH24'),'18',1,0)) "6PM", 
sum(decode(to_char(l.start_time, 'HH24'),'19',1,0)) "7PM"
from applsys.fnd_login_resp_forms l, applsys.fnd_form_tl f, applsys.fnd_application a,
	applsys.fnd_logins log
where l.form_appl_id = f.application_id
and l.form_id = f.form_id
and f.application_id = a.application_id
and f.language = 'US'
and l.start_time > '31-Jan-2002'
and to_char(l.start_time, 'DAY') NOT LIKE 'SUNDAY%'
AND to_char(l.start_time, 'DAY') NOT LIKE 'SATURDAY%'
and 	to_char(l.start_time, 'HH24') between '07' and '19'
and log.login_id = l.login_id
group by application_short_name,user_form_name
order by 1,2;
