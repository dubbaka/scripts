set verify off
col bgpe format 999,999,999
col drpe format 999,999,999
col first_load_time format a18 trunc
col subsqltxt format a60 trunc head SQL_TEXT_60
accept trgthash number default 0 prompt 'What is the SQL hash value : '
select hash_value,executions,buffer_gets,disk_reads,sorts,first_load_time,
       buffer_gets/decode(executions,0,1,executions) bgpe, 
       disk_reads/decode(executions,0,1,executions) drpe,
       substr(sql_text,1,60) subsqltxt
from v$sqlarea
where hash_value = &trgthash
and hash_value <> 0;

