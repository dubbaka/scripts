-- @IndexesUnusable.sql

set lines 400 wrap on
clear columns breaks computes

col OWNER for a12
col INDEX_NAME for a35
col TABLESPACE_NAME for a15
col TABLE_OWNER for a12
col TABLE_NAME for a30
col INDEX_TYPE for a12

select OWNER, INDEX_NAME, STATUS , NUM_ROWS, TABLESPACE_NAME, INDEX_TYPE, TABLE_OWNER, TABLE_NAME, TABLE_TYPE, DEGREE
from   DBA_INDEXES
where  STATUS = 'UNUSABLE'
order  by OWNER, INDEX_NAME;

accept junk1 char prompt "Press enter for generating SQL statements that can be used for rebuilding unusable Indexes ....."

prompt Use following statements to rebuild the indexes
select 'alter index '||OWNER||'.'||INDEX_NAME||' rebuild parallel 2;'
from   DBA_INDEXES
where  STATUS = 'UNUSABLE'
order  by OWNER, INDEX_NAME;

clear columns breaks computes
