col name format a10
col usn format 9999
col xacts format 9999
col extents format 9999
col rssmb format 9,999.90 head CurrSize
col hwsmb format 99,999.90 head HWMSize
col tablespace_name format a10 trunc
col status format a3 trunc head STS
col tbsgb format 99999.90
break on tablespace_name skip 1 on tbsgb nodup
compute sum of rssmb on tablespace_name
compute sum of hwsmb on tablespace_name
set lines 132
select d.tablespace_name, 
	sum(f.bytes)/1024/1024/1024 TBSGB,
	s.usn,n.name,xacts,optsize,s.extents,
	rssize/1024/1024 rssmb,
       hwmsize/1024/1024 hwsmb,s.status
from v$rollstat s, v$rollname n, dba_rollback_segs d, dba_data_files f
where s.usn = n.usn
and d.segment_name = n.name
and f.tablespace_name = d.tablespace_name
group by d.tablespace_name, s.usn,n.name,xacts,optsize,s.extents,
	rssize/1024/1024, hwmsize/1024/1024, s.status
order by 1,3
/

