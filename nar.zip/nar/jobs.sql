-- @jobs.sql


clear columns breaks computes

set lines 2000 veri off

col what for a300
col interval for a30
col PRIV_USER for a12
col log_user for a12
col schema_user for a12


select job, instance, interval, log_user, PRIV_USER, schema_user, LAST_DATE, THIS_DATE, NEXT_DATE, TOTAL_TIME, BROKEN, FAILURES, what
from dba_jobs
order by job;
