-- @DBObjRpt.sql

clear columns breaks computes

set pages 50000 lines 2000 feed off pau off timing on time off echo off trim on trimspool on colsep |


prompt Object Wise count stats in the database
col "ObjType" for a30
col OWNER for a25
col "Cnt" for 99999999

col "TimeNow"      for a18
col pHost for a10
col pSid for a10

col mysid new_value _MySID noprint
col myhost new_value _MyHOST noprint
select INSTANCE_NAME mysid , HOST_NAME myhost  from v$instance;

select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", count(1) "Cnt" from dba_objects;
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", object_type "ObjType", count(1) "Cnt" from dba_objects group by object_type;
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", OWNER, count(1) from dba_objects group by owner;
select '&_MyHOST' as pHost, '&_MySID' as pSid, to_char(sysdate,'dd-Mon-yy hh24:mi:ss') as "TimeNow", OWNER, object_type "ObjType", count(1) "Cnt" from dba_objects group by owner, object_type;

clear columns breaks computes

