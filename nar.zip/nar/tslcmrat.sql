/* tslcmrat.sql
     find the librarycache miss ratio over a time interval
     Results:
        < 5% OK
        > 5% increase size of shared pool
*/
set serveroutput on
set feedback off
prompt Checking the library cache miss ratio....
declare
   lctr number := 0;
   xctr number := 0;

   pinsb number := 0;
   pinsa number := 0;
   pinsd number := 0;

   reldb number := 0;
   relda number := 0;
   reldd number := 0;

   timeb number := 0;
   timea number := 0;
   elaptime number := 0;
   secstime number := 0;

   grossrat number := 0;
   ratpersec number := 0;
begin

/* -- get initial values -- */
select sum(l.pins), sum(l.reloads), t.hsecs
  into pinsb, reldb, timeb
from v$librarycache l, v$timer t
group by t.hsecs;

/* -- sleep a little while -- */
dbms_lock.sleep(15);

/* -- get finishing values -- */
select sum(l.pins), sum(l.reloads), t.hsecs
  into pinsa, relda, timea
from v$librarycache l, v$timer t
group by t.hsecs;

/* -- perform the time computations -- */
elaptime := timea - timeb;
secstime := elaptime/100;

/* -- perform the pins and reloads computations -- */
pinsd := pinsa - pinsb;
reldd := relda - reldb;
grossrat := round((reldd / pinsd) * 100);
ratpersec := round(grossrat/secstime);

/* -- report results -- */
dbms_output.put_line (' ');
dbms_output.put_line ('Total Pins:' || pinsd || ', Total Reloads:' || reldd || ', Elapsed Time: ' || secstime || ' seconds');
dbms_output.put_line ('Miss Ratios total: ' || grossrat || '%, avg: ' || ratpersec || '% misses per second.');

end;
/


