-- @mvstatus.sql
-- Displays Materialized View Status


accept trgtmv char default ALL prompt 'Mview <ALL>: '

SELECT MVIEW_NAME, STALENESS, LAST_REFRESH_TYPE, COMPILE_STATE
FROM   all_MVIEWS
where (upper(MVIEW_NAME) like upper('%&trgtmv%') or '&trgtmv' = 'ALL')
ORDER  BY MVIEW_NAME;
