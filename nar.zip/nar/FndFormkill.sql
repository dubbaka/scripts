/* FndFormkill.sql
    find the Oracle session info for a given application OS process id
*/



col machine format a15 trunc
col program format a25 trunc
col LastCallET format a11
col status format a1 trunc
col module format a12 trunc
col username format a12 trunc
col osuser format a10 trunc

set pagesize 200 verify off

spool long_form_sessions.lst
select s.sid, s.status,
       floor(last_call_et/3600)||':'||floor(mod(last_call_et,3600)/60)||':'||mod(mod(last_call_et,3600),60) "LastCallET",
       s.machine, s.module, s.action, s.process, p.spid, s.sql_hash_value, s.username, s.osuser
from   gv$session s, gv$process p, apps.fnd_form f
where  s.paddr = p.addr
and s.inst_id=p.inst_id
and    f.form_name=s.module
and   (floor(last_call_et/3600)) > 1
order  by floor(last_call_et/3600) desc;
Spool off

set heading off feedback off echo off

prompt Run kill commands on DB Server from Oracle OS user
select 'kill -9 '||p.spid||'' 
from   v$session s, v$process p, apps.fnd_form f
where  s.paddr = p.addr
and    f.form_name=s.module
and   (floor(last_call_et/3600)) > 15
order  by floor(last_call_et/3600) desc;

set heading on feedback on echo off
