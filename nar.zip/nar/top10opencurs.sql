/* top10opencurs.sql
	see the top 10 sessions having the most open cursors
	the value of session_cached_cursors affects the cache_hits and cache_count values
	Note: the hard-coded statistic #s are usually correct, but check v$statname to be sure
		2 - cumulative open cursors
		3 - current open cursors
		191 - cache hits
		192 - cache count
		180 - hard parses
		179 - total parses (soft is total - hard)
	SRedmond-OCS
*/
col sid format 9999
col machine format a15 trunc
col proginfo format a20 trunc
col osuser format a8 trunc
select * from (
select s.sid, 
         v0.value cum_open_cursors,
         v1.value cur_open_cursors, 
         v2.value cache_hits,
         v3.value cache_count,
         v4.value hard_parse,
         v5.value - v4.value soft_parse,
         s.osuser, s.machine ,
         nvl(s.module,s.program) proginfo
from v$sesstat v0, v$sesstat v1, v$sesstat v2, v$sesstat v3, v$sesstat v4, v$sesstat v5,
     v$session s
where v0.statistic# = 2
and v0.sid = s.sid
and v1.statistic# = 3
and v1.sid = s.sid
and v2.statistic# = 191
and v2.sid = s.sid
and v3.statistic# = 192
and v3.sid = s.sid
and v4.statistic# = 180
and v4.sid = s.sid
and v5.statistic# = 179
and v5.sid = s.sid
order by 3 desc,7 desc)
where rownum < 11
/

