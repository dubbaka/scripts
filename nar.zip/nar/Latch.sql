-- latchwaits.sql 	get info on sessions that show library cache waits


spool LATCH_WAITS
set serveroutput on size 1000000
declare
	l_kgllkuse raw(100);
	l_kgllkHDL raw(100);
	l_kgllkmod char(1);
	l_kgllktype varchar2(4);

	l_locked_object varchar2(35);
        l_objtype varchar2(10);

	l_holder_sid number;
        l_holder_sql number;
        l_holder_srvr varchar2(30);
	l_holder_status varchar2(1);
	l_holder_module varchar2(48);
	l_holder_lastcallet number;
        l_holder_waitevent varchar2(64);
        l_holder_state varchar2(19);
	l_holder_spid varchar2(10);
	
	-- find all holder kgllock info
	cursor all_kglholders is 
	select * from (
	select decode(x.kgllkmod,2,'S',3,'X',1,'N') decodemode , x.kgllkmod, x.KGLLKTYPE, x.kgllkHDL, x.kgllkuse
	from   dba_kgllock x
	where  x.kgllkMOD > 0
	order  by 2 desc)
	where  rownum < 11;

        -- find the object in contention
	cursor kglobject is
        select /*+ rule */
		substr(o.KGLNAOWN||'.'||o.KGLNAOBJ,1,45) locked_object, o.KGLOBTYP objtype
        from    x$kglob o
        where   o.kglhdadr = l_kgllkhdl
	order   by 1;

	-- find the sesssions waiting for the same object
	cursor all_kglwaiters is
	select sid, decode(trunc(p3/10),2,'S',3,'X',1,'N') req_mode, decode(substr(event,15),'pin','Pin','lock','Lock') wait_type
       	from   v$session_wait
      	where  event like 'library cache %'
	and    p1raw = l_kgllkhdl;

begin
	-- start with kgl holders
	<<kglholders>>
	for each_kglholder in all_kglholders
	loop
		l_kgllkuse := each_kglholder.kgllkuse;
		l_kgllkmod := each_kglholder.decodemode;
		l_kgllktype := each_kglholder.kgllktype;
		l_kgllkhdl := each_kglholder.kgllkHDL;

        	-- find session info for exclusive locks
        	select s.sid, s.sql_hash_value, s.module, s.machine, substr(s.status,1,1), floor(s.last_call_et/60),
		       sw.event, sw.state, p.spid
		into   l_holder_sid, l_holder_sql, l_holder_module, l_holder_srvr, l_holder_status, l_holder_lastcallet,
		       l_holder_waitevent, l_holder_state, l_holder_spid
        	from   v$session s, v$session_wait sw, v$process p
        	where  s.saddr = l_kgllkuse
		and    s.sid = sw.sid
 		and    s.paddr = p.addr;

		dbms_output.put_line('Sid ' || l_holder_sid || ' is holding a ' ||
					l_kgllkmod || ' library cache ' || l_kgllktype );
		dbms_output.put_line(chr(9) || 'Module:' || l_holder_module || ' Status:' || l_holder_status || 
					' Elapsed:' || l_holder_lastcallet || ' minutes from server ' ||
					l_holder_srvr || ' SPID:' || l_holder_spid);

                -- is this holder being blocked by another session
		dbms_output.put_line(chr(9) || 'Current Wait:' || l_holder_waitevent || ' State:' || l_holder_state);

		-- find the object in contention
		<<kglobjs>>
		for each_object in kglobject
		loop

			dbms_output.put_line(chr(009) || 'Object:' || each_object.locked_object || ' (' || 
					each_object.objtype || ')');

		end loop kglobjs;

		<<kglwaiters>>
		for each_waiter in all_kglwaiters
		loop
		 	dbms_output.put_line(chr(9) || 'SID ' || each_waiter.sid || ' waiting for a ' ||
		 		each_waiter.req_mode || ' ' || each_waiter.wait_type);
		 
		end loop kglwaiters;

	end loop kglholders;

end;
/
spool off
