/* apps_alerts1.sql
 Provide basic info on long-running ccmgr jobs and spinning apps modules
 Generic Output: dbname, threshholds
 Long Job Criteria:  any ccmgr job that is running longer than 10 minutes (l_threshhold)
                     AND
                     the current runtime exceeds by l_asrt_factor longer than average successful runtime 
			(phase_code = 'C', status_code = 'C')

  		Output: queue w/node, reqid, prog short name, runtime, avg runtime, max runtime, # jobs
 Spinning Modules Criteria: any active module (that is not a ccmgr program)
		  AND
		   with a last call elapsed time > l_lcet_threshhold number
		Output: module, server, status, Last call elapsed time (minutes), App user name

  Change History
        Date            Version Initials        Comments
	3/6/02		1.4	SDR-Oracle	Added elapsed time to blocking sid in enqueue section
	3/4/02		1.3	SDR-Oracle	Added server and module to blocking sid in enqueue section
	2/28/02		1.2	SDR-Oracle	Modified spinning modules section
        2/15/02         1.1     SDR-Oracle      Added enqueue and wait event info
        2/11/02         1.0     SDR-Oracl       Creation using cmlong, active etc as basis    
*/
set serveroutput on size 100000

declare

	-- general info
	l_name varchar2(9);
   	l_machine varchar2(15);
	l_verno varchar2(10) := 'v1.3';

	-- counters and arrays
	l_longjob_ctr number := 0;
	l_longjob_loop_ctr number := 0;
	l_module_ctr number := 0;
	type modulename is varray(10) of varchar2(30);
	ccmgr_modules modulename := modulename(null,null,null,null,null,null,null,null,null,null);
	l_module_match number := 0;
	i number;
	l_ccmgr_module_name varchar2(30);

	-- long job threshhold (minutes) and trigger (%) values
	l_threshhold number := 5;
	l_asrt_factor number := 1.25;

	-- stuck module threshhold (minutes) and name values
	l_lcet_threshhold number := 5;
	l_module_name varchar2(30) := 'FNDRSRUN';
        l_module_hash number := 664471776;

	-- individual job info
	l_avgruntime number(8,2) := 0;
        l_maxruntime number(8,2) := 0;
        l_jobcount number := 0;  
	l_username varchar2(15);
	l_full_username varchar2(30);

	l_curruntime number(8,2) := 0;
	l_asrt_trigger number(8,2) := 0;
   	
	-- individual module user info
	l_app_userctr number := 0;
	l_app_userid varchar2(20);
	l_app_username varchar2(30);
	l_app_formname varchar2(45);

	-- for enqueue waits
	l_blocking_sid number;
	l_blocking_sid_status varchar2(10);
	l_blocking_sid_machine varchar2(15);
	l_blocking_sid_module varchar2(20);
	l_blocking_sid_lastcallet varchar2(10);
	l_lock_type varchar2(30);
	l_mode_held varchar(30);
	l_mode_requested varchar2(30);

-- cursor for any longrunning ccmgr jobs over threshhold
cursor all_longjobs is
   select q.concurrent_queue_name || ' - ' || target_node qname,
          a.request_id reqid,
          a.phase_code,
          a.status_code,
          (nvl(actual_completion_date,sysdate)-actual_start_date)*1440 cur_runtime,
          c.concurrent_program_name,
          c.concurrent_program_id,
          ctl.user_concurrent_program_name,
          u.user_name,
          u.description full_user_name
   from APPLSYS.fnd_Concurrent_requests a,
	APPLSYS.fnd_concurrent_processes b,
    	applsys.fnd_concurrent_queues q,
    	APPLSYS.fnd_concurrent_programs c,
    	APPLSYS.fnd_concurrent_programs_tl ctl,
 	applsys.fnd_user u
  where a.controlling_manager = b.concurrent_process_id
    and a.concurrent_program_id = c.concurrent_program_id
    and a.program_application_id = c.application_id
    and a.phase_code = 'R'
    and a.status_code = 'R'
    and b.queue_application_id = q.application_id
    and b.concurrent_queue_id = q.concurrent_queue_id
    and ctl.concurrent_program_id = c.concurrent_program_id   
    and ctl.language = 'US'
    and u.user_id = a.requested_by
    and c.concurrent_program_name not like 'FNDWF%'
    and (nvl(actual_completion_date,sysdate)-actual_start_date)*1440 > l_threshhold;

-- cursor for any module session active > threshhold
cursor all_modules is
     select nvl(s.module,'UNK') module,
            to_char(s.logon_time, 'mm/dd hh:mi:ssAM') loggedon,
            s.sid, 
            floor(last_call_et/60) lastcallet,
            s.username, 
            s.osuser,
            p.spid ,
	    s.machine,
	    s.status,
	    s.sql_hash_value,
	    w.event,
	    w.state
       from v$session s, v$process p, v$session_wait w
      where p.addr = s.paddr
        and status != 'INACTIVE'
   	and w.sid = s.sid
        and (s.module is not null and s.machine != l_machine)
        and floor(last_call_et/60) > l_lcet_threshhold
  	and nvl(s.module,'UNK') not like 'FNDWF%';
                                         
begin

	-- get basic info
	select rtrim(substr(p.machine,1,15)), d.name
          into l_machine, l_name
          from v$database d, v$session p
         where p.sid = 1;

        -- display header info 
        dbms_output.put_line('apps_alerts1 - ' || l_verno);
        dbms_output.put_line(to_char(sysdate,'mm/dd/yy') || ' - ' || to_char(sysdate,'hh24:mi'));
        dbms_output.put_line('Server:' || l_machine || chr(9) || 'Database:' || l_name);
        dbms_output.put_line('Longjob Threshhold runtime:' || l_threshhold || ' minutes');
        dbms_output.put_line('Longjob ASRT Factor:' || l_asrt_factor);
        dbms_output.put_line('Spinning Module Threshhold Elapsed Time:' || l_lcet_threshhold || ' minutes');
        dbms_output.put_line(chr(9) || '-----------------------------');
     
	-- get each longrunning job
	<<longjobs>>
    	for each_longjob in all_longjobs
	loop
		-- initialize counters
		l_avgruntime := 0;
		l_maxruntime := 0;
		l_jobcount := 0;
		l_curruntime := each_longjob.cur_runtime;

                -- populate array w/module name to exclude in forms part below
		l_longjob_loop_ctr := l_longjob_loop_ctr + 1;
                ccmgr_modules(l_longjob_loop_ctr) := each_longjob.concurrent_program_name;
                                  

		-- get successful completion stats for this ccmgr job id
    		select  avg(nvl(actual_completion_date-actual_start_date,0))*1440,
          		max(nvl(actual_completion_date-actual_start_date,0))*1440,
          		count(*)
		into 	l_avgruntime,
			l_maxruntime,
			l_jobcount
		from APPLSYS.fnd_Concurrent_requests a
 	       where a.concurrent_program_id = each_longjob.concurrent_program_id
   	 	 and a.phase_code || '' = 'C'
		 and a.status_code || '' = 'C';

		-- have we exceeded avg successful runtime by the specified factor (l_asrt_factor)
		l_asrt_trigger := (l_avgruntime * l_asrt_factor);

		-- we dont care about WorkFlow stuff for this alert
		if l_curruntime > l_asrt_trigger then

			   -- this one now qualifies as a long job
			   l_longjob_ctr := l_longjob_ctr + 1;

			   dbms_output.put_line('Queue:' || each_longjob.qname || chr(9) || 'ReqID:' || each_longjob.reqid);
			   dbms_output.put_line('Submitted By:' || each_longjob.user_name || ' - ' ||
						each_longjob.full_user_name);
			   dbms_output.put_line('Program:' || each_longjob.concurrent_program_name || 
                                             '(' || each_longjob.concurrent_program_id || ')' || chr(9) || 
                                             'Current Runtime:' || l_curruntime);
			   dbms_output.put_line('Avg Runtime:' || l_avgruntime || chr(9) || 
					     'Trigger Runtime:' || l_asrt_trigger || chr(9) ||
					     'Max Runtime:' || l_maxruntime);
			   dbms_output.put_line('# Successful Jobs:' || l_jobcount);
			   dbms_output.put_line(chr(9) || '-----------------------------');

		end if;
	end loop longjobs;

	<<modules>>
	for each_moduser in all_modules
	loop
	    -- see if this module was reported in the longjob section above
	    l_module_match := 0;
	    <<ccmgr_module_list>>
	    for i in 1..l_longjob_loop_ctr loop
		if each_moduser.module = ccmgr_modules(i) then
		 	l_module_match := 1;
		end if;
	    end loop ccmgr_module_list;

	    -- skip this module if it matched ccmgr module
	    if l_module_match = 0 then
		-- increment counter
		l_module_ctr := l_module_ctr + 1;

		-- display generic info on suspect module
		dbms_output.put_line('Module:' || each_moduser.module || chr(9) || 'SQL:' || each_moduser.sql_hash_value);
		dbms_output.put_line('Sid:' || each_moduser.sid || chr(9) || 'Status:' || each_moduser.status ||
					chr(9) || 'OSPid:' || each_moduser.spid);
		dbms_output.put_line(chr(9) || 'Elapsed Time:' || each_moduser.lastcallet || ' minutes');
		dbms_output.put_line('Logged on at:' || each_moduser.loggedon || chr(9) || 'AppServer:' || each_moduser.machine);
		dbms_output.put_line('Current Wait Event:' || each_moduser.event || ' (' || each_moduser.state || ')');

		-- take action on known conditions
		if each_moduser.event = 'enqueue' then
			select /*+ordered */ 
				s.ksusenum,
				vs.status,
				vs.machine,
				nvl(vs.module,'UNK'),
				floor(last_call_et/60)
  			  into l_blocking_sid, l_blocking_sid_status,
				l_blocking_sid_machine, l_blocking_sid_module,
				l_blocking_sid_lastcallet
  			  from v$session_wait w, v$session vs, x$ksqrs r, v$_lock l, x$ksuse s
			 where w.wait_Time = 0
			   and w.event = 'enqueue'
			   and r.ksqrsid1 = w.p2
			   and r.ksqrsid2 = w.p3
			   and r.ksqrsidt = chr(bitand(p1,-16777216)/16777215)||
			                   chr(bitand(p1,16711680)/65535)
			   and l.block = 1
			   and l.saddr = s.addr
			   and l.raddr = r.addr
			   and s.inst_id = userenv('Instance')
			   and w.sid = each_moduser.sid
			   and s.ksusenum = vs.sid;

			dbms_output.put_line(chr(9) || 'Blocking SID:' || l_blocking_sid || ' (' || l_blocking_sid_status || ')');
			dbms_output.put_line(chr(9) || chr(9) || l_blocking_sid_machine || ' - ' || l_blocking_sid_module);
			dbms_output.put_line(chr(9) || chr(9) || 'Elapsed Time:' || l_blocking_sid_lastcallet || ' minutes');
		end if;

		if each_moduser.module = l_module_name and each_moduser.sql_hash_value = l_module_hash then
			-- get apps user info
			select /*+ rule */
       				u.user_name, u.description
		  	into l_app_userid, l_app_username
   		  	from applsys.fnd_logins l,
       				applsys.fnd_user u,
       				v$process p,
       				v$session s
	 		  where s.sid = each_moduser.sid
   				and s.paddr = p.addr
   				and p.pid = l.pid
   				and l.end_time is null
   				and l.spid = s.process
				and l.start_time is not null
   				and l.user_id = u.user_id
   				and l.start_time = (select max(l2.start_time) 
       		                  			from applsys.fnd_logins l2
       		                 			where l2.pid = l.pid);

			-- display module-specific user info
			dbms_output.put_line('App UserName:' || l_app_username);
		end if;

		dbms_output.put_line(chr(9) || '-----------------------------');

	    end if;  -- end of if a module match with ccmgr program
	end loop modules;

	-- final message
	dbms_output.put_line(l_longjob_ctr || ' long-running jobs detected.');
	dbms_output.put_line(l_module_ctr || ' spinning module users detected.');

end;
/

