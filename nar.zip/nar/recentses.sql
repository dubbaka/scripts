col dispord noprint
col timecat head TimeCategory
col totsescnt head "SessCnt"
break on report
compute sum of totsescnt on report
select 1 dispord,'Last 15 Seconds' timecat,
       count(*) totsescnt,
       to_char(min(logon_time),'mm/dd hh:mi:ssAM') earliest,
       to_char(max(logon_time),'mm/dd hh:mi:ssAM') latest
from v$session 
where logon_time >= (sysdate - 1/5760)
  and nvl(username,'AQADMIN') != 'AQADMIN'
union
select 2 dispord,'Last 30 Seconds' timecat,
       count(*) totsescnt,
       to_char(min(logon_time),'mm/dd hh:mi:ssAM'),
       to_char(max(logon_time),'mm/dd hh:mi:ssAM')
from v$session
where logon_time >= (sysdate - 1/2880)
  and logon_time < (sysdate - 1/5760)
  and nvl(username,'AQADMIN') != 'AQADMIN'
union
select 3 dispord,'Last 60 Seconds' timecat,
       count(*) totsescnt,
       to_char(min(logon_time),'mm/dd hh:mi:ssAM'),
       to_char(max(logon_time),'mm/dd hh:mi:ssAM')
from v$session 
where logon_time >= (sysdate - 1/1440)
  and logon_time < (sysdate - 1/2880)
  and nvl(username,'AQADMIN') != 'AQADMIN'
union
select 4 dispord,'Last 2 Minutes' timecat,
       count(*) totsescnt,
       to_char(min(logon_time),'mm/dd hh:mi:ssAM'),
       to_char(max(logon_time),'mm/dd hh:mi:ssAM')
from v$session 
where logon_time >= (sysdate - 1/720)
  and logon_time < (sysdate - 1/1440)
  and nvl(username,'AQADMIN') != 'AQADMIN'
union
select 5 dispord,'Last 4 Minutes' timecat,
       count(*) totsescnt,
       to_char(min(logon_time),'mm/dd hh:mi:ssAM'),
       to_char(max(logon_time),'mm/dd hh:mi:ssAM')
from v$session 
where logon_time >= (sysdate - 1/360)
  and logon_time < (sysdate - 1/720)
  and nvl(username,'AQADMIN') != 'AQADMIN'
union
select 6 dispord,'Last 8 Minutes' timecat,
       count(*) totsescnt,
       to_char(min(logon_time),'mm/dd hh:mi:ssAM'),
       to_char(max(logon_time),'mm/dd hh:mi:ssAM')
from v$session 
where logon_time >= (sysdate - 1/180)
  and logon_time < (sysdate - 1/360)
  and nvl(username,'AQADMIN') != 'AQADMIN'
union
select 7 dispord,'Last 16 Minutes' timecat,
       count(*) totsescnt,
       to_char(min(logon_time),'mm/dd hh:mi:ssAM'),
       to_char(max(logon_time),'mm/dd hh:mi:ssAM')
from v$session 
where logon_time >= (sysdate - 1/90)
  and logon_time < (sysdate - 1/180)
  and nvl(username,'AQADMIN') != 'AQADMIN'
order by 1
/

